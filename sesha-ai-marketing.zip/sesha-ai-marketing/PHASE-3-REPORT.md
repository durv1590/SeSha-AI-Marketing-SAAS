# SeSha AI Marketing — Phase 3 report

AI Copilot · Marketing Strategy · Content Studio · Social Marketing
Built on the stable Phase 2 codebase. Authentication, onboarding and the
dashboard are unchanged and still pass their own suites.

---

## 1. The quality gate

Every line of the brief's fifteen-item gate is an executable assertion in
`tests/phase3-gate.test.ts`, one `describe` block per item, so the gate fails
loudly if the behaviour regresses rather than being ticked by hand.

| # | Gate item | Status | Where it is proven |
|---|---|---|---|
| 1 | AI chat | **PASS** | `phase3-gate` · a question produces a labelled answer and two persisted messages |
| 2 | AI context | **PASS** | `phase3-gate` · business, city, audience and goals reach the system prompt; missing inputs are named; competitors are named but explicitly not described |
| 3 | Strategy | **PASS** | `phase3-gate`, `content-studio` · all 17 sections present; SEO and AEO are placeholders pending a crawl |
| 4 | Content generation | **PASS** | `phase3-gate`, `ai-services` · 20 formats; the format brief reaches the model |
| 5 | Brand voice | **PASS** | `phase3-gate` · the tones and the voice note appear in the system prompt |
| 6 | Languages | **PASS** | `phase3-gate`, `content-studio` · en/hi/hinglish each carry a distinct instruction; script is verified in the output |
| 7 | Save content | **PASS** | `ai-services` · the item is retrievable with its provenance blocks and generator stamp |
| 8 | Regenerate | **PASS** | `phase3-gate` · regeneration bypasses the cache, so it really calls again |
| 9 | Export | **PASS** | `ai-services` · txt/md/json; only md and json keep the labels; the filename cannot carry a path, quote or newline |
| 10 | Usage limits | **PASS** | `phase3-gate`, `ai-orchestrator` · the plan quota refuses a call **before** the provider is contacted |
| 11 | Provider abstraction | **PASS** | `ai-provider`, `phase3-gate` · three adapters behind one interface; the orchestrator runs against a fake that implements nothing else |
| 12 | No exposed API keys | **PASS** | `ai-security` · see §3 |
| 13 | No fabricated facts | **PASS** | `ai-provenance`, `phase3-gate` · see §4 |
| 14 | Error handling | **PASS** | `phase3-gate` · a transient failure retries; a sustained one becomes written prose with no provider detail; failures are audited |
| 15 | Tests | **PASS** | 736 passing, 0 failing; real `tsc` PASS over 115 files |

---

## 2. What was built

**Provider layer** (`lib/ai/provider.ts`) — one `AIProvider` interface, three
adapters (OpenAI, Anthropic, Gemini) written against `fetch`. No SDK was added;
the dependency count is still four.

**Orchestrator** (`lib/ai/orchestrator.ts`) — the only path to a provider.
Eight ordered steps, each able to refuse: agent check → rate limit → quota →
size → cache → call with retry and timeout → provenance parse → record.

**Agents** (`lib/ai/agents.ts`) — 13 declared. Five available (copilot,
strategy, content, social, brand); eight declared with the phase they belong to
(SEO, AEO, schema, ads, lead, analytics, competitor, report). A planned agent
returns a clear "not in this phase", not a crash.

**Copilot** (`/app/ai`) — chat with project context, copy, regenerate, shorten,
expand, translate, change tone, and export to txt/md/json. Every refinement
round-trips through the server so the rewrite is linted again.

**Strategy** (`/app/strategy`) — the brief's seventeen sections, generated one
at a time. The plan is shown first and costs nothing.

**Content Studio** (`/app/create`) — the brief's twenty formats; controls for
language, tone, audience, length, creativity, brand voice, CTA, search intent
and answer intent; English, Hindi and Hinglish.

**Social** (`/app/social`, `/app/calendar`) — the brief's seven platforms, with
real character and hashtag limits, post ideas, captions, hashtags and a planning
calendar.

**Cost control** (`lib/ai/cost.ts`) — usage and token tracking, per-plan
quotas, two layers of rate limit, model selection by task weight, retry with
full jitter, timeout, response limits, and an organization-keyed cache limited
to low-temperature requests.

**API** — 15 route handlers under `/api/ai`, `/api/content`, `/api/strategy`
and `/api/social`, each doing HTTP only; every decision lives in the service
layer and is unit-tested without a server.

**Database** — migration `0003_ai_content.sql`: the `ai_tokens` usage metric,
provenance columns on `ai_messages`, and the `content_items`, `strategies` and
`social_posts` tables with row-level security. 27 tables, and
`scripts/build-schema.mjs --check` confirms the generated schema matches.

---

## 3. "The frontend must never receive provider API keys"

Enforced in five ways, each asserted in `tests/ai-security.test.ts`:

1. Keys are read in **exactly one module**, `lib/ai/provider.ts` — the test
   fails if any other file reads one, so there is one place to audit.
2. No client component imports a server-only AI module as a value. The check
   uses the TypeScript AST, so a type-only import is correctly allowed and a
   regex-level degradation of the check would itself fail a test.
3. No key variable is named `NEXT_PUBLIC_*`, which is the only mechanism that
   could bundle one.
4. No key shape (`sk-`, `sk-ant-`, `AIza`) appears anywhere in the source.
5. `publicStatus()` — the only AI configuration the interface receives — carries
   provider names, a boolean, and model labels. Nothing else.

Two further precautions: the Gemini key travels in the `x-goog-api-key`
**header** rather than the `?key=` query parameter Google documents, because a
query string ends up in every proxy log along the path; and
`userFacingMessage()` maps an error code to written prose so the provider's own
message — which routinely contains the endpoint and organisation id — never
reaches a user.

The audit log records the provider, model and token count, and **not** the
prompt or the output. A log that accumulates every customer's marketing copy is
a liability, not a control.

---

## 4. "Never present AI assumptions as facts"

Three independent defences, because prompting alone is not a control.

**One — the prompt contract.** `PROVENANCE_INSTRUCTION` specifies the seven
kinds and forbids inventing statistics, market sizes, percentages, studies,
surveys, reviews and testimonials. It lives in the same file as the enforcement
so the two cannot drift.

**Two — the parser.** An untagged response is **rejected**, not shown
unlabelled. The user is told the answer was discarded because its sourcing could
not be verified. A `retrieved` or `connected` block naming no source is refused
for the same reason.

**Three — the claim linter.** `lintClaims()` scans unsourced blocks for
statistic-shaped assertions — percentages, currency amounts, large counts,
ranking claims, multipliers, dated market statistics, references to studies and
surveys. Unhedged in an unsourced block is an **error**: the response is
`safe: false`, the artefact saves as `in_review`, and `setStrategyStatus`
refuses to approve it. Hedged is a warning. Crucially this runs *regardless of
what the model claimed the block was*, so a fabricated figure labelled
`recommendation` is still caught.

The context renderer does the complementary half: it always emits a
`NOT AVAILABLE` section naming the gaps, followed by "do not invent any of the
above". Competitors are named but annotated "you know nothing about these
companies beyond their names" — a competitor name is exactly the prompt a model
will happily invent a profile from.

In the interface, an error is shown **above** the answer, so the caveat is read
before the number.

---

## 5. "Do not pretend to publish"

No platform API is connected, so nothing publishes. That is enforced in four
places rather than written in one:

| Where | What it does |
|---|---|
| `PLATFORM_SPECS` | all seven are `canPublish: false`, each with a reason and what an API would require |
| `POST_STATUSES` | `idea \| draft \| ready \| archived` — no published or scheduled state exists |
| `checkPost()` | validates status at **runtime**, so a value from a request body or a cast is refused too |
| `social_posts` CHECK | the database refuses the row |

`plannedFor` is a date on a calendar, not a scheduled job, and the calendar says
so on screen. The render and page audits assert that no control on these screens
is labelled "publish", "post now", "schedule" or "go live" — checked against the
rendered HTML, because a button is what a user actually clicks.

Hashtags count toward the platform character limit, because they do in reality.

---

## 6. Defects found and fixed during Phase 3

Eight, all found by the suites in this phase rather than by inspection.

1. **Ranking-claim regex never matched `#1`.** `\b(#\d+|…)` cannot match — a
   word boundary cannot precede `#`. Moved `\b` inside the alternation for the
   word-initial alternatives only. Until this was fixed, "position yourself as
   the #1 roaster" passed the linter.
2. **Devanagari hashtags were mangled.** `normalizeHashtag` stripped Unicode
   combining marks, turning `#कॉफी` into `#कफ`, and `checkPost` rejected a valid
   Hindi hashtag as malformed. Both character classes now include `\p{M}` — a
   real defect for a product that supports Hindi and Hinglish.
3. **A social post could be written with `status: 'published'`.** The type
   forbade it and the route validated it, but the service trusted the type, so a
   cast slipped through. `checkPost()` now validates the status at runtime,
   which every path already runs. Found by a test asserting the guarantee rather
   than the implementation.
4. **Six type errors in the new service layer**, found the moment a real `tsc`
   became runnable: `assertTenant` returns the narrowed row rather than
   narrowing in place, `GenerationRecord` has no `contextSources` or `usage`,
   `AgentDefinition` has `status` not `available`, and a `Partial<Row>` of a
   readonly interface cannot be assigned to.
5. **`GeneratedBy` was an object, not a string.** The content service wrote
   `'ai'` and `'ai_edited'` into it. Replaced with a proper stamp
   (`generatedByFrom`) plus a `humanEdited` flag.
6. **Two thin platform notes.** Facebook Story and WhatsApp Status said only
   "24 hours." — nine characters of guidance handed to the model as
   `PLATFORM NOTES`. Rewritten to say something useful.
7. **A `const` assertion on a conditional** in the orchestrator test, invalid
   TypeScript that only surfaced once type checking ran.
8. **One vacuous assertion I had written myself** —
   `assert.ok(!regex.test(x) === false || true)`, which can never fail.
   Replaced with a check that no rendered control is labelled with a publishing
   verb.

---

## 7. Verification status

The npm registry was still unreachable (`403` at the gateway), so `npm install`,
`next build`, `next lint` and Playwright still could not run. Phase 3 closed the
largest remaining gap.

### New in this phase

**`scripts/typecheck.mjs` is a real `tsc` run** — the actual compiler, the
project's real strict settings including `noUncheckedIndexedAccess`, over every
`.ts` file: library, content, all 33 API route handlers, and the tests. Within
those files it is not an approximation of type checking; it *is* type checking.
It found six genuine errors on its first run (item 4 above). This was made
possible by linking `@types/node` from a globally installed tool and writing
narrow, verification-only declarations for the `next/*` modules — deliberately
narrower than the real API, since a narrow shim causes an investigable false
error while a wide `any` shim hides a real one.

### Verified

| Check | Result |
|---|---|
| Unit tests | **736 passing, 0 failing** |
| Type check — real `tsc`, strict, every `.ts` file | **115 files, PASS** |
| Static verification — syntax, imports, exports, RSC boundary, route conventions | **188 files, PASS** |
| Component render assertions against real HTML | **39 passing** |
| Page audit — headings, JSON-LD, accessible names, no fake content | **48 surfaces, 0 problems** |
| Generated database schema matches the migrations | **PASS** |
| Phase 1 and Phase 2 suites still green after the Phase 3 changes | **PASS** |

### Not verified — run these first

| Check | How to run |
|---|---|
| Type checking of `.tsx` files (needs `@types/react`) | `npm run typecheck` |
| Lint | `npm run lint` |
| Production build | `npm run build` |
| Browser behaviour | `npm run test:e2e` |
| Visual appearance (Tailwind was never compiled here) | `npm run dev` and look |

`.tsx` is not type-checked because that needs `@types/react`, which was not
installable, and a hand-written stub would report confident nonsense. The
components and pages are covered by *execution* instead — server-rendered, with
their HTML audited — but **a type error inside a component remains the most
likely category of first-build failure.**

`tests/e2e/ai.spec.ts` was authored but never executed. Its generation tests are
opt-in behind `AI_E2E=1`, because a test that spends money at a provider on
every CI run is a test people switch off.

---

## 8. Before using the AI features

- **Set at least one provider key** — `OPENAI_API_KEY`, `ANTHROPIC_API_KEY` or
  `GEMINI_API_KEY`. With none set, every AI surface renders and says plainly
  that AI is not configured on this deployment, with the controls disabled,
  rather than failing on the first click.
- **Review `AI_QUOTAS` in `lib/ai/cost.ts`** against your real pricing. The
  numbers are a defensible starting point, not a costed plan — they were chosen
  to be a real ceiling rather than a label, which is the property the tests
  assert.
- **Nothing approves itself.** Generated content and strategies land as `draft`
  or `in_review` and require a person with `content:publish` to approve. An
  artefact carrying a linter error cannot be approved at all until the offending
  section is regenerated or edited.

---

## 9. Stopping here

Phase 3 is complete. **Phase 4 has not been started**, per the standing
instruction. Section 34 of ARCHITECTURE.md lists the seams Phase 4 plugs into —
the eight planned agents are already declared with their purposes, the crawl
consent captured in Phase 2 is what the `retrieved` provenance kind is waiting
for, and `publishingStatus()` is the single place that will change when a real
platform API is connected.
