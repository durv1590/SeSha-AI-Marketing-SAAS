# SeSha AI Marketing — Architecture

Public website foundation and production architecture for the SeSha AI Marketing platform, built by SeSha AI Marketing.

This document covers **Phase 1** (public website foundation), **Phase 2**
(authentication, accounts, business onboarding and the SaaS foundation),
**Phase 3** (the AI copilot, strategy, content and social layer), **Phase 4**
(SEO, AEO and the secure website crawler), **Phase 5** (structured data,
competitor intelligence and marketing operations), **Phase 6** (analytics,
calendar, automation and reports) and **Phase 7** (subscriptions, usage limits
and the admin platform). Part I is Phase 1; Part II begins at section 13,
Part III at section 23, Part IV at section 35, Part V at section 48, Part VI at
section 63 and Part VII at section 76.

---

# Part I — Phase 1: public website foundation

## 1. Technology decisions

| Layer | Choice | Why |
|---|---|---|
| Framework | Next.js 15, App Router | Server rendering by default, file-system routing, first-class metadata API |
| Language | TypeScript, `strict` + `noUncheckedIndexedAccess` | Indexed access returning `T \| undefined` catches a whole class of runtime bug at compile time |
| UI | React 19 server components | Content ships as HTML; client JavaScript only where interaction requires it |
| Styling | Tailwind CSS v4, CSS-first config | Tokens live in `globals.css`; no `tailwind.config.js` to drift from the CSS |
| Components | Hand-built, shadcn/ui conventions | See the decision record below |
| Fonts | System font stack | Zero font requests, no swap-induced layout shift, no external origin under the CSP |
| Database | PostgreSQL (schema defined, not connected) | Phase 1 has nothing to persist beyond form submissions |
| API | REST route handlers under `/api` | Matches the platform API the authenticated app will expose |
| Tests | `node:test` + tsx, Playwright for e2e | Domain logic is framework-free and testable without a browser |

### Decision record: component library

The brief prefers "an accessible component library such as shadcn/ui". This codebase adopts **shadcn/ui's conventions** — a `cn()` utility, a `components/ui/*` directory, variant-driven styling — but implements the primitives directly rather than installing Radix UI.

Reasons:

1. **Fewer moving parts.** Production dependencies are four packages: `next`, `react`, `react-dom`, and the `clsx` + `tailwind-merge` pair that `cn()` needs. Every additional dependency is a version to track and a supply-chain surface.
2. **The primitives we need are small.** The FAQ accordion is a native `<details>` element, the modal is a native `<dialog>`, the tooltip is forty lines. Each is documented with the accessibility requirement it satisfies.
3. **`<details>` is an AEO requirement, not a preference.** A JavaScript accordion that injects its answer on click hides that answer from anything that does not run scripts. Native disclosure keeps every answer in the server-rendered HTML.

The components are drop-in replaceable: if Phase 2 wants Radix, swapping `components/ui/accordion.tsx` changes nothing above it.

### Decision record: no schema-validation library

Form validation in `src/lib/validation/forms.ts` is hand-written rather than built on a schema library. Phase 1 has exactly two payloads, the rules are explicit and auditable, and the module exposes a `ValidationResult` contract. If Phase 2 adds many payloads, replace the internals behind that contract.

---

## 2. Folder structure

```
sesha/
├── ARCHITECTURE.md              this document
├── README.md                    setup, scripts, verification status
├── package.json                 4 production dependencies
├── next.config.ts               security headers, image + build policy
├── tsconfig.json                strict; "@/*" -> "./src/*"
├── tsconfig.sandbox.json        offline-verification override only
├── postcss.config.mjs           Tailwind v4 plugin
├── eslint.config.mjs            next/core-web-vitals + next/typescript
├── playwright.config.ts         five breakpoint projects
├── .env.example                 every variable, with Phase 2 ones marked
│
├── db/
│   └── schema.sql               PostgreSQL target schema (not yet applied)
│
├── public/
│   ├── favicon.svg              inline-safe SVG mark
│   ├── icon-180.png, icon-512.png
│   ├── site.webmanifest
│   ├── brand/logo-mark.svg
│   └── og/default.png           1200x630 social card
│
├── scripts/                     offline verification harness (see §11)
│   ├── sandbox-setup.mjs
│   ├── verify-static.mjs
│   ├── render-check.mjs
│   └── page-audit.mjs
│
├── tests/
│   ├── routes.test.ts           route registry + breadcrumb resolution
│   ├── seo.test.ts              metadata construction + per-page lint
│   ├── schema.test.ts           structured-data generation
│   ├── schema-validator.test.ts the validator's own rule set
│   ├── security.test.ts         headers, rate limiting, sanitisers, forms
│   ├── links.test.ts            internal-link integrity
│   ├── content-policy.test.ts   claims policy, secrets, a11y invariants
│   └── e2e/                     Playwright specs
│
└── src/
    ├── app/                     routes (see §4)
    ├── components/
    │   ├── ui/                  design system primitives
    │   ├── layout/              header, footer, theme, breadcrumbs, containers
    │   ├── marketing/           page-level composed sections
    │   └── seo/                 JSON-LD renderer
    ├── content/                 all copy, as typed data (see §3)
    ├── lib/
    │   ├── routes.ts            THE route registry
    │   ├── seo/                 core.ts (framework-free) + metadata.ts (adapter)
    │   ├── schema/              JSON-LD generators
    │   ├── schema-validator/    the validator engine
    │   ├── security/            headers, rate limiting, sanitisers
    │   ├── validation/          form validation
    │   ├── api/                 response envelope + rate-limit helper
    │   ├── db/                  types, client seam, repositories
    │   ├── auth/                Phase 2 contract
    │   ├── ai/                  Phase 2 contract
    │   └── utils/               cn(), variant helper
    └── types/
```

---

## 3. Content architecture

**All copy lives in `src/content/` as typed data, never inline in components.**

This is the single most load-bearing decision in the codebase. It means:

- a capability is described **once** and renders identically on the home page, `/features` and every solution page;
- copy can be linted by tests — `tests/content-policy.test.ts` scans the actual strings a visitor sees;
- the Phase 2 migration to database-backed content is a repository swap, because the content types already mirror `db/schema.sql`.

| Module | Contains |
|---|---|
| `site.ts` | Verified organization facts. Unverified fields are `undefined`, never guessed. |
| `seo-map.ts` | Title + description for every route. Linted for length and uniqueness. |
| `modules.ts` | The fourteen platform modules. Home sections 4–17 render from here. |
| `solutions.ts` | Nine industry verticals in full AEO structure. |
| `home.ts` | Home sections 1–3 and 18–22. |
| `pricing.ts` | Tiers with a `verified` flag (see §8). |
| `faq.ts` | Site-wide FAQ, categorised. |
| `blog.ts` | Posts as typed content blocks. |
| `pages.ts` | `/seo`, `/aeo`, `/about`, `/security` long-form content. |
| `legal.ts` | Privacy and terms, with a legal-review flag. |
| `resources.ts` | Resource hub collections. |
| `nav.ts` | Header and footer navigation. |
| `blocks.ts` | The shared content-block model. |

Long-form pages are authored as **typed blocks**, not MDX or HTML. The renderer decides which elements are emitted, so a content author cannot break the document outline — block headings are always `<h2>`, lists are always real lists, and everything server-renders as HTML.

---

## 4. Route architecture

`src/lib/routes.ts` is the **single source of truth** for the public URL surface. Navigation, breadcrumbs, the sitemap, and the link-integrity test all derive from it. A route that is not registered there does not exist.

```
/                              home (23 sections)
/features                      all fourteen modules
/solutions                     index
/solutions/[slug]              9 verticals, statically generated, dynamicParams: false
/seo  /aeo  /security          answer-first (AEO) template
/schema-validator              free tool + explainer
/pricing                       tiers + comparison table
/resources                     hub
/blog                          index
/blog/[slug]                   3 posts, statically generated
/about  /contact  /faq
/privacy  /terms
/sitemap.xml  /robots.txt      generated from the registry
/404                           noindex, with real navigation

/api/health                    GET  liveness
/api/contact                   POST rate-limited, validated, bot-filtered
/api/newsletter                POST rate-limited, validated
/api/schema-validator          POST stateless validation
```

Both dynamic segments set `dynamicParams = false`, so an unknown slug is a real 404 rather than a soft 404 returning 200.

---

## 5. Component architecture

Three layers, each with one responsibility:

**`components/ui/`** — design system primitives. No business knowledge, no content imports. `button`, `card`, `badge`, `alert`, `accordion`, `modal`, `tooltip`, `field` (input / textarea / select / checkbox / honeypot), `icon`.

**`components/layout/`** — site chrome. `container` + `section` (the only places spacing and page measure are defined), `site-header`, `site-footer`, `section-header`, `breadcrumbs`, `logo`, `theme`, `newsletter-form`.

**`components/marketing/`** — composed page sections. `hero`, `module-section`, `feature-card`, `pricing-card`, `steps`, `cta-block`, `faq-section`, `page-hero`, `answer-block`, `answer-page`, `prose`, `contact-form`, `validator-tool`.

### Server vs client

Server components are the default. Exactly five components are client components, each for a specific reason:

| Component | Why it needs the client |
|---|---|
| `site-header` | menu state, Escape/outside-click handling |
| `theme` | reads and writes the stored theme preference |
| `contact-form` | submit lifecycle and error display |
| `newsletter-form` | submit lifecycle |
| `validator-tool` | input state and fetch |
| `tooltip`, `modal` | hover/focus state, `<dialog>` control |

`scripts/verify-static.mjs` enforces the boundary: a file using hooks or DOM event props without `"use client"` fails, and a client component importing a server-only module fails.

### Heading hierarchy

Exactly one `<h1>` per page, always the page title, rendered by `PageHero` or `Hero`. Section headings are `<h2>` via `SectionHeader`; cards inside a section are `<h3>`. Card components take an `as` prop so a grid that sits directly under the `h1` uses `h2` — `scripts/page-audit.mjs` verifies no level is skipped on any page.

---

## 6. Design system

Tokens are defined once in `src/app/globals.css` as CSS custom properties and exposed to Tailwind through `@theme inline`.

- **Semantic naming.** Components use `bg-surface`, `text-fg-muted`, `border-border` — never a raw palette value. Light and dark therefore stay in sync by construction: only the token values are redefined under `.dark`.
- **Colour.** OKLCH throughout, for perceptually even ramps.
- **Theme.** An inline script in `<head>` applies the stored preference before first paint, so there is no flash. Storage access is wrapped in `try/catch` because it throws in some privacy modes.
- **Motion.** Transitions are 120–180ms; `prefers-reduced-motion: reduce` disables animation globally.
- **Focus.** A 2px `:focus-visible` outline on every interactive element. `tests/content-policy.test.ts` fails the build if `outline: none` appears without a replacement.

---

## 7. SEO architecture

Split deliberately into two files:

- **`lib/seo/core.ts`** — framework-free. `buildSeo()`, `canonicalUrl()`, `absoluteUrl()`, `formatTitle()`, and `lintSeo()`. No Next.js import, so it is fully unit tested.
- **`lib/seo/metadata.ts`** — adapts that output into the Next.js `Metadata` shape.

Every page exports `metadata` built through `buildMetadata(seoFor(path))`. `scripts/verify-static.mjs` fails any `page.tsx` without a metadata export.

What is implemented: dynamic titles with a brand suffix and de-duplication, descriptions linted to 70–160 characters, canonicals with query strings and fragments stripped, Open Graph and Twitter cards with a generated 1200×630 image, semantic HTML, enforced heading hierarchy, a generated sitemap, robots directives, a noindex 404 with real navigation, breadcrumbs derived from the route registry, alt text on every image, and an internal-linking architecture in which the footer reaches every registered route (asserted by `tests/links.test.ts`).

**`tests/seo.test.ts` lints every page's metadata.** A truncated title or a duplicated description fails the test run rather than shipping.

---

## 8. AEO architecture

Answer engine optimisation is implemented as **structure the code enforces**, not a style guide.

`components/marketing/answer-page.tsx` renders every AEO page in a fixed order: definition → direct answer → table of contents → explanation → examples → FAQs → related concepts → author → last-updated. The content type (`AnswerPage` in `content/pages.ts`) makes each part required, so a page cannot be authored without them.

Supporting decisions:

- **Nothing essential is behind an interaction.** FAQ answers are server-rendered inside `<details>`, so they are in the HTML whether or not the disclosure is open and whether or not JavaScript runs. `scripts/page-audit.mjs` asserts this on every rendered page.
- **Definitions are marked up as `<dl>/<dt>/<dd>`**, so the term and its meaning are one extractable unit.
- **Authorship and freshness are rendered**, because answer engines favour sources they can attribute.
- **Direct answers are written to survive being quoted with no surrounding context** — the "extraction test" described on `/aeo`.

---

## 9. Structured data architecture

`src/lib/schema/` generates JSON-LD for Organization, WebSite, WebPage, BreadcrumbList, Article, FAQPage and SoftwareApplication.

Three rules are enforced in code and asserted by tests:

1. **Generated only from verified application data.** `prune()` recursively strips undefined, null and empty values, so a missing fact becomes an absent property rather than an empty one.
2. **Never fabricated.** `aggregateRating`, `review` and `award` are never emitted. `buildOffers()` **refuses to publish an unverified price** — `tests/schema.test.ts` and `tests/content-policy.test.ts` both assert this. All three pricing tiers are currently `verified: false`, so no price reaches structured data and none is displayed.
3. **One `@graph` per page**, with stable `@id` anchors so nodes cross-reference correctly. `serializeJsonLd()` escapes `<` and `>` so a value containing `</script>` cannot break out of the tag.

The site validates its own output: `tests/schema.test.ts` runs generated graphs through the same validator that powers `/schema-validator`, and `scripts/page-audit.mjs` validates the JSON-LD in every rendered page.

---

## 10. API, database, auth and AI architecture

**API.** Every route handler follows the same order: rate limit → parse body defensively → bot checks → validate → persist. Responses share one envelope (`lib/api/respond.ts`), always send `Cache-Control: no-store`, and never echo unsanitised input. Internal errors return a generic message.

**Database.** `db/schema.sql` defines the target PostgreSQL schema — tenancy, identity, sessions, workspaces, brand kits, posts, contact submissions, subscribers, leads and an audit log — with row-level security on tenant-scoped tables. Phase 1 does **not** connect to it. `lib/db/repositories.ts` defines the interfaces API routes depend on and ships a logging adapter that records receipt without persisting content or personal data. Phase 2 swaps the adapter; no call site changes.

**Auth.** `lib/auth/` fixes the contract and records the decisions (server-side sessions with opaque tokens in httpOnly cookies, Argon2id, CSRF on every mutation, authorisation checked at the data layer) without implementing anything. `getSession()` returns `null`. Shipping half an auth system would add attack surface for no capability.

**AI.** `lib/ai/` fixes the generation interface and encodes the constraints that make AI output safe to ship: every generation carries a `review` state that starts as `pending`, records the workspace context it drew from, and surfaces `claimsToVerify` rather than publishing marketing claims. The public site performs no generation.

---

## 11. Testing architecture

Four layers, three of which run without a browser or a build:

1. **Unit tests** (`tests/*.test.ts`, `node:test` + tsx) — 197 assertions across routes, SEO, structured data, the validator engine, security, links and content policy. All domain logic is framework-free specifically so it can be tested this way.
2. **Static verification** (`scripts/verify-static.mjs`) — parses every source file with the TypeScript compiler, resolves every import, checks every named import against the target's real exports, and enforces the server/client component boundary and Next.js route conventions.
3. **Render checks** (`scripts/render-check.mjs`, `scripts/page-audit.mjs`) — server-renders components and all 29 pages with `react-dom/server`, then audits the HTML for heading hierarchy, JSON-LD validity, accessible names, and AEO content presence.
4. **End-to-end** (`tests/e2e/`, Playwright) — routes, metadata, keyboard behaviour, theme, responsiveness at five breakpoints, security headers, and the API contract. **Authored but not executed**; see README §Verification status.

Policy is enforced by tests rather than documentation: `tests/content-policy.test.ts` scans visible copy for fabricated metrics, customer counts, superlatives, awards and guarantee promises, and scans source for secrets and accessibility regressions.

---

## 12. Security architecture

- **Headers** (`lib/security/headers.ts`, applied in `next.config.ts`): a content security policy that allow-lists **no external origin**, `frame-ancestors 'none'` plus `X-Frame-Options: DENY`, `nosniff`, `strict-origin-when-cross-origin`, a restrictive permissions policy, same-origin COOP/CORP, and HSTS with preload in production. `X-Powered-By` is disabled.
- **Input**: validated and sanitised server-side. Control characters stripped, email header injection rejected against the **raw** value (sanitising first would hide it — a bug this project's own tests caught).
- **Rate limiting**: fixed-window per client per endpoint, behind a `RateLimitStore` interface. Fails closed when the client cannot be identified.
- **Bots**: an off-screen honeypot plus a submit-timing check. Both are silent — an automated client receives a normal-looking success response.
- **Secrets**: none in the repository; `.env.example` documents every variable. Tests scan for key material and for server-only variables leaking through `NEXT_PUBLIC_` names or into client components.

Known gaps are stated on `/security` rather than implied away: no authentication yet, per-instance rather than distributed rate limiting, inline-script CSP allowances rather than per-request nonces, and no third-party certification.

---

---

# Part II — Phase 2: authentication and the SaaS foundation

Phase 2 adds accounts, roles, tenancy, onboarding and the application shell on
top of Phase 1 **without rebuilding it**. The public site is unchanged in
behaviour; it moved into a `(marketing)` route group so the sign-in pages and
the workspace do not inherit marketing navigation.

## 13. Dependencies: still four

Phase 2 adds **no new production dependency**. Everything security-critical is
built on Node's own `crypto`:

| Need | Built with | Why not a library |
|---|---|---|
| Password hashing | `crypto.scrypt` | Memory-hard, OWASP-accepted. Argon2 needs a native npm package, which the build environment could not install. The `PasswordHasher` interface makes swapping it one file. |
| Session tokens | `crypto.randomBytes` + SHA-256 | 256 bits of entropy; the database stores only the hash. |
| CSRF | `crypto.createHmac` | Signed double-submit, bound to the session id. |
| Google OAuth | `fetch` + `crypto.createPublicKey` | A hand-rolled flow makes every check visible and testable: state, PKCE, nonce, RS256 signature against Google's JWKS. |

## 14. Authentication

`src/lib/auth/` — all framework-free and unit tested; `current-session.ts` is
the only file that touches Next.js APIs.

| Module | Responsibility |
|---|---|
| `password.ts` | scrypt hashing (N=2^16, r=8, 64-byte output), versioned self-describing format, `needsRehash`, NIST-style length-first policy, and `dummyVerify` for timing parity |
| `tokens.ts` | Opaque token issue/hash/expiry for sessions, verification and reset |
| `session.ts` | Session record validation against **three independent expiry rules**, cookie attributes |
| `csrf.ts` | Signed double-submit tokens plus a fail-closed origin check |
| `lockout.ts` | Two independent counters — per account and per client address — with exponential, temporary back-off |
| `rbac.ts` | Four roles, 27 permissions, minimum-role table |
| `service.ts` | The flows: sign-up, sign-in, verification, reset, change, deletion, OAuth |
| `oauth/google.ts` | The full OAuth 2.0 + PKCE + OIDC implementation |

### Decisions that are easy to get wrong, and how they are handled

**Account enumeration.** Sign-up returns an identical response whether or not
the address is registered — the difference is which email is sent (the account
holder gets "someone tried to sign up"). Password reset always returns the same
message. Sign-in spends the same CPU on a missing account as on a real one, so
response time is not an oracle either. All three are asserted by tests.

**Session fixation.** The token is rotated on every privilege change: sign-in,
email verification, password change. A password reset revokes every session; a
password change revokes every session *except* the one making the change.

**Sessions expire three ways.** Their own `expiresAt`, a 14-day idle timeout,
and a 90-day absolute lifetime that constant activity cannot extend. `lastActive`
is only written when it is more than an hour stale, so a busy session does not
issue a write per request.

**Lockout is temporary.** Permanent lockout turns a brute-force attempt into a
denial-of-service against the real user — anyone who knows an email address
could lock its owner out. Back-off is exponential and capped; a successful
sign-in clears the account counter but *not* the address counter.

**Google OAuth.** State (login CSRF), PKCE S256 (stolen-code replay), nonce
(token replay), and RS256 signature verification against the published JWKS,
followed by issuer, audience, expiry and nonce claim checks. `alg: none` and
algorithm confusion are rejected explicitly. An unverified provider email is
refused, and linking by email to an existing *password* account is refused —
otherwise a provider-side email change becomes an account-takeover path.

## 15. Authorization and tenancy

Four roles in a strict order: `user < team_member < manager < admin`. Roles are
**per organization**, so a permission check is always (user, organization,
permission).

Permissions are declared as a **minimum role per permission** rather than a list
per role, so a new permission cannot be accidentally granted to nobody or to
everybody. A test asserts the mapping is monotonic across the role order, and
another asserts every permission has an entry.

Authorization runs at **four independent layers**:

1. **UI** — controls the user cannot use are hidden. A courtesy, never a control.
2. **API route** — `requireAuth` / `requireAuthorized` before anything else.
3. **Service layer** — `requirePermission` then the tenant guard.
4. **Database** — PostgreSQL row-level security on every tenant-scoped table.

**Cross-tenant access returns 404, not 403.** A 403 confirms the resource
exists, which turns an authorization check into an id-enumeration oracle. The
error message for "not yours" is byte-identical to "does not exist", and a test
asserts that.

The repository interfaces make the filter impossible to forget: there is no
`findById(id)` for a tenant-scoped row, only `findById(organizationId, id)`.

## 16. Business onboarding

Four steps — business, marketing profile, website access, review — producing an
**AI Marketing Profile** with a stored completeness score. Every field the brief
lists is captured and validated server-side; unknown goals, channels and tones
are dropped rather than trusted, and the competitor list is capped.

## 17. Website crawl consent

**Nothing may fetch a customer's website without a live consent row.** Entering
a URL during onboarding grants nothing — a test asserts exactly that.

The consent step states, in the interface: what would be accessed, why, the page
and rate limits, robots.txt handling, how long data is kept, how to stop and
delete it, and that the crawler is not built yet. The checkbox starts unchecked
and the step is skippable.

Each grant records `consent_version`, so a later change to the wording or the
default scope cannot retroactively widen a consent someone already gave. Bump
`CRAWL_CONSENT_VERSION` whenever the disclosure changes; a stale version is
refused.

The URL validator doubles as an **SSRF guard**: http/https only, no embedded
credentials, no non-standard ports, and loopback, link-local, private,
carrier-grade-NAT and cloud-metadata addresses are all rejected.

## 18. Projects and tenant isolation

A project is the isolation unit. Business data, brand, content, campaigns,
leads, analytics, AI conversations, website data and audits all hang off one,
and every one of those tables carries `organization_id` as well.

Plan limits are enforced in the **service layer**, not the UI: Starter 1
project, Growth 3, Agency 50. Deleting frees a slot. Slugs are unique per
organization, and the same slug may exist in another organization.

## 19. Database

24 tables. Migrations are forward-only in `db/migrations/`; `db/schema.sql` is
**generated** from them by `scripts/build-schema.mjs`, and a test fails if it is
stale. Another test asserts the table list in code matches the migrations
exactly, in both directions.

Conventions enforced by test: a primary key on every table, `timestamptz`
everywhere, `organization_id` plus row-level security on every tenant-scoped
table, an `ON DELETE` behaviour on every foreign key, `citext` emails, session
tokens stored only as hashes, and no plaintext password column anywhere.

**Soft delete is per-table and deliberate.** `users`, `organizations`,
`businesses` and `projects` use `deleted_at`, because audit records reference
them. `sessions` and tokens are hard-deleted — keeping a revoked session row
"for history" is a liability, not history. The audit log is append-only,
enforced by database rules so a bug cannot erase it.

Account deletion is two-stage: immediate soft delete (sign-in blocked, sessions
revoked, tokens void) and a scheduled `anonymize_deleted_user` job after the
retention window. A partial unique index on `users.email WHERE deleted_at IS
NULL` means the address can be reused afterwards.

## 20. Dashboard foundation

`(app)/layout.tsx` is the page-level authorization boundary: it resolves the
session server-side and redirects if it is invalid or onboarding is incomplete.

**The Edge middleware is not the gate.** It cannot reach the database, so it
only observes that a cookie exists and redirects early for a better experience.
A forged cookie sails past it and is stopped by the layout and by every API
route. Treating middleware as the boundary is a common and serious mistake, and
the file says so at the top.

Navigation matches the brief exactly. Every item declares `status:
'available' | 'planned'`, and a planned item renders as a **disabled element
with a "Soon" badge — not a link**. Its page shows what the feature will do and
which phase it belongs to. No placeholder charts, no fake rows: the page audit
asserts the coming-soon component renders no chart-like content.

3 of 16 areas are available (Schema Validator, Brand Kit, Settings) plus the
workspace home and projects. 12 are marked Soon.

## 21. Security additions

| Control | Implementation |
|---|---|
| Rate limiting | Per client address, per endpoint, in front of the per-account lockout |
| Brute force | Two independent counters, exponential temporary back-off |
| CSRF | Fail-closed origin check + signed double-submit bound to the session |
| Session expiry | Three independent rules, all checked per request |
| Secure cookies | httpOnly, Secure in production, SameSite=Lax, never `None` |
| Input validation | Server-side and authoritative; the client mirrors for convenience only |
| Audit logging | Every auth outcome including failures and denials; append-only |
| Secrets | `AUTH_SECRET` required in production — the app refuses to start without it |
| SSRF | Private-address blocklist on every user-supplied URL |

IP addresses are **keyed-hashed** before storage: an unsalted IPv4 hash is
trivially reversible by brute-forcing 2^32 values. Audit entries are asserted by
test to contain no raw address and no password.

## 22. What Phase 3 plugs into

| Phase 3 work | Seam that already exists |
|---|---|
| PostgreSQL adapter | `Database` interface + 24-table schema + migrations |
| AI copilot | `lib/ai/` generation interface with mandatory review states; `ai_conversations` / `ai_messages` tables |
| Content Studio | `posts` table, brand kit, review states |
| Website crawler | Consent records with scope, limits and retention already captured |
| Distributed rate limiting | `RateLimitStore` and `LockoutStore` interfaces; `login_attempts` table |
| Billing | `subscriptions` / `usage_records` tables with external-id columns |
| Team invitations | `memberships` table and the role model |
| Nonce-based CSP | `securityHeaders()` is a single function |

---

# Part III — Phase 3: AI copilot, strategy, content and social

Phase 3 is where the product starts spending money on someone else's API and
producing text a user might publish under their own name. Both facts shape the
architecture more than any feature does.

## 23. Dependencies: still four

No dependency was added in Phase 3. The AI providers are reached with `fetch`
and a small adapter each, rather than three vendor SDKs — roughly 200 lines
against three transitive trees, with the useful side effect that swapping a
provider is a file, not a migration.

## 24. The provider layer

`lib/ai/provider.ts` defines one interface and three adapters.

```ts
interface AIProvider {
  readonly name: ProviderName;
  readonly models: readonly ModelSpec[];
  isConfigured(): boolean;
  complete(request: CompletionRequest, model: string, fetchImpl?: typeof fetch): Promise<CompletionResult>;
}
```

**Keys never reach the browser.** They are read from `process.env` inside this
one module — `tests/ai-security.test.ts` asserts that no other file reads them,
that no client component imports the module as a value (checked with the
TypeScript AST, so a type-only import is correctly ignored), and that no key
shape appears anywhere in the source. `publicStatus()` is the only thing the
interface sees: provider names, a configured flag, and model labels.

Two smaller decisions worth naming:

* The Gemini key travels in the `x-goog-api-key` **header**. Google documents a
  `?key=` query parameter, which is simpler and ends up in every proxy log and
  browser history along the path.
* `userFacingMessage()` maps an error code to written prose. The provider's own
  message never reaches the user, because it routinely contains the endpoint,
  the organisation id, and occasionally the request body.

`fetch` is injected rather than imported, which is what lets the adapters be
tested against a fake transport with no network.

## 25. The orchestrator

`AIOrchestrator.run()` is the only path to a provider in the product. Its order
is deliberate and every step can refuse:

1. **Agent check** — is this agent implemented in this phase?
2. **Rate limit** — per organization, per minute.
3. **Quota** — generations and tokens for the billing period, budgeting the
   worst-case output so a call that cannot finish never starts.
4. **Size** — prompt and context against the model's window.
5. **Cache** — organization-keyed, and only for temperature ≤ 0.3, because
   caching a creative generation returns the same "fresh" draft twice.
6. **Call** — with retry (full jitter) and a hard timeout.
7. **Provenance** — parse, and *reject the response* if it is untagged.
8. **Record** — usage and an audit entry.

Steps 2–4 all run before the provider is contacted, so a request that will be
refused costs nothing. A cache hit is recorded with zero tokens and does not
count against the generation quota, because it did not generate anything.

The audit entry carries the provider, model, token count and warning count. It
does **not** carry the prompt or the output; `tests/phase3-gate.test.ts`
asserts that, because an audit log that accumulates every customer's marketing
copy is a liability rather than a control.

## 26. Agents

Thirteen agents are declared in `lib/ai/agents.ts`. Five are available
(copilot, strategy, content, social, brand) and eight are declared with the
phase they belong to (SEO, AEO, schema, ads, lead, analytics, competitor,
report). A planned agent is not a missing key in a map — it exists, it has a
purpose string, and calling it returns a clear "not in this phase" rather than
a crash.

Temperature is set per agent and is a real decision: strategy runs at 0.25 so
the same inputs give the same answer, content at 0.7 because variation is the
point. That single number also decides cacheability.

## 27. Provenance — the part that matters most

Every response is a list of blocks, each tagged with one of seven kinds:
`user_provided`, `connected`, `retrieved`, `ai_estimate`, `ai_inference`,
`recommendation`, `unavailable`. The first three are sourced; the rest are the
model reasoning.

There are **three independent defences**, because prompting alone is not a
control:

1. **The prompt contract.** `PROVENANCE_INSTRUCTION` tells the model the format
   and forbids inventing statistics, market sizes, studies, reviews and
   testimonials. It lives in the same file as the enforcement so the two cannot
   drift apart.
2. **The parser.** An untagged response is *rejected* — not shown unlabelled.
   `retrieved` and `connected` blocks must name a source or the response is
   refused. This is the step that makes "never present AI assumptions as facts"
   structural rather than aspirational.
3. **The claim linter.** `lintClaims()` scans unsourced blocks for
   statistic-shaped assertions: percentages, currency amounts, large counts,
   ranking claims, multipliers, dated market statistics, references to studies
   and surveys. Unhedged in an unsourced block is an **error** and makes the
   response `safe: false`; hedged is a warning. It runs *independently of what
   the model claimed the block was*, which is the point — a fabricated figure
   labelled `recommendation` is still caught.

An artefact carrying a linter error is saved as `in_review`, and
`setStrategyStatus` refuses to approve it at all. The interface shows the
warning **above** the answer, so the caveat is read before the number.

The context renderer does the complementary job: it always emits a
`NOT AVAILABLE` section naming what is missing, followed by "do not invent any
of the above". Competitors are named but explicitly annotated "you know nothing
about these companies beyond their names", because a competitor name is exactly
the prompt a model will happily hallucinate a profile from.

## 28. Strategy: seventeen sections, generated one at a time

Sections have different input requirements, so they are generated
**individually** rather than as one document. A single call would either refuse
everything because one input was missing, or produce a document whose weakest
section looks exactly like its strongest.

`planSections()` classifies each of the seventeen as `full`, `partial` or
`unavailable`:

* **unavailable** — a required workspace input is missing. Not generated at
  all; stored with what it needs.
* **partial** — only an unconnected data source is missing. Written from
  principles, with an explicit instruction to state the gap rather than fill
  it. SEO and AEO are permanently partial until a crawl runs, which is exactly
  what the brief asks for with "placeholder".
* **full** — everything it needs is present.

The plan is shown to the user *before* generation, and costs nothing. Sections
run sequentially: a quota that runs out mid-document stops the run and records
the remainder as not generated, rather than firing seventeen calls in parallel
and discovering the budget halfway through.

## 29. Content Studio

Twenty formats, three languages, and controls for tone, audience, length,
creativity, brand voice, CTA, search intent and answer intent. Two decisions:

* **An unknown enum value is rejected, not coerced.** A silently substituted
  tone produces content the user did not ask for and cannot tell apart from
  content they did.
* **`checkContent()` checks the script.** Hindi output with almost no
  Devanagari, or Hinglish containing Devanagari, means the language control was
  ignored — and script is the only distinction between Hindi and Hinglish, so
  it is checked rather than trusted.

The word target shown beside the length control is computed by the same
function that builds the prompt, so the number on screen is the number the
model was asked for.

## 30. Social: the negative requirement

Seven platforms, and **none of them can publish**. That is enforced in four
places rather than written in one:

| Where | What it does |
|---|---|
| `PLATFORM_SPECS` | every platform is `canPublish: false` with a reason and an API requirement |
| `POST_STATUSES` | `idea \| draft \| ready \| archived` — there is no published or scheduled state |
| `checkPost()` | validates the status at **runtime**, so a value from a request body or a cast is refused too |
| `social_posts` CHECK | the database refuses the row |

`plannedFor` is a date on a calendar, not a scheduled job, and the calendar
says so on screen. Hashtags count toward the platform character limit, because
they do in reality and a draft that passes here but fails in the composer is
worse than no check.

The renderer and page audits assert that no control on these screens is
labelled "publish", "post now", "schedule" or "go live" — checked against the
rendered HTML, because a button is what a user actually clicks.

## 31. Cost control

`lib/ai/cost.ts` holds `AI_QUOTAS` per plan (generations, tokens, requests per
minute, input and output ceilings), the rate limiter, the cache, model
selection by task weight, and retry with full jitter. Three layers sit in front
of a provider call and none substitutes for another:

* the **HTTP rate limit** (`ai`, `aiBatch`) is per client address;
* the **request rate** is per organization per minute;
* the **quota** is per organization per billing period.

## 32. Service layer

Routes do HTTP — rate limit, CSRF, auth, envelope — and nothing else. Every
decision lives in `lib/{ai,content,strategy,social}/service.ts`, framework-free
and unit-tested against the in-memory database. Ownership is checked **before**
the provider is contacted, so a cross-tenant prompt never costs money; a
cross-tenant resource is a 404 with a byte-identical message to a genuinely
missing one, as in Phase 2.

Editing generated text clears its provenance blocks and stamps
`generatedBy.humanEdited`. Keeping provenance that described the *generated*
text against text a person rewrote would be a false attribution.

## 33. Verification: what changed in Phase 3

The npm registry was still unreachable, so `npm install`, `next build` and
Playwright still could not run. Phase 3 closed the largest part of that gap:

**`scripts/typecheck.mjs` is a real `tsc` run.** The actual TypeScript
compiler, the project's real strict settings including
`noUncheckedIndexedAccess`, over every `.ts` file — library, content, API
routes and tests. Within those files it is not an approximation of type
checking; it *is* type checking. It found six genuine type errors in the Phase 3
service layer on its first run.

`.tsx` files are still not covered: that needs `@types/react`, which is not
available offline, and a hand-written stub would report confident nonsense. The
components and pages are covered by execution instead —
`scripts/render-check.mjs` and `scripts/page-audit.mjs` render them and assert
on the HTML. They remain the part of the codebase most likely to surface
something on the first real `npm run build`.

## 34. What Phase 4 plugs into

| Phase 4 work | Seam that already exists |
|---|---|
| SEO / AEO / schema agents | declared in `AGENTS` with purpose and phase; `planSections` already marks their strategy sections partial |
| Website crawler | crawl consent from Phase 2; `retrieved` provenance kind and source references already defined |
| Real publishing | `publishingStatus()` is the single place that says no; `POST_STATUSES` is one constant |
| Ads, leads, analytics, reports | agent definitions, usage metrics and the review-state model |
| Streaming responses | `complete()` returns a whole result; a `stream()` sibling fits the same interface |
| Prompt versioning | agent instructions are data in one module |

---

# Part IV — Phase 4: SEO, AEO and the secure website crawler

Phase 4 adds the part of the product that reads the real world: a crawler that
visits the customer's own website, a store of what it found, two rule-based
audits over that store, and a keyword system. It is the first phase where
SeSha makes outbound network requests to an address a user supplied, which is
why most of this part is about refusing to do so.

Sections 23 to 34 are Phase 3; Part IV begins at section 35.

## 35. Dependencies: still four

No dependency was added. The crawler uses `node:http`, `node:https`, `node:dns`
and `node:net`; the HTML and XML readers are written here.

Two absences are deliberate, not an oversight:

- **No HTML parser.** A full DOM for extraction would be convenient. It is also
  a large attack surface pointed directly at untrusted input, and it tempts the
  code into executing or evaluating what it reads. `parse.ts` strips
  `script`, `style`, `noscript`, `template`, `svg` and `iframe` *first*, then
  extracts the specific fields the audit needs with bounded expressions.
- **No XML library.** XML parsers are where XXE and entity-expansion bugs live.
  `sitemap.ts` refuses outright any document containing `<!DOCTYPE` or
  `<!ENTITY`, then reads the handful of elements a sitemap is allowed to have.

## 36. The crawl pipeline

```
URL  →  url-policy  →  ip-policy  →  resolver  →  robots  →  sitemap
                                                              ↓
        analyse  ←  store  ←  parse  ←  fetcher  ←  queue  ←  seeds
```

One module per stage, each independently testable, in `src/lib/crawler`:

| Module | Responsibility |
|---|---|
| `url-policy.ts` | Is this a URL we are willing to treat as a public web page? Scheme, shape, hostname, credentials, port, normalisation. |
| `ip-policy.ts` | Is this *address* one we are allowed to connect to? Byte-level CIDR checks over 15 IPv4 and 9 IPv6 ranges plus 5 named cloud-metadata addresses. |
| `resolver.ts` | Resolve once, check every answer, return the address to connect to. |
| `fetcher.ts` | Connect to that address with limits, re-validating every redirect. |
| `robots.ts` | What the site permits, failing closed when it cannot be read. |
| `sitemap.ts` | Discover URLs the site publishes, same-site only. |
| `queue.ts` | The frontier: budget, depth, dedup, concurrency, politeness. |
| `parse.ts` | Extract the fields the audits need. No DOM. |
| `crawler.ts` | The pipeline itself. |

## 37. SSRF: the three defences that actually matter

A crawler is a request forgery engine that a user points wherever they like. The
protections below are not a list of filters; they are three specific answers to
three specific bypasses.

**1. A hostname check alone is defeated by DNS.** `ip-policy.ts` is never
asked about a name the attacker controls resolution for — `resolver.ts`
resolves the name once and judges **every** A and AAAA record it gets back. If
any answer is private, the name is refused outright rather than connected to on
the public answers and hoped about. An already-blocked hostname (`localhost`,
`*.localhost`, `*.internal`, `.local`, reserved TLDs) never reaches DNS at all.

**2. A check followed by `fetch` is defeated by DNS rebinding.** Between a
check and a connection, `fetch` resolves the name *again*, and an attacker who
controls the record can answer `93.184.216.34` the first time and `127.0.0.1`
the second. `fetch` offers no way to pin a resolved address, which is the reason
this crawler uses `node:http`/`node:https` directly: the agent is given a
`lookup` that ignores the hostname and returns the address already checked.

```ts
lookup: (_hostname, _opts, callback) => {
  // The single-address callback form, which is what the agent uses.
  callback(null, req.address, req.family);
},
```

The socket cannot perform its own resolution, so there is no second answer to
differ from the first.

**3. A string-prefix blocklist is defeated by encoding.** `10.0.0.1` is
blocked by a naive prefix check; `0xA.0.0.1`, `012.0.0.1`, `167772161`,
`::ffff:10.0.0.1` and `64:ff9b::10.0.0.1` are not. `parseIpv4` refuses
ambiguous forms outright — a leading zero, a non-decimal digit, anything that is
not four plain decimal octets — and `finishIpv6` unwraps IPv4-mapped, NAT64 and
6to4 addresses so that `checkAddress` judges **both** the outer bytes and the
embedded address. Comparison is byte-level against the range's prefix length,
never string matching.

The fifteen IPv4 ranges: `0.0.0.0/8`, the three RFC 1918 private ranges,
CGNAT shared space, loopback, link-local, IETF protocol assignments, the three
TEST-NET documentation ranges, the 6to4 relay anycast range, benchmarking,
multicast and reserved. The nine IPv6 ranges: unspecified, loopback,
IPv4-mapped, discard-only, IETF protocol assignments, documentation,
unique-local, link-local and multicast. The five metadata addresses are named
individually as well as covered by range — `169.254.169.254` (AWS, Azure, GCP,
DigitalOcean), `169.254.170.2` (AWS ECS), `100.100.100.200` (Alibaba),
`192.0.0.192` (Oracle) and `fd00:ec2::254` (AWS IPv6) — so that a denial reads
"cloud metadata endpoint" rather than "link-local", which would invite someone
to wonder whether the rule is too broad.
`tests/crawler-security.test.ts` names each one.

## 38. The other limits, and why each exists

| Limit | Default | What it prevents |
|---|---|---|
| Max pages | 50 (plan ceiling 300, absolute 500) | an unbounded crawl of a large site |
| Max depth | 3 (plan ceiling 5) | one deep branch crowding out the site's own structure |
| Concurrency | 2 | the crawl being more load than a few simultaneous visitors |
| Politeness delay | 500 ms per host | request bursts |
| Per-page timeout | 15 s | a slow endpoint holding a worker |
| Whole-crawl timeout | 10 min | a job that never ends |
| Response size | 2 MB | memory exhaustion from a large or endless body |
| Redirect hops | 5, loops detected separately | redirect chains and cycles |

Two properties are worth stating because they are easy to get wrong:

- **The page budget is checked on dequeue as well as enqueue.** A budget checked
  only when adding can be overshot by work already in flight.
- **Every limit narrows.** `resolveLimits` intersects the plan ceiling, the
  consent record's own `maxPages` and the deployment's `CRAWLER_MAX_PAGES`;
  `CRAWLER_EXTRA_BLOCKED_HOSTS` can only add to the blocklist. There is no
  variable, plan or request that widens the policy, and
  `tests/crawler-security.test.ts` asserts that a configured value above the
  built-in cap is ignored rather than honoured.

## 39. robots.txt, handled properly

Most robots parsers in the wild are wrong in the same three ways, so this one is
explicit about each.

- **Most-specific rule wins**, measured by pattern length, with `Allow`
  breaking a tie — not first-match, which is the common bug.
- **Groups are not merged.** A `User-agent: *` group and a
  `User-agent: SeShaBot` group are separate; the most specific matching group
  is the one that applies, and its rules are the only rules.
- **`*` and `$` wildcards** are honoured in paths.
- **Unreadable means do not crawl.** A 5xx, a timeout or a connection failure
  returns `ROBOTS_UNAVAILABLE` and the crawl does not start. A 404 means the
  site published no rules, which is permission. Failing open on a 500 would mean
  a site's momentary outage became consent.
- **`Crawl-delay` is recorded and clamped**, not rejected. An earlier version
  refused an out-of-range value and then fell back to the *floor* — the opposite
  of what the site asked for.
- **robots governs the sitemap fetch too.** `Disallow: /` disallows
  `/sitemap.xml`, and an earlier version fetched it anyway.

The user agent is honest and traceable:
`SeShaBot/1.0 (+https://seshaaimarketing.com/bot; website audit on behalf of the site owner)`.
No cookies and no authorization header are ever sent.

## 40. Consent is the authorisation, and it is checked twice

Phase 2 captured crawl consent; Phase 4 is the first code that relies on it.

- Consent is checked **when the job is queued** and **again inside
  `executeCrawl`**, because a job can sit in the queue after consent is
  withdrawn. `tests/jobs.test.ts` fails if the second check is removed.
- The crawl's limits are the **intersection** of the plan ceiling and the
  `maxPages` the consent record itself records.
- `crawls.consent_id` references the consent row `ON DELETE RESTRICT`: the
  record that authorised a crawl cannot be deleted while the crawl exists.
- Withdrawal hard-deletes page content (`deleteCrawlDataForConsent`), as does
  retention lapse (`deleteExpiredCrawlData`). The crawl row survives so the
  history of what was done remains auditable; the content does not.
- **Raw HTML is never stored.** The audits need extracted fields, not markup,
  and keeping a copy of someone's whole site is a liability with no matching
  benefit. A gate test asserts no stored page contains `<html` or `<script` and
  that no raw-HTML column exists.

Fixing this phase's dependency on consent surfaced a **Phase 2 defect**:
`revokeCrawlConsent` looked the record up via `tenant.projectId`, which is
optional on `TenantContext` and is not set on a settings request, so the lookup
always came back empty and revocation always threw `NotFound`. **Consent could
not actually be withdrawn.** `CrawlConsentRepository.findById` was added, the
lookup fixed, and a regression test written.

## 41. What is extracted, and what is stored

`parse.ts` returns exactly what the brief lists — URL, status, title, meta
description, H1/H2/H3, text content, internal and external links, images with
alt text, canonical, robots directives, HTTPS, structured data, FAQ pairs,
author, publisher and entity signals — plus `crawledAt`, so every finding can
say *when* the evidence was gathered.

One detail that was wrong first: an FAQ pair derived from a question-shaped
heading is not the same evidence as one declared in `FAQPage` structured data.
`ExtractedFaq` now carries `source: 'structured_data' | 'heading'`, and only
structured data counts as an FAQ for audit purposes.

Storage is five new tables in `0004_crawl_audit.sql` — `jobs`, `crawls`,
`crawled_pages`, `audits`, `keywords` — bringing the schema to **32 tables**,
all with row-level security, all tenant-scoped. `jobs` carries a partial unique
index (`jobs_one_active_per_project`) so a project cannot have two active jobs.

## 42. The findings contract

Every recommendation the product makes, in either audit, is the same six-part
record — and the shape is enforced by the type, not by a convention:

| Part | What it is |
|---|---|
| Issue | what is wrong |
| Evidence | the specific thing found, quoted from the crawl |
| Recommended change | what to do |
| Expected benefit | what improving it plausibly helps |
| Confidence | high / medium / low |
| Data basis | what this was derived from |

`lintFindings` then scans every finding for a forbidden promise — AI ranking, AI
citation, AI visibility, guaranteed traffic, ranking superlatives — and **drops**
any finding that makes one. Dropping rather than flagging is deliberate: a
flagged finding is still on screen.

`scoreFindings` returns a score *and* a `basis` stating that the score is
SeSha's own weighting of its own checks, not a measurement by Google or by any
answer engine. The UI renders the two together; `tests/audit.test.ts` fails if a
score can reach the screen without its basis.

`AEO_DISCLAIMER` states plainly that no tool can measure whether an AI system
cites a page. The AEO audit reports structure that is *associated with* being
quotable, and says so.

## 43. Fifteen SEO areas, twelve AEO areas, and what was not checked

`auditSeo` covers the fifteen areas the brief names; `auditAeo` covers the
twelve. Both return a `notChecked` list that is **always non-empty**, because
both always have something they could not determine from an HTML crawl —
rendering behaviour, Core Web Vitals, anything behind JavaScript. An audit that
claimed to have checked everything would be the dishonest version.

The crawler does not run JavaScript, and the product says so on screen rather
than only in this document. `/app/website-audit` publishes the crawler's policy
in-product: who the bot is, that it obeys robots.txt and fails closed, that it
cannot be pointed at a private network, and that it does not execute scripts. A
user authorising a crawler is entitled to read what it does without reading the
source.

## 44. Keywords without invented numbers

Nine kinds (`KEYWORD_KINDS`), each keyword carrying query, intent, relevance,
competition, priority, suggested content format and entities — and search volume
expressed as a discriminated union with no bare-number variant:

```ts
export type SearchVolume =
  | { kind: 'unavailable'; label: 'Data unavailable'; why: string }
  | { kind: 'estimate';    label: 'AI estimate'; magnitude: VolumeMagnitude; basis: string }
  | { kind: 'measured';    label: 'Measured'; monthly: number; source: string; asOf: string };
```

A number can only exist alongside a `source` and an `asOf`. No data source is
connected in Phase 4, so every keyword is `unavailable` with a written reason.
The `keywords` table stores `volume` as `jsonb` and deliberately has **no
numeric volume column**, with a comment in the migration explaining why: a
numeric column would eventually be populated with an estimate by someone in a
hurry. `PRIORITY_BASIS` states that priority is computed from relevance,
intent and competition and **excludes volume**, so priority is not a number
pretending to be derived from data nobody has.

## 45. Background jobs

`jobs/types.ts` defines `QUEUED → RUNNING → COMPLETED | FAILED | CANCELLED`
with `canTransition` as the only legal path between states, progress reporting,
cancellation, retry with `isRetryable`, and a written failure code on every
failure. A cancelled crawl keeps what it already read — the partial result is
useful and discarding it would be surprising.

Routes: `POST /api/crawl`, `GET|POST /api/jobs`, `GET|DELETE /api/jobs/[id]`,
`POST /api/audit`, `GET /api/keywords`. As in Phase 3, routes do HTTP and
nothing else; every decision is in `lib/crawl/service.ts`, tested against the
in-memory database. The UI polls `/api/jobs/[id]` and stops on a terminal state.

## 46. Verification: what changed in Phase 4

The npm registry was still unreachable, so `npm install`, `next build`,
`next lint` and Playwright still could not run. The offline harness from Phase 3
carried over unchanged and was extended: **1049 unit tests**, a real `tsc` over
**142 `.ts` files**, static verification of **214 source files**, 49 render
assertions and a 50-surface page audit.

Mutation testing was used again to confirm the new tests bite. Removing the
second consent check, bypassing the promise linter, and crawling despite an
unreadable robots.txt were each introduced deliberately; all three were caught.

`.tsx` files remain untyped-checked (that needs `@types/react`), so a type error
inside a component is still the most likely first-build failure.
`tests/e2e/crawl.spec.ts` is authored but unexecuted, and **nothing in it
crawls a third-party site**: the real-crawl tests are skipped unless `CRAWL_E2E=1`
and `CRAWL_E2E_SITE` point at a site the operator owns.

## 47. What Phase 5 plugs into

| Later work | Seam that already exists |
|---|---|
| SEO/AEO narrative commentary | `lib/audit` findings are data; the `seo` and `aeo` agents are declared and refuse cleanly until built |
| A real volume data source | `SearchVolume`'s `measured` variant already demands `source` and `asOf`; nothing else changes |
| Scheduled re-crawls | `jobs` carries status, progress and retry; a scheduler enqueues rather than crawls |
| Competitor analysis | the crawler is already constrained to a consented site — competitor crawling needs its own authorisation story, not a wider crawler |
| Rendered-page auditing | `notChecked` already names what an HTML-only crawl cannot see |
| Ads, leads, analytics, reports | unchanged from Phase 3: agent definitions, usage metrics, review states |

---

# Part V — Phase 5: structured data, competitors and marketing operations

Phase 5 does two quite different things. The first half replaces the structured-
data validator with one that can tell four kinds of finding apart. The second half
adds the operational surfaces — competitors, ads, leads, messaging, video — which
share a single property: **every one of them is a place where a product is
tempted to invent something**, and most of this part is about what each one
refuses to do.

Sections 35 to 47 are Phase 4; Part V begins at section 48.

## 48. Dependencies: still four

No dependency was added, in the phase that reads three markup syntaxes and parses
HTML. Two absences are deliberate and are the same decision as the crawler's:

- **No DOM library.** `schema-validator/parse.ts` reads Microdata and RDFa with
  bounded expressions over text with comments, `style` and `noscript` stripped
  first. A full HTML parser is a large attack surface pointed at a document a
  stranger pasted.
- **No XML or JSON-LD library.** `@context` is checked as a string and **never
  dereferenced**. Fetching a URL out of a submitted document would rebuild the
  crawler's entire threat model inside a validation endpoint.

## 49. One validator, four dimensions

The brief is explicit: schema.org validity, search-engine eligibility, general SEO
guidance and AI/AEO clarity are four different things and one must never be
represented as another. A validator that reports them in one list of "errors" has
already broken that rule, whatever each row says, because a reader takes "12
issues" as one number about one thing.

So `dimension` is a **required field on every issue**. There is no default and no
way to emit a finding without choosing one:

| Dimension | May claim | Example |
|---|---|---|
| `SCHEMA_VALIDITY` | facts about the document | "`datePublished` is not an ISO 8601 date" |
| `SEARCH_ELIGIBILITY` | what published documentation asks for | "as of 2026-05, the requirements ask for an image" |
| `SEO_GUIDANCE` | ordinary on-page advice | "this headline will be truncated" |
| `AEO_CLARITY` | whether facts are stated unambiguously | "an AI system would have to infer the author" |

What no dimension may claim is an outcome. "You will get a rich result" and "an AI
system will cite this" are not knowable, and `tests/schema-engine.test.ts` scans
every explanation string in the engine for that phrasing rather than trusting the
author to have avoided it.

**The search requirements carry a date.** `SEARCH_RULES_AS_OF` is rendered next to
every SEARCH_ELIGIBILITY finding. A requirement list presented as timeless is
wrong within a year and the user finds out from a support ticket.

## 50. Six statuses, and the two that matter

`VALID / INVALID / WARNING / RECOMMENDATION / NOT_EVALUATED / UNSUPPORTED`.

The last two are the honest ones:

- **NOT_EVALUATED** means "we did not check this", which is different from "this
  is fine". Image dimensions are not checked (that needs a fetch); the canonical
  is not checked unless a crawl supplied one; whether a rich result appears is
  never checked, because it cannot be. All three are emitted as findings and
  rendered in their own block, because the absence of a finding otherwise reads
  as a pass.
- **UNSUPPORTED** means "a real schema.org type SeSha has no rules for".
  Reporting it as INVALID would be a false accusation about markup that may be
  perfect.

A document with no structured data is `NOT_EVALUATED`, never `VALID`: "we found
nothing" and "yours is correct" are different sentences.

## 51. Three syntaxes, one node shape

JSON-LD, Microdata and RDFa normalise to one `ParsedNode`, so a missing `name` is
the same finding with the same explanation whichever syntax it came from — and so
the same entity described in two syntaxes can be detected and reported, which is a
real and common WordPress-plugin problem.

The Microdata and RDFa readers are deliberately conservative, and say so in a
`limitation` rather than guessing: `itemref` is not resolved, RDFa prefixes are
not expanded, and nesting is followed by element order rather than by a rendered
tree. A limitation is the honest output; the alternative is a confident wrong
answer about which property belongs to which item.

## 52. The corrected document, and the line it does not cross

A correction is only useful if it can be pasted, which creates an obvious
temptation: fill in the gaps so the output looks complete. That would publish
invented facts on the customer's own domain, under their name.

So:

1. A value is **changed** only when the right value is derivable — a missing
   `@context`, an enum spelled without its prefix, a relative URL where the page
   URL is known.
2. A **missing** property becomes a visibly fake placeholder, `<add address — for
   example …>`. A plausible-looking placeholder is worse than none, because it
   gets published.
3. Reviews, ratings, prices, availability, awards, certifications and credentials
   are **never** added, not even as a placeholder — a placeholder shaped like
   `"ratingValue": "<add>"` is one find-and-replace from a fabricated rating. The
   refusals are returned alongside the correction and rendered as prominently as
   the changes.

Microdata and RDFa are not rewritten at all. A tool that rewrites HTML it parsed
with regular expressions will eventually corrupt a page.

## 53. History, and why the validator's own version is stored

`schema_validations` keeps every run with `validator_version` NOT NULL. Without
it a history is not comparable: a finding that appears between two runs might be
the customer's markup changing or our rules changing, and there would be no way
to tell. `compareResults` says so explicitly when the versions differ, rather
than presenting the diff as though it were all the user's doing.

## 54. Generation: three lists, not one

`lib/schema/generate.ts` emits **included** (with the field each value came from),
**omitted** (what is missing and how to supply it) and **refused** (what will
never be generated, with a reason specific to the property). A generator that
showed only its output would be indistinguishable from one that invented the gaps.

Every value goes through `take()`, so the provenance list cannot drift from the
document — a list maintained by hand beside a builder is wrong by the third edit.

And the generator **runs its own output through the validator**. Markup this
product generates should pass the validator this product ships; if it does not,
the user is entitled to see that, so the result is rendered rather than hidden.

## 55. Competitors: authorisation without consent

A competitor cannot consent to being read. Phase 4 said this explicitly and left
competitor crawling out rather than pointing the consented crawler at third
parties. Phase 5's answer is a deliberately narrower instrument:

- **The same safety policy, unchanged.** `safeFetch` with SSRF checks, DNS
  pinning, redirect re-validation, size and time limits; robots.txt consulted and
  **failing closed**. Nothing about a competitor makes private-network scanning
  acceptable, and a second fetch path with weaker rules is how a second SSRF hole
  arrives.
- **Three pages maximum**, one request at a time with a two-second gap. Enough to
  read how they present themselves; not a crawl.
- **An acknowledgement from the customer**, versioned, dated, attributable, and
  referenced `ON DELETE RESTRICT` exactly as crawl consent is. It is checked when
  the analysis is requested **and again immediately before the first request**.
- **Findings are stored; page content is not.** There is no column for it.

Every finding is `verified_public` — with the URL and the time it was read — or
`ai_inference`, with what it was drawn from. The type makes the first
unconstructible without a source. `withInferences()` forces the model's
conclusions to `ai_inference` regardless of what the caller passed, so a
conclusion cannot be recorded as an observation by mistake or otherwise.

`lintCompetitorFindings` drops any finding stating revenue, funding, spend,
traffic, customer counts, follower counts, conversion rates or rankings — none of
which is visible from outside. The one exemption is a figure **quoted from the
competitor's own page**, and it only applies when the numbers in the statement
actually appear in the quote; without that condition the exemption would be wide
enough to drive every fabricated number through.

## 56. Ads: separating recommendations from data that does not exist

"Separate AI recommendations from live data." No ad account is connected, so the
honest implementation is not an empty metrics panel — it is a type that cannot
hold a measurement. `BudgetRecommendation` has no variant carrying observed cost
per click, conversion rate or spend; it holds a range, the reasoning, and what it
would take to replace the suggestion with a measurement. This is the same move as
`SearchVolume` in Phase 4: make the dishonest version unrepresentable.

Platform limits are data, dated `AD_SPECS_AS_OF`, and enforced before a plan can
be approved — a Google headline cannot be saved at 45 characters and discovered at
upload time. A plan with errors can be a draft, because half-finished work is real
work, but "approved" means it will actually upload.

## 57. Leads: a score that shows its reasoning

Every CRM shows a lead score and almost none can say why. An opaque 87 is the same
dishonesty as a fabricated search volume: an opinion with the reasoning thrown
away, wearing a measurement's clothes.

`LeadScore` carries its components, each naming what it looked at, the points and
the reason. `scoreIsConsistent()` asserts the parts sum to the total, the database
`CHECK` refuses a score stored without its components and basis, and the interface
never shows the number without the rubric. There is no model, and nothing implies
one.

Stage moves are one step at a time, every change is logged as an activity with
both stages, and a lost lead must say why — enforced in the service and again by a
database constraint. `new → won` is refused because a deal nobody contacted did
not happen; `lost → won` is refused because it is the same edit with the evidence
removed.

## 58. Messaging: the refusal is the feature

"Use official APIs only. Do not enable unauthorized spam."

- **Nothing sends.** There is no `send()`, no scheduler, no recipient list, and no
  `sent_at` column — a nullable one is an invitation to write to it from a screen
  that implies the product sends.
- **A plan with no lawful basis is refused, not warned about.** A bought or
  scraped list is rejected before the subject line is even validated, is not
  stored as a draft, and the database `CHECK` cannot hold those values either.
- **A marketing email without an unsubscribe is an ERROR.** It is a legal
  requirement in most of this product's markets, and a tool that treats it as
  advice is helping its user break the law.
- **WhatsApp is template-shaped**, because that is what the official API accepts:
  a category derived from the kind (never chosen by the caller, since marketing
  content under a UTILITY category is a policy breach), numbered placeholders each
  of which must be described, and the real body and button limits.

## 59. Video: a concept is not an image

No image-generation API is connected, so `ThumbnailConcept` has **no image field
at all** — nothing to fill with a placeholder that later looks like an asset, and
no column in `video_scripts` either. What is produced is a written brief: what is
in frame, the overlay words, why that earns a click.

Scene durations are summed and checked against the platform limit, because a
sixty-second Reel whose scenes total ninety seconds is a wish rather than a
script. On a platform that plays muted, a spoken line with no on-screen text is an
error rather than a note.

## 60. Storage

Migration `0005` adds `schema_validations`, `competitors`,
`competitor_acknowledgements`, `competitor_analyses`, `ad_plans`,
`lead_activities`, `messaging_plans` and `video_scripts`, and **alters the
existing `leads` table in place** rather than shadowing it — it was created in
Phase 1 as an unused skeleton with a required email and a five-value `status`.
Forward-only means altering it: `email` becomes nullable (a great many enquiries
in this market arrive by phone with no email at all), `status` becomes `stage`
with the seven values, and the score arrives with its components and basis.

Forty tables, all with row-level security, all tenant-scoped.

## 61. Verification: what changed in Phase 5

Unchanged constraint: the npm registry is still unreachable, so `npm install`,
`next build`, `next lint` and Playwright have never run. The offline harness
carried over and grew: **1339 unit tests**, real `tsc` over **182 `.ts` files**,
static verification of **260 source files**, 49 render assertions and a
**53-surface** page audit.

Two harness additions are worth noting because they check something no unit test
can: the page audit asserts that the validation report **renders all four
dimension headings** — a merged list would pass every other check while undoing
the distinction the brief requires — and that no screen implies the product sends
messages, spends money or generates images.

Mutation testing again: removing the bought-list refusal, removing the second
acknowledgement check, and making the generator emit a rating were each introduced
deliberately and each caught.

## 62. What a later phase plugs into

| Later work | Seam that already exists |
|---|---|
| Ad copy, lead summaries, competitor inferences | the `ads`, `lead` and `competitor` agents are declared and refuse cleanly; `withInferences()` is the labelled entry point for the competitor half |
| A connected ad account | `BudgetRecommendation` gains a `measured` variant demanding a source and a date; `performanceStatus()` is the one place that says there is no data |
| A connected email or WhatsApp provider | `sendingStatus()` is the single gate; the plan types already match what each official API accepts |
| Image generation | `imageGenerationStatus()` is the gate; `ThumbnailConcept` would gain an image field, and only then |
| Analytics and reports | unchanged: usage metrics, review states and the job model |
| Rendered-page validation | the validator already reports what an HTML-only read cannot see as `NOT_EVALUATED` |

---

# Part VI — Phase 6: analytics, calendar, automation and reports

Phase 6 is the phase where a marketing product normally starts lying. An
analytics screen is the single most tempting place to invent a number: nothing on
it is obviously wrong, a plausible traffic figure looks exactly like a real one,
and the user has no way to check. A report is worse, because it is read away from
the screen that would have carried the caveat.

The brief is blunt about it — *"If no connected data exists: display 'No
connected data available.' Never fabricate analytics"* — and everything in this
part follows from taking that literally rather than as a disclaimer.

## 63. Dependencies: still four

`next`, `react`, `react-dom`, and `clsx` + `tailwind-merge`. Nothing added in
Phase 6, which is the fifth consecutive phase with no addition.

The interesting one is the PDF. Exporting a report as PDF normally means a 2–15 MB
library that pulls a font stack and a canvas shim and runs layout code over
user-controlled strings. What this product actually needs is black text on white
paper in one font family, and the PDF format supports exactly that in about three
hundred lines: `src/lib/reports/pdf.ts` writes the bytes directly — `%PDF-1.7`, a
catalogue, a page tree, uncompressed content streams in the standard Helvetica
faces, and a cross-reference table. The fourteen standard faces are built into
every reader, so nothing is embedded.

The fiddly part is that the cross-reference table stores **byte offsets**. Every
object is therefore built as a latin1 string in which no character exceeds 0xFF,
which makes the byte offset equal to the string length. `encodeWinAnsi` is what
guarantees that, and it is not a text tidy-up — a single character above 0xFF
corrupts every offset after it. A test asserts the property directly, and a
mutation that removed the clamp was caught.

## 64. `MetricValue`: no variant carries a bare number

The same move as `SearchVolume` (Phase 4) and `BudgetRecommendation` (Phase 5).
`MetricValue` is a discriminated union with **no** `{ value: number }` variant.
Every variant that has a figure also carries where it came from:

| Kind | Carries | Meaning |
|---|---|---|
| `connected_api` | `source`, `asOf` | read from a connected account |
| `user_provided` | `enteredBy`, `asOf` | a figure the customer typed |
| `retrieved` | `sourceUrl`, `asOf` | read from their own site by our crawler |
| `calculated` | `formula`, `inputs`, `asOf` | computed here, with checkable arithmetic |
| `ai_estimate` | `band`, `basis` | a magnitude band, never a precise figure |
| `unavailable` | `label`, `why`, `whatWouldMakeItAvailable` | we do not have it |

Those are the brief's six source labels, and they are the union's discriminator
rather than a display string beside it. A figure without provenance is not a
value this type system can express.

`hasFigure()` is the only way to reach a number, and it narrows to the four
variants that have one. `formatValue()` returns `null` for everything else, so a
UI that renders it blindly shows nothing rather than "0".

## 65. Nineteen metrics, and which six SeSha actually has

`METRIC_IDS` is exactly the brief's nineteen. `METRICS[id].requires` says what
would have to be connected, per metric, individually — because the difference
matters: a customer who connects Google Analytics still will not get CPC.

Eight are genuinely first-party today, computed by `src/lib/analytics/compute.ts`
from rows in this database: leads, pipeline conversion, SEO score, AEO score,
schema issues, crawl errors, content coverage, and content activity. Each returns
a `calculated` value carrying its formula and its inputs.

The other eleven are `unavailable`, with the specific account named.

**What is deliberately absent from that file matters as much as what is in it.**
There is no function that produces a traffic, impression, click or follower
figure, because SeSha cannot know one. A helper called `estimateTraffic` would
be used within a week. A gate test asserts that no exported function in
`analytics`, `reports`, `calendar` or `automation` is named like an estimator.

Two computed metrics return `unavailable` rather than zero, and the reason is the
same in both cases — **a zero is a claim**:

- pipeline conversion, when nothing has closed. "0%" says *you convert nobody*,
  which is a different and false statement from *nothing has closed yet*.
- content coverage, when no keywords are tracked. "0% coverage" says *your content
  covers nothing*, when the truth is *nothing has been measured*.

`content_performance` is the interesting middle case. SeSha knows how much
content was created and approved and knows nothing about how it performed.
Reporting the whole metric as unavailable hides real information; reporting the
count as "performance" is a category error. So the count is returned with a
formula that says, in capitals, that this is ACTIVITY and not performance, and
that the real thing needs an analytics account.

## 66. `data_connections`, and the absence of a metrics table

There is no `metrics` table, and no column anywhere holding a traffic,
impression, click, follower or spend figure. A nullable `sessions integer` would
be filled in within a month — by a seed script, a demo fixture, or a well-meaning
estimator — and from then on nobody could distinguish a measured figure from an
invented one. A gate test walks `db/schema.sql` and fails on such a column.

`data_connections` records the *absence* instead: one row per provider a customer
has connected, six providers declared, and **a provider with no row is not
connected**. There is no `pending` state, because a screen would round it up to
"connected". No access token is stored there either — token custody belongs with
the credential store, not with a row that reporting queries join against.

`analyticsStatus()` is the one function every analytics surface calls before
rendering anything, the same shape as `publishingStatus()` (Phase 3),
`adsDataStatus()` and `sendingStatus()` (Phase 5).

## 67. The calendar: a plan, not a schedule

Four views — daily, weekly, monthly, campaign — and the brief's ten event kinds.
Weeks start on Monday. `event_date` is a `date`, not a `timestamptz`: a marketing
calendar is a calendar of days, and storing an instant forces a timezone decision
that would move an entry across a date boundary for a colleague in another
country.

`EventStatus` is `planned | done | skipped`. There is deliberately **no
`scheduled` and no `published`**: SeSha cannot publish anything (Phase 3) and
nothing fires on a calendar date. A status claiming otherwise would be the
database asserting a capability the rest of the product refuses.

The campaign view is not a date window. It groups every entry carrying a campaign
however far apart the dates are, because clipping it to a month would hide the
start of anything that ran across a boundary.

### Suggestions are a different type from entries

`Suggestion` is a separate type from `CalendarEvent`, it has no id and no status,
and nothing writes one. That is not fastidiousness: *a suggestion rendered as an
entry becomes, within a week, something the user believes they planned*, and the
calendar stops being a record of decisions. The UI renders them in a separate
panel, labelled, with the reason. Accepting one is an explicit act and what it
creates is marked `accepted_suggestion` forever.

Two rules keep `suggestForEmptyDates()` honest:

1. **A suggestion must have a reason specific to this customer** — an open finding
   from their own audit, or a channel they named at onboarding. "Post something on
   Tuesday" is filler, and filler trains people to ignore the calendar. A customer
   who listed no channels and has no open findings gets *nothing*.
2. **Real work comes first.** An open schema error is a better use of a Tuesday
   than an invented blog post, and it is checkable, so open tasks are placed
   before anything derived from a channel preference.

## 68. Automation: the action list is the boundary

An automation engine in a marketing product is normally a machine for sending
things to people without a human in the loop. This one cannot be, and the reason
is not caution — **the capability genuinely does not exist**. SeSha cannot send
email or WhatsApp (Phase 5), cannot publish to a social platform (Phase 3), and
cannot spend money on ads (Phase 5).

So `ACTION_KINDS` is closed at six, and every one produces something a person
then acts on: a task, a follow-up on a lead, an in-app notification, a content
suggestion, a calendar entry, a recommendation. `isOutboundAction()` returns false
for all of them — it exists so a gate test can assert it over the whole list
rather than over the ones someone remembered to check, and so that adding an
outbound action means deliberately making it return true. `checkRule()` emits an
error if any action would reach a third party, and migration 0006 enforces the
same list in the database through an `IMMUTABLE` function, so an action cannot be
introduced by a fixture or a direct `INSERT`.

This matters more than it looks. *"Inactive customer → re-engagement"* is one of
the brief's own examples, and the obvious implementation sends a re-engagement
email. The honest implementation drafts one and tells a person it is waiting —
which is also the only version lawful under the opt-in rules Phase 5 enforces.

`campaign_plan_declined` is the honest version of the brief's "campaign decline".
SeSha has no ads API, so the only decline it can see is a person rejecting a
plan in review — and Phase 5 had no way to do that. Phase 6 adds `rejected` to
`ad_plans.review_state` with a **required** `review_note`, because a rejection
with no reason leaves the author guessing and leaves the recommending automation
with nothing to say.

### Conditions are declared, not free-form

`TRIGGER_FIELDS` states, per trigger, exactly which fields its payload carries.
`checkRule()` rejects a condition on anything else, on create **and on every
update** — because a rule edited to point at a field its trigger does not publish
is a rule that silently never fires again, and the person who edited it has no
way to tell.

The numeric comparison has its own trap, found by a test rather than by reasoning:
`Number(null)`, `Number('')` and `Number(false)` are all `0`, so "days since
activity is less than 5" was TRUE for a lead whose field was missing entirely —
a re-engagement task for every lead with no data. `numeric()` returns `null` for
all three.

### Every run is recorded, including the ones that did nothing

A rule that quietly stops matching is indistinguishable from a rule that never
runs. `automation_runs` has `matched boolean NOT NULL` plus a `skip_reason`
carrying which condition failed, in words, and a CHECK constraint requiring the
reason whenever `matched` is false. Hitting the daily ceiling is recorded the same
way, so "it stopped because of a limit" is distinguishable from "it is broken".

## 69. Reports: the six questions are fields on a type

The brief asks for a report answering: what happened, why, what next, which
campaigns, which pages, and where attention or budget should be reviewed. That is
not a layout — it is a promise that the report explains itself. So the six
sections are **fields on a type**, `orderedSections()` fills in any that were not
built, and a section with no points carries a **required** `emptyReason`. An empty
section with no explanation reads as "nothing to report", which is a claim, and
usually the wrong one.

The hard section is **"why?"**. Every analytics product writes "what happened" by
listing numbers; very few attempt "why", because the honest answer is usually *we
cannot tell you from here*. `generate.ts` either names a real cause found in the
customer's own records — a crawl that stopped early, a plan declined in review, a
page that lost its markup — or says plainly that the cause is not visible to
SeSha and what would make it visible. The alternative, which is what a generated
narrative usually does, is to restate the numbers in sentence form and call it
analysis. That reads like insight and contains none.

**"Where should budget be reviewed?"** refuses to answer. SeSha has no spend
data, and a recommendation about budget without spend data is a guess wearing a
suit. What it does instead is point at where a decision is actually waiting — a
declined plan, a stalled campaign, a calendar being skipped more than completed —
and say what is missing that would make the budget question answerable.

`generateReport()` is a pure function from a fact bundle to a `Report`: no
database, no clock, no randomness, so the same facts produce an identical report.
A test asserts that byte-for-byte.

### A report is a snapshot

`reports.document` holds the rendered report whole, including every
`MetricValue` with its provenance. Export and share read that row; they do not
re-run the generator. A link sent to a client in March must show what it showed in
March, and a PDF downloaded twice must be the same PDF. Regenerating on read would
silently rewrite history.

`connected_sources` is denormalised onto the row on purpose, so the report is
still readable after a connection is removed.

## 70. Export: the caveat travels with the file

| Format | What carries the provenance |
|---|---|
| JSON | the `MetricValue` union, unchanged — the consumer gets the discriminator and cannot read a figure without seeing its kind |
| CSV | two columns, `source` and `as_of`, that cannot be omitted |
| PDF | the honesty banner is the first thing on page 1, and every figure prints its source line beneath it |

An unavailable metric exports as a **row**, with an empty value cell and the
reason in the source column. Dropping it would let a reader count the rows and
conclude the missing metrics were zero. A gate test asserts the row exists and the
value cell is empty.

The CSV escaper guards the leading character. A value beginning with `=`, `+`, `-`
or `@` is executed as a formula by Excel and Sheets when the file is opened, which
turns an exported report into a way of running something on the reader's machine.
None of our own values legitimately start with those characters, but a lead's name
or a page title is user-controlled and this is an export of user data.

## 71. Share links: four decisions, each refusing the convenient version

A share link is an unauthenticated door into tenant data, which makes it the most
dangerous feature in Phase 6.

1. **The token is random, not derived.** A token built from the report id — even
   hashed — is enumerable the moment someone learns the scheme. 32 bytes from the
   platform CSPRNG, base64url, no structure to guess.
2. **Only a hash is stored.** If the table leaks, what leaks is not a set of
   working links. The same reasoning as password storage, for the same reason: the
   stored value should not be the credential.
3. **It expires by default.** A link with no expiry is a permanent hole that
   outlives the employee who created it. Thirty days by default, ninety maximum,
   `expires_at NOT NULL`.
4. **Revocation is immediate**, checked on every view, never cached.

Every failure — unknown, expired, revoked, malformed, report deleted — returns the
**same sentence**. "This link has expired" tells a stranger the link was once
real, which is more than they need to know; the reason is returned separately for
the audit log. The shape guard runs before any lookup, so a scanner cannot use
timing to distinguish malformed from missing, and a test asserts the repository is
not called.

`/api/share/[token]` is the only unauthenticated endpoint in the product that
returns tenant data. It sets `no-store` and `noindex, nofollow`, because a link
pasted into an email that a crawler follows would put a customer's report into a
search index.

## 72. Notifications: where the decision lives

*"Users must control notification preferences."* That is not a settings screen —
it is a rule about where the decision lives. `shouldNotify()` is the only route
from an event to a user, it takes the preference as an argument, and there is no
bypass. A feature cannot decide its own message is important enough.

An automation does not get a bypass either. Asking for a rule and asking to be
told every time it runs are two different decisions, and a test asserts that a
rule whose notification the user switched off writes nothing.

Two kinds cannot be switched off, and the interface **shows the reason** rather
than greying a toggle out: a product that lets someone mute "your password was
changed" helps an attacker stay hidden, and one that lets someone mute "your card
failed" surprises them with a dead account. `notification_preferences` enforces it
with a CHECK constraint as well, so a direct `UPDATE` cannot mute a security
alert. None of the brief's eight marketing kinds is forced on — a gate test
asserts that too.

A kind with **no stored row** takes the application default rather than being
treated as off, so adding a new notification kind does not arrive silently
switched off for every existing user.

Email is listed as a channel, marked unavailable, with the reason — rather than
hidden. SeSha cannot send email, so an email toggle would be a switch wired to
nothing; but a customer deciding whether to buy should be able to see what is not
built yet. `shouldNotify()` cannot return it, and there is no branch anywhere that
would try.

## 73. Storage

Seven tables, taking the schema to **47**. Every one is tenant-scoped with
row-level security; `report_shares.findByTokenHash` is the single deliberately
un-tenanted read in the codebase, because its caller is an anonymous visitor
whose only credential is the token.

| Table | Note |
|---|---|
| `data_connections` | one row per connected provider; no row means not connected; holds no token |
| `calendar_events` | `event_date date`; a derived entry must name its source (CHECK) |
| `automation_rules` | the permitted action list enforced by an `IMMUTABLE` function |
| `automation_runs` | non-matches recorded; `skip_reason` required when not matched |
| `reports` | the rendered document, stored whole |
| `report_shares` | `token_hash` only; `expires_at NOT NULL`; revocable |
| `notification_preferences` | per user per kind; security and billing cannot be muted (CHECK) |

`notification_preferences` is destroyed with the user by
`anonymize_deleted_user()`: it is personal data, not organization data.

## 74. Verification: what changed in Phase 6

Unchanged constraint: the npm registry is still unreachable, so `npm install`,
`next build`, `next lint` and Playwright have never run. Postgres is unreachable
too, so **no migration in this project has ever been executed** — the SQL is
reviewed, and `db/schema.sql` is generated from it and checked against the row
types in code, but it has not been run.

The offline harness grew to: **1627 unit tests** (312 suites), real `tsc` over
**203 `.ts` files**, static verification of **296 source files**, 49 render
assertions and a **56-surface** page audit.

Two harness additions are worth naming.

**The page audit now renders the Phase 6 surfaces in the state that matters — nothing
connected.** That is the state a real customer sees on day one, and it is the state
in which a fabricated figure would appear if one were ever going to. It asserts the
required sentence is present, that unavailable is distinguished from zero, and that
no figure is rendered for traffic, impressions, ROAS or followers.

**Static verification now checks how `Field` is used.** `Field` takes a render prop
— it calls `children({ id, describedBy, invalid })` so the label and the control
are genuinely bound. Passing child elements instead type-checks under this offline
harness, because `.tsx` is not covered by `tsc` here, and then throws
`children is not a function` the first time the screen renders. Eighteen such
usages were found at once in Phase 6 — **thirteen of them shipped in earlier
phases**, on screens the render audit did not reach. All eighteen are fixed and the
check stops it recurring. This is the clearest example so far of the specific risk
of building without `next build`, and of why the substitute harness has to keep
growing.

Mutation testing again, 24 mutations: removing the conversion-is-unavailable
branch, marking an action outbound, removing the CSV injection guard, ignoring
revocation, ignoring expiry, letting the PDF emit characters above 0xFF, and
reverting the PDF title to WinAnsi were each introduced deliberately. Three
survived the first pass and exposed real gaps — an empty string coercing to zero,
a security notification silenced when `shouldNotify` is called directly, and a
malformed share token reaching the database. All three now have tests that fail
without the guard.

## 75. What a later phase plugs into

| Later work | Seam that already exists |
|---|---|
| A connected analytics or search console account | `data_connections` has the provider rows; `availableSources()` and `whyUnavailable()` are the two functions that change; every metric becomes `connected_api` with a source and an as-of, and nothing else moves |
| A connected ad account | the same, plus `BudgetRecommendation` gains its `measured` variant (Phase 5) |
| Narrative commentary over reports | the `report` and `analytics` agents are declared and refuse cleanly; they would write prose over `Report`, never replace the rule-based sections |
| Scheduled report delivery | the `report_generation` job kind exists; delivery needs an email provider, which `sendingStatus()` still gates |
| Genuinely outbound automations | `isOutboundAction()` and the database's `automation_actions_permitted()` are the two places that would have to change, deliberately and visibly |
| Rendered-page analytics | unchanged: the validator already reports what an HTML-only read cannot see as `NOT_EVALUATED` |

---

# Part VII — Phase 7: subscriptions, usage limits and the admin platform

Phase 7 is where a SaaS product acquires the two powers it can most easily abuse:
the power to charge people, and the power to look at everyone's account. Both are
built here. Neither is switched on.

There is no payment provider connected, so nothing can be charged — and the code
is arranged so that this is a *fact about configuration*, not a promise in a
comment. There is no staff row in any database, so the admin panel is unreachable
— and to anyone who is not in that table it returns 404 rather than 403, so it
does not exist rather than merely being locked.

The brief's two hard instructions shaped most of what follows: *"Do not hard-code
pricing into business logic"* and *"Do not store sensitive payment data unless
required and properly handled."* The second one is met by a stronger claim than
the brief asks for: **there is no column anywhere in fifty-six tables that could
hold a card, and no function signature that would accept one.**

## 76. Dependencies: still four

`next`, `react`, `react-dom`, and `clsx` + `tailwind-merge`. Nothing added in
Phases 2 through 7. The billing abstraction is an interface and a null
implementation; the usage meters are CSS; the admin panel is the same component
primitives as the rest of the product. A payment SDK is what you add when you
connect a provider, and connecting one is a later decision.

## 77. Plans are content, limits are code, prices are neither

`src/content/plans.ts` declares four plans — `free`, `pro`, `business`, `agency` —
and eleven limits for each. It contains no price, no currency symbol and no
amount field, and `tests/phase7-gate.test.ts` scans it to keep that true.

The reason is not tidiness. A limit is an engineering fact: "this plan allows 500
AI requests" is something the system can enforce and the team can verify. A price
is a commitment the business makes to a customer, with tax, invoicing and
contract consequences. Putting them in the same object means changing a price is
a code deploy, and it means a bug in the pricing table can change what someone is
allowed to do. They are kept apart, and prices stay in `content/pricing.ts` behind
the `verified` guard that has been there since Phase 1 — unverified tiers still
render no figure at all.

**Plan comparison is by rank, never by price or name.** `planChange(from, to)`
returns `upgrade`, `downgrade` or `same` by comparing an integer `rank`. Comparing
prices would make a promotional discount look like a downgrade; comparing names
alphabetically would put `agency` below `free`.

### The rename, and why it took three SQL statements

Phases 2–6 shipped with plans named `starter`, `growth`, `agency`. Phase 7's brief
names `free`, `pro`, `business`, `agency`. Live rows already carry the old values,
and a `CHECK` constraint will not let you update a row to a value it forbids.

Migration `0007` therefore does it in three steps, in this order:

1. **widen** the CHECK constraint to permit both spellings;
2. **UPDATE** the rows to the new spelling;
3. **narrow** the constraint to the new spelling alone.

Doing 3 before 2 fails on the existing data. `tests/phase7-gate.test.ts` asserts
the order, because it is the kind of thing that looks like noise in a diff and
takes a production database down.

`resolvePlanId()` also accepts the old spellings forever, mapping `starter → pro`
and `growth → business`. A subscription row that somehow still carries an old
value resolves rather than silently dropping the account to free.

## 78. Eleven limits, two kinds, three zero-like states

The eleven limits the brief lists divide into two kinds:

- **per-period** — AI requests, tokens, content generations, website crawls, SEO
  audits, AEO audits, schema validations, reports. These reset on the 1st, UTC.
- **absolute** — projects, team members, automations. These are standing totals
  that never reset; deleting a project frees its place immediately.

A limit value is `number | null`, and it has **three** meaningful states that look
identical if you are careless:

| Value | Means | Renders as |
|---|---|---|
| `null` | unlimited | "Unlimited", and **no progress bar at all** |
| `0` | not included on this plan | "Not on this plan", full muted bar |
| `n > 0` | a ceiling | "3 of 500", proportional bar |

Conflating `0` with "no ceiling" would hand every customer every feature.
Conflating it with "used up" would tell someone to wait for a monthly reset that
is never going to grant them the feature. `limitStatus()` returns a distinct shape
for each, `checkLimit()` returns a distinct `reason` (`not_included` versus
`period_exhausted`), and the render harness asserts on the rendered HTML that an
unlimited limit draws no bar and a zero limit never prints "0 of 0".

`clampLimit()` decides what to do with a stored override that is not a sane
limit. A non-number, a negative, `NaN` and `Infinity` all return `undefined`,
which means "ignore this row and use the plan". A **fraction is floored, not
rejected**, and the direction is the argument: rejecting `1.5` falls back to the
plan's own value, which may be *higher* than the override someone set in order to
restrict this account. Flooring can only ever give less than was asked for, so a
malformed row cannot widen an entitlement.

## 79. One decision function

`checkLimit(limitId, context, amount = 1)` is the only place that decides whether
something is allowed. It runs in a fixed order, and the order is the design:

1. `blockedReason` — the subscription itself forbids new work. Checked **first**,
   because no limit matters if the account is not entitled to write at all.
2. `null` — unlimited, allow.
3. `0` — not included, refuse with `not_included`.
4. over the ceiling — refuse with `at_capacity` or `period_exhausted`.

The refusal messages are written to be read by the person who was refused:

- an **absolute** limit never mentions a reset, because nothing resets — it says
  "Remove one, or upgrade for more";
- a **spent monthly allowance** does say when it returns, because waiting works;
- a **single request larger than the whole monthly allowance** says so explicitly
  instead of telling someone to wait for a reset that cannot help.

Units are singularised when the limit is 1, because "1 automations" reads as
unfinished software.

Every refusal is recorded in `quota_refusals` with the usage **frozen at that
moment**. Raising a limit later must not rewrite the record of why someone was
blocked last Tuesday; support needs to see what the customer saw.

## 80. Usage: eight things, nine counters

The brief lists eight things to track. They map onto nine metrics, because *audit
usage* is recorded as `seo_audit` and `aeo_audit` separately — the brief itself
asks for SEO audits and AEO audits as two independent limits, and one shared
counter could not enforce both. The gate asserts the mapping rather than a count
of eight, because asserting the count would pressure the implementation into
merging two limits that have to stay apart.

`MEASURES` is the table that connects a limit to its measurement, and it is the
crux of the whole system:

```ts
ai_requests:  { kind: 'per_period', metrics: ['ai_generation'] }
seo_audits:   { kind: 'per_period', metrics: ['seo_audit', 'audit_run'] }
projects:     { kind: 'absolute',   countable: 'projects' }
```

A per-period limit sums usage rows; an absolute limit counts **live rows**, not
usage history, so deleting a project genuinely frees its place.

`audit_run` is the legacy metric. It has been a permitted value in
`usage_records` since migration `0002` and **nothing ever wrote it** — audits were
running and recording nothing at all for four phases. Phase 7 found that while
wiring the audit limits, and fixed it by recording `seo_audit` / `aeo_audit`. The
old value stays readable, so historic rows still count, and is excluded from
`WRITABLE_METRICS` so nothing writes the ambiguous one again.

## 81. Billing: an abstraction with exactly one implementation, and it refuses

`PaymentProvider` is an interface: `createCheckout`, `createPortalSession`,
`changePlan`, `cancel`, `fetchSubscription`, `verifyWebhook`. `nullProvider` is
the only implementation, `configured` is `false`, and every method returns
`{ ok: false, reason: NOT_CONFIGURED }`.

**`nullProvider.verifyWebhook` returns `false`. Always.** That single line is why
the webhook endpoint cannot be abused today, and it is the most load-bearing line
in the phase — a mutation that changes it to `true` would let anyone who can POST
grant themselves the Agency plan, and `scripts/mutation-check.mjs` introduces
exactly that mutation to prove the tests notice.

### What the product will store about a card

```ts
interface PaymentMethodSummary {
  readonly brand: string;          // "Visa"
  readonly last4: string;          // "4242"
  readonly expiryMonth: number | null;
  readonly expiryYear: number | null;
}
```

That is the whole type, and those four are the whole set of `payment_*` columns in
the schema. There is no field for a number, a token, a CVV or a bank detail —
**the dishonest version is unrepresentable**, which is the same technique as
`SearchVolume` (Phase 4), `BudgetRecommendation` (Phase 5) and `MetricValue`
(Phase 6). The gate reads the column names out of the DDL and asserts the set is
exactly those four.

There is no card field on any screen either, and the billing screen renders **no
data-entry control at all** — asserted on the rendered HTML, which is a stronger
claim than "no input named card".

### Subscription state is a table, not a switch

`TRANSITIONS` is a map from status to the events that move it, expressed as data
so a test can walk the whole thing: every status must be reachable, and no
transition may leave a value that is not a status.

An event with no transition from the current state is **ignored and recorded with
a note**, never treated as an error. Providers retry and deliver out of order; a
retried `payment_succeeded` arriving after a cancellation must not break a live
subscription. `billing_events.external_event_id` is UNIQUE, so a retry is
recorded as already-seen rather than applied twice.

**`accessFor()` never revokes read access. In any state.** Past due, cancelled,
paused, incomplete — `readable` is `true` in every branch, and the gate asserts it
across every status. A customer whose card failed still owns their work and can
still export it; taking that away would be holding their data hostage over a bank
decline. A failed payment opens a **seven-day grace window** during which writing
continues, the window is measured from `pastDueSince` so a second failure does not
restart it, and after it closes writing stops and reading does not.

### The webhook: the most dangerous endpoint in the product

`POST /api/billing/webhook` is the one endpoint a stranger can reach that could
change what an account is entitled to. Four things protect it:

1. **The signature is verified first, against the raw body.** The body is read
   with `request.text()` and parsed only after verification, because providers
   sign the bytes and re-serialising parsed JSON changes them. Using `readJson()`
   first would consume the body and make verification impossible. The gate
   asserts the three operations appear in that order.
2. `nullProvider.verifyWebhook` returns false, so nothing is ever applied today.
3. No authentication and therefore no CSRF — the caller is a machine with no
   session. **The signature is the authentication.**
4. Idempotency, via the unique external event id.

A bad signature is answered **202 with no detail**. A 401 would confirm to a
forger that the endpoint is live and that only the signature stood in their way;
a 500 would suggest they had found a bug. Nothing was applied either way.

Only a **summary** of a provider payload is stored, never the raw body: a provider
webhook carries more customer data than this product needs, and keeping it
wholesale would create a second copy of it in a table staff can read.

## 82. Organization admin is not platform admin

This is the defining security decision of the phase.

SeSha has had an `admin` role on `memberships` since Phase 2. It means "can
administer *this organization*" — invite people, change billing, delete projects.
It is the most common role among paying customers.

Platform staff is a **separate table**, `platform_staff`, with its own three
roles (`support`, `engineer`, `platform_owner`) and its own twenty-four
permissions. Making it a role on `memberships` would have been less code and would
have meant that **every customer who clicked "make me an admin" could read every
other customer's account.** `tests/phase7-services.test.ts` has a test named
exactly that — *"AN ORGANIZATION ADMIN IS REFUSED BY THE ADMIN PANEL"*.

`StaffContext` deliberately carries **no `organizationId`**. The admin panel reads
across tenants by definition; a context that also offered a single organization id
would invite a query to be scoped by it, which silently returns nothing and looks
like it worked. The gate asserts the field is absent from the interface.

`AdminReadRepository` is the one deliberate cross-tenant seam in a codebase where
every other repository method takes an `organizationId` so it is not *possible* to
forget the tenant filter. It is one narrow interface that says so in its name, and
**no method on it returns customer content** — no lead, no article, no report
body, no message. Support needs to know an organization exists, what plan it is
on, how much it has used and whether its jobs are failing. None of that requires
reading what the customer wrote. The single exception is feedback, which a
customer typed in order to be read, and reading it is audited like everything
else.

## 83. Six security measures, and what a stranger is told

| Brief's item | How |
|---|---|
| Separate admin authorization | `platform_staff`, `requireStaff`, `StaffContext` with no tenant |
| Strong authentication | every `:write` permission requires a live sudo window, computed from the session record so the client cannot extend it |
| Role restrictions | permissions declared as a **minimum role**, so a new one cannot be accidentally granted to everyone or forgotten for a role |
| Audit logs | `admin_actions`, every action **including every read** |
| Rate limits | `enforceRateLimit` on every admin route; the gate scans for one that lacks it |
| Session controls | the staff row is read on **every request**, so revocation takes effect immediately rather than when a thirty-day session expires |

Support holds exactly one write permission: moving a piece of feedback along its
triage states. That is the job, it touches a status field, and it changes nothing
about what any account may do. Every other write is withheld, and the gate lists
them individually rather than asserting the neater and false sentence "support
holds no writes".

**What a non-staff caller gets is 404.** Not 403, and not a different shape of 404
from a missing route — the same not-found page a mistyped URL gets. This is the
reasoning behind cross-tenant 404s in Phase 2, applied to something worth far more
to an attacker than one customer's project id. Staff with the *wrong role* also
get 404: a support engineer probing for the staff-management endpoint should not
learn it is there and that someone senior can reach it. The one exception is a
stale sign-in, which is 403 with a `needsSudo` flag, because that caller is
already established as staff and asking them to re-authenticate discloses nothing
they do not already know.

That mapping was originally inline in the request guard, where no test could reach
it — and a mutation that changed the 404 to a 403 **left the entire suite green**.
It is now `adminRefusal()`, a pure function in `lib/admin/auth.ts` with six tests
of its own, and the gate asserts the guard still delegates to it.

`admin_actions` has **no cascade to `organizations`**. Every other
organization-scoped table cascades on delete, which is right for customer data and
wrong for the record of what staff did: deleting an account must not delete the
evidence. Reading the audit trail requires `engineer` — support cannot review its
own activity — and the read is itself recorded, so the reviewer's visit appears
the next time the page loads. The page says so on screen.

## 84. Feature flags: a fixed registry with a documented precedence

Thirteen flags across the brief's five categories (AI providers, modules, beta
features, plans, experimental). A **fixed registry**, not free-form strings: a
flag created by typing a new key into a form is a flag nobody can find, nobody
documents and nobody removes, and `evaluate()` on an unknown key would have to
guess, which defeats the point of a safe default.

Precedence, checked in this order, first match wins:

1. `disabled` — the kill switch. Nothing overrides it, including a named account.
2. `excludedOrganizationIds`
3. `organizationIds`
4. `plans`
5. `rolloutPercent`
6. the flag's declared default

The percentage is a **stable cohort, not a dice roll**: `inRollout()` hashes
`${key}:${organizationId}` with FNV-1a, so the same account always gets the same
answer, and two flags at the same percentage select *different* accounts rather
than the same unlucky tenth of the customer base. The admin form prints this
precedence on itself, because a rule with a percentage and an exclusion list and a
plan gate is not obvious from the fields alone at 2am.

A flag that depends on something external — an API key, a connected provider —
declares `requires`, and the panel renders it as **unavailable with the reason**
rather than as a switch that does nothing.

## 85. Ten settings, and the one that may only be narrowed

`SETTING_DEFINITIONS` covers the brief's remaining four controls: prompts,
templates, validator configuration and system configuration. Each setting
declares a shape (`string`, `number`, `boolean`, `string_list`), its bounds, and
its own permission — so the audit trail records *which surface* was touched rather
than "a setting changed", and a role that may edit prompts does not thereby gain
the ability to close sign-ups.

`crawler.max_pages_ceiling` carries `narrowOnly: 'lower'`. It may be lowered from
its default and **never raised**, because raising it would make SeSha crawl
harder than the policy it publishes on its own security page.

The first version of that guard was **unreachable**. `max: 500` equalled
`defaultValue: 500`, so the bounds check fired first and refused 5000 with "at
most 500" — true, and not the thing that matters, which is that this is a safety
limit and raising it is not a thing anyone may do. The direction guard was dead
code that looked like protection. The checks are now ordered so `narrowOnly` runs
first, and the mutation suite introduces a mutation that disables it.

The settings editor picks its control from the **declared shape**, not from the
current value: a `string_list` that happens to be empty is still a list, and a
`number` that happens to be 0 is still a number. Guessing from the value is how a
boolean ends up as a text box the first time nobody has set it. And `Number('')`
is `0` — so an empty number box is refused rather than read as zero, both in the
settings editor and in the limit-override form, which is the same bug class that
`numeric()` fixed in Phase 6's automation conditions.

## 86. What the admin panel will not tell you

`health()` reports only what is actually knowable from this deployment: which
database adapter is live, whether the required secrets are set, whether an email
provider and an AI provider are configured, how many jobs are stuck, how many
errors are open in 24 hours. Alongside it is a `notMeasured` list, rendered on
screen under the heading **"Not measured"**:

- uptime — this deployment records no availability history, so any figure would be
  invented;
- response latency — not instrumented;
- queue depth over time — jobs are counted now, not sampled;
- provider latency and error rates — not recorded per provider.

There is no "all systems operational" badge. A green tick that means nothing is
worse than no tick, and a dashboard that silently omits what it cannot measure
teaches its readers to believe it measures everything. `unknown` is given its own
word and its own colour, and ranks **worse than `ok`**: a check that could not be
performed is not a pass.

The platform usage screen lists every metric including the ones still at zero,
because "we have no figure for content generation" and "nobody generated content"
look identical in a sparse object and the first is a bug worth seeing. It reports
no cost figure at all — token counts are recorded, provider invoices are not.

## 87. Reading secrets in exactly one place

`tests/ai-security.test.ts` has asserted since Phase 3 that API keys are read in
exactly one module. Phase 7 tripped it twice: `admin/service.ts` and
`flags/service.ts` both reached for `process.env.*_API_KEY` to report whether AI
was configured. Both now ask `aiIsEnabled()` / `configuredProviders()`.

The health check also wanted to report whether `AUTH_SECRET` is set, and reading
it there would have put a second reader of the most sensitive variable in the
product into a service file — where the next person who needs "the secret, just to
check something" copies the line. It now calls `authSecretIsConfigured()`, which
lives in `lib/auth` and returns a **boolean, never the value**.

## 88. Mutation testing as a script, not a one-off

Phases 3 through 6 did mutation testing by hand. Phase 7 makes it
`scripts/mutation-check.mjs` and `npm run verify:mutation`: fourteen named
mutations, each a plausible mistake or a plausible malicious edit, each with the
tests that are supposed to scream and a sentence saying what breaks if they do
not. It refuses to run if any `find` string no longer matches exactly once, so a
stale mutation fails loudly instead of silently testing nothing.

One mutation survived the first run — the admin 404 described in §83 — and fixing
it meant extracting a pure function, not adding an assertion. That is the whole
point of the exercise: a surviving mutation is a design finding, not a missing
test.

## 89. What remains unverified, honestly

Unchanged from Phase 6, and still the largest risk in the project:

- **`npm install` has never run.** The npm registry returns 403 in this
  environment, so `next build`, `next lint` and Playwright have never executed.
- **No migration has ever been executed.** Fifty-six tables of reviewed SQL, and
  `db/schema.sql` is generated from the migrations by `scripts/build-schema.mjs`
  so the two cannot drift, but no PostgreSQL server has seen either.
- **`.tsx` is not type-checked.** `tsc` runs offline over every `.ts` file with
  the project's real strict settings, but JSX needs `@types/react`, which is not
  available. A `.tsx` type error remains the single most likely first-build
  failure.

Phase 6's `Field` incident is the evidence for how that costs: eighteen misuses of
a render prop, thirteen of them shipped in earlier phases, found at once. Phase 7's
answer is to grow the substitute harness rather than hope — the render check gained
twenty Phase 7 assertions over the new components, and the page audit gained three
composite screens. **Those found three real bugs** the moment they ran: a heading
jump from `h1` to `h3` on the usage screen, the same on the billing screen, and a
structured-data expectation that should never have applied to a noindex admin page.
All three are fixed. None would have been visible without executing the components.

## 90. What a later phase plugs into

| Later work | Seam that already exists |
|---|---|
| A real payment provider | implement `PaymentProvider`; `billingStatus()`, the checkout route and the webhook all already branch on `configured`, and `verifyWebhook` is the only line that makes the webhook safe today |
| A customer portal for invoices | `createPortalSession` is already on the interface and already refuses |
| Annual or per-seat pricing | `content/pricing.ts` and the `verified` guard; the plan registry and every limit stay untouched, because they never knew about money |
| Usage-based billing | `usage_records` already carries the quantities; what is missing is an invoice, not a measurement |
| Cost reporting in the admin panel | the `notMeasured` list names this explicitly; it needs provider invoices, which nothing records |
| Uptime and latency | also named in `notMeasured`; it needs instrumentation, not a dashboard |
| More staff roles | `MINIMUM_STAFF_ROLE` is one map and `STAFF_RANK` one ordering; the gate asserts every permission has an entry |
| Saved content templates | the Templates screen is still an honest coming-soon; Phase 7 shipped the *staff-side* template settings, which are a different thing, and the nav note now says so without naming a phase number |

---

# Part VIII — Phase 8: Production hardening

Phase 8 added no product features. It audited the Phase 7 codebase against the
brief's ten sections and fixed what it found; the itemised findings, controls and
residual risks are in [SECURITY-AUDIT.md](./SECURITY-AUDIT.md), the operational
procedures in [docs/OPERATIONS.md](./docs/OPERATIONS.md).

## 91. Two critical crawler defects, found by running the transport

Every earlier crawler test used IP literals or a fake transport, so two things in
`nodeTransport` had never executed. **The wall-clock timeout did not exist** — only
a socket-idle timer, which a server trickling a byte a second never trips — and
**the DNS pin passed a bare string to a `lookup` hook Node calls with
`{all: true}`**, so every crawl of a real hostname would have failed with
`ERR_INVALID_IP_ADDRESS`. `tests/crawler-transport.test.ts` now drives the real
transport against a local HTTP server, and both fixes have a mutation.

## 92. Client identity behind proxies

`clientKey` trusted the first `X-Forwarded-For` entry — the one the client
writes. It now counts `TRUSTED_PROXY_COUNT` hops from the right, falls back to
`X-Real-IP`, and finally to a shared `unknown-client` bucket (fail closed: an
unidentifiable client shares one limit rather than getting its own).

## 93. Reliability primitives (`lib/reliability`)

`withTimeout` (the callee receives an `AbortSignal`), `retry` (requires
`idempotent: true` at the call site, retries only transient failures, full-jitter
backoff), `CircuitBreaker` (consecutive failures open it; half-open admits exactly
one probe), and `IdempotencyStore` (stores the in-flight promise so concurrent
callers share one execution; failures are not cached). The durable half of
idempotency is the `idempotency_keys` table in 0008, whose `UNIQUE (scope, key)`
is the enforcement.

## 94. Job recovery and scheduled maintenance

A stale running job is **requeued with backoff while attempts remain** and failed
only at `MAX_ATTEMPTS` — a dead worker says nothing about whether the job would
succeed. `reapStaleJobs` and `deleteExpiredCrawlData` were previously called by
nothing; `lib/jobs/maintenance.ts` runs both, isolated from each other, behind
`POST /api/internal/maintenance` (bearer `CRON_SECRET` of at least 32 characters,
read in `lib/auth` per the Phase 7 secrets rule; 404 otherwise).

## 95. Observability without leakage

`lib/observability/log.ts` writes one JSON object per line. Redaction cannot be
bypassed: secret key names (exact and by suffix), secret-shaped values (Bearer,
Basic, provider key prefixes, JWTs — all **global** patterns, after the gate found
the first version redacted only the first match in a line), a per-field length
cap and a cycle guard. Reserved fields are written last so a caller cannot forge
`level` or `time`. `metrics.ts` accepts only declared counter and histogram names.

## 96. Privacy: export, deletion, disclosure

The export (`lib/privacy/export.ts`) is organization-scoped, versioned, counts
every collection, lists in the file itself what it does not contain, and is
walked for credential-shaped keys after it is built rather than trusting each
builder. It needs the sudo window **and** `billing:read`, is audited with counts
only, and is served `private, no-store`. Consent revocation now deletes the
crawled pages before it writes `data_deleted_at` — previously it wrote only the
marker. `DELETE /api/crawl?consentId=` exposes it. The privacy policy gained
sections on app data, crawling and AI processing.

## 97. Performance

Cursor pagination (`lib/api/pagination.ts`): `limit + 1` rows, an unsigned
base64url `{at, id}` cursor that grants nothing because every query is still
tenant-scoped, and a hard cap of 100. Migration 0008 indexes seventeen
foreign keys PostgreSQL does not index on its own, adds five query-shape
indexes for lookups no existing index could serve, and `(created_at DESC, id DESC)`
cursor indexes. The dead `/fonts` cache rule was replaced; unversioned public
images are never cached `immutable`.

## 98. Accessibility

`scripts/contrast-check.mjs` converts OKLCH to linear sRGB and computes WCAG
relative luminance for 27 declared token pairs in both themes; six real failures
were fixed. Decorative `--border` is exempt under SC 1.4.11 and says so; controls
use `--border-strong`. Tables gained captions, dialogs `useId` labels, the auth
shell a skip link, and live errors `role="alert"`.

## 99. The Phase 8 gate and what is still unverified

`tests/phase8-gate.test.ts` has one describe per quality-gate item (sixteen).
Behaviour is exercised where possible; source scans run on comment-stripped code.
Twenty mutations are all caught. **Still unverified:** `next build`, ESLint,
Playwright on any browser, a Postgres adapter (so RLS is inert), a distributed
rate limiter, and a nonce-based CSP.

---

# Part IX — Phase 9: Final QA and release preparation

## 100. What Phase 9 verified, and how

| Brief item | Evidence |
|---|---|
| Complete user journey | `tests/journey.test.ts`: 24 stages, one tenant, ids and counts carried between modules, and usage totals reconciled at the end |
| Public website QA | `sandbox:audit` (59 pages: headings, JSON-LD, accessible names), the phase gates (metadata, sitemap, robots, the 404 page), and `tests/e2e/*` (written, not run) |
| Application states | The render check's empty, loading and error assertions, plus the service tests |
| Failure testing | `tests/failure-recovery.test.ts`, twelve modes plus the circuit breaker |
| Data integrity | `docs/DATA-INTEGRITY.md`: nothing fabricated was found |
| Secrets | The Phase 9 gate scan and the `.env.example` coverage test |
| Database | `tests/database-audit.test.ts` and migration 0009 |
| Deployment | `Dockerfile`, `docker-compose.yml`, `deploy/Caddyfile`, `docs/DEPLOYMENT.md` |
| Documentation | `docs/README.md` indexes every topic; three references are generated |

## 101. The AI provider circuit breaker

Each provider instance gets its own breaker. It opens after five consecutive **outage-class** failures (timeout, unavailable, unknown) and stays open for 30 seconds, then lets exactly one probe through. A content refusal or an over-long context never counts toward opening it. Without the breaker, one provider outage made every customer's request wait through the full timeout and retry sequence. The breaker is keyed by provider object in a `WeakMap`, so tests with fresh fake providers never share one.

## 102. Why the verdict is "not ready"

The application logic is complete and tested. Two things remain unproven, and the brief forbids calling the product ready while either is open:

- **There is no PostgreSQL adapter.** It fails fast when `DATABASE_URL` is set rather than silently falling back to memory.
- **The toolchain has never produced a build.**

The Phase 9 gate pins both facts to the code. When the adapter or email delivery lands, the gate fails until the report is revised. A stale "not ready" is as dishonest as a premature "ready".
