import type { NextConfig } from 'next';
import { securityHeaders } from './src/lib/security/headers';

const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  compress: true,
  // A self-contained server bundle for the Docker image (see Dockerfile), which
  // sets NEXT_OUTPUT_STANDALONE=true. It is OFF by default because platform
  // adapters (Netlify's OpenNext runtime, Vercel) build their own output and
  // must not be handed a standalone bundle.
  ...(process.env.NEXT_OUTPUT_STANDALONE === 'true' ? { output: 'standalone' as const } : {}),

  // Phase 1 ships no remote images; `formats` keeps AVIF/WebP negotiation on
  // for any local asset served through next/image.
  images: {
    formats: ['image/avif', 'image/webp'],
    remotePatterns: [],
  },

  eslint: {
    // Never let a lint failure silently ship.
    ignoreDuringBuilds: false,
  },
  typescript: {
    ignoreBuildErrors: false,
  },

  async headers() {
    return [
      {
        source: '/:path*',
        headers: securityHeaders(),
      },
      {
        // Phase 8: this rule used to target `/fonts/*`, which does not exist
        // (fonts are self-hosted by next/font under `/_next/static`, which Next
        // already serves immutable). The public brand and OG images are NOT
        // fingerprinted, so they get a day plus revalidation, never `immutable` —
        // an immutable unversioned file can never be corrected in a browser.
        source: '/:dir(brand|og)/:path*',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=86400, stale-while-revalidate=604800' },
        ],
      },
    ];
  },
};

export default nextConfig;
