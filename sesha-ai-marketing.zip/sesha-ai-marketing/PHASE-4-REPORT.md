# SeSha AI Marketing — Phase 4 report

SEO · AEO · Secure website crawler
Built on the stable Phase 3 codebase. Authentication, onboarding, the dashboard
and the whole AI layer are unchanged and still pass their own suites.

This was the phase where the product starts reading the real world. Everything
else in it follows from one fact: **a crawler is a server-side request forgery
engine that a user points wherever they like.** The brief said "do not implement
an unsafe website crawler", and most of the work went into earning that.

---

## 1. The quality gate

Every line of the brief's sixteen-item gate is an executable assertion in
`tests/phase4-gate.test.ts`, one `describe` block per item, so the gate fails
loudly if the behaviour regresses rather than being ticked by hand.

| # | Gate item | Status | Where it is proven |
|---|---|---|---|
| 1 | URL validation | **PASS** | `phase4-gate`, `crawler-security` · scheme, shape, credentials, port, hostname, normalisation; 18 dangerous schemes named individually, each with a written reason |
| 2 | SSRF protection | **PASS** | `phase4-gate`, `crawler-security` · see §3 — three specific bypasses, three specific defences |
| 3 | Private IP blocking | **PASS** | `crawler-security` · 15 IPv4 and 9 IPv6 ranges plus 5 metadata addresses, byte-level, through IPv4-mapped / NAT64 / 6to4 wrapping |
| 4 | robots handling | **PASS** | `crawler-limits`, `phase4-gate` · most-specific rule wins, groups not merged, `*`/`$` honoured, **fails closed**, governs the sitemap fetch too |
| 5 | Sitemap handling | **PASS** | `crawler-limits` · urlset / sitemapindex / plain text; `<!DOCTYPE` or `<!ENTITY` refuses the document outright; same-site entries only |
| 6 | Crawl limits | **PASS** | `crawler-limits`, `phase4-gate` · pages, depth, concurrency, delay; every path narrows, none widens |
| 7 | Timeouts | **PASS** | `crawler-limits` · per-page 15 s and whole-crawl 10 min, both enforced against a transport that never answers |
| 8 | Response limits | **PASS** | `crawler-limits` · 2 MB cap enforced on the stream, and on a lying `content-length` |
| 9 | Crawl queue | **PASS** | `crawler-limits` · breadth-first; budget checked on dequeue as well as enqueue; dedup on the normalised URL; politeness slot reserved before sleeping |
| 10 | SEO audit | **PASS** | `audit` · 15 areas; `notChecked` always non-empty |
| 11 | AEO audit | **PASS** | `audit` · 12 areas; the disclaimer states no tool can measure AI citation |
| 12 | Provenance | **PASS** | `audit`, `phase4-gate` · every finding carries all six parts; no score reaches the screen without its basis |
| 13 | No fabricated metrics | **PASS** | `audit`, `phase4-gate` · see §5 — the type makes a sourceless number unrepresentable |
| 14 | Background jobs | **PASS** | `jobs` · `QUEUED → RUNNING → COMPLETED \| FAILED \| CANCELLED`, only legal transitions; progress, cancellation, retry |
| 15 | Error handling | **PASS** | `jobs` · every failure carries a written code; an unreachable site fails cleanly rather than hanging; a cancelled crawl keeps what it read |
| 16 | Tests | **PASS** | 1049 passing, 0 failing; real `tsc` PASS over 142 files |

A seventeenth block was added that the brief did not ask for: **no delivered
phase may still be advertised as upcoming.** See §6 — it exists because Phase 4
shipped while fifteen places in the product still said features were "arriving in
Phase 4".

---

## 2. What was built

**The crawler** (`lib/crawler`, 10 modules) — one module per pipeline stage:
`url-policy` (is this a URL we will treat as a public page), `ip-policy` (is this
address one we may connect to), `resolver` (resolve once, check every answer),
`fetcher` (connect to the checked address, re-validate every redirect), `robots`,
`sitemap`, `queue` (the frontier), `parse` (extraction, no DOM), `crawler` (the
pipeline).

**The store** — `0004_crawl_audit.sql` adds `jobs`, `crawls`, `crawled_pages`,
`audits` and `keywords`, bringing the schema to **32 tables**, all with
row-level security and all tenant-scoped. Raw HTML is deliberately not stored.

**The audits** (`lib/audit`) — `auditSeo` covers the fifteen areas the brief
names, `auditAeo` the twelve. Both are rule-based over crawled data, not
generated: a finding is only made when the evidence for it was actually read.
Both always return a non-empty `notChecked` list, because an HTML-only crawl
genuinely cannot see rendering behaviour or Core Web Vitals.

**The findings contract** (`lib/audit/finding.ts`) — the six parts are the type,
not a convention. `lintFindings` then **drops** any finding that promises AI
ranking, AI citation, AI visibility or guaranteed traffic. `scoreFindings`
returns a score together with a `basis` stating the score is SeSha's own
weighting of its own checks, not a measurement by Google or any answer engine.

**Keywords** (`lib/keywords`) — nine kinds, each carrying query, intent,
relevance, competition, priority, suggested content format and entities.

**Jobs** (`lib/jobs`, `lib/crawl/service.ts`) — five states with `canTransition`
as the only legal path, progress reporting, cancellation, retry with
`isRetryable`, and a written failure code on every failure.

**Routes** — `POST /api/crawl`, `GET|POST /api/jobs`, `GET|DELETE
/api/jobs/[id]`, `POST /api/audit`, `GET /api/keywords`. As in Phase 3, routes do
HTTP and nothing else; every decision lives in the service layer and is tested
against the in-memory database.

**Screens** — `/app/seo-aeo` (run an audit, read the findings, see the score with
its basis) and `/app/website-audit` (start and watch a crawl, read the keyword
table, and read the crawler's policy in plain language). Both nav items moved
from "Soon" to available; the workspace now has 11 of 18 areas live.

**Dependencies added: none.** Still four in production.

---

## 3. The security argument

This is the section to read if you read only one. Each defence below answers a
specific bypass, not a general worry.

### A hostname blocklist alone is not a defence

The name is resolved *after* the check, and whoever controls the DNS record
controls what it resolves to. So `resolver.ts` resolves the name once and judges
**every** A and AAAA answer it receives. If any answer is private, the name is
refused outright — allowing the public answers and hoping the stack picks one of
them is a race, not a policy. A hostname already on the blocklist (`localhost`,
`*.localhost`, `*.internal`, `.local`, the reserved TLDs) never reaches DNS at
all.

### A check followed by `fetch` is defeated by DNS rebinding

`fetch` resolves the name again when it connects, and offers no way to say which
address to use. An attacker answers `93.184.216.34` for the check and
`127.0.0.1` for the connection. This is the single reason the crawler uses
`node:http`/`node:https` directly: the agent is given a `lookup` that ignores
the hostname and hands back the address that was already checked, so the socket
cannot perform its own resolution and there is no second answer to differ from
the first.

### A string-prefix blocklist is defeated by encoding

`10.0.0.1` is caught by a naive check. `0xA.0.0.1`, `012.0.0.1`, `167772161`,
`::ffff:10.0.0.1` and `64:ff9b::10.0.0.1` are not, and all reach the same place.
`parseIpv4` refuses ambiguous notations rather than normalising them — a leading
zero, a non-decimal digit, anything that is not four plain decimal octets — and
`finishIpv6` unwraps IPv4-mapped, NAT64 and 6to4 addresses so `checkAddress`
judges **both** the outer bytes and the embedded address. Comparison is
byte-level against the range's prefix length.

### The rest of it

HTTP and HTTPS only, with eighteen dangerous schemes refused by name, each
with a written reason. No credentials in URLs. No cookies and no authorization header, ever.
Redirect hops capped at five, each hop re-validated from scratch, loops detected
separately from the hop count. Response bodies capped at 2 MB, enforced on the
stream rather than trusting `content-length`. Per-page and whole-crawl timeouts.
Page and depth budgets enforced on dequeue as well as enqueue. A per-host
politeness delay whose slot is reserved before sleeping, so two workers cannot
both decide it is their turn. An honest, traceable user agent.

robots.txt **fails closed**: a 5xx, a timeout or a connection failure stops the
crawl. A 404 means the site published no rules, which is permission. Failing
open on a 500 would mean a site's momentary outage became consent.

**Every configuration path narrows.** `CRAWLER_MAX_PAGES` can only lower the
cap; `CRAWLER_EXTRA_BLOCKED_HOSTS` can only add to the blocklist. A configured
value that would widen the policy is ignored, and there are tests whose whole
purpose is to prove an operator cannot loosen it.

Two structural rules are enforced by tests over the source tree rather than by
review: **nothing outside `lib/crawler` may import `node:http`, `node:https` or
`node:dns`** (that is the path that bypasses every check above), and **no client
component may import the crawler** (which would ship the policy to the browser,
where it is advisory rather than enforced).

And the crawl is authorised, not assumed: consent is checked when the job is
queued **and again when it runs**, because a job can sit in a queue after consent
is withdrawn. Withdrawal hard-deletes the stored page content; the crawl row
survives so the history of what was done stays auditable.

---

## 4. Honesty: what the product will not claim

The brief forbids promising AI ranking, AI citation, AI visibility or guaranteed
traffic. Three independent mechanisms, because a prompt — or a coding convention
— is not a control:

1. **The findings type** requires all six parts, so a recommendation cannot exist
   without its evidence and its data basis.
2. **`lintFindings` drops** a finding that makes a forbidden promise. Dropping
   rather than flagging is the point: a flagged finding is still on screen.
3. **`AEO_DISCLAIMER`** states plainly that no tool can measure whether an AI
   system cites a page. The AEO audit reports structure *associated with* being
   quotable, and says that is what it is doing.

Scores never appear without their basis. `notChecked` is always non-empty. The
crawler does not execute JavaScript, and the product says so on screen rather
than only in this report.

---

## 5. No fabricated search volume

The brief's hardest line to keep honestly was *"never fabricate search volume"*,
because the pressure to fill that column is permanent. The defence is structural
rather than procedural:

```ts
export type SearchVolume =
  | { kind: 'unavailable'; label: 'Data unavailable'; why: string }
  | { kind: 'estimate';    label: 'AI estimate'; magnitude: VolumeMagnitude; basis: string }
  | { kind: 'measured';    label: 'Measured'; monthly: number; source: string; asOf: string };
```

There is **no variant that carries a bare number.** A figure can only exist
alongside a source and an as-of date. No data source is connected in Phase 4, so
every keyword is `unavailable` with a written reason, and the table says so above
itself rather than in a footnote.

The `keywords` table stores `volume` as `jsonb` and has **no numeric volume
column**, with a comment in the migration explaining why: a numeric column would
eventually be filled with an estimate by someone in a hurry. `PRIORITY_BASIS`
states that priority is computed from relevance, intent and competition and
**excludes volume**, so priority is not a number pretending to be derived from
data nobody has.

---

## 6. Defects found and fixed

Writing the tests found real problems. These are the ones worth recording.

**A Phase 2 bug: consent could not be withdrawn.** `revokeCrawlConsent` looked
the record up via `tenant.projectId`, which is optional on `TenantContext` and is
not set on a settings request — so the lookup always came back empty and
revocation always threw `NotFound`. This had shipped in Phase 2 and was only
found because Phase 4 is the first code that depends on consent meaning
something. `CrawlConsentRepository.findById` was added, the lookup fixed, and a
regression test written.

**robots.txt did not govern the sitemap fetch.** `Disallow: /` disallows
`/sitemap.xml`, and the crawler fetched it anyway. The `allow` predicate is now
passed into `discoverSitemap`.

**`Crawl-delay: 99999` produced the *shortest* delay.** The parser rejected the
out-of-range value and the caller then fell back to the floor — the exact
opposite of what the site asked for. It now records and clamps.

**A forbidden-promise pattern did not match.** `\b` cannot precede `#`: there is
no word boundary between a space and a punctuation character, so the `#1` pattern
never fired. This exact mistake had already shipped once, in the Phase 3 claim
linter — it is now fixed in both places, with a comment in the source recording
that it has been made twice so it is not made a third time.

**A question-shaped heading was being reported as an FAQ.** A heading that reads
like a question is not the same evidence as a declared `FAQPage`. `ExtractedFaq`
now carries `source: 'structured_data' | 'heading'`, and only structured data
counts as an FAQ for audit purposes.

**"Stopped early" was silently wrong.** URLs refused at the door for budget were
not counted, so a crawl that hit its cap could report that it had not.

**A duplicate-title finding quoted the wrong string** — the lowercased comparison
key rather than the title the user actually wrote.

**I documented two environment variables before they existed.** `.env.example`
described `CRAWLER_MAX_PAGES` and `CRAWLER_EXTRA_BLOCKED_HOSTS` while neither was
read anywhere. That is precisely the kind of dishonesty this project is built to
avoid, so both were implemented — as narrowing-only, with tests proving they
cannot widen the policy.

**Fifteen places still promised Phase 4 after Phase 4 shipped.** Six "Soon"
screens, six navigation notes and three agent definitions all said features were
"arriving in Phase 4" — a false promise the moment this phase was delivered
without them. A sixteenth, the Templates screen, had been promising *Phase 3*
since that phase shipped. All were corrected, and `tests/phase4-gate.test.ts` now fails if
any planned surface names a phase that has already been delivered. Relatedly, the
`seo` and `aeo` agent definitions were corrected: the **audits** shipped in
Phase 4 and are rule-based, so the agents that would write prose over their
findings now say that, and point at a later phase.

Two earlier self-inflicted problems are worth noting because they were mistakes
in the *verification*, not the product: my own static checker demanded a default
export from `lib/crawler/robots.ts` because it matched Next's route convention by
filename anywhere (now scoped to `src/app`), and a test fixture used a
`.example` domain, which the URL policy correctly refuses as a reserved TLD.

---

## 7. Verification status

Unchanged constraint: **the npm registry is unreachable from the build
environment** (`registry.npmjs.org` returns 403 at the gateway). `npm install`,
`next build`, `next lint` and Playwright have never been run, in any phase. The
offline harness built in earlier phases carried over and was extended.

| Check | Result |
|---|---|
| Unit tests | **1049 passing, 0 failing** (211 suites) |
| Real `tsc`, strict + `noUncheckedIndexedAccess`, every `.ts` file | **142 files, PASS** |
| Static verification (syntax, imports, exports, RSC boundary, route conventions) | **214 files, PASS** |
| Component render assertions against real HTML | **49 passing** |
| Whole-page render audit | **50 surfaces, 0 problems** |
| `db/schema.sql` matches the migrations | **PASS, 32 tables** |

Phase 4's own suites: `crawler-security` 67, `crawler-limits` 62, `audit` 73,
`jobs` 54, `phase4-gate` 57.

**Mutation testing** was used again to confirm the new tests bite rather than
merely pass. Three defects were introduced deliberately — skipping the second
consent check, bypassing the promise linter, and crawling despite an unreadable
robots.txt — and all three were caught. The mutation of the new
already-shipped-phase guard was also checked: reverting one screen to "Phase 4"
fails the gate.

### Still not verified — run these first

| Check | How to run |
|---|---|
| Type checking of `.tsx` files (needs `@types/react`) | `npm run typecheck` |
| Lint | `npm run lint` |
| Production build | `npm run build` |
| Browser behaviour | `npm run test:e2e` |
| Visual appearance (Tailwind was never compiled here) | `npm run dev` |

`tests/e2e/crawl.spec.ts` is authored but unexecuted. **Nothing in it crawls a
third-party site**: the real-crawl tests are skipped unless `CRAWL_E2E=1` and
`CRAWL_E2E_SITE` point at a site the operator owns. What runs unconditionally is
the part that matters most — that the crawl surfaces refuse to act without
consent, and that the refusal is visible rather than a silent no-op.

A type error inside a `.tsx` component remains the most likely first-build
failure, for the same reason as in Phase 3: JSX type checking needs
`@types/react`, and a hand-written stub would report confident nonsense.

### Before storing real customer crawls

`deleteExpiredCrawlData` exists, is tested, and **nothing calls it on a
schedule.** Wire it to a cron or job runner. This is noted in the README's
go-live list rather than left implied.

---

## 8. Stopping here

Phase 4 is complete. **Phase 5 has not been started**, per the phased
development instruction. The seams it would use are listed in ARCHITECTURE.md
§47: `lib/audit` findings are data a narrative agent can read; `SearchVolume`'s
`measured` variant already demands a source and an as-of date, so connecting a
real volume provider changes nothing else; `jobs` already carries the status,
progress and retry a scheduler needs.

One thing deliberately left for a later phase rather than stubbed: competitor
crawling. The crawler is constrained to a site the customer has consented to,
and pointing it at a third party needs its own authorisation story — not a wider
crawler.
