# Product notes and verification record

_This was the original project README: the full build record, the verification
status, and the design decisions behind each subsystem. It is kept as-is because
the reasoning is the point. The short README in the repository root is the
entry point; this file is the detail behind it._

Public marketing website, authentication and accounts, the AI generation layer,
the SEO/AEO audit on a secure first-party crawler, and the structured-data,
competitor and marketing-operations layer. The platform for SeSha AI Marketing,
built by SeSha AI Marketing.

Next.js 15 (App Router) · TypeScript (strict) · React 19 · Tailwind CSS v4 ·
**four production dependencies** (`next`, `react`, `react-dom`, `clsx` +
`tailwind-merge`).

**Phase 1** — public website, design system, SEO/AEO/structured data. Complete.
**Phase 2** — authentication, roles, tenancy, onboarding, dashboard. Complete.
**Phase 3** — AI copilot, marketing strategy, Content Studio, social planning. Complete.
**Phase 4** — SEO + AEO audits and the secure website crawler. Complete.
**Phase 5** — schema validation, competitors, ads, leads, messaging, video. Complete.
**Phase 6** — analytics, marketing calendar, automation, reports, export, notifications. Complete.
**Phase 7** — subscriptions, plan limits, usage tracking, billing abstraction, admin platform, feature flags. Complete.
**Phase 8** — production security, performance, reliability, accessibility and privacy hardening. Complete (see [SECURITY-AUDIT.md](./SECURITY-AUDIT.md)).
**Phase 9** — final QA, deployment preparation, documentation. Complete. **Verdict: NOT production ready** — see [PRODUCTION-READINESS-REPORT.md](./PRODUCTION-READINESS-REPORT.md) (blockers B1–B5).

Three properties are worth knowing before reading anything else:

- **An AI response that does not declare where each part of it came from is
  rejected, not displayed.** See [Provenance](#provenance).
- **The crawler cannot be pointed at a private network, and will not crawl a
  site without recorded consent.** See [The crawler](#the-crawler).
- **The product refuses to invent.** No generated rating, price or credential; no
  competitor claim that a public page cannot show; no message to a bought list;
  no generated image; **no analytics figure without its source**. See
  [What SeSha refuses to do](#what-sesha-refuses-to-do).
- **No payment provider is connected, so nothing can be charged — and there is no
  column in fifty-seven tables, and no function signature anywhere, that could hold
  a card.** See [Billing](#billing).
- **The admin panel returns 404 to anyone who is not platform staff.** An
  organization admin is not a platform admin; the two are separate tables on
  purpose. See [The admin platform](#the-admin-platform).
- **Every number on the analytics screen says where it came from, or says it is
  not there.** `MetricValue` has no variant carrying a bare figure, so the
  dishonest version is not expressible. An unavailable metric renders its reason,
  never a zero.

See **[ARCHITECTURE.md](./ARCHITECTURE.md)** for the full architecture and **[docs/README.md](./docs/README.md)** for every other document.
Continuing development in Claude Code: **[CLAUDE.md](./CLAUDE.md)** and **[docs/CLAUDE-CODE-HANDOFF.md](./docs/CLAUDE-CODE-HANDOFF.md)**.
Taking it live: **[docs/GOING-LIVE.md](./docs/GOING-LIVE.md)**.

---

## Getting started

```bash
npm install
cp .env.example .env.local
#   set NEXT_PUBLIC_SITE_URL
#   set AUTH_SECRET       (openssl rand -base64 48)  — REQUIRED in production
#   optionally set DATABASE_URL, SMTP_URL, GOOGLE_CLIENT_ID/SECRET
npm run dev                    # http://localhost:3000
```

Without `DATABASE_URL` the app runs on an **in-memory** adapter: everything
works, and all data is lost on restart. Without `SMTP_URL` verification and
reset links are **logged rather than sent** — set `EMAIL_DEBUG=true` in
development to print the link so you can complete a signup without a mailbox.
Both states are shown on screen in Settings rather than hidden.

### Applying the database

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/0001_init.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/0002_accounts.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/0003_ai_content.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/0004_crawl_audit.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/0005_schema_competitors_ops.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/0006_analytics_calendar_automation_reports.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/0007_subscriptions_usage_admin.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/0008_indexes_and_operations.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/0009_foreign_key_indexes.sql
```

`0007` renames the plans in place. It widens the `CHECK` constraint, updates the
existing rows, then narrows the constraint again — in that order, because
narrowing first fails on the data already there. Run it as a whole file, not
statement by statement.

Migrations are forward-only. `db/schema.sql` is generated from them
(`node scripts/build-schema.mjs`) and a test fails if it is stale.

> **If you received this project as an archive**, delete `node_modules` before installing.
> The offline verification harness writes stand-in modules there (see below), and the real
> packages must win:
>
> ```bash
> rm -rf node_modules && npm install
> ```

### Run the full quality gate

```bash
npm run verify                 # typecheck -> lint -> unit tests -> production build
npm run build && npm run test:e2e   # Playwright: five breakpoints + Firefox, WebKit, Edge, Android, iOS
```

---

## Scripts

| Script | What it does |
|---|---|
| `npm run dev` | Development server |
| `npm run build` | Production build |
| `npm run start` | Serve the production build |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run lint` | ESLint (`next/core-web-vitals` + `next/typescript`) |
| `npm test` | Unit tests (`node:test`, no browser needed) |
| `npm run test:e2e` | Playwright end-to-end suite |
| `npm run verify` | typecheck + lint + test + build |
| `npm run verify:static` | Offline structural verification (see below) |
| `npm run verify:types` | Real `tsc` over every `.ts` file, offline |
| `npm run verify:tsx` | Type-checks every `.tsx` file against narrow React shims (intrinsic DOM elements excepted) |
| `npm run verify:contrast` | WCAG contrast of every declared token pair, both themes |
| `npm run verify:mutation` | Mutation testing — 21 deliberate breakages, each with the tests that must catch it |
| `node scripts/typecheck.mjs` | Real `tsc` over every `.ts` file, offline (see below) |
| `npm run sandbox:all` | The full offline harness |
| `node scripts/build-schema.mjs` | Regenerate `db/schema.sql` from the migrations |
| `node scripts/build-docs.mjs` | Regenerate `docs/API.md`, `docs/DATABASE.md`, `docs/ENVIRONMENT.md` (`--check` to verify) |

---

## Verification status — read this first

This project was developed in an environment with **no access to the npm registry**
(`registry.npmjs.org` returns `403 Forbidden` at the network gateway). `npm install`,
`next build`, `tsc --noEmit` and `next lint` therefore **could not be executed** during
development.

Rather than claim a green build that was never run, the checks that do not require
installed dependencies were rebuilt from the TypeScript compiler API and
`react-dom/server`. This is what **was** verified, and what was not:

### Verified in the build environment

| Check | Result |
|---|---|
| Unit tests — routes, SEO, security, links, content policy, auth crypto, RBAC, tenancy, auth flows, OAuth, onboarding, database schema, provenance, providers, orchestrator, cost control, content, strategy, social, crawler security, crawler limits, audits, jobs, the schema engine, schema generation, competitors, ads, leads, messaging, video, analytics, the calendar, automation, reports, the PDF writer, share links, notifications, the Phase 3–6 gates, **plans, quotas, billing, feature flags, admin security, the Phase 7 gate** | **1900 passing, 0 failing** (367 suites) |
| **Type checking — real `tsc`, strict + `noUncheckedIndexedAccess`, every `.ts` file (library, content, API routes, tests)** | **260 files, PASS** |
| Static verification — 359 files: syntax, import resolution, named exports, server/client boundary, route conventions, **`Field` render-prop usage** | **PASS** |
| Component render assertions against real HTML output | **69 passing** |
| Whole-page render audit — 59 surfaces plus the full document, **including the usage dashboard, the billing screen and the admin shell** | **0 problems** |
| **Mutation testing — 14 named mutations, each a plausible mistake or malicious edit** (`npm run verify:mutation`) | **all 14 caught** |
| **No payment data is storable** — the four `payment_*` columns are brand, last4, expiry month and expiry year, and no other; no billing type or provider method names a chargeable field; the billing screen renders no data-entry control at all | **PASS** |
| **Admin APIs answer 404 to non-staff** — including staff holding the wrong role; the only other status is the sudo 403 | **PASS** |
| **Every admin action is recorded, including every read**, and `admin_actions` does not cascade away with an organization | **PASS** |
| **No fabricated analytics** — with nothing connected, no metric requiring a connection carries a figure; `db/schema.sql` has no column that could hold one | **PASS** |
| **The generated PDF is a real PDF** — verified against `qpdf --check`, `pdftotext` and `pypdf`: 4 pages, valid cross-reference table, correct metadata | **PASS** |
| **Share links** — random token, only the hash stored, expiring, revocable, one message for every failure | **PASS** |
| JSON-LD on every public page, validated by this project's own validator | **PASS** |
| Heading hierarchy — one `h1`, no skipped levels, every page | **PASS** |
| Accessible names on every link and button in rendered output | **PASS** |
| FAQ answers present in HTML while collapsed (AEO) | **PASS** |
| No fabricated metrics, customer counts, superlatives, awards or guarantees | **PASS** |
| No secrets, no server-only env vars in client components | **PASS** |
| **Password hashing** — scrypt, salted, never plaintext, timing-safe | **PASS** |
| **Account enumeration** — sign-up, sign-in and reset are indistinguishable | **PASS** |
| **Tenant isolation** — every cross-organization path returns 404 | **PASS** |
| **OAuth** — real RS256 verification; tampering, `alg:none`, algorithm confusion, wrong audience and nonce replay all rejected | **PASS** |
| **Crawl consent** — never granted implicitly; SSRF blocklist enforced | **PASS** |
| **Database schema** — migrations, generated schema and code agree | **PASS** |
| **No exposed API keys** — no client component imports the provider module as a value; keys read in one file; none named `NEXT_PUBLIC_*`; none in `publicStatus()`, a response payload or the audit log | **PASS** |
| **No fabricated facts** — an untagged AI response is rejected; an unsourced statistic is an error and blocks approval | **PASS** |
| **No pretend publishing** — no platform can publish; no published or scheduled state exists in the type, the validator, the database or any control | **PASS** |
| **AI context** — business, audience, goals, channels and brand voice reach the prompt; what is missing is stated explicitly | **PASS** |
| **Languages** — English, Hindi and Hinglish each carry a distinct instruction, and script is verified in the output | **PASS** |
| **Usage limits** — the plan quota refuses a call before the provider is contacted | **PASS** |
| **Error handling** — a transient failure retries; a sustained one becomes written prose with no provider detail | **PASS** |
| **SSRF** — loopback, private, link-local, CGNAT, documentation, multicast and reserved ranges, and five cloud metadata addresses, refused in both IPv4 and IPv6 and through IPv4-mapped, NAT64 and 6to4 wrapping | **PASS** |
| **DNS rebinding** — the checked address is pinned into the socket; a name that resolves differently on the second lookup cannot be reached | **PASS** |
| **Decimal, octal, hex and integer IP forms** — ambiguous notations are refused rather than normalised | **PASS** |
| **Redirects** — every hop is re-validated from scratch; a redirect to a private address is refused at the hop | **PASS** |
| **robots.txt** — most-specific rule wins, groups are not merged, an unreadable file stops the crawl, and robots governs the sitemap fetch too | **PASS** |
| **Crawl limits** — pages, depth, concurrency, politeness delay, per-page and whole-crawl timeouts, response size; every configuration path narrows and none widens | **PASS** |
| **Consent** — checked at queue time and again at execution; withdrawal hard-deletes page content; raw HTML is never stored | **PASS** |
| **No forbidden promises** — a finding claiming AI ranking, AI citation, AI visibility or guaranteed traffic is dropped, not flagged | **PASS** |
| **No fabricated search volume** — no type, table, API payload or screen can carry a volume figure without a source and an as-of date | **PASS** |
| **Every finding carries six parts** — issue, evidence, recommended change, expected benefit, confidence, data basis — and no score reaches the screen without its basis | **PASS** |
| **Background jobs** — only legal state transitions; progress, cancellation and retry; a written failure code on every failure | **PASS** |
| **Schema validation** — JSON-LD, Microdata and RDFa across 24 types, with every finding carrying one of four dimensions and six statuses | **PASS** |
| **The four dimensions stay apart** — schema validity, search eligibility, SEO guidance and AEO clarity are grouped separately on screen, and no finding promises a rich result or a citation | **PASS** |
| **Corrected JSON-LD** — placeholders are visibly fake; ratings, prices and credentials are never filled in, not even as a placeholder | **PASS** |
| **Validation history** — every run stored with the validator's own version, so a diff can be attributed to your markup rather than to our rules | **PASS** |
| **Schema generation** — every value traces to a field; the output is validated by our own validator; the refusals are reported | **PASS** |
| **Competitor authorisation** — no page is read without a recorded acknowledgement, checked again immediately before the first request; at most three pages; page content is never stored | **PASS** |
| **Verified vs inferred** — a verified competitor finding cannot exist without a source URL and a time; a model's conclusion cannot be recorded as an observation | **PASS** |
| **No unknowable competitor claims** — revenue, spend, traffic, customer and follower figures are dropped unless quoted from the competitor's own page | **PASS** |
| **Ads** — platform limits enforced before approval; no type can hold a performance measurement; nothing spends | **PASS** |
| **Leads** — seven stages with legal transitions only; the score's components always sum to its total and are stored with it | **PASS** |
| **Messaging** — a bought or scraped list is refused and not stored; a marketing email without an unsubscribe cannot be approved; nothing can send | **PASS** |
| **Video** — scene durations are summed against the platform limit; no type or column can hold a generated image | **PASS** |
| **Plans** — four plans, eleven limits each, no price in the registry or in any module that decides an entitlement; comparison by rank, so repricing cannot invert an upgrade; the earlier plan names still resolve | **PASS** |
| **Quotas** — every limit has a measurement; unlimited, not-included and unused are distinguishable everywhere; an absolute limit never promises a reset; a request larger than the whole monthly allowance says so; every refusal is recorded with the usage frozen at that moment | **PASS** |
| **Subscription state** — every status reachable, no transition leaves a non-status, an out-of-order webhook is recorded and ignored rather than throwing, **read access is never revoked in any state**, and the grace window does not restart on a second failure | **PASS** |
| **Webhook safety** — the signature is verified against the raw body *before* the body is parsed; the null provider verifies nothing; a retry is idempotent; a bad signature is answered 202 with no detail | **PASS** |
| **Admin separation** — an organization admin is refused by the admin panel; `StaffContext` carries no organization id; the admin read interface cannot reach customer content | **PASS** |
| **Feature flags** — five categories, fixed registry, a rule cannot be stored for an undeclared flag, the kill switch beats every targeting list, and the rollout percentage is a stable cohort | **PASS** |
| **The README lists every migration, in order** — added after it silently stopped at 0005 for two phases | **PASS** |
| **Phase 8 quality gate** — sixteen items, 40 assertions (`tests/phase8-gate.test.ts`) | **PASS** |
| **Crawler transport against a real local server** — slow drip, silent server, oversize bodies, the DNS pin | **PASS** |
| **`.tsx` type check over narrow React shims** (`verify:tsx`) | **PASS** |
| **WCAG contrast, 27 token pairs × 2 themes** (`verify:contrast`) | **PASS** |
| **20 mutations, every one caught** (`verify:mutation`) | **PASS** |
| **Unit tests** — 2,121 | **PASS** |
| **End-to-end journey, failure injection, database audit, Phase 9 gate** | **PASS** |

### NOT verified — run these first

| Check | How to run |
|---|---|
| **Full type checking of `.tsx` files** (the offline shim check covers props, not intrinsic DOM attributes) | `npm run typecheck` |
| **Lint** | `npm run lint` |
| **Production build** | `npm run build` |
| **Browser behaviour on Chrome, Firefox, WebKit/Safari, Edge, Android and iOS** | `npm run test:e2e` |
| **The Postgres adapter and RLS** (not written; memory adapter only) | — |
| **Visual appearance** (Tailwind was never compiled here) | `npm run dev` and look |
| **Core Web Vitals** | Lighthouse against a production build |

Structure, imports, exports, rendered markup, **types across every `.ts` file**, and
all domain logic — authentication, authorization, tenancy, and the whole AI layer —
are verified.

What is **not** verified is `.tsx`: type-checking JSX needs `@types/react`, which was
not installable offline, and a hand-written stub would report confident nonsense. The
components and pages are covered by *execution* instead — they are server-rendered and
their HTML is audited — but a type error inside a component is the most likely
category of first-build failure. Tailwind was also never compiled here, so visual
appearance is unverified by construction.

Phase 7's answer to that was to grow the harness rather than hope: twenty render
assertions over the new components and three composite screens in the page audit.
**They found three real bugs on their first run** — a heading jump from `h1` to
`h3` on the usage screen, the same on the billing screen, and a structured-data
expectation that should never have applied to a noindex admin page. None of the
three was visible without executing the components, which is the clearest
available measure of what `next build` would still find.

---

## The offline verification harness

`scripts/` contains the tooling that made the above possible. It is kept in the
repository because it is useful in any environment that cannot install dependencies, and
because it documents exactly what was checked.

```bash
npm run sandbox:all
```

| Script | Purpose |
|---|---|
| `sandbox-setup.mjs` | Writes minimal stand-ins for `next/*`, `clsx` and `tailwind-merge` into `node_modules`. Refuses to run if real Next.js is installed. |
| `verify-static.mjs` | Parses every source file with the TypeScript compiler: syntax, import resolution, named exports, RSC boundary, Next.js route conventions. Needs no stand-ins. |
| `render-check.mjs` | Server-renders components and asserts on the HTML. |
| `typecheck.mjs` | A real `tsc` run over every `.ts` file with the project's strict settings. Needs `node_modules/@types/node`, which `sandbox-setup.mjs` links from a global tool if one is present. `.tsx` is excluded — see above. |
| `page-audit.mjs` | Renders all 53 surfaces — public, auth, coming-soon, and the Phase 3, 4 and 5 workspace screens — and audits headings, JSON-LD, accessible names, AEO content presence, that the validation report keeps its four dimensions visibly separate, and that no screen implies the product sends messages, spends money or generates images. |

`tailwind-merge`'s stand-in is **approximate** and exists only so components render. It is
not a substitute for the real package.

---

## Before going live

Items deliberately left for a human decision. None block a build; all are visible on the
site, in the workspace Settings page, or in the code.

### Required before any real deployment

- **`AUTH_SECRET`** — the app refuses to start in production without it rather
  than falling back to a predictable value. `openssl rand -base64 48`.
- **`DATABASE_URL`, plus the migrations** — without it the in-memory adapter is
  used, which loses everything on restart and cannot be shared between
  instances. Production start-up refuses unless `ALLOW_MEMORY_DB=true`.
- **`SMTP_URL`** — until it is set, verification and password-reset links are
  logged instead of sent, so nobody can confirm an address or recover an account
  by email.

### Decisions left to you

1. **Pricing** — all three tiers are `verified: false` in `src/content/pricing.ts`, so no
   price is displayed and none reaches structured data. Set `verified: true` and the real
   `monthlyPrice` to publish. Do not publish an unconfirmed figure.
2. **Legal review** — `src/content/legal.ts` has `requiresLegalReview = true`, which
   renders a visible notice on `/privacy` and `/terms`. The text describes what the site
   actually does; it still needs counsel. Set the flag to `false` afterwards.
3. **Organization facts** — `src/content/site.ts` omits telephone, postal address,
   founding year and social profiles because they were not verified. Add them and they
   flow into Organization structured data automatically. The contact email
   (`seshaaimarketing@gmail.com`) is a placeholder if it is not yet live.
4. **`NEXT_PUBLIC_SITE_URL`** — must be the real canonical origin in production, with no
   trailing slash. Canonicals, Open Graph URLs, the sitemap and robots all derive from it.
5. **Content security policy** — currently permits inline scripts, which Next's hydration
   bootstrap and the no-flash theme script require. Tightening to per-request nonces is
   still outstanding; it needs middleware-generated nonces threaded through the
   layout, and it has not been done.
6. **Crawler limits for your deployment** — the built-in caps are deliberately
   polite (50 pages, depth 3, two concurrent requests, a 500 ms per-host delay).
   `CRAWLER_MAX_PAGES` lowers the absolute cap and
   `CRAWLER_EXTRA_BLOCKED_HOSTS` adds hostnames your network must never be asked
   to reach — for example an internal domain that resolves publicly. Neither can
   widen the policy.
7. **Crawl data retention** — `deleteExpiredCrawlData` hard-deletes page content
   once its retention period lapses, but nothing calls it on a schedule yet. Wire
   it to a cron or a job runner before you store real customer crawls.

---

## Project status

**Phase 1** — public website, design system, SEO/AEO/structured-data
architecture, API layer, security posture. Complete.

**Phase 2** — authentication (password + Google OAuth), email verification,
password reset, session management, account deletion, four-role authorization,
strict tenant isolation, business onboarding with an AI Marketing Profile,
website crawl consent, projects, a 24-table database with migrations, and the
authenticated dashboard shell. Complete.

**Phase 3** — the AI provider layer (OpenAI, Anthropic, Gemini behind one
interface), the orchestrator with five live agents and eight declared for later
phases, the SeSha AI Copilot, the seven-kind provenance system with an
independent claim linter, a seventeen-section marketing strategy generator,
Content Studio across twenty formats in English, Hindi and Hinglish, social
planning for seven platforms, a content calendar, and cost control (usage and
token tracking, quotas, rate limits, model selection, retry, timeout, response
limits, caching). Complete.

**Phase 4** — the secure website crawler (SSRF and DNS-rebinding defences,
robots compliance, sitemap discovery, a bounded frontier), the crawled-page
store, a fifteen-area SEO audit, a twelve-area AEO audit, the six-part findings
contract with a promise linter, a nine-kind keyword system with no invented
search volume, and background jobs with progress, cancellation and retry.
Complete.

**Phase 5** — a structured-data validator covering JSON-LD, Microdata and RDFa
across 24 schema.org types with six statuses and four separated dimensions;
corrected JSON-LD with visibly fake placeholders; a stored validation history with
comparison over time; generation from verified data only; competitor intelligence
with verified observations kept apart from AI inference; advertising plans for
five platforms; a seven-stage lead pipeline with an auditable score; email and
WhatsApp planning under the official rules; and video scripts with written
thumbnail briefs. Complete.

**Phase 6** — an analytics layer covering the nineteen metrics the brief names,
every figure carrying one of six source labels or marked unavailable with the
specific account that would supply it; a marketing calendar with daily, weekly,
monthly and campaign views across ten activity kinds, and suggestions for empty
stretches drawn only from the customer's own findings and stated channels; a
Trigger → Condition → Action automation engine whose six actions all produce work
for a person and none of which can contact anybody; nine kinds of report, each
answering the same six questions or saying why it cannot; export to PDF (written
without a dependency), CSV and JSON; revocable, expiring share links; and eight
kinds of notification the user controls, with two that cannot be silenced and the
reason shown. Complete.

**Phase 7** — four configurable plans declared as content with no price in them;
eleven limits across two kinds, with the three zero-like states (unlimited, not
included, unused) kept distinguishable everywhere; one quota decision function
whose refusals never tell someone to wait for a reset that cannot help them;
usage tracking for the eight things the brief names, recorded per period and
frozen into the refusal record; a payment-provider abstraction with one null
implementation that refuses everything and verifies no signature; a subscription
state machine expressed as data, in which **read access is never revoked in any
state**; a platform admin panel on a separate staff table with twenty-four
permissions, a sudo requirement on every write, and a 404 for everyone else;
thirteen feature flags with a documented precedence and a stable rollout cohort;
and ten system settings, one of which may only ever be narrowed. Complete.

**Phase 8** — production hardening, no new product features. Twelve findings
fixed, among them two critical crawler defects (no wall-clock timeout; a DNS pin
that had never run), a spoofable rate-limit identity, a consent revocation that
recorded a deletion it never performed, and retention and job recovery that
nothing scheduled. Added: cursor pagination, 0008 indexes and the idempotency
table, retry/timeout/circuit-breaker/idempotency primitives, a redacting
structured logger and metrics, a data export, crawl-history deletion, AI and
crawling disclosures, a scheduled maintenance endpoint, WCAG contrast fixes,
cross-browser Playwright projects, a backup runbook
([docs/OPERATIONS.md](./docs/OPERATIONS.md)) and a sixteen-item quality gate.
Complete.

**Phase 9** — final QA and release preparation. A 24-stage end-to-end journey
test through the real services, a twelve-mode failure-injection suite, a database
audit (every FK indexed — 41 found and fixed in migration 0009 — RLS on every
tenant table), a data-integrity audit (no fabricated figures found), a secret scan
(clean), an AI provider circuit breaker, Docker/Compose/Caddy deployment files,
generated API/database/environment references, and the final readiness report.
Bugs fixed: a stack-overflow DoS and a false "valid" verdict in the public schema
validator, report and content limits that were never consumed, empty "Which
pages?" in reports, an unthrottled session endpoint.

**The product is NOT production ready.** Two critical blockers remain: there is
no PostgreSQL adapter (all data lives in memory), and the real build has never
been run. See [PRODUCTION-READINESS-REPORT.md](./PRODUCTION-READINESS-REPORT.md).

Of the 21 workspace areas in the dashboard, 20 are available — AI Copilot,
Strategy, Content Studio, SEO/AEO, Campaigns, Leads, Analytics, Website Audit,
Schema Validator, Social, Competitors, Calendar, Automations, Reports,
Email & WhatsApp, Video, Brand Kit, Usage, Settings and the workspace home —
alongside projects and the billing screen; 1 renders an explicit "Soon" state
describing what it will do. Nothing is mocked up to look finished.

The platform admin panel is separate from all of that, at `/admin`, and is
invisible — it returns the ordinary not-found page — to anyone without a row in
`platform_staff`.

---

## Provenance

The one design decision in this codebase most worth understanding.

Every AI response is a list of blocks, each tagged with one of seven kinds:

| Kind | Meaning | Presented as fact? |
|---|---|---|
| `user_provided` | You told us this | Yes |
| `connected` | From a connected data source | Yes |
| `retrieved` | From a source we can cite | Yes |
| `ai_estimate` | A figure the model produced with no source | No |
| `ai_inference` | A conclusion the model drew | No |
| `recommendation` | Advice | No |
| `unavailable` | We do not have this | No |

Three independent defences, because a prompt is not a control:

1. **The prompt contract** tells the model the format and forbids inventing
   statistics, market sizes, studies, reviews and testimonials.
2. **The parser rejects an untagged response.** It is discarded, and the user is
   told it was — not shown unlabelled. A `retrieved` or `connected` block that
   names no source is refused too.
3. **The claim linter** independently scans unsourced blocks for
   statistic-shaped assertions — percentages, currency, large counts, ranking
   claims, multipliers, references to studies. An unhedged one is an **error**:
   the response is marked unsafe, the artefact is saved as `in_review`, and
   approval is refused until it is fixed. This runs regardless of what the model
   claimed the block was, so a fabricated figure labelled "recommendation" is
   still caught.

`tests/ai-provenance.test.ts` and `tests/phase3-gate.test.ts` hold the
assertions.

---

## The crawler

The second design decision worth understanding. Phase 4 makes outbound requests
to an address a user supplied, which is the classic shape of a server-side
request forgery. Three specific bypasses are defended against specifically:

1. **A hostname blocklist alone is not a defence**, because the name is resolved
   after the check. `resolver.ts` resolves once and judges **every** A and AAAA
   answer; if any is private the name is refused outright rather than connected
   to on the public answers.
2. **A check followed by `fetch` is defeated by DNS rebinding**, because `fetch`
   resolves the name again and cannot be told which address to use. The crawler
   therefore uses `node:http`/`node:https` with a custom `lookup` that returns
   the **already-checked address**, so the socket cannot perform its own
   resolution.
3. **A string-prefix blocklist is defeated by encoding.** `0xA.0.0.1`,
   `012.0.0.1`, `167772161`, `::ffff:10.0.0.1` and `64:ff9b::10.0.0.1` all reach
   a private address. Ambiguous notations are refused rather than normalised, and
   IPv4-mapped, NAT64 and 6to4 addresses are unwrapped so that both the outer
   and the embedded address are judged. Comparison is byte-level against the
   prefix length, never string matching.

Beyond that: HTTP and HTTPS only, no credentials in URLs, no cookies and no
authorization header, redirect hops capped and each re-validated from scratch,
response size and timeouts bounded, page and depth budgets enforced on dequeue
as well as enqueue, a per-host politeness delay, and robots.txt honoured —
**failing closed**, so a site's 500 or a timeout stops the crawl rather than
becoming permission.

Every configuration path narrows. `CRAWLER_MAX_PAGES` can only lower the cap and
`CRAWLER_EXTRA_BLOCKED_HOSTS` can only add to the blocklist; a value that would
widen the policy is ignored, and `tests/crawler-security.test.ts` proves it.

A crawl requires a recorded consent record, which is checked when the job is
queued **and again when it runs**. Withdrawing consent hard-deletes the stored
page content. Raw HTML is never stored at all — the audits need extracted
fields, not markup.

`tests/crawler-security.test.ts`, `tests/crawler-limits.test.ts` and
`tests/phase4-gate.test.ts` hold the assertions. The policy is also published
inside the product on `/app/website-audit`: a user authorising a crawler is
entitled to read what it does without reading the source.

---

## Billing

**No payment provider is connected, so nothing can be charged.** That is a fact
about configuration, and the code says so everywhere it matters:
`billingStatus().configured` is `false`, checkout refuses with a reason rather
than a crash, and paid plans render "Cannot be bought yet — no payment provider
is connected" instead of a button that fails.

`PaymentProvider` is an interface with one implementation, `nullProvider`, whose
`verifyWebhook` returns `false` **always**. That single line is why the webhook
endpoint cannot be abused today.

What the product will ever store about a card is four fields — brand, last four
digits, expiry month, expiry year — and those are the only four `payment_*`
columns in the schema. There is no field for a number, a token, a CVV or a bank
detail, no provider method that would accept one, and no data-entry control on the
billing screen at all. The limit is structural, not procedural: the dishonest
version is unrepresentable.

Read access is never revoked. Past due, cancelled, paused or incomplete — a
customer can always read and export their own work. A failed payment opens a
seven-day grace window during which writing continues; after it closes, writing
stops and reading does not.

## The admin platform

**An organization admin is not a platform admin.** The `admin` role on a
membership means "can administer *this organization*", and most paying customers
have one. Platform staff is a separate table, `platform_staff`, with its own three
roles and twenty-four permissions. Merging them would have been less code and
would have meant every customer who made themselves an admin could read every
other customer's account.

To anyone without an active staff row, `/admin` and every `/api/admin/*` endpoint
return **404** — the same not-found page a mistyped URL gets. Staff holding the
wrong role also get 404, so probing cannot map the panel. The only other status is
a 403 asking a known staff member to confirm their password, which every write
requires.

The panel reads **metadata, never customer content**: no lead, no article, no
report body, no message. The single exception is feedback, which a customer wrote
in order to be read — and reading it is recorded like everything else, because
every admin action is audited **including every read**. For a panel that can see
across every tenant, looking is the sensitive act.

It also declines to report what it cannot measure. There is no uptime figure, no
latency percentile and no "all systems operational" badge; instead the health
screen carries a list headed **"Not measured"** naming each one and why.

## What SeSha refuses to do

The third design decision worth understanding, and the one that shapes most of
Phase 5. In each case the refusal is structural — a type that cannot hold the
dishonest value, or a column that does not exist — rather than a rule someone has
to remember.

| It will not | Because | Enforced by |
|---|---|---|
| Generate a rating, review, price, availability, award or credential | It would publish invented facts on your own domain, under your name | `NEVER_INVENT_PROPERTIES`; the generator reports each refusal with a reason |
| Fill a gap in corrected markup with a plausible value | A plausible placeholder gets published; a visibly fake one gets replaced | `<add …>` placeholders, and no placeholder at all for the properties above |
| Claim a rich result or an AI citation will appear | Neither is knowable; both are the search engine's decision or unmeasurable | a test scans every explanation the engine can emit |
| State a competitor's revenue, spend, traffic, customers or followers | None of it is visible from a public page | `lintCompetitorFindings` drops the finding, unless the figure is quoted from their own page |
| Record a model's conclusion as an observation | They are different kinds of claim about a third party | `Evidence` is a union; the verified variant cannot be built without a source URL and a time |
| Read a competitor's site without a recorded acknowledgement | They cannot consent, so the authorisation on record must be yours | checked at request time and again immediately before the first fetch |
| Show a performance figure for an ad campaign | No ad account is connected, so there is nothing to measure | `BudgetRecommendation` has no variant that can hold a measurement |
| Show a lead score without its reasoning | An opaque score is an opinion wearing a measurement's clothes | components stored with the score; a database CHECK refuses one without them |
| Plan a campaign to a bought or scraped list | Those people did not ask to hear from you | refused before validation, not stored, and the database CHECK cannot hold the value |
| Send an email or a WhatsApp message | No provider is connected, and only official APIs ever will be | no send path exists; no `sent_at` column exists |
| Produce an image | No image-generation API is connected | `ThumbnailConcept` has no image field; `video_scripts` has no image column |
| Show a traffic, impression, click, follower or spend figure | Nothing is connected that could measure one | `MetricValue` has no variant carrying a bare number; no column in `db/schema.sql` could hold one; no function in `analytics` or `reports` is named like an estimator |
| Show 0% conversion when nothing has closed | "0%" says you convert nobody, which is a different claim from nothing having closed | `conversionMetric` returns `unavailable` with that sentence as the reason |
| Show 0% content coverage when no keywords are tracked | It would claim your content covers nothing | `contentCoverageMetric` returns `unavailable` |
| Leave a report section silently empty | An unexplained gap reads as "nothing to report", which is a claim | `ReportSection.emptyReason` is required whenever there are no points |
| Recommend moving a budget | There is no spend data, and a budget recommendation without it is a guess | the section says so and names what is missing instead |
| Let an automation contact anyone | It cannot send, post or spend, so no rule may either | `isOutboundAction()` is false for all six actions; a database `IMMUTABLE` function enforces the same list |
| Put a suggestion on the calendar | A suggestion shown as an entry becomes something the user believes they planned | `Suggestion` is a separate type with no id and no status; nothing writes one |
| Keep a share link alive forever, or say why one failed | A permanent link outlives whoever made it; a specific error tells a stranger the link was real | `expires_at NOT NULL`, ninety days maximum, one message for every failure |
| Let a user silence a security or billing notice | It would help an attacker stay hidden, or turn a failed payment into a surprise cancellation | `shouldNotify()` ignores the preference; a database CHECK refuses the row; the reason is shown, not hidden |

`tests/phase5-gate.test.ts` and `tests/phase6-gate.test.ts` hold these as
executable assertions.
