# Documentation index

`ARCHITECTURE.md` is the design record: §n refers to its numbered sections. The generated references (API, database, environment) are rebuilt with `node scripts/build-docs.mjs`, and a test fails if they go stale.

| Topic | Where |
|---|---|
| Overview, setup, scripts, status | [../README.md](../README.md) |
| Product notes and the full verification record | [PRODUCT-NOTES.md](PRODUCT-NOTES.md) |
| Architecture | [../ARCHITECTURE.md](../ARCHITECTURE.md) §1–5, §10, §32 |
| Database | [DATABASE.md](DATABASE.md) (generated), ARCHITECTURE §19, §60, §66, §73 |
| API | [API.md](API.md) (generated), ARCHITECTURE §4, §10 |
| Authentication | ARCHITECTURE §14, §21; SECURITY-AUDIT §1 |
| Authorization and tenancy | ARCHITECTURE §15, §18, §82 |
| AI architecture | ARCHITECTURE §25–27, §31 |
| AI providers | ARCHITECTURE §24. OpenAI, Anthropic and Gemini sit behind `AIProvider`, which has a circuit breaker per provider (Phase 9) |
| SEO | ARCHITECTURE §7, §43 |
| AEO | ARCHITECTURE §8, §43 |
| Schema / structured data | ARCHITECTURE §9, §49–54 |
| Crawler and crawler security | ARCHITECTURE §36–41, §91; SECURITY-AUDIT §2 |
| Advertising integrations | ARCHITECTURE §56. **Planning only: no ad-platform API is connected, and nothing is spent or published** |
| Social integrations | ARCHITECTURE §30. **Planning only: no post is ever published to a platform** |
| Analytics | ARCHITECTURE §64–66. `google_analytics`, `google_search_console`, `google_ads`, `meta_ads`, `meta_pages` and `linkedin_pages` are declared connection types, **none of which can be connected yet**, so those metrics show as unavailable |
| CRM / leads | ARCHITECTURE §57 |
| Automation | ARCHITECTURE §68 |
| Reports | ARCHITECTURE §69–71 |
| Subscriptions and billing | ARCHITECTURE §77–81. No payment provider is connected |
| Admin | ARCHITECTURE §82–86 |
| Going live, step by step | [GOING-LIVE.md](GOING-LIVE.md) |
| GitHub + Netlify deployment | [NETLIFY-GITHUB-DEPLOY.md](NETLIFY-GITHUB-DEPLOY.md) |
| Continuing the work in Claude Code | [CLAUDE-CODE-HANDOFF.md](CLAUDE-CODE-HANDOFF.md) |
| Deployment | [DEPLOYMENT.md](DEPLOYMENT.md) |
| Operations, backups, restore, monitoring | [OPERATIONS.md](OPERATIONS.md) |
| Testing | [TESTING.md](TESTING.md) |
| Security | [../SECURITY-AUDIT.md](../SECURITY-AUDIT.md) |
| Privacy | SECURITY-AUDIT §3, ARCHITECTURE §96, the Privacy Policy (`src/content/legal.ts`) |
| Data integrity | [DATA-INTEGRITY.md](DATA-INTEGRITY.md) |
| Environment variables | [ENVIRONMENT.md](ENVIRONMENT.md) (generated) |
| Troubleshooting | [TROUBLESHOOTING.md](TROUBLESHOOTING.md) |
| Roadmap | [ROADMAP.md](ROADMAP.md) |
| Final report | [../PRODUCTION-READINESS-REPORT.md](../PRODUCTION-READINESS-REPORT.md) |
