# Deployment

> **Status: NOT deployable to production yet.** There is no PostgreSQL adapter. With
> `DATABASE_URL` set, the app refuses to start on purpose. Without it, production refuses to
> start unless `ALLOW_MEMORY_DB=true`, and that mode loses all data on every restart. See
> blocker B1 in `PRODUCTION-READINESS-REPORT.md`. Everything below is the target topology.
> None of it has been executed, because the development environment had no registry access.

## Topology

```
Browser ──HTTPS──> CDN / Caddy (TLS, HTTP/2, gzip/zstd, /_next/static cached forever)
                      │
                      ▼
                 app (Next.js standalone, Node 20, non-root, port 3000) ×N
                      │  ├─ PostgreSQL 16 (managed, PITR)       ← needs the adapter (B1)
                      │  └─ Redis 7 (rate limits, lockout)        ← not used yet (B3)
                      ▼
                 scheduler: POST /api/internal/maintenance every 5 min
```

| Concern | Choice | File |
|---|---|---|
| Frontend + backend | One Next.js app: the pages and the API routes run in the same process | `Dockerfile` (`output: 'standalone'`) |
| PostgreSQL | Managed Postgres 16 with PITR (RDS, Cloud SQL, Neon, Supabase) | `db/migrations/*.sql` |
| Redis | **Not used by the code.** Required before running more than one instance | — |
| Background workers | Crawls, audits and competitor analyses run in-process, started after the response is sent. Recovery and retention run via the scheduler. A dedicated worker process is roadmap item R2 | `docker-compose.yml` `scheduler` |
| Storage | None needed: no user uploads; exports and PDFs are generated per request | — |
| CDN | Any CDN in front of the proxy; `/_next/static/*` is immutable, `/brand` and `/og` get one day with revalidation | `next.config.ts`, `deploy/Caddyfile` |
| HTTPS | Caddy with automatic Let's Encrypt, or the platform's TLS. The app sends HSTS when `NODE_ENV=production` | `deploy/Caddyfile` |
| Domain | Set `NEXT_PUBLIC_SITE_URL` to the canonical origin; CSRF origin checks, canonicals and the sitemap all derive from it | `.env.example` |
| Environment | See `docs/ENVIRONMENT.md` | `.env.example` |
| Migrations | `docker compose --profile ops run --rm migrate`: each file is one transaction | `docker-compose.yml` |
| Backups, restore | PITR plus a daily encrypted `pg_dump`, with a quarterly restore drill | `docs/OPERATIONS.md` |
| Monitoring | `/api/health` (container healthcheck), JSON logs on stdout, `error_events`, and the admin Health screen | `docs/OPERATIONS.md` |
| Logging | Structured JSON, redacted, at `LOG_LEVEL` | `src/lib/observability/log.ts` |

## Release procedure (once B1 is resolved)

1. `rm -rf node_modules && npm ci && npm run verify && npm run test:e2e`. Everything must pass.
2. `docker build -t sesha-ai-marketing:$(git rev-parse --short HEAD) .` The build stage runs typecheck, lint, the tests, the schema check and `next build`.
3. Take a manual backup snapshot.
4. Run the migrations, then deploy the new image. Migrations are forward-only and additive, so the previous image keeps working against the new schema.
5. Smoke-test `/api/health`, sign-in, one crawl and one AI call. Watch `error_events` for 30 minutes.
6. To roll back, redeploy the previous image. Never roll back a migration; write a new one instead.

## Vercel alternative

This also works on Vercel (use the default output instead of `standalone`), using Vercel Cron for the maintenance call and a managed Postgres. The in-process crawl start (`void runJob(...)`) can be cut off when a serverless function freezes. Until R2 lands, the maintenance requeue is what recovers those jobs.
