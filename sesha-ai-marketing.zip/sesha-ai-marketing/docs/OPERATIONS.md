# Operations runbook (Phase 8)

## Scheduled maintenance

Call `POST /api/internal/maintenance` every **5 minutes** with the header `Authorization: Bearer $CRON_SECRET`. The secret must be at least 32 characters. Any request without it gets a 404.

Each run does two things:

- **Job recovery.** Any running job whose worker has gone quiet for longer than `STALE_RUNNING_MS` is either requeued with backoff or, once it has used all of `MAX_ATTEMPTS`, failed.
- **Retention.** Crawled page content that has passed its consent's retention period is hard-deleted.

The two tasks are independent, so if one fails the other still runs. The JSON response reports the outcome of each task.

Example (Vercel Cron, Kubernetes CronJob, or any scheduler):

```
curl -fsS -X POST -H "Authorization: Bearer $CRON_SECRET" https://app.example.com/api/internal/maintenance
```

Once Postgres is attached, also run stage 2 of account deletion daily, using pg_cron or the same scheduler (`anonymize_deleted_user`, migration 0002):

```sql
SELECT anonymize_deleted_user(id) FROM users
 WHERE deleted_at < now() - interval '30 days' AND email NOT LIKE 'deleted-%@invalid';
```

## Backup strategy

| What | How | Frequency | Retention |
|---|---|---|---|
| Point-in-time recovery | Managed Postgres PITR (WAL archiving) | continuous | 7 days |
| Logical backup | `pg_dump --format=custom --no-owner "$DATABASE_URL" > sesha-$(date +%F).dump`, encrypted (`age`/KMS) and stored in a separate account or region | daily | 30 daily + 12 monthly |
| Schema | `db/migrations/*.sql` in git | every change | forever |

Rules:

1. **Backups are encrypted and stored outside the production account.** A backup is a complete copy of every tenant's data.
2. **Restore drill every quarter.** Restore into a scratch database, apply any pending migrations, run `node scripts/build-schema.mjs --check`, and compare row counts. A backup that has never been restored is not a backup.
3. **Deletion and backups.** Deleted data stays in backups until they age out, which is at most 12 months for the monthly backups. The privacy policy retention section must state this before launch.
4. **RPO/RTO targets:** RPO ≤ 5 minutes (PITR); RTO ≤ 4 hours.

## Monitoring

| Signal | Source |
|---|---|
| Structured logs (JSON, redacted) | `lib/observability/log.ts` → stdout |
| API latency and error counters | `lib/observability/metrics.ts` |
| Error events | `error_events` table, shown on the admin Errors screen |
| Security events | `audit_log` and `admin_actions` (sign-in failures, lockouts, exports, admin reads) |
| AI usage | `usage_records`, `quota_refusals`, and the admin Usage screen |
| Background jobs | the maintenance response (`requeued`, `abandoned`); jobs with a high `recovered_count` |

The following are never logged: passwords, API keys, tokens, or export contents (counts only).

## Required production environment

`AUTH_SECRET` (≥32), `CRON_SECRET` (≥32), `DATABASE_URL`, `NEXT_PUBLIC_SITE_URL`, and `TRUSTED_PROXY_COUNT` (the number of proxies in front of the app). See `.env.example`.
