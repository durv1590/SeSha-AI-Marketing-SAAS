# Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `DATABASE_URL is set, but the PostgreSQL adapter is not implemented yet` | Blocker B1 | Unset `DATABASE_URL` for development, or implement the adapter |
| `No DATABASE_URL in production` | Production refuses the in-memory DB | Throwaway demo only: set `ALLOW_MEMORY_DB=true`. Data is lost on restart |
| `AUTH_SECRET is missing or shorter than 32 bytes` | Production secret not set | `openssl rand -base64 48` |
| Every request from every user is rate-limited together | `TRUSTED_PROXY_COUNT` is too high, or the proxy doesn't set `X-Forwarded-For`, so all clients share the `unknown-client` bucket | Set it to the real number of proxies |
| One user can bypass rate limits | `TRUSTED_PROXY_COUNT` is too low: the client-supplied header is trusted | Same |
| 403 "Please sign in again" on export, account deletion or admin writes | The sudo window has expired | Sign in again |
| Admin panel shows the 404 page | No `platform_staff` row for the user (by design) | Insert the row by hand; see README |
| Crawl fails with "robots.txt could not be read" | The site is unreachable, or robots.txt returned 5xx | Check the site. The error text also covers connection refusal (known wording gap) |
| Crawl stuck on "running" | The worker died | Wait for maintenance, which requeues the job; check the scheduler is calling `/api/internal/maintenance` |
| AI requests fail instantly with "temporarily unavailable" | The provider circuit breaker is open after 5 outage-class failures | It probes again after 30 s. Check the provider's status and the API key |
| Verification or reset emails never arrive | No email provider is implemented (blocker B4). With `SMTP_URL` unset, the send is logged without the link (set `EMAIL_DEBUG=true` in development to see it). With it set, the send throws | Implement `deliver()` in `src/lib/email.ts` |
| `/api/internal/maintenance` returns 404 | `CRON_SECRET` is missing or shorter than 32 chars, or the bearer header is wrong | Set it, and send `Authorization: Bearer …` |
| `npm install` then build failures in `next/*` | The offline harness stubs are still in `node_modules` | `rm -rf node_modules && npm install` |
| Stale `docs/API.md` | Routes changed | `node scripts/build-docs.mjs` |
