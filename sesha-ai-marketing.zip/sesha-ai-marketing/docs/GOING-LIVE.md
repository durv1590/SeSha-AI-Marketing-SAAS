# How to take SeSha live — step by step

There are two different things people mean by "live", and the steps are different.

- **Path A — a public demo, today.** The site is on a real domain, anyone can visit, sign up and click around. **Data is erased on every restart or redeploy.** Fine for showing investors, testing on real devices and getting feedback. Not fine for real customers.
- **Path B — a real launch.** Real accounts, real data kept safely. Needs the five blockers fixed first (B1–B5 in `PRODUCTION-READINESS-REPORT.md`). Expect roughly 2–4 weeks of developer work.

Do Path A first even if you want Path B. It is how you discover build errors early.

---

## Path A — public demo (about half a day)

### Step 1. Get the code onto a computer with internet
Unzip `sesha-ai-marketing.zip`. Install Node.js 20 or newer (nodejs.org). Then:

```bash
cd sesha-ai-marketing
rm -rf node_modules        # important: the offline placeholders must go
npm install
```

### Step 2. Prove it builds (this has never been done)
```bash
npm run verify          # types, lint, 2,121 tests, production build
```

This is the moment of truth. If it fails, the errors will be small and mechanical (a missing React type, a lint rule). Fix them, or send me the output and I will fix them. **Do not continue until this passes.**

### Step 3. Try it on your own machine
```bash
npm run dev
```
Open http://localhost:3000, sign up, click through the app. If you want to see verification links in the terminal instead of email, put `EMAIL_DEBUG=true` in a file named `.env.local`.

### Step 4. Put it on GitHub
Create a private repository and push the code. Never commit a `.env` file — the project already ignores them.

### Step 5. Deploy

**Using GitHub + Netlify?** Everything is pre-configured — follow [NETLIFY-GITHUB-DEPLOY.md](NETLIFY-GITHUB-DEPLOY.md) instead of this step. Note that on Netlify the signed-in part of the app is unreliable until the database adapter exists; the public site is fine.

**Using Vercel:**
1. Sign in at vercel.com with GitHub, click **Add New → Project**, pick the repository.
2. Framework "Next.js" is detected. Before the first deploy, add these environment variables:

| Name | Value |
|---|---|
| `AUTH_SECRET` | run `openssl rand -base64 48` and paste the result |
| `CRON_SECRET` | run it again for a second, different value |
| `NEXT_PUBLIC_SITE_URL` | `https://your-domain.com` (or the vercel.app URL for now) |
| `ALLOW_MEMORY_DB` | `true` — **demo only**, this is what permits the memory database |
| `TRUSTED_PROXY_COUNT` | `1` |
| `OPENAI_API_KEY` (or `ANTHROPIC_API_KEY` / `GEMINI_API_KEY`) | your AI key, if you want the AI features to work |

3. Click **Deploy**. You get a live `*.vercel.app` URL in a couple of minutes.

### Step 6. Point your domain at it
In Vercel: **Project → Settings → Domains → Add**, type your domain. Vercel shows the DNS records to create. At your registrar (GoDaddy, Namecheap, Cloudflare, BigRock…), add them:
- apex domain `seshaaimarketing.com` → an **A** record to the IP Vercel shows;
- `www` → a **CNAME** to `cname.vercel-dns.com`.

DNS takes 5 minutes to a few hours. HTTPS is issued automatically. Then set `NEXT_PUBLIC_SITE_URL` to the real domain and redeploy — sitemap, canonical URLs and the CSRF origin check all read it.

### Step 7. Schedule the maintenance job
Add a `vercel.json` with:

```json
{ "crons": [{ "path": "/api/internal/maintenance", "schedule": "*/5 * * * *" }] }
```

Vercel Cron cannot send the bearer header, so either allow Vercel's cron header in that route, or run the curl from any scheduler (cron-job.org, a VPS crontab, GitHub Actions):

```bash
curl -fsS -X POST -H "Authorization: Bearer $CRON_SECRET" https://your-domain.com/api/internal/maintenance
```

### Step 8. Say what it is
On a demo, put a line on the home page or a banner: **"Demo — data is reset regularly."** People who sign up must not be surprised when their work disappears.

### What does not work on the demo
- Everything resets on each deploy or idle restart.
- No verification or password-reset emails (B4).
- No payments.
- No Google Analytics, Search Console, Ads, Meta or LinkedIn data — those screens honestly say "not connected".

---

## Path B — real launch

### Step 1. Fix B1: the database adapter (the big one)
Nothing else matters until this is done. A developer implements `PostgresDatabase` against the `Database` interface in `src/lib/db/repositories.ts`, using the `pg` driver with parameterised queries, and sets `SET LOCAL app.current_organization` inside each request's transaction so row-level security applies. Then run the whole test suite against a real database. Budget 1.5–3 engineer-weeks. `docs/DATABASE.md` and `db/schema.sql` are the reference.

### Step 2. Provision Postgres 16 and run the migrations
Use a managed database with point-in-time recovery: Neon, Supabase, AWS RDS, Google Cloud SQL or DigitalOcean. Then:

```bash
for f in db/migrations/*.sql; do psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$f"; done
```

Each file is one transaction and they must run in order 0001 → 0009.

### Step 3. Fix B4: email
Implement `deliver()` in `src/lib/email.ts` with your provider (Amazon SES, Resend, Postmark, SendGrid or plain SMTP), set `SMTP_URL`, then test: sign up, receive the verification email, reset a password.

### Step 4. Fix B3: shared rate limiting
Add Redis (Upstash is simple) and move the rate limiter, lockout and idempotency store to it. Until this is done, **run exactly one instance** of the app — otherwise the login lockout can be bypassed.

### Step 5. Fix B5: legal and company facts
Have a lawyer review the Privacy Policy and Terms in `src/content/legal.ts`, remove the "Pending legal review" notice, and confirm your legal entity name, support inbox, the AI providers you actually use, and prices if you are charging.

### Step 6. Choose how to host
- **Simplest:** Vercel (as in Path A) plus managed Postgres. Remove `ALLOW_MEMORY_DB` and set `DATABASE_URL`.
- **Full control:** a VPS (Hetzner, DigitalOcean, AWS) with the included Docker setup:

```bash
docker build -t sesha-ai-marketing .
docker compose --profile ops run --rm migrate    # migrations
docker compose up -d                             # app + Caddy (HTTPS) + Postgres + scheduler
```

Put your domain in `deploy/Caddyfile` and your settings in `.env.production`. All of `docs/DEPLOYMENT.md` applies.

### Step 7. Environment variables for production
`AUTH_SECRET`, `CRON_SECRET`, `DATABASE_URL`, `NEXT_PUBLIC_SITE_URL`, `TRUSTED_PROXY_COUNT`, `SMTP_URL`, and at least one AI key. Full list with explanations: `docs/ENVIRONMENT.md`. Keep them in the host's secret store, never in the repository.

### Step 8. Turn on backups before the first customer
Enable point-in-time recovery on the database, plus a daily encrypted `pg_dump` stored in a different account or region. **Restore one backup into a scratch database and check it works** — a backup nobody has restored is not a backup. The procedure and the RPO/RTO targets are in `docs/OPERATIONS.md`.

### Step 9. Make yourself platform staff
There is no bootstrap screen, on purpose. After your account exists, insert one row by hand:

```sql
INSERT INTO platform_staff (user_id, role, granted_by)
VALUES ('<your user id>', 'platform_owner', '<your user id>');
```

Then `/admin` opens for you. It shows the ordinary 404 page to everyone else.

### Step 10. Monitoring and the go-live check
Point uptime monitoring at `/api/health`. Ship the JSON logs somewhere you can search them. Then walk the product yourself on the live domain: sign up → verify by email → onboard a business → connect and crawl a website → run an SEO and AEO audit → generate content with AI → create a report → check the admin Health and Errors screens. Watch the error log for the first day.

### Step 11. Announce
Submit the sitemap (`https://your-domain.com/sitemap.xml`) in Google Search Console, check the home page renders correctly when shared on WhatsApp and LinkedIn, and only then send people to it.

---

## Shortest possible answer

1. `npm install && npm run verify` on a machine with internet — fix anything it reports.
2. Push to GitHub, import into Vercel, set the environment variables, deploy.
3. Add your domain's DNS records.
4. For a **demo**, set `ALLOW_MEMORY_DB=true` and label it a demo.
5. For a **real launch**, first do the database adapter, email, Redis and the legal review, then set `DATABASE_URL`, run the migrations and turn on backups.
