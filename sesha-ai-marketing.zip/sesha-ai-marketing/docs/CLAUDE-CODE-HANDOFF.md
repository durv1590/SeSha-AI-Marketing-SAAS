# Moving this project into Claude Code

Claude Code runs in a terminal on your own computer, inside this repository's folder. Unlike this cloud session, it has internet access, so it can install packages, run the real build, run Playwright and talk to a database. That makes it the right place for the remaining work (blockers B1–B5).

Nothing needs to be "converted": this is an ordinary Next.js repository. The transfer is just getting the folder onto your machine and starting Claude Code inside it. `CLAUDE.md` in the project root is already written — Claude Code reads it automatically and follows the project's rules.

## Step 1 — put the code on your computer

Download `sesha-ai-marketing.zip` from this conversation and unzip it, for example to `~/projects/sesha-ai-marketing`.

```bash
cd ~/projects/sesha-ai-marketing
rm -rf node_modules          # the offline stand-ins must not survive
npm install
```

## Step 2 — make it a git repository (recommended before any AI edits)

```bash
git init
git add -A
git commit -m "SeSha phases 1-9, as delivered"
```

With git in place you can always see and undo what changed (`git diff`, `git checkout .`).

## Step 3 — install and start Claude Code

```bash
npm install -g @anthropic-ai/claude-code
cd ~/projects/sesha-ai-marketing
claude
```

Sign in when prompted. Claude Code picks up `CLAUDE.md` automatically, so it starts with the architecture, the commands, the coding rules and the blockers already in hand.

## Step 4 — the first three prompts, in order

Paste these one at a time. The first is the most important: nobody has ever built this project.

**1. The first real build**

```
Read CLAUDE.md and PRODUCTION-READINESS-REPORT.md first.
Then run: npm run verify
It has never been run — the repository was developed without npm access.
Fix every error it reports, smallest possible change, no behaviour changes, no new
dependencies. After each fix re-run the command. When it passes, run
npm run verify:mutation, node scripts/build-schema.mjs --check and
node scripts/build-docs.mjs --check, then show me a summary of what you changed and why.
```

**2. Run it and look at it**

```
Start the dev server and walk the app: sign up, complete onboarding, create a project,
run a crawl against a site I own, generate content. Report anything that looks broken,
ugly at mobile width, or different from what ARCHITECTURE.md describes. Do not fix
anything yet — give me the list first.
```

**3. Blocker B1 — the PostgreSQL adapter**

```
Implement PostgresDatabase against the Database interface in src/lib/db/repositories.ts,
using the pg driver with parameterised queries only. Follow the rules in CLAUDE.md.
Each request runs in a transaction that sets app.current_organization so the RLS policies
in db/migrations apply. Work repository by repository, smallest useful commits, and after
each one run the existing test suite against both the memory adapter and Postgres.
Start by writing the plan and the test harness, and show me the plan before you write the adapter.
```

Then, in whatever order suits you: B4 (email in `src/lib/email.ts`), B3 (Redis-backed rate limiting and lockout), deployment from `docs/GOING-LIVE.md`.

## Step 5 — how to work with it day to day

- **One task per session.** "Fix the build", then "implement the projects repository", not both at once.
- **Ask for a plan first** on anything large: "plan this, don't write code yet".
- **Make it prove things.** "Run `npm test` and show me the output" beats accepting "done".
- **Commit after each green run.** Small commits make a bad change easy to drop.
- **Point at the documents.** "Follow ARCHITECTURE.md §77" or "the rules in CLAUDE.md" keeps the codebase consistent.
- **Keep `CLAUDE.md` current.** When a blocker is fixed or a rule changes, edit it in the same commit.
- **Never paste a real API key into a prompt.** Put it in `.env.local`, which is git-ignored.

## What each tool is for, from here on

| Work | Where |
|---|---|
| Installing packages, real builds, lint, Playwright, database work, running the app | **Claude Code**, on your machine |
| Deploying, DNS, hosting | your host's dashboard, with `docs/GOING-LIVE.md` |
| Planning, reviewing, writing documents, checking work | this Cowork session |

This session can still read the code and answer questions about it, but it cannot install packages or run the real build — that is exactly the gap Claude Code fills.

## If you would rather not use the terminal

Connect this Cowork session to your computer instead: open the Claude desktop app, open this task there and choose **Link to this computer**. I can then write files into a folder you choose and run commands there. Claude Code is still the better tool for a long build-and-fix loop, but linking works if you prefer to stay in the chat.
