# Testing

| Layer | Command | What it proves | Run here? |
|---|---|---|---|
| Unit and service tests | `npm test` | Domain logic, services against the in-memory DB, the phase gates | **Yes, all pass** |
| End-to-end journey | `npx tsx --test tests/journey.test.ts` | Visitor → … → Subscription through the real services, one tenant, with data carried between modules | **Yes** |
| Failure injection | `tests/failure-recovery.test.ts` | Timeout, AI outage and circuit breaker, DB failure, crawl failure, invalid URL and schema, 429, 401/403/404, expired session, network, job failure, partial response | **Yes** |
| Database audit | `tests/database-audit.test.ts` | Every FK indexed, RLS on tenant tables, one transaction per migration, contiguous numbering | **Yes** |
| Types (`.ts`) | `npm run verify:types` | Real `tsc`, strict | **Yes** |
| Types (`.tsx`) | `npm run verify:tsx` | Component props against React shims; intrinsic DOM attributes are not checked | **Yes** |
| Structure | `npm run verify:static` | Syntax, imports, exports, RSC boundaries | **Yes** |
| Rendering | `npm run sandbox:render`, `sandbox:audit` | Server-rendered HTML, headings, JSON-LD, accessible names on 59 pages | **Yes** |
| Contrast | `npm run verify:contrast` | WCAG AA for 27 token pairs × 2 themes | **Yes** |
| Mutation | `npm run verify:mutation` | Every listed control has a test that fails when it is broken | **Yes** |
| Generated docs | `node scripts/build-docs.mjs --check` | API, DB and env docs match the code | **Yes** |
| Real typecheck, lint, build | `npm run verify` | Everything the shims can't cover | **No (npm blocked)** |
| Browsers | `npm run test:e2e` | 5 breakpoints plus Firefox, WebKit, Edge, Android, iOS | **No** |
| Lighthouse / Web Vitals | Against `npm run start` | Real performance | **No** |
| PostgreSQL | Apply the migrations to a scratch database | That the SQL runs | **No** |

The full offline run is `npm run sandbox:all`, then `npm run verify:mutation`.
