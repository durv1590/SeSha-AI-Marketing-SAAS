# Deploying with GitHub + Netlify

Everything needed is already in the repository:

| File | What it does |
|---|---|
| `netlify.toml` | Build command, Node 20, the Next.js adapter, the maintenance schedule, and `noindex` on preview deploys |
| `netlify/functions/maintenance.mts` | Scheduled function that calls `/api/internal/maintenance` every 15 minutes |
| `.nvmrc` | Pins Node 20 for Netlify and GitHub Actions |
| `.github/workflows/ci.yml` | Typecheck, lint, 2,121 tests, generated-file checks, mutation tests, production build, **migrations against a real PostgreSQL 16**, and Playwright on Chromium, Firefox and WebKit |
| `.github/dependabot.yml` | Weekly dependency updates, grouped |
| `.github/pull_request_template.md` | The definition of done, as a checklist |
| `.env.example` | Every variable, with placeholders (never real values) |

## Read this first — what Netlify can and cannot host today

Netlify runs the app as **serverless functions**: many short-lived instances, each with its own memory. This project has **no PostgreSQL adapter yet** (blocker B1), so the only database available is in-memory.

- **Works properly on Netlify now:** the whole public marketing site, the free schema validator, the contact and newsletter forms, SEO metadata, sitemap, robots, dark mode, the 404 page.
- **Will misbehave on Netlify until B1 is done:** anything behind sign-in. An account created by one request may not exist for the next one, because a different instance answered it. It is not a configuration mistake you can fix in the dashboard.

So: use Netlify today to put the **public site** in front of people. For a demo where people sign in and their work survives, either finish B1, or run one always-on instance somewhere like Render, Railway, Fly or a small VPS (see `docs/GOING-LIVE.md`).

## Step 1 — get it onto GitHub

```bash
cd sesha-ai-marketing
rm -rf node_modules          # the offline stand-ins must not be committed
git init
git add -A
git commit -m "SeSha phases 1-9"
git branch -M main
git remote add origin https://github.com/<your-account>/sesha-ai-marketing.git
git push -u origin main
```

Make the repository **private**. `.gitignore` already excludes `.env*`, `node_modules`, `.next` and the deploy password file — check `git status` shows none of them before you push.

The moment you push, GitHub Actions runs the CI workflow. **This is the first real build this project has ever had.** Expect failures on the first run; they are the errors listed as blocker B2. Fix them (Claude Code is good at this — see `docs/CLAUDE-CODE-HANDOFF.md`) until the workflow is green. Do not deploy a red build.

## Step 2 — connect Netlify to the repository

1. Sign in at app.netlify.com with GitHub.
2. **Add new site → Import an existing project → GitHub**, authorise, pick the repository.
3. Netlify reads `netlify.toml`, so the build command (`npm run build`), the publish directory and Node 20 are already correct. Do not override them.
4. Before the first deploy, open **Add environment variables** and add the ones in Step 3.
5. **Deploy site.**

## Step 3 — environment variables (Site configuration → Environment variables)

Generate two different secrets first:

```bash
openssl rand -base64 48    # run once for AUTH_SECRET
openssl rand -base64 48    # run again for CRON_SECRET
```

| Key | Value | Notes |
|---|---|---|
| `AUTH_SECRET` | the first generated string | Required. The app refuses to start in production without it |
| `CRON_SECRET` | the second generated string | At least 32 characters; the scheduled function uses it |
| `NEXT_PUBLIC_SITE_URL` | `https://your-domain.com` | Your real domain once it is attached; the Netlify URL until then. Canonical URLs, the sitemap and the CSRF origin check all read it |
| `ALLOW_MEMORY_DB` | `true` | **Demo only.** It is what lets the app start without a database. Remove it the day `DATABASE_URL` exists |
| `TRUSTED_PROXY_COUNT` | `1` | Netlify's edge is one proxy in front of the app |
| `NODE_VERSION` | `20` | Already set in `netlify.toml`; set it here too if you override the file |
| `OPENAI_API_KEY` *or* `ANTHROPIC_API_KEY` *or* `GEMINI_API_KEY` | your key | Optional. Without one, AI features honestly report "not configured" |
| `EMAIL_DEBUG` | *(leave unset)* | Never set this in production: it would put verification links in the logs |

Set them for **all contexts** (production, deploy previews, branch deploys) unless you want previews to stay AI-less, which is a reasonable way to control cost.

Never put a secret in `netlify.toml` — that file is in git.

## Step 4 — your domain

1. **Domain management → Add a domain**, type `seshaaimarketing.com` (or whichever you own).
2. Netlify shows you what to create at your registrar. Either:
   - point the nameservers at Netlify DNS (simplest), or
   - keep your DNS and add an `A`/`ALIAS` record for the apex plus a `CNAME` for `www` to `<your-site>.netlify.app`.
3. Wait for DNS to propagate (minutes to a few hours). HTTPS is issued automatically; turn on **Force HTTPS**.
4. Update `NEXT_PUBLIC_SITE_URL` to the real domain and redeploy, otherwise canonical tags and the sitemap keep pointing at the Netlify URL.

## Step 5 — check the scheduled function

**Site configuration → Functions → Scheduled functions** should list `maintenance`, running every 15 minutes. Its log line reports the status it got back. It only runs on published production deploys, never on previews.

Until B1 is finished it does nothing useful, because there is no shared database. Leave it wired; it starts working by itself when the adapter lands.

## Step 6 — after the first deploy, check these

- `https://your-domain.com/` loads and looks right on a phone.
- `https://your-domain.com/robots.txt` and `/sitemap.xml` both respond, and the sitemap URLs use your domain.
- `https://your-domain.com/api/health` returns JSON.
- A deploy preview (open a pull request) responds with `X-Robots-Tag: noindex`.
- `https://your-domain.com/admin` shows the ordinary 404 page.
- The browser console is clean, and dark mode follows your system setting.

## Step 7 — how work flows from here

1. Branch, commit, open a pull request.
2. CI runs the whole gate; Netlify builds a deploy preview with its own URL.
3. Review the preview, get CI green, merge.
4. Merging to `main` deploys production automatically. If something is wrong, use **Deploys → Published deploy → Publish this deploy** on the previous build to roll back in seconds.

## When the database adapter (B1) is ready

1. Create a managed Postgres 16 (Neon and Supabase both work well with Netlify).
2. Apply `db/migrations/0001…0009` in order — the CI workflow already proves they apply cleanly.
3. In Netlify, add `DATABASE_URL` and **delete `ALLOW_MEMORY_DB`**.
4. Redeploy, then sign up and sign out and in again to confirm the account survives.
5. Turn on backups before you invite anyone: `docs/OPERATIONS.md`.

## Netlify-specific things worth knowing

- **Rate limiting and login lockout are per-instance** (blocker B3), and serverless means many instances. On Netlify they are weak until they move to Redis or Postgres. Netlify's own rate limiting rules can cover the login endpoints in the meantime.
- **Crawls start in the request process.** A serverless function can be frozen once it responds, so a long crawl may be cut short. The maintenance job requeues those — another reason it matters after B1.
- **Headers** come from `next.config.ts`. Do not add a second copy in `netlify.toml`; two sources for one header is how they drift.
- **Preview deploys are noindex** by configuration, so Google will not index a staging copy of your site.
