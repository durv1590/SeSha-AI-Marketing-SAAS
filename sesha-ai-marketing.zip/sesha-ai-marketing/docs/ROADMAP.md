# Roadmap

## Before launch (blockers: see PRODUCTION-READINESS-REPORT.md)

- **B1** PostgreSQL adapter implementing `Database` (`src/lib/db/repositories.ts`), setting `app.current_organization` per transaction so RLS applies.
- **B2** A real `npm ci && npm run verify && npm run test:e2e && docker build` run, with every failure fixed.
- **B3** A shared store (Redis or Postgres) for the rate limiter, lockout, AI rate limiter and idempotency, before running more than one instance.
- **B4** An email provider inside `deliver()` in `src/lib/email.ts`. None exists: setting `SMTP_URL` throws on purpose, so no verification or reset email can be sent in production.
- **B5** Legal review of the Privacy Policy and Terms, plus confirmation of the company facts.

## After launch

- **R1** Nonce-based CSP, removing `'unsafe-inline'`.
- **R2** A dedicated worker process that claims jobs, instead of starting them in-process.
- **R3** A real payment provider behind the `PaymentProvider` interface.
- **R4** Data connections: OAuth to Google Analytics, Search Console, Google Ads, Meta and LinkedIn. `data_connections` and `MetricValue` are ready; no API client exists.
- **R5** Social publishing: today posts are planned, never sent.
- **R6** Customer templates (the "Soon" screen).
- **R7** Uptime, latency and queue-depth instrumentation (`notMeasured` in the admin panel).
- **R8** Nothing in `src/` uses `withTimeout` or `retry` from `lib/reliability` yet; adopt them for SMTP and future integrations. (The AI provider already has its own timeout and retry, and now a circuit breaker.)
