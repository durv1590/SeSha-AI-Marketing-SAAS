# Data integrity audit

Date: 2026-09-22. Scope: `src/` (content, components, app, lib) and `public/`.
Result: **no fabricated production data found. No source changes were needed.**

## Method

Case-insensitive ripgrep over `src/`, then a manual read of every hit:

- Ratings and reviews: `aggregateRating|reviewCount|ratingValue|testimonial|review`
- Social proof: `[0-9][0-9,]*\+ (businesses|customers|brands|clients|users|...)`, `trusted by`, `#1|leading|award|certified|partner`
- Results claims: `[0-9]+x (growth|traffic|leads|roi|roas)`, `[0-9]+% (increase|growth|lift|...)`, `studies show|according to|survey|[0-9]+%`, `million|thousand|[0-9]{1,3}(,[0-9]{3})+`
- Metric literals: `(visits|sessions|clicks|impressions|leads|revenue|roas|ctr|cpc|volume|rank|position|citations)\s*[:=]\s*[0-9]`, hard-coded chart arrays (`const (data|rows|series|stats|kpis|mock*|sample*|demo*) = [`)
- Estimates: `estimat|benchmark|industry average`, `Math.random|faker`
- Company facts: `telephone|streetAddress|founded|since 20|employees|+91|CIN|GST|@domain`
- Demo markers: `DEMO DATA|SAMPLE DATA|sample|demo|mock|fake|placeholder`

## Results by category

| Category | Result |
|---|---|
| Analytics, traffic, leads, revenue | None found. Metric board shows each figure's source and marks unavailable data "unavailable" (`src/app/(app)/app/analytics/page.tsx`, `src/components/analytics/metric-board.tsx`). |
| ROAS / CTR / CPC | None found. |
| Search volume / rankings | None found. `src/lib/keywords/types.ts` blocks an invented `volume` at the type level. |
| Reviews / ratings / JSON-LD | None found. `aggregateRating`/`review`/`offers` are never emitted (`src/lib/schema/index.ts`, `src/lib/schema/generate.ts`). The corrector refuses to add them even as placeholders (`NEVER_INVENT_PROPERTIES` in `src/lib/schema-validator/registry.ts`). |
| Testimonials, customer logos and counts | None found. |
| AI citations | None found. |
| Case-study results | None found. |
| Company facts (Sesha AI) | No invented facts. Telephone, address, founding year and `sameAs` are deliberately left out (`src/content/site.ts`). |
| Marketing-site stats | None found. "Fourteen modules" matches the 14 entries in `src/content/modules.ts`. The SOC 2 / ISO FAQ correctly says no certification is held. |
| Pricing | All tiers have `verified: false` and `monthlyPrice: null`. The page shows a provisional notice, and `buildOffers()` publishes no price. |

## Left as illustrative (not production data)

- `src/components/marketing/validator-tool.tsx`: "Load an example" JSON-LD inputs for the free validator. They use `example.com` and contain no metrics, so they carry no SAMPLE DATA label.
- `src/lib/schema-validator/registry.ts`: per-property syntax hints (such as `"ratingValue": "4.6"` and `+91-712-000-0000`). These appear only as "for example …" text inside `<add …>` placeholders. Rating properties are never inserted.

## Residual items needing a human decision

1. Confirm that `seshaaimarketing@gmail.com` (`src/content/site.ts`) is a real, monitored inbox. The file calls it verified.
2. Confirm the legal entity name "SeSha AI Marketing". Before adding phone, address, founding year, social profiles or CIN/GST, get the real values from the business.
3. Pricing stays provisional until real prices are entered and `verified: true` is set (`src/content/pricing.ts`).
4. Legal copy is flagged for counsel review (`src/content/legal.ts`).
5. Blog `lastUpdated` dates (2026-09-11) are editorial metadata. Keep them accurate when content changes.
