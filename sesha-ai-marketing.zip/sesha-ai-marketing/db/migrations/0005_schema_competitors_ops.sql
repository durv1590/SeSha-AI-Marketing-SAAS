-- ---------------------------------------------------------------------------
-- Migration 0005 — Phase 5: schema validation history, competitor intelligence,
--                  advertising plans, leads, messaging plans, video scripts
-- ---------------------------------------------------------------------------
-- Forward-only. Do not edit once applied; add a new migration instead.
--
-- Conventions carried forward: uuid keys, timestamptz, organization_id plus
-- row-level security on every tenant-scoped table, ON DELETE on every foreign
-- key, soft delete only where history references the row.
--
-- THREE DECISIONS IN HERE ARE LOAD-BEARING AND ARE NOT STYLISTIC:
--
-- 1. `schema_validations` stores `validator_version`. Without it a history is
--    not comparable: a finding that appears between two runs could be a change
--    in the customer's markup or a change in our rules, with no way to tell
--    which. The column is NOT NULL for that reason.
--
-- 2. `competitor_analyses.acknowledgement_id` is ON DELETE RESTRICT, exactly as
--    `crawls.consent_id` is. A competitor cannot consent to being read, so the
--    authorisation on record is the CUSTOMER'S acknowledgement that they asked
--    for public information about a named third party. That record may not be
--    deleted while analyses performed under it still exist.
--
-- 3. There is no `sent_at`, `scheduled_at` or 'sent' status anywhere on
--    `messaging_plans`, and no `image_url` on `video_scripts`. SeSha cannot
--    send email or WhatsApp and cannot generate images, so the columns that
--    would record having done so do not exist. A nullable `sent_at` is an
--    invitation to write to it from a screen that implies the product sends.
-- ---------------------------------------------------------------------------

BEGIN;

-- ---------------------------------------------------------------------------
-- Usage metrics and job kinds
-- ---------------------------------------------------------------------------

ALTER TABLE usage_records DROP CONSTRAINT IF EXISTS usage_records_metric_check;
ALTER TABLE usage_records ADD CONSTRAINT usage_records_metric_check
    CHECK (metric IN ('ai_generation','ai_tokens','content_item','crawl_page',
                      'crawl_run','audit_run','report','automation_run','seat',
                      'schema_validation','competitor_analysis','lead'));

ALTER TABLE jobs DROP CONSTRAINT IF EXISTS jobs_kind_check;
ALTER TABLE jobs ADD CONSTRAINT jobs_kind_check
    CHECK (kind IN ('crawl','seo_audit','aeo_audit','schema_validation','competitor_analysis'));

-- ---------------------------------------------------------------------------
-- Schema validation history
-- ---------------------------------------------------------------------------
-- One row per validation run. The whole result is kept as jsonb rather than
-- normalised into an issues table: an issue has no life of its own, is never
-- queried independently of its run, and normalising it would mean a schema
-- migration every time a check is added.

CREATE TABLE IF NOT EXISTS schema_validations (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    source_kind       text NOT NULL CHECK (source_kind IN ('pasted','page_url','website_url')),
    -- NULL for pasted markup, which has no URL.
    source_url        text,
    -- The page's canonical URL, when the run knew it. NULL means the canonical
    -- check was reported NOT_EVALUATED rather than passed.
    canonical_url     text,

    -- Which of the three syntaxes were found. Empty when nothing was found,
    -- which is a real and different outcome from "valid".
    syntaxes          jsonb NOT NULL DEFAULT '[]'::jsonb,
    validator_version text NOT NULL,

    overall_status    text NOT NULL
                          CHECK (overall_status IN ('VALID','INVALID','WARNING',
                                                    'RECOMMENDATION','NOT_EVALUATED','UNSUPPORTED')),
    -- Counts per status, so a history list renders without reading every issue.
    counts            jsonb NOT NULL DEFAULT '{}'::jsonb,
    types_found       jsonb NOT NULL DEFAULT '[]'::jsonb,
    entities          jsonb NOT NULL DEFAULT '[]'::jsonb,
    issues            jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- Limits of how the document was obtained. NOT findings about the markup.
    limitations       jsonb NOT NULL DEFAULT '[]'::jsonb,

    checked_at        timestamptz NOT NULL,
    created_at        timestamptz NOT NULL DEFAULT now(),

    -- A pasted document has no URL; a URL run must have one.
    CONSTRAINT schema_validations_url_matches_kind CHECK (
        (source_kind = 'pasted') = (source_url IS NULL)
    )
);

CREATE INDEX IF NOT EXISTS schema_validations_project_idx
    ON schema_validations (project_id, checked_at DESC);
CREATE INDEX IF NOT EXISTS schema_validations_org_idx ON schema_validations (organization_id);
-- The comparison-over-time query: the previous run for the same URL.
CREATE INDEX IF NOT EXISTS schema_validations_source_idx
    ON schema_validations (project_id, source_url, checked_at DESC);

-- ---------------------------------------------------------------------------
-- Competitors
-- ---------------------------------------------------------------------------
-- Soft-deleted, because analyses reference them and a deleted competitor's past
-- analyses are still part of the customer's own record.

CREATE TABLE IF NOT EXISTS competitors (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    name              text NOT NULL CHECK (length(trim(name)) > 0),
    website_url       text,
    source            text NOT NULL DEFAULT 'user_added'
                          CHECK (source IN ('onboarding','user_added')),
    notes             text NOT NULL DEFAULT '',

    deleted_at        timestamptz,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT competitors_unique_per_project UNIQUE (project_id, name)
);

CREATE INDEX IF NOT EXISTS competitors_project_idx ON competitors (project_id, name);
CREATE INDEX IF NOT EXISTS competitors_org_idx ON competitors (organization_id);

-- ---------------------------------------------------------------------------
-- Competitor research acknowledgements
-- ---------------------------------------------------------------------------
-- THE AUTHORISATION RECORD, and the reason this is a separate table rather than
-- a boolean on `competitors`.
--
-- A competitor cannot give consent. What can be recorded is that a named person
-- at the customer asked for publicly available pages to be read, having been
-- shown exactly what that means. That is a dated, versioned, attributable act —
-- the same shape as `website_crawl_consents` — and a boolean column cannot
-- express it.

CREATE TABLE IF NOT EXISTS competitor_acknowledgements (
    id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id    uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id         uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    competitor_id      uuid NOT NULL REFERENCES competitors(id) ON DELETE CASCADE,
    acknowledged_by    uuid REFERENCES users(id) ON DELETE SET NULL,

    acknowledged_at    timestamptz NOT NULL DEFAULT now(),
    revoked_at         timestamptz,
    -- The version of the wording that was shown and accepted.
    statement_version  text NOT NULL,
    -- The maximum pages the acknowledgement covers, recorded as applied.
    max_pages          integer NOT NULL CHECK (max_pages > 0 AND max_pages <= 3),

    created_at         timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS competitor_ack_competitor_idx
    ON competitor_acknowledgements (competitor_id, acknowledged_at DESC);
CREATE INDEX IF NOT EXISTS competitor_ack_org_idx ON competitor_acknowledgements (organization_id);
-- At most one live acknowledgement per competitor.
CREATE UNIQUE INDEX IF NOT EXISTS competitor_ack_one_live
    ON competitor_acknowledgements (competitor_id) WHERE revoked_at IS NULL;

-- ---------------------------------------------------------------------------
-- Competitor analyses
-- ---------------------------------------------------------------------------
-- Findings are stored; PAGE CONTENT IS NOT. There is deliberately no column for
-- the third party's page text. The analysis needs the findings, and keeping a
-- copy of someone else's website is a liability with no matching benefit.

CREATE TABLE IF NOT EXISTS competitor_analyses (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id     uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id          uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    competitor_id       uuid NOT NULL REFERENCES competitors(id) ON DELETE CASCADE,
    -- RESTRICT: the acknowledgement is the authorisation for this analysis.
    acknowledgement_id  uuid REFERENCES competitor_acknowledgements(id) ON DELETE RESTRICT,
    job_id              uuid REFERENCES jobs(id) ON DELETE SET NULL,
    created_by          uuid REFERENCES users(id) ON DELETE SET NULL,

    analysed_at         timestamptz NOT NULL,
    findings            jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- URL and time per page, so every verified finding is auditable.
    pages_read          jsonb NOT NULL DEFAULT '[]'::jsonb,
    limitations         jsonb NOT NULL DEFAULT '[]'::jsonb,
    not_covered         jsonb NOT NULL DEFAULT '[]'::jsonb,

    -- Split counts, because the verified/inferred ratio is the first thing a
    -- reader needs and it must not require parsing the findings array.
    verified_count      integer NOT NULL DEFAULT 0 CHECK (verified_count >= 0),
    inferred_count      integer NOT NULL DEFAULT 0 CHECK (inferred_count >= 0),

    created_at          timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS competitor_analyses_competitor_idx
    ON competitor_analyses (competitor_id, analysed_at DESC);
CREATE INDEX IF NOT EXISTS competitor_analyses_project_idx
    ON competitor_analyses (project_id, analysed_at DESC);
CREATE INDEX IF NOT EXISTS competitor_analyses_org_idx ON competitor_analyses (organization_id);

-- ---------------------------------------------------------------------------
-- Advertising plans
-- ---------------------------------------------------------------------------
-- A plan, not a campaign. There is no `platform_campaign_id`, no `spend` and no
-- `status` beyond the review state: no ad account is connected, so a column
-- recording what a campaign did would never be written truthfully.

CREATE TABLE IF NOT EXISTS ad_plans (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    platform          text NOT NULL
                          CHECK (platform IN ('google_ads','meta','instagram','linkedin','youtube')),
    objective         text NOT NULL,
    campaign_name     text NOT NULL CHECK (length(trim(campaign_name)) > 0),

    -- The whole plan: audience, headlines, descriptions, creative concepts,
    -- landing page, A/B ideas and the budget recommendation with its basis.
    plan              jsonb NOT NULL DEFAULT '{}'::jsonb,
    -- Problems found by the validator at save time, kept so a reviewer sees
    -- what was known when it was approved.
    problems          jsonb NOT NULL DEFAULT '[]'::jsonb,

    review_state      text NOT NULL DEFAULT 'draft'
                          CHECK (review_state IN ('draft','in_review','approved')),

    deleted_at        timestamptz,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ad_plans_project_idx ON ad_plans (project_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ad_plans_org_idx ON ad_plans (organization_id);

-- ---------------------------------------------------------------------------
-- Leads
-- ---------------------------------------------------------------------------
-- A `leads` table already exists, created in migration 0001 as part of the
-- Phase 1 architecture and never written to by any repository: it had an
-- organization but no project, a required email, a five-value `status`, and no
-- score. Phase 5 is where leads are actually implemented.
--
-- THIS IS ALTERED IN PLACE RATHER THAN REPLACED. Migrations are forward-only, and
-- a second table called `leads_v2` would mean every future reader of this schema
-- having to work out which one is real. Three of the changes below are worth
-- reading:
--
--  · `email` becomes NULLABLE. In this market a great many enquiries arrive by
--    phone or WhatsApp with no email address at all, and a NOT NULL email would
--    force whoever takes the call to invent one.
--  · `status` becomes `stage`, with the seven values the brief names. The old
--    name said nothing about a pipeline; `proposal` and `negotiation` did not
--    exist, so a real sales process could not be recorded.
--  · the score arrives WITH its components and basis, never as a bare number.

ALTER TABLE leads ADD COLUMN IF NOT EXISTS project_id uuid REFERENCES projects(id) ON DELETE CASCADE;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS phone text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS company text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS enquiry text NOT NULL DEFAULT '';
ALTER TABLE leads ADD COLUMN IF NOT EXISTS score integer NOT NULL DEFAULT 0;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS score_components jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS score_basis text NOT NULL DEFAULT '';
ALTER TABLE leads ADD COLUMN IF NOT EXISTS scored_at timestamptz;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS opt_in_basis text NOT NULL DEFAULT 'none';
ALTER TABLE leads ADD COLUMN IF NOT EXISTS lost_reason text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS last_activity_at timestamptz;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

-- A phone-only lead is a real lead.
ALTER TABLE leads ALTER COLUMN email DROP NOT NULL;

-- `name` is required from here: a lead nobody can address is not workable.
UPDATE leads SET name = 'Unnamed enquiry' WHERE name IS NULL OR trim(name) = '';
ALTER TABLE leads ALTER COLUMN name SET NOT NULL;

-- status -> stage, with the seven stages the brief names.
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'leads' AND column_name = 'status'
    ) AND NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'leads' AND column_name = 'stage'
    ) THEN
        ALTER TABLE leads RENAME COLUMN status TO stage;
    END IF;
END
$$;

ALTER TABLE leads ADD COLUMN IF NOT EXISTS stage text NOT NULL DEFAULT 'new';
ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_status_check;
ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_stage_check;
ALTER TABLE leads ADD CONSTRAINT leads_stage_check
    CHECK (stage IN ('new','contacted','qualified','proposal','negotiation','won','lost'));

ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_source_check;
-- `source_path` and `source_campaign` from Phase 1 are kept: they are real
-- attribution captured at creation, and `source` answers a different question.
ALTER TABLE leads ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'unknown';
ALTER TABLE leads ADD CONSTRAINT leads_source_check
    CHECK (source IN ('website_form','landing_page','phone','whatsapp','email',
                      'referral','walk_in','social','paid_ad','marketplace',
                      'event','imported','manual','unknown'));

ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_opt_in_basis_check;
ALTER TABLE leads ADD CONSTRAINT leads_opt_in_basis_check
    CHECK (opt_in_basis IN ('explicit_opt_in','existing_customer','enquiry_reply',
                            'contract_necessity','purchased_list','scraped','none'));

ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_score_range;
ALTER TABLE leads ADD CONSTRAINT leads_score_range CHECK (score >= 0 AND score <= 100);

-- A lost lead must say why. "Lost" with no reason teaches nobody anything.
ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_lost_has_reason;
ALTER TABLE leads ADD CONSTRAINT leads_lost_has_reason
    CHECK (stage <> 'lost' OR lost_reason IS NOT NULL);

-- A score must carry its components and basis, or it is the opaque number this
-- schema refuses to store.
ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_score_has_basis;
ALTER TABLE leads ADD CONSTRAINT leads_score_has_basis
    CHECK (score = 0 OR (score_basis <> '' AND jsonb_array_length(score_components) > 0));

-- A lead must belong to a contactable person somehow.
ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_has_contact;
ALTER TABLE leads ADD CONSTRAINT leads_has_contact
    CHECK (email IS NOT NULL OR phone IS NOT NULL OR company IS NOT NULL);

CREATE INDEX IF NOT EXISTS leads_project_stage_idx ON leads (project_id, stage, score DESC);
CREATE INDEX IF NOT EXISTS leads_owner_idx ON leads (owner_user_id, stage);
CREATE INDEX IF NOT EXISTS leads_email_idx ON leads (project_id, lower(email::text));

-- ---------------------------------------------------------------------------
-- Lead activities and follow-ups
-- ---------------------------------------------------------------------------
-- One table for both: a follow-up is an activity with a due date. Two tables
-- would mean the same history assembled from two places, in date order, forever.

CREATE TABLE IF NOT EXISTS lead_activities (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    lead_id           uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    kind              text NOT NULL
                          CHECK (kind IN ('note','call','email_sent','email_received',
                                          'whatsapp_sent','whatsapp_received','meeting',
                                          'quote_sent','stage_change','follow_up')),
    note              text NOT NULL DEFAULT '',

    -- When it happened. For a follow-up this is when it was created.
    occurred_at       timestamptz NOT NULL DEFAULT now(),
    -- Set only on a follow-up.
    due_at            timestamptz,
    completed_at      timestamptz,

    -- For a stage_change, what moved. Kept so the pipeline history is readable
    -- without reconstructing it from timestamps.
    from_stage        text,
    to_stage          text,

    created_at        timestamptz NOT NULL DEFAULT now(),

    -- A due date only makes sense on a follow-up.
    CONSTRAINT lead_activities_due_only_on_follow_up CHECK (
        due_at IS NULL OR kind = 'follow_up'
    ),
    CONSTRAINT lead_activities_stage_change_has_stages CHECK (
        kind <> 'stage_change' OR (from_stage IS NOT NULL AND to_stage IS NOT NULL)
    )
);

CREATE INDEX IF NOT EXISTS lead_activities_lead_idx ON lead_activities (lead_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS lead_activities_org_idx ON lead_activities (organization_id);
-- The "what is due" query.
CREATE INDEX IF NOT EXISTS lead_activities_due_idx
    ON lead_activities (organization_id, due_at) WHERE due_at IS NOT NULL AND completed_at IS NULL;

-- ---------------------------------------------------------------------------
-- Messaging plans (email and WhatsApp)
-- ---------------------------------------------------------------------------
-- NOTE WHAT IS ABSENT: no sent_at, no scheduled_at, no 'sent' or 'scheduled'
-- review state, no recipient list. SeSha cannot send, so there is nothing to
-- record having sent — and a recipient list stored here would be a list this
-- product cannot lawfully act on anyway.

CREATE TABLE IF NOT EXISTS messaging_plans (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    channel           text NOT NULL CHECK (channel IN ('email','whatsapp')),
    kind              text NOT NULL,
    -- WhatsApp only. NULL for email.
    category          text CHECK (category IS NULL OR category IN ('MARKETING','UTILITY','AUTHENTICATION')),

    title             text NOT NULL DEFAULT '',
    plan              jsonb NOT NULL DEFAULT '{}'::jsonb,
    problems          jsonb NOT NULL DEFAULT '[]'::jsonb,

    -- Why the recipients may be messaged. A forbidden basis cannot be stored:
    -- the service refuses the plan, and the CHECK refuses the row.
    opt_in_basis      text NOT NULL
                          CHECK (opt_in_basis IN ('explicit_opt_in','existing_customer',
                                                  'enquiry_reply','contract_necessity')),
    audience_note     text NOT NULL DEFAULT '',

    review_state      text NOT NULL DEFAULT 'draft'
                          CHECK (review_state IN ('draft','in_review','approved')),

    deleted_at        timestamptz,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),

    -- A WhatsApp plan has a category; an email plan does not.
    CONSTRAINT messaging_plans_category_matches_channel CHECK (
        (channel = 'whatsapp') = (category IS NOT NULL)
    )
);

CREATE INDEX IF NOT EXISTS messaging_plans_project_idx
    ON messaging_plans (project_id, channel, created_at DESC);
CREATE INDEX IF NOT EXISTS messaging_plans_org_idx ON messaging_plans (organization_id);

-- ---------------------------------------------------------------------------
-- Video scripts
-- ---------------------------------------------------------------------------
-- No image columns. Thumbnail concepts are written briefs inside `script`; no
-- image-generation API is connected, so there is no asset to point at and no
-- column that could hold a convincing-looking placeholder.

CREATE TABLE IF NOT EXISTS video_scripts (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    platform          text NOT NULL
                          CHECK (platform IN ('youtube_long','youtube_shorts',
                                              'instagram_reels','linkedin_video')),
    topic             text NOT NULL CHECK (length(trim(topic)) > 0),
    total_seconds     integer NOT NULL DEFAULT 0 CHECK (total_seconds >= 0),

    script            jsonb NOT NULL DEFAULT '{}'::jsonb,
    problems          jsonb NOT NULL DEFAULT '[]'::jsonb,

    review_state      text NOT NULL DEFAULT 'draft'
                          CHECK (review_state IN ('draft','in_review','approved')),

    deleted_at        timestamptz,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS video_scripts_project_idx
    ON video_scripts (project_id, created_at DESC);
CREATE INDEX IF NOT EXISTS video_scripts_org_idx ON video_scripts (organization_id);

-- ---------------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------------

ALTER TABLE schema_validations           ENABLE ROW LEVEL SECURITY;
ALTER TABLE competitors                  ENABLE ROW LEVEL SECURITY;
ALTER TABLE competitor_acknowledgements  ENABLE ROW LEVEL SECURITY;
ALTER TABLE competitor_analyses          ENABLE ROW LEVEL SECURITY;
ALTER TABLE ad_plans                     ENABLE ROW LEVEL SECURITY;
ALTER TABLE leads                        ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_activities              ENABLE ROW LEVEL SECURITY;
ALTER TABLE messaging_plans              ENABLE ROW LEVEL SECURITY;
ALTER TABLE video_scripts                ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
    target text;
BEGIN
    FOREACH target IN ARRAY ARRAY['schema_validations','competitors','competitor_acknowledgements',
                                  'competitor_analyses','ad_plans','leads','lead_activities',
                                  'messaging_plans','video_scripts']
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON %I', target || '_tenant_isolation', target);
        EXECUTE format(
            'CREATE POLICY %I ON %I USING (organization_id = current_setting(%L, true)::uuid)',
            target || '_tenant_isolation', target, 'app.current_organization'
        );
    END LOOP;
END
$$;

-- ---------------------------------------------------------------------------
-- updated_at maintenance
-- ---------------------------------------------------------------------------

CREATE TRIGGER competitors_updated_at BEFORE UPDATE ON competitors
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER ad_plans_updated_at BEFORE UPDATE ON ad_plans
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER leads_updated_at BEFORE UPDATE ON leads
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER messaging_plans_updated_at BEFORE UPDATE ON messaging_plans
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER video_scripts_updated_at BEFORE UPDATE ON video_scripts
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

COMMIT;
