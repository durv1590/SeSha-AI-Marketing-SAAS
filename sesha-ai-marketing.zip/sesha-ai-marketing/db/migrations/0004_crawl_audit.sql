-- ---------------------------------------------------------------------------
-- Migration 0004 — Phase 4: crawler, SEO and AEO audits, keywords, jobs
-- ---------------------------------------------------------------------------
-- Forward-only. Do not edit once applied; add a new migration instead.
--
-- Conventions carried forward: uuid keys, timestamptz, organization_id plus
-- row-level security on every tenant-scoped table, ON DELETE on every foreign
-- key, soft delete only where audit history references the row.
--
-- RETENTION IS LOAD-BEARING HERE. Crawled page content is the user's own
-- website text, stored under a consent record that names a retention period.
-- `crawled_pages.expires_at` is set from that period on insert, and the
-- deletion job reads it. A crawl whose consent is revoked has its pages
-- deleted outright rather than soft-deleted: the user asked for the data to be
-- gone, and a soft delete would not honour that.
-- ---------------------------------------------------------------------------

BEGIN;

-- ---------------------------------------------------------------------------
-- Usage: crawled pages already exist as a metric; add audit runs
-- ---------------------------------------------------------------------------

ALTER TABLE usage_records DROP CONSTRAINT IF EXISTS usage_records_metric_check;
ALTER TABLE usage_records ADD CONSTRAINT usage_records_metric_check
    CHECK (metric IN ('ai_generation','ai_tokens','content_item','crawl_page',
                      'crawl_run','audit_run','report','automation_run','seat'));

-- ---------------------------------------------------------------------------
-- Background jobs
-- ---------------------------------------------------------------------------
-- One table for every kind of long-running work, because the lifecycle is
-- identical and a per-feature job table means the same bugs fixed three times.
--
-- The five states are the brief's. `cancel_requested` is separate from the
-- status: a running job is asked to stop and acknowledges by transitioning to
-- cancelled itself, so the worker is never killed mid-write.

CREATE TABLE IF NOT EXISTS jobs (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid REFERENCES projects(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    kind              text NOT NULL CHECK (kind IN ('crawl','seo_audit','aeo_audit')),
    status            text NOT NULL DEFAULT 'queued'
                          CHECK (status IN ('queued','running','completed','failed','cancelled')),

    -- Progress, written as the job runs so a poller can show it.
    progress_done     integer NOT NULL DEFAULT 0 CHECK (progress_done >= 0),
    progress_total    integer CHECK (progress_total IS NULL OR progress_total >= 0),
    progress_message  text NOT NULL DEFAULT '',

    -- A cancellation REQUEST. The worker polls this and stops cleanly.
    cancel_requested  boolean NOT NULL DEFAULT false,

    attempts          integer NOT NULL DEFAULT 0 CHECK (attempts >= 0 AND attempts <= 10),
    failure_code      text,
    failure_detail    text,

    -- Input for the job, and the id of whatever it produced.
    input             jsonb NOT NULL DEFAULT '{}'::jsonb,
    result_id         uuid,

    -- Set when a retry may not run before this time.
    not_before        timestamptz,

    queued_at         timestamptz NOT NULL DEFAULT now(),
    started_at        timestamptz,
    finished_at       timestamptz,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),

    -- A terminal job must have a finish time; a non-terminal one must not.
    CONSTRAINT jobs_finished_when_terminal CHECK (
        (status IN ('completed','failed','cancelled')) = (finished_at IS NOT NULL)
    ),
    -- A failure must say why. An unexplained failure is not actionable.
    CONSTRAINT jobs_failure_has_code CHECK (status <> 'failed' OR failure_code IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS jobs_org_idx ON jobs (organization_id, created_at DESC);
CREATE INDEX IF NOT EXISTS jobs_project_idx ON jobs (project_id, kind, created_at DESC);
-- The worker's claim query: oldest runnable job first.
CREATE INDEX IF NOT EXISTS jobs_runnable_idx
    ON jobs (status, not_before, queued_at) WHERE status = 'queued';
-- At most one active job of a kind per project, enforced in the database rather
-- than only in the service: two concurrent crawls of one site is both a waste
-- and a politeness problem.
CREATE UNIQUE INDEX IF NOT EXISTS jobs_one_active_per_project
    ON jobs (project_id, kind) WHERE status IN ('queued','running');

-- ---------------------------------------------------------------------------
-- Crawls
-- ---------------------------------------------------------------------------
-- One row per crawl run. The consent record that authorised it is referenced,
-- not copied, so revoking consent is traceable to the crawls it covered.

CREATE TABLE IF NOT EXISTS crawls (
    id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id      uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id           uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    job_id               uuid REFERENCES jobs(id) ON DELETE SET NULL,
    -- RESTRICT, not CASCADE: a consent record may not be deleted while crawls
    -- performed under it still exist, because the record is the authorisation.
    consent_id           uuid REFERENCES website_crawl_consents(id) ON DELETE RESTRICT,
    started_by           uuid REFERENCES users(id) ON DELETE SET NULL,

    site_url             text NOT NULL,
    -- What the crawl was permitted and limited to, recorded as applied.
    max_pages            integer NOT NULL CHECK (max_pages > 0 AND max_pages <= 500),
    max_depth            integer NOT NULL CHECK (max_depth >= 0 AND max_depth <= 10),
    respect_robots       boolean NOT NULL,
    crawl_delay_ms       integer NOT NULL CHECK (crawl_delay_ms >= 0),

    pages_crawled        integer NOT NULL DEFAULT 0 CHECK (pages_crawled >= 0),
    pages_failed         integer NOT NULL DEFAULT 0 CHECK (pages_failed >= 0),

    robots_found         boolean NOT NULL DEFAULT false,
    robots_readable      boolean NOT NULL DEFAULT true,
    robots_summary       text NOT NULL DEFAULT '',
    sitemap_found        boolean NOT NULL DEFAULT false,
    sitemap_note         text NOT NULL DEFAULT '',
    sitemap_urls_found   integer NOT NULL DEFAULT 0 CHECK (sitemap_urls_found >= 0),

    failures             jsonb NOT NULL DEFAULT '[]'::jsonb,
    skipped              jsonb NOT NULL DEFAULT '{}'::jsonb,
    stopped_early        text,
    cancelled            boolean NOT NULL DEFAULT false,

    started_at           timestamptz NOT NULL DEFAULT now(),
    finished_at          timestamptz,
    -- When the stored page content must be deleted, from the consent record.
    expires_at           timestamptz NOT NULL,
    created_at           timestamptz NOT NULL DEFAULT now(),
    updated_at           timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS crawls_project_idx ON crawls (project_id, started_at DESC);
CREATE INDEX IF NOT EXISTS crawls_org_idx ON crawls (organization_id, started_at DESC);
-- The retention sweep's query.
CREATE INDEX IF NOT EXISTS crawls_expiry_idx ON crawls (expires_at);
CREATE INDEX IF NOT EXISTS crawls_consent_idx ON crawls (consent_id);

-- ---------------------------------------------------------------------------
-- Crawled pages
-- ---------------------------------------------------------------------------
-- The extracted fields from the brief's "website data" list. The RAW HTML IS
-- NOT STORED: the audit needs the extracted values, and keeping a copy of
-- someone's entire site is a liability with no corresponding benefit.

CREATE TABLE IF NOT EXISTS crawled_pages (
    id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id      uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    crawl_id             uuid NOT NULL REFERENCES crawls(id) ON DELETE CASCADE,

    url                  text NOT NULL,
    status               integer NOT NULL,
    https                boolean NOT NULL,

    title                text,
    meta_description     text,
    h1                   jsonb NOT NULL DEFAULT '[]'::jsonb,
    h2                   jsonb NOT NULL DEFAULT '[]'::jsonb,
    h3                   jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- Extracted text, not markup, and capped by the extractor.
    text_content         text NOT NULL DEFAULT '',
    word_count           integer NOT NULL DEFAULT 0 CHECK (word_count >= 0),

    links                jsonb NOT NULL DEFAULT '[]'::jsonb,
    images               jsonb NOT NULL DEFAULT '[]'::jsonb,
    canonical            text,
    robots_directives    jsonb NOT NULL DEFAULT '{}'::jsonb,
    structured_data      jsonb NOT NULL DEFAULT '[]'::jsonb,
    structured_data_errors jsonb NOT NULL DEFAULT '[]'::jsonb,
    faqs                 jsonb NOT NULL DEFAULT '[]'::jsonb,

    author               text,
    publisher            text,
    published_at_raw     text,
    modified_at_raw      text,
    entity_signals       jsonb NOT NULL DEFAULT '{}'::jsonb,
    open_graph           jsonb NOT NULL DEFAULT '{}'::jsonb,

    lang                 text,
    has_viewport_meta    boolean NOT NULL DEFAULT false,
    has_charset          boolean NOT NULL DEFAULT false,

    bytes                integer NOT NULL DEFAULT 0 CHECK (bytes >= 0),
    response_time_ms     integer NOT NULL DEFAULT 0 CHECK (response_time_ms >= 0),
    truncated            boolean NOT NULL DEFAULT false,

    -- The brief: "Store crawl timestamp." Per page, not per crawl, because
    -- a crawl spans minutes and a page's freshness is its own fetch time.
    crawled_at           timestamptz NOT NULL,
    created_at           timestamptz NOT NULL DEFAULT now(),

    -- One row per URL per crawl.
    CONSTRAINT crawled_pages_unique_per_crawl UNIQUE (crawl_id, url)
);

CREATE INDEX IF NOT EXISTS crawled_pages_crawl_idx ON crawled_pages (crawl_id);
CREATE INDEX IF NOT EXISTS crawled_pages_org_idx ON crawled_pages (organization_id);
CREATE INDEX IF NOT EXISTS crawled_pages_url_idx ON crawled_pages (organization_id, url);

-- ---------------------------------------------------------------------------
-- Audits
-- ---------------------------------------------------------------------------
-- SEO and AEO share a table: the shape is identical and the difference is the
-- `kind` plus which analyser produced the findings. Separating them would
-- duplicate the findings/score/provenance columns for no gain.

CREATE TABLE IF NOT EXISTS audits (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    crawl_id          uuid NOT NULL REFERENCES crawls(id) ON DELETE CASCADE,
    job_id            uuid REFERENCES jobs(id) ON DELETE SET NULL,

    kind              text NOT NULL CHECK (kind IN ('seo','aeo')),
    score             integer NOT NULL CHECK (score >= 0 AND score <= 100),
    -- Always stored with the score, so the number can never be shown without
    -- the explanation that it is our own weighting.
    score_basis       text NOT NULL,

    findings          jsonb NOT NULL DEFAULT '[]'::jsonb,
    stats             jsonb NOT NULL DEFAULT '{}'::jsonb,
    -- What could NOT be assessed. Never empty in practice.
    not_checked       jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- Findings the promise linter refused to publish. A bug signal.
    suppressed        jsonb NOT NULL DEFAULT '[]'::jsonb,

    checked_at        timestamptz NOT NULL DEFAULT now(),
    created_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS audits_project_idx ON audits (project_id, kind, checked_at DESC);
CREATE INDEX IF NOT EXISTS audits_crawl_idx ON audits (crawl_id);
CREATE INDEX IF NOT EXISTS audits_org_idx ON audits (organization_id, checked_at DESC);

-- ---------------------------------------------------------------------------
-- Keywords
-- ---------------------------------------------------------------------------
-- NOTE THE ABSENCE: there is no `search_volume integer` column, and there is
-- no `competition integer`. Those values are unknown to this product, and a
-- nullable number column would invite a future writer to fill it with an
-- estimate that then reads as a measurement. The two jsonb columns hold the
-- discriminated union from lib/keywords/types.ts, which has no variant that
-- carries a bare number without naming its source.

CREATE TABLE IF NOT EXISTS keywords (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    crawl_id          uuid REFERENCES crawls(id) ON DELETE SET NULL,

    query             text NOT NULL,
    kinds             jsonb NOT NULL DEFAULT '[]'::jsonb,
    intent            text NOT NULL CHECK (intent IN ('informational','commercial','transactional','navigational')),

    relevance_score   integer NOT NULL CHECK (relevance_score >= 0 AND relevance_score <= 100),
    relevance_basis   text NOT NULL,
    covering_urls     jsonb NOT NULL DEFAULT '[]'::jsonb,

    -- Discriminated unions, never bare numbers. See the note above.
    volume            jsonb NOT NULL DEFAULT '{"kind":"unavailable","label":"Data unavailable"}'::jsonb,
    competition       jsonb NOT NULL DEFAULT '{"kind":"unavailable","label":"Data unavailable"}'::jsonb,

    priority          text NOT NULL CHECK (priority IN ('high','medium','low')),
    content_format    text NOT NULL,
    entities          jsonb NOT NULL DEFAULT '[]'::jsonb,
    source            text NOT NULL CHECK (source IN ('page_heading','page_title','faq','user_provided','ai_suggested')),

    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT keywords_unique_per_project UNIQUE (project_id, query)
);

CREATE INDEX IF NOT EXISTS keywords_project_idx ON keywords (project_id, priority);
CREATE INDEX IF NOT EXISTS keywords_org_idx ON keywords (organization_id);

-- ---------------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------------

ALTER TABLE jobs          ENABLE ROW LEVEL SECURITY;
ALTER TABLE crawls        ENABLE ROW LEVEL SECURITY;
ALTER TABLE crawled_pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE audits        ENABLE ROW LEVEL SECURITY;
ALTER TABLE keywords      ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
    target text;
BEGIN
    FOREACH target IN ARRAY ARRAY['jobs','crawls','crawled_pages','audits','keywords']
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON %I', target || '_tenant_isolation', target);
        EXECUTE format(
            'CREATE POLICY %I ON %I USING (organization_id = current_setting(%L, true)::uuid)',
            target || '_tenant_isolation', target, 'app.current_organization'
        );
    END LOOP;
END
$$;

-- ---------------------------------------------------------------------------
-- updated_at maintenance
-- ---------------------------------------------------------------------------

CREATE TRIGGER jobs_updated_at BEFORE UPDATE ON jobs
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER crawls_updated_at BEFORE UPDATE ON crawls
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER keywords_updated_at BEFORE UPDATE ON keywords
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

COMMIT;
