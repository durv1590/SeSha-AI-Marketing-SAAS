-- ---------------------------------------------------------------------------
-- Migration 0006 — Phase 6: data connections, marketing calendar, automation,
--                  reports with export and sharing, notification preferences
-- ---------------------------------------------------------------------------
-- Forward-only. Do not edit once applied; add a new migration instead.
--
-- Conventions carried forward: uuid keys, timestamptz, organization_id plus
-- row-level security on every tenant-scoped table, ON DELETE on every foreign
-- key, soft delete only where history references the row.
--
-- FIVE DECISIONS IN HERE ARE LOAD-BEARING AND ARE NOT STYLISTIC:
--
-- 1. THERE IS NO `metrics` TABLE, AND NO COLUMN ANYWHERE HOLDING A TRAFFIC,
--    IMPRESSION, CLICK OR FOLLOWER FIGURE. SeSha has no connected source for
--    any of them. A nullable `sessions integer` would be filled in within a
--    month — by a seed script, a demo fixture, or a well-meaning estimator —
--    and from then on nobody could tell a measured figure from an invented one.
--    `data_connections` records the absence instead; every metric is computed
--    at read time from rows this database genuinely has.
--
-- 2. `calendar_events.status` is planned/done/skipped, with no 'scheduled' and
--    no 'published'. SeSha cannot publish anything (Phase 3) and nothing
--    fires on a calendar date. A status claiming otherwise would be the
--    database asserting a capability the product refuses.
--
-- 3. `automation_runs` records runs that did NOTHING, with the condition that
--    failed. A rule that quietly stops matching is indistinguishable from a
--    rule that never runs, and the difference matters to the person who built
--    it. `matched boolean NOT NULL` plus `skip_reason` is that difference.
--
-- 4. `report_shares` stores only `token_hash`, never the token. If this table
--    leaks, what leaks is not a set of working links. Same reasoning as
--    password storage, and `expires_at` is NOT NULL so no share is permanent.
--
-- 5. `reports.document` is the RENDERED report, stored whole. A shared link
--    sent to a client in March must show what it showed in March, not today's
--    numbers re-run against today's data. Regenerating on read would silently
--    rewrite history.
-- ---------------------------------------------------------------------------

BEGIN;

-- ---------------------------------------------------------------------------
-- Usage metrics and job kinds
-- ---------------------------------------------------------------------------

ALTER TABLE usage_records DROP CONSTRAINT IF EXISTS usage_records_metric_check;
ALTER TABLE usage_records ADD CONSTRAINT usage_records_metric_check
    CHECK (metric IN ('ai_generation','ai_tokens','content_item','crawl_page',
                      'crawl_run','audit_run','report','automation_run','seat',
                      'schema_validation','competitor_analysis','lead',
                      'calendar_event','report_export'));

ALTER TABLE jobs DROP CONSTRAINT IF EXISTS jobs_kind_check;
ALTER TABLE jobs ADD CONSTRAINT jobs_kind_check
    CHECK (kind IN ('crawl','seo_audit','aeo_audit','schema_validation',
                    'competitor_analysis','report_generation','automation_sweep'));

-- ---------------------------------------------------------------------------
-- Rejecting a campaign plan
-- ---------------------------------------------------------------------------
-- Phase 5 gave ad plans draft/in_review/approved, with no way to say no. That
-- omission only became visible in Phase 6, because the brief asks for a
-- "campaign decline" trigger and there was nothing for it to fire on: a plan
-- could be approved or left in review forever, which is how a decision quietly
-- becomes a backlog.
--
-- `review_note` carries WHY it was rejected. A rejection with no reason is a
-- rejection the author has to guess at, and the automation that recommends what
-- to reconsider has nothing to say.
-- ---------------------------------------------------------------------------

ALTER TABLE ad_plans DROP CONSTRAINT IF EXISTS ad_plans_review_state_check;
ALTER TABLE ad_plans ADD CONSTRAINT ad_plans_review_state_check
    CHECK (review_state IN ('draft','in_review','approved','rejected'));
ALTER TABLE ad_plans ADD COLUMN IF NOT EXISTS review_note text;
ALTER TABLE ad_plans ADD COLUMN IF NOT EXISTS reviewed_by uuid REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE ad_plans ADD COLUMN IF NOT EXISTS reviewed_at timestamptz;

ALTER TABLE ad_plans DROP CONSTRAINT IF EXISTS ad_plans_rejection_has_reason;
ALTER TABLE ad_plans ADD CONSTRAINT ad_plans_rejection_has_reason
    CHECK (review_state <> 'rejected' OR review_note IS NOT NULL);

-- ---------------------------------------------------------------------------
-- Data connections
-- ---------------------------------------------------------------------------
-- One row per provider a customer has connected. A provider with NO ROW is not
-- connected: absence is the honest default, and there is no 'pending' state
-- that a screen could round up to "connected".
--
-- No access token is stored here. Token custody belongs with the credential
-- store, and putting one in a table that a reporting query joins against is how
-- a token ends up in a log. `external_account_id` is the non-secret handle.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS data_connections (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id     uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id          uuid REFERENCES projects(id) ON DELETE CASCADE,
    provider            text NOT NULL
                        CHECK (provider IN ('google_analytics','google_search_console',
                                            'google_ads','meta_ads','meta_pages',
                                            'linkedin_pages')),
    external_account_id text,
    connected_by        uuid REFERENCES users(id) ON DELETE SET NULL,
    connected_at        timestamptz,
    disconnected_at     timestamptz,
    last_synced_at      timestamptz,
    -- Set when a connection exists but cannot currently be read. Shown to the
    -- user rather than swallowed, because a stale figure with no warning is
    -- worse than no figure.
    problem             text,
    created_at          timestamptz NOT NULL DEFAULT now(),
    updated_at          timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT data_connections_unique UNIQUE (organization_id, project_id, provider)
);

CREATE INDEX IF NOT EXISTS data_connections_org_idx
    ON data_connections (organization_id, provider);

-- ---------------------------------------------------------------------------
-- Marketing calendar
-- ---------------------------------------------------------------------------
-- `event_date` is a DATE, not a timestamptz. A marketing calendar is a calendar
-- of days: storing an instant forces a timezone decision that would move an
-- entry across a date boundary for a colleague in another country.
--
-- `origin` distinguishes a manual entry from one derived from real content and
-- from an ACCEPTED SUGGESTION. Suggestions themselves are never stored here —
-- a suggestion rendered beside real entries becomes, within a week, something
-- the user believes they planned.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS calendar_events (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    kind             text NOT NULL
                     CHECK (kind IN ('social','blog','email','ads','offer','event',
                                     'website_update','seo_task','aeo_task','schema_task')),
    title            text NOT NULL CHECK (length(title) BETWEEN 1 AND 200),
    notes            text NOT NULL DEFAULT '',
    event_date       date NOT NULL,
    status           text NOT NULL DEFAULT 'planned'
                     CHECK (status IN ('planned','done','skipped')),
    origin           text NOT NULL DEFAULT 'manual'
                     CHECK (origin IN ('manual','derived','accepted_suggestion')),
    source_kind      text
                     CHECK (source_kind IN ('content','social_post','ad_plan',
                                            'messaging_plan','audit_finding',
                                            'schema_validation')),
    source_id        uuid,
    campaign         text,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now(),
    -- A derived entry must say what it was derived from, or it is indistinguishable
    -- from something a person planned.
    CONSTRAINT calendar_events_derived_has_source
        CHECK (origin <> 'derived' OR (source_kind IS NOT NULL AND source_id IS NOT NULL))
);

CREATE INDEX IF NOT EXISTS calendar_events_range_idx
    ON calendar_events (organization_id, project_id, event_date);
CREATE INDEX IF NOT EXISTS calendar_events_campaign_idx
    ON calendar_events (organization_id, campaign) WHERE campaign IS NOT NULL;

-- ---------------------------------------------------------------------------
-- Automation
-- ---------------------------------------------------------------------------
-- `action_kind` in the CHECK below is the WHOLE list of things a rule may do,
-- and every one of them produces something a person then acts on. There is no
-- 'send_email', 'publish_post' or 'adjust_budget', because SeSha cannot do
-- those things. The constraint is where that boundary is enforced for anything
-- that reaches the database by a route other than the application.
-- ---------------------------------------------------------------------------

-- A CHECK constraint may not contain a subquery, so the list is enforced through
-- an IMMUTABLE function instead. Keeping it in the database rather than only in
-- the application matters: this is the boundary that stops an outbound action
-- being introduced by a migration, a fixture or a direct INSERT.
CREATE OR REPLACE FUNCTION automation_actions_permitted(actions jsonb) RETURNS boolean AS $$
    SELECT jsonb_typeof(actions) = 'array'
       AND NOT EXISTS (
               SELECT 1
                 FROM jsonb_array_elements(actions) AS action
                WHERE action->>'kind' IS NULL
                   OR action->>'kind' NOT IN ('create_task','create_follow_up','notify',
                                              'suggest_content','add_calendar_entry','recommend')
           );
$$ LANGUAGE sql IMMUTABLE;

COMMENT ON FUNCTION automation_actions_permitted IS
    'The complete list of things an automation may do. Every one produces
     something a person then acts on; none contacts anybody, publishes anything
     or spends anything, because SeSha cannot.';

CREATE TABLE IF NOT EXISTS automation_rules (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name             text NOT NULL CHECK (length(name) BETWEEN 1 AND 120),
    trigger_kind     text NOT NULL
                     CHECK (trigger_kind IN ('lead_created','lead_stage_changed',
                                             'lead_went_quiet','content_approved',
                                             'campaign_plan_declined','schema_error_found',
                                             'structured_data_lost','crawl_completed',
                                             'audit_completed','validation_completed')),
    -- [{field, operator, value}]. ALL must hold.
    conditions       jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- [{kind, template, offsetDays}]. Validated in the application against the
    -- trigger's declared fields; constrained here to the permitted kinds.
    actions          jsonb NOT NULL,
    enabled          boolean NOT NULL DEFAULT false,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT automation_rules_actions_present
        CHECK (jsonb_typeof(actions) = 'array' AND jsonb_array_length(actions) > 0),
    CONSTRAINT automation_rules_actions_permitted
        CHECK (automation_actions_permitted(actions)),
    CONSTRAINT automation_rules_conditions_array
        CHECK (jsonb_typeof(conditions) = 'array')
);

CREATE INDEX IF NOT EXISTS automation_rules_trigger_idx
    ON automation_rules (organization_id, trigger_kind) WHERE enabled;

-- Every evaluation, including the ones that did nothing.
CREATE TABLE IF NOT EXISTS automation_runs (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    rule_id          uuid NOT NULL REFERENCES automation_rules(id) ON DELETE CASCADE,
    trigger_kind     text NOT NULL,
    subject_id       uuid,
    matched          boolean NOT NULL,
    -- Which condition failed, in words. NULL only when matched.
    skip_reason      text,
    -- What was produced: [{kind, text, offsetDays}]. Empty when not matched.
    actions_taken    jsonb NOT NULL DEFAULT '[]'::jsonb,
    ran_at           timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT automation_runs_skip_has_reason
        CHECK (matched OR skip_reason IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS automation_runs_rule_idx
    ON automation_runs (rule_id, ran_at DESC);
CREATE INDEX IF NOT EXISTS automation_runs_org_day_idx
    ON automation_runs (organization_id, ran_at DESC);

-- ---------------------------------------------------------------------------
-- Reports
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reports (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    kind             text NOT NULL
                     CHECK (kind IN ('daily','weekly','monthly','campaign','seo',
                                     'aeo','schema','social','executive')),
    title            text NOT NULL,
    period_from      date NOT NULL,
    period_to        date NOT NULL,
    period_label     text NOT NULL,
    -- The rendered report: sections, points and every MetricValue with its
    -- provenance. Stored whole so a shared link never changes under the reader.
    document         jsonb NOT NULL,
    -- Which sources were connected when it was generated. Denormalised on
    -- purpose: the report must still be readable after a connection is removed.
    connected_sources text[] NOT NULL DEFAULT ARRAY[]::text[],
    generated_by     uuid REFERENCES users(id) ON DELETE SET NULL,
    generated_at     timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT reports_period_ordered CHECK (period_to >= period_from)
);

CREATE INDEX IF NOT EXISTS reports_project_idx
    ON reports (organization_id, project_id, generated_at DESC);

-- A revocable, expiring, unauthenticated link to one report.
CREATE TABLE IF NOT EXISTS report_shares (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    report_id        uuid NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    -- sha256 of the token. The token itself is shown once and never stored.
    token_hash       text NOT NULL UNIQUE,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at       timestamptz NOT NULL DEFAULT now(),
    expires_at       timestamptz NOT NULL,
    revoked_at       timestamptz,
    last_viewed_at   timestamptz,
    view_count       integer NOT NULL DEFAULT 0,
    CONSTRAINT report_shares_expiry_future CHECK (expires_at > created_at)
);

CREATE INDEX IF NOT EXISTS report_shares_report_idx
    ON report_shares (report_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- Notification preferences
-- ---------------------------------------------------------------------------
-- Per user, per kind. A user with NO ROW for a kind gets the application
-- default, so adding a new kind does not arrive switched off for everyone who
-- already has a row for something else.
--
-- `email` exists as a column while no email provider is connected, because the
-- preference is the user's to hold even when SeSha cannot yet act on it. The
-- application refuses to set it to true until a provider exists, so nothing in
-- here can quietly become a promise to send.
-- ---------------------------------------------------------------------------

ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_kind_check;
ALTER TABLE notifications ADD CONSTRAINT notifications_kind_check
    CHECK (kind IN ('security','billing','system','content','lead','report',
                    'report_ready','new_lead','campaign_changed','content_scheduled',
                    'schema_error','audit_complete','crawl_complete','validation_complete'));

CREATE TABLE IF NOT EXISTS notification_preferences (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id          uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind             text NOT NULL
                     CHECK (kind IN ('report_ready','new_lead','campaign_changed',
                                     'content_scheduled','schema_error','audit_complete',
                                     'crawl_complete','validation_complete',
                                     'security','billing','system')),
    in_app           boolean NOT NULL DEFAULT true,
    email            boolean NOT NULL DEFAULT false,
    updated_at       timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT notification_preferences_unique UNIQUE (user_id, kind),
    -- The two kinds a user may not silence. Enforced here as well as in the
    -- application, so a direct UPDATE cannot mute a security alert.
    CONSTRAINT notification_preferences_always_on
        CHECK (kind NOT IN ('security','billing') OR in_app)
);

CREATE INDEX IF NOT EXISTS notification_preferences_user_idx
    ON notification_preferences (user_id);

-- ---------------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------------

ALTER TABLE data_connections          ENABLE ROW LEVEL SECURITY;
ALTER TABLE calendar_events           ENABLE ROW LEVEL SECURITY;
ALTER TABLE automation_rules          ENABLE ROW LEVEL SECURITY;
ALTER TABLE automation_runs           ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports                   ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_shares             ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_preferences  ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
    target text;
BEGIN
    FOREACH target IN ARRAY ARRAY['data_connections','calendar_events','automation_rules',
                                  'automation_runs','reports','report_shares',
                                  'notification_preferences']
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON %I', target || '_tenant_isolation', target);
        EXECUTE format(
            'CREATE POLICY %I ON %I USING (organization_id = current_setting(%L, true)::uuid)',
            target || '_tenant_isolation', target, 'app.current_organization'
        );
    END LOOP;
END
$$;

-- ---------------------------------------------------------------------------
-- updated_at maintenance
-- ---------------------------------------------------------------------------

CREATE TRIGGER data_connections_updated_at BEFORE UPDATE ON data_connections
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER calendar_events_updated_at BEFORE UPDATE ON calendar_events
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER automation_rules_updated_at BEFORE UPDATE ON automation_rules
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER notification_preferences_updated_at BEFORE UPDATE ON notification_preferences
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Account deletion
-- ---------------------------------------------------------------------------
-- Notification preferences are personal data and are destroyed with the user.
-- Everything else added here is organization data keyed to the organization,
-- and is removed by the organization's own cascade.
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION anonymize_deleted_user(target_user uuid) RETURNS void AS $$
BEGIN
    UPDATE users
       SET email             = 'deleted-' || target_user || '@invalid',
           name              = NULL,
           password_hash     = NULL,
           timezone          = NULL,
           email_verified_at = NULL
     WHERE id = target_user
       AND deleted_at IS NOT NULL;

    DELETE FROM oauth_accounts             WHERE user_id = target_user;
    DELETE FROM sessions                   WHERE user_id = target_user;
    DELETE FROM email_verification_tokens  WHERE user_id = target_user;
    DELETE FROM password_reset_tokens      WHERE user_id = target_user;
    DELETE FROM notifications              WHERE user_id = target_user;
    DELETE FROM notification_preferences   WHERE user_id = target_user;
END;
$$ LANGUAGE plpgsql;

COMMENT ON TABLE data_connections IS
    'One row per connected provider. No row means not connected. Holds no access
     token: token custody belongs with the credential store.';
COMMENT ON TABLE automation_runs IS
    'Every evaluation, including non-matches. A rule that quietly stops matching
     is otherwise indistinguishable from one that never runs.';
COMMENT ON TABLE reports IS
    'The rendered report, stored whole, so a shared link shows what it showed
     when it was sent rather than being re-run against today''s data.';
COMMENT ON TABLE report_shares IS
    'Revocable, expiring share links. Only the sha256 of the token is stored.';

COMMIT;
