-- ---------------------------------------------------------------------------
-- Migration 0003 — Phase 3: AI generation, strategy, content and social
-- ---------------------------------------------------------------------------
-- Forward-only. Do not edit once applied; add a new migration instead.
--
-- Conventions carried forward: uuid keys, timestamptz, organization_id plus
-- row-level security on every tenant-scoped table, ON DELETE on every foreign
-- key, soft delete only where audit history references the row.
-- ---------------------------------------------------------------------------

BEGIN;

-- ---------------------------------------------------------------------------
-- Usage: token accounting
-- ---------------------------------------------------------------------------
-- AI cost has two dimensions that behave differently: the NUMBER of
-- generations (a fair-use limit) and the TOKENS they consumed (the actual
-- spend). One long strategy can cost more than fifty captions, so counting
-- generations alone would not bound the bill.

ALTER TABLE usage_records DROP CONSTRAINT IF EXISTS usage_records_metric_check;
ALTER TABLE usage_records ADD CONSTRAINT usage_records_metric_check
    CHECK (metric IN ('ai_generation','ai_tokens','content_item','crawl_page',
                      'report','automation_run','seat'));

-- ---------------------------------------------------------------------------
-- AI messages: cost and provenance
-- ---------------------------------------------------------------------------

ALTER TABLE ai_messages
    ADD COLUMN IF NOT EXISTS provider        text,
    ADD COLUMN IF NOT EXISTS model           text,
    ADD COLUMN IF NOT EXISTS agent           text,
    ADD COLUMN IF NOT EXISTS input_tokens    integer,
    ADD COLUMN IF NOT EXISTS output_tokens   integer,
    ADD COLUMN IF NOT EXISTS cached          boolean NOT NULL DEFAULT false,
    -- The provenance-tagged blocks exactly as parsed. Stored rather than
    -- flattened to text so the interface can re-render the labels, and so a
    -- claim can be traced back to how it was sourced long after the fact.
    ADD COLUMN IF NOT EXISTS blocks          jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- Findings from the claim linter. A message with errors was shown with a
    -- warning; keeping them means the record reflects what the user actually saw.
    ADD COLUMN IF NOT EXISTS claim_warnings  jsonb NOT NULL DEFAULT '[]'::jsonb;

CREATE INDEX IF NOT EXISTS ai_messages_org_created_idx
    ON ai_messages (organization_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- Content items
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS content_items (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,

    -- One of the twenty formats in src/lib/content/types.ts. Not constrained to
    -- an enum here: the list grows every phase, and a CHECK would mean a
    -- migration each time. The application validates against the typed list.
    format           text NOT NULL,
    title            text NOT NULL,
    body             text NOT NULL,

    language         text NOT NULL DEFAULT 'en'
                     CHECK (language IN ('en','hi','hinglish')),
    tone             text,
    audience         text,
    length_preset    text,
    creativity       smallint CHECK (creativity BETWEEN 0 AND 100),
    call_to_action   text,
    search_intent    text,
    answer_intent    text,

    -- Nothing publishes without review. 'draft' is the only state a generation
    -- can create; a person moves it forward.
    status           text NOT NULL DEFAULT 'draft'
                     CHECK (status IN ('draft','in_review','approved','archived')),
    reviewed_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    reviewed_at      timestamptz,

    -- Provenance travels with the saved content, not just with the chat message.
    blocks           jsonb NOT NULL DEFAULT '[]'::jsonb,
    claim_warnings   jsonb NOT NULL DEFAULT '[]'::jsonb,
    generated_by     jsonb NOT NULL DEFAULT '{}'::jsonb,

    deleted_at       timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT content_items_reviewed_has_reviewer
        CHECK (status <> 'approved' OR reviewed_by IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS content_items_project_idx
    ON content_items (project_id, created_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS content_items_format_idx
    ON content_items (organization_id, format) WHERE deleted_at IS NULL;

-- ---------------------------------------------------------------------------
-- Strategies
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS strategies (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,

    title            text NOT NULL,
    -- One row per generated strategy, with all sections in a single document.
    -- Sections are a fixed list in code; storing them as jsonb avoids a
    -- seventeen-column table that changes shape every time the list does.
    sections         jsonb NOT NULL DEFAULT '{}'::jsonb,
    blocks           jsonb NOT NULL DEFAULT '[]'::jsonb,
    claim_warnings   jsonb NOT NULL DEFAULT '[]'::jsonb,
    generated_by     jsonb NOT NULL DEFAULT '{}'::jsonb,

    status           text NOT NULL DEFAULT 'draft'
                     CHECK (status IN ('draft','in_review','approved','archived')),
    -- Exactly one approved strategy per project at a time; enforced by the
    -- partial index below rather than by application discipline.
    deleted_at       timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS strategies_one_approved_idx
    ON strategies (project_id) WHERE status = 'approved' AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS strategies_project_idx
    ON strategies (project_id, created_at DESC) WHERE deleted_at IS NULL;

-- ---------------------------------------------------------------------------
-- Social posts
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS social_posts (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,

    platform         text NOT NULL
                     CHECK (platform IN ('instagram','facebook','linkedin','youtube',
                                         'x','pinterest','whatsapp')),
    format           text NOT NULL,
    caption          text NOT NULL,
    hashtags         jsonb NOT NULL DEFAULT '[]'::jsonb,
    idea             text,

    -- PLANNING STATES ONLY. There is deliberately no 'published' state and no
    -- scheduled-publish worker: no platform API is connected, so a post cannot
    -- be published from here. 'ready' means a person can copy it out and post
    -- it themselves. Adding 'published' before an API exists would be a lie in
    -- the schema.
    status           text NOT NULL DEFAULT 'idea'
                     CHECK (status IN ('idea','draft','ready','archived')),
    planned_for      date,

    blocks           jsonb NOT NULL DEFAULT '[]'::jsonb,
    generated_by     jsonb NOT NULL DEFAULT '{}'::jsonb,

    deleted_at       timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS social_posts_calendar_idx
    ON social_posts (project_id, planned_for) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS social_posts_platform_idx
    ON social_posts (organization_id, platform) WHERE deleted_at IS NULL;

-- ---------------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------------

ALTER TABLE content_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE strategies    ENABLE ROW LEVEL SECURITY;
ALTER TABLE social_posts  ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
    target text;
BEGIN
    FOREACH target IN ARRAY ARRAY['content_items','strategies','social_posts']
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON %I', target || '_tenant_isolation', target);
        EXECUTE format(
            'CREATE POLICY %I ON %I USING (organization_id = current_setting(%L, true)::uuid)',
            target || '_tenant_isolation', target, 'app.current_organization'
        );
    END LOOP;
END
$$;

-- ---------------------------------------------------------------------------
-- updated_at maintenance
-- ---------------------------------------------------------------------------

CREATE TRIGGER content_items_updated_at BEFORE UPDATE ON content_items
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER strategies_updated_at BEFORE UPDATE ON strategies
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER social_posts_updated_at BEFORE UPDATE ON social_posts
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

COMMIT;
