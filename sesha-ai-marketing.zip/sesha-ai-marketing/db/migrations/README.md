# Migrations

Forward-only SQL, applied in filename order. Never edit a migration that has run
in any environment — add a new one.

| File | Phase | Contents |
|---|---|---|
| `0001_init.sql` | 1 | Public-site baseline: organizations, users, memberships, sessions, workspaces, brand kits, posts, contact submissions, subscribers, leads, audit log |
| `0002_accounts.sql` | 2 | Authentication, OAuth, verification and reset tokens, businesses, projects, marketing profiles, crawl consent, subscriptions, usage, notifications, AI conversations, login attempts, soft delete, RLS policies |

`../schema.sql` is the **full current schema as one readable file**. It is kept in
sync with the migrations, and `tests/database.test.ts` fails if a table exists in
one and not the other.

## Applying

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/0001_init.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/0002_accounts.sql
```

Each migration is wrapped in a transaction, so a failure leaves the database
unchanged.
