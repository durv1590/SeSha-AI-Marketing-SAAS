-- Migration 0001 — Phase 1 baseline.
-- Forward-only. Do not edit once applied; add a new migration instead.
BEGIN;

-- ---------------------------------------------------------------------------
-- SeSha AI Marketing — PostgreSQL schema
-- ---------------------------------------------------------------------------
-- Phase 1 does NOT run this. It is the target shape the repository interfaces
-- in src/lib/db are written against, checked in now so Phase 2 starts from a
-- reviewed design rather than an improvised one.
--
-- Conventions:
--   * UUID primary keys generated in the database.
--   * timestamptz everywhere; never a naive timestamp.
--   * Tenant isolation on organization_id, enforced by row-level security in
--     addition to repository-level filtering (defence in depth).
--   * citext for emails so uniqueness is case-insensitive.
-- ---------------------------------------------------------------------------

CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";

-- --------------------------------------------------------------------------
-- Tenancy and identity
-- --------------------------------------------------------------------------

CREATE TABLE organizations (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name        text NOT NULL CHECK (length(btrim(name)) > 0),
    slug        citext NOT NULL UNIQUE,
    plan        text NOT NULL DEFAULT 'starter'
                CHECK (plan IN ('starter', 'growth', 'agency')),
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE users (
    id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email              citext NOT NULL UNIQUE,
    name               text,
    -- Argon2id encoded hash. NULL for accounts that only use SSO.
    password_hash      text,
    email_verified_at  timestamptz,
    last_login_at      timestamptz,
    created_at         timestamptz NOT NULL DEFAULT now(),
    updated_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE memberships (
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id          uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role             text NOT NULL DEFAULT 'viewer'
                     CHECK (role IN ('owner', 'admin', 'editor', 'viewer')),
    created_at       timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (organization_id, user_id)
);

CREATE INDEX memberships_user_idx ON memberships (user_id);

-- Server-side sessions. The cookie holds an opaque token, never a JWT payload.
CREATE TABLE sessions (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    -- SHA-256 of the token; a database leak must not yield usable sessions.
    token_hash   bytea NOT NULL UNIQUE,
    user_agent   text,
    ip_hash      bytea,
    expires_at   timestamptz NOT NULL,
    revoked_at   timestamptz,
    created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX sessions_user_idx ON sessions (user_id);
CREATE INDEX sessions_expiry_idx ON sessions (expires_at) WHERE revoked_at IS NULL;

-- --------------------------------------------------------------------------
-- Workspaces and brand
-- --------------------------------------------------------------------------

CREATE TABLE workspaces (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name             text NOT NULL,
    slug             citext NOT NULL,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, slug)
);

CREATE TABLE brand_kits (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id  uuid NOT NULL UNIQUE REFERENCES workspaces(id) ON DELETE CASCADE,
    voice         text,
    tone_rules    text,
    terminology   jsonb NOT NULL DEFAULT '{}'::jsonb,
    palette       jsonb NOT NULL DEFAULT '{}'::jsonb,
    updated_at    timestamptz NOT NULL DEFAULT now()
);

-- --------------------------------------------------------------------------
-- Content
-- --------------------------------------------------------------------------

CREATE TABLE posts (
    id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id   uuid REFERENCES workspaces(id) ON DELETE CASCADE,
    slug           citext NOT NULL,
    title          text NOT NULL,
    excerpt        text NOT NULL,
    -- AEO: the quotable answer, stored separately so it is never buried.
    direct_answer  text NOT NULL,
    body           jsonb NOT NULL DEFAULT '[]'::jsonb,
    author_id      text NOT NULL,
    category       text NOT NULL,
    status         text NOT NULL DEFAULT 'draft'
                   CHECK (status IN ('draft', 'in_review', 'published', 'archived')),
    -- Enforces the rule that a published post must have a publication date.
    published_at   timestamptz,
    updated_at     timestamptz NOT NULL DEFAULT now(),
    created_at     timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT posts_published_has_date
        CHECK (status <> 'published' OR published_at IS NOT NULL)
);

CREATE UNIQUE INDEX posts_workspace_slug_idx ON posts (workspace_id, slug);
CREATE INDEX posts_published_idx ON posts (published_at DESC) WHERE status = 'published';

-- --------------------------------------------------------------------------
-- Public site: inbound
-- --------------------------------------------------------------------------

CREATE TABLE contact_submissions (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name         text NOT NULL,
    email        citext NOT NULL,
    company      text,
    topic        text NOT NULL
                 CHECK (topic IN ('product','pricing','partnership','support','security','other')),
    message      text NOT NULL,
    source_path  text,
    handled_at   timestamptz,
    created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX contact_submissions_created_idx ON contact_submissions (created_at DESC);
CREATE INDEX contact_submissions_open_idx ON contact_submissions (created_at DESC)
    WHERE handled_at IS NULL;

CREATE TABLE newsletter_subscribers (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email            citext NOT NULL UNIQUE,
    confirmed_at     timestamptz,
    unsubscribed_at  timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE leads (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    email            citext NOT NULL,
    name             text,
    -- Attribution captured at creation, never reconstructed later.
    source_path      text,
    source_campaign  text,
    status           text NOT NULL DEFAULT 'new'
                     CHECK (status IN ('new','qualified','contacted','won','lost')),
    owner_user_id    uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX leads_org_created_idx ON leads (organization_id, created_at DESC);

-- --------------------------------------------------------------------------
-- Audit
-- --------------------------------------------------------------------------

CREATE TABLE audit_log (
    id           bigserial PRIMARY KEY,
    actor_id     uuid REFERENCES users(id) ON DELETE SET NULL,
    action       text NOT NULL,
    entity_type  text NOT NULL,
    entity_id    text,
    metadata     jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX audit_log_entity_idx ON audit_log (entity_type, entity_id, created_at DESC);

-- --------------------------------------------------------------------------
-- Row-level security (defence in depth behind repository-level filtering)
-- --------------------------------------------------------------------------

ALTER TABLE workspaces ENABLE ROW LEVEL SECURITY;
ALTER TABLE brand_kits ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts      ENABLE ROW LEVEL SECURITY;
ALTER TABLE leads      ENABLE ROW LEVEL SECURITY;

-- The application sets `app.current_organization` per connection after auth.
CREATE POLICY workspaces_tenant_isolation ON workspaces
    USING (organization_id = current_setting('app.current_organization', true)::uuid);

CREATE POLICY leads_tenant_isolation ON leads
    USING (organization_id = current_setting('app.current_organization', true)::uuid);

-- --------------------------------------------------------------------------
-- updated_at maintenance
-- --------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER organizations_updated_at BEFORE UPDATE ON organizations
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER workspaces_updated_at BEFORE UPDATE ON workspaces
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER posts_updated_at BEFORE UPDATE ON posts
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

COMMIT;
