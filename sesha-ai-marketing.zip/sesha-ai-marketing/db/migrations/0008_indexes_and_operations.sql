-- ============================================================================
-- 0008 — Phase 8: the indexes that were missing, and operational tables.
--
-- FORWARD-ONLY. No table is dropped, no column is removed.
--
-- WHY A WHOLE MIGRATION OF INDEXES
-- A Phase 8 audit walked every repository method against every index and found
-- two distinct classes of gap. Neither shows up in development, because the
-- in-memory adapter scans arrays and does not care, and both become an incident
-- on the first table with real row counts.
--
--   1. UNINDEXED FOREIGN KEYS. PostgreSQL does NOT index a foreign key for you.
--      It indexes the PRIMARY KEY of the parent, not the column that references
--      it. So every `DELETE FROM users` takes a sequential scan of every child
--      table to check the constraint — and account deletion touches a dozen of
--      them. On a large `admin_actions` or `feedback` table that is the
--      difference between a delete that returns and one that holds a lock while
--      support wonder why the page is spinning.
--
--   2. QUERY-SHAPE GAPS. An index on `(organization_id, project_id, event_date)`
--      cannot serve a query that filters on `(organization_id, source_kind)` —
--      a btree is only usable from its leading column onwards. Several indexes
--      added in 0006 and 0007 lead with a column the actual query does not
--      supply, which makes them dead weight for that path: the cost of
--      maintaining an index with none of the benefit.
--
-- CREATE INDEX IF NOT EXISTS throughout, so this is safe to re-run.
--
-- A NOTE ON `CONCURRENTLY`. These are written WITHOUT it, because
-- `CREATE INDEX CONCURRENTLY` cannot run inside a transaction block and every
-- migration in this project is wrapped in one — a property worth more than the
-- ability to build these particular indexes online. On a large live table, build
-- them by hand with CONCURRENTLY first; `IF NOT EXISTS` then makes this file a
-- no-op for the ones already there. That is the whole reason it is written this
-- way.
-- ============================================================================

BEGIN;

-- ---------------------------------------------------------------------------
-- 1. Unindexed foreign keys
--
-- Every one of these is a column that REFERENCES another table and had no index
-- of its own. Listed by the parent whose deletes they slow down.
-- ---------------------------------------------------------------------------

-- → users(id). Account deletion scans each of these without an index.
CREATE INDEX IF NOT EXISTS calendar_events_created_by_idx
  ON calendar_events (created_by);
CREATE INDEX IF NOT EXISTS automation_rules_created_by_idx
  ON automation_rules (created_by);
CREATE INDEX IF NOT EXISTS reports_generated_by_idx
  ON reports (generated_by);
CREATE INDEX IF NOT EXISTS report_shares_created_by_idx
  ON report_shares (created_by);
CREATE INDEX IF NOT EXISTS quota_refusals_user_idx
  ON quota_refusals (user_id);
CREATE INDEX IF NOT EXISTS plan_limit_overrides_set_by_idx
  ON plan_limit_overrides (set_by);
CREATE INDEX IF NOT EXISTS platform_staff_granted_by_idx
  ON platform_staff (granted_by);
CREATE INDEX IF NOT EXISTS platform_staff_revoked_by_idx
  ON platform_staff (revoked_by);
CREATE INDEX IF NOT EXISTS error_events_resolved_by_idx
  ON error_events (resolved_by);
CREATE INDEX IF NOT EXISTS feedback_user_idx
  ON feedback (user_id);
CREATE INDEX IF NOT EXISTS feedback_triaged_by_idx
  ON feedback (triaged_by);

-- → organizations(id). Deleting an organization cascades through these.
CREATE INDEX IF NOT EXISTS report_shares_org_idx
  ON report_shares (organization_id);
CREATE INDEX IF NOT EXISTS notification_preferences_org_idx
  ON notification_preferences (organization_id);
CREATE INDEX IF NOT EXISTS error_events_org_idx
  ON error_events (organization_id);
CREATE INDEX IF NOT EXISTS feedback_org_idx
  ON feedback (organization_id);

-- → projects(id).
CREATE INDEX IF NOT EXISTS automation_rules_project_idx
  ON automation_rules (organization_id, project_id);
CREATE INDEX IF NOT EXISTS quota_refusals_project_idx
  ON quota_refusals (project_id);

-- ---------------------------------------------------------------------------
-- 2. Query-shape gaps
--
-- Each of these serves a repository method that no existing index could help,
-- named in the comment so the pairing survives.
-- ---------------------------------------------------------------------------

-- CalendarRepository.findBySource(organizationId, kind, id). The existing
-- range index leads with project_id, which this lookup does not supply.
CREATE INDEX IF NOT EXISTS calendar_events_source_idx
  ON calendar_events (organization_id, source_kind, source_id);

-- BillingEventRepository.listRecent() reads ACROSS tenants, newest first, for
-- the admin panel. `billing_events_org_idx` leads with organization_id and
-- cannot serve a global ordered scan.
CREATE INDEX IF NOT EXISTS billing_events_recent_idx
  ON billing_events (occurred_at DESC);

-- AdminActionRepository.list({ kind: 'read' }). 0007 added a partial index for
-- `kind = 'write'` only, so the reads — which are the majority, and the whole
-- point of auditing a cross-tenant panel — had nothing.
CREATE INDEX IF NOT EXISTS admin_actions_kind_idx
  ON admin_actions (kind, created_at DESC);

-- ErrorEventRepository.countSince() counts resolved rows too, so the partial
-- `WHERE resolved_at IS NULL` index excludes exactly what it needs.
CREATE INDEX IF NOT EXISTS error_events_last_seen_idx
  ON error_events (last_seen_at DESC);

-- FeedbackRepository.list() with no status filter sorts by created_at, and
-- `feedback_status_idx` leads with status.
CREATE INDEX IF NOT EXISTS feedback_created_idx
  ON feedback (created_at DESC);

-- Cursor pagination compares (created_at, id) as a row value. A composite index
-- in exactly that order is what makes `WHERE (created_at, id) < ($1, $2)` an
-- index scan rather than a sort of the whole table.
CREATE INDEX IF NOT EXISTS admin_actions_cursor_idx
  ON admin_actions (created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS audit_log_cursor_idx
  ON audit_log (created_at DESC, id DESC);

-- ---------------------------------------------------------------------------
-- 3. Job recovery
--
-- WHAT THIS FIXES: a worker that dies mid-job leaves the row in `running`
-- forever. Nothing reaps it, nothing retries it, and the customer's crawl simply
-- never finishes — the failure mode that looks like a hang rather than an error,
-- which is the worst kind to diagnose from a support ticket.
--
-- `heartbeat_at` is written by the worker as it makes progress. A row in
-- `running` whose heartbeat is older than the threshold had its worker die, and
-- can be returned to the queue. This is a column rather than a separate table
-- because the alternative — inferring death from `started_at` alone — cannot
-- tell a dead worker from a slow one, and would cancel long legitimate crawls.
-- ---------------------------------------------------------------------------

ALTER TABLE jobs
  ADD COLUMN IF NOT EXISTS heartbeat_at timestamptz,
  -- Set when a job is returned to the queue by the reaper rather than by its
  -- own worker, so "why did this run twice" has an answer.
  ADD COLUMN IF NOT EXISTS recovered_count integer NOT NULL DEFAULT 0;

COMMENT ON COLUMN jobs.heartbeat_at IS
  'Last progress signal from the worker. A running job whose heartbeat is stale had its worker die and is recoverable.';
COMMENT ON COLUMN jobs.recovered_count IS
  'How many times this job was returned to the queue by the reaper. A job recovered repeatedly is failing, not unlucky.';

-- Finds stalled jobs without scanning the whole table. Partial, because only
-- running jobs can stall.
CREATE INDEX IF NOT EXISTS jobs_stalled_idx
  ON jobs (heartbeat_at)
  WHERE status = 'running';

-- ---------------------------------------------------------------------------
-- 4. Idempotency keys
--
-- WHY A TABLE AND NOT JUST THE IN-MEMORY STORE: the in-memory one
-- (`lib/reliability`) is per-process, so with two instances behind a load
-- balancer the same key can run once on each — which is precisely the
-- double-charge the mechanism exists to prevent. This table is the durable half.
--
-- The UNIQUE constraint is the enforcement. Not a SELECT-then-INSERT, which
-- races exactly when it matters: two concurrent requests both find nothing and
-- both insert. The second INSERT violates the constraint and the caller replays
-- the first result instead.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS idempotency_keys (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id  uuid REFERENCES organizations(id) ON DELETE CASCADE,
  -- Scope keeps one feature's keys from colliding with another's.
  scope            text NOT NULL CHECK (length(scope) BETWEEN 1 AND 64),
  key              text NOT NULL CHECK (length(key) BETWEEN 1 AND 255),
  -- A SUMMARY of the outcome, never the full response: a response body can
  -- carry customer content, and this table is not a second copy of it.
  outcome          jsonb NOT NULL DEFAULT '{}'::jsonb,
  status           text NOT NULL DEFAULT 'succeeded'
                     CHECK (status IN ('succeeded', 'failed')),
  created_at       timestamptz NOT NULL DEFAULT now(),
  expires_at       timestamptz NOT NULL,

  UNIQUE (scope, key)
);

COMMENT ON TABLE idempotency_keys IS
  'At-most-once execution for critical operations, durable across instances. The UNIQUE (scope, key) constraint is the enforcement; a SELECT-then-INSERT would race exactly when two requests arrive together, which is the case this exists for.';

CREATE INDEX IF NOT EXISTS idempotency_keys_expiry_idx
  ON idempotency_keys (expires_at);
CREATE INDEX IF NOT EXISTS idempotency_keys_org_idx
  ON idempotency_keys (organization_id);

ALTER TABLE idempotency_keys ENABLE ROW LEVEL SECURITY;

-- Rows with a NULL organization are platform-level (a provider webhook, which
-- belongs to no tenant until it has been read). They are invisible to tenants.
CREATE POLICY idempotency_keys_tenant_isolation ON idempotency_keys
  USING (organization_id = current_setting('app.current_organization', true)::uuid);

COMMIT;
