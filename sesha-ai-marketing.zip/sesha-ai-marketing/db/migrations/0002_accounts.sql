-- ---------------------------------------------------------------------------
-- Migration 0002 — Phase 2: authentication, accounts, businesses, projects
-- ---------------------------------------------------------------------------
-- Forward-only. Do not edit once applied; add a new migration instead.
--
-- Conventions carried forward from 0001:
--   * uuid primary keys generated in the database
--   * timestamptz everywhere
--   * citext for email, so uniqueness is case-insensitive
--   * tenant isolation on organization_id, enforced by RLS as well as by the
--     repository layer
--
-- SOFT DELETE POLICY (deliberate, per-table):
--   * users, organizations, businesses, projects  -> soft delete (deleted_at).
--     These are referenced by audit records and by the user's own data; a hard
--     delete would orphan history or cascade far wider than intended.
--   * sessions, tokens, login_attempts            -> HARD delete / expiry.
--     Keeping a revoked session row "soft deleted" is a liability, not history.
--   * A user who requests account deletion is soft-deleted immediately
--     (sign-in blocked, sessions revoked, email released via anonymisation) and
--     purged by a scheduled job after the retention window. See
--     `anonymize_deleted_user` at the end of this file.
-- ---------------------------------------------------------------------------

BEGIN;

-- ---------------------------------------------------------------------------
-- Users: additions for authentication and lifecycle
-- ---------------------------------------------------------------------------

ALTER TABLE users
    ADD COLUMN IF NOT EXISTS onboarding_completed_at  timestamptz,
    ADD COLUMN IF NOT EXISTS deleted_at               timestamptz,
    ADD COLUMN IF NOT EXISTS deletion_requested_at    timestamptz,
    ADD COLUMN IF NOT EXISTS password_changed_at      timestamptz,
    ADD COLUMN IF NOT EXISTS locale                   text NOT NULL DEFAULT 'en',
    ADD COLUMN IF NOT EXISTS timezone                 text;

-- A user with no password_hash must have at least one OAuth account; enforced
-- in the application because the check spans two tables.
COMMENT ON COLUMN users.password_hash IS
    'scrypt encoded hash (see src/lib/auth/password.ts). NULL means OAuth-only.';

-- Active (non-deleted) email uniqueness. The plain UNIQUE from 0001 would block
-- a new signup on an address whose previous account was soft-deleted, so the
-- constraint is replaced by a partial index.
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_email_key;
CREATE UNIQUE INDEX IF NOT EXISTS users_email_active_idx
    ON users (email) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS users_deleted_idx ON users (deleted_at) WHERE deleted_at IS NOT NULL;

-- ---------------------------------------------------------------------------
-- Sessions: additions for idle timeout, sudo mode and device display
-- ---------------------------------------------------------------------------

ALTER TABLE sessions
    ADD COLUMN IF NOT EXISTS last_active_at timestamptz NOT NULL DEFAULT now(),
    ADD COLUMN IF NOT EXISTS sudo_until     timestamptz;

CREATE INDEX IF NOT EXISTS sessions_active_idx
    ON sessions (user_id, last_active_at DESC) WHERE revoked_at IS NULL;

COMMENT ON COLUMN sessions.token_hash IS
    'SHA-256 of the opaque session token. The token itself is never stored.';

-- ---------------------------------------------------------------------------
-- OAuth accounts (Google, and any future provider)
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS oauth_accounts (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id           uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider          text NOT NULL CHECK (provider IN ('google')),
    -- The provider's stable subject identifier. NOT the email: an email can be
    -- reassigned by a Workspace admin, `sub` cannot.
    provider_user_id  text NOT NULL,
    email             citext,
    email_verified    boolean NOT NULL DEFAULT false,
    created_at        timestamptz NOT NULL DEFAULT now(),
    last_login_at     timestamptz,
    UNIQUE (provider, provider_user_id)
);

CREATE INDEX IF NOT EXISTS oauth_accounts_user_idx ON oauth_accounts (user_id);

-- ---------------------------------------------------------------------------
-- Email verification and password reset
-- ---------------------------------------------------------------------------
-- Both store only a SHA-256 hash of the token. Both are single-use: `used_at`
-- is set on redemption, and redemption checks it, so a leaked link cannot be
-- replayed.

CREATE TABLE IF NOT EXISTS email_verification_tokens (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash  bytea NOT NULL UNIQUE,
    email       citext NOT NULL,
    expires_at  timestamptz NOT NULL,
    used_at     timestamptz,
    created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS email_verification_user_idx ON email_verification_tokens (user_id);

CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash  bytea NOT NULL UNIQUE,
    expires_at  timestamptz NOT NULL,
    used_at     timestamptz,
    -- Recorded for the security-notification email, hashed not raw.
    ip_hash     bytea,
    created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS password_reset_user_idx ON password_reset_tokens (user_id);

-- ---------------------------------------------------------------------------
-- Login attempts — durable brute-force counters
-- ---------------------------------------------------------------------------
-- The in-process limiter in src/lib/auth/lockout.ts is correct for a single
-- instance. This table is the shared store a multi-instance deployment needs:
-- without it an attacker simply spreads attempts across instances.

CREATE TABLE IF NOT EXISTS login_attempts (
    id           bigserial PRIMARY KEY,
    -- 'account:<email>' or 'address:<ip-hash>'
    scope_key    text NOT NULL,
    succeeded    boolean NOT NULL,
    attempted_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS login_attempts_scope_idx
    ON login_attempts (scope_key, attempted_at DESC);

-- ---------------------------------------------------------------------------
-- Businesses
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS businesses (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name             text NOT NULL CHECK (length(btrim(name)) > 0),
    industry         text,
    country          text,
    city             text,
    website_url      text,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at       timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS businesses_org_idx
    ON businesses (organization_id) WHERE deleted_at IS NULL;

-- ---------------------------------------------------------------------------
-- Projects — the tenant-isolation unit
-- ---------------------------------------------------------------------------
-- Every piece of customer data below hangs off a project, and every project
-- hangs off an organization. A query that filters by project_id alone is a bug:
-- always filter by organization_id as well, which is what RLS enforces.

CREATE TABLE IF NOT EXISTS projects (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    business_id      uuid REFERENCES businesses(id) ON DELETE SET NULL,
    name             text NOT NULL CHECK (length(btrim(name)) > 0),
    slug             citext NOT NULL,
    description      text,
    status           text NOT NULL DEFAULT 'active'
                     CHECK (status IN ('active', 'paused', 'archived')),
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at       timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);

-- Slug unique per organization, among live projects only.
CREATE UNIQUE INDEX IF NOT EXISTS projects_org_slug_idx
    ON projects (organization_id, slug) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS projects_org_idx
    ON projects (organization_id, created_at DESC) WHERE deleted_at IS NULL;

-- ---------------------------------------------------------------------------
-- AI Marketing Profile — the onboarding output
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS marketing_profiles (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL UNIQUE REFERENCES projects(id) ON DELETE CASCADE,
    target_audience   text,
    products_services text,
    price_range       text CHECK (price_range IS NULL OR price_range IN
                        ('budget', 'mid_market', 'premium', 'luxury', 'varies')),
    marketing_goals   jsonb NOT NULL DEFAULT '[]'::jsonb,
    marketing_channels jsonb NOT NULL DEFAULT '[]'::jsonb,
    brand_voice       jsonb NOT NULL DEFAULT '{}'::jsonb,
    competitors       jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- Completeness drives the onboarding progress indicator. Derived, but
    -- stored so list queries do not have to recompute it.
    completeness      smallint NOT NULL DEFAULT 0
                      CHECK (completeness BETWEEN 0 AND 100),
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS marketing_profiles_org_idx ON marketing_profiles (organization_id);

-- ---------------------------------------------------------------------------
-- Website crawl consent
-- ---------------------------------------------------------------------------
-- NOTHING may crawl a customer's website without a row here. The consent record
-- captures WHAT was agreed, WHEN, and BY WHOM, and is revocable. Storing the
-- scope alongside the grant means a later change to default crawl behaviour
-- cannot retroactively widen an existing consent.

CREATE TABLE IF NOT EXISTS website_crawl_consents (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    website_url      text NOT NULL,
    granted_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    granted_at       timestamptz NOT NULL DEFAULT now(),
    revoked_at       timestamptz,
    -- The exact terms shown to the user, so consent is auditable against the
    -- wording that was actually presented.
    consent_version  text NOT NULL,
    max_pages        integer NOT NULL DEFAULT 100 CHECK (max_pages > 0 AND max_pages <= 5000),
    respect_robots   boolean NOT NULL DEFAULT true,
    retention_days   integer NOT NULL DEFAULT 90 CHECK (retention_days > 0),
    -- Set when the user asks for crawled data to be erased.
    data_deleted_at  timestamptz
);

CREATE INDEX IF NOT EXISTS crawl_consents_project_idx
    ON website_crawl_consents (project_id) WHERE revoked_at IS NULL;

-- ---------------------------------------------------------------------------
-- Brand kits — re-scoped from workspace to project
-- ---------------------------------------------------------------------------

ALTER TABLE brand_kits
    ADD COLUMN IF NOT EXISTS organization_id uuid REFERENCES organizations(id) ON DELETE CASCADE,
    ADD COLUMN IF NOT EXISTS project_id      uuid REFERENCES projects(id) ON DELETE CASCADE,
    ADD COLUMN IF NOT EXISTS logo_url        text,
    ADD COLUMN IF NOT EXISTS created_at      timestamptz NOT NULL DEFAULT now();

ALTER TABLE brand_kits ALTER COLUMN workspace_id DROP NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS brand_kits_project_idx
    ON brand_kits (project_id) WHERE project_id IS NOT NULL;

-- ---------------------------------------------------------------------------
-- Subscriptions and usage
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS subscriptions (
    id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id      uuid NOT NULL UNIQUE REFERENCES organizations(id) ON DELETE CASCADE,
    plan                 text NOT NULL DEFAULT 'starter'
                         CHECK (plan IN ('starter', 'growth', 'agency')),
    status               text NOT NULL DEFAULT 'trialing'
                         CHECK (status IN ('trialing','active','past_due','canceled','paused')),
    -- Set only by the billing provider webhook; never by the application.
    external_customer_id text,
    external_subscription_id text,
    current_period_start timestamptz,
    current_period_end   timestamptz,
    cancel_at_period_end boolean NOT NULL DEFAULT false,
    trial_ends_at        timestamptz,
    created_at           timestamptz NOT NULL DEFAULT now(),
    updated_at           timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS usage_records (
    id               bigserial PRIMARY KEY,
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid REFERENCES projects(id) ON DELETE SET NULL,
    metric           text NOT NULL
                     CHECK (metric IN ('ai_generation','content_item','crawl_page',
                                       'report','automation_run','seat')),
    quantity         integer NOT NULL DEFAULT 1 CHECK (quantity > 0),
    -- First day of the billing month, so a month's usage is one indexed range.
    period_start     date NOT NULL,
    recorded_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS usage_org_period_idx
    ON usage_records (organization_id, period_start, metric);

-- ---------------------------------------------------------------------------
-- Notifications
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS notifications (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id          uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    project_id       uuid REFERENCES projects(id) ON DELETE CASCADE,
    kind             text NOT NULL
                     CHECK (kind IN ('security','billing','system','content','lead','report')),
    title            text NOT NULL,
    body             text,
    action_url       text,
    read_at          timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS notifications_unread_idx
    ON notifications (user_id, created_at DESC) WHERE read_at IS NULL;

-- ---------------------------------------------------------------------------
-- AI conversations
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ai_conversations (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id          uuid REFERENCES users(id) ON DELETE SET NULL,
    title            text,
    -- Which module opened the conversation, for filtering and analytics.
    surface          text NOT NULL DEFAULT 'copilot'
                     CHECK (surface IN ('copilot','content','seo','aeo','campaign','report')),
    archived_at      timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ai_conversations_project_idx
    ON ai_conversations (project_id, updated_at DESC) WHERE archived_at IS NULL;

CREATE TABLE IF NOT EXISTS ai_messages (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id  uuid NOT NULL REFERENCES ai_conversations(id) ON DELETE CASCADE,
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    role             text NOT NULL CHECK (role IN ('user','assistant','system')),
    content          text NOT NULL,
    -- The workspace context the model was given, for user-facing provenance.
    context_sources  jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- Assistant output starts unreviewed; nothing publishes without approval.
    review_state     text NOT NULL DEFAULT 'pending'
                     CHECK (review_state IN ('pending','approved','rejected','not_applicable')),
    token_count      integer,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ai_messages_conversation_idx
    ON ai_messages (conversation_id, created_at);

-- ---------------------------------------------------------------------------
-- Audit log additions
-- ---------------------------------------------------------------------------

ALTER TABLE audit_log
    ADD COLUMN IF NOT EXISTS organization_id uuid REFERENCES organizations(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS ip_hash         bytea,
    ADD COLUMN IF NOT EXISTS user_agent      text,
    ADD COLUMN IF NOT EXISTS outcome         text NOT NULL DEFAULT 'success'
                                             CHECK (outcome IN ('success','failure','denied'));

CREATE INDEX IF NOT EXISTS audit_log_org_idx ON audit_log (organization_id, created_at DESC);
CREATE INDEX IF NOT EXISTS audit_log_actor_idx ON audit_log (actor_id, created_at DESC);

-- The audit log is append-only. Nothing in the application may update or delete
-- a row; a rule enforces it at the database level so a bug cannot erase history.
CREATE OR REPLACE RULE audit_log_no_update AS ON UPDATE TO audit_log DO INSTEAD NOTHING;
CREATE OR REPLACE RULE audit_log_no_delete AS ON DELETE TO audit_log DO INSTEAD NOTHING;

-- ---------------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------------
-- Second, independent barrier behind the repository-layer filter. The
-- application sets `app.current_organization` per connection after
-- authenticating; a query that forgets its WHERE clause still returns nothing.

ALTER TABLE businesses             ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects               ENABLE ROW LEVEL SECURITY;
ALTER TABLE marketing_profiles     ENABLE ROW LEVEL SECURITY;
ALTER TABLE website_crawl_consents ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions          ENABLE ROW LEVEL SECURITY;
ALTER TABLE usage_records          ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications          ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_conversations       ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_messages            ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
    target text;
BEGIN
    FOREACH target IN ARRAY ARRAY[
        'businesses','projects','marketing_profiles','website_crawl_consents',
        'subscriptions','usage_records','notifications','ai_conversations','ai_messages'
    ]
    LOOP
        EXECUTE format(
            'DROP POLICY IF EXISTS %I ON %I',
            target || '_tenant_isolation', target
        );
        EXECUTE format(
            'CREATE POLICY %I ON %I USING (organization_id = current_setting(%L, true)::uuid)',
            target || '_tenant_isolation', target, 'app.current_organization'
        );
    END LOOP;
END
$$;

-- ---------------------------------------------------------------------------
-- updated_at maintenance for the new tables
-- ---------------------------------------------------------------------------

CREATE TRIGGER businesses_updated_at BEFORE UPDATE ON businesses
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER projects_updated_at BEFORE UPDATE ON projects
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER marketing_profiles_updated_at BEFORE UPDATE ON marketing_profiles
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER subscriptions_updated_at BEFORE UPDATE ON subscriptions
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER ai_conversations_updated_at BEFORE UPDATE ON ai_conversations
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Account deletion
-- ---------------------------------------------------------------------------
-- Two-stage, so "delete my account" is immediate from the user's point of view
-- but recoverable from an accidental click, and so audit history survives.
--
-- Stage 1 (immediate, in the application): set deleted_at, revoke every session,
--   delete outstanding tokens. The account can no longer be used.
-- Stage 2 (scheduled job, after the retention window): call this function to
--   anonymise. Personal data is destroyed; the row remains so foreign keys and
--   audit records stay intact.

CREATE OR REPLACE FUNCTION anonymize_deleted_user(target_user uuid) RETURNS void AS $$
BEGIN
    UPDATE users
       SET email             = 'deleted-' || target_user || '@invalid',
           name              = NULL,
           password_hash     = NULL,
           timezone          = NULL,
           email_verified_at = NULL
     WHERE id = target_user
       AND deleted_at IS NOT NULL;

    DELETE FROM oauth_accounts             WHERE user_id = target_user;
    DELETE FROM sessions                   WHERE user_id = target_user;
    DELETE FROM email_verification_tokens  WHERE user_id = target_user;
    DELETE FROM password_reset_tokens      WHERE user_id = target_user;
    DELETE FROM notifications              WHERE user_id = target_user;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION anonymize_deleted_user IS
    'Stage 2 of account deletion. Destroys personal data, keeps the row so audit
     history and foreign keys remain valid. Run only after the retention window.';

COMMIT;
