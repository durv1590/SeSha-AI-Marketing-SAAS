-- ============================================================================
-- 0009 — Phase 9: the foreign keys 0008 did not reach.
--
-- FORWARD-ONLY. Indexes only; no table or column is changed.
--
-- The Phase 9 database audit parsed db/schema.sql and listed every column that
-- REFERENCES another table without an index whose LEADING column it is.
-- PostgreSQL does not index a referencing column for you, so each of these
-- made a DELETE of the parent row (an account deletion, an organization
-- deletion, a job cleanup) scan the child table. 0008 fixed seventeen; this
-- file fixes the remaining ones, and tests/database-audit.test.ts now fails if
-- a new unindexed foreign key is ever added.
--
-- CONCURRENTLY is not used for the reason given in 0008.
-- ============================================================================

BEGIN;

CREATE INDEX IF NOT EXISTS businesses_created_by_fk_idx ON businesses (created_by);
CREATE INDEX IF NOT EXISTS projects_business_id_fk_idx ON projects (business_id);
CREATE INDEX IF NOT EXISTS projects_created_by_fk_idx ON projects (created_by);
CREATE INDEX IF NOT EXISTS website_crawl_consents_organization_id_fk_idx ON website_crawl_consents (organization_id);
CREATE INDEX IF NOT EXISTS website_crawl_consents_granted_by_fk_idx ON website_crawl_consents (granted_by);
CREATE INDEX IF NOT EXISTS usage_records_project_id_fk_idx ON usage_records (project_id);
CREATE INDEX IF NOT EXISTS notifications_organization_id_fk_idx ON notifications (organization_id);
CREATE INDEX IF NOT EXISTS notifications_project_id_fk_idx ON notifications (project_id);
CREATE INDEX IF NOT EXISTS ai_conversations_organization_id_fk_idx ON ai_conversations (organization_id);
CREATE INDEX IF NOT EXISTS ai_conversations_user_id_fk_idx ON ai_conversations (user_id);
CREATE INDEX IF NOT EXISTS content_items_created_by_fk_idx ON content_items (created_by);
CREATE INDEX IF NOT EXISTS content_items_reviewed_by_fk_idx ON content_items (reviewed_by);
CREATE INDEX IF NOT EXISTS strategies_organization_id_fk_idx ON strategies (organization_id);
CREATE INDEX IF NOT EXISTS strategies_created_by_fk_idx ON strategies (created_by);
CREATE INDEX IF NOT EXISTS social_posts_created_by_fk_idx ON social_posts (created_by);
CREATE INDEX IF NOT EXISTS jobs_created_by_fk_idx ON jobs (created_by);
CREATE INDEX IF NOT EXISTS crawls_job_id_fk_idx ON crawls (job_id);
CREATE INDEX IF NOT EXISTS crawls_started_by_fk_idx ON crawls (started_by);
CREATE INDEX IF NOT EXISTS audits_job_id_fk_idx ON audits (job_id);
CREATE INDEX IF NOT EXISTS keywords_crawl_id_fk_idx ON keywords (crawl_id);
CREATE INDEX IF NOT EXISTS schema_validations_created_by_fk_idx ON schema_validations (created_by);
CREATE INDEX IF NOT EXISTS competitors_created_by_fk_idx ON competitors (created_by);
CREATE INDEX IF NOT EXISTS competitor_acknowledgements_project_id_fk_idx ON competitor_acknowledgements (project_id);
CREATE INDEX IF NOT EXISTS competitor_acknowledgements_acknowledged_by_fk_idx ON competitor_acknowledgements (acknowledged_by);
CREATE INDEX IF NOT EXISTS competitor_analyses_acknowledgement_id_fk_idx ON competitor_analyses (acknowledgement_id);
CREATE INDEX IF NOT EXISTS competitor_analyses_job_id_fk_idx ON competitor_analyses (job_id);
CREATE INDEX IF NOT EXISTS competitor_analyses_created_by_fk_idx ON competitor_analyses (created_by);
CREATE INDEX IF NOT EXISTS ad_plans_created_by_fk_idx ON ad_plans (created_by);
CREATE INDEX IF NOT EXISTS lead_activities_created_by_fk_idx ON lead_activities (created_by);
CREATE INDEX IF NOT EXISTS messaging_plans_created_by_fk_idx ON messaging_plans (created_by);
CREATE INDEX IF NOT EXISTS video_scripts_created_by_fk_idx ON video_scripts (created_by);
CREATE INDEX IF NOT EXISTS data_connections_project_id_fk_idx ON data_connections (project_id);
CREATE INDEX IF NOT EXISTS data_connections_connected_by_fk_idx ON data_connections (connected_by);
CREATE INDEX IF NOT EXISTS calendar_events_project_id_fk_idx ON calendar_events (project_id);
CREATE INDEX IF NOT EXISTS automation_rules_project_id_fk_idx ON automation_rules (project_id);
CREATE INDEX IF NOT EXISTS reports_project_id_fk_idx ON reports (project_id);
CREATE INDEX IF NOT EXISTS feature_flag_rules_updated_by_fk_idx ON feature_flag_rules (updated_by);
CREATE INDEX IF NOT EXISTS system_settings_updated_by_fk_idx ON system_settings (updated_by);
CREATE INDEX IF NOT EXISTS brand_kits_organization_id_fk_idx ON brand_kits (organization_id);
CREATE INDEX IF NOT EXISTS leads_created_by_fk_idx ON leads (created_by);
CREATE INDEX IF NOT EXISTS ad_plans_reviewed_by_fk_idx ON ad_plans (reviewed_by);

COMMIT;
