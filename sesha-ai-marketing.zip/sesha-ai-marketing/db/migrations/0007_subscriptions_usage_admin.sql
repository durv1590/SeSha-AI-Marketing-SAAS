-- ---------------------------------------------------------------------------
-- Migration 0007 — Phase 7: plans, usage, quotas, billing, the admin platform,
--                  feature flags
-- ---------------------------------------------------------------------------
-- Forward-only. Do not edit once applied; add a new migration instead.
--
-- Conventions carried forward: uuid keys, timestamptz, organization_id plus
-- row-level security on every tenant-scoped table, ON DELETE on every foreign
-- key, soft delete only where history references the row.
--
-- SIX DECISIONS IN HERE ARE LOAD-BEARING AND ARE NOT STYLISTIC:
--
-- 1. THE PLAN RENAME IS DONE IN THREE STEPS, NOT ONE. The CHECK is widened to
--    accept both vocabularies, the rows are migrated, and only then is it
--    narrowed. A single `ALTER ... CHECK (plan IN ('free',...))` would fail on
--    the first existing row and abort the whole migration. The mapping is
--    upward — `starter` was a PAID tier and becomes `pro`, never `free` — and
--    `tests/plans.test.ts` asserts no migrated organization loses a limit.
--
-- 2. `platform_staff` IS NOT A ROLE ON `memberships`. An organization admin is
--    a customer; a platform admin is staff. One table, one scale, one guard
--    each, and nothing in the organization role system grants anything here.
--    Putting platform access on `memberships.role` would let any customer who
--    made themselves an admin of their own workspace read every other
--    customer's data.
--
-- 3. `admin_actions` HAS NO CASCADE TO `organizations`. Every other
--    organization-scoped table cascades on delete, which is correct for
--    customer data and wrong for the record of what staff did: deleting a
--    tenant would erase the evidence of every admin action taken against it.
--    `target_organization_id` is a plain uuid with no foreign key for exactly
--    that reason, and the table has no UPDATE or DELETE policy.
--
-- 4. QUOTA REFUSALS GET THEIR OWN TABLE rather than a `refused` flag on
--    `usage_records`. A flag would mean every total had to remember to filter
--    it, and a forgotten filter over-counts usage — which wrongly BLOCKS a
--    paying customer. Separating them makes that mistake unavailable.
--
-- 5. THERE IS NO COLUMN ANYWHERE THAT COULD HOLD A CARD. No number, no token,
--    no CVV, no bank detail — not nullable, not "temporary". `subscriptions`
--    gains four display-metadata columns (brand, last four, expiry month and
--    year) which are what every provider returns and none of which can charge
--    anybody. `tests/billing.test.ts` greps every migration for the column
--    names a card would have.
--
-- 6. `billing_events.external_event_id` IS UNIQUE. Payment providers retry
--    webhooks and deliver them out of order; without an idempotency key, a
--    retried `payment_succeeded` is applied twice. The unique constraint is the
--    guarantee, not the application code that also checks.
-- ---------------------------------------------------------------------------

BEGIN;

-- ---------------------------------------------------------------------------
-- 1. The plan rename: widen, migrate, narrow
-- ---------------------------------------------------------------------------

ALTER TABLE organizations DROP CONSTRAINT IF EXISTS organizations_plan_check;
ALTER TABLE organizations ADD CONSTRAINT organizations_plan_check
    CHECK (plan IN ('starter','growth','agency','free','pro','business'));

ALTER TABLE subscriptions DROP CONSTRAINT IF EXISTS subscriptions_plan_check;
ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_plan_check
    CHECK (plan IN ('starter','growth','agency','free','pro','business'));

-- The mapping. Upward only: nobody moves to a plan with a lower limit.
--   starter -> pro        (both paid, comparable position)
--   growth  -> business
--   agency  -> agency     (unchanged)
-- Nobody is migrated to `free`, which is new.
UPDATE organizations SET plan = 'pro'      WHERE plan = 'starter';
UPDATE organizations SET plan = 'business' WHERE plan = 'growth';
UPDATE subscriptions SET plan = 'pro'      WHERE plan = 'starter';
UPDATE subscriptions SET plan = 'business' WHERE plan = 'growth';

ALTER TABLE organizations DROP CONSTRAINT organizations_plan_check;
ALTER TABLE organizations ADD CONSTRAINT organizations_plan_check
    CHECK (plan IN ('free','pro','business','agency'));
ALTER TABLE organizations ALTER COLUMN plan SET DEFAULT 'free';

ALTER TABLE subscriptions DROP CONSTRAINT subscriptions_plan_check;
ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_plan_check
    CHECK (plan IN ('free','pro','business','agency'));
ALTER TABLE subscriptions ALTER COLUMN plan SET DEFAULT 'free';

-- ---------------------------------------------------------------------------
-- 2. Subscription state
-- ---------------------------------------------------------------------------
-- `incomplete` is added because a checkout that was started and not finished is
-- not an active subscription, and treating it as one grants access to someone
-- who never paid.

ALTER TABLE subscriptions DROP CONSTRAINT IF EXISTS subscriptions_status_check;
ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_status_check
    CHECK (status IN ('trialing','active','past_due','canceled','paused','incomplete'));

ALTER TABLE subscriptions
    -- When the payment first failed, so the grace window can be measured. A
    -- past_due row with no timestamp gives the customer the benefit of the doubt.
    ADD COLUMN IF NOT EXISTS past_due_since      timestamptz,
    ADD COLUMN IF NOT EXISTS canceled_at         timestamptz,
    ADD COLUMN IF NOT EXISTS provider            text,
    -- DISPLAY METADATA ONLY. Nothing here can be used to charge anyone, and
-- there is deliberately no column for a number, a token, a CVV or a bank
    -- account. See decision 5 in the header.
    ADD COLUMN IF NOT EXISTS payment_brand       text,
    ADD COLUMN IF NOT EXISTS payment_last4       text
                                                 CHECK (payment_last4 IS NULL OR payment_last4 ~ '^[0-9]{4}$'),
    ADD COLUMN IF NOT EXISTS payment_expiry_month smallint
                                                 CHECK (payment_expiry_month IS NULL OR payment_expiry_month BETWEEN 1 AND 12),
    ADD COLUMN IF NOT EXISTS payment_expiry_year  smallint
                                                 CHECK (payment_expiry_year IS NULL OR payment_expiry_year BETWEEN 2000 AND 2100);

-- A past_due subscription must record when it went past due, or the grace
-- window cannot be measured and the customer is never cut off.
ALTER TABLE subscriptions DROP CONSTRAINT IF EXISTS subscriptions_past_due_dated;
ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_past_due_dated
    CHECK (status <> 'past_due' OR past_due_since IS NOT NULL);

-- ---------------------------------------------------------------------------
-- 3. Usage
-- ---------------------------------------------------------------------------
-- `seo_audit` and `aeo_audit` replace the single `audit_run`, because the brief
-- gives SEO and AEO separate limits and one counter cannot enforce two. The old
-- value is kept in the CHECK: rows already exist under it and rewriting history
-- to tidy an enum is worse than carrying one extra value.
--
-- `api_call` is new in Phase 7.

ALTER TABLE usage_records DROP CONSTRAINT IF EXISTS usage_records_metric_check;
ALTER TABLE usage_records ADD CONSTRAINT usage_records_metric_check
    CHECK (metric IN ('ai_generation','ai_tokens','content_item','crawl_page',
                      'crawl_run','audit_run','report','automation_run','seat',
                      'schema_validation','competitor_analysis','lead',
                      'calendar_event','report_export',
                      'seo_audit','aeo_audit','api_call'));

CREATE INDEX IF NOT EXISTS usage_records_period_idx
    ON usage_records (organization_id, period_start, metric);

-- Refusals, in their own table. See decision 4 in the header.
-- A customer blocked thirty times a day is a sales signal, and it is invisible
-- unless the refusal is recorded.
CREATE TABLE IF NOT EXISTS quota_refusals (
    id               bigserial PRIMARY KEY,
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid REFERENCES projects(id) ON DELETE SET NULL,
    user_id          uuid REFERENCES users(id) ON DELETE SET NULL,
    limit_id         text NOT NULL
                     CHECK (limit_id IN ('ai_requests','tokens','content_generations',
                                         'website_crawls','seo_audits','aeo_audits',
                                         'schema_validations','projects','team_members',
                                         'reports','automations')),
    reason           text NOT NULL
                     CHECK (reason IN ('period_exhausted','at_capacity','not_included',
                                       'subscription_blocked')),
    plan             text NOT NULL,
    -- What they had used and what the limit was, at the moment of refusal, so a
    -- later limit change does not rewrite the history of why someone was blocked.
    used_at_refusal  integer NOT NULL DEFAULT 0,
    limit_at_refusal integer,
    period_start     date NOT NULL,
    refused_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS quota_refusals_org_idx
    ON quota_refusals (organization_id, refused_at DESC);
CREATE INDEX IF NOT EXISTS quota_refusals_limit_idx
    ON quota_refusals (limit_id, refused_at DESC);

-- ---------------------------------------------------------------------------
-- 4. Plan limit overrides
-- ---------------------------------------------------------------------------
-- How "Admin controls: Plans, Limits" is satisfied without a deployment.
-- `reason` is NOT NULL because "why is this customer's limit 40?" gets asked,
-- and an override nobody can explain is an override nobody dares remove.

CREATE TABLE IF NOT EXISTS plan_limit_overrides (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    limit_id         text NOT NULL
                     CHECK (limit_id IN ('ai_requests','tokens','content_generations',
                                         'website_crawls','seo_audits','aeo_audits',
                                         'schema_validations','projects','team_members',
                                         'reports','automations')),
    -- NULL means unlimited. A negative value is refused: a negative ceiling
    -- makes every check fail with no message that makes sense.
    value            integer CHECK (value IS NULL OR value >= 0),
    reason           text NOT NULL CHECK (length(trim(reason)) > 0),
    set_by           uuid REFERENCES users(id) ON DELETE SET NULL,
    set_at           timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT plan_limit_overrides_unique UNIQUE (organization_id, limit_id)
);

-- ---------------------------------------------------------------------------
-- 5. Platform staff
-- ---------------------------------------------------------------------------
-- See decision 2 in the header. This table is the ONLY thing that grants admin
-- access, and a revoked row grants nothing — checked on every request rather
-- than trusted from a session, which could be thirty days old.

CREATE TABLE IF NOT EXISTS platform_staff (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      uuid NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    role         text NOT NULL CHECK (role IN ('support','engineer','platform_owner')),
    -- Who granted it. Nullable only for the first row, which has to be seeded.
    granted_by   uuid REFERENCES users(id) ON DELETE SET NULL,
    granted_at   timestamptz NOT NULL DEFAULT now(),
    revoked_by   uuid REFERENCES users(id) ON DELETE SET NULL,
    revoked_at   timestamptz,
    -- Why this person has platform access. Required: an unexplained staff row
    -- is the one nobody removes when someone changes team.
    reason       text NOT NULL CHECK (length(trim(reason)) > 0),
    CONSTRAINT platform_staff_revocation_complete
        CHECK ((revoked_at IS NULL) = (revoked_by IS NULL))
);

CREATE INDEX IF NOT EXISTS platform_staff_active_idx
    ON platform_staff (user_id) WHERE revoked_at IS NULL;

-- ---------------------------------------------------------------------------
-- 6. Admin actions
-- ---------------------------------------------------------------------------
-- Every admin action, INCLUDING READS. "Who looked at which customer" is the
-- question an audit log exists to answer, and a log of writes only cannot.
--
-- No cascade to organizations — see decision 3 in the header.

CREATE TABLE IF NOT EXISTS admin_actions (
    id                     bigserial PRIMARY KEY,
    staff_user_id          uuid REFERENCES users(id) ON DELETE SET NULL,
    staff_role             text NOT NULL,
    permission             text NOT NULL,
    action                 text NOT NULL,
    -- 'read' or 'write', so the log can be filtered to changes.
    kind                   text NOT NULL CHECK (kind IN ('read','write')),
    target_type            text NOT NULL,
    target_id              text,
    -- Deliberately NOT a foreign key. See decision 3.
    target_organization_id uuid,
    -- What changed, summarised. Never customer content: an audit log is not a
    -- second copy of the customer's data.
    metadata               jsonb NOT NULL DEFAULT '{}'::jsonb,
    outcome                text NOT NULL DEFAULT 'success'
                           CHECK (outcome IN ('success','failure','denied')),
    session_id             uuid,
    ip_hash                bytea,
    created_at             timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS admin_actions_staff_idx
    ON admin_actions (staff_user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS admin_actions_target_org_idx
    ON admin_actions (target_organization_id, created_at DESC);
CREATE INDEX IF NOT EXISTS admin_actions_writes_idx
    ON admin_actions (created_at DESC) WHERE kind = 'write';

-- ---------------------------------------------------------------------------
-- 7. Billing events
-- ---------------------------------------------------------------------------
-- The subscription's history, and the idempotency guarantee for webhooks.
--
-- `payload_summary` is a SUMMARY, not the raw body. A provider payload contains
-- more customer data than this product needs, and storing it wholesale would
-- create a second copy of it in a table an admin can read.

CREATE TABLE IF NOT EXISTS billing_events (
    id                   bigserial PRIMARY KEY,
    organization_id      uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    -- The provider's own event id. UNIQUE: see decision 6 in the header.
    external_event_id    text UNIQUE,
    provider             text NOT NULL,
    event                text NOT NULL
                         CHECK (event IN ('trial_started','checkout_completed',
                                          'payment_succeeded','payment_failed','renewed',
                                          'plan_changed','cancellation_requested',
                                          'cancellation_effective','paused','resumed')),
    status_before        text,
    status_after         text,
    plan_before          text,
    plan_after           text,
    -- Recorded even when the event changed nothing, with the reason. An ignored
    -- webhook is normal and must be visible, not silent.
    applied              boolean NOT NULL DEFAULT true,
    note                 text,
    payload_summary      jsonb NOT NULL DEFAULT '{}'::jsonb,
    occurred_at          timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS billing_events_org_idx
    ON billing_events (organization_id, occurred_at DESC);

-- ---------------------------------------------------------------------------
-- 8. Feature flag rules
-- ---------------------------------------------------------------------------
-- One row per flag. The key is constrained to the application's registry by the
-- application, not here: the registry is code, and a CHECK listing every flag
-- would need a migration to add one. `disabled` is the kill switch and beats
-- every other column.

CREATE TABLE IF NOT EXISTS feature_flag_rules (
    key                        text PRIMARY KEY,
    disabled                   boolean NOT NULL DEFAULT false,
    organization_ids           uuid[] NOT NULL DEFAULT ARRAY[]::uuid[],
    excluded_organization_ids  uuid[] NOT NULL DEFAULT ARRAY[]::uuid[],
    plans                      text[] NOT NULL DEFAULT ARRAY[]::text[],
    rollout_percent            smallint NOT NULL DEFAULT 0
                               CHECK (rollout_percent BETWEEN 0 AND 100),
    updated_by                 uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_at                 timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- 9. System settings
-- ---------------------------------------------------------------------------
-- Backs the brief's Templates, Prompts, Validator configuration and System
-- configuration controls. One table with a namespaced key, and — as with flags —
-- the set of permitted keys is a registry in code, so a setting cannot be
-- created by typing a new name into a form and then never found again.

CREATE TABLE IF NOT EXISTS system_settings (
    key         text PRIMARY KEY,
    value       jsonb NOT NULL,
    updated_by  uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_at  timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- 10. Errors
-- ---------------------------------------------------------------------------
-- Backs the "Errors" dashboard. `fingerprint` groups recurrences so the panel
-- shows twelve distinct problems rather than nine thousand lines.
--
-- NO STACK TRACE AND NO REQUEST BODY. A stack can contain a token read from a
-- header and a body can contain a customer's content; this table is read by
-- staff, so it holds only what is needed to find the problem in the code.

CREATE TABLE IF NOT EXISTS error_events (
    id               bigserial PRIMARY KEY,
    fingerprint      text NOT NULL,
    severity         text NOT NULL CHECK (severity IN ('warning','error','critical')),
    source           text NOT NULL,
    message          text NOT NULL,
    -- Which tenant hit it, for support. Nullable: a public-site error has none.
    organization_id  uuid REFERENCES organizations(id) ON DELETE SET NULL,
    occurrences      integer NOT NULL DEFAULT 1 CHECK (occurrences > 0),
    first_seen_at    timestamptz NOT NULL DEFAULT now(),
    last_seen_at     timestamptz NOT NULL DEFAULT now(),
    resolved_at      timestamptz,
    resolved_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT error_events_fingerprint_unique UNIQUE (fingerprint)
);

CREATE INDEX IF NOT EXISTS error_events_open_idx
    ON error_events (last_seen_at DESC) WHERE resolved_at IS NULL;

-- ---------------------------------------------------------------------------
-- 11. Feedback
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS feedback (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid REFERENCES organizations(id) ON DELETE SET NULL,
    user_id          uuid REFERENCES users(id) ON DELETE SET NULL,
    kind             text NOT NULL CHECK (kind IN ('bug','idea','praise','other')),
    message          text NOT NULL CHECK (length(trim(message)) > 0),
    -- Which screen it came from, so a report is actionable.
    surface          text,
    status           text NOT NULL DEFAULT 'new'
                     CHECK (status IN ('new','triaged','answered','closed')),
    triaged_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    triaged_at       timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS feedback_status_idx ON feedback (status, created_at DESC);

-- ---------------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------------
-- The tenant-scoped tables get the same policy as every other. The PLATFORM
-- tables deliberately do not: `platform_staff`, `admin_actions`,
-- `feature_flag_rules`, `system_settings` and `error_events` are not tenant
-- data and have no organization to scope to. They are reached only through the
-- admin service, which runs on a connection that does not set
-- `app.current_organization`, and are never exposed to a tenant-facing route.

ALTER TABLE quota_refusals       ENABLE ROW LEVEL SECURITY;
ALTER TABLE plan_limit_overrides ENABLE ROW LEVEL SECURITY;
ALTER TABLE billing_events       ENABLE ROW LEVEL SECURITY;
ALTER TABLE feedback             ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
    target text;
BEGIN
    FOREACH target IN ARRAY ARRAY['quota_refusals','plan_limit_overrides','billing_events']
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON %I', target || '_tenant_isolation', target);
        EXECUTE format(
            'CREATE POLICY %I ON %I USING (organization_id = current_setting(%L, true)::uuid)',
            target || '_tenant_isolation', target, 'app.current_organization'
        );
    END LOOP;
END
$$;

-- Feedback's organization_id is nullable (the public site has none), so its
-- policy has to permit a null row rather than comparing it and getting NULL,
-- which would silently hide every anonymous submission from everyone.
DROP POLICY IF EXISTS feedback_tenant_isolation ON feedback;
CREATE POLICY feedback_tenant_isolation ON feedback
    USING (organization_id IS NULL
           OR organization_id = current_setting('app.current_organization', true)::uuid);

-- ---------------------------------------------------------------------------
-- updated_at maintenance
-- ---------------------------------------------------------------------------

CREATE TRIGGER feature_flag_rules_updated_at BEFORE UPDATE ON feature_flag_rules
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER system_settings_updated_at BEFORE UPDATE ON system_settings
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Account deletion
-- ---------------------------------------------------------------------------
-- Feedback a user wrote is personal data and goes with them. Their platform
-- staff row goes too — a deleted account must not retain admin access.
--
-- `admin_actions.staff_user_id` is ON DELETE SET NULL rather than cascading:
-- the record of what was done survives the person who did it, which is the
-- entire point of an audit log.

CREATE OR REPLACE FUNCTION anonymize_deleted_user(target_user uuid) RETURNS void AS $$
BEGIN
    UPDATE users
       SET email             = 'deleted-' || target_user || '@invalid',
           name              = NULL,
           password_hash     = NULL,
           timezone          = NULL,
           email_verified_at = NULL
     WHERE id = target_user
       AND deleted_at IS NOT NULL;

    DELETE FROM oauth_accounts             WHERE user_id = target_user;
    DELETE FROM sessions                   WHERE user_id = target_user;
    DELETE FROM email_verification_tokens  WHERE user_id = target_user;
    DELETE FROM password_reset_tokens      WHERE user_id = target_user;
    DELETE FROM notifications              WHERE user_id = target_user;
    DELETE FROM notification_preferences   WHERE user_id = target_user;
    DELETE FROM platform_staff             WHERE user_id = target_user;
    DELETE FROM feedback                   WHERE user_id = target_user;
END;
$$ LANGUAGE plpgsql;

COMMENT ON TABLE platform_staff IS
    'The only thing that grants admin access. An organization admin is a
     customer and is NOT platform staff. A revoked row grants nothing.';
COMMENT ON TABLE admin_actions IS
    'Every admin action including reads. No cascade to organizations: deleting a
     tenant must not erase the record of what staff did to it.';
COMMENT ON TABLE quota_refusals IS
    'Separate from usage_records so a forgotten filter cannot over-count usage
     and wrongly block a paying customer.';
COMMENT ON COLUMN subscriptions.payment_last4 IS
    'Display metadata only. There is deliberately no column anywhere for a card
     number, token, CVV or bank detail.';

COMMIT;
