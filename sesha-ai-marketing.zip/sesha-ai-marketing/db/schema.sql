-- ---------------------------------------------------------------------------
-- SeSha AI Marketing — full schema
-- ---------------------------------------------------------------------------
-- GENERATED FILE. Do not edit.
-- Source of truth: db/migrations/*.sql (forward-only).
-- Regenerate with: node scripts/build-schema.mjs
-- ---------------------------------------------------------------------------

-- ===== 0001_init.sql ===============================================

-- Migration 0001 — Phase 1 baseline.
-- Forward-only. Do not edit once applied; add a new migration instead.

-- ---------------------------------------------------------------------------
-- SeSha AI Marketing — PostgreSQL schema
-- ---------------------------------------------------------------------------
-- Phase 1 does NOT run this. It is the target shape the repository interfaces
-- in src/lib/db are written against, checked in now so Phase 2 starts from a
-- reviewed design rather than an improvised one.
--
-- Conventions:
--   * UUID primary keys generated in the database.
--   * timestamptz everywhere; never a naive timestamp.
--   * Tenant isolation on organization_id, enforced by row-level security in
--     addition to repository-level filtering (defence in depth).
--   * citext for emails so uniqueness is case-insensitive.
-- ---------------------------------------------------------------------------

CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";

-- --------------------------------------------------------------------------
-- Tenancy and identity
-- --------------------------------------------------------------------------

CREATE TABLE organizations (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name        text NOT NULL CHECK (length(btrim(name)) > 0),
    slug        citext NOT NULL UNIQUE,
    plan        text NOT NULL DEFAULT 'starter'
                CHECK (plan IN ('starter', 'growth', 'agency')),
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE users (
    id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email              citext NOT NULL UNIQUE,
    name               text,
    -- Argon2id encoded hash. NULL for accounts that only use SSO.
    password_hash      text,
    email_verified_at  timestamptz,
    last_login_at      timestamptz,
    created_at         timestamptz NOT NULL DEFAULT now(),
    updated_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE memberships (
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id          uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role             text NOT NULL DEFAULT 'viewer'
                     CHECK (role IN ('owner', 'admin', 'editor', 'viewer')),
    created_at       timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (organization_id, user_id)
);

CREATE INDEX memberships_user_idx ON memberships (user_id);

-- Server-side sessions. The cookie holds an opaque token, never a JWT payload.
CREATE TABLE sessions (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    -- SHA-256 of the token; a database leak must not yield usable sessions.
    token_hash   bytea NOT NULL UNIQUE,
    user_agent   text,
    ip_hash      bytea,
    expires_at   timestamptz NOT NULL,
    revoked_at   timestamptz,
    created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX sessions_user_idx ON sessions (user_id);
CREATE INDEX sessions_expiry_idx ON sessions (expires_at) WHERE revoked_at IS NULL;

-- --------------------------------------------------------------------------
-- Workspaces and brand
-- --------------------------------------------------------------------------

CREATE TABLE workspaces (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name             text NOT NULL,
    slug             citext NOT NULL,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, slug)
);

CREATE TABLE brand_kits (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id  uuid NOT NULL UNIQUE REFERENCES workspaces(id) ON DELETE CASCADE,
    voice         text,
    tone_rules    text,
    terminology   jsonb NOT NULL DEFAULT '{}'::jsonb,
    palette       jsonb NOT NULL DEFAULT '{}'::jsonb,
    updated_at    timestamptz NOT NULL DEFAULT now()
);

-- --------------------------------------------------------------------------
-- Content
-- --------------------------------------------------------------------------

CREATE TABLE posts (
    id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id   uuid REFERENCES workspaces(id) ON DELETE CASCADE,
    slug           citext NOT NULL,
    title          text NOT NULL,
    excerpt        text NOT NULL,
    -- AEO: the quotable answer, stored separately so it is never buried.
    direct_answer  text NOT NULL,
    body           jsonb NOT NULL DEFAULT '[]'::jsonb,
    author_id      text NOT NULL,
    category       text NOT NULL,
    status         text NOT NULL DEFAULT 'draft'
                   CHECK (status IN ('draft', 'in_review', 'published', 'archived')),
    -- Enforces the rule that a published post must have a publication date.
    published_at   timestamptz,
    updated_at     timestamptz NOT NULL DEFAULT now(),
    created_at     timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT posts_published_has_date
        CHECK (status <> 'published' OR published_at IS NOT NULL)
);

CREATE UNIQUE INDEX posts_workspace_slug_idx ON posts (workspace_id, slug);
CREATE INDEX posts_published_idx ON posts (published_at DESC) WHERE status = 'published';

-- --------------------------------------------------------------------------
-- Public site: inbound
-- --------------------------------------------------------------------------

CREATE TABLE contact_submissions (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name         text NOT NULL,
    email        citext NOT NULL,
    company      text,
    topic        text NOT NULL
                 CHECK (topic IN ('product','pricing','partnership','support','security','other')),
    message      text NOT NULL,
    source_path  text,
    handled_at   timestamptz,
    created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX contact_submissions_created_idx ON contact_submissions (created_at DESC);
CREATE INDEX contact_submissions_open_idx ON contact_submissions (created_at DESC)
    WHERE handled_at IS NULL;

CREATE TABLE newsletter_subscribers (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email            citext NOT NULL UNIQUE,
    confirmed_at     timestamptz,
    unsubscribed_at  timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE leads (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    email            citext NOT NULL,
    name             text,
    -- Attribution captured at creation, never reconstructed later.
    source_path      text,
    source_campaign  text,
    status           text NOT NULL DEFAULT 'new'
                     CHECK (status IN ('new','qualified','contacted','won','lost')),
    owner_user_id    uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX leads_org_created_idx ON leads (organization_id, created_at DESC);

-- --------------------------------------------------------------------------
-- Audit
-- --------------------------------------------------------------------------

CREATE TABLE audit_log (
    id           bigserial PRIMARY KEY,
    actor_id     uuid REFERENCES users(id) ON DELETE SET NULL,
    action       text NOT NULL,
    entity_type  text NOT NULL,
    entity_id    text,
    metadata     jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX audit_log_entity_idx ON audit_log (entity_type, entity_id, created_at DESC);

-- --------------------------------------------------------------------------
-- Row-level security (defence in depth behind repository-level filtering)
-- --------------------------------------------------------------------------

ALTER TABLE workspaces ENABLE ROW LEVEL SECURITY;
ALTER TABLE brand_kits ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts      ENABLE ROW LEVEL SECURITY;
ALTER TABLE leads      ENABLE ROW LEVEL SECURITY;

-- The application sets `app.current_organization` per connection after auth.
CREATE POLICY workspaces_tenant_isolation ON workspaces
    USING (organization_id = current_setting('app.current_organization', true)::uuid);

CREATE POLICY leads_tenant_isolation ON leads
    USING (organization_id = current_setting('app.current_organization', true)::uuid);

-- --------------------------------------------------------------------------
-- updated_at maintenance
-- --------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER organizations_updated_at BEFORE UPDATE ON organizations
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER workspaces_updated_at BEFORE UPDATE ON workspaces
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER posts_updated_at BEFORE UPDATE ON posts
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ===== 0002_accounts.sql ===========================================

-- ---------------------------------------------------------------------------
-- Migration 0002 — Phase 2: authentication, accounts, businesses, projects
-- ---------------------------------------------------------------------------
-- Forward-only. Do not edit once applied; add a new migration instead.
--
-- Conventions carried forward from 0001:
--   * uuid primary keys generated in the database
--   * timestamptz everywhere
--   * citext for email, so uniqueness is case-insensitive
--   * tenant isolation on organization_id, enforced by RLS as well as by the
--     repository layer
--
-- SOFT DELETE POLICY (deliberate, per-table):
--   * users, organizations, businesses, projects  -> soft delete (deleted_at).
--     These are referenced by audit records and by the user's own data; a hard
--     delete would orphan history or cascade far wider than intended.
--   * sessions, tokens, login_attempts            -> HARD delete / expiry.
--     Keeping a revoked session row "soft deleted" is a liability, not history.
--   * A user who requests account deletion is soft-deleted immediately
--     (sign-in blocked, sessions revoked, email released via anonymisation) and
--     purged by a scheduled job after the retention window. See
--     `anonymize_deleted_user` at the end of this file.
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- Users: additions for authentication and lifecycle
-- ---------------------------------------------------------------------------

ALTER TABLE users
    ADD COLUMN IF NOT EXISTS onboarding_completed_at  timestamptz,
    ADD COLUMN IF NOT EXISTS deleted_at               timestamptz,
    ADD COLUMN IF NOT EXISTS deletion_requested_at    timestamptz,
    ADD COLUMN IF NOT EXISTS password_changed_at      timestamptz,
    ADD COLUMN IF NOT EXISTS locale                   text NOT NULL DEFAULT 'en',
    ADD COLUMN IF NOT EXISTS timezone                 text;

-- A user with no password_hash must have at least one OAuth account; enforced
-- in the application because the check spans two tables.
COMMENT ON COLUMN users.password_hash IS
    'scrypt encoded hash (see src/lib/auth/password.ts). NULL means OAuth-only.';

-- Active (non-deleted) email uniqueness. The plain UNIQUE from 0001 would block
-- a new signup on an address whose previous account was soft-deleted, so the
-- constraint is replaced by a partial index.
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_email_key;
CREATE UNIQUE INDEX IF NOT EXISTS users_email_active_idx
    ON users (email) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS users_deleted_idx ON users (deleted_at) WHERE deleted_at IS NOT NULL;

-- ---------------------------------------------------------------------------
-- Sessions: additions for idle timeout, sudo mode and device display
-- ---------------------------------------------------------------------------

ALTER TABLE sessions
    ADD COLUMN IF NOT EXISTS last_active_at timestamptz NOT NULL DEFAULT now(),
    ADD COLUMN IF NOT EXISTS sudo_until     timestamptz;

CREATE INDEX IF NOT EXISTS sessions_active_idx
    ON sessions (user_id, last_active_at DESC) WHERE revoked_at IS NULL;

COMMENT ON COLUMN sessions.token_hash IS
    'SHA-256 of the opaque session token. The token itself is never stored.';

-- ---------------------------------------------------------------------------
-- OAuth accounts (Google, and any future provider)
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS oauth_accounts (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id           uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider          text NOT NULL CHECK (provider IN ('google')),
    -- The provider's stable subject identifier. NOT the email: an email can be
    -- reassigned by a Workspace admin, `sub` cannot.
    provider_user_id  text NOT NULL,
    email             citext,
    email_verified    boolean NOT NULL DEFAULT false,
    created_at        timestamptz NOT NULL DEFAULT now(),
    last_login_at     timestamptz,
    UNIQUE (provider, provider_user_id)
);

CREATE INDEX IF NOT EXISTS oauth_accounts_user_idx ON oauth_accounts (user_id);

-- ---------------------------------------------------------------------------
-- Email verification and password reset
-- ---------------------------------------------------------------------------
-- Both store only a SHA-256 hash of the token. Both are single-use: `used_at`
-- is set on redemption, and redemption checks it, so a leaked link cannot be
-- replayed.

CREATE TABLE IF NOT EXISTS email_verification_tokens (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash  bytea NOT NULL UNIQUE,
    email       citext NOT NULL,
    expires_at  timestamptz NOT NULL,
    used_at     timestamptz,
    created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS email_verification_user_idx ON email_verification_tokens (user_id);

CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash  bytea NOT NULL UNIQUE,
    expires_at  timestamptz NOT NULL,
    used_at     timestamptz,
    -- Recorded for the security-notification email, hashed not raw.
    ip_hash     bytea,
    created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS password_reset_user_idx ON password_reset_tokens (user_id);

-- ---------------------------------------------------------------------------
-- Login attempts — durable brute-force counters
-- ---------------------------------------------------------------------------
-- The in-process limiter in src/lib/auth/lockout.ts is correct for a single
-- instance. This table is the shared store a multi-instance deployment needs:
-- without it an attacker simply spreads attempts across instances.

CREATE TABLE IF NOT EXISTS login_attempts (
    id           bigserial PRIMARY KEY,
    -- 'account:<email>' or 'address:<ip-hash>'
    scope_key    text NOT NULL,
    succeeded    boolean NOT NULL,
    attempted_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS login_attempts_scope_idx
    ON login_attempts (scope_key, attempted_at DESC);

-- ---------------------------------------------------------------------------
-- Businesses
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS businesses (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name             text NOT NULL CHECK (length(btrim(name)) > 0),
    industry         text,
    country          text,
    city             text,
    website_url      text,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at       timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS businesses_org_idx
    ON businesses (organization_id) WHERE deleted_at IS NULL;

-- ---------------------------------------------------------------------------
-- Projects — the tenant-isolation unit
-- ---------------------------------------------------------------------------
-- Every piece of customer data below hangs off a project, and every project
-- hangs off an organization. A query that filters by project_id alone is a bug:
-- always filter by organization_id as well, which is what RLS enforces.

CREATE TABLE IF NOT EXISTS projects (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    business_id      uuid REFERENCES businesses(id) ON DELETE SET NULL,
    name             text NOT NULL CHECK (length(btrim(name)) > 0),
    slug             citext NOT NULL,
    description      text,
    status           text NOT NULL DEFAULT 'active'
                     CHECK (status IN ('active', 'paused', 'archived')),
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at       timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);

-- Slug unique per organization, among live projects only.
CREATE UNIQUE INDEX IF NOT EXISTS projects_org_slug_idx
    ON projects (organization_id, slug) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS projects_org_idx
    ON projects (organization_id, created_at DESC) WHERE deleted_at IS NULL;

-- ---------------------------------------------------------------------------
-- AI Marketing Profile — the onboarding output
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS marketing_profiles (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL UNIQUE REFERENCES projects(id) ON DELETE CASCADE,
    target_audience   text,
    products_services text,
    price_range       text CHECK (price_range IS NULL OR price_range IN
                        ('budget', 'mid_market', 'premium', 'luxury', 'varies')),
    marketing_goals   jsonb NOT NULL DEFAULT '[]'::jsonb,
    marketing_channels jsonb NOT NULL DEFAULT '[]'::jsonb,
    brand_voice       jsonb NOT NULL DEFAULT '{}'::jsonb,
    competitors       jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- Completeness drives the onboarding progress indicator. Derived, but
    -- stored so list queries do not have to recompute it.
    completeness      smallint NOT NULL DEFAULT 0
                      CHECK (completeness BETWEEN 0 AND 100),
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS marketing_profiles_org_idx ON marketing_profiles (organization_id);

-- ---------------------------------------------------------------------------
-- Website crawl consent
-- ---------------------------------------------------------------------------
-- NOTHING may crawl a customer's website without a row here. The consent record
-- captures WHAT was agreed, WHEN, and BY WHOM, and is revocable. Storing the
-- scope alongside the grant means a later change to default crawl behaviour
-- cannot retroactively widen an existing consent.

CREATE TABLE IF NOT EXISTS website_crawl_consents (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    website_url      text NOT NULL,
    granted_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    granted_at       timestamptz NOT NULL DEFAULT now(),
    revoked_at       timestamptz,
    -- The exact terms shown to the user, so consent is auditable against the
    -- wording that was actually presented.
    consent_version  text NOT NULL,
    max_pages        integer NOT NULL DEFAULT 100 CHECK (max_pages > 0 AND max_pages <= 5000),
    respect_robots   boolean NOT NULL DEFAULT true,
    retention_days   integer NOT NULL DEFAULT 90 CHECK (retention_days > 0),
    -- Set when the user asks for crawled data to be erased.
    data_deleted_at  timestamptz
);

CREATE INDEX IF NOT EXISTS crawl_consents_project_idx
    ON website_crawl_consents (project_id) WHERE revoked_at IS NULL;

-- ---------------------------------------------------------------------------
-- Brand kits — re-scoped from workspace to project
-- ---------------------------------------------------------------------------

ALTER TABLE brand_kits
    ADD COLUMN IF NOT EXISTS organization_id uuid REFERENCES organizations(id) ON DELETE CASCADE,
    ADD COLUMN IF NOT EXISTS project_id      uuid REFERENCES projects(id) ON DELETE CASCADE,
    ADD COLUMN IF NOT EXISTS logo_url        text,
    ADD COLUMN IF NOT EXISTS created_at      timestamptz NOT NULL DEFAULT now();

ALTER TABLE brand_kits ALTER COLUMN workspace_id DROP NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS brand_kits_project_idx
    ON brand_kits (project_id) WHERE project_id IS NOT NULL;

-- ---------------------------------------------------------------------------
-- Subscriptions and usage
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS subscriptions (
    id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id      uuid NOT NULL UNIQUE REFERENCES organizations(id) ON DELETE CASCADE,
    plan                 text NOT NULL DEFAULT 'starter'
                         CHECK (plan IN ('starter', 'growth', 'agency')),
    status               text NOT NULL DEFAULT 'trialing'
                         CHECK (status IN ('trialing','active','past_due','canceled','paused')),
    -- Set only by the billing provider webhook; never by the application.
    external_customer_id text,
    external_subscription_id text,
    current_period_start timestamptz,
    current_period_end   timestamptz,
    cancel_at_period_end boolean NOT NULL DEFAULT false,
    trial_ends_at        timestamptz,
    created_at           timestamptz NOT NULL DEFAULT now(),
    updated_at           timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS usage_records (
    id               bigserial PRIMARY KEY,
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid REFERENCES projects(id) ON DELETE SET NULL,
    metric           text NOT NULL
                     CHECK (metric IN ('ai_generation','content_item','crawl_page',
                                       'report','automation_run','seat')),
    quantity         integer NOT NULL DEFAULT 1 CHECK (quantity > 0),
    -- First day of the billing month, so a month's usage is one indexed range.
    period_start     date NOT NULL,
    recorded_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS usage_org_period_idx
    ON usage_records (organization_id, period_start, metric);

-- ---------------------------------------------------------------------------
-- Notifications
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS notifications (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id          uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    project_id       uuid REFERENCES projects(id) ON DELETE CASCADE,
    kind             text NOT NULL
                     CHECK (kind IN ('security','billing','system','content','lead','report')),
    title            text NOT NULL,
    body             text,
    action_url       text,
    read_at          timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS notifications_unread_idx
    ON notifications (user_id, created_at DESC) WHERE read_at IS NULL;

-- ---------------------------------------------------------------------------
-- AI conversations
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ai_conversations (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id          uuid REFERENCES users(id) ON DELETE SET NULL,
    title            text,
    -- Which module opened the conversation, for filtering and analytics.
    surface          text NOT NULL DEFAULT 'copilot'
                     CHECK (surface IN ('copilot','content','seo','aeo','campaign','report')),
    archived_at      timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ai_conversations_project_idx
    ON ai_conversations (project_id, updated_at DESC) WHERE archived_at IS NULL;

CREATE TABLE IF NOT EXISTS ai_messages (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id  uuid NOT NULL REFERENCES ai_conversations(id) ON DELETE CASCADE,
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    role             text NOT NULL CHECK (role IN ('user','assistant','system')),
    content          text NOT NULL,
    -- The workspace context the model was given, for user-facing provenance.
    context_sources  jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- Assistant output starts unreviewed; nothing publishes without approval.
    review_state     text NOT NULL DEFAULT 'pending'
                     CHECK (review_state IN ('pending','approved','rejected','not_applicable')),
    token_count      integer,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ai_messages_conversation_idx
    ON ai_messages (conversation_id, created_at);

-- ---------------------------------------------------------------------------
-- Audit log additions
-- ---------------------------------------------------------------------------

ALTER TABLE audit_log
    ADD COLUMN IF NOT EXISTS organization_id uuid REFERENCES organizations(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS ip_hash         bytea,
    ADD COLUMN IF NOT EXISTS user_agent      text,
    ADD COLUMN IF NOT EXISTS outcome         text NOT NULL DEFAULT 'success'
                                             CHECK (outcome IN ('success','failure','denied'));

CREATE INDEX IF NOT EXISTS audit_log_org_idx ON audit_log (organization_id, created_at DESC);
CREATE INDEX IF NOT EXISTS audit_log_actor_idx ON audit_log (actor_id, created_at DESC);

-- The audit log is append-only. Nothing in the application may update or delete
-- a row; a rule enforces it at the database level so a bug cannot erase history.
CREATE OR REPLACE RULE audit_log_no_update AS ON UPDATE TO audit_log DO INSTEAD NOTHING;
CREATE OR REPLACE RULE audit_log_no_delete AS ON DELETE TO audit_log DO INSTEAD NOTHING;

-- ---------------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------------
-- Second, independent barrier behind the repository-layer filter. The
-- application sets `app.current_organization` per connection after
-- authenticating; a query that forgets its WHERE clause still returns nothing.

ALTER TABLE businesses             ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects               ENABLE ROW LEVEL SECURITY;
ALTER TABLE marketing_profiles     ENABLE ROW LEVEL SECURITY;
ALTER TABLE website_crawl_consents ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions          ENABLE ROW LEVEL SECURITY;
ALTER TABLE usage_records          ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications          ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_conversations       ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_messages            ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
    target text;
BEGIN
    FOREACH target IN ARRAY ARRAY[
        'businesses','projects','marketing_profiles','website_crawl_consents',
        'subscriptions','usage_records','notifications','ai_conversations','ai_messages'
    ]
    LOOP
        EXECUTE format(
            'DROP POLICY IF EXISTS %I ON %I',
            target || '_tenant_isolation', target
        );
        EXECUTE format(
            'CREATE POLICY %I ON %I USING (organization_id = current_setting(%L, true)::uuid)',
            target || '_tenant_isolation', target, 'app.current_organization'
        );
    END LOOP;
END
$$;

-- ---------------------------------------------------------------------------
-- updated_at maintenance for the new tables
-- ---------------------------------------------------------------------------

CREATE TRIGGER businesses_updated_at BEFORE UPDATE ON businesses
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER projects_updated_at BEFORE UPDATE ON projects
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER marketing_profiles_updated_at BEFORE UPDATE ON marketing_profiles
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER subscriptions_updated_at BEFORE UPDATE ON subscriptions
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER ai_conversations_updated_at BEFORE UPDATE ON ai_conversations
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Account deletion
-- ---------------------------------------------------------------------------
-- Two-stage, so "delete my account" is immediate from the user's point of view
-- but recoverable from an accidental click, and so audit history survives.
--
-- Stage 1 (immediate, in the application): set deleted_at, revoke every session,
--   delete outstanding tokens. The account can no longer be used.
-- Stage 2 (scheduled job, after the retention window): call this function to
--   anonymise. Personal data is destroyed; the row remains so foreign keys and
--   audit records stay intact.

CREATE OR REPLACE FUNCTION anonymize_deleted_user(target_user uuid) RETURNS void AS $$
BEGIN
    UPDATE users
       SET email             = 'deleted-' || target_user || '@invalid',
           name              = NULL,
           password_hash     = NULL,
           timezone          = NULL,
           email_verified_at = NULL
     WHERE id = target_user
       AND deleted_at IS NOT NULL;

    DELETE FROM oauth_accounts             WHERE user_id = target_user;
    DELETE FROM sessions                   WHERE user_id = target_user;
    DELETE FROM email_verification_tokens  WHERE user_id = target_user;
    DELETE FROM password_reset_tokens      WHERE user_id = target_user;
    DELETE FROM notifications              WHERE user_id = target_user;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION anonymize_deleted_user IS
    'Stage 2 of account deletion. Destroys personal data, keeps the row so audit
     history and foreign keys remain valid. Run only after the retention window.';

-- ===== 0003_ai_content.sql =========================================

-- ---------------------------------------------------------------------------
-- Migration 0003 — Phase 3: AI generation, strategy, content and social
-- ---------------------------------------------------------------------------
-- Forward-only. Do not edit once applied; add a new migration instead.
--
-- Conventions carried forward: uuid keys, timestamptz, organization_id plus
-- row-level security on every tenant-scoped table, ON DELETE on every foreign
-- key, soft delete only where audit history references the row.
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- Usage: token accounting
-- ---------------------------------------------------------------------------
-- AI cost has two dimensions that behave differently: the NUMBER of
-- generations (a fair-use limit) and the TOKENS they consumed (the actual
-- spend). One long strategy can cost more than fifty captions, so counting
-- generations alone would not bound the bill.

ALTER TABLE usage_records DROP CONSTRAINT IF EXISTS usage_records_metric_check;
ALTER TABLE usage_records ADD CONSTRAINT usage_records_metric_check
    CHECK (metric IN ('ai_generation','ai_tokens','content_item','crawl_page',
                      'report','automation_run','seat'));

-- ---------------------------------------------------------------------------
-- AI messages: cost and provenance
-- ---------------------------------------------------------------------------

ALTER TABLE ai_messages
    ADD COLUMN IF NOT EXISTS provider        text,
    ADD COLUMN IF NOT EXISTS model           text,
    ADD COLUMN IF NOT EXISTS agent           text,
    ADD COLUMN IF NOT EXISTS input_tokens    integer,
    ADD COLUMN IF NOT EXISTS output_tokens   integer,
    ADD COLUMN IF NOT EXISTS cached          boolean NOT NULL DEFAULT false,
    -- The provenance-tagged blocks exactly as parsed. Stored rather than
    -- flattened to text so the interface can re-render the labels, and so a
    -- claim can be traced back to how it was sourced long after the fact.
    ADD COLUMN IF NOT EXISTS blocks          jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- Findings from the claim linter. A message with errors was shown with a
    -- warning; keeping them means the record reflects what the user actually saw.
    ADD COLUMN IF NOT EXISTS claim_warnings  jsonb NOT NULL DEFAULT '[]'::jsonb;

CREATE INDEX IF NOT EXISTS ai_messages_org_created_idx
    ON ai_messages (organization_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- Content items
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS content_items (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,

    -- One of the twenty formats in src/lib/content/types.ts. Not constrained to
    -- an enum here: the list grows every phase, and a CHECK would mean a
    -- migration each time. The application validates against the typed list.
    format           text NOT NULL,
    title            text NOT NULL,
    body             text NOT NULL,

    language         text NOT NULL DEFAULT 'en'
                     CHECK (language IN ('en','hi','hinglish')),
    tone             text,
    audience         text,
    length_preset    text,
    creativity       smallint CHECK (creativity BETWEEN 0 AND 100),
    call_to_action   text,
    search_intent    text,
    answer_intent    text,

    -- Nothing publishes without review. 'draft' is the only state a generation
    -- can create; a person moves it forward.
    status           text NOT NULL DEFAULT 'draft'
                     CHECK (status IN ('draft','in_review','approved','archived')),
    reviewed_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    reviewed_at      timestamptz,

    -- Provenance travels with the saved content, not just with the chat message.
    blocks           jsonb NOT NULL DEFAULT '[]'::jsonb,
    claim_warnings   jsonb NOT NULL DEFAULT '[]'::jsonb,
    generated_by     jsonb NOT NULL DEFAULT '{}'::jsonb,

    deleted_at       timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT content_items_reviewed_has_reviewer
        CHECK (status <> 'approved' OR reviewed_by IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS content_items_project_idx
    ON content_items (project_id, created_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS content_items_format_idx
    ON content_items (organization_id, format) WHERE deleted_at IS NULL;

-- ---------------------------------------------------------------------------
-- Strategies
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS strategies (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,

    title            text NOT NULL,
    -- One row per generated strategy, with all sections in a single document.
    -- Sections are a fixed list in code; storing them as jsonb avoids a
    -- seventeen-column table that changes shape every time the list does.
    sections         jsonb NOT NULL DEFAULT '{}'::jsonb,
    blocks           jsonb NOT NULL DEFAULT '[]'::jsonb,
    claim_warnings   jsonb NOT NULL DEFAULT '[]'::jsonb,
    generated_by     jsonb NOT NULL DEFAULT '{}'::jsonb,

    status           text NOT NULL DEFAULT 'draft'
                     CHECK (status IN ('draft','in_review','approved','archived')),
    -- Exactly one approved strategy per project at a time; enforced by the
    -- partial index below rather than by application discipline.
    deleted_at       timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS strategies_one_approved_idx
    ON strategies (project_id) WHERE status = 'approved' AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS strategies_project_idx
    ON strategies (project_id, created_at DESC) WHERE deleted_at IS NULL;

-- ---------------------------------------------------------------------------
-- Social posts
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS social_posts (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,

    platform         text NOT NULL
                     CHECK (platform IN ('instagram','facebook','linkedin','youtube',
                                         'x','pinterest','whatsapp')),
    format           text NOT NULL,
    caption          text NOT NULL,
    hashtags         jsonb NOT NULL DEFAULT '[]'::jsonb,
    idea             text,

    -- PLANNING STATES ONLY. There is deliberately no 'published' state and no
    -- scheduled-publish worker: no platform API is connected, so a post cannot
    -- be published from here. 'ready' means a person can copy it out and post
    -- it themselves. Adding 'published' before an API exists would be a lie in
    -- the schema.
    status           text NOT NULL DEFAULT 'idea'
                     CHECK (status IN ('idea','draft','ready','archived')),
    planned_for      date,

    blocks           jsonb NOT NULL DEFAULT '[]'::jsonb,
    generated_by     jsonb NOT NULL DEFAULT '{}'::jsonb,

    deleted_at       timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS social_posts_calendar_idx
    ON social_posts (project_id, planned_for) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS social_posts_platform_idx
    ON social_posts (organization_id, platform) WHERE deleted_at IS NULL;

-- ---------------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------------

ALTER TABLE content_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE strategies    ENABLE ROW LEVEL SECURITY;
ALTER TABLE social_posts  ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
    target text;
BEGIN
    FOREACH target IN ARRAY ARRAY['content_items','strategies','social_posts']
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON %I', target || '_tenant_isolation', target);
        EXECUTE format(
            'CREATE POLICY %I ON %I USING (organization_id = current_setting(%L, true)::uuid)',
            target || '_tenant_isolation', target, 'app.current_organization'
        );
    END LOOP;
END
$$;

-- ---------------------------------------------------------------------------
-- updated_at maintenance
-- ---------------------------------------------------------------------------

CREATE TRIGGER content_items_updated_at BEFORE UPDATE ON content_items
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER strategies_updated_at BEFORE UPDATE ON strategies
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER social_posts_updated_at BEFORE UPDATE ON social_posts
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ===== 0004_crawl_audit.sql ========================================

-- ---------------------------------------------------------------------------
-- Migration 0004 — Phase 4: crawler, SEO and AEO audits, keywords, jobs
-- ---------------------------------------------------------------------------
-- Forward-only. Do not edit once applied; add a new migration instead.
--
-- Conventions carried forward: uuid keys, timestamptz, organization_id plus
-- row-level security on every tenant-scoped table, ON DELETE on every foreign
-- key, soft delete only where audit history references the row.
--
-- RETENTION IS LOAD-BEARING HERE. Crawled page content is the user's own
-- website text, stored under a consent record that names a retention period.
-- `crawled_pages.expires_at` is set from that period on insert, and the
-- deletion job reads it. A crawl whose consent is revoked has its pages
-- deleted outright rather than soft-deleted: the user asked for the data to be
-- gone, and a soft delete would not honour that.
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- Usage: crawled pages already exist as a metric; add audit runs
-- ---------------------------------------------------------------------------

ALTER TABLE usage_records DROP CONSTRAINT IF EXISTS usage_records_metric_check;
ALTER TABLE usage_records ADD CONSTRAINT usage_records_metric_check
    CHECK (metric IN ('ai_generation','ai_tokens','content_item','crawl_page',
                      'crawl_run','audit_run','report','automation_run','seat'));

-- ---------------------------------------------------------------------------
-- Background jobs
-- ---------------------------------------------------------------------------
-- One table for every kind of long-running work, because the lifecycle is
-- identical and a per-feature job table means the same bugs fixed three times.
--
-- The five states are the brief's. `cancel_requested` is separate from the
-- status: a running job is asked to stop and acknowledges by transitioning to
-- cancelled itself, so the worker is never killed mid-write.

CREATE TABLE IF NOT EXISTS jobs (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid REFERENCES projects(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    kind              text NOT NULL CHECK (kind IN ('crawl','seo_audit','aeo_audit')),
    status            text NOT NULL DEFAULT 'queued'
                          CHECK (status IN ('queued','running','completed','failed','cancelled')),

    -- Progress, written as the job runs so a poller can show it.
    progress_done     integer NOT NULL DEFAULT 0 CHECK (progress_done >= 0),
    progress_total    integer CHECK (progress_total IS NULL OR progress_total >= 0),
    progress_message  text NOT NULL DEFAULT '',

    -- A cancellation REQUEST. The worker polls this and stops cleanly.
    cancel_requested  boolean NOT NULL DEFAULT false,

    attempts          integer NOT NULL DEFAULT 0 CHECK (attempts >= 0 AND attempts <= 10),
    failure_code      text,
    failure_detail    text,

    -- Input for the job, and the id of whatever it produced.
    input             jsonb NOT NULL DEFAULT '{}'::jsonb,
    result_id         uuid,

    -- Set when a retry may not run before this time.
    not_before        timestamptz,

    queued_at         timestamptz NOT NULL DEFAULT now(),
    started_at        timestamptz,
    finished_at       timestamptz,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),

    -- A terminal job must have a finish time; a non-terminal one must not.
    CONSTRAINT jobs_finished_when_terminal CHECK (
        (status IN ('completed','failed','cancelled')) = (finished_at IS NOT NULL)
    ),
    -- A failure must say why. An unexplained failure is not actionable.
    CONSTRAINT jobs_failure_has_code CHECK (status <> 'failed' OR failure_code IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS jobs_org_idx ON jobs (organization_id, created_at DESC);
CREATE INDEX IF NOT EXISTS jobs_project_idx ON jobs (project_id, kind, created_at DESC);
-- The worker's claim query: oldest runnable job first.
CREATE INDEX IF NOT EXISTS jobs_runnable_idx
    ON jobs (status, not_before, queued_at) WHERE status = 'queued';
-- At most one active job of a kind per project, enforced in the database rather
-- than only in the service: two concurrent crawls of one site is both a waste
-- and a politeness problem.
CREATE UNIQUE INDEX IF NOT EXISTS jobs_one_active_per_project
    ON jobs (project_id, kind) WHERE status IN ('queued','running');

-- ---------------------------------------------------------------------------
-- Crawls
-- ---------------------------------------------------------------------------
-- One row per crawl run. The consent record that authorised it is referenced,
-- not copied, so revoking consent is traceable to the crawls it covered.

CREATE TABLE IF NOT EXISTS crawls (
    id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id      uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id           uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    job_id               uuid REFERENCES jobs(id) ON DELETE SET NULL,
    -- RESTRICT, not CASCADE: a consent record may not be deleted while crawls
    -- performed under it still exist, because the record is the authorisation.
    consent_id           uuid REFERENCES website_crawl_consents(id) ON DELETE RESTRICT,
    started_by           uuid REFERENCES users(id) ON DELETE SET NULL,

    site_url             text NOT NULL,
    -- What the crawl was permitted and limited to, recorded as applied.
    max_pages            integer NOT NULL CHECK (max_pages > 0 AND max_pages <= 500),
    max_depth            integer NOT NULL CHECK (max_depth >= 0 AND max_depth <= 10),
    respect_robots       boolean NOT NULL,
    crawl_delay_ms       integer NOT NULL CHECK (crawl_delay_ms >= 0),

    pages_crawled        integer NOT NULL DEFAULT 0 CHECK (pages_crawled >= 0),
    pages_failed         integer NOT NULL DEFAULT 0 CHECK (pages_failed >= 0),

    robots_found         boolean NOT NULL DEFAULT false,
    robots_readable      boolean NOT NULL DEFAULT true,
    robots_summary       text NOT NULL DEFAULT '',
    sitemap_found        boolean NOT NULL DEFAULT false,
    sitemap_note         text NOT NULL DEFAULT '',
    sitemap_urls_found   integer NOT NULL DEFAULT 0 CHECK (sitemap_urls_found >= 0),

    failures             jsonb NOT NULL DEFAULT '[]'::jsonb,
    skipped              jsonb NOT NULL DEFAULT '{}'::jsonb,
    stopped_early        text,
    cancelled            boolean NOT NULL DEFAULT false,

    started_at           timestamptz NOT NULL DEFAULT now(),
    finished_at          timestamptz,
    -- When the stored page content must be deleted, from the consent record.
    expires_at           timestamptz NOT NULL,
    created_at           timestamptz NOT NULL DEFAULT now(),
    updated_at           timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS crawls_project_idx ON crawls (project_id, started_at DESC);
CREATE INDEX IF NOT EXISTS crawls_org_idx ON crawls (organization_id, started_at DESC);
-- The retention sweep's query.
CREATE INDEX IF NOT EXISTS crawls_expiry_idx ON crawls (expires_at);
CREATE INDEX IF NOT EXISTS crawls_consent_idx ON crawls (consent_id);

-- ---------------------------------------------------------------------------
-- Crawled pages
-- ---------------------------------------------------------------------------
-- The extracted fields from the brief's "website data" list. The RAW HTML IS
-- NOT STORED: the audit needs the extracted values, and keeping a copy of
-- someone's entire site is a liability with no corresponding benefit.

CREATE TABLE IF NOT EXISTS crawled_pages (
    id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id      uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    crawl_id             uuid NOT NULL REFERENCES crawls(id) ON DELETE CASCADE,

    url                  text NOT NULL,
    status               integer NOT NULL,
    https                boolean NOT NULL,

    title                text,
    meta_description     text,
    h1                   jsonb NOT NULL DEFAULT '[]'::jsonb,
    h2                   jsonb NOT NULL DEFAULT '[]'::jsonb,
    h3                   jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- Extracted text, not markup, and capped by the extractor.
    text_content         text NOT NULL DEFAULT '',
    word_count           integer NOT NULL DEFAULT 0 CHECK (word_count >= 0),

    links                jsonb NOT NULL DEFAULT '[]'::jsonb,
    images               jsonb NOT NULL DEFAULT '[]'::jsonb,
    canonical            text,
    robots_directives    jsonb NOT NULL DEFAULT '{}'::jsonb,
    structured_data      jsonb NOT NULL DEFAULT '[]'::jsonb,
    structured_data_errors jsonb NOT NULL DEFAULT '[]'::jsonb,
    faqs                 jsonb NOT NULL DEFAULT '[]'::jsonb,

    author               text,
    publisher            text,
    published_at_raw     text,
    modified_at_raw      text,
    entity_signals       jsonb NOT NULL DEFAULT '{}'::jsonb,
    open_graph           jsonb NOT NULL DEFAULT '{}'::jsonb,

    lang                 text,
    has_viewport_meta    boolean NOT NULL DEFAULT false,
    has_charset          boolean NOT NULL DEFAULT false,

    bytes                integer NOT NULL DEFAULT 0 CHECK (bytes >= 0),
    response_time_ms     integer NOT NULL DEFAULT 0 CHECK (response_time_ms >= 0),
    truncated            boolean NOT NULL DEFAULT false,

    -- The brief: "Store crawl timestamp." Per page, not per crawl, because
    -- a crawl spans minutes and a page's freshness is its own fetch time.
    crawled_at           timestamptz NOT NULL,
    created_at           timestamptz NOT NULL DEFAULT now(),

    -- One row per URL per crawl.
    CONSTRAINT crawled_pages_unique_per_crawl UNIQUE (crawl_id, url)
);

CREATE INDEX IF NOT EXISTS crawled_pages_crawl_idx ON crawled_pages (crawl_id);
CREATE INDEX IF NOT EXISTS crawled_pages_org_idx ON crawled_pages (organization_id);
CREATE INDEX IF NOT EXISTS crawled_pages_url_idx ON crawled_pages (organization_id, url);

-- ---------------------------------------------------------------------------
-- Audits
-- ---------------------------------------------------------------------------
-- SEO and AEO share a table: the shape is identical and the difference is the
-- `kind` plus which analyser produced the findings. Separating them would
-- duplicate the findings/score/provenance columns for no gain.

CREATE TABLE IF NOT EXISTS audits (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    crawl_id          uuid NOT NULL REFERENCES crawls(id) ON DELETE CASCADE,
    job_id            uuid REFERENCES jobs(id) ON DELETE SET NULL,

    kind              text NOT NULL CHECK (kind IN ('seo','aeo')),
    score             integer NOT NULL CHECK (score >= 0 AND score <= 100),
    -- Always stored with the score, so the number can never be shown without
    -- the explanation that it is our own weighting.
    score_basis       text NOT NULL,

    findings          jsonb NOT NULL DEFAULT '[]'::jsonb,
    stats             jsonb NOT NULL DEFAULT '{}'::jsonb,
    -- What could NOT be assessed. Never empty in practice.
    not_checked       jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- Findings the promise linter refused to publish. A bug signal.
    suppressed        jsonb NOT NULL DEFAULT '[]'::jsonb,

    checked_at        timestamptz NOT NULL DEFAULT now(),
    created_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS audits_project_idx ON audits (project_id, kind, checked_at DESC);
CREATE INDEX IF NOT EXISTS audits_crawl_idx ON audits (crawl_id);
CREATE INDEX IF NOT EXISTS audits_org_idx ON audits (organization_id, checked_at DESC);

-- ---------------------------------------------------------------------------
-- Keywords
-- ---------------------------------------------------------------------------
-- NOTE THE ABSENCE: there is no `search_volume integer` column, and there is
-- no `competition integer`. Those values are unknown to this product, and a
-- nullable number column would invite a future writer to fill it with an
-- estimate that then reads as a measurement. The two jsonb columns hold the
-- discriminated union from lib/keywords/types.ts, which has no variant that
-- carries a bare number without naming its source.

CREATE TABLE IF NOT EXISTS keywords (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    crawl_id          uuid REFERENCES crawls(id) ON DELETE SET NULL,

    query             text NOT NULL,
    kinds             jsonb NOT NULL DEFAULT '[]'::jsonb,
    intent            text NOT NULL CHECK (intent IN ('informational','commercial','transactional','navigational')),

    relevance_score   integer NOT NULL CHECK (relevance_score >= 0 AND relevance_score <= 100),
    relevance_basis   text NOT NULL,
    covering_urls     jsonb NOT NULL DEFAULT '[]'::jsonb,

    -- Discriminated unions, never bare numbers. See the note above.
    volume            jsonb NOT NULL DEFAULT '{"kind":"unavailable","label":"Data unavailable"}'::jsonb,
    competition       jsonb NOT NULL DEFAULT '{"kind":"unavailable","label":"Data unavailable"}'::jsonb,

    priority          text NOT NULL CHECK (priority IN ('high','medium','low')),
    content_format    text NOT NULL,
    entities          jsonb NOT NULL DEFAULT '[]'::jsonb,
    source            text NOT NULL CHECK (source IN ('page_heading','page_title','faq','user_provided','ai_suggested')),

    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT keywords_unique_per_project UNIQUE (project_id, query)
);

CREATE INDEX IF NOT EXISTS keywords_project_idx ON keywords (project_id, priority);
CREATE INDEX IF NOT EXISTS keywords_org_idx ON keywords (organization_id);

-- ---------------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------------

ALTER TABLE jobs          ENABLE ROW LEVEL SECURITY;
ALTER TABLE crawls        ENABLE ROW LEVEL SECURITY;
ALTER TABLE crawled_pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE audits        ENABLE ROW LEVEL SECURITY;
ALTER TABLE keywords      ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
    target text;
BEGIN
    FOREACH target IN ARRAY ARRAY['jobs','crawls','crawled_pages','audits','keywords']
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON %I', target || '_tenant_isolation', target);
        EXECUTE format(
            'CREATE POLICY %I ON %I USING (organization_id = current_setting(%L, true)::uuid)',
            target || '_tenant_isolation', target, 'app.current_organization'
        );
    END LOOP;
END
$$;

-- ---------------------------------------------------------------------------
-- updated_at maintenance
-- ---------------------------------------------------------------------------

CREATE TRIGGER jobs_updated_at BEFORE UPDATE ON jobs
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER crawls_updated_at BEFORE UPDATE ON crawls
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER keywords_updated_at BEFORE UPDATE ON keywords
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ===== 0005_schema_competitors_ops.sql =============================

-- ---------------------------------------------------------------------------
-- Migration 0005 — Phase 5: schema validation history, competitor intelligence,
--                  advertising plans, leads, messaging plans, video scripts
-- ---------------------------------------------------------------------------
-- Forward-only. Do not edit once applied; add a new migration instead.
--
-- Conventions carried forward: uuid keys, timestamptz, organization_id plus
-- row-level security on every tenant-scoped table, ON DELETE on every foreign
-- key, soft delete only where history references the row.
--
-- THREE DECISIONS IN HERE ARE LOAD-BEARING AND ARE NOT STYLISTIC:
--
-- 1. `schema_validations` stores `validator_version`. Without it a history is
--    not comparable: a finding that appears between two runs could be a change
--    in the customer's markup or a change in our rules, with no way to tell
--    which. The column is NOT NULL for that reason.
--
-- 2. `competitor_analyses.acknowledgement_id` is ON DELETE RESTRICT, exactly as
--    `crawls.consent_id` is. A competitor cannot consent to being read, so the
--    authorisation on record is the CUSTOMER'S acknowledgement that they asked
--    for public information about a named third party. That record may not be
--    deleted while analyses performed under it still exist.
--
-- 3. There is no `sent_at`, `scheduled_at` or 'sent' status anywhere on
--    `messaging_plans`, and no `image_url` on `video_scripts`. SeSha cannot
--    send email or WhatsApp and cannot generate images, so the columns that
--    would record having done so do not exist. A nullable `sent_at` is an
--    invitation to write to it from a screen that implies the product sends.
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- Usage metrics and job kinds
-- ---------------------------------------------------------------------------

ALTER TABLE usage_records DROP CONSTRAINT IF EXISTS usage_records_metric_check;
ALTER TABLE usage_records ADD CONSTRAINT usage_records_metric_check
    CHECK (metric IN ('ai_generation','ai_tokens','content_item','crawl_page',
                      'crawl_run','audit_run','report','automation_run','seat',
                      'schema_validation','competitor_analysis','lead'));

ALTER TABLE jobs DROP CONSTRAINT IF EXISTS jobs_kind_check;
ALTER TABLE jobs ADD CONSTRAINT jobs_kind_check
    CHECK (kind IN ('crawl','seo_audit','aeo_audit','schema_validation','competitor_analysis'));

-- ---------------------------------------------------------------------------
-- Schema validation history
-- ---------------------------------------------------------------------------
-- One row per validation run. The whole result is kept as jsonb rather than
-- normalised into an issues table: an issue has no life of its own, is never
-- queried independently of its run, and normalising it would mean a schema
-- migration every time a check is added.

CREATE TABLE IF NOT EXISTS schema_validations (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    source_kind       text NOT NULL CHECK (source_kind IN ('pasted','page_url','website_url')),
    -- NULL for pasted markup, which has no URL.
    source_url        text,
    -- The page's canonical URL, when the run knew it. NULL means the canonical
    -- check was reported NOT_EVALUATED rather than passed.
    canonical_url     text,

    -- Which of the three syntaxes were found. Empty when nothing was found,
    -- which is a real and different outcome from "valid".
    syntaxes          jsonb NOT NULL DEFAULT '[]'::jsonb,
    validator_version text NOT NULL,

    overall_status    text NOT NULL
                          CHECK (overall_status IN ('VALID','INVALID','WARNING',
                                                    'RECOMMENDATION','NOT_EVALUATED','UNSUPPORTED')),
    -- Counts per status, so a history list renders without reading every issue.
    counts            jsonb NOT NULL DEFAULT '{}'::jsonb,
    types_found       jsonb NOT NULL DEFAULT '[]'::jsonb,
    entities          jsonb NOT NULL DEFAULT '[]'::jsonb,
    issues            jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- Limits of how the document was obtained. NOT findings about the markup.
    limitations       jsonb NOT NULL DEFAULT '[]'::jsonb,

    checked_at        timestamptz NOT NULL,
    created_at        timestamptz NOT NULL DEFAULT now(),

    -- A pasted document has no URL; a URL run must have one.
    CONSTRAINT schema_validations_url_matches_kind CHECK (
        (source_kind = 'pasted') = (source_url IS NULL)
    )
);

CREATE INDEX IF NOT EXISTS schema_validations_project_idx
    ON schema_validations (project_id, checked_at DESC);
CREATE INDEX IF NOT EXISTS schema_validations_org_idx ON schema_validations (organization_id);
-- The comparison-over-time query: the previous run for the same URL.
CREATE INDEX IF NOT EXISTS schema_validations_source_idx
    ON schema_validations (project_id, source_url, checked_at DESC);

-- ---------------------------------------------------------------------------
-- Competitors
-- ---------------------------------------------------------------------------
-- Soft-deleted, because analyses reference them and a deleted competitor's past
-- analyses are still part of the customer's own record.

CREATE TABLE IF NOT EXISTS competitors (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    name              text NOT NULL CHECK (length(trim(name)) > 0),
    website_url       text,
    source            text NOT NULL DEFAULT 'user_added'
                          CHECK (source IN ('onboarding','user_added')),
    notes             text NOT NULL DEFAULT '',

    deleted_at        timestamptz,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT competitors_unique_per_project UNIQUE (project_id, name)
);

CREATE INDEX IF NOT EXISTS competitors_project_idx ON competitors (project_id, name);
CREATE INDEX IF NOT EXISTS competitors_org_idx ON competitors (organization_id);

-- ---------------------------------------------------------------------------
-- Competitor research acknowledgements
-- ---------------------------------------------------------------------------
-- THE AUTHORISATION RECORD, and the reason this is a separate table rather than
-- a boolean on `competitors`.
--
-- A competitor cannot give consent. What can be recorded is that a named person
-- at the customer asked for publicly available pages to be read, having been
-- shown exactly what that means. That is a dated, versioned, attributable act —
-- the same shape as `website_crawl_consents` — and a boolean column cannot
-- express it.

CREATE TABLE IF NOT EXISTS competitor_acknowledgements (
    id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id    uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id         uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    competitor_id      uuid NOT NULL REFERENCES competitors(id) ON DELETE CASCADE,
    acknowledged_by    uuid REFERENCES users(id) ON DELETE SET NULL,

    acknowledged_at    timestamptz NOT NULL DEFAULT now(),
    revoked_at         timestamptz,
    -- The version of the wording that was shown and accepted.
    statement_version  text NOT NULL,
    -- The maximum pages the acknowledgement covers, recorded as applied.
    max_pages          integer NOT NULL CHECK (max_pages > 0 AND max_pages <= 3),

    created_at         timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS competitor_ack_competitor_idx
    ON competitor_acknowledgements (competitor_id, acknowledged_at DESC);
CREATE INDEX IF NOT EXISTS competitor_ack_org_idx ON competitor_acknowledgements (organization_id);
-- At most one live acknowledgement per competitor.
CREATE UNIQUE INDEX IF NOT EXISTS competitor_ack_one_live
    ON competitor_acknowledgements (competitor_id) WHERE revoked_at IS NULL;

-- ---------------------------------------------------------------------------
-- Competitor analyses
-- ---------------------------------------------------------------------------
-- Findings are stored; PAGE CONTENT IS NOT. There is deliberately no column for
-- the third party's page text. The analysis needs the findings, and keeping a
-- copy of someone else's website is a liability with no matching benefit.

CREATE TABLE IF NOT EXISTS competitor_analyses (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id     uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id          uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    competitor_id       uuid NOT NULL REFERENCES competitors(id) ON DELETE CASCADE,
    -- RESTRICT: the acknowledgement is the authorisation for this analysis.
    acknowledgement_id  uuid REFERENCES competitor_acknowledgements(id) ON DELETE RESTRICT,
    job_id              uuid REFERENCES jobs(id) ON DELETE SET NULL,
    created_by          uuid REFERENCES users(id) ON DELETE SET NULL,

    analysed_at         timestamptz NOT NULL,
    findings            jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- URL and time per page, so every verified finding is auditable.
    pages_read          jsonb NOT NULL DEFAULT '[]'::jsonb,
    limitations         jsonb NOT NULL DEFAULT '[]'::jsonb,
    not_covered         jsonb NOT NULL DEFAULT '[]'::jsonb,

    -- Split counts, because the verified/inferred ratio is the first thing a
    -- reader needs and it must not require parsing the findings array.
    verified_count      integer NOT NULL DEFAULT 0 CHECK (verified_count >= 0),
    inferred_count      integer NOT NULL DEFAULT 0 CHECK (inferred_count >= 0),

    created_at          timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS competitor_analyses_competitor_idx
    ON competitor_analyses (competitor_id, analysed_at DESC);
CREATE INDEX IF NOT EXISTS competitor_analyses_project_idx
    ON competitor_analyses (project_id, analysed_at DESC);
CREATE INDEX IF NOT EXISTS competitor_analyses_org_idx ON competitor_analyses (organization_id);

-- ---------------------------------------------------------------------------
-- Advertising plans
-- ---------------------------------------------------------------------------
-- A plan, not a campaign. There is no `platform_campaign_id`, no `spend` and no
-- `status` beyond the review state: no ad account is connected, so a column
-- recording what a campaign did would never be written truthfully.

CREATE TABLE IF NOT EXISTS ad_plans (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    platform          text NOT NULL
                          CHECK (platform IN ('google_ads','meta','instagram','linkedin','youtube')),
    objective         text NOT NULL,
    campaign_name     text NOT NULL CHECK (length(trim(campaign_name)) > 0),

    -- The whole plan: audience, headlines, descriptions, creative concepts,
    -- landing page, A/B ideas and the budget recommendation with its basis.
    plan              jsonb NOT NULL DEFAULT '{}'::jsonb,
    -- Problems found by the validator at save time, kept so a reviewer sees
    -- what was known when it was approved.
    problems          jsonb NOT NULL DEFAULT '[]'::jsonb,

    review_state      text NOT NULL DEFAULT 'draft'
                          CHECK (review_state IN ('draft','in_review','approved')),

    deleted_at        timestamptz,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ad_plans_project_idx ON ad_plans (project_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ad_plans_org_idx ON ad_plans (organization_id);

-- ---------------------------------------------------------------------------
-- Leads
-- ---------------------------------------------------------------------------
-- A `leads` table already exists, created in migration 0001 as part of the
-- Phase 1 architecture and never written to by any repository: it had an
-- organization but no project, a required email, a five-value `status`, and no
-- score. Phase 5 is where leads are actually implemented.
--
-- THIS IS ALTERED IN PLACE RATHER THAN REPLACED. Migrations are forward-only, and
-- a second table called `leads_v2` would mean every future reader of this schema
-- having to work out which one is real. Three of the changes below are worth
-- reading:
--
--  · `email` becomes NULLABLE. In this market a great many enquiries arrive by
--    phone or WhatsApp with no email address at all, and a NOT NULL email would
--    force whoever takes the call to invent one.
--  · `status` becomes `stage`, with the seven values the brief names. The old
--    name said nothing about a pipeline; `proposal` and `negotiation` did not
--    exist, so a real sales process could not be recorded.
--  · the score arrives WITH its components and basis, never as a bare number.

ALTER TABLE leads ADD COLUMN IF NOT EXISTS project_id uuid REFERENCES projects(id) ON DELETE CASCADE;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS phone text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS company text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS enquiry text NOT NULL DEFAULT '';
ALTER TABLE leads ADD COLUMN IF NOT EXISTS score integer NOT NULL DEFAULT 0;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS score_components jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS score_basis text NOT NULL DEFAULT '';
ALTER TABLE leads ADD COLUMN IF NOT EXISTS scored_at timestamptz;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS opt_in_basis text NOT NULL DEFAULT 'none';
ALTER TABLE leads ADD COLUMN IF NOT EXISTS lost_reason text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS last_activity_at timestamptz;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

-- A phone-only lead is a real lead.
ALTER TABLE leads ALTER COLUMN email DROP NOT NULL;

-- `name` is required from here: a lead nobody can address is not workable.
UPDATE leads SET name = 'Unnamed enquiry' WHERE name IS NULL OR trim(name) = '';
ALTER TABLE leads ALTER COLUMN name SET NOT NULL;

-- status -> stage, with the seven stages the brief names.
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'leads' AND column_name = 'status'
    ) AND NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'leads' AND column_name = 'stage'
    ) THEN
        ALTER TABLE leads RENAME COLUMN status TO stage;
    END IF;
END
$$;

ALTER TABLE leads ADD COLUMN IF NOT EXISTS stage text NOT NULL DEFAULT 'new';
ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_status_check;
ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_stage_check;
ALTER TABLE leads ADD CONSTRAINT leads_stage_check
    CHECK (stage IN ('new','contacted','qualified','proposal','negotiation','won','lost'));

ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_source_check;
-- `source_path` and `source_campaign` from Phase 1 are kept: they are real
-- attribution captured at creation, and `source` answers a different question.
ALTER TABLE leads ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'unknown';
ALTER TABLE leads ADD CONSTRAINT leads_source_check
    CHECK (source IN ('website_form','landing_page','phone','whatsapp','email',
                      'referral','walk_in','social','paid_ad','marketplace',
                      'event','imported','manual','unknown'));

ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_opt_in_basis_check;
ALTER TABLE leads ADD CONSTRAINT leads_opt_in_basis_check
    CHECK (opt_in_basis IN ('explicit_opt_in','existing_customer','enquiry_reply',
                            'contract_necessity','purchased_list','scraped','none'));

ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_score_range;
ALTER TABLE leads ADD CONSTRAINT leads_score_range CHECK (score >= 0 AND score <= 100);

-- A lost lead must say why. "Lost" with no reason teaches nobody anything.
ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_lost_has_reason;
ALTER TABLE leads ADD CONSTRAINT leads_lost_has_reason
    CHECK (stage <> 'lost' OR lost_reason IS NOT NULL);

-- A score must carry its components and basis, or it is the opaque number this
-- schema refuses to store.
ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_score_has_basis;
ALTER TABLE leads ADD CONSTRAINT leads_score_has_basis
    CHECK (score = 0 OR (score_basis <> '' AND jsonb_array_length(score_components) > 0));

-- A lead must belong to a contactable person somehow.
ALTER TABLE leads DROP CONSTRAINT IF EXISTS leads_has_contact;
ALTER TABLE leads ADD CONSTRAINT leads_has_contact
    CHECK (email IS NOT NULL OR phone IS NOT NULL OR company IS NOT NULL);

CREATE INDEX IF NOT EXISTS leads_project_stage_idx ON leads (project_id, stage, score DESC);
CREATE INDEX IF NOT EXISTS leads_owner_idx ON leads (owner_user_id, stage);
CREATE INDEX IF NOT EXISTS leads_email_idx ON leads (project_id, lower(email::text));

-- ---------------------------------------------------------------------------
-- Lead activities and follow-ups
-- ---------------------------------------------------------------------------
-- One table for both: a follow-up is an activity with a due date. Two tables
-- would mean the same history assembled from two places, in date order, forever.

CREATE TABLE IF NOT EXISTS lead_activities (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    lead_id           uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    kind              text NOT NULL
                          CHECK (kind IN ('note','call','email_sent','email_received',
                                          'whatsapp_sent','whatsapp_received','meeting',
                                          'quote_sent','stage_change','follow_up')),
    note              text NOT NULL DEFAULT '',

    -- When it happened. For a follow-up this is when it was created.
    occurred_at       timestamptz NOT NULL DEFAULT now(),
    -- Set only on a follow-up.
    due_at            timestamptz,
    completed_at      timestamptz,

    -- For a stage_change, what moved. Kept so the pipeline history is readable
    -- without reconstructing it from timestamps.
    from_stage        text,
    to_stage          text,

    created_at        timestamptz NOT NULL DEFAULT now(),

    -- A due date only makes sense on a follow-up.
    CONSTRAINT lead_activities_due_only_on_follow_up CHECK (
        due_at IS NULL OR kind = 'follow_up'
    ),
    CONSTRAINT lead_activities_stage_change_has_stages CHECK (
        kind <> 'stage_change' OR (from_stage IS NOT NULL AND to_stage IS NOT NULL)
    )
);

CREATE INDEX IF NOT EXISTS lead_activities_lead_idx ON lead_activities (lead_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS lead_activities_org_idx ON lead_activities (organization_id);
-- The "what is due" query.
CREATE INDEX IF NOT EXISTS lead_activities_due_idx
    ON lead_activities (organization_id, due_at) WHERE due_at IS NOT NULL AND completed_at IS NULL;

-- ---------------------------------------------------------------------------
-- Messaging plans (email and WhatsApp)
-- ---------------------------------------------------------------------------
-- NOTE WHAT IS ABSENT: no sent_at, no scheduled_at, no 'sent' or 'scheduled'
-- review state, no recipient list. SeSha cannot send, so there is nothing to
-- record having sent — and a recipient list stored here would be a list this
-- product cannot lawfully act on anyway.

CREATE TABLE IF NOT EXISTS messaging_plans (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    channel           text NOT NULL CHECK (channel IN ('email','whatsapp')),
    kind              text NOT NULL,
    -- WhatsApp only. NULL for email.
    category          text CHECK (category IS NULL OR category IN ('MARKETING','UTILITY','AUTHENTICATION')),

    title             text NOT NULL DEFAULT '',
    plan              jsonb NOT NULL DEFAULT '{}'::jsonb,
    problems          jsonb NOT NULL DEFAULT '[]'::jsonb,

    -- Why the recipients may be messaged. A forbidden basis cannot be stored:
    -- the service refuses the plan, and the CHECK refuses the row.
    opt_in_basis      text NOT NULL
                          CHECK (opt_in_basis IN ('explicit_opt_in','existing_customer',
                                                  'enquiry_reply','contract_necessity')),
    audience_note     text NOT NULL DEFAULT '',

    review_state      text NOT NULL DEFAULT 'draft'
                          CHECK (review_state IN ('draft','in_review','approved')),

    deleted_at        timestamptz,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),

    -- A WhatsApp plan has a category; an email plan does not.
    CONSTRAINT messaging_plans_category_matches_channel CHECK (
        (channel = 'whatsapp') = (category IS NOT NULL)
    )
);

CREATE INDEX IF NOT EXISTS messaging_plans_project_idx
    ON messaging_plans (project_id, channel, created_at DESC);
CREATE INDEX IF NOT EXISTS messaging_plans_org_idx ON messaging_plans (organization_id);

-- ---------------------------------------------------------------------------
-- Video scripts
-- ---------------------------------------------------------------------------
-- No image columns. Thumbnail concepts are written briefs inside `script`; no
-- image-generation API is connected, so there is no asset to point at and no
-- column that could hold a convincing-looking placeholder.

CREATE TABLE IF NOT EXISTS video_scripts (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,

    platform          text NOT NULL
                          CHECK (platform IN ('youtube_long','youtube_shorts',
                                              'instagram_reels','linkedin_video')),
    topic             text NOT NULL CHECK (length(trim(topic)) > 0),
    total_seconds     integer NOT NULL DEFAULT 0 CHECK (total_seconds >= 0),

    script            jsonb NOT NULL DEFAULT '{}'::jsonb,
    problems          jsonb NOT NULL DEFAULT '[]'::jsonb,

    review_state      text NOT NULL DEFAULT 'draft'
                          CHECK (review_state IN ('draft','in_review','approved')),

    deleted_at        timestamptz,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS video_scripts_project_idx
    ON video_scripts (project_id, created_at DESC);
CREATE INDEX IF NOT EXISTS video_scripts_org_idx ON video_scripts (organization_id);

-- ---------------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------------

ALTER TABLE schema_validations           ENABLE ROW LEVEL SECURITY;
ALTER TABLE competitors                  ENABLE ROW LEVEL SECURITY;
ALTER TABLE competitor_acknowledgements  ENABLE ROW LEVEL SECURITY;
ALTER TABLE competitor_analyses          ENABLE ROW LEVEL SECURITY;
ALTER TABLE ad_plans                     ENABLE ROW LEVEL SECURITY;
ALTER TABLE leads                        ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_activities              ENABLE ROW LEVEL SECURITY;
ALTER TABLE messaging_plans              ENABLE ROW LEVEL SECURITY;
ALTER TABLE video_scripts                ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
    target text;
BEGIN
    FOREACH target IN ARRAY ARRAY['schema_validations','competitors','competitor_acknowledgements',
                                  'competitor_analyses','ad_plans','leads','lead_activities',
                                  'messaging_plans','video_scripts']
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON %I', target || '_tenant_isolation', target);
        EXECUTE format(
            'CREATE POLICY %I ON %I USING (organization_id = current_setting(%L, true)::uuid)',
            target || '_tenant_isolation', target, 'app.current_organization'
        );
    END LOOP;
END
$$;

-- ---------------------------------------------------------------------------
-- updated_at maintenance
-- ---------------------------------------------------------------------------

CREATE TRIGGER competitors_updated_at BEFORE UPDATE ON competitors
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER ad_plans_updated_at BEFORE UPDATE ON ad_plans
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER leads_updated_at BEFORE UPDATE ON leads
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER messaging_plans_updated_at BEFORE UPDATE ON messaging_plans
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER video_scripts_updated_at BEFORE UPDATE ON video_scripts
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ===== 0006_analytics_calendar_automation_reports.sql ==============

-- ---------------------------------------------------------------------------
-- Migration 0006 — Phase 6: data connections, marketing calendar, automation,
--                  reports with export and sharing, notification preferences
-- ---------------------------------------------------------------------------
-- Forward-only. Do not edit once applied; add a new migration instead.
--
-- Conventions carried forward: uuid keys, timestamptz, organization_id plus
-- row-level security on every tenant-scoped table, ON DELETE on every foreign
-- key, soft delete only where history references the row.
--
-- FIVE DECISIONS IN HERE ARE LOAD-BEARING AND ARE NOT STYLISTIC:
--
-- 1. THERE IS NO `metrics` TABLE, AND NO COLUMN ANYWHERE HOLDING A TRAFFIC,
--    IMPRESSION, CLICK OR FOLLOWER FIGURE. SeSha has no connected source for
--    any of them. A nullable `sessions integer` would be filled in within a
--    month — by a seed script, a demo fixture, or a well-meaning estimator —
--    and from then on nobody could tell a measured figure from an invented one.
--    `data_connections` records the absence instead; every metric is computed
--    at read time from rows this database genuinely has.
--
-- 2. `calendar_events.status` is planned/done/skipped, with no 'scheduled' and
--    no 'published'. SeSha cannot publish anything (Phase 3) and nothing
--    fires on a calendar date. A status claiming otherwise would be the
--    database asserting a capability the product refuses.
--
-- 3. `automation_runs` records runs that did NOTHING, with the condition that
--    failed. A rule that quietly stops matching is indistinguishable from a
--    rule that never runs, and the difference matters to the person who built
--    it. `matched boolean NOT NULL` plus `skip_reason` is that difference.
--
-- 4. `report_shares` stores only `token_hash`, never the token. If this table
--    leaks, what leaks is not a set of working links. Same reasoning as
--    password storage, and `expires_at` is NOT NULL so no share is permanent.
--
-- 5. `reports.document` is the RENDERED report, stored whole. A shared link
--    sent to a client in March must show what it showed in March, not today's
--    numbers re-run against today's data. Regenerating on read would silently
--    rewrite history.
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- Usage metrics and job kinds
-- ---------------------------------------------------------------------------

ALTER TABLE usage_records DROP CONSTRAINT IF EXISTS usage_records_metric_check;
ALTER TABLE usage_records ADD CONSTRAINT usage_records_metric_check
    CHECK (metric IN ('ai_generation','ai_tokens','content_item','crawl_page',
                      'crawl_run','audit_run','report','automation_run','seat',
                      'schema_validation','competitor_analysis','lead',
                      'calendar_event','report_export'));

ALTER TABLE jobs DROP CONSTRAINT IF EXISTS jobs_kind_check;
ALTER TABLE jobs ADD CONSTRAINT jobs_kind_check
    CHECK (kind IN ('crawl','seo_audit','aeo_audit','schema_validation',
                    'competitor_analysis','report_generation','automation_sweep'));

-- ---------------------------------------------------------------------------
-- Rejecting a campaign plan
-- ---------------------------------------------------------------------------
-- Phase 5 gave ad plans draft/in_review/approved, with no way to say no. That
-- omission only became visible in Phase 6, because the brief asks for a
-- "campaign decline" trigger and there was nothing for it to fire on: a plan
-- could be approved or left in review forever, which is how a decision quietly
-- becomes a backlog.
--
-- `review_note` carries WHY it was rejected. A rejection with no reason is a
-- rejection the author has to guess at, and the automation that recommends what
-- to reconsider has nothing to say.
-- ---------------------------------------------------------------------------

ALTER TABLE ad_plans DROP CONSTRAINT IF EXISTS ad_plans_review_state_check;
ALTER TABLE ad_plans ADD CONSTRAINT ad_plans_review_state_check
    CHECK (review_state IN ('draft','in_review','approved','rejected'));
ALTER TABLE ad_plans ADD COLUMN IF NOT EXISTS review_note text;
ALTER TABLE ad_plans ADD COLUMN IF NOT EXISTS reviewed_by uuid REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE ad_plans ADD COLUMN IF NOT EXISTS reviewed_at timestamptz;

ALTER TABLE ad_plans DROP CONSTRAINT IF EXISTS ad_plans_rejection_has_reason;
ALTER TABLE ad_plans ADD CONSTRAINT ad_plans_rejection_has_reason
    CHECK (review_state <> 'rejected' OR review_note IS NOT NULL);

-- ---------------------------------------------------------------------------
-- Data connections
-- ---------------------------------------------------------------------------
-- One row per provider a customer has connected. A provider with NO ROW is not
-- connected: absence is the honest default, and there is no 'pending' state
-- that a screen could round up to "connected".
--
-- No access token is stored here. Token custody belongs with the credential
-- store, and putting one in a table that a reporting query joins against is how
-- a token ends up in a log. `external_account_id` is the non-secret handle.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS data_connections (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id     uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id          uuid REFERENCES projects(id) ON DELETE CASCADE,
    provider            text NOT NULL
                        CHECK (provider IN ('google_analytics','google_search_console',
                                            'google_ads','meta_ads','meta_pages',
                                            'linkedin_pages')),
    external_account_id text,
    connected_by        uuid REFERENCES users(id) ON DELETE SET NULL,
    connected_at        timestamptz,
    disconnected_at     timestamptz,
    last_synced_at      timestamptz,
    -- Set when a connection exists but cannot currently be read. Shown to the
    -- user rather than swallowed, because a stale figure with no warning is
    -- worse than no figure.
    problem             text,
    created_at          timestamptz NOT NULL DEFAULT now(),
    updated_at          timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT data_connections_unique UNIQUE (organization_id, project_id, provider)
);

CREATE INDEX IF NOT EXISTS data_connections_org_idx
    ON data_connections (organization_id, provider);

-- ---------------------------------------------------------------------------
-- Marketing calendar
-- ---------------------------------------------------------------------------
-- `event_date` is a DATE, not a timestamptz. A marketing calendar is a calendar
-- of days: storing an instant forces a timezone decision that would move an
-- entry across a date boundary for a colleague in another country.
--
-- `origin` distinguishes a manual entry from one derived from real content and
-- from an ACCEPTED SUGGESTION. Suggestions themselves are never stored here —
-- a suggestion rendered beside real entries becomes, within a week, something
-- the user believes they planned.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS calendar_events (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    kind             text NOT NULL
                     CHECK (kind IN ('social','blog','email','ads','offer','event',
                                     'website_update','seo_task','aeo_task','schema_task')),
    title            text NOT NULL CHECK (length(title) BETWEEN 1 AND 200),
    notes            text NOT NULL DEFAULT '',
    event_date       date NOT NULL,
    status           text NOT NULL DEFAULT 'planned'
                     CHECK (status IN ('planned','done','skipped')),
    origin           text NOT NULL DEFAULT 'manual'
                     CHECK (origin IN ('manual','derived','accepted_suggestion')),
    source_kind      text
                     CHECK (source_kind IN ('content','social_post','ad_plan',
                                            'messaging_plan','audit_finding',
                                            'schema_validation')),
    source_id        uuid,
    campaign         text,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now(),
    -- A derived entry must say what it was derived from, or it is indistinguishable
    -- from something a person planned.
    CONSTRAINT calendar_events_derived_has_source
        CHECK (origin <> 'derived' OR (source_kind IS NOT NULL AND source_id IS NOT NULL))
);

CREATE INDEX IF NOT EXISTS calendar_events_range_idx
    ON calendar_events (organization_id, project_id, event_date);
CREATE INDEX IF NOT EXISTS calendar_events_campaign_idx
    ON calendar_events (organization_id, campaign) WHERE campaign IS NOT NULL;

-- ---------------------------------------------------------------------------
-- Automation
-- ---------------------------------------------------------------------------
-- `action_kind` in the CHECK below is the WHOLE list of things a rule may do,
-- and every one of them produces something a person then acts on. There is no
-- 'send_email', 'publish_post' or 'adjust_budget', because SeSha cannot do
-- those things. The constraint is where that boundary is enforced for anything
-- that reaches the database by a route other than the application.
-- ---------------------------------------------------------------------------

-- A CHECK constraint may not contain a subquery, so the list is enforced through
-- an IMMUTABLE function instead. Keeping it in the database rather than only in
-- the application matters: this is the boundary that stops an outbound action
-- being introduced by a migration, a fixture or a direct INSERT.
CREATE OR REPLACE FUNCTION automation_actions_permitted(actions jsonb) RETURNS boolean AS $$
    SELECT jsonb_typeof(actions) = 'array'
       AND NOT EXISTS (
               SELECT 1
                 FROM jsonb_array_elements(actions) AS action
                WHERE action->>'kind' IS NULL
                   OR action->>'kind' NOT IN ('create_task','create_follow_up','notify',
                                              'suggest_content','add_calendar_entry','recommend')
           );
$$ LANGUAGE sql IMMUTABLE;

COMMENT ON FUNCTION automation_actions_permitted IS
    'The complete list of things an automation may do. Every one produces
     something a person then acts on; none contacts anybody, publishes anything
     or spends anything, because SeSha cannot.';

CREATE TABLE IF NOT EXISTS automation_rules (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name             text NOT NULL CHECK (length(name) BETWEEN 1 AND 120),
    trigger_kind     text NOT NULL
                     CHECK (trigger_kind IN ('lead_created','lead_stage_changed',
                                             'lead_went_quiet','content_approved',
                                             'campaign_plan_declined','schema_error_found',
                                             'structured_data_lost','crawl_completed',
                                             'audit_completed','validation_completed')),
    -- [{field, operator, value}]. ALL must hold.
    conditions       jsonb NOT NULL DEFAULT '[]'::jsonb,
    -- [{kind, template, offsetDays}]. Validated in the application against the
    -- trigger's declared fields; constrained here to the permitted kinds.
    actions          jsonb NOT NULL,
    enabled          boolean NOT NULL DEFAULT false,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT automation_rules_actions_present
        CHECK (jsonb_typeof(actions) = 'array' AND jsonb_array_length(actions) > 0),
    CONSTRAINT automation_rules_actions_permitted
        CHECK (automation_actions_permitted(actions)),
    CONSTRAINT automation_rules_conditions_array
        CHECK (jsonb_typeof(conditions) = 'array')
);

CREATE INDEX IF NOT EXISTS automation_rules_trigger_idx
    ON automation_rules (organization_id, trigger_kind) WHERE enabled;

-- Every evaluation, including the ones that did nothing.
CREATE TABLE IF NOT EXISTS automation_runs (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    rule_id          uuid NOT NULL REFERENCES automation_rules(id) ON DELETE CASCADE,
    trigger_kind     text NOT NULL,
    subject_id       uuid,
    matched          boolean NOT NULL,
    -- Which condition failed, in words. NULL only when matched.
    skip_reason      text,
    -- What was produced: [{kind, text, offsetDays}]. Empty when not matched.
    actions_taken    jsonb NOT NULL DEFAULT '[]'::jsonb,
    ran_at           timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT automation_runs_skip_has_reason
        CHECK (matched OR skip_reason IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS automation_runs_rule_idx
    ON automation_runs (rule_id, ran_at DESC);
CREATE INDEX IF NOT EXISTS automation_runs_org_day_idx
    ON automation_runs (organization_id, ran_at DESC);

-- ---------------------------------------------------------------------------
-- Reports
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reports (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    kind             text NOT NULL
                     CHECK (kind IN ('daily','weekly','monthly','campaign','seo',
                                     'aeo','schema','social','executive')),
    title            text NOT NULL,
    period_from      date NOT NULL,
    period_to        date NOT NULL,
    period_label     text NOT NULL,
    -- The rendered report: sections, points and every MetricValue with its
    -- provenance. Stored whole so a shared link never changes under the reader.
    document         jsonb NOT NULL,
    -- Which sources were connected when it was generated. Denormalised on
    -- purpose: the report must still be readable after a connection is removed.
    connected_sources text[] NOT NULL DEFAULT ARRAY[]::text[],
    generated_by     uuid REFERENCES users(id) ON DELETE SET NULL,
    generated_at     timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT reports_period_ordered CHECK (period_to >= period_from)
);

CREATE INDEX IF NOT EXISTS reports_project_idx
    ON reports (organization_id, project_id, generated_at DESC);

-- A revocable, expiring, unauthenticated link to one report.
CREATE TABLE IF NOT EXISTS report_shares (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    report_id        uuid NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    -- sha256 of the token. The token itself is shown once and never stored.
    token_hash       text NOT NULL UNIQUE,
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at       timestamptz NOT NULL DEFAULT now(),
    expires_at       timestamptz NOT NULL,
    revoked_at       timestamptz,
    last_viewed_at   timestamptz,
    view_count       integer NOT NULL DEFAULT 0,
    CONSTRAINT report_shares_expiry_future CHECK (expires_at > created_at)
);

CREATE INDEX IF NOT EXISTS report_shares_report_idx
    ON report_shares (report_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- Notification preferences
-- ---------------------------------------------------------------------------
-- Per user, per kind. A user with NO ROW for a kind gets the application
-- default, so adding a new kind does not arrive switched off for everyone who
-- already has a row for something else.
--
-- `email` exists as a column while no email provider is connected, because the
-- preference is the user's to hold even when SeSha cannot yet act on it. The
-- application refuses to set it to true until a provider exists, so nothing in
-- here can quietly become a promise to send.
-- ---------------------------------------------------------------------------

ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_kind_check;
ALTER TABLE notifications ADD CONSTRAINT notifications_kind_check
    CHECK (kind IN ('security','billing','system','content','lead','report',
                    'report_ready','new_lead','campaign_changed','content_scheduled',
                    'schema_error','audit_complete','crawl_complete','validation_complete'));

CREATE TABLE IF NOT EXISTS notification_preferences (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id          uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind             text NOT NULL
                     CHECK (kind IN ('report_ready','new_lead','campaign_changed',
                                     'content_scheduled','schema_error','audit_complete',
                                     'crawl_complete','validation_complete',
                                     'security','billing','system')),
    in_app           boolean NOT NULL DEFAULT true,
    email            boolean NOT NULL DEFAULT false,
    updated_at       timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT notification_preferences_unique UNIQUE (user_id, kind),
    -- The two kinds a user may not silence. Enforced here as well as in the
    -- application, so a direct UPDATE cannot mute a security alert.
    CONSTRAINT notification_preferences_always_on
        CHECK (kind NOT IN ('security','billing') OR in_app)
);

CREATE INDEX IF NOT EXISTS notification_preferences_user_idx
    ON notification_preferences (user_id);

-- ---------------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------------

ALTER TABLE data_connections          ENABLE ROW LEVEL SECURITY;
ALTER TABLE calendar_events           ENABLE ROW LEVEL SECURITY;
ALTER TABLE automation_rules          ENABLE ROW LEVEL SECURITY;
ALTER TABLE automation_runs           ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports                   ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_shares             ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_preferences  ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
    target text;
BEGIN
    FOREACH target IN ARRAY ARRAY['data_connections','calendar_events','automation_rules',
                                  'automation_runs','reports','report_shares',
                                  'notification_preferences']
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON %I', target || '_tenant_isolation', target);
        EXECUTE format(
            'CREATE POLICY %I ON %I USING (organization_id = current_setting(%L, true)::uuid)',
            target || '_tenant_isolation', target, 'app.current_organization'
        );
    END LOOP;
END
$$;

-- ---------------------------------------------------------------------------
-- updated_at maintenance
-- ---------------------------------------------------------------------------

CREATE TRIGGER data_connections_updated_at BEFORE UPDATE ON data_connections
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER calendar_events_updated_at BEFORE UPDATE ON calendar_events
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER automation_rules_updated_at BEFORE UPDATE ON automation_rules
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER notification_preferences_updated_at BEFORE UPDATE ON notification_preferences
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Account deletion
-- ---------------------------------------------------------------------------
-- Notification preferences are personal data and are destroyed with the user.
-- Everything else added here is organization data keyed to the organization,
-- and is removed by the organization's own cascade.
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION anonymize_deleted_user(target_user uuid) RETURNS void AS $$
BEGIN
    UPDATE users
       SET email             = 'deleted-' || target_user || '@invalid',
           name              = NULL,
           password_hash     = NULL,
           timezone          = NULL,
           email_verified_at = NULL
     WHERE id = target_user
       AND deleted_at IS NOT NULL;

    DELETE FROM oauth_accounts             WHERE user_id = target_user;
    DELETE FROM sessions                   WHERE user_id = target_user;
    DELETE FROM email_verification_tokens  WHERE user_id = target_user;
    DELETE FROM password_reset_tokens      WHERE user_id = target_user;
    DELETE FROM notifications              WHERE user_id = target_user;
    DELETE FROM notification_preferences   WHERE user_id = target_user;
END;
$$ LANGUAGE plpgsql;

COMMENT ON TABLE data_connections IS
    'One row per connected provider. No row means not connected. Holds no access
     token: token custody belongs with the credential store.';
COMMENT ON TABLE automation_runs IS
    'Every evaluation, including non-matches. A rule that quietly stops matching
     is otherwise indistinguishable from one that never runs.';
COMMENT ON TABLE reports IS
    'The rendered report, stored whole, so a shared link shows what it showed
     when it was sent rather than being re-run against today''s data.';
COMMENT ON TABLE report_shares IS
    'Revocable, expiring share links. Only the sha256 of the token is stored.';

-- ===== 0007_subscriptions_usage_admin.sql ==========================

-- ---------------------------------------------------------------------------
-- Migration 0007 — Phase 7: plans, usage, quotas, billing, the admin platform,
--                  feature flags
-- ---------------------------------------------------------------------------
-- Forward-only. Do not edit once applied; add a new migration instead.
--
-- Conventions carried forward: uuid keys, timestamptz, organization_id plus
-- row-level security on every tenant-scoped table, ON DELETE on every foreign
-- key, soft delete only where history references the row.
--
-- SIX DECISIONS IN HERE ARE LOAD-BEARING AND ARE NOT STYLISTIC:
--
-- 1. THE PLAN RENAME IS DONE IN THREE STEPS, NOT ONE. The CHECK is widened to
--    accept both vocabularies, the rows are migrated, and only then is it
--    narrowed. A single `ALTER ... CHECK (plan IN ('free',...))` would fail on
--    the first existing row and abort the whole migration. The mapping is
--    upward — `starter` was a PAID tier and becomes `pro`, never `free` — and
--    `tests/plans.test.ts` asserts no migrated organization loses a limit.
--
-- 2. `platform_staff` IS NOT A ROLE ON `memberships`. An organization admin is
--    a customer; a platform admin is staff. One table, one scale, one guard
--    each, and nothing in the organization role system grants anything here.
--    Putting platform access on `memberships.role` would let any customer who
--    made themselves an admin of their own workspace read every other
--    customer's data.
--
-- 3. `admin_actions` HAS NO CASCADE TO `organizations`. Every other
--    organization-scoped table cascades on delete, which is correct for
--    customer data and wrong for the record of what staff did: deleting a
--    tenant would erase the evidence of every admin action taken against it.
--    `target_organization_id` is a plain uuid with no foreign key for exactly
--    that reason, and the table has no UPDATE or DELETE policy.
--
-- 4. QUOTA REFUSALS GET THEIR OWN TABLE rather than a `refused` flag on
--    `usage_records`. A flag would mean every total had to remember to filter
--    it, and a forgotten filter over-counts usage — which wrongly BLOCKS a
--    paying customer. Separating them makes that mistake unavailable.
--
-- 5. THERE IS NO COLUMN ANYWHERE THAT COULD HOLD A CARD. No number, no token,
--    no CVV, no bank detail — not nullable, not "temporary". `subscriptions`
--    gains four display-metadata columns (brand, last four, expiry month and
--    year) which are what every provider returns and none of which can charge
--    anybody. `tests/billing.test.ts` greps every migration for the column
--    names a card would have.
--
-- 6. `billing_events.external_event_id` IS UNIQUE. Payment providers retry
--    webhooks and deliver them out of order; without an idempotency key, a
--    retried `payment_succeeded` is applied twice. The unique constraint is the
--    guarantee, not the application code that also checks.
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- 1. The plan rename: widen, migrate, narrow
-- ---------------------------------------------------------------------------

ALTER TABLE organizations DROP CONSTRAINT IF EXISTS organizations_plan_check;
ALTER TABLE organizations ADD CONSTRAINT organizations_plan_check
    CHECK (plan IN ('starter','growth','agency','free','pro','business'));

ALTER TABLE subscriptions DROP CONSTRAINT IF EXISTS subscriptions_plan_check;
ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_plan_check
    CHECK (plan IN ('starter','growth','agency','free','pro','business'));

-- The mapping. Upward only: nobody moves to a plan with a lower limit.
--   starter -> pro        (both paid, comparable position)
--   growth  -> business
--   agency  -> agency     (unchanged)
-- Nobody is migrated to `free`, which is new.
UPDATE organizations SET plan = 'pro'      WHERE plan = 'starter';
UPDATE organizations SET plan = 'business' WHERE plan = 'growth';
UPDATE subscriptions SET plan = 'pro'      WHERE plan = 'starter';
UPDATE subscriptions SET plan = 'business' WHERE plan = 'growth';

ALTER TABLE organizations DROP CONSTRAINT organizations_plan_check;
ALTER TABLE organizations ADD CONSTRAINT organizations_plan_check
    CHECK (plan IN ('free','pro','business','agency'));
ALTER TABLE organizations ALTER COLUMN plan SET DEFAULT 'free';

ALTER TABLE subscriptions DROP CONSTRAINT subscriptions_plan_check;
ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_plan_check
    CHECK (plan IN ('free','pro','business','agency'));
ALTER TABLE subscriptions ALTER COLUMN plan SET DEFAULT 'free';

-- ---------------------------------------------------------------------------
-- 2. Subscription state
-- ---------------------------------------------------------------------------
-- `incomplete` is added because a checkout that was started and not finished is
-- not an active subscription, and treating it as one grants access to someone
-- who never paid.

ALTER TABLE subscriptions DROP CONSTRAINT IF EXISTS subscriptions_status_check;
ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_status_check
    CHECK (status IN ('trialing','active','past_due','canceled','paused','incomplete'));

ALTER TABLE subscriptions
    -- When the payment first failed, so the grace window can be measured. A
    -- past_due row with no timestamp gives the customer the benefit of the doubt.
    ADD COLUMN IF NOT EXISTS past_due_since      timestamptz,
    ADD COLUMN IF NOT EXISTS canceled_at         timestamptz,
    ADD COLUMN IF NOT EXISTS provider            text,
    -- DISPLAY METADATA ONLY. Nothing here can be used to charge anyone, and
-- there is deliberately no column for a number, a token, a CVV or a bank
    -- account. See decision 5 in the header.
    ADD COLUMN IF NOT EXISTS payment_brand       text,
    ADD COLUMN IF NOT EXISTS payment_last4       text
                                                 CHECK (payment_last4 IS NULL OR payment_last4 ~ '^[0-9]{4}$'),
    ADD COLUMN IF NOT EXISTS payment_expiry_month smallint
                                                 CHECK (payment_expiry_month IS NULL OR payment_expiry_month BETWEEN 1 AND 12),
    ADD COLUMN IF NOT EXISTS payment_expiry_year  smallint
                                                 CHECK (payment_expiry_year IS NULL OR payment_expiry_year BETWEEN 2000 AND 2100);

-- A past_due subscription must record when it went past due, or the grace
-- window cannot be measured and the customer is never cut off.
ALTER TABLE subscriptions DROP CONSTRAINT IF EXISTS subscriptions_past_due_dated;
ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_past_due_dated
    CHECK (status <> 'past_due' OR past_due_since IS NOT NULL);

-- ---------------------------------------------------------------------------
-- 3. Usage
-- ---------------------------------------------------------------------------
-- `seo_audit` and `aeo_audit` replace the single `audit_run`, because the brief
-- gives SEO and AEO separate limits and one counter cannot enforce two. The old
-- value is kept in the CHECK: rows already exist under it and rewriting history
-- to tidy an enum is worse than carrying one extra value.
--
-- `api_call` is new in Phase 7.

ALTER TABLE usage_records DROP CONSTRAINT IF EXISTS usage_records_metric_check;
ALTER TABLE usage_records ADD CONSTRAINT usage_records_metric_check
    CHECK (metric IN ('ai_generation','ai_tokens','content_item','crawl_page',
                      'crawl_run','audit_run','report','automation_run','seat',
                      'schema_validation','competitor_analysis','lead',
                      'calendar_event','report_export',
                      'seo_audit','aeo_audit','api_call'));

CREATE INDEX IF NOT EXISTS usage_records_period_idx
    ON usage_records (organization_id, period_start, metric);

-- Refusals, in their own table. See decision 4 in the header.
-- A customer blocked thirty times a day is a sales signal, and it is invisible
-- unless the refusal is recorded.
CREATE TABLE IF NOT EXISTS quota_refusals (
    id               bigserial PRIMARY KEY,
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    project_id       uuid REFERENCES projects(id) ON DELETE SET NULL,
    user_id          uuid REFERENCES users(id) ON DELETE SET NULL,
    limit_id         text NOT NULL
                     CHECK (limit_id IN ('ai_requests','tokens','content_generations',
                                         'website_crawls','seo_audits','aeo_audits',
                                         'schema_validations','projects','team_members',
                                         'reports','automations')),
    reason           text NOT NULL
                     CHECK (reason IN ('period_exhausted','at_capacity','not_included',
                                       'subscription_blocked')),
    plan             text NOT NULL,
    -- What they had used and what the limit was, at the moment of refusal, so a
    -- later limit change does not rewrite the history of why someone was blocked.
    used_at_refusal  integer NOT NULL DEFAULT 0,
    limit_at_refusal integer,
    period_start     date NOT NULL,
    refused_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS quota_refusals_org_idx
    ON quota_refusals (organization_id, refused_at DESC);
CREATE INDEX IF NOT EXISTS quota_refusals_limit_idx
    ON quota_refusals (limit_id, refused_at DESC);

-- ---------------------------------------------------------------------------
-- 4. Plan limit overrides
-- ---------------------------------------------------------------------------
-- How "Admin controls: Plans, Limits" is satisfied without a deployment.
-- `reason` is NOT NULL because "why is this customer's limit 40?" gets asked,
-- and an override nobody can explain is an override nobody dares remove.

CREATE TABLE IF NOT EXISTS plan_limit_overrides (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    limit_id         text NOT NULL
                     CHECK (limit_id IN ('ai_requests','tokens','content_generations',
                                         'website_crawls','seo_audits','aeo_audits',
                                         'schema_validations','projects','team_members',
                                         'reports','automations')),
    -- NULL means unlimited. A negative value is refused: a negative ceiling
    -- makes every check fail with no message that makes sense.
    value            integer CHECK (value IS NULL OR value >= 0),
    reason           text NOT NULL CHECK (length(trim(reason)) > 0),
    set_by           uuid REFERENCES users(id) ON DELETE SET NULL,
    set_at           timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT plan_limit_overrides_unique UNIQUE (organization_id, limit_id)
);

-- ---------------------------------------------------------------------------
-- 5. Platform staff
-- ---------------------------------------------------------------------------
-- See decision 2 in the header. This table is the ONLY thing that grants admin
-- access, and a revoked row grants nothing — checked on every request rather
-- than trusted from a session, which could be thirty days old.

CREATE TABLE IF NOT EXISTS platform_staff (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      uuid NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    role         text NOT NULL CHECK (role IN ('support','engineer','platform_owner')),
    -- Who granted it. Nullable only for the first row, which has to be seeded.
    granted_by   uuid REFERENCES users(id) ON DELETE SET NULL,
    granted_at   timestamptz NOT NULL DEFAULT now(),
    revoked_by   uuid REFERENCES users(id) ON DELETE SET NULL,
    revoked_at   timestamptz,
    -- Why this person has platform access. Required: an unexplained staff row
    -- is the one nobody removes when someone changes team.
    reason       text NOT NULL CHECK (length(trim(reason)) > 0),
    CONSTRAINT platform_staff_revocation_complete
        CHECK ((revoked_at IS NULL) = (revoked_by IS NULL))
);

CREATE INDEX IF NOT EXISTS platform_staff_active_idx
    ON platform_staff (user_id) WHERE revoked_at IS NULL;

-- ---------------------------------------------------------------------------
-- 6. Admin actions
-- ---------------------------------------------------------------------------
-- Every admin action, INCLUDING READS. "Who looked at which customer" is the
-- question an audit log exists to answer, and a log of writes only cannot.
--
-- No cascade to organizations — see decision 3 in the header.

CREATE TABLE IF NOT EXISTS admin_actions (
    id                     bigserial PRIMARY KEY,
    staff_user_id          uuid REFERENCES users(id) ON DELETE SET NULL,
    staff_role             text NOT NULL,
    permission             text NOT NULL,
    action                 text NOT NULL,
    -- 'read' or 'write', so the log can be filtered to changes.
    kind                   text NOT NULL CHECK (kind IN ('read','write')),
    target_type            text NOT NULL,
    target_id              text,
    -- Deliberately NOT a foreign key. See decision 3.
    target_organization_id uuid,
    -- What changed, summarised. Never customer content: an audit log is not a
    -- second copy of the customer's data.
    metadata               jsonb NOT NULL DEFAULT '{}'::jsonb,
    outcome                text NOT NULL DEFAULT 'success'
                           CHECK (outcome IN ('success','failure','denied')),
    session_id             uuid,
    ip_hash                bytea,
    created_at             timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS admin_actions_staff_idx
    ON admin_actions (staff_user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS admin_actions_target_org_idx
    ON admin_actions (target_organization_id, created_at DESC);
CREATE INDEX IF NOT EXISTS admin_actions_writes_idx
    ON admin_actions (created_at DESC) WHERE kind = 'write';

-- ---------------------------------------------------------------------------
-- 7. Billing events
-- ---------------------------------------------------------------------------
-- The subscription's history, and the idempotency guarantee for webhooks.
--
-- `payload_summary` is a SUMMARY, not the raw body. A provider payload contains
-- more customer data than this product needs, and storing it wholesale would
-- create a second copy of it in a table an admin can read.

CREATE TABLE IF NOT EXISTS billing_events (
    id                   bigserial PRIMARY KEY,
    organization_id      uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    -- The provider's own event id. UNIQUE: see decision 6 in the header.
    external_event_id    text UNIQUE,
    provider             text NOT NULL,
    event                text NOT NULL
                         CHECK (event IN ('trial_started','checkout_completed',
                                          'payment_succeeded','payment_failed','renewed',
                                          'plan_changed','cancellation_requested',
                                          'cancellation_effective','paused','resumed')),
    status_before        text,
    status_after         text,
    plan_before          text,
    plan_after           text,
    -- Recorded even when the event changed nothing, with the reason. An ignored
    -- webhook is normal and must be visible, not silent.
    applied              boolean NOT NULL DEFAULT true,
    note                 text,
    payload_summary      jsonb NOT NULL DEFAULT '{}'::jsonb,
    occurred_at          timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS billing_events_org_idx
    ON billing_events (organization_id, occurred_at DESC);

-- ---------------------------------------------------------------------------
-- 8. Feature flag rules
-- ---------------------------------------------------------------------------
-- One row per flag. The key is constrained to the application's registry by the
-- application, not here: the registry is code, and a CHECK listing every flag
-- would need a migration to add one. `disabled` is the kill switch and beats
-- every other column.

CREATE TABLE IF NOT EXISTS feature_flag_rules (
    key                        text PRIMARY KEY,
    disabled                   boolean NOT NULL DEFAULT false,
    organization_ids           uuid[] NOT NULL DEFAULT ARRAY[]::uuid[],
    excluded_organization_ids  uuid[] NOT NULL DEFAULT ARRAY[]::uuid[],
    plans                      text[] NOT NULL DEFAULT ARRAY[]::text[],
    rollout_percent            smallint NOT NULL DEFAULT 0
                               CHECK (rollout_percent BETWEEN 0 AND 100),
    updated_by                 uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_at                 timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- 9. System settings
-- ---------------------------------------------------------------------------
-- Backs the brief's Templates, Prompts, Validator configuration and System
-- configuration controls. One table with a namespaced key, and — as with flags —
-- the set of permitted keys is a registry in code, so a setting cannot be
-- created by typing a new name into a form and then never found again.

CREATE TABLE IF NOT EXISTS system_settings (
    key         text PRIMARY KEY,
    value       jsonb NOT NULL,
    updated_by  uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_at  timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- 10. Errors
-- ---------------------------------------------------------------------------
-- Backs the "Errors" dashboard. `fingerprint` groups recurrences so the panel
-- shows twelve distinct problems rather than nine thousand lines.
--
-- NO STACK TRACE AND NO REQUEST BODY. A stack can contain a token read from a
-- header and a body can contain a customer's content; this table is read by
-- staff, so it holds only what is needed to find the problem in the code.

CREATE TABLE IF NOT EXISTS error_events (
    id               bigserial PRIMARY KEY,
    fingerprint      text NOT NULL,
    severity         text NOT NULL CHECK (severity IN ('warning','error','critical')),
    source           text NOT NULL,
    message          text NOT NULL,
    -- Which tenant hit it, for support. Nullable: a public-site error has none.
    organization_id  uuid REFERENCES organizations(id) ON DELETE SET NULL,
    occurrences      integer NOT NULL DEFAULT 1 CHECK (occurrences > 0),
    first_seen_at    timestamptz NOT NULL DEFAULT now(),
    last_seen_at     timestamptz NOT NULL DEFAULT now(),
    resolved_at      timestamptz,
    resolved_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT error_events_fingerprint_unique UNIQUE (fingerprint)
);

CREATE INDEX IF NOT EXISTS error_events_open_idx
    ON error_events (last_seen_at DESC) WHERE resolved_at IS NULL;

-- ---------------------------------------------------------------------------
-- 11. Feedback
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS feedback (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  uuid REFERENCES organizations(id) ON DELETE SET NULL,
    user_id          uuid REFERENCES users(id) ON DELETE SET NULL,
    kind             text NOT NULL CHECK (kind IN ('bug','idea','praise','other')),
    message          text NOT NULL CHECK (length(trim(message)) > 0),
    -- Which screen it came from, so a report is actionable.
    surface          text,
    status           text NOT NULL DEFAULT 'new'
                     CHECK (status IN ('new','triaged','answered','closed')),
    triaged_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    triaged_at       timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS feedback_status_idx ON feedback (status, created_at DESC);

-- ---------------------------------------------------------------------------
-- Row-level security
-- ---------------------------------------------------------------------------
-- The tenant-scoped tables get the same policy as every other. The PLATFORM
-- tables deliberately do not: `platform_staff`, `admin_actions`,
-- `feature_flag_rules`, `system_settings` and `error_events` are not tenant
-- data and have no organization to scope to. They are reached only through the
-- admin service, which runs on a connection that does not set
-- `app.current_organization`, and are never exposed to a tenant-facing route.

ALTER TABLE quota_refusals       ENABLE ROW LEVEL SECURITY;
ALTER TABLE plan_limit_overrides ENABLE ROW LEVEL SECURITY;
ALTER TABLE billing_events       ENABLE ROW LEVEL SECURITY;
ALTER TABLE feedback             ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
    target text;
BEGIN
    FOREACH target IN ARRAY ARRAY['quota_refusals','plan_limit_overrides','billing_events']
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON %I', target || '_tenant_isolation', target);
        EXECUTE format(
            'CREATE POLICY %I ON %I USING (organization_id = current_setting(%L, true)::uuid)',
            target || '_tenant_isolation', target, 'app.current_organization'
        );
    END LOOP;
END
$$;

-- Feedback's organization_id is nullable (the public site has none), so its
-- policy has to permit a null row rather than comparing it and getting NULL,
-- which would silently hide every anonymous submission from everyone.
DROP POLICY IF EXISTS feedback_tenant_isolation ON feedback;
CREATE POLICY feedback_tenant_isolation ON feedback
    USING (organization_id IS NULL
           OR organization_id = current_setting('app.current_organization', true)::uuid);

-- ---------------------------------------------------------------------------
-- updated_at maintenance
-- ---------------------------------------------------------------------------

CREATE TRIGGER feature_flag_rules_updated_at BEFORE UPDATE ON feature_flag_rules
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER system_settings_updated_at BEFORE UPDATE ON system_settings
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Account deletion
-- ---------------------------------------------------------------------------
-- Feedback a user wrote is personal data and goes with them. Their platform
-- staff row goes too — a deleted account must not retain admin access.
--
-- `admin_actions.staff_user_id` is ON DELETE SET NULL rather than cascading:
-- the record of what was done survives the person who did it, which is the
-- entire point of an audit log.

CREATE OR REPLACE FUNCTION anonymize_deleted_user(target_user uuid) RETURNS void AS $$
BEGIN
    UPDATE users
       SET email             = 'deleted-' || target_user || '@invalid',
           name              = NULL,
           password_hash     = NULL,
           timezone          = NULL,
           email_verified_at = NULL
     WHERE id = target_user
       AND deleted_at IS NOT NULL;

    DELETE FROM oauth_accounts             WHERE user_id = target_user;
    DELETE FROM sessions                   WHERE user_id = target_user;
    DELETE FROM email_verification_tokens  WHERE user_id = target_user;
    DELETE FROM password_reset_tokens      WHERE user_id = target_user;
    DELETE FROM notifications              WHERE user_id = target_user;
    DELETE FROM notification_preferences   WHERE user_id = target_user;
    DELETE FROM platform_staff             WHERE user_id = target_user;
    DELETE FROM feedback                   WHERE user_id = target_user;
END;
$$ LANGUAGE plpgsql;

COMMENT ON TABLE platform_staff IS
    'The only thing that grants admin access. An organization admin is a
     customer and is NOT platform staff. A revoked row grants nothing.';
COMMENT ON TABLE admin_actions IS
    'Every admin action including reads. No cascade to organizations: deleting a
     tenant must not erase the record of what staff did to it.';
COMMENT ON TABLE quota_refusals IS
    'Separate from usage_records so a forgotten filter cannot over-count usage
     and wrongly block a paying customer.';
COMMENT ON COLUMN subscriptions.payment_last4 IS
    'Display metadata only. There is deliberately no column anywhere for a card
     number, token, CVV or bank detail.';

-- ===== 0008_indexes_and_operations.sql =============================

-- ============================================================================
-- 0008 — Phase 8: the indexes that were missing, and operational tables.
--
-- FORWARD-ONLY. No table is dropped, no column is removed.
--
-- WHY A WHOLE MIGRATION OF INDEXES
-- A Phase 8 audit walked every repository method against every index and found
-- two distinct classes of gap. Neither shows up in development, because the
-- in-memory adapter scans arrays and does not care, and both become an incident
-- on the first table with real row counts.
--
--   1. UNINDEXED FOREIGN KEYS. PostgreSQL does NOT index a foreign key for you.
--      It indexes the PRIMARY KEY of the parent, not the column that references
--      it. So every `DELETE FROM users` takes a sequential scan of every child
--      table to check the constraint — and account deletion touches a dozen of
--      them. On a large `admin_actions` or `feedback` table that is the
--      difference between a delete that returns and one that holds a lock while
--      support wonder why the page is spinning.
--
--   2. QUERY-SHAPE GAPS. An index on `(organization_id, project_id, event_date)`
--      cannot serve a query that filters on `(organization_id, source_kind)` —
--      a btree is only usable from its leading column onwards. Several indexes
--      added in 0006 and 0007 lead with a column the actual query does not
--      supply, which makes them dead weight for that path: the cost of
--      maintaining an index with none of the benefit.
--
-- CREATE INDEX IF NOT EXISTS throughout, so this is safe to re-run.
--
-- A NOTE ON `CONCURRENTLY`. These are written WITHOUT it, because
-- `CREATE INDEX CONCURRENTLY` cannot run inside a transaction block and every
-- migration in this project is wrapped in one — a property worth more than the
-- ability to build these particular indexes online. On a large live table, build
-- them by hand with CONCURRENTLY first; `IF NOT EXISTS` then makes this file a
-- no-op for the ones already there. That is the whole reason it is written this
-- way.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. Unindexed foreign keys
--
-- Every one of these is a column that REFERENCES another table and had no index
-- of its own. Listed by the parent whose deletes they slow down.
-- ---------------------------------------------------------------------------

-- → users(id). Account deletion scans each of these without an index.
CREATE INDEX IF NOT EXISTS calendar_events_created_by_idx
  ON calendar_events (created_by);
CREATE INDEX IF NOT EXISTS automation_rules_created_by_idx
  ON automation_rules (created_by);
CREATE INDEX IF NOT EXISTS reports_generated_by_idx
  ON reports (generated_by);
CREATE INDEX IF NOT EXISTS report_shares_created_by_idx
  ON report_shares (created_by);
CREATE INDEX IF NOT EXISTS quota_refusals_user_idx
  ON quota_refusals (user_id);
CREATE INDEX IF NOT EXISTS plan_limit_overrides_set_by_idx
  ON plan_limit_overrides (set_by);
CREATE INDEX IF NOT EXISTS platform_staff_granted_by_idx
  ON platform_staff (granted_by);
CREATE INDEX IF NOT EXISTS platform_staff_revoked_by_idx
  ON platform_staff (revoked_by);
CREATE INDEX IF NOT EXISTS error_events_resolved_by_idx
  ON error_events (resolved_by);
CREATE INDEX IF NOT EXISTS feedback_user_idx
  ON feedback (user_id);
CREATE INDEX IF NOT EXISTS feedback_triaged_by_idx
  ON feedback (triaged_by);

-- → organizations(id). Deleting an organization cascades through these.
CREATE INDEX IF NOT EXISTS report_shares_org_idx
  ON report_shares (organization_id);
CREATE INDEX IF NOT EXISTS notification_preferences_org_idx
  ON notification_preferences (organization_id);
CREATE INDEX IF NOT EXISTS error_events_org_idx
  ON error_events (organization_id);
CREATE INDEX IF NOT EXISTS feedback_org_idx
  ON feedback (organization_id);

-- → projects(id).
CREATE INDEX IF NOT EXISTS automation_rules_project_idx
  ON automation_rules (organization_id, project_id);
CREATE INDEX IF NOT EXISTS quota_refusals_project_idx
  ON quota_refusals (project_id);

-- ---------------------------------------------------------------------------
-- 2. Query-shape gaps
--
-- Each of these serves a repository method that no existing index could help,
-- named in the comment so the pairing survives.
-- ---------------------------------------------------------------------------

-- CalendarRepository.findBySource(organizationId, kind, id). The existing
-- range index leads with project_id, which this lookup does not supply.
CREATE INDEX IF NOT EXISTS calendar_events_source_idx
  ON calendar_events (organization_id, source_kind, source_id);

-- BillingEventRepository.listRecent() reads ACROSS tenants, newest first, for
-- the admin panel. `billing_events_org_idx` leads with organization_id and
-- cannot serve a global ordered scan.
CREATE INDEX IF NOT EXISTS billing_events_recent_idx
  ON billing_events (occurred_at DESC);

-- AdminActionRepository.list({ kind: 'read' }). 0007 added a partial index for
-- `kind = 'write'` only, so the reads — which are the majority, and the whole
-- point of auditing a cross-tenant panel — had nothing.
CREATE INDEX IF NOT EXISTS admin_actions_kind_idx
  ON admin_actions (kind, created_at DESC);

-- ErrorEventRepository.countSince() counts resolved rows too, so the partial
-- `WHERE resolved_at IS NULL` index excludes exactly what it needs.
CREATE INDEX IF NOT EXISTS error_events_last_seen_idx
  ON error_events (last_seen_at DESC);

-- FeedbackRepository.list() with no status filter sorts by created_at, and
-- `feedback_status_idx` leads with status.
CREATE INDEX IF NOT EXISTS feedback_created_idx
  ON feedback (created_at DESC);

-- Cursor pagination compares (created_at, id) as a row value. A composite index
-- in exactly that order is what makes `WHERE (created_at, id) < ($1, $2)` an
-- index scan rather than a sort of the whole table.
CREATE INDEX IF NOT EXISTS admin_actions_cursor_idx
  ON admin_actions (created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS audit_log_cursor_idx
  ON audit_log (created_at DESC, id DESC);

-- ---------------------------------------------------------------------------
-- 3. Job recovery
--
-- WHAT THIS FIXES: a worker that dies mid-job leaves the row in `running`
-- forever. Nothing reaps it, nothing retries it, and the customer's crawl simply
-- never finishes — the failure mode that looks like a hang rather than an error,
-- which is the worst kind to diagnose from a support ticket.
--
-- `heartbeat_at` is written by the worker as it makes progress. A row in
-- `running` whose heartbeat is older than the threshold had its worker die, and
-- can be returned to the queue. This is a column rather than a separate table
-- because the alternative — inferring death from `started_at` alone — cannot
-- tell a dead worker from a slow one, and would cancel long legitimate crawls.
-- ---------------------------------------------------------------------------

ALTER TABLE jobs
  ADD COLUMN IF NOT EXISTS heartbeat_at timestamptz,
  -- Set when a job is returned to the queue by the reaper rather than by its
  -- own worker, so "why did this run twice" has an answer.
  ADD COLUMN IF NOT EXISTS recovered_count integer NOT NULL DEFAULT 0;

COMMENT ON COLUMN jobs.heartbeat_at IS
  'Last progress signal from the worker. A running job whose heartbeat is stale had its worker die and is recoverable.';
COMMENT ON COLUMN jobs.recovered_count IS
  'How many times this job was returned to the queue by the reaper. A job recovered repeatedly is failing, not unlucky.';

-- Finds stalled jobs without scanning the whole table. Partial, because only
-- running jobs can stall.
CREATE INDEX IF NOT EXISTS jobs_stalled_idx
  ON jobs (heartbeat_at)
  WHERE status = 'running';

-- ---------------------------------------------------------------------------
-- 4. Idempotency keys
--
-- WHY A TABLE AND NOT JUST THE IN-MEMORY STORE: the in-memory one
-- (`lib/reliability`) is per-process, so with two instances behind a load
-- balancer the same key can run once on each — which is precisely the
-- double-charge the mechanism exists to prevent. This table is the durable half.
--
-- The UNIQUE constraint is the enforcement. Not a SELECT-then-INSERT, which
-- races exactly when it matters: two concurrent requests both find nothing and
-- both insert. The second INSERT violates the constraint and the caller replays
-- the first result instead.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS idempotency_keys (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id  uuid REFERENCES organizations(id) ON DELETE CASCADE,
  -- Scope keeps one feature's keys from colliding with another's.
  scope            text NOT NULL CHECK (length(scope) BETWEEN 1 AND 64),
  key              text NOT NULL CHECK (length(key) BETWEEN 1 AND 255),
  -- A SUMMARY of the outcome, never the full response: a response body can
  -- carry customer content, and this table is not a second copy of it.
  outcome          jsonb NOT NULL DEFAULT '{}'::jsonb,
  status           text NOT NULL DEFAULT 'succeeded'
                     CHECK (status IN ('succeeded', 'failed')),
  created_at       timestamptz NOT NULL DEFAULT now(),
  expires_at       timestamptz NOT NULL,

  UNIQUE (scope, key)
);

COMMENT ON TABLE idempotency_keys IS
  'At-most-once execution for critical operations, durable across instances. The UNIQUE (scope, key) constraint is the enforcement; a SELECT-then-INSERT would race exactly when two requests arrive together, which is the case this exists for.';

CREATE INDEX IF NOT EXISTS idempotency_keys_expiry_idx
  ON idempotency_keys (expires_at);
CREATE INDEX IF NOT EXISTS idempotency_keys_org_idx
  ON idempotency_keys (organization_id);

ALTER TABLE idempotency_keys ENABLE ROW LEVEL SECURITY;

-- Rows with a NULL organization are platform-level (a provider webhook, which
-- belongs to no tenant until it has been read). They are invisible to tenants.
CREATE POLICY idempotency_keys_tenant_isolation ON idempotency_keys
  USING (organization_id = current_setting('app.current_organization', true)::uuid);

-- ===== 0009_foreign_key_indexes.sql ================================

-- ============================================================================
-- 0009 — Phase 9: the foreign keys 0008 did not reach.
--
-- FORWARD-ONLY. Indexes only; no table or column is changed.
--
-- The Phase 9 database audit parsed db/schema.sql and listed every column that
-- REFERENCES another table without an index whose LEADING column it is.
-- PostgreSQL does not index a referencing column for you, so each of these
-- made a DELETE of the parent row (an account deletion, an organization
-- deletion, a job cleanup) scan the child table. 0008 fixed seventeen; this
-- file fixes the remaining ones, and tests/database-audit.test.ts now fails if
-- a new unindexed foreign key is ever added.
--
-- CONCURRENTLY is not used for the reason given in 0008.
-- ============================================================================

CREATE INDEX IF NOT EXISTS businesses_created_by_fk_idx ON businesses (created_by);
CREATE INDEX IF NOT EXISTS projects_business_id_fk_idx ON projects (business_id);
CREATE INDEX IF NOT EXISTS projects_created_by_fk_idx ON projects (created_by);
CREATE INDEX IF NOT EXISTS website_crawl_consents_organization_id_fk_idx ON website_crawl_consents (organization_id);
CREATE INDEX IF NOT EXISTS website_crawl_consents_granted_by_fk_idx ON website_crawl_consents (granted_by);
CREATE INDEX IF NOT EXISTS usage_records_project_id_fk_idx ON usage_records (project_id);
CREATE INDEX IF NOT EXISTS notifications_organization_id_fk_idx ON notifications (organization_id);
CREATE INDEX IF NOT EXISTS notifications_project_id_fk_idx ON notifications (project_id);
CREATE INDEX IF NOT EXISTS ai_conversations_organization_id_fk_idx ON ai_conversations (organization_id);
CREATE INDEX IF NOT EXISTS ai_conversations_user_id_fk_idx ON ai_conversations (user_id);
CREATE INDEX IF NOT EXISTS content_items_created_by_fk_idx ON content_items (created_by);
CREATE INDEX IF NOT EXISTS content_items_reviewed_by_fk_idx ON content_items (reviewed_by);
CREATE INDEX IF NOT EXISTS strategies_organization_id_fk_idx ON strategies (organization_id);
CREATE INDEX IF NOT EXISTS strategies_created_by_fk_idx ON strategies (created_by);
CREATE INDEX IF NOT EXISTS social_posts_created_by_fk_idx ON social_posts (created_by);
CREATE INDEX IF NOT EXISTS jobs_created_by_fk_idx ON jobs (created_by);
CREATE INDEX IF NOT EXISTS crawls_job_id_fk_idx ON crawls (job_id);
CREATE INDEX IF NOT EXISTS crawls_started_by_fk_idx ON crawls (started_by);
CREATE INDEX IF NOT EXISTS audits_job_id_fk_idx ON audits (job_id);
CREATE INDEX IF NOT EXISTS keywords_crawl_id_fk_idx ON keywords (crawl_id);
CREATE INDEX IF NOT EXISTS schema_validations_created_by_fk_idx ON schema_validations (created_by);
CREATE INDEX IF NOT EXISTS competitors_created_by_fk_idx ON competitors (created_by);
CREATE INDEX IF NOT EXISTS competitor_acknowledgements_project_id_fk_idx ON competitor_acknowledgements (project_id);
CREATE INDEX IF NOT EXISTS competitor_acknowledgements_acknowledged_by_fk_idx ON competitor_acknowledgements (acknowledged_by);
CREATE INDEX IF NOT EXISTS competitor_analyses_acknowledgement_id_fk_idx ON competitor_analyses (acknowledgement_id);
CREATE INDEX IF NOT EXISTS competitor_analyses_job_id_fk_idx ON competitor_analyses (job_id);
CREATE INDEX IF NOT EXISTS competitor_analyses_created_by_fk_idx ON competitor_analyses (created_by);
CREATE INDEX IF NOT EXISTS ad_plans_created_by_fk_idx ON ad_plans (created_by);
CREATE INDEX IF NOT EXISTS lead_activities_created_by_fk_idx ON lead_activities (created_by);
CREATE INDEX IF NOT EXISTS messaging_plans_created_by_fk_idx ON messaging_plans (created_by);
CREATE INDEX IF NOT EXISTS video_scripts_created_by_fk_idx ON video_scripts (created_by);
CREATE INDEX IF NOT EXISTS data_connections_project_id_fk_idx ON data_connections (project_id);
CREATE INDEX IF NOT EXISTS data_connections_connected_by_fk_idx ON data_connections (connected_by);
CREATE INDEX IF NOT EXISTS calendar_events_project_id_fk_idx ON calendar_events (project_id);
CREATE INDEX IF NOT EXISTS automation_rules_project_id_fk_idx ON automation_rules (project_id);
CREATE INDEX IF NOT EXISTS reports_project_id_fk_idx ON reports (project_id);
CREATE INDEX IF NOT EXISTS feature_flag_rules_updated_by_fk_idx ON feature_flag_rules (updated_by);
CREATE INDEX IF NOT EXISTS system_settings_updated_by_fk_idx ON system_settings (updated_by);
CREATE INDEX IF NOT EXISTS brand_kits_organization_id_fk_idx ON brand_kits (organization_id);
CREATE INDEX IF NOT EXISTS leads_created_by_fk_idx ON leads (created_by);
CREATE INDEX IF NOT EXISTS ad_plans_reviewed_by_fk_idx ON ad_plans (reviewed_by);

