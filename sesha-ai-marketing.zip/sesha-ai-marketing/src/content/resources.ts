/**
 * Resource library.
 *
 * A hub page that links to the explainers, tools and articles already on the
 * site. It exists to serve the internal-linking architecture: it gives every
 * educational page a second, topical entry point beyond the header navigation.
 */

export interface ResourceItem {
  readonly title: string;
  readonly description: string;
  readonly href: string;
  readonly kind: 'guide' | 'tool' | 'article' | 'answers';
}

export interface ResourceCollection {
  readonly id: string;
  readonly heading: string;
  readonly intro: string;
  readonly items: readonly ResourceItem[];
}

export const resourceIntro = {
  heading: 'Resources',
  body: 'Practical explanations of the concepts this platform is built around — search optimisation, answer engine optimisation, structured data and AI-assisted marketing — plus the free tools on this site.',
} as const;

export const resourceCollections: readonly ResourceCollection[] = [
  {
    id: 'fundamentals',
    heading: 'Fundamentals',
    intro: 'Start here if you want the concepts defined clearly before the tactics.',
    items: [
      {
        title: 'Search engine optimisation',
        description:
          'What SEO covers, split into the three layers that have to work together: technical, content and internal links.',
        href: '/seo',
        kind: 'guide',
      },
      {
        title: 'Answer engine optimisation',
        description:
          'What AEO is, how it differs from SEO, and the four principles that make a passage quotable by an AI answer system.',
        href: '/aeo',
        kind: 'guide',
      },
      {
        title: 'Frequently asked questions',
        description:
          'Direct answers about what the platform does, how AI is used, what data is stored and how pricing works.',
        href: '/faq',
        kind: 'answers',
      },
    ],
  },
  {
    id: 'tools',
    heading: 'Free tools',
    intro: 'Usable now, with no account required.',
    items: [
      {
        title: 'JSON-LD schema validator',
        description:
          'Paste structured data and check it for missing required properties, malformed dates, broken breadcrumb ordering and invalid FAQ markup.',
        href: '/schema-validator',
        kind: 'tool',
      },
    ],
  },
  {
    id: 'articles',
    heading: 'Articles',
    intro: 'Longer pieces from the editorial team.',
    items: [
      {
        title: 'What is answer engine optimisation?',
        description:
          'The extraction test, why self-contained sentences matter, and where structured data fits into AEO.',
        href: '/blog',
        kind: 'article',
      },
      {
        title: 'Six structured data mistakes',
        description:
          'The JSON-LD failures we see most often — all of which fail silently rather than reporting an error.',
        href: '/blog',
        kind: 'article',
      },
      {
        title: 'Where AI helps in a marketing workflow',
        description:
          'A practical split between the tasks AI genuinely accelerates and the ones where handing over judgement is costly.',
        href: '/blog',
        kind: 'article',
      },
    ],
  },
  {
    id: 'by-industry',
    heading: 'By industry',
    intro: 'How the same modules adapt to different marketing realities.',
    items: [
      {
        title: 'Agencies',
        description: 'Per-client brand kits, repeatable delivery and client-ready reporting.',
        href: '/solutions/agencies',
        kind: 'guide',
      },
      {
        title: 'E-commerce',
        description: 'Category and product content at volume, with structured data that validates.',
        href: '/solutions/ecommerce',
        kind: 'guide',
      },
      {
        title: 'Local business',
        description: 'Service-area pages and local markup for nearby-intent search.',
        href: '/solutions/local-business',
        kind: 'guide',
      },
      {
        title: 'All industries',
        description: 'The full set of nine industry solution pages.',
        href: '/solutions',
        kind: 'guide',
      },
    ],
  },
];
