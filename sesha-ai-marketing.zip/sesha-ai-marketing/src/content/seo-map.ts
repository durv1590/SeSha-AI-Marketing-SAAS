/**
 * Per-route SEO copy.
 *
 * Every registered route must have an entry here, and every entry is linted by
 * `tests/seo.test.ts` for length, uniqueness and structure. That test is the
 * guard that stops a truncated title or a duplicate description from shipping.
 *
 * Claims policy: descriptions describe what the product *does*. No metrics,
 * customer counts, rankings or superlatives appear anywhere in this file.
 */

import type { SeoInput } from '@/lib/seo/core';

export const pageSeo: Record<string, SeoInput> = {
  '/': {
    title: 'AI-Powered Digital Marketing Command Center',
    description:
      'Plan strategy, create content, run campaigns and manage SEO, AEO and structured data from one AI-assisted marketing workspace.',
    path: '/',
    keywords: ['ai marketing platform', 'seo software', 'aeo', 'structured data', 'content studio'],
  },

  '/features': {
    title: 'Features',
    description:
      'Explore every SeSha module: AI copilot, strategy, content studio, SEO, AEO, schema tooling, campaigns, leads, analytics and automation.',
    path: '/features',
  },

  '/solutions': {
    title: 'Solutions by Industry',
    description:
      'See how SeSha adapts to small businesses, startups, agencies, e-commerce, local services, real estate, education, healthcare and restaurants.',
    path: '/solutions',
  },

  '/solutions/small-business': {
    title: 'AI Marketing for Small Business',
    description:
      'Run a complete marketing programme without a large team. SeSha helps small businesses plan, publish and measure with AI assistance.',
    path: '/solutions/small-business',
  },
  '/solutions/startups': {
    title: 'AI Marketing for Startups',
    description:
      'Test positioning, ship content quickly and build an early growth engine. SeSha gives startups a full marketing stack in one workspace.',
    path: '/solutions/startups',
  },
  '/solutions/agencies': {
    title: 'AI Marketing Platform for Agencies',
    description:
      'Manage strategy, content and reporting for many clients from one place, with reusable brand kits and repeatable delivery workflows.',
    path: '/solutions/agencies',
  },
  '/solutions/ecommerce': {
    title: 'AI Marketing for E-commerce',
    description:
      'Improve product discovery with structured data, category content and campaign planning designed for online stores and catalogues.',
    path: '/solutions/ecommerce',
  },
  '/solutions/local-business': {
    title: 'AI Marketing for Local Business',
    description:
      'Win nearby customers with location content, local structured data and review-ready pages that answer the questions people actually ask.',
    path: '/solutions/local-business',
  },
  '/solutions/real-estate': {
    title: 'AI Marketing for Real Estate',
    description:
      'Market listings and neighbourhoods with area guides, lead capture and structured data built for property search behaviour.',
    path: '/solutions/real-estate',
  },
  '/solutions/education': {
    title: 'AI Marketing for Education',
    description:
      'Help learners find the right programme with course content, admissions FAQs and answer-first pages for education providers.',
    path: '/solutions/education',
  },
  '/solutions/healthcare': {
    title: 'AI Marketing for Healthcare',
    description:
      'Publish careful, reviewable patient-facing content with clear authorship, service pages and structured data for healthcare providers.',
    path: '/solutions/healthcare',
  },
  '/solutions/restaurants': {
    title: 'AI Marketing for Restaurants',
    description:
      'Promote menus, locations and offers with local structured data and content built around the questions diners search for most.',
    path: '/solutions/restaurants',
  },

  '/seo': {
    title: 'SEO Workspace',
    description:
      'Understand what search engine optimisation involves and how SeSha supports technical, content and internal-linking work in one place.',
    path: '/seo',
  },
  '/aeo': {
    title: 'What Is AEO? Answer Engine Optimisation',
    description:
      'Answer engine optimisation is structuring content so AI answer systems can quote it. Learn how AEO differs from SEO and how to apply it.',
    path: '/aeo',
  },
  '/schema-validator': {
    title: 'Free JSON-LD Schema Validator',
    description:
      'Paste JSON-LD structured data and check it for missing required properties, malformed dates, broken breadcrumbs and invalid FAQ markup.',
    path: '/schema-validator',
  },

  '/pricing': {
    title: 'Pricing',
    description:
      'Compare SeSha plans for individuals, growing teams and agencies, and see exactly what each tier includes before you talk to us.',
    path: '/pricing',
  },
  '/resources': {
    title: 'Resources',
    description:
      'Guides, definitions and practical explanations covering AI marketing, search optimisation, answer engines and structured data.',
    path: '/resources',
  },
  '/blog': {
    title: 'Blog',
    description:
      'Articles from the SeSha editorial team on AI-assisted marketing, search optimisation, answer engine optimisation and structured data.',
    path: '/blog',
  },

  '/about': {
    title: 'About SeSha',
    description:
      'SeSha AI Marketing is built by SeSha AI Marketing. Read what we are building, how we work and the principles behind the product.',
    path: '/about',
  },
  '/contact': {
    title: 'Contact Us',
    description:
      'Ask a question about the product, pricing, partnerships, support or security, and the SeSha team will get back to you by email.',
    path: '/contact',
  },
  '/faq': {
    title: 'Frequently Asked Questions',
    description:
      'Direct answers about what SeSha does, how AI is used, what data we store, how pricing works and what is available today.',
    path: '/faq',
  },
  '/security': {
    title: 'Security',
    description:
      'How SeSha approaches application security: transport encryption, security headers, input validation, access control and disclosure.',
    path: '/security',
  },
  '/privacy': {
    title: 'Privacy Policy',
    description:
      'What personal information SeSha AI Marketing collects through this website, why we collect it, how long we keep it and your rights.',
    path: '/privacy',
  },
  '/terms': {
    title: 'Terms of Service',
    description:
      'The terms that govern your use of the SeSha AI Marketing website and services, including acceptable use and limitations of liability.',
    path: '/terms',
  },
};

/** Throws at module load if a page is requested that has no SEO entry. */
export function seoFor(path: string): SeoInput {
  const entry = pageSeo[path];
  if (!entry) {
    throw new Error(`No SEO entry registered for "${path}". Add one to src/content/seo-map.ts.`);
  }
  return entry;
}
