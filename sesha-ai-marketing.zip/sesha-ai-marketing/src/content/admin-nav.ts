/**
 * The admin panel's navigation.
 *
 * KEPT OUT OF `app-nav.ts` DELIBERATELY. That file drives the customer's
 * sidebar, and a platform route that appeared there — even gated, even hidden —
 * would be one conditional away from being rendered to a customer. These routes
 * are also absent from the sitemap and from the public link-integrity test, for
 * the same reason the API returns 404: to anyone who is not staff, this panel
 * does not exist.
 *
 * Every item declares the permission it needs. The shell hides items the signed-
 * in staff member's ROLE does not hold — a courtesy, not the control: the pages
 * and the API routes each re-check independently.
 */

import type { AdminPermission } from '@/lib/admin/auth';

export interface AdminNavItem {
  readonly label: string;
  readonly href: string;
  readonly permission: AdminPermission;
  /** What this screen is for, one line, shown as the page description. */
  readonly summary: string;
}

export interface AdminNavGroup {
  readonly label: string;
  readonly items: readonly AdminNavItem[];
}

export const ADMIN_NAV: readonly AdminNavGroup[] = [
  {
    label: 'Platform',
    items: [
      {
        label: 'Overview',
        href: '/admin',
        permission: 'admin:health:read',
        summary: 'Counts, plan spread, subscription states and system health.',
      },
      {
        label: 'Organizations',
        href: '/admin/organizations',
        permission: 'admin:businesses:read',
        summary: 'Every account, its plan, its usage and its overrides. Metadata only.',
      },
      {
        label: 'Usage',
        href: '/admin/usage',
        permission: 'admin:usage:read',
        summary: 'What the platform has consumed this period, and AI requests over 30 days.',
      },
      {
        label: 'Health',
        href: '/admin/health',
        permission: 'admin:health:read',
        summary: 'What is checkable, and an explicit list of what is not measured.',
      },
    ],
  },
  {
    label: 'Operations',
    items: [
      {
        label: 'Jobs',
        href: '/admin/jobs',
        permission: 'admin:jobs:read',
        summary: 'Crawl and schema jobs across every tenant, with their failures.',
      },
      {
        label: 'Errors',
        href: '/admin/errors',
        permission: 'admin:errors:read',
        summary: 'Open problems grouped by fingerprint, worst first.',
      },
      {
        label: 'Feedback',
        href: '/admin/feedback',
        permission: 'admin:feedback:read',
        summary: 'What customers have written in, and its triage state.',
      },
      {
        label: 'Security',
        href: '/admin/security',
        permission: 'admin:security:read',
        summary: 'Security-relevant tenant events — sign-in failures, permission denials.',
      },
    ],
  },
  {
    label: 'Controls',
    items: [
      {
        label: 'Plans',
        href: '/admin/plans',
        permission: 'admin:subscriptions:read',
        summary: 'The plan registry as deployed, and where its definitions live.',
      },
      {
        label: 'Feature flags',
        href: '/admin/flags',
        permission: 'admin:flags:write',
        summary: 'Providers, modules, beta features, plan gates and experiments.',
      },
      {
        label: 'System',
        href: '/admin/settings',
        permission: 'admin:system:write',
        summary: 'Prompts, templates, validator behaviour and system configuration.',
      },
    ],
  },
  {
    label: 'Accountability',
    items: [
      {
        label: 'Audit trail',
        href: '/admin/audit',
        permission: 'admin:audit:read',
        summary: 'Every staff action, including every read. Engineer and above.',
      },
      {
        label: 'Staff',
        href: '/admin/staff',
        permission: 'admin:staff:read',
        summary: 'Who holds platform access, who granted it, and why.',
      },
    ],
  },
];

/** Every admin route, for the route-coverage test. */
export const adminRoutes: readonly string[] = ADMIN_NAV.flatMap((group) =>
  group.items.map((item) => item.href),
);

export function adminItemFor(href: string): AdminNavItem | null {
  for (const group of ADMIN_NAV) {
    for (const item of group.items) {
      if (item.href === href) return item;
    }
  }
  return null;
}
