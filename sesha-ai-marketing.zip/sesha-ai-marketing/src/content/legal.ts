/**
 * Privacy policy and terms of service content.
 *
 * IMPORTANT: these are drafted to describe what this website actually does,
 * which makes them accurate but NOT a substitute for legal review. Both pages
 * render a visible notice to that effect while `requiresLegalReview` is true.
 * Have counsel review and adjust for your jurisdiction, then set the flag to
 * false and update `effectiveDate`.
 */

import type { Block } from './blocks';
import { organization } from './site';

export const requiresLegalReview = true;
export const effectiveDate = '2026-09-11';

export const legalReviewNotice =
  'This document describes how this website currently operates and has not yet been reviewed by legal counsel. It will be updated following that review.';

export const privacyPolicy = {
  heading: 'Privacy Policy',
  intro: `This policy explains what personal information ${organization.brandName}, operated by ${organization.legalName}, collects through this website, why we collect it, how long we keep it, and the choices you have.`,
  blocks: [
    { kind: 'heading', id: 'what-we-collect', text: 'Information we collect' },
    {
      kind: 'paragraph',
      text: 'We collect only what you actively submit, plus the technical information any web server records in order to serve a request.',
    },
    {
      kind: 'list',
      items: [
        'Contact form: your name, email address, company (optional), the topic you select and your message.',
        'Newsletter form: your email address.',
        'Server logs: IP address, request time, requested URL, user agent and response status.',
        'Schema validator: the content you paste is processed to produce your report and is not stored as content.',
      ],
    },
    {
      kind: 'callout',
      title: 'No tracking scripts',
      text: 'This website loads no third-party analytics, advertising or tracking scripts. Its content security policy blocks external scripts, so none can be added without a deliberate code change. We do not set advertising or cross-site tracking cookies.',
    },
    { kind: 'heading', id: 'account-data', text: 'If you use the SeSha app' },
    {
      kind: 'list',
      items: [
        'Account: your email address, name, a salted scrypt hash of your password (never the password itself) and your sign-in sessions.',
        'Workspace: the business details, marketing profile, content, plans and reports you create.',
        'Billing: your plan and invoices. Card numbers are handled by the payment provider; we keep only the card brand and last four digits.',
      ],
    },
    { kind: 'heading', id: 'crawling', text: 'Websites we crawl for you' },
    {
      kind: 'paragraph',
      text: 'We crawl a website only after you confirm you are authorised to, and we record that consent. Crawled page content is kept for the retention period you choose and then permanently deleted by a scheduled job. Withdrawing consent deletes everything crawled under it immediately.',
    },
    { kind: 'heading', id: 'ai-processing', text: 'AI processing' },
    {
      kind: 'paragraph',
      text: 'Features marked as AI send the text needed for that request, such as your business profile and the page being analysed, to an AI model provider to generate a draft. We do not send passwords, payment data or other customers’ data. AI output is labelled as AI-generated, can be wrong, and should be reviewed before it is published.',
    },
    { kind: 'heading', id: 'why', text: 'Why we collect it' },
    {
      kind: 'list',
      items: [
        'To reply to your enquiry — this is the only purpose of contact form data.',
        'To send the updates you asked for, if you subscribed to the newsletter.',
        'To keep the service available and secure, which is the purpose of server logs and rate limiting.',
      ],
    },
    {
      kind: 'paragraph',
      text: 'We do not sell personal information, and we do not share it with advertisers or data brokers.',
    },
    { kind: 'heading', id: 'cookies', text: 'Cookies and local storage' },
    {
      kind: 'paragraph',
      text: 'This website stores one value in your browser: your light or dark theme preference. It is kept in local storage on your own device, is not a cookie, is never sent to our servers and is used for nothing else. Clearing your browser storage removes it.',
    },
    { kind: 'heading', id: 'retention', text: 'How long we keep it' },
    {
      kind: 'list',
      items: [
        'Contact enquiries: kept while we handle your request and for a reasonable period afterwards, then deleted.',
        'Newsletter subscriptions: kept until you unsubscribe.',
        'Server logs: retained for a limited period for security and reliability purposes, then rotated out.',
        'Crawled website content: the retention period you chose when consenting (90 days by default, 365 at most), then permanently deleted.',
        'Account data: until you delete your account. Security audit records are kept for a limited period after that.',
      ],
    },
    { kind: 'heading', id: 'your-rights', text: 'Your rights' },
    {
      kind: 'paragraph',
      text: `Depending on where you live, you may have the right to access the personal information we hold about you, to have it corrected or deleted, to object to or restrict how we use it, and to receive a copy in a portable format. In the app you can download a complete copy of your organization’s data from Settings (a machine-readable JSON file), delete crawled content, and delete your account: sign-in stops immediately and your personal data is erased after a 30-day grace period. For anything else, email ${organization.email} and we will respond within a reasonable time.`,
    },
    { kind: 'heading', id: 'sharing', text: 'Service providers' },
    {
      kind: 'paragraph',
      text: 'We use infrastructure providers to host this website and to deliver email. They process data only to provide those services to us. We will update this section with a specific list as arrangements are finalised.',
    },
    { kind: 'heading', id: 'children', text: "Children's privacy" },
    {
      kind: 'paragraph',
      text: 'This website is intended for business use and is not directed at children. We do not knowingly collect personal information from anyone under 16.',
    },
    { kind: 'heading', id: 'changes', text: 'Changes to this policy' },
    {
      kind: 'paragraph',
      text: 'If we change this policy we will update the effective date shown on this page. Material changes affecting how we use information you have already given us will be communicated directly where we have a way to reach you.',
    },
    { kind: 'heading', id: 'contact', text: 'Contacting us' },
    {
      kind: 'paragraph',
      text: `For any privacy question, email ${organization.email}. ${organization.legalName} is the controller of the personal information described in this policy.`,
    },
  ] as readonly Block[],
} as const;

export const termsOfService = {
  heading: 'Terms of Service',
  intro: `These terms govern your use of this website and any services ${organization.legalName} makes available through it. By using the site you agree to them.`,
  blocks: [
    { kind: 'heading', id: 'scope', text: 'What these terms cover' },
    {
      kind: 'paragraph',
      text: 'These terms cover this public website and the free tools published on it, including the schema validator. Access to the authenticated SeSha workspace, when it becomes available, will be governed by a separate agreement presented at sign-up.',
    },
    { kind: 'heading', id: 'acceptable-use', text: 'Acceptable use' },
    {
      kind: 'paragraph',
      text: 'You may use this website and its free tools for lawful purposes. You agree not to:',
    },
    {
      kind: 'list',
      items: [
        'Attempt to gain unauthorised access to any system, account or data.',
        'Probe or test the security of the site except as described on the security page.',
        'Interfere with the service, including by circumventing rate limits or automating submissions.',
        'Submit content that is unlawful, infringing or malicious.',
        'Scrape or reproduce the content of this site at scale without written permission.',
      ],
    },
    { kind: 'heading', id: 'tools', text: 'The free tools' },
    {
      kind: 'paragraph',
      text: 'The schema validator checks structure and property completeness for the schema types it supports. It does not contact any search engine, and a passing result is not a guarantee of rich-result eligibility or of any search outcome. It is provided as-is and may change or be withdrawn.',
    },
    { kind: 'heading', id: 'no-guarantees', text: 'No performance guarantees' },
    {
      kind: 'paragraph',
      text: 'Nothing on this site is a promise of marketing results, search rankings, traffic or revenue. Search and answer engines control their own results, and outcomes depend on factors outside our control and yours.',
    },
    { kind: 'heading', id: 'ip', text: 'Intellectual property' },
    {
      kind: 'paragraph',
      text: `The content, design and software of this website are owned by ${organization.legalName} or its licensors. Content you submit remains yours; you grant us only the permission needed to process and respond to it.`,
    },
    { kind: 'heading', id: 'availability', text: 'Availability' },
    {
      kind: 'paragraph',
      text: 'We aim to keep this site available but do not guarantee uninterrupted access. We may change, suspend or discontinue any part of it, including the free tools, at any time.',
    },
    { kind: 'heading', id: 'liability', text: 'Limitation of liability' },
    {
      kind: 'paragraph',
      text: 'To the fullest extent permitted by law, we are not liable for indirect, incidental or consequential losses arising from your use of this website or its free tools. Nothing in these terms limits liability that cannot lawfully be limited.',
    },
    { kind: 'heading', id: 'changes', text: 'Changes to these terms' },
    {
      kind: 'paragraph',
      text: 'We may update these terms. The effective date on this page shows when the current version took effect, and continuing to use the site after a change means you accept the updated terms.',
    },
    { kind: 'heading', id: 'contact', text: 'Contact' },
    {
      kind: 'paragraph',
      text: `Questions about these terms can be sent to ${organization.email}.`,
    },
  ] as readonly Block[],
} as const;
