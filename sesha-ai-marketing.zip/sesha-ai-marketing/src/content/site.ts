/**
 * Single source of truth for organization + site facts.
 *
 * RULE: every value here must be a VERIFIED fact about the business.
 * Structured data is generated from this file, so anything invented here
 * becomes a fabricated claim in schema.org output. Fields that are not yet
 * verified are typed as optional and left `undefined` rather than guessed.
 */

export interface OrganizationProfile {
  readonly legalName: string;
  readonly brandName: string;
  readonly shortName: string;
  readonly tagline: string;
  readonly description: string;
  /** Verified public contact address. */
  readonly email: string;
  /** Left undefined until verified — never guess a phone number. */
  readonly telephone?: string;
  /** Left undefined until verified — never guess a postal address. */
  readonly address?: {
    readonly streetAddress: string;
    readonly addressLocality: string;
    readonly addressRegion: string;
    readonly postalCode: string;
    readonly addressCountry: string;
  };
  /** Verified profile URLs only. Empty until confirmed. */
  readonly sameAs: readonly string[];
  readonly foundingYear?: number;
}

export const organization: OrganizationProfile = {
  legalName: 'SeSha AI Marketing',
  brandName: 'SeSha AI Marketing',
  shortName: 'SeSha',
  tagline: 'Your AI-Powered Digital Marketing Command Center',
  description:
    'SeSha AI Marketing is an AI-powered digital marketing platform for creating strategies, content, campaigns, SEO, AEO, structured data and marketing insights from one workspace.',
  email: 'seshaaimarketing@gmail.com',
  // Verified by the owner, September 2026. E.164 format, because that is what
  // schema.org, `tel:` links and every dialler expect.
  telephone: '+918218397819',
  // address: intentionally omitted until verified.
  sameAs: [],
  // foundingYear: intentionally omitted until verified.
};

/**
 * Renders an E.164 number for display: `+918218397819` → `+91 82183 97819`.
 *
 * The stored value stays E.164, because that is what `tel:` links and
 * schema.org need; only the display is grouped, and only for Indian numbers,
 * which is the one country code this business has. Anything else is returned
 * unchanged rather than mis-grouped.
 */
export function formatPhone(e164: string): string {
  const india = /^\+91(\d{5})(\d{5})$/.exec(e164);
  return india ? `+91 ${india[1]} ${india[2]}` : e164;
}

/**
 * Canonical origin. Must be absolute and have no trailing slash.
 * Falls back to localhost so local builds still produce valid absolute URLs.
 */
export const siteUrl: string = (
  process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000'
).replace(/\/+$/, '');

export const site = {
  name: organization.brandName,
  shortName: organization.shortName,
  url: siteUrl,
  locale: 'en_US',
  language: 'en',
  /** Used as the default social card + twitter:image. */
  defaultOgImage: '/og/default.png',
  /** Handle is omitted until a verified account exists. */
  twitterHandle: undefined as string | undefined,
  themeColor: { light: '#ffffff', dark: '#0b0b12' },
} as const;

/**
 * Editorial identity used for AEO author attribution.
 * Team pages and bylines resolve through here.
 */
export interface Author {
  readonly id: string;
  readonly name: string;
  readonly role: string;
  readonly bio: string;
  readonly url: string;
}

export const authors: Record<string, Author> = {
  editorial: {
    id: 'editorial',
    name: 'SeSha Editorial Team',
    role: 'Marketing research and product education',
    bio: 'The SeSha editorial team documents how AI-assisted marketing, search optimisation and answer-engine optimisation work in practice.',
    url: '/about',
  },
};
