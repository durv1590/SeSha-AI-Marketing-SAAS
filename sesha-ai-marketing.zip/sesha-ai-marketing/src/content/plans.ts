/**
 * The plan registry: what each plan allows.
 *
 * WHY THIS IS CONTENT AND NOT CODE
 * The brief says *"do not hard-code pricing into business logic"*, and the same
 * reasoning applies to limits. Before Phase 7 the AI quotas lived in
 * `lib/ai/cost.ts` as a `Record<Plan, AiQuota>` — business logic that had to be
 * edited and redeployed to change a number a salesperson might want to change on
 * a Tuesday. This file is typed data, like every other `src/content` module, and
 * `lib/plans` resolves it with per-organization overrides an admin can set.
 *
 * WHAT IS NOT IN THIS FILE: PRICES.
 * Money lives in `src/content/pricing.ts` behind its own fabrication guard
 * (`verified: false` means no figure is published anywhere, including in
 * structured data). Limits and prices are separate concerns with separate review
 * paths — a limit is an engineering fact, a price is a commitment by the
 * business — and joining them here would mean a code change to alter a price.
 *
 * THE TWO KINDS OF LIMIT, AND WHY THE DIFFERENCE IS IN THE TYPE
 * A monthly counter and an absolute cap behave differently at the period
 * boundary, and confusing them is how a product either deletes a customer's
 * projects on the first of the month or lets them create unlimited ones. So
 * `LimitKind` is explicit:
 *
 *   · `per_period` — resets each billing month (AI requests, tokens, content,
 *     crawls, audits, validations, reports). Usage is counted in the window.
 *   · `absolute`   — a ceiling on how many may exist at once (projects, team
 *     members, automations). Nothing resets; the check counts live rows.
 *
 * `tests/plans.test.ts` asserts every limit declares one, and that the
 * enforcement path reads the right counter for each.
 */

/* -------------------------------------------------------------------------- */
/* Plans                                                                      */
/* -------------------------------------------------------------------------- */

/**
 * The four plans the brief names.
 *
 * A NOTE ON THE RENAME, because it is a breaking change and pretending
 * otherwise would hide a migration risk.
 *
 * Phases 1–6 shipped `starter | growth | agency`, chosen before this
 * instruction existed. Those identifiers are in the `organizations` and
 * `subscriptions` CHECK constraints, in the pricing page and in the published
 * structured data. Phase 7 makes the brief's four canonical and migrates the old
 * rows (migration 0007), under one rule:
 *
 *   **NO MIGRATED ORGANIZATION MAY LOSE AN ENTITLEMENT.**
 *
 * `starter` was a PAID tier, so it does not become `free` — that would hand a
 * paying customer a free plan and silently cut their quotas mid-month. The
 * mapping is in `LEGACY_PLAN_MAP` below and `tests/plans.test.ts` asserts that
 * every limit on the destination plan is greater than or equal to the limit on
 * the plan it replaced. `free` is genuinely new and nobody is migrated onto it.
 */
export const PLANS = ['free', 'pro', 'business', 'agency'] as const;

export type PlanId = (typeof PLANS)[number];

export function isPlanId(value: unknown): value is PlanId {
  return typeof value === 'string' && (PLANS as readonly string[]).includes(value);
}

/** The plan identifiers Phases 1–6 used. Accepted on read, never written. */
export const LEGACY_PLANS = ['starter', 'growth', 'agency'] as const;

export type LegacyPlanId = (typeof LEGACY_PLANS)[number];

/**
 * Where a pre-Phase-7 organization lands.
 *
 * Deliberately upward: each destination is at least as generous as its source.
 * A test proves it rather than trusting this comment.
 */
export const LEGACY_PLAN_MAP: Readonly<Record<LegacyPlanId, PlanId>> = {
  starter: 'pro',
  growth: 'business',
  agency: 'agency',
};

/** Resolves any stored plan string, current or legacy, to a canonical plan. */
export function resolvePlanId(value: unknown): PlanId | null {
  if (isPlanId(value)) return value;
  if (typeof value === 'string' && (LEGACY_PLANS as readonly string[]).includes(value)) {
    return LEGACY_PLAN_MAP[value as LegacyPlanId];
  }
  return null;
}

/* -------------------------------------------------------------------------- */
/* Limits                                                                     */
/* -------------------------------------------------------------------------- */

/** The eleven limits the brief names, in its order. */
export const LIMIT_IDS = [
  'ai_requests',
  'tokens',
  'content_generations',
  'website_crawls',
  'seo_audits',
  'aeo_audits',
  'schema_validations',
  'projects',
  'team_members',
  'reports',
  'automations',
] as const;

export type LimitId = (typeof LIMIT_IDS)[number];

export type LimitKind = 'per_period' | 'absolute';

export interface LimitDefinition {
  readonly id: LimitId;
  readonly label: string;
  /** One sentence a customer can act on, shown beside the number. */
  readonly description: string;
  readonly kind: LimitKind;
  /** Plural noun for messages: "You have used all 200 generations". */
  readonly unit: string;
}

export const LIMITS: Readonly<Record<LimitId, LimitDefinition>> = {
  ai_requests: {
    id: 'ai_requests',
    label: 'AI requests',
    description: 'Every call SeSha makes to an AI provider on your behalf, from any screen.',
    kind: 'per_period',
    unit: 'requests',
  },
  tokens: {
    id: 'tokens',
    label: 'AI tokens',
    description:
      'Input plus output tokens across all AI requests. One long strategy can cost more than fifty captions, which is why this is counted separately from the request count.',
    kind: 'per_period',
    unit: 'tokens',
  },
  content_generations: {
    id: 'content_generations',
    label: 'Content generations',
    description: 'Items created in Content Studio. Editing a draft does not count again.',
    kind: 'per_period',
    unit: 'generations',
  },
  website_crawls: {
    id: 'website_crawls',
    label: 'Website crawls',
    description: 'Crawl runs. Pages within a crawl are bounded separately by the crawler itself.',
    kind: 'per_period',
    unit: 'crawls',
  },
  seo_audits: {
    id: 'seo_audits',
    label: 'SEO audits',
    description: 'SEO audit runs over a completed crawl.',
    kind: 'per_period',
    unit: 'audits',
  },
  aeo_audits: {
    id: 'aeo_audits',
    label: 'AEO audits',
    description: 'AEO audit runs over a completed crawl.',
    kind: 'per_period',
    unit: 'audits',
  },
  schema_validations: {
    id: 'schema_validations',
    label: 'Schema validations',
    description: 'Structured-data checks, whether pasted or read from one of your pages.',
    kind: 'per_period',
    unit: 'validations',
  },
  projects: {
    id: 'projects',
    label: 'Projects',
    description: 'How many projects may exist at once. Archiving one frees the slot.',
    kind: 'absolute',
    unit: 'projects',
  },
  team_members: {
    id: 'team_members',
    label: 'Team members',
    description: 'People who may be members of this organization at once.',
    kind: 'absolute',
    unit: 'members',
  },
  reports: {
    id: 'reports',
    label: 'Reports',
    description: 'Reports generated. A report already generated is yours to keep and re-export.',
    kind: 'per_period',
    unit: 'reports',
  },
  automations: {
    id: 'automations',
    label: 'Automations',
    description: 'How many automation rules may exist at once, switched on or off.',
    kind: 'absolute',
    unit: 'automations',
  },
};

/** `null` means unlimited. An explicit `0` means the feature is off for this plan. */
export type LimitValue = number | null;

export type PlanLimits = Readonly<Record<LimitId, LimitValue>>;

export interface PlanDefinition {
  readonly id: PlanId;
  readonly name: string;
  /** Who it is for, in the customer's words. */
  readonly audience: string;
  /** Rank, used to decide whether a change is an upgrade or a downgrade. */
  readonly rank: number;
  /** Whether a card is required to start. `free` needs none. */
  readonly requiresPayment: boolean;
  /** Trial length in days, for plans that offer one. 0 means none. */
  readonly trialDays: number;
  readonly limits: PlanLimits;
}

/**
 * The default limits per plan.
 *
 * These are DEFAULTS. An admin can override any of them for one organization
 * (`plan_limit_overrides`, migration 0007), which is how the brief's
 * *"Admin controls: Plans, Limits"* is satisfied without a deployment. The
 * resolver in `lib/plans` is the only thing that should read this object.
 */
export const PLAN_DEFINITIONS: Readonly<Record<PlanId, PlanDefinition>> = {
  free: {
    id: 'free',
    name: 'Free',
    audience: 'Trying SeSha on one small site',
    rank: 0,
    requiresPayment: false,
    trialDays: 0,
    limits: {
      ai_requests: 25,
      tokens: 50_000,
      content_generations: 10,
      website_crawls: 1,
      seo_audits: 1,
      aeo_audits: 1,
      schema_validations: 20,
      projects: 1,
      team_members: 1,
      reports: 2,
      automations: 1,
    },
  },
  pro: {
    id: 'pro',
    name: 'Pro',
    audience: 'Solo marketers and small businesses',
    rank: 1,
    requiresPayment: true,
    trialDays: 14,
    limits: {
      ai_requests: 500,
      tokens: 1_000_000,
      content_generations: 150,
      website_crawls: 10,
      seo_audits: 20,
      aeo_audits: 20,
      schema_validations: 500,
      projects: 3,
      team_members: 3,
      reports: 50,
      automations: 10,
    },
  },
  business: {
    id: 'business',
    name: 'Business',
    audience: 'Marketing teams running several brands',
    rank: 2,
    requiresPayment: true,
    trialDays: 14,
    limits: {
      ai_requests: 3_000,
      tokens: 8_000_000,
      content_generations: 1_000,
      website_crawls: 60,
      seo_audits: 120,
      aeo_audits: 120,
      schema_validations: 3_000,
      projects: 15,
      team_members: 15,
      reports: 400,
      automations: 50,
    },
  },
  agency: {
    id: 'agency',
    name: 'Agency',
    audience: 'Agencies managing client accounts',
    rank: 3,
    requiresPayment: true,
    trialDays: 14,
    limits: {
      ai_requests: 12_000,
      tokens: 40_000_000,
      content_generations: 5_000,
      website_crawls: 300,
      seo_audits: 600,
      aeo_audits: 600,
      schema_validations: 15_000,
      projects: null,
      team_members: 50,
      reports: null,
      automations: 200,
    },
  },
};

/** Plans in rank order, for a pricing table or an upgrade path. */
export const PLANS_BY_RANK: readonly PlanDefinition[] = [...PLANS]
  .map((id) => PLAN_DEFINITIONS[id])
  .sort((a, b) => a.rank - b.rank);

/**
 * Whether moving between two plans is an upgrade, a downgrade, or neither.
 *
 * Compared by RANK, not by name and not by price: price lives elsewhere and is
 * not verified, so it cannot be the basis of a decision the code makes.
 */
export function planChange(from: PlanId, to: PlanId): 'upgrade' | 'downgrade' | 'same' {
  const a = PLAN_DEFINITIONS[from].rank;
  const b = PLAN_DEFINITIONS[to].rank;
  return b > a ? 'upgrade' : b < a ? 'downgrade' : 'same';
}

/** Formats a limit for display. `null` is unlimited; `0` is not included. */
export function formatLimit(value: LimitValue): string {
  if (value === null) return 'Unlimited';
  if (value === 0) return 'Not included';
  return value.toLocaleString('en-IN');
}
