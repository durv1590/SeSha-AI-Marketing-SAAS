/**
 * Industry solution pages.
 *
 * Each entry is written in AEO (answer-first) structure: a definition, a direct
 * answer, supporting explanation, concrete examples, FAQs and related concepts.
 * `/solutions/[slug]` renders every vertical from this map, and the route
 * registry in lib/routes.ts is the authority on which slugs exist.
 */

import type { SolutionSlug } from '@/lib/routes';

export interface SolutionFaq {
  readonly question: string;
  readonly answer: string;
}

export interface Solution {
  readonly slug: SolutionSlug;
  readonly name: string;
  readonly heroHeading: string;
  /** AEO: the one-sentence definition of the audience. */
  readonly definition: string;
  /** AEO: the direct answer to "how does SeSha help this audience?" */
  readonly directAnswer: string;
  /** AEO: supporting explanation, two to three sentences. */
  readonly explanation: string;
  readonly challenges: readonly string[];
  /** AEO: concrete, checkable examples of the work. */
  readonly examples: readonly { readonly title: string; readonly body: string }[];
  /** Module ids from content/modules.ts that matter most here. */
  readonly keyModules: readonly string[];
  readonly faqs: readonly SolutionFaq[];
  /** AEO: related concepts, as internal links. */
  readonly related: readonly { readonly label: string; readonly href: string }[];
  readonly lastUpdated: string;
}

const common = {
  lastUpdated: '2026-09-11',
};

export const solutions: Record<SolutionSlug, Solution> = {
  'small-business': {
    ...common,
    slug: 'small-business',
    name: 'Small Business',
    heroHeading: 'Marketing that works when you are the marketing team',
    definition:
      'A small business here means an established company marketing to local or niche customers, usually with one person or a small team handling all marketing work alongside other duties.',
    directAnswer:
      'SeSha helps a small business run a complete marketing programme without a specialist for each channel: one plan, AI-assisted drafting, and the technical work handled automatically.',
    explanation:
      'The limiting factor in small-business marketing is rarely ideas — it is hours. Because the workspace already holds your brand and plan, producing a month of content is a review task rather than a writing task. Metadata and structured data are generated with the content, so the technical work that usually gets skipped simply happens.',
    challenges: [
      'One person covering strategy, writing, social, ads and reporting',
      'No time for technical SEO or structured data',
      'Message drifts between the website, social posts and ads',
      'Enquiries arrive with no record of what produced them',
    ],
    examples: [
      {
        title: 'A month of content from one brief',
        body: 'Describe a seasonal offer once. The strategy module places it in the calendar, Content Studio drafts the landing page and posts, and the social module adapts the message per channel.',
      },
      {
        title: 'Local pages that answer real questions',
        body: 'Build service pages in answer-first structure with FAQ markup, so the questions customers actually ask are answered on the page and available to answer engines.',
      },
    ],
    keyModules: ['ai-copilot', 'content-studio', 'seo', 'leads'],
    faqs: [
      {
        question: 'Do I need marketing experience to use SeSha?',
        answer:
          'No. The strategy module asks what you sell and who you serve, then produces an editable plan. You review and adjust rather than starting from a blank page.',
      },
      {
        question: 'Can I use it for just one part of my marketing?',
        answer:
          'Yes. Modules work independently — many small businesses start with content and SEO, then add campaigns and lead management later.',
      },
      {
        question: 'Will the content sound like my business?',
        answer:
          'Content is drafted against the voice, tone and terminology rules in your brand kit, and every draft is editable before it is published.',
      },
    ],
    related: [
      { label: 'Local business marketing', href: '/solutions/local-business' },
      { label: 'SEO workspace', href: '/seo' },
      { label: 'Pricing', href: '/pricing' },
    ],
  },

  startups: {
    ...common,
    slug: 'startups',
    name: 'Startups',
    heroHeading: 'Find the message that works, then scale it',
    definition:
      'A startup here means an early-stage company still testing positioning and channels, where the marketing question is which message works rather than how to produce more of it.',
    directAnswer:
      'SeSha gives startups a full marketing stack in one workspace so positioning can be tested, revised and rolled out across content, ads and social without rebuilding the setup each time.',
    explanation:
      'Early-stage marketing changes fast, and the usual cost of a pivot is rewriting everything by hand. When positioning lives in the strategy module, changing it updates the context every other module draws from, so the next round of content and campaigns reflects the new message immediately.',
    challenges: [
      'Positioning still moving while content is being produced',
      'No dedicated marketing hire yet',
      'Needing to test several message angles at once',
      'Founders writing copy between product work',
    ],
    examples: [
      {
        title: 'Test three positioning angles',
        body: 'Define three messaging pillars, generate matching landing copy and ad variants for each, and compare which angle converts before committing.',
      },
      {
        title: 'Launch content that stays consistent',
        body: 'A launch brief produces the announcement post, the landing page and the social sequence from one message, so the story does not fragment.',
      },
    ],
    keyModules: ['strategy', 'ai-copilot', 'advertising', 'analytics'],
    faqs: [
      {
        question: 'What if our positioning changes next month?',
        answer:
          'Update the strategy module. Because every other module reads from it, subsequent drafts and campaigns pick up the new positioning without a manual sweep.',
      },
      {
        question: 'Is this useful before we have a marketing hire?',
        answer:
          'Yes — that is the common starting point. Founders use the copilot and strategy modules to produce a plan they can execute, then hand the workspace over when they hire.',
      },
      {
        question: 'Can we export our data if we outgrow it?',
        answer:
          'Yes. Content, leads and reports can be exported, and lead records can be pushed to your CRM.',
      },
    ],
    related: [
      { label: 'Agency workflows', href: '/solutions/agencies' },
      { label: 'Answer engine optimisation', href: '/aeo' },
      { label: 'All features', href: '/features' },
    ],
  },

  agencies: {
    ...common,
    slug: 'agencies',
    name: 'Agencies',
    heroHeading: 'Run many clients without running many tool stacks',
    definition:
      'An agency here means a team delivering marketing for multiple clients, where each client needs its own brand, plan and reporting while the delivery process stays consistent.',
    directAnswer:
      'SeSha gives each client its own brand kit, strategy and reporting inside one workspace, so delivery is repeatable while the output stays specific to each client.',
    explanation:
      'Agency margin comes from repeatable process, and it leaks through per-client tool sprawl and hand-built reports. Per-client brand kits keep outputs distinct, shared workflow templates keep delivery uniform, and reports are generated from the same data the team works in.',
    challenges: [
      'A different tool stack for every client',
      'Reports rebuilt by hand every month',
      'Onboarding a new client takes days of setup',
      'Junior work needs heavy senior review',
    ],
    examples: [
      {
        title: 'Onboard a client from a template',
        body: 'Start from a workflow template, fill in the client brand kit and positioning, and the calendar, content types and report format are configured.',
      },
      {
        title: 'Monthly reporting on a schedule',
        body: 'Reports build from live workspace data with drafted commentary, so the team edits the narrative instead of assembling the numbers.',
      },
    ],
    keyModules: ['brand-kit', 'reports', 'automation', 'content-studio'],
    faqs: [
      {
        question: 'Can each client have separate branding?',
        answer:
          'Yes. Each client gets its own brand kit — voice, terminology and visual assets — and every module applies the correct one automatically.',
      },
      {
        question: 'Can clients see their own reports?',
        answer:
          'Reports are exportable and shareable. Client-facing access controls are part of the Phase 2 roadmap rather than available today.',
      },
      {
        question: 'Does it replace our project management tool?',
        answer:
          'No. It covers marketing production and reporting. Task and resource management stays in your existing tool.',
      },
    ],
    related: [
      { label: 'Reports and analytics', href: '/features' },
      { label: 'Pricing for teams', href: '/pricing' },
      { label: 'Security', href: '/security' },
    ],
  },

  ecommerce: {
    ...common,
    slug: 'ecommerce',
    name: 'E-commerce',
    heroHeading: 'Make a large catalogue discoverable and consistent',
    definition:
      'E-commerce here means selling products online through a catalogue, where discovery depends on category and product pages being both readable and correctly marked up at scale.',
    directAnswer:
      'SeSha helps online stores produce category and product content at volume while keeping structured data valid, so products stay discoverable in search and in AI-generated answers.',
    explanation:
      'Catalogue marketing fails at scale for structural reasons: thin category pages, duplicated descriptions, and product markup that is missing a required property. The workspace produces the content and the JSON-LD together and validates the markup before it ships.',
    challenges: [
      'Thin or duplicated category and product copy',
      'Product structured data missing required properties',
      'Seasonal campaigns needing a full content refresh',
      'Ad copy drifting from what the product page says',
    ],
    examples: [
      {
        title: 'Category pages that earn their place',
        body: 'Generate buying-guide content for a category with FAQ markup answering the comparison questions shoppers actually ask.',
      },
      {
        title: 'Validated product markup',
        body: 'Run product JSON-LD through the validator to catch a price without a currency or an offer with no availability before it reaches production.',
      },
    ],
    keyModules: ['content-studio', 'schema-validator', 'advertising', 'seo'],
    faqs: [
      {
        question: 'Does it connect to my store platform?',
        answer:
          'Phase 1 of the platform covers content, markup generation and validation. Direct store integrations are planned for a later phase and are not available today.',
      },
      {
        question: 'Can it write product descriptions in bulk?',
        answer:
          'Content Studio drafts descriptions from product attributes you supply, applying your brand voice rules. Every draft remains editable before publishing.',
      },
      {
        question: 'Will it invent product ratings for schema?',
        answer:
          'No. Structured data is generated only from data you provide. Ratings and reviews are never fabricated — the validator warns if it sees rating markup.',
      },
    ],
    related: [
      { label: 'Schema validator', href: '/schema-validator' },
      { label: 'SEO workspace', href: '/seo' },
      { label: 'Local business marketing', href: '/solutions/local-business' },
    ],
  },

  'local-business': {
    ...common,
    slug: 'local-business',
    name: 'Local Business',
    heroHeading: 'Be the answer when someone searches nearby',
    definition:
      'A local business here means a company serving customers in a defined geographic area, where discovery happens through local search, maps and nearby-intent queries.',
    directAnswer:
      'SeSha helps local businesses build location and service pages with correct local structured data, so the details customers need are both on the page and machine-readable.',
    explanation:
      'Local search rewards specificity: a page that names the service, the area and the practical details beats a generic page every time. The workspace produces those pages in answer-first structure and generates the matching local business markup from the details you supply.',
    challenges: [
      'One generic page trying to cover several service areas',
      'Opening hours and contact details inconsistent across the web',
      'No structured data for location or services',
      'Common customer questions answered nowhere on the site',
    ],
    examples: [
      {
        title: 'A page per service area',
        body: 'Generate distinct service-area pages that share your positioning but carry area-specific detail, instead of one page listing every town.',
      },
      {
        title: 'Questions answered on the page',
        body: 'Turn the questions customers ask on the phone into an FAQ section with valid FAQ markup, so answer engines can quote them.',
      },
    ],
    keyModules: ['seo', 'aeo', 'schema-validator', 'leads'],
    faqs: [
      {
        question: 'Does it manage my business listings?',
        answer:
          'No. It builds the pages and structured data on your own site. Third-party listing management is outside the current scope.',
      },
      {
        question: 'What local structured data does it support?',
        answer:
          'The validator checks LocalBusiness markup for name, address, telephone and opening hours, and the generator emits only details you have entered.',
      },
      {
        question: 'Can I create pages for several locations?',
        answer:
          'Yes. Each location or service area can have its own page with its own markup, sharing the brand voice defined once in the brand kit.',
      },
    ],
    related: [
      { label: 'Restaurants', href: '/solutions/restaurants' },
      { label: 'Small business marketing', href: '/solutions/small-business' },
      { label: 'What is AEO?', href: '/aeo' },
    ],
  },

  'real-estate': {
    ...common,
    slug: 'real-estate',
    name: 'Real Estate',
    heroHeading: 'Market properties and the places they are in',
    definition:
      'Real estate here means agencies and agents marketing properties, where buyers search for both specific listings and the areas those listings sit in.',
    directAnswer:
      'SeSha helps property marketers produce listing content, neighbourhood guides and lead capture that stay consistent as inventory turns over.',
    explanation:
      'Property inventory changes constantly, but area content does not — and area content is what attracts buyers before they have chosen a listing. The workspace lets you build durable neighbourhood guides alongside listing copy, with enquiries tracked back to whichever page produced them.',
    challenges: [
      'Listing copy written from scratch for every property',
      'No content for the areas buyers search first',
      'Enquiries arriving with no record of the source listing',
      'Brand consistency across many individual agents',
    ],
    examples: [
      {
        title: 'Neighbourhood guides that keep working',
        body: 'Build area guides answering what it is like to live somewhere — these keep attracting buyers long after individual listings sell.',
      },
      {
        title: 'Listing copy from property attributes',
        body: 'Turn structured property details into listing descriptions that follow your agency voice rather than each agent improvising.',
      },
    ],
    keyModules: ['content-studio', 'leads', 'brand-kit', 'seo'],
    faqs: [
      {
        question: 'Does it integrate with property listing feeds?',
        answer:
          'Not in the current scope. Listing content is produced from attributes you provide; feed integrations are a later-phase consideration.',
      },
      {
        question: 'Can each agent have their own voice?',
        answer:
          'Brand kits are defined per workspace, so an agency can enforce one consistent voice, or maintain separate kits per team.',
      },
      {
        question: 'How are enquiries attributed?',
        answer:
          'Lead capture records the page and campaign that produced each enquiry, so attribution does not need reconstructing later.',
      },
    ],
    related: [
      { label: 'Local business marketing', href: '/solutions/local-business' },
      { label: 'Lead management', href: '/features' },
      { label: 'Contact us', href: '/contact' },
    ],
  },

  education: {
    ...common,
    slug: 'education',
    name: 'Education',
    heroHeading: 'Help learners find the right programme',
    definition:
      'Education here means schools, universities and training providers marketing courses and programmes to prospective learners and the people advising them.',
    directAnswer:
      'SeSha helps education providers publish clear programme information, admissions answers and comparison content in a structure that both search engines and answer engines can use.',
    explanation:
      'Prospective learners research by asking questions — entry requirements, duration, cost, outcomes — often long before they visit a website directly. Publishing those answers in answer-first structure with FAQ markup means the information is available at the moment the question is asked.',
    challenges: [
      'Programme details buried in PDFs and prospectuses',
      'Admissions questions answered only by email',
      'Course pages that describe the syllabus but not the outcome',
      'Long decision cycles with many touchpoints',
    ],
    examples: [
      {
        title: 'Programme pages that answer first',
        body: 'Lead with what the programme is, who it is for and what it requires, then support it with detail — the structure answer engines can quote.',
      },
      {
        title: 'Admissions FAQs as structured data',
        body: 'Publish entry requirements and deadlines as marked-up FAQ content instead of a downloadable document.',
      },
    ],
    keyModules: ['aeo', 'content-studio', 'seo', 'leads'],
    faqs: [
      {
        question: 'Can it handle several programmes or departments?',
        answer:
          'Yes. Each programme can have its own content set while sharing the institution brand kit and positioning.',
      },
      {
        question: 'How do we keep published information accurate?',
        answer:
          'Pages carry a last-updated date and content stays editable, so corrections to fees or dates are a direct edit rather than a rebuild.',
      },
      {
        question: 'Does it handle student enquiries?',
        answer:
          'Lead capture records enquiries with their source. Full CRM functionality is not included and enquiries can be exported to your system.',
      },
    ],
    related: [
      { label: 'What is AEO?', href: '/aeo' },
      { label: 'Healthcare marketing', href: '/solutions/healthcare' },
      { label: 'Resources', href: '/resources' },
    ],
  },

  healthcare: {
    ...common,
    slug: 'healthcare',
    name: 'Healthcare',
    heroHeading: 'Publish patient-facing content you can stand behind',
    definition:
      'Healthcare here means clinics, practices and health services publishing information for patients, where accuracy, clear authorship and careful review matter more than volume.',
    directAnswer:
      'SeSha helps healthcare providers publish service and patient information with explicit authorship, review dates and structured data, using drafting that always stays under human review.',
    explanation:
      'Health content carries a duty of care, so the workflow matters as much as the output. Drafts move through explicit review states before publishing, authorship and last-reviewed dates are recorded on the page, and nothing publishes automatically.',
    challenges: [
      'Content that must be reviewed before it can be published',
      'Patient questions answered inconsistently across the site',
      'No visible authorship or review date on published pages',
      'Service pages that do not explain what to expect',
    ],
    examples: [
      {
        title: 'Review states before anything publishes',
        body: 'Every draft moves through explicit review before it can go live, with the reviewer and date recorded on the page.',
      },
      {
        title: 'Service pages that set expectations',
        body: 'Explain what a service involves, who it is for and what happens at an appointment, in a structure that can be quoted accurately.',
      },
    ],
    keyModules: ['content-studio', 'aeo', 'seo', 'automation'],
    faqs: [
      {
        question: 'Is AI-generated health content safe to publish?',
        answer:
          'Not without review, and the workspace is built on that assumption: drafts are proposals, publishing requires a human approval step, and the reviewer is recorded.',
      },
      {
        question: 'Does SeSha handle patient data?',
        answer:
          'No. It is a marketing workspace. Do not enter patient information — it is not designed or certified for clinical data.',
      },
      {
        question: 'Can we show who reviewed a page?',
        answer:
          'Yes. Authorship and last-reviewed dates are part of the content model and are rendered on the page and in structured data.',
      },
    ],
    related: [
      { label: 'Security', href: '/security' },
      { label: 'Education marketing', href: '/solutions/education' },
      { label: 'Privacy policy', href: '/privacy' },
    ],
  },

  restaurants: {
    ...common,
    slug: 'restaurants',
    name: 'Restaurants',
    heroHeading: 'Turn menus, hours and offers into discoverable content',
    definition:
      'Restaurants here means food and hospitality venues marketing to nearby diners, where menus, hours, location and offers are the information people actually search for.',
    directAnswer:
      'SeSha helps restaurants publish menu, location and offer information as structured, answer-ready content rather than as images and PDFs that search engines cannot read.',
    explanation:
      'Most restaurant information is published in a format machines cannot read — a menu as a JPEG, hours in a footer image, an offer only on social. Converting those into structured page content with local markup makes them available to search and answer engines at the moment someone is deciding where to eat.',
    challenges: [
      'Menus published as images or PDFs',
      'Hours and holiday changes inconsistent across the web',
      'Offers announced only on social and then lost',
      'No local structured data for the venue',
    ],
    examples: [
      {
        title: 'A readable menu page',
        body: 'Publish the menu as structured page content with dish descriptions and dietary information, so it can be read, searched and quoted.',
      },
      {
        title: 'Offers that live somewhere permanent',
        body: 'Give each promotion a page with clear terms and dates, then drive social and ads to it instead of to a disappearing post.',
      },
    ],
    keyModules: ['seo', 'social', 'schema-validator', 'content-studio'],
    faqs: [
      {
        question: 'Does it manage reservations?',
        answer:
          'No. It covers marketing content, local structured data and campaigns. Reservation systems stay with your existing provider.',
      },
      {
        question: 'Can it handle several venues?',
        answer:
          'Yes. Each venue can have its own location page and markup while sharing one brand kit.',
      },
      {
        question: 'What about menu changes?',
        answer:
          'Menu content is editable page content, so a change is an edit — and the structured data regenerates from the updated values.',
      },
    ],
    related: [
      { label: 'Local business marketing', href: '/solutions/local-business' },
      { label: 'Schema validator', href: '/schema-validator' },
      { label: 'Social media module', href: '/features' },
    ],
  },
};

export function getSolution(slug: string): Solution | undefined {
  return solutions[slug as SolutionSlug];
}

export const solutionList: readonly Solution[] = Object.values(solutions);
