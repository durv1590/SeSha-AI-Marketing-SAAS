/**
 * Navigation structure.
 *
 * Every href here must resolve to a registered route in lib/routes.ts —
 * `tests/links.test.ts` enforces that, so navigation can never point at a
 * page that does not exist.
 */

export interface NavLink {
  readonly label: string;
  readonly href: string;
  readonly description?: string;
}

export interface NavGroup {
  readonly label: string;
  readonly href?: string;
  readonly links: readonly NavLink[];
}

/** Primary header navigation. Groups render as disclosure menus. */
export const primaryNav: readonly NavGroup[] = [
  {
    label: 'Product',
    links: [
      { label: 'Features', href: '/features', description: 'Every module in the platform' },
      { label: 'SEO', href: '/seo', description: 'Technical, content and link work' },
      { label: 'AEO', href: '/aeo', description: 'Optimise for AI-generated answers' },
      {
        label: 'Schema Validator',
        href: '/schema-validator',
        description: 'Free JSON-LD validation tool',
      },
    ],
  },
  {
    label: 'Solutions',
    href: '/solutions',
    links: [
      { label: 'Small Business', href: '/solutions/small-business' },
      { label: 'Startups', href: '/solutions/startups' },
      { label: 'Agencies', href: '/solutions/agencies' },
      { label: 'E-commerce', href: '/solutions/ecommerce' },
      { label: 'Local Business', href: '/solutions/local-business' },
      { label: 'Real Estate', href: '/solutions/real-estate' },
      { label: 'Education', href: '/solutions/education' },
      { label: 'Healthcare', href: '/solutions/healthcare' },
      { label: 'Restaurants', href: '/solutions/restaurants' },
    ],
  },
  {
    label: 'Resources',
    href: '/resources',
    links: [
      { label: 'Resource library', href: '/resources', description: 'Guides and definitions' },
      { label: 'Blog', href: '/blog', description: 'Articles from the editorial team' },
      { label: 'FAQ', href: '/faq', description: 'Direct answers to common questions' },
    ],
  },
];

/** Flat links that sit beside the grouped navigation. */
export const flatNav: readonly NavLink[] = [
  { label: 'Pricing', href: '/pricing' },
  { label: 'About', href: '/about' },
];

export const headerCta = { label: 'Start Free', href: '/contact' } as const;

export const footerNav: readonly NavGroup[] = [
  {
    label: 'Product',
    links: [
      { label: 'Features', href: '/features' },
      { label: 'SEO', href: '/seo' },
      { label: 'AEO', href: '/aeo' },
      { label: 'Schema Validator', href: '/schema-validator' },
      { label: 'Pricing', href: '/pricing' },
    ],
  },
  {
    label: 'Solutions',
    links: [
      { label: 'Small Business', href: '/solutions/small-business' },
      { label: 'Startups', href: '/solutions/startups' },
      { label: 'Agencies', href: '/solutions/agencies' },
      { label: 'E-commerce', href: '/solutions/ecommerce' },
      { label: 'All solutions', href: '/solutions' },
    ],
  },
  {
    label: 'Resources',
    links: [
      { label: 'Resource library', href: '/resources' },
      { label: 'Blog', href: '/blog' },
      { label: 'FAQ', href: '/faq' },
      { label: 'Contact', href: '/contact' },
    ],
  },
  {
    label: 'Company',
    links: [
      { label: 'About', href: '/about' },
      { label: 'Security', href: '/security' },
      { label: 'Privacy Policy', href: '/privacy' },
      { label: 'Terms of Service', href: '/terms' },
    ],
  },
];
