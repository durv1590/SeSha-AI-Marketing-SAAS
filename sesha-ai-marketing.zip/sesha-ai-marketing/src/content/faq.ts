/**
 * Site-wide FAQ content.
 *
 * Used by /faq, by the home page FAQ section, and as the source for FAQPage
 * structured data. Answers are written answer-first: the first sentence is a
 * complete, quotable answer, and anything after it is supporting detail.
 */

export interface FaqItem {
  readonly question: string;
  readonly answer: string;
  readonly category: FaqCategory;
}

export type FaqCategory = 'product' | 'ai' | 'seo-aeo' | 'data' | 'pricing';

export const faqCategories: readonly { id: FaqCategory; label: string }[] = [
  { id: 'product', label: 'Product' },
  { id: 'ai', label: 'AI and content' },
  { id: 'seo-aeo', label: 'SEO and AEO' },
  { id: 'data', label: 'Data and security' },
  { id: 'pricing', label: 'Pricing and access' },
];

export const faqs: readonly FaqItem[] = [
  {
    category: 'product',
    question: 'What is SeSha AI Marketing?',
    answer:
      'SeSha AI Marketing is an AI-assisted digital marketing workspace that combines strategy, content production, SEO, AEO, structured data, campaigns, lead management, analytics and reporting in one platform. Because the modules share the same brand and strategy context, work produced in one module is consistent with the rest.',
  },
  {
    category: 'product',
    question: 'Who is SeSha for?',
    answer:
      'It is built for teams that own marketing end to end: small businesses, startups, in-house marketing teams and agencies managing several clients. The modules stay the same across industries while plans, content types and structured data adapt to the vertical.',
  },
  {
    category: 'product',
    question: 'Does SeSha replace my existing tools?',
    answer:
      'It replaces the cluster of separate tools used for strategy documents, content drafting, SEO checks, schema generation and marketing reporting. It does not replace your CRM, your project management tool or your website platform.',
  },
  {
    category: 'ai',
    question: 'How is AI used in the platform?',
    answer:
      'AI is used to draft and propose, never to publish on its own. The copilot reads the brand kit, strategy and assets in your workspace, then produces drafts, outlines and suggestions that you review and edit before anything goes live.',
  },
  {
    category: 'ai',
    question: 'Will AI-generated content sound generic?',
    answer:
      'Drafts are generated against the voice, tone and terminology rules stored in your brand kit rather than from a generic prompt. The output is a starting draft that carries your constraints, and it remains fully editable.',
  },
  {
    category: 'ai',
    question: 'Can I see what the AI based its output on?',
    answer:
      'Yes. Suggestions reference the workspace context they drew from — the brand kit, the strategy entry or the asset — so you can check the reasoning rather than trusting the output blindly.',
  },
  {
    category: 'seo-aeo',
    question: 'What is the difference between SEO and AEO?',
    answer:
      'SEO optimises for ranked links in a results page, while AEO — answer engine optimisation — optimises for being quoted inside a generated answer. SEO emphasises crawlability, intent match and authority; AEO emphasises clear definitions, direct answers, explicit structure and verifiable authorship so a machine can extract and attribute a passage.',
  },
  {
    category: 'seo-aeo',
    question: 'Does SeSha guarantee better rankings?',
    answer:
      'No, and any tool that guarantees rankings is misleading you. Search and answer engines control their own results. What the platform does is make the work that influences visibility — structure, metadata, structured data, internal linking and content quality — consistent and repeatable.',
  },
  {
    category: 'seo-aeo',
    question: 'Is the schema validator really free?',
    answer:
      'Yes. The JSON-LD validator on this site runs in your browser session against our validation engine, requires no account, and stores nothing you paste into it. It checks structure and property completeness for the schema types we support.',
  },
  {
    category: 'data',
    question: 'What data does this website collect?',
    answer:
      'This website collects only what you submit through the contact and newsletter forms, plus standard server request logs. There are no third-party analytics, advertising or tracking scripts on this site — the content security policy blocks external scripts entirely.',
  },
  {
    category: 'data',
    question: 'Do you store what I paste into the schema validator?',
    answer:
      'No. Validator input is processed to produce the report and is not persisted to a database or logged as content. Treat it as you would any web form and avoid pasting secrets.',
  },
  {
    category: 'data',
    question: 'How do you handle security?',
    answer:
      'The site enforces a strict content security policy, sends a full set of security headers, validates and sanitises every form input server-side, and rate-limits its API endpoints. The security page describes the current posture in detail, including what is not yet in place.',
  },
  {
    category: 'pricing',
    question: 'How much does SeSha cost?',
    answer:
      'Plan pricing has not been finalised, so no figure is published on this site — we do not publish prices we have not confirmed. Contact us and we will give you current pricing for your team size and workspace count.',
  },
  {
    category: 'pricing',
    question: 'What does "Start Free" mean today?',
    answer:
      'It means you can use the schema validator on this site immediately with no account, and contact us to arrange access to the full workspace. Self-service signup arrives with the authenticated application in the next phase.',
  },
];

export function faqsByCategory(category: FaqCategory): FaqItem[] {
  return faqs.filter((f) => f.category === category);
}

/** A shorter set surfaced on the home page. */
export const homeFaqs: readonly FaqItem[] = faqs.filter((f) =>
  [
    'What is SeSha AI Marketing?',
    'How is AI used in the platform?',
    'What is the difference between SEO and AEO?',
    'Does SeSha guarantee better rankings?',
    'How much does SeSha cost?',
  ].includes(f.question),
);
