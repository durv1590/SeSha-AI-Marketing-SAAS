/**
 * Home page content.
 *
 * Section numbering follows the Phase 1 specification exactly:
 *  1 Hero · 2 Problem · 3 Solution · 4–17 the fourteen platform modules
 *  (rendered from content/modules.ts) · 18 How it works · 19 Use cases
 *  · 20 Pricing preview · 21 FAQ · 22 Final CTA · 23 Footer (site-wide).
 */

export const hero = {
  eyebrow: 'AI marketing workspace',
  headline: 'Your AI-Powered Digital Marketing Command Center',
  supporting:
    'Create strategies, content, campaigns, SEO, AEO, structured data and marketing insights from one intelligent platform.',
  primaryCta: { label: 'Start Free', href: '/contact' },
  secondaryCta: { label: 'See How It Works', href: '#how-it-works' },
  /** Honest, checkable statements only — no metrics, no customer counts. */
  assurances: [
    'One workspace instead of six disconnected tools',
    'Structured data generated only from data you provide',
    'Your brand rules applied across every module',
  ],
} as const;

export const problem = {
  id: 'problem',
  eyebrow: 'The problem',
  heading: 'Marketing work is scattered across tools that do not talk to each other',
  intro:
    'Strategy lives in a document, content in another tool, SEO in a third, ads in a fourth and reporting in a spreadsheet. The cost is not licence fees — it is that no tool has enough context to be genuinely useful, so the work of holding it together falls on you.',
  points: [
    {
      title: 'Context is lost between tools',
      body: 'The tool writing your content does not know the strategy, so every brief is rewritten from memory.',
    },
    {
      title: 'The same message drifts',
      body: 'An ad, a landing page and a social post about one launch end up saying three different things.',
    },
    {
      title: 'Technical work gets skipped',
      body: 'Structured data, metadata and internal linking are the first things dropped when time is short.',
    },
    {
      title: 'Reporting is reconstruction',
      body: 'Attribution is rebuilt by hand at month end, from data that was never joined up in the first place.',
    },
  ],
} as const;

export const solution = {
  id: 'solution',
  eyebrow: 'The SeSha approach',
  heading: 'One workspace where every module shares the same context',
  intro:
    'SeSha keeps strategy, brand, content, campaigns and measurement in a single system. Because the modules read from the same source, work produced in one is already consistent with the rest.',
  pillars: [
    {
      title: 'Shared context',
      body: 'Your brand kit and strategy are defined once and read by every module, so drafts start informed rather than blank.',
    },
    {
      title: 'AI you can check',
      body: 'The copilot proposes; you decide. Every output is editable and shows what it was based on.',
    },
    {
      title: 'Technical work included',
      body: 'Metadata, structured data and internal linking are produced alongside the content, not bolted on afterwards.',
    },
    {
      title: 'Measurement that joins up',
      body: 'Leads keep the campaign and page that created them, so reporting is a query rather than a reconstruction.',
    },
  ],
} as const;

export const howItWorks = {
  id: 'how-it-works',
  eyebrow: 'How it works',
  heading: 'From positioning to published work in four steps',
  intro:
    'The sequence is deliberate: context first, then plan, then production, then measurement. Each step feeds the next.',
  steps: [
    {
      number: 1,
      title: 'Define your brand and audience',
      body: 'Set up the brand kit — voice, tone, terminology and visual assets — and describe who you are selling to. This becomes the context every module reads.',
    },
    {
      number: 2,
      title: 'Build the strategy',
      body: 'Turn that context into an editable marketing plan: segments, messaging pillars, channel mix and a publishing calendar.',
    },
    {
      number: 3,
      title: 'Produce and publish',
      body: 'Create content, campaigns, social posts and ads from the plan. Metadata and structured data are generated as you go.',
    },
    {
      number: 4,
      title: 'Measure and adjust',
      body: 'Leads and results link back to the work that produced them, so the next cycle starts from evidence rather than guesswork.',
    },
  ],
} as const;

export const pricingPreview = {
  id: 'pricing-preview',
  eyebrow: 'Pricing',
  heading: 'Plans for solo marketers, growing teams and agencies',
  intro:
    'Every plan includes the full module set. Tiers differ by workspace count, seats and automation volume.',
  cta: { label: 'See full pricing', href: '/pricing' },
} as const;

export const finalCta = {
  id: 'get-started',
  heading: 'Bring your marketing into one workspace',
  body: 'Tell us what you are working on and we will show you how SeSha fits your setup.',
  primaryCta: { label: 'Start Free', href: '/contact' },
  secondaryCta: { label: 'Try the schema validator', href: '/schema-validator' },
} as const;

/** Section 19 — use cases, linking to the nine solution verticals. */
export const useCases = {
  id: 'use-cases',
  eyebrow: 'Use cases',
  heading: 'Built to adapt to how your business actually markets',
  intro:
    'The modules stay the same; the plans, content types and structured data change to fit the vertical.',
} as const;
