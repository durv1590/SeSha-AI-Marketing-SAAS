/**
 * The platform module catalogue.
 *
 * Home sections 4–17, the /features page and the solutions pages all render
 * from this one array, so a capability is described once and stays consistent
 * everywhere. Add a module here and it appears in every surface automatically.
 *
 * CLAIMS POLICY: entries describe what a module does. No performance figures,
 * customer counts, rankings, awards or superlatives. `benefits` are outcomes a
 * user works toward, never guaranteed results.
 */

export type IconName =
  | 'copilot'
  | 'strategy'
  | 'content'
  | 'search'
  | 'answer'
  | 'schema'
  | 'social'
  | 'ads'
  | 'leads'
  | 'analytics'
  | 'automation'
  | 'competitor'
  | 'reports'
  | 'brand';

export interface PlatformModule {
  readonly id: string;
  /** Short label used in navigation and chips. */
  readonly name: string;
  /** Section heading on the home page. */
  readonly heading: string;
  /** One-sentence definition — also used as the AEO direct answer. */
  readonly summary: string;
  /** Two or three sentences of supporting explanation. */
  readonly detail: string;
  readonly capabilities: readonly string[];
  readonly icon: IconName;
  /** Optional deep link to a dedicated page. */
  readonly href?: string;
}

export const modules: readonly PlatformModule[] = [
  {
    id: 'ai-copilot',
    name: 'AI Copilot',
    heading: 'An AI copilot that works inside your marketing context',
    summary:
      'The AI copilot is an assistant that answers marketing questions and drafts work using the brand, audience and campaign context already stored in your workspace.',
    detail:
      'Rather than starting from a blank prompt, the copilot reads the brand kit, the strategy you have defined and the assets in your workspace, then proposes drafts, outlines and next actions. Every suggestion is editable, and you decide what gets saved or published.',
    capabilities: [
      'Ask questions about your own strategy, content and campaigns',
      'Generate first drafts that follow your brand voice rules',
      'Turn a brief into an outline, an outline into a draft',
      'Explain its reasoning so you can check the work',
    ],
    icon: 'copilot',
  },
  {
    id: 'strategy',
    name: 'Strategy',
    heading: 'Turn positioning into a marketing plan you can execute',
    summary:
      'The strategy module converts your audience, positioning and goals into a structured marketing plan with channels, themes and a publishing calendar.',
    detail:
      'You describe who you serve and what you sell. The workspace builds an editable plan: audience segments, messaging pillars, channel mix and a content calendar. The plan stays live, so campaigns and content you create later inherit the same positioning.',
    capabilities: [
      'Audience segments and messaging pillars',
      'Channel mix with reasoning you can review',
      'Quarterly themes and a publishing calendar',
      'A single plan that downstream modules read from',
    ],
    icon: 'strategy',
  },
  {
    id: 'content-studio',
    name: 'Content Studio',
    heading: 'Draft, review and publish content in one workspace',
    summary:
      'Content Studio is a workspace for producing marketing content — blog posts, landing copy, emails and social posts — with AI drafting, editorial review and brand-voice checks built in.',
    detail:
      'Every piece moves through a visible workflow from brief to draft to review to publish-ready. Brand voice rules from the brand kit are applied as you write, and structured data is generated for content that needs it.',
    capabilities: [
      'Briefs, outlines and drafts in one place',
      'Brand voice rules applied while you write',
      'Editorial review states and version history',
      'Structured data generated alongside the content',
    ],
    icon: 'content',
  },
  {
    id: 'seo',
    name: 'SEO',
    heading: 'Search optimisation that covers technical, content and links',
    summary:
      'The SEO module helps you plan keyword coverage, review on-page structure, manage metadata and keep internal linking coherent across the site.',
    detail:
      'Search visibility depends on three things working together: pages a crawler can read, content that matches intent, and a link structure that shows what matters. The module keeps all three in one view instead of three disconnected tools.',
    capabilities: [
      'Topic and keyword coverage planning',
      'On-page structure and heading hierarchy review',
      'Metadata and canonical management',
      'Internal linking suggestions across your pages',
    ],
    icon: 'search',
    href: '/seo',
  },
  {
    id: 'aeo',
    name: 'AEO',
    heading: 'Answer engine optimisation for AI-generated answers',
    summary:
      'Answer engine optimisation is the practice of structuring content so AI answer systems and search summaries can extract, attribute and cite it accurately.',
    detail:
      'Answer engines quote sources that state a definition clearly, support it with explanation, and mark up authorship and structure. The AEO module scores your pages against those patterns and shows exactly which part of a page is unquotable.',
    capabilities: [
      'Answer-first page structure checks',
      'Definition, explanation and example coverage',
      'Authorship, freshness and citation signals',
      'FAQ and question coverage for a topic',
    ],
    icon: 'answer',
    href: '/aeo',
  },
  {
    id: 'schema-validator',
    name: 'Schema Validator',
    heading: 'Generate and validate structured data without guesswork',
    summary:
      'The schema tooling generates JSON-LD from your real page data and validates it for missing required properties, malformed dates and broken breadcrumb or FAQ markup.',
    detail:
      'Structured data fails quietly: a missing property or an out-of-order breadcrumb costs rich results with no visible error. The validator is free to use on this site, and the generator only ever emits values that exist in your workspace.',
    capabilities: [
      'JSON-LD generation from verified page data',
      'Validation for required and recommended properties',
      'Breadcrumb ordering and FAQ structure checks',
      'Clear error paths that point at the exact node',
    ],
    icon: 'schema',
    href: '/schema-validator',
  },
  {
    id: 'social',
    name: 'Social Media',
    heading: 'Plan and schedule social content from the same calendar',
    summary:
      'The social module plans, drafts and schedules posts across channels from the same calendar and brand kit the rest of your marketing uses.',
    detail:
      'Social posts are generated from the content and campaigns you already have, so a launch post carries the same message as the landing page it points to. Formats adapt per channel while the underlying message stays fixed.',
    capabilities: [
      'One calendar shared with content and campaigns',
      'Per-channel formatting from a single message',
      'Draft, approve and schedule workflow',
      'Reusable post templates per campaign type',
    ],
    icon: 'social',
  },
  {
    id: 'advertising',
    name: 'Advertising',
    heading: 'Build campaign structures and ad copy variants',
    summary:
      'The advertising module helps you structure campaigns, generate ad copy variants and keep landing-page messaging aligned with what the ad promises.',
    detail:
      'Campaign structure, audience and creative are planned together. Copy variants are produced in sets so you can test message angles rather than word-level tweaks, and each variant links back to the landing page it drives to.',
    capabilities: [
      'Campaign and ad group structure planning',
      'Copy variants grouped by message angle',
      'Ad-to-landing-page message alignment checks',
      'Reusable creative briefs per campaign',
    ],
    icon: 'ads',
  },
  {
    id: 'leads',
    name: 'Lead Management',
    heading: 'Capture, qualify and route inbound leads',
    summary:
      'Lead management captures enquiries from your forms and landing pages, records their source, and routes them to the right owner with a qualification summary.',
    detail:
      'Every lead keeps the campaign, page and content that produced it, so attribution is not reconstructed later. Qualification notes are drafted from the enquiry itself and remain fully editable.',
    capabilities: [
      'Form and landing-page capture with source tracking',
      'Qualification summaries you can edit',
      'Owner routing rules',
      'Export to your CRM',
    ],
    icon: 'leads',
  },
  {
    id: 'analytics',
    name: 'Analytics',
    heading: 'See what your marketing is actually doing',
    summary:
      'Analytics connects content, campaigns and leads so you can see which work produced which result instead of reading each channel in isolation.',
    detail:
      'Because content, campaigns and leads live in the same workspace, the reporting layer can trace a lead back to the page and campaign that created it. Metrics shown are the ones you connect — nothing is estimated or invented.',
    capabilities: [
      'Content, campaign and lead performance in one view',
      'Source attribution carried from capture',
      'Comparisons across time periods',
      'Only data you connect — no estimated figures',
    ],
    icon: 'analytics',
  },
  {
    id: 'automation',
    name: 'Automation',
    heading: 'Automate the repetitive parts, keep the judgement calls',
    summary:
      'Automation runs recurring marketing work — briefs, publishing steps, reporting and follow-ups — on a schedule or in response to an event in your workspace.',
    detail:
      'Automations are built from the same building blocks you use manually, so you can see exactly what each step will do before enabling it. Anything that publishes or contacts a person can require approval first.',
    capabilities: [
      'Scheduled and event-triggered workflows',
      'Approval steps before anything goes out',
      'Reusable workflow templates',
      'A full run history for every automation',
    ],
    icon: 'automation',
  },
  {
    id: 'competitor',
    name: 'Competitor Intelligence',
    heading: 'Track how competitors position and publish',
    summary:
      'Competitor intelligence tracks the public positioning, messaging and published content of the competitors you choose to follow.',
    detail:
      'You select the competitors. The module summarises how they describe themselves, which topics they publish on, and where their coverage differs from yours, so gaps in your own plan become visible.',
    capabilities: [
      'A watchlist of competitors you choose',
      'Positioning and messaging summaries',
      'Topic coverage comparison against your plan',
      'Content gap shortlists',
    ],
    icon: 'competitor',
  },
  {
    id: 'reports',
    name: 'Reports',
    heading: 'Reporting that explains the numbers, not just prints them',
    summary:
      'Reports turn workspace data into shareable summaries for clients or stakeholders, with written commentary explaining what changed and why.',
    detail:
      'Reports are built from the same connected data as the analytics view, so a client report and an internal dashboard never disagree. Commentary is drafted for you and stays editable before you send it.',
    capabilities: [
      'Scheduled client and stakeholder reports',
      'Written commentary you can edit',
      'Consistent figures across every export',
      'Brand-kit styling applied automatically',
    ],
    icon: 'reports',
  },
  {
    id: 'brand-kit',
    name: 'Brand Kit',
    heading: 'One brand definition every module reads from',
    summary:
      'The brand kit stores your voice, tone rules, terminology, colours and logos so every module produces work that already matches your brand.',
    detail:
      'Brand rules are defined once and applied everywhere — content drafts, ad copy, social posts and reports. For agencies, each client gets its own brand kit inside the same workspace.',
    capabilities: [
      'Voice, tone and terminology rules',
      'Colour, type and logo assets',
      'Per-client brand kits for agencies',
      'Applied automatically across every module',
    ],
    icon: 'brand',
  },
];

export const moduleById = new Map(modules.map((m) => [m.id, m]));

export function getModule(id: string): PlatformModule {
  const found = moduleById.get(id);
  if (!found) throw new Error(`Unknown module "${id}".`);
  return found;
}

/** Feature names used in SoftwareApplication structured data. */
export function featureList(): string[] {
  return modules.map((m) => m.name);
}
