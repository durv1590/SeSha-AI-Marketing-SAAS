/**
 * Shared content block model.
 *
 * Long-form pages (blog posts, legal pages, the SEO and AEO explainers) are
 * authored as typed blocks rather than raw HTML or MDX. Three reasons:
 *  1. No markdown toolchain, so Phase 1 adds no dependency to render prose.
 *  2. Everything server-renders as real HTML, which AEO requires — an answer
 *     engine must be able to read the content without running JavaScript.
 *  3. The renderer controls the heading hierarchy and element semantics, so a
 *     content author cannot accidentally break the document outline.
 */

export type Block =
  | { readonly kind: 'paragraph'; readonly text: string }
  | { readonly kind: 'heading'; readonly text: string; readonly id: string }
  | { readonly kind: 'list'; readonly items: readonly string[]; readonly ordered?: boolean }
  | { readonly kind: 'callout'; readonly title: string; readonly text: string }
  | { readonly kind: 'definition'; readonly term: string; readonly text: string };

/** Extracts headings for an on-page table of contents. */
export function headings(blocks: readonly Block[]): { id: string; text: string }[] {
  return blocks
    .filter((b): b is Extract<Block, { kind: 'heading' }> => b.kind === 'heading')
    .map((b) => ({ id: b.id, text: b.text }));
}
