/**
 * Pricing content.
 *
 * IMPORTANT — FABRICATION GUARD
 * Prices in this file are UNVERIFIED PLACEHOLDERS until the business confirms
 * them. `verified: false` has two consequences enforced elsewhere:
 *   1. `buildOffers()` in lib/schema refuses to publish the price in
 *      structured data (tests/schema.test.ts asserts this).
 *   2. The pricing page renders the tier WITHOUT a currency figure and shows a
 *      "pricing on request" state instead.
 * Set `verified: true` and fill in the real amount to publish a price. Do not
 * publish a number that has not been confirmed by the business.
 */

export interface PricingTier {
  readonly id: string;
  readonly name: string;
  readonly audience: string;
  readonly description: string;
  /** Monthly amount in `currency`. Meaningless while `verified` is false. */
  readonly monthlyPrice: number | null;
  readonly currency: string;
  readonly verified: boolean;
  readonly featured: boolean;
  readonly cta: { readonly label: string; readonly href: string };
  readonly includes: readonly string[];
  readonly limits: readonly { readonly label: string; readonly value: string }[];
}

export const pricingTiers: readonly PricingTier[] = [
  {
    id: 'starter',
    name: 'Starter',
    audience: 'Solo marketers and small businesses',
    description:
      'One workspace with the full module set, for a single brand run by one or two people.',
    monthlyPrice: null,
    currency: 'USD',
    verified: false,
    featured: false,
    cta: { label: 'Get started', href: '/contact' },
    includes: [
      'All fourteen modules',
      'One brand kit',
      'AI copilot with workspace context',
      'SEO, AEO and structured-data tooling',
      'Email support',
    ],
    limits: [
      { label: 'Workspaces', value: '1' },
      { label: 'Seats', value: 'Up to 2' },
      { label: 'Automations', value: 'Core workflows' },
    ],
  },
  {
    id: 'growth',
    name: 'Growth',
    audience: 'Marketing teams',
    description:
      'For a team running several campaigns at once, with review workflows and scheduled reporting.',
    monthlyPrice: null,
    currency: 'USD',
    verified: false,
    featured: true,
    cta: { label: 'Talk to us', href: '/contact' },
    includes: [
      'Everything in Starter',
      'Editorial review workflows',
      'Scheduled reports with commentary',
      'Competitor watchlist',
      'Priority email support',
    ],
    limits: [
      { label: 'Workspaces', value: 'Up to 3' },
      { label: 'Seats', value: 'Up to 10' },
      { label: 'Automations', value: 'Extended volume' },
    ],
  },
  {
    id: 'agency',
    name: 'Agency',
    audience: 'Agencies and multi-brand teams',
    description:
      'Per-client brand kits, repeatable delivery templates and client-ready reporting in one workspace.',
    monthlyPrice: null,
    currency: 'USD',
    verified: false,
    featured: false,
    cta: { label: 'Talk to us', href: '/contact' },
    includes: [
      'Everything in Growth',
      'Per-client brand kits',
      'Delivery workflow templates',
      'Client-ready report exports',
      'Onboarding support',
    ],
    limits: [
      { label: 'Workspaces', value: 'Unlimited clients' },
      { label: 'Seats', value: 'Custom' },
      { label: 'Automations', value: 'Custom volume' },
    ],
  },
];

/** True when no tier has a confirmed price — drives the on-page notice. */
export const pricingIsProvisional: boolean = pricingTiers.every((t) => !t.verified);

export const pricingFaqs = [
  {
    question: 'Why are prices not shown yet?',
    answer:
      'Plan pricing has not been finalised, and we will not publish a figure we have not confirmed. Contact us and we will give you current pricing for your setup directly.',
  },
  {
    question: 'Do all plans include every module?',
    answer:
      'Yes. All fourteen modules are included on every plan. Tiers differ by how many workspaces, seats and automation runs they cover, not by which features you can use.',
  },
  {
    question: 'Can I change plan later?',
    answer:
      'Yes. Plans can be changed as your team grows, and your workspace content is unaffected by a change of tier.',
  },
  {
    question: 'Is there a free trial?',
    answer:
      'The schema validator on this site is free to use with no account. For the full workspace, contact us and we will arrange access appropriate to your situation.',
  },
] as const;

export const pricingComparison = {
  heading: 'What differs between plans',
  rows: [
    { label: 'All fourteen modules', starter: true, growth: true, agency: true },
    { label: 'AI copilot', starter: true, growth: true, agency: true },
    { label: 'SEO, AEO and schema tooling', starter: true, growth: true, agency: true },
    { label: 'Editorial review workflows', starter: false, growth: true, agency: true },
    { label: 'Scheduled reports', starter: false, growth: true, agency: true },
    { label: 'Competitor watchlist', starter: false, growth: true, agency: true },
    { label: 'Per-client brand kits', starter: false, growth: false, agency: true },
    { label: 'Delivery workflow templates', starter: false, growth: false, agency: true },
  ],
} as const;
