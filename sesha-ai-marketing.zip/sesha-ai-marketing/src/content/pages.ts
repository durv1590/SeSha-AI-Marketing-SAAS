/**
 * Long-form page content: the SEO and AEO explainers, About, Security,
 * Privacy and Terms. Authored as shared content blocks (see ./blocks.ts).
 *
 * The SEO and AEO pages are written in strict AEO structure — definition,
 * direct answer, supporting explanation, examples, FAQs, related concepts,
 * author and last-updated — because they are the pages most likely to be
 * quoted by an answer engine.
 */

import type { Block } from './blocks';
import { authors, organization } from './site';

export interface AnswerPage {
  readonly title: string;
  readonly definitionTerm: string;
  readonly definition: string;
  readonly directAnswer: string;
  readonly blocks: readonly Block[];
  readonly examples: readonly { readonly title: string; readonly body: string }[];
  readonly faqs: readonly { readonly question: string; readonly answer: string }[];
  readonly related: readonly { readonly label: string; readonly href: string }[];
  readonly lastUpdated: string;
  readonly authorId: keyof typeof authors;
}

/* -------------------------------------------------------------------------- */
/* /seo                                                                       */
/* -------------------------------------------------------------------------- */

export const seoPage: AnswerPage = {
  title: 'Search engine optimisation in one workspace',
  definitionTerm: 'Search engine optimisation (SEO)',
  definition:
    'Search engine optimisation is the practice of making a website findable and understandable to search engines so that its pages can rank for the queries its audience actually searches.',
  directAnswer:
    'SEO succeeds when three things hold at once: a search engine can crawl and parse your pages, the content matches what the searcher intended, and your internal link structure makes clear which pages matter. SeSha keeps all three in one view instead of splitting them across separate tools.',
  lastUpdated: '2026-09-11',
  authorId: 'editorial',
  blocks: [
    {
      kind: 'paragraph',
      text: 'Most SEO problems are not mysterious. They fall into a small number of categories, and the reason they persist is that the tools covering each category do not share any context with one another.',
    },
    { kind: 'heading', id: 'technical', text: 'Technical: can it be read?' },
    {
      kind: 'paragraph',
      text: 'A page that cannot be crawled, rendered or parsed cannot rank, however good the writing is. This layer covers status codes, canonical tags, redirects, sitemaps, robots directives, heading hierarchy and page performance.',
    },
    {
      kind: 'list',
      items: [
        'One canonical URL per piece of content, with query strings stripped',
        'A heading hierarchy that describes the document, not the visual design',
        'A sitemap generated from the actual route registry, not maintained by hand',
        'Content present in the server-rendered HTML',
      ],
    },
    { kind: 'heading', id: 'content', text: 'Content: does it match intent?' },
    {
      kind: 'paragraph',
      text: 'Intent is the gap between what someone typed and what they wanted. A query can be informational, comparative, or transactional, and a page that answers the wrong one will not perform no matter how well it is optimised technically.',
    },
    {
      kind: 'paragraph',
      text: 'This is where topic coverage matters more than keyword density. A topic is covered when the questions a reader would reasonably ask next are answered somewhere you control and linked from where they would look.',
    },
    { kind: 'heading', id: 'links', text: 'Links: what does the structure say?' },
    {
      kind: 'paragraph',
      text: 'Internal linking is the most neglected of the three and the easiest to fix. The pages you link to most often, from the most places, are the pages you are telling search engines to treat as important. When that structure is accidental, it usually contradicts your actual priorities.',
    },
    {
      kind: 'callout',
      title: 'Nobody can guarantee rankings',
      text: 'Search engines control their own results and change them continuously. Any tool promising a position is selling you something it cannot deliver. What can be controlled is whether the work that influences visibility is done consistently.',
    },
    { kind: 'heading', id: 'seo-and-aeo', text: 'How this relates to AEO' },
    {
      kind: 'paragraph',
      text: 'Answer engine optimisation builds on top of SEO rather than replacing it. A passage cannot be quoted in a generated answer unless the page was findable and trustworthy first. The difference is what you optimise the page shape for: a ranked link, or an extractable answer.',
    },
  ],
  examples: [
    {
      title: 'Generated, not hand-maintained, sitemaps',
      body: 'This site generates its sitemap from the same route registry that renders navigation and breadcrumbs, so a new page cannot be missing from it.',
    },
    {
      title: 'Metadata linted in the test suite',
      body: 'Every page title and description on this site is checked for length, uniqueness and structure by an automated test, so a truncated title fails the build rather than shipping.',
    },
  ],
  faqs: [
    {
      question: 'How long does SEO take to show results?',
      answer:
        'It varies by competition, site authority and how large the change is, and honest answers are ranges rather than dates. Technical fixes can register within days; content and authority work is typically a multi-month effort.',
    },
    {
      question: 'Is SEO still relevant if AI answers questions directly?',
      answer:
        'Yes. Answer engines select from indexed, crawlable sources, so the fundamentals that make a page findable are also what make it eligible to be cited.',
    },
    {
      question: 'Does SeSha submit pages to search engines?',
      answer:
        'It generates the sitemap and robots directives that search engines use to discover pages. Submission and verification stay in your own search console account.',
    },
  ],
  related: [
    { label: 'Answer engine optimisation', href: '/aeo' },
    { label: 'Schema validator', href: '/schema-validator' },
    { label: 'All features', href: '/features' },
  ],
};

/* -------------------------------------------------------------------------- */
/* /aeo                                                                       */
/* -------------------------------------------------------------------------- */

export const aeoPage: AnswerPage = {
  title: 'Answer engine optimisation',
  definitionTerm: 'Answer engine optimisation (AEO)',
  definition:
    'Answer engine optimisation is the practice of structuring and marking up content so that AI answer systems and search summaries can extract a passage, attribute it correctly and cite it.',
  directAnswer:
    'AEO differs from SEO in what it competes for: SEO competes for a ranked link, AEO competes to be the sentence quoted inside a generated answer. In practice that means leading with a self-contained definition, answering directly within the first hundred words, using explicit structure and markup, and making authorship and freshness visible.',
  lastUpdated: '2026-09-11',
  authorId: 'editorial',
  blocks: [
    {
      kind: 'paragraph',
      text: 'When an answer engine composes a response, it needs passages it can lift without distorting them. That is a different requirement from ranking, and it rewards a different page shape.',
    },
    { kind: 'heading', id: 'principles', text: 'The four principles' },
    {
      kind: 'list',
      ordered: true,
      items: [
        'Answer first. The direct answer appears before the explanation, not after it.',
        'Make passages self-contained. A quoted sentence must still make sense alone.',
        'Be explicit about structure. Real headings, real lists, real FAQ markup.',
        'Be attributable. Named authorship, a last-updated date, and a stable URL.',
      ],
    },
    { kind: 'heading', id: 'self-contained', text: 'Why self-contained matters most' },
    {
      kind: 'paragraph',
      text: 'The single most common reason a good page is not quoted is that its sentences depend on the ones before them. "This makes it significantly faster" is unusable out of context; "Server-side rendering reduces time to first contentful paint because the browser receives HTML rather than an empty shell" is quotable on its own.',
    },
    {
      kind: 'callout',
      title: 'The extraction test',
      text: 'Copy one sentence from your page and read it with no surrounding context. If it still answers the question and names its subject, an answer engine can use it.',
    },
    { kind: 'heading', id: 'javascript', text: 'Do not hide the answer behind JavaScript' },
    {
      kind: 'paragraph',
      text: 'Content that only exists after a click is content an answer engine may never see. Collapsible sections are fine when the content is present in the HTML and merely hidden with CSS — which is why the FAQ sections on this site are built from native disclosure elements that render their answers into the page regardless of interaction.',
    },
    { kind: 'heading', id: 'markup', text: 'What structured data adds' },
    {
      kind: 'paragraph',
      text: 'Markup does not make a passage quotable, but it removes ambiguity about what the passage is. FAQPage markup declares that a block is a question and its answer. Article markup names the author and the dates. Each one converts an inference into a stated fact — and each fails silently when it is invalid, which is why validating it matters.',
    },
    { kind: 'heading', id: 'honesty', text: 'Attribution cuts both ways' },
    {
      kind: 'paragraph',
      text: 'Being quotable means being quoted accurately, including when you are wrong. Unverifiable claims, invented statistics and fabricated reviews are more damaging in an AEO context than in a traditional one, because a generated answer strips the hedging language that made them look reasonable on your own page.',
    },
  ],
  examples: [
    {
      title: 'A definition block before the prose',
      body: 'Every answer-first page on this site opens with a marked-up definition, so the term and its meaning can be extracted as one unit.',
    },
    {
      title: 'FAQs that exist in the HTML',
      body: 'FAQ answers on this site are server-rendered inside native disclosure elements, so they are readable without JavaScript and are covered by FAQPage markup.',
    },
  ],
  faqs: [
    {
      question: 'Is AEO just SEO with a new name?',
      answer:
        'No, though they overlap heavily. SEO optimises for retrieval and ranking; AEO optimises for extraction and attribution. A page can rank well and still be useless to an answer engine because its sentences are not self-contained.',
    },
    {
      question: 'Which pages should be AEO-structured first?',
      answer:
        'Start with pages that answer a definable question: definitions, comparisons, how-to content and FAQs. Pages whose purpose is persuasion rather than explanation benefit less.',
    },
    {
      question: 'Can I measure AEO performance?',
      answer:
        'Only partially today. Answer engines expose limited attribution data, so measurement usually combines citation spot-checks for target questions with conventional search metrics.',
    },
    {
      question: 'Does AEO require structured data?',
      answer:
        'Not strictly, but it helps substantially. Markup removes ambiguity about what a block of content is, and it is the difference between an engine inferring your author and knowing it.',
    },
  ],
  related: [
    { label: 'SEO workspace', href: '/seo' },
    { label: 'Validate your structured data', href: '/schema-validator' },
    { label: 'What is AEO? (article)', href: '/blog' },
  ],
};

/* -------------------------------------------------------------------------- */
/* /about                                                                     */
/* -------------------------------------------------------------------------- */

export const aboutPage = {
  heading: `About ${organization.brandName}`,
  intro: `${organization.brandName} is built by ${organization.legalName}. We are building a marketing workspace where strategy, content, search, structured data and measurement share the same context, because the cost of keeping them in separate tools falls entirely on the person doing the work.`,
  blocks: [
    { kind: 'heading', id: 'what-we-are-building', text: 'What we are building' },
    {
      kind: 'paragraph',
      text: 'A single workspace for marketing work: brand and strategy defined once, then read by every module that produces content, campaigns, markup and reports. The aim is not to add another tool to the stack but to remove the seams between the ones already there.',
    },
    { kind: 'heading', id: 'principles', text: 'How we build' },
    {
      kind: 'list',
      items: [
        'AI proposes, a person approves. Nothing publishes itself.',
        'Structured data is generated from real data or not at all.',
        'We do not publish claims, figures or reviews we cannot evidence.',
        'Technical work — metadata, markup, linking — is part of the output, not an upsell.',
        'What is not built yet is described as not built yet.',
      ],
    },
    { kind: 'heading', id: 'status', text: 'Where the product is today' },
    {
      kind: 'paragraph',
      text: 'This website is the public foundation of the platform, and the schema validator on it is a working tool you can use now with no account. The authenticated workspace — sign-in, brand kits, the copilot and the module set described across this site — is in active development and is not yet generally available. Contact us and we will tell you honestly what you can use today.',
    },
    { kind: 'heading', id: 'contact', text: 'Talking to us' },
    {
      kind: 'paragraph',
      text: `The fastest route is the contact form, which reaches the team directly. For security reports, use the disclosure process on the security page rather than the general form.`,
    },
  ] as readonly Block[],
  lastUpdated: '2026-09-11',
} as const;

/* -------------------------------------------------------------------------- */
/* /security                                                                  */
/* -------------------------------------------------------------------------- */

export const securityPage: AnswerPage = {
  title: 'Security',
  definitionTerm: 'Our security posture',
  definition:
    'This page describes the security controls implemented on the SeSha public website and how to report a vulnerability.',
  directAnswer:
    'The public website enforces a strict content security policy that blocks all third-party scripts, sends a full set of hardening headers, validates and sanitises every form input on the server, and rate-limits its API endpoints. It stores no accounts, passwords or payment data, because authentication is not part of this phase.',
  lastUpdated: '2026-09-11',
  authorId: 'editorial',
  blocks: [
    { kind: 'heading', id: 'transport', text: 'Transport and browser hardening' },
    {
      kind: 'list',
      items: [
        'HTTPS enforced in production, with HSTS including subdomains and preload',
        'A content security policy that allow-lists no external origins at all',
        'Framing denied through both frame-ancestors and X-Frame-Options',
        'MIME sniffing disabled; referrer policy set to strict-origin-when-cross-origin',
        'Permissions policy disabling camera, microphone, geolocation and payment',
        'Cross-origin opener and resource policies set to same-origin',
      ],
    },
    { kind: 'heading', id: 'application', text: 'Application controls' },
    {
      kind: 'list',
      items: [
        'Every form input is validated and sanitised server-side, never trusting the client',
        'Control characters are stripped and email header injection is rejected',
        'API endpoints are rate-limited per client, failing closed when the client is unknown',
        'Bot submissions are filtered with a honeypot field and a submit-timing check',
        'Responses never echo back unsanitised input',
      ],
    },
    { kind: 'heading', id: 'data', text: 'What this website stores' },
    {
      kind: 'paragraph',
      text: 'Contact and newsletter submissions, and standard server request logs. There are no analytics, advertising or session-tracking scripts on this site — the content security policy would block them. Input submitted to the schema validator is processed to produce your report and is not persisted as content.',
    },
    { kind: 'heading', id: 'not-yet', text: 'What is not in place yet' },
    {
      kind: 'paragraph',
      text: 'We would rather state this than imply otherwise. There is no authentication system on this site yet, so there is no session, password or account security to describe. Rate limiting is per-instance rather than distributed. The content security policy uses inline-script allowances rather than per-request nonces. No third-party security certification has been obtained. All four are scheduled work for the authenticated application phase.',
    },
    { kind: 'heading', id: 'disclosure', text: 'Reporting a vulnerability' },
    {
      kind: 'paragraph',
      text: `Email ${organization.email} with the subject line "Security". Include the affected URL, the steps to reproduce and what you observed. We ask that you give us reasonable time to respond before publishing, and that you avoid testing that degrades service or accesses other people's data. We do not currently operate a paid bug bounty.`,
    },
  ],
  examples: [
    {
      title: 'No third-party origins',
      body: 'The content security policy on this site allow-lists no external script, style, font or image hosts, so a supply-chain compromise of a CDN cannot reach your browser through this site.',
    },
    {
      title: 'Fail closed, not open',
      body: 'When a request arrives with no identifiable client address, the rate limiter assigns it to a shared restricted bucket rather than exempting it.',
    },
  ],
  faqs: [
    {
      question: 'Do you use third-party analytics or tracking?',
      answer:
        'No. This website loads no third-party scripts of any kind, and the content security policy is configured to block them rather than relying on policy alone.',
    },
    {
      question: 'Is the data I paste into the schema validator stored?',
      answer:
        'No. It is processed to generate your validation report and is not written to a database or logged as content. As with any web form, do not paste secrets into it.',
    },
    {
      question: 'Do you have SOC 2 or ISO 27001 certification?',
      answer:
        'No. We hold no third-party security certification today and will not claim otherwise. If certification becomes relevant to your evaluation, contact us and we will tell you the current status directly.',
    },
  ],
  related: [
    { label: 'Privacy policy', href: '/privacy' },
    { label: 'Terms of service', href: '/terms' },
    { label: 'Contact us', href: '/contact' },
  ],
};
