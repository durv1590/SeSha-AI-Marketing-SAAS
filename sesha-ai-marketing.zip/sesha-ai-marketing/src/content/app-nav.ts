/**
 * Authenticated application navigation.
 *
 * Kept separate from the public `nav.ts` on purpose: these routes must never
 * appear in the sitemap, in the marketing footer, or in the public link-
 * integrity test.
 *
 * AVAILABILITY IS EXPLICIT. Every item declares a `status`, and the shell
 * renders `planned` items as visibly disabled with a "coming soon" label rather
 * than as a working link to an empty page. The brief asks for proper
 * coming-soon states instead of fake functionality, and making it a data field
 * means a feature cannot be quietly presented as ready.
 */

import type { IconName } from './modules';
import type { Permission } from '@/lib/auth/rbac';

export type FeatureStatus = 'available' | 'planned';

export interface AppNavItem {
  readonly label: string;
  readonly href: string;
  readonly icon: IconName | 'home' | 'settings' | 'calendar' | 'template' | 'audit' | 'video';
  readonly status: FeatureStatus;
  /** Shown on the coming-soon state, so the label is honest about scope. */
  readonly note?: string;
  readonly permission?: Permission;
}

export interface AppNavGroup {
  readonly label: string;
  readonly items: readonly AppNavItem[];
}

/** Primary navigation, exactly as the Phase 2 brief lists it. */
export const appPrimaryNav: readonly AppNavItem[] = [
  { label: 'Home', href: '/app', icon: 'home', status: 'available' },
  {
    label: 'AI',
    href: '/app/ai',
    icon: 'copilot',
    status: 'available',
    note: 'Ask questions about your workspace. Every answer says where it came from.',
    permission: 'content:create',
  },
  {
    label: 'Create',
    href: '/app/create',
    icon: 'content',
    status: 'available',
    note: 'Content Studio: twenty formats, in English, Hindi or Hinglish.',
    permission: 'content:create',
  },
  {
    label: 'Strategy',
    href: '/app/strategy',
    icon: 'strategy',
    status: 'available',
    note: 'A seventeen-section marketing strategy built from your own profile.',
    permission: 'content:create',
  },
  {
    label: 'SEO/AEO',
    href: '/app/seo-aeo',
    icon: 'search',
    status: 'available',
    note: 'Technical SEO and answer-engine findings from a crawl of your own site.',
    permission: 'content:read',
  },
  {
    label: 'Campaigns',
    href: '/app/campaigns',
    icon: 'ads',
    status: 'available',
    note: 'Plan ads for five platforms against their real limits. No ad account is connected, so nothing spends.',
    permission: 'campaign:read',
  },
  {
    label: 'Leads',
    href: '/app/leads',
    icon: 'leads',
    status: 'available',
    note: 'A seven-stage pipeline, with a lead score that shows its own reasoning.',
    permission: 'lead:read',
  },
  {
    label: 'Analytics',
    href: '/app/analytics',
    icon: 'analytics',
    status: 'available',
    note: 'Every figure labelled with where it came from. Nothing estimated.',
    permission: 'analytics:read',
  },
];

/** The "More" menu, exactly as the brief lists it. */
export const appMoreNav: readonly AppNavItem[] = [
  {
    label: 'Website Audit',
    href: '/app/website-audit',
    icon: 'search',
    status: 'available',
    note: 'Crawl your own site, with your explicit permission, and see exactly what was read.',
  },
  {
    label: 'Schema Validator',
    href: '/app/schema-validator',
    icon: 'schema',
    status: 'available',
    note: 'The same validator as the public tool, inside your workspace.',
  },
  {
    label: 'Social',
    href: '/app/social',
    icon: 'social',
    status: 'available',
    note: 'Draft posts for seven platforms. Publishing needs an official API, which is not connected.',
  },
  {
    label: 'Competitors',
    href: '/app/competitors',
    icon: 'competitor',
    status: 'available',
    note: 'What they publish publicly, read from their own pages. Verified observations are kept apart from AI inference.',
  },
  {
    label: 'Calendar',
    href: '/app/calendar',
    icon: 'calendar',
    status: 'available',
    note: 'Daily, weekly, monthly and campaign views. Nothing publishes automatically — no platform API is connected.',
    permission: 'campaign:read',
  },
  {
    label: 'Automations',
    href: '/app/automations',
    icon: 'automation',
    status: 'available',
    note: 'Trigger, condition, action. Nothing is sent, posted or spent.',
    permission: 'campaign:read',
  },
  {
    label: 'Reports',
    href: '/app/reports',
    icon: 'reports',
    status: 'available',
    note: 'Nine reports, six questions, PDF / CSV / JSON, and a revocable share link.',
    permission: 'analytics:read',
  },
  {
    label: 'Email & WhatsApp',
    href: '/app/messaging',
    icon: 'content',
    status: 'available',
    note: 'Write and plan messages. SeSha cannot send — no provider is connected.',
    permission: 'content:read',
  },
  {
    label: 'Video',
    href: '/app/video',
    icon: 'video',
    status: 'available',
    note: 'Scripts, hooks, shot lists and thumbnail briefs. No images are generated.',
    permission: 'content:read',
  },
  {
    label: 'Brand Kit',
    href: '/app/brand-kit',
    icon: 'brand',
    status: 'available',
    note: 'Voice and tone captured during onboarding.',
  },
  {
    label: 'Templates',
    href: '/app/templates',
    icon: 'template',
    status: 'planned',
    // No phase number in a customer-facing note: the only thing a phase
    // number tells them is that someone else is keeping a schedule they
    // cannot see, and the nav scan in tests/phase4-gate.test.ts rightly
    // reads any number here as a promise.
    note: 'Saved content presets are not built yet. The template settings staff manage are a different thing.',
  },
  {
    label: 'Usage',
    href: '/app/usage',
    icon: 'analytics',
    status: 'available',
    note: 'What you have used against your plan this period, and why anything was refused.',
  },
  { label: 'Settings', href: '/app/settings', icon: 'settings', status: 'available' },
];

export const appNavGroups: readonly AppNavGroup[] = [
  { label: 'Workspace', items: appPrimaryNav },
  { label: 'More', items: appMoreNav },
];

/** Every application route, for the route-coverage test. */
export const appRoutes: readonly string[] = [
  ...appPrimaryNav.map((item) => item.href),
  ...appMoreNav.map((item) => item.href),
  '/app/projects',
  '/app/settings/billing',
  '/onboarding',
  '/sign-in',
  '/sign-up',
  '/forgot-password',
  '/reset-password',
  '/verify-email',
];

export function availableCount(): number {
  return [...appPrimaryNav, ...appMoreNav].filter((item) => item.status === 'available').length;
}
