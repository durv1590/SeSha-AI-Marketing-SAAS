/**
 * Blog content.
 *
 * Posts are stored as typed content blocks rather than MDX so that Phase 1
 * ships with no markdown toolchain and every post is server-rendered as real
 * HTML — which matters for AEO: an answer engine must be able to read the
 * content without executing JavaScript.
 *
 * Phase 2 replaces this module with the PostgreSQL-backed posts table defined
 * in db/schema.sql. The `Post` interface is deliberately shaped like that table
 * so the swap is a repository change, not a rewrite.
 */

import { authors, type Author } from './site';
import type { Block } from './blocks';

export interface Post {
  readonly slug: string;
  readonly title: string;
  readonly excerpt: string;
  /** AEO: a complete, quotable answer placed before the body. */
  readonly directAnswer: string;
  readonly publishedAt: string;
  readonly updatedAt: string;
  readonly author: Author;
  readonly category: string;
  readonly readingMinutes: number;
  readonly blocks: readonly Block[];
  readonly faqs: readonly { readonly question: string; readonly answer: string }[];
  readonly related: readonly { readonly label: string; readonly href: string }[];
}

const editorial = authors.editorial!;

export const posts: readonly Post[] = [
  {
    slug: 'what-is-answer-engine-optimisation',
    title: 'What is answer engine optimisation, and how is it different from SEO?',
    excerpt:
      'AEO is the practice of structuring content so AI answer systems can extract, attribute and cite it. Here is how it differs from SEO in practice.',
    directAnswer:
      'Answer engine optimisation (AEO) is the practice of structuring content so that AI answer systems can extract a passage, attribute it to you and cite it accurately. SEO competes for a ranked link; AEO competes to be the quoted sentence inside a generated answer.',
    publishedAt: '2026-06-18',
    updatedAt: '2026-09-11',
    author: editorial,
    category: 'AEO',
    readingMinutes: 7,
    blocks: [
      {
        kind: 'definition',
        term: 'Answer engine optimisation',
        text: 'Structuring and marking up content so that AI answer systems and search summaries can reliably extract, attribute and cite it.',
      },
      {
        kind: 'paragraph',
        text: 'Search behaviour has shifted. A growing share of questions is answered inside a generated summary rather than by a click through to a page. That does not make SEO obsolete — an answer engine still has to find and trust a source — but it changes what a winning page looks like.',
      },
      { kind: 'heading', id: 'what-changes', text: 'What actually changes' },
      {
        kind: 'paragraph',
        text: 'A page optimised only for ranking can still be useless to an answer engine. The classic pattern — a long preamble, a story, then the answer somewhere in the middle — gives a model nothing clean to quote. An AEO-shaped page states the answer in a single self-contained sentence, then supports it.',
      },
      {
        kind: 'list',
        items: [
          'A definition that stands alone without the surrounding paragraph',
          'A direct answer in the first hundred words, not the fifth section',
          'Explicit structure: real headings, real lists, real FAQ markup',
          'Verifiable authorship and a visible last-updated date',
          'Content in the HTML, not injected after a JavaScript interaction',
        ],
      },
      { kind: 'heading', id: 'the-extraction-test', text: 'The extraction test' },
      {
        kind: 'paragraph',
        text: 'There is a simple test for whether a passage is AEO-ready: copy one sentence out of the page and read it with no context. If it still answers the question and identifies what it is about, an answer engine can use it. If it starts with "this means that" or "as we saw above", it cannot.',
      },
      {
        kind: 'callout',
        title: 'A practical rule',
        text: 'Write the first sentence of every section so it survives being quoted on its own. Everything after it can assume context; that sentence cannot.',
      },
      { kind: 'heading', id: 'structured-data', text: 'Where structured data fits' },
      {
        kind: 'paragraph',
        text: 'Structured data does not make content quotable, but it removes ambiguity about what the content is. FAQPage markup tells a machine that a block is a question and its answer. Article markup identifies the author and the publication date. Breadcrumb markup places the page in a hierarchy. Each of these turns an inference into a fact.',
      },
      {
        kind: 'paragraph',
        text: 'The failure mode is quiet: markup with a missing required property is usually ignored entirely rather than reported, so a page can carry invalid JSON-LD for months with no visible signal. Validating markup before it ships is the cheapest part of AEO work.',
      },
      { kind: 'heading', id: 'what-not-to-do', text: 'What not to do' },
      {
        kind: 'list',
        items: [
          'Do not mark up content that is not visible on the page',
          'Do not publish ratings, reviews or awards you cannot evidence',
          'Do not hide the answer behind an accordion that only populates on click',
          'Do not strip authorship to make a page look brand-neutral',
        ],
      },
      {
        kind: 'paragraph',
        text: 'The last point is counterintuitive but consistent: answer engines favour sources they can attribute. Removing the author to look more official removes the signal that makes a passage safe to cite.',
      },
    ],
    faqs: [
      {
        question: 'Does AEO replace SEO?',
        answer:
          'No. AEO depends on SEO fundamentals — a page still has to be crawlable, indexed and trusted before it can be quoted. AEO is an additional layer concerned with extraction and attribution rather than ranking.',
      },
      {
        question: 'How do I know if AEO is working?',
        answer:
          'Track whether your pages appear as cited sources in AI answers for your target questions, alongside your normal search metrics. Direct measurement is limited today because answer engines expose little attribution data.',
      },
      {
        question: 'Does FAQ markup guarantee a rich result?',
        answer:
          'No. Valid markup makes a page eligible for enhanced treatment; it does not entitle it to one. Search engines decide what to display and change those rules regularly.',
      },
    ],
    related: [
      { label: 'AEO overview', href: '/aeo' },
      { label: 'Schema validator', href: '/schema-validator' },
      { label: 'SEO workspace', href: '/seo' },
    ],
  },

  {
    slug: 'structured-data-mistakes',
    title: 'Six structured data mistakes that silently cost you rich results',
    excerpt:
      'Invalid JSON-LD usually fails without an error message. These are the six failures we see most often, and how to catch each one.',
    directAnswer:
      'The six most common JSON-LD failures are missing required properties, non-ISO dates, out-of-order breadcrumb positions, FAQ entries without an acceptedAnswer, prices without a currency, and markup describing content that is not on the page. All six fail silently — the markup is ignored rather than reported.',
    publishedAt: '2026-07-22',
    updatedAt: '2026-09-11',
    author: editorial,
    category: 'Structured data',
    readingMinutes: 6,
    blocks: [
      {
        kind: 'paragraph',
        text: 'Structured data has an unusual failure mode: when it is wrong, nothing happens. There is no console error, no warning in your CMS and often no message in a search console report. The markup is simply disregarded, and the rich result you were expecting never appears.',
      },
      { kind: 'heading', id: 'missing-required', text: '1. Missing required properties' },
      {
        kind: 'paragraph',
        text: 'Every type has properties that are not optional. An Article without datePublished, an Organization without a url, a LocalBusiness without an address — each of these invalidates the node. The property being absent and the property being an empty string fail identically, which catches people who template their markup from a CMS field that is sometimes blank.',
      },
      { kind: 'heading', id: 'dates', text: '2. Dates that are not ISO 8601' },
      {
        kind: 'paragraph',
        text: 'Dates must be ISO 8601: 2026-09-11, or 2026-09-11T10:30:00Z with a time. Locale formats such as 11/09/2026 are ambiguous and are rejected. A related error is a dateModified that falls before datePublished, which usually means two different template variables were wired to the wrong fields.',
      },
      { kind: 'heading', id: 'breadcrumbs', text: '3. Breadcrumb positions out of order' },
      {
        kind: 'paragraph',
        text: 'BreadcrumbList positions must start at 1 and increase by exactly one with no gaps. Starting at 0, or skipping a number because a level was conditionally hidden, invalidates the trail. Generating breadcrumbs from a route registry rather than from the rendered UI avoids this entirely.',
      },
      { kind: 'heading', id: 'faq', text: '4. FAQ entries without a usable answer' },
      {
        kind: 'paragraph',
        text: 'Each entry in an FAQPage must be a Question with a name and an acceptedAnswer object containing text. The common template bug is emitting the acceptedAnswer wrapper but leaving text empty when the answer field is blank, which produces structurally valid JSON that fails validation.',
      },
      { kind: 'heading', id: 'price', text: '5. A price with no currency' },
      {
        kind: 'paragraph',
        text: 'An Offer with a price must declare priceCurrency as an ISO 4217 code. A bare number is meaningless — 29 could be dollars, euros or rupees. If the price genuinely varies, use priceSpecification rather than guessing a figure.',
      },
      { kind: 'heading', id: 'invisible', text: '6. Marking up content that is not on the page' },
      {
        kind: 'paragraph',
        text: 'This is the only one of the six that is a policy violation rather than a technical error. Markup must describe content a visitor can actually see. FAQ markup for questions that appear nowhere on the page, or review markup for reviews you have not collected, risks a manual action.',
      },
      {
        kind: 'callout',
        title: 'Never invent the data',
        text: 'Generate structured data from the same source that renders the page. If a value does not exist in your data, omit the property — an absent property is valid, an invented one is not.',
      },
      { kind: 'heading', id: 'catching-them', text: 'Catching all six before they ship' },
      {
        kind: 'paragraph',
        text: 'All six are mechanically detectable, which means they belong in a check that runs before deployment rather than in a manual review afterwards. The validator on this site checks each of them and reports the exact node path that failed.',
      },
    ],
    faqs: [
      {
        question: 'Why does invalid markup fail silently?',
        answer:
          'Consumers of structured data treat it as an optional enhancement. When a node does not parse or is missing required properties, the safest behaviour is to ignore it rather than to surface an error to the site owner.',
      },
      {
        question: 'Should structured data be validated in CI?',
        answer:
          'Yes, if you generate it programmatically. Validating the generated output as part of your test suite catches a template regression at build time rather than weeks later in a search console report.',
      },
      {
        question: 'Is more structured data always better?',
        answer:
          'No. Publish markup for what the page genuinely contains. Extra types that do not describe the page add no benefit and increase the surface for an error.',
      },
    ],
    related: [
      { label: 'Validate your JSON-LD', href: '/schema-validator' },
      { label: 'What is AEO?', href: '/aeo' },
      { label: 'E-commerce solutions', href: '/solutions/ecommerce' },
    ],
  },

  {
    slug: 'ai-marketing-workflow',
    title: 'Where AI actually helps in a marketing workflow, and where it does not',
    excerpt:
      'A practical split of marketing work into the parts AI genuinely accelerates and the parts where handing over judgement costs you.',
    directAnswer:
      'AI reliably accelerates the parts of marketing work that are structured transformation — turning a brief into an outline, an outline into a draft, or data into commentary. It does not replace judgement about positioning, claims or what is true about your product, and treating it as if it does is how teams publish confident nonsense.',
    publishedAt: '2026-08-14',
    updatedAt: '2026-09-11',
    author: editorial,
    category: 'AI marketing',
    readingMinutes: 6,
    blocks: [
      {
        kind: 'paragraph',
        text: 'The useful question is not whether AI helps with marketing but which specific tasks it improves. Splitting the work by task rather than by role gives a clearer answer than most of the discussion around it.',
      },
      { kind: 'heading', id: 'genuinely-helps', text: 'Where it genuinely helps' },
      {
        kind: 'list',
        items: [
          'Transformation: a brief into an outline, an outline into a draft, a long piece into a summary',
          'Variation: producing several message angles so you can test which one lands',
          'Coverage: finding the questions a topic needs to answer that you have not answered',
          'Commentary: turning a set of numbers into a readable explanation of what changed',
          'Consistency: applying the same voice rules across a large volume of output',
        ],
      },
      {
        kind: 'paragraph',
        text: 'What those tasks share is a verifiable input. The model is reorganising material that already exists, and you can check the output against the source. That is a fundamentally different risk profile from asking it to supply facts.',
      },
      { kind: 'heading', id: 'does-not-help', text: 'Where it does not' },
      {
        kind: 'list',
        items: [
          'Deciding what your product actually does and what it does not',
          'Making claims about performance, customers or results',
          'Judging whether a message is honest as well as persuasive',
          'Anything where being confidently wrong is expensive',
        ],
      },
      {
        kind: 'paragraph',
        text: 'A language model will produce a plausible customer count, a plausible percentage improvement and a plausible testimonial if you let it. None of those are true, and all of them are the kind of claim that damages trust when a prospect checks.',
      },
      {
        kind: 'callout',
        title: 'The rule we build to',
        text: 'AI proposes, a person approves. Anything that publishes externally or asserts a fact about the business passes through a human review step.',
      },
      { kind: 'heading', id: 'context', text: 'Context is what makes the difference' },
      {
        kind: 'paragraph',
        text: 'The gap between a generic AI draft and a useful one is almost entirely context. A model given your positioning, audience, voice rules and existing content produces a draft you edit. The same model given a one-line prompt produces something you rewrite. That is the argument for keeping marketing context in one workspace rather than scattered across tools.',
      },
      {
        kind: 'paragraph',
        text: 'It is also why the review step is cheap rather than burdensome. When the draft already respects your constraints, reviewing it is checking a colleague, not repairing a stranger.',
      },
    ],
    faqs: [
      {
        question: 'Will AI-written content be penalised by search engines?',
        answer:
          'Search guidance focuses on whether content is helpful and original rather than on how it was produced. Low-value content produced at scale is the problem; reviewed, accurate content that serves the reader is not.',
      },
      {
        question: 'How much editing does an AI draft need?',
        answer:
          'It depends almost entirely on the context the model was given. A draft produced against a defined brand voice and a real brief typically needs editing for accuracy and specificity rather than a rewrite.',
      },
      {
        question: 'Should AI-assisted content be disclosed?',
        answer:
          'There is no universal requirement, but authorship and accountability should always be clear. We publish the reviewing author rather than describing the drafting method.',
      },
    ],
    related: [
      { label: 'All features', href: '/features' },
      { label: 'Startup marketing', href: '/solutions/startups' },
      { label: 'Resources', href: '/resources' },
    ],
  },
];

export const postBySlug = new Map(posts.map((p) => [p.slug, p]));

export function getPost(slug: string): Post | undefined {
  return postBySlug.get(slug);
}

export const postsNewestFirst: readonly Post[] = [...posts].sort((a, b) =>
  b.publishedAt.localeCompare(a.publishedAt),
);
