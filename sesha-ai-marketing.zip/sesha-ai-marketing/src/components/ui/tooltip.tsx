'use client';

import { useId, useState, type ReactNode } from 'react';

import { cn } from '@/lib/utils/cn';

/**
 * Tooltip.
 *
 * Hand-built rather than pulled from a primitive library so the dependency
 * list stays at two. Accessibility requirements met here:
 *  - shows on hover AND on keyboard focus, not hover alone;
 *  - dismissible with Escape (WCAG 2.2 "Content on Hover or Focus");
 *  - linked with aria-describedby so the text is announced;
 *  - the trigger is always a real focusable element supplied by the caller.
 *
 * Tooltips carry supplementary information only. Anything essential belongs in
 * visible text.
 */

export interface TooltipProps {
  readonly content: string;
  readonly children: ReactNode;
  readonly side?: 'top' | 'bottom';
  readonly className?: string;
}

export function Tooltip({ content, children, side = 'top', className }: TooltipProps) {
  const id = useId();
  const [open, setOpen] = useState(false);

  return (
    <span
      className={cn('relative inline-flex', className)}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocusCapture={() => setOpen(true)}
      onBlurCapture={() => setOpen(false)}
      onKeyDown={(event) => {
        if (event.key === 'Escape' && open) {
          setOpen(false);
        }
      }}
    >
      <span aria-describedby={open ? id : undefined} className="inline-flex">
        {children}
      </span>
      <span
        id={id}
        role="tooltip"
        hidden={!open}
        className={cn(
          'pointer-events-none absolute left-1/2 z-50 w-max max-w-64 -translate-x-1/2',
          'rounded-control border border-border bg-surface-raised px-2.5 py-1.5',
          'text-xs leading-snug text-fg shadow-md',
          side === 'top' ? 'bottom-full mb-2' : 'top-full mt-2',
        )}
      >
        {content}
      </span>
    </span>
  );
}
