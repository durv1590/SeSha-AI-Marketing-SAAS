import Link from 'next/link';
import type { AnchorHTMLAttributes, ButtonHTMLAttributes, ReactNode } from 'react';

import { tv } from '@/lib/utils/variants';

/**
 * Button / link button.
 *
 * Renders an <a> (via next/link) when `href` is present and a <button>
 * otherwise, because a control that navigates must be a link for keyboard,
 * middle-click and screen-reader behaviour to be correct.
 */

const buttonStyles = tv({
  base: [
    'inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium',
    'rounded-control transition-colors duration-150 ease-out',
    'disabled:pointer-events-none disabled:opacity-55 aria-disabled:pointer-events-none aria-disabled:opacity-55',
  ].join(' '),
  variants: {
    variant: {
      primary: 'bg-primary text-primary-fg shadow-sm hover:bg-primary-hover',
      secondary: 'bg-surface text-fg border border-border-strong shadow-xs hover:bg-bg-muted',
      ghost: 'text-fg hover:bg-bg-muted',
      subtle: 'bg-primary-subtle text-primary-subtle-fg hover:brightness-95',
      danger: 'bg-danger text-white hover:brightness-110',
      link: 'text-primary underline underline-offset-4 hover:text-primary-hover',
    },
    size: {
      sm: 'h-9 px-3.5 text-sm',
      md: 'h-11 px-5 text-sm',
      lg: 'h-12 px-6 text-base',
      icon: 'h-10 w-10 p-0',
    },
    block: {
      true: 'w-full',
      false: '',
    },
  },
  defaultVariants: { variant: 'primary', size: 'md', block: false },
  compoundVariants: [{ variant: 'link', size: 'md', class: 'h-auto px-0' }],
});

type Variant = 'primary' | 'secondary' | 'ghost' | 'subtle' | 'danger' | 'link';
type Size = 'sm' | 'md' | 'lg' | 'icon';

interface CommonProps {
  readonly variant?: Variant;
  readonly size?: Size;
  readonly block?: boolean;
  readonly className?: string;
  readonly children: ReactNode;
}

type ButtonAsButton = CommonProps &
  Omit<ButtonHTMLAttributes<HTMLButtonElement>, keyof CommonProps> & { href?: undefined };

type ButtonAsLink = CommonProps &
  Omit<AnchorHTMLAttributes<HTMLAnchorElement>, keyof CommonProps> & { href: string };

export type ButtonProps = ButtonAsButton | ButtonAsLink;

export function Button(props: ButtonProps) {
  const { variant, size, block, className, children } = props;
  const classes = buttonStyles({ variant, size, block, className });

  if ('href' in props && props.href !== undefined) {
    const { href, variant: _v, size: _s, block: _b, className: _c, children: _ch, ...rest } = props;
    const isExternal = /^https?:\/\//i.test(href);
    if (isExternal) {
      return (
        <a href={href} className={classes} rel="noopener noreferrer" {...rest}>
          {children}
        </a>
      );
    }
    return (
      <Link href={href} className={classes} {...rest}>
        {children}
      </Link>
    );
  }

  const { variant: _v, size: _s, block: _b, className: _c, children: _ch, ...rest } = props;
  return (
    <button className={classes} {...rest}>
      {children}
    </button>
  );
}
