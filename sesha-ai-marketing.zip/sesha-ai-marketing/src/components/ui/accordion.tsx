import type { ReactNode } from 'react';

import { Icon } from './icon';
import { cn } from '@/lib/utils/cn';

/**
 * FAQ accordion built on native <details>/<summary>.
 *
 * This is an AEO decision as much as an accessibility one. A JavaScript
 * accordion that injects its answer on click hides that answer from anything
 * that does not execute scripts. With <details>, the answer is server-rendered
 * into the HTML and merely collapsed by the browser, so it is always readable
 * by crawlers and answer engines — and it works with zero client JavaScript,
 * keyboard support included, for free.
 */

export interface AccordionItem {
  readonly question: string;
  readonly answer: ReactNode;
  readonly id?: string;
}

export interface AccordionProps {
  readonly items: readonly AccordionItem[];
  /** Index of an item to render open. Defaults to the first. */
  readonly defaultOpenIndex?: number | null;
  readonly className?: string;
}

export function Accordion({ items, defaultOpenIndex = 0, className }: AccordionProps) {
  return (
    <div className={cn('divide-y divide-border rounded-card border border-border bg-surface', className)}>
      {items.map((item, index) => (
        <details
          key={item.id ?? item.question}
          id={item.id}
          open={index === defaultOpenIndex}
          className="group"
        >
          <summary
            className={cn(
              'flex w-full cursor-pointer items-center justify-between gap-4 px-5 py-4 text-left',
              'text-base font-medium transition-colors duration-150',
              'hover:bg-bg-subtle',
            )}
          >
            <span className="min-w-0">{item.question}</span>
            <Icon
              name="chevron-down"
              size={18}
              className="shrink-0 text-fg-subtle transition-transform duration-200 ease-out group-open:rotate-180"
            />
          </summary>
          <div className="px-5 pb-5 text-sm leading-relaxed text-fg-muted">{item.answer}</div>
        </details>
      ))}
    </div>
  );
}
