import type {
  InputHTMLAttributes,
  ReactNode,
  SelectHTMLAttributes,
  TextareaHTMLAttributes,
} from 'react';

import { cn } from '@/lib/utils/cn';

/**
 * Form primitives.
 *
 * Accessibility contract, enforced by construction rather than by convention:
 *  - every control has a real <label> bound with htmlFor/id;
 *  - errors are linked via aria-describedby and marked aria-invalid;
 *  - the error text is announced (role="alert");
 *  - required fields are marked with the `required` attribute, not a bare
 *    asterisk, and the asterisk itself is hidden from screen readers.
 */

/**
 * `border-border-strong`, not `border-border`.
 *
 * An input's border is the only thing that says where the input is. WCAG 2.1
 * SC 1.4.11 requires 3:1 for exactly that, and `--border` is a soft rule
 * intended for card edges and table dividers — which the same criterion does
 * NOT cover, because they carry no information about a control.
 *
 * At rest this used `--border`, about 1.2:1 against the surface, so a form was
 * a set of invisible boxes to anyone with low vision. `scripts/contrast-check.mjs`
 * now asserts the strong token clears 3:1 in both themes.
 */
const controlBase = [
  'w-full rounded-control border border-border-strong bg-surface px-3.5 text-sm text-fg',
  'placeholder:text-fg-subtle',
  'transition-colors duration-150',
  'hover:border-fg-muted',
  'disabled:cursor-not-allowed disabled:opacity-60',
  'aria-[invalid=true]:border-danger',
].join(' ');

export interface FieldProps {
  readonly id: string;
  readonly label: string;
  readonly hint?: string;
  readonly error?: string;
  readonly required?: boolean;
  readonly children: (ids: { id: string; describedBy?: string; invalid: boolean }) => ReactNode;
  readonly className?: string;
}

export function Field({ id, label, hint, error, required, children, className }: FieldProps) {
  const hintId = hint ? `${id}-hint` : undefined;
  const errorId = error ? `${id}-error` : undefined;
  const describedBy = [hintId, errorId].filter(Boolean).join(' ') || undefined;

  return (
    <div className={cn('flex flex-col gap-1.5', className)}>
      <label htmlFor={id} className="text-sm font-medium text-fg">
        {label}
        {required ? (
          <span className="ml-0.5 text-danger" aria-hidden="true">
            *
          </span>
        ) : null}
      </label>
      {hint ? (
        <p id={hintId} className="text-xs text-fg-muted">
          {hint}
        </p>
      ) : null}
      {children({ id, describedBy, invalid: Boolean(error) })}
      {error ? (
        <p id={errorId} role="alert" className="text-xs font-medium text-danger">
          {error}
        </p>
      ) : null}
    </div>
  );
}

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return <input className={cn(controlBase, 'h-11', className)} {...props} />;
}

export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={cn(controlBase, 'min-h-32 py-3 leading-relaxed', className)} {...props} />;
}

export function Select({ className, children, ...props }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select className={cn(controlBase, 'h-11 pr-9', className)} {...props}>
      {children}
    </select>
  );
}

export interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  readonly label: ReactNode;
  readonly error?: string;
  readonly id: string;
}

export function Checkbox({ label, error, id, className, ...props }: CheckboxProps) {
  const errorId = error ? `${id}-error` : undefined;
  return (
    <div className={cn('flex flex-col gap-1.5', className)}>
      <div className="flex items-start gap-2.5">
        <input
          id={id}
          type="checkbox"
          aria-invalid={error ? true : undefined}
          aria-describedby={errorId}
          className="mt-0.5 size-4 shrink-0 rounded border-border-strong text-primary accent-primary"
          {...props}
        />
        <label htmlFor={id} className="text-sm leading-relaxed text-fg-muted">
          {label}
        </label>
      </div>
      {error ? (
        <p id={errorId} role="alert" className="text-xs font-medium text-danger">
          {error}
        </p>
      ) : null}
    </div>
  );
}

/** Off-screen honeypot. Hidden from sighted users AND from screen readers. */
export function Honeypot({ name = 'website' }: { readonly name?: string }) {
  return (
    <div aria-hidden="true" className="absolute left-[-9999px] top-0 h-0 w-0 overflow-hidden">
      <label htmlFor={`hp-${name}`}>Leave this field empty</label>
      <input id={`hp-${name}`} name={name} type="text" tabIndex={-1} autoComplete="off" />
    </div>
  );
}
