import type { HTMLAttributes, ReactNode } from 'react';

import { Icon, type UiIconName } from './icon';
import { cn } from '@/lib/utils/cn';

export type AlertTone = 'info' | 'success' | 'warning' | 'danger';

const toneStyles: Record<AlertTone, { wrapper: string; icon: UiIconName; label: string }> = {
  info: { wrapper: 'border-info/30 bg-info-subtle text-fg', icon: 'info', label: 'Note' },
  success: {
    wrapper: 'border-success/30 bg-success-subtle text-fg',
    icon: 'success',
    label: 'Success',
  },
  warning: {
    wrapper: 'border-warning/40 bg-warning-subtle text-fg',
    icon: 'alert',
    label: 'Warning',
  },
  danger: { wrapper: 'border-danger/40 bg-danger-subtle text-fg', icon: 'error', label: 'Error' },
};

export interface AlertProps extends HTMLAttributes<HTMLDivElement> {
  readonly tone?: AlertTone;
  readonly title?: string;
  /**
   * Set for messages that appear in response to a user action, so screen
   * readers announce them. Leave unset for static page content.
   */
  readonly live?: boolean;
  readonly children: ReactNode;
}

export function Alert({ tone = 'info', title, live, className, children, ...props }: AlertProps) {
  const styles = toneStyles[tone];
  return (
    <div
      className={cn('flex gap-3 rounded-card border p-4', styles.wrapper, className)}
      role={live ? 'status' : undefined}
      aria-live={live ? 'polite' : undefined}
      {...props}
    >
      <Icon name={styles.icon} size={20} className="mt-0.5 opacity-80" />
      <div className="min-w-0 text-sm leading-relaxed">
        {title ? <p className="mb-1 font-semibold">{title}</p> : null}
        <div className="[&_a]:underline [&_a]:underline-offset-2">{children}</div>
      </div>
    </div>
  );
}
