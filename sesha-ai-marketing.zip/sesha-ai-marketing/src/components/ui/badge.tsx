import type { HTMLAttributes } from 'react';

import { tv } from '@/lib/utils/variants';

const badgeStyles = tv({
  base: 'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium',
  variants: {
    tone: {
      neutral: 'border-border bg-bg-muted text-fg-muted',
      brand: 'border-transparent bg-primary-subtle text-primary-subtle-fg',
      success: 'border-transparent bg-success-subtle text-success',
      warning: 'border-transparent bg-warning-subtle text-warning',
      danger: 'border-transparent bg-danger-subtle text-danger',
      info: 'border-transparent bg-info-subtle text-info',
      outline: 'border-border-strong bg-transparent text-fg-muted',
    },
  },
  defaultVariants: { tone: 'neutral' },
});

export interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  readonly tone?: 'neutral' | 'brand' | 'success' | 'warning' | 'danger' | 'info' | 'outline';
}

export function Badge({ tone, className, ...props }: BadgeProps) {
  return <span className={badgeStyles({ tone, className })} {...props} />;
}
