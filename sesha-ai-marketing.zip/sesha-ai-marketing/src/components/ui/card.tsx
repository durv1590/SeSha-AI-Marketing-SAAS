import type { HTMLAttributes, ReactNode } from 'react';

import { cn } from '@/lib/utils/cn';

export interface CardProps extends HTMLAttributes<HTMLDivElement> {
  readonly interactive?: boolean;
  readonly tone?: 'default' | 'subtle' | 'outline';
}

export function Card({ className, interactive, tone = 'default', ...props }: CardProps) {
  return (
    <div
      className={cn(
        'rounded-card border border-border',
        tone === 'default' && 'bg-surface shadow-sm',
        tone === 'subtle' && 'bg-bg-subtle',
        tone === 'outline' && 'bg-transparent',
        interactive &&
          'transition-shadow duration-200 ease-out hover:shadow-md focus-within:shadow-md',
        className,
      )}
      {...props}
    />
  );
}

export function CardHeader({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('flex flex-col gap-1.5 p-6 pb-0', className)} {...props} />;
}

export function CardTitle({
  className,
  as: Tag = 'h3',
  ...props
}: HTMLAttributes<HTMLHeadingElement> & { as?: 'h2' | 'h3' | 'h4' }) {
  return <Tag className={cn('text-lg font-semibold tracking-tight', className)} {...props} />;
}

export function CardDescription({ className, ...props }: HTMLAttributes<HTMLParagraphElement>) {
  return <p className={cn('text-sm leading-relaxed text-fg-muted', className)} {...props} />;
}

export function CardContent({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('p-6', className)} {...props} />;
}

export function CardFooter({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('flex items-center gap-3 p-6 pt-0', className)} {...props} />;
}

export function CardIcon({ children }: { readonly children: ReactNode }) {
  return (
    <span className="mb-4 inline-flex size-11 items-center justify-center rounded-control bg-primary-subtle text-primary-subtle-fg">
      {children}
    </span>
  );
}
