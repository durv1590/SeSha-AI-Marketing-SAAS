import type { SVGProps } from 'react';

import type { IconName } from '@/content/modules';
import { cn } from '@/lib/utils/cn';

/**
 * Inline SVG icon set.
 *
 * Hand-drawn rather than pulled from an icon package: it keeps the production
 * dependency list at two, ships only the ~20 glyphs actually used instead of a
 * full library, and avoids the version churn of icon packages.
 *
 * Every icon is decorative by default (`aria-hidden`), because icons here
 * always sit beside a text label. Pass a `title` to make one meaningful, which
 * switches it to `role="img"` with an accessible name.
 */

export type UiIconName =
  | IconName
  // Navigation and interface glyphs that are not one of the marketed modules.
  | 'video'
  | 'arrow-right'
  | 'check'
  | 'chevron-down'
  | 'close'
  | 'external'
  | 'info'
  | 'alert'
  | 'error'
  | 'success'
  | 'menu'
  | 'sun'
  | 'moon'
  | 'copy'
  | 'spark'
  | 'home'
  | 'settings'
  | 'calendar'
  | 'template'
  | 'audit'
  | 'lock'
  | 'mail'
  | 'user'
  | 'logout'
  | 'plus'
  | 'phone'
  | 'google';

export interface IconProps extends Omit<SVGProps<SVGSVGElement>, 'name'> {
  readonly name: UiIconName;
  readonly size?: number;
  /** Providing a title makes the icon meaningful to assistive technology. */
  readonly title?: string;
}

const paths: Record<UiIconName, string> = {
  // Module icons
  copilot: 'M12 3v3m0 12v3m9-9h-3M6 12H3m2.6-6.4 2.1 2.1m8.6 8.6 2.1 2.1m0-12.8-2.1 2.1m-8.6 8.6-2.1 2.1M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z',
  strategy: 'M4 20V10m6 10V4m6 16v-7m-9 7h12M4 6h4M4 14h4',
  content: 'M5 4h9l5 5v11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Zm9 0v5h5M8 13h8M8 17h5',
  search: 'M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16Zm10 2-4.5-4.5',
  answer: 'M4 5h16v11H9l-5 4V5Zm4 4h8M8 12h5',
  schema: 'M12 3 4 7v10l8 4 8-4V7l-8-4Zm0 0v18m8-14-8 4-8-4',
  social: 'M17 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm0 14a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM6 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm2.6-3.6 5.8-3m0 7.2-5.8-3',
  ads: 'M4 9v6h3l6 4V5L7 9H4Zm13-1a5 5 0 0 1 0 8',
  video: 'M4 6h11a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1Zm12 5 5-3v8l-5-3v-2Z',
  leads: 'M16 20v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v1M12.5 7a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM18 8v6m3-3h-6',
  analytics: 'M4 20h16M7 20V11m5 9V6m5 14v-6',
  automation: 'M12 5V3m0 18v-2m7-7h2M3 12h2m11.5-5.5L18 5M6 19l1.5-1.5m9 1.5L18 19M6 5l1.5 1.5M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z',
  competitor: 'M3 20h18M6 20V9m6 11V4m6 16v-8M9.5 6.5 12 4l2.5 2.5',
  reports: 'M6 3h9l4 4v14H6V3Zm9 0v4h4M9 12h6M9 16h6',
  brand: 'M12 3 3 8v8l9 5 9-5V8l-9-5Zm0 5.5L7.5 11v4L12 17.5 16.5 15v-4L12 8.5Z',

  // UI icons
  'arrow-right': 'M5 12h14m-6-6 6 6-6 6',
  check: 'm4 12.5 5 5L20 6.5',
  'chevron-down': 'm6 9 6 6 6-6',
  close: 'M6 6l12 12M18 6 6 18',
  external: 'M14 4h6v6m0-6-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5',
  info: 'M12 21a9 9 0 1 1 0-18 9 9 0 0 1 0 18Zm0-13h.01M11 12h1v5h1',
  alert: 'M12 9v5m0 3h.01M10.3 3.9 2.5 17.4A2 2 0 0 0 4.2 20.4h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z',
  error: 'M12 21a9 9 0 1 1 0-18 9 9 0 0 1 0 18Zm3-12-6 6m0-6 6 6',
  success: 'M12 21a9 9 0 1 1 0-18 9 9 0 0 1 0 18Zm-3.5-9 2.5 2.5 4.5-5',
  menu: 'M4 7h16M4 12h16M4 17h16',
  sun: 'M12 17a5 5 0 1 1 0-10 5 5 0 0 1 0 10Zm0-14v2m0 14v2M5.6 5.6 7 7m10 10 1.4 1.4M3 12h2m14 0h2M5.6 18.4 7 17M17 7l1.4-1.4',
  moon: 'M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z',
  copy: 'M9 9V5a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-4M5 9h9a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1Z',
  spark: 'M12 3.5 13.8 9 19 10.8 13.8 12.6 12 18l-1.8-5.4L5 10.8 10.2 9 12 3.5ZM18.5 15l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7.7-2Z',
  home: 'M4 10.5 12 4l8 6.5V19a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1v-8.5Z',
  settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm7.4-3a7.4 7.4 0 0 0-.1-1.2l2-1.5-2-3.4-2.3 1a7.5 7.5 0 0 0-2-1.2L14.6 3H9.4l-.4 2.7c-.7.3-1.4.7-2 1.2l-2.3-1-2 3.4 2 1.5a7.4 7.4 0 0 0 0 2.4l-2 1.5 2 3.4 2.3-1c.6.5 1.3.9 2 1.2l.4 2.7h5.2l.4-2.7c.7-.3 1.4-.7 2-1.2l2.3 1 2-3.4-2-1.5c.1-.4.1-.8.1-1.2Z',
  calendar: 'M4 8h16M7 3v3m10-3v3M5 6h14a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1Zm3 8h3v3H8v-3Z',
  template: 'M4 5h16v4H4V5Zm0 6h7v8H4v-8Zm9 0h7v8h-7v-8Z',
  audit: 'M9 11.5 11 13.5l4.5-4.5M6 3h9l4 4v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Zm9 0v4h4',
  lock: 'M7 11V8a5 5 0 0 1 10 0v3M6 11h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1Z',
  mail: 'M4 6h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1Zm0 1.5 8 5.5 8-5.5',
  user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-8 8v-1a5 5 0 0 1 5-5h6a5 5 0 0 1 5 5v1',
  logout: 'M15 17v2a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1v2m3 5H9m9 0-3-3m3 3-3 3',
  plus: 'M12 5v14M5 12h14',
  // Handset: the verified phone number on the contact page and in the footer.
  phone: 'M6.5 3h3l1.5 4-2 1.5a12 12 0 0 0 5.5 5.5L16 12l4 1.5v3a2 2 0 0 1-2.2 2A16 16 0 0 1 4.5 5.2 2 2 0 0 1 6.5 3Z',
  // Google "G" simplified to a single stroke path; the button carries the
  // wordmark as text, so this is a decorative mark only.
  google: 'M21 12.2c0-.7-.1-1.3-.2-1.9H12v3.7h5.1a4.4 4.4 0 0 1-1.9 2.9v2.4h3.1c1.8-1.7 2.7-4.1 2.7-7.1ZM12 21c2.4 0 4.5-.8 6-2.2l-3.1-2.4a5.6 5.6 0 0 1-8.3-2.9H3.4v2.5A9 9 0 0 0 12 21Zm-5.4-7.5a5.4 5.4 0 0 1 0-3.4V7.6H3.4a9 9 0 0 0 0 8.1l3.2-2.2ZM12 6.6c1.3 0 2.5.5 3.4 1.4l2.6-2.6A9 9 0 0 0 3.4 7.6l3.2 2.5A5.4 5.4 0 0 1 12 6.6Z',
};

export function Icon({ name, size = 20, title, className, ...props }: IconProps) {
  const accessible = Boolean(title);
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={cn('shrink-0', className)}
      aria-hidden={accessible ? undefined : true}
      role={accessible ? 'img' : undefined}
      focusable="false"
      {...props}
    >
      {accessible ? <title>{title}</title> : null}
      <path d={paths[name]} />
    </svg>
  );
}
