'use client';

import { useCallback, useEffect, useId, useRef, type ReactNode } from 'react';

import { Button } from './button';
import { Icon } from './icon';
import { cn } from '@/lib/utils/cn';

/**
 * Modal dialog built on the native <dialog> element.
 *
 * `showModal()` gives us the behaviour that is hard to get right by hand, for
 * free and correctly: focus is moved into the dialog, focus is trapped while it
 * is open, the rest of the page is marked inert, Escape closes it, and the
 * browser's top layer means no z-index fights.
 *
 * Phase 1 uses this for confirmations and the mobile navigation panel.
 */

export interface ModalProps {
  readonly open: boolean;
  readonly onClose: () => void;
  readonly title: string;
  readonly description?: string;
  readonly children?: ReactNode;
  readonly footer?: ReactNode;
  readonly className?: string;
}

export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  className,
}: ModalProps) {
  const ref = useRef<HTMLDialogElement>(null);
  /**
   * IDs must be unique in a document, and these were the literals
   * `"modal-title"` and `"modal-description"`. Two Modals mounted at once — a
   * confirmation opened from a panel that is itself a dialog, or simply two
   * kept in the tree with only one `open` — produced duplicate ids, at which
   * point `aria-labelledby` resolves to whichever the browser finds first and a
   * screen reader announces the wrong dialog's title.
   */
  const baseId = useId();
  const titleId = `${baseId}-title`;
  const descriptionId = `${baseId}-description`;

  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);

  // The native `close` event fires for Escape too, so state stays in sync.
  const handleClose = useCallback(() => onClose(), [onClose]);

  return (
    <dialog
      ref={ref}
      onClose={handleClose}
      onClick={(event) => {
        // Clicking the backdrop (the dialog element itself) dismisses.
        if (event.target === ref.current) onClose();
      }}
      aria-labelledby={titleId}
      aria-describedby={description ? descriptionId : undefined}
      className={cn(
        'w-[min(32rem,calc(100vw-2rem))] rounded-card border border-border bg-surface p-0 text-fg shadow-lg',
        'backdrop:bg-neutral-950/45 backdrop:backdrop-blur-sm',
        className,
      )}
    >
      <div className="flex items-start justify-between gap-4 p-6 pb-2">
        <div>
          <h2 id={titleId} className="text-lg font-semibold tracking-tight">
            {title}
          </h2>
          {description ? (
            <p id={descriptionId} className="mt-1 text-sm text-fg-muted">
              {description}
            </p>
          ) : null}
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close dialog">
          <Icon name="close" size={18} />
        </Button>
      </div>
      {children ? <div className="px-6 py-2 text-sm leading-relaxed">{children}</div> : null}
      {footer ? <div className="flex justify-end gap-3 p-6 pt-4">{footer}</div> : null}
    </dialog>
  );
}
