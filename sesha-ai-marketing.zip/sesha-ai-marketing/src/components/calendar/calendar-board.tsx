'use client';

import { useCallback, useMemo, useState } from 'react';

import { readCsrfCookie } from '@/components/app/app-shell';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Field, Input, Select, Textarea } from '@/components/ui/field';
import {
  CALENDAR_VIEWS,
  EVENT_KINDS,
  EVENT_LABEL,
  ORIGIN_LABEL,
  STATUS_LABEL,
  VIEW_LABEL,
  datesInRange,
  groupByCampaign,
  type CalendarEvent,
  type CalendarView,
  type EventKind,
  type Suggestion,
} from '@/lib/calendar/types';

/**
 * The marketing calendar.
 *
 * SUGGESTIONS ARE RENDERED SEPARATELY, AND LOOK DIFFERENT
 * They sit in their own panel, marked as suggestions, with the reason SeSha
 * thought of them. A suggestion drawn in the grid beside real entries becomes,
 * within a week, something the user believes they planned — and the calendar
 * stops being a record of decisions.
 *
 * Accepting one is an explicit act, and what it creates is marked
 * "You accepted a suggestion" forever.
 */

export interface CalendarBoardProps {
  readonly projectId: string | null;
  readonly view: CalendarView;
  readonly anchor: string;
  readonly range: { readonly from: string; readonly to: string };
  readonly events: readonly CalendarEvent[];
  readonly suggestions: readonly Suggestion[];
  readonly canEdit: boolean;
}

export function CalendarBoard({
  projectId,
  view,
  anchor,
  range,
  events,
  suggestions,
  canEdit,
}: CalendarBoardProps) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const byDate = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const event of events) {
      const list = map.get(event.date) ?? [];
      list.push(event);
      map.set(event.date, list);
    }
    return map;
  }, [events]);

  const days = useMemo(
    () => (view === 'campaign' ? [] : datesInRange({ from: range.from, to: range.to })),
    [range.from, range.to, view],
  );

  const campaigns = useMemo(() => (view === 'campaign' ? groupByCampaign(events) : []), [events, view]);

  const post = useCallback(
    async (body: Record<string, unknown>) => {
      if (!projectId) return;
      setBusy(true);
      setError(null);
      setMessage(null);
      try {
        const response = await fetch('/api/calendar', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
          body: JSON.stringify({ projectId, ...body }),
        });
        const payload = (await response.json()) as { ok?: boolean; message?: string };
        if (!response.ok) {
          setError(payload.message ?? 'That could not be saved.');
          return;
        }
        setMessage(payload.message ?? 'Added.');
      } catch {
        setError('The request did not complete.');
      } finally {
        setBusy(false);
      }
    },
    [projectId],
  );

  if (!projectId) {
    return (
      <Alert tone="info" title="No project yet">
        Create a project and the calendar has something to plan against.
      </Alert>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <nav aria-label="Calendar views" className="flex flex-wrap gap-2">
        {CALENDAR_VIEWS.map((candidate) => (
          <a
            key={candidate}
            href={`/app/calendar?view=${candidate}&date=${anchor}`}
            className={
              candidate === view
                ? 'rounded-control bg-primary px-3 py-1.5 text-sm font-medium text-primary-fg'
                : 'rounded-control border border-border px-3 py-1.5 text-sm font-medium'
            }
          >
            {VIEW_LABEL[candidate]}
          </a>
        ))}
      </nav>

      {message && <Alert tone="success" live>{message}</Alert>}
      {error && <Alert tone="danger" live>{error}</Alert>}

      {view === 'campaign' ? (
        <section className="flex flex-col gap-4">
          <h2 className="text-lg font-semibold tracking-tight">Campaigns</h2>
          {campaigns.length === 0 && (
            <p className="text-sm text-fg-muted">
              Nothing is grouped into a campaign yet. Add a campaign name to an entry and it appears here.
            </p>
          )}
          {campaigns.map((group) => (
            <Card key={group.campaign ?? 'ungrouped'}>
              <CardHeader>
                <CardTitle as="h3">{group.campaign ?? 'Not part of a campaign'}</CardTitle>
                <CardDescription>{group.events.length} entries</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col gap-2 pt-3">
                {group.events.map((event) => (
                  <EventRow key={event.id} event={event} />
                ))}
              </CardContent>
            </Card>
          ))}
        </section>
      ) : (
        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-semibold tracking-tight">
            {VIEW_LABEL[view]} — {range.from} to {range.to}
          </h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-7">
            {days.map((date) => {
              const dayEvents = byDate.get(date) ?? [];
              return (
                <Card key={date} tone={dayEvents.length === 0 ? 'subtle' : 'default'}>
                  <CardHeader className="pb-2">
                    <CardTitle as="h3" className="text-sm">
                      {date}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex flex-col gap-2 p-4 pt-2">
                    {dayEvents.length === 0 ? (
                      <p className="text-xs text-fg-muted">Nothing planned.</p>
                    ) : (
                      dayEvents.map((event) => <EventRow key={event.id} event={event} compact />)
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>
      )}

      {suggestions.length > 0 && (
        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-semibold tracking-tight">Suggestions</h2>
          <p className="max-w-3xl text-sm leading-relaxed text-fg-muted">
            These are not on your calendar. Each one comes from something SeSha actually knows about
            you — an open finding, or a channel you said you use. Accept one and it becomes a planned
            entry, recorded as a suggestion you accepted.
          </p>
          <div className="grid gap-3 sm:grid-cols-2">
            {suggestions.map((suggestion) => (
              <Card key={`${suggestion.date}-${suggestion.title}`} tone="outline">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Badge tone="warning">Suggestion</Badge>
                    <Badge tone="neutral">{suggestion.date}</Badge>
                  </div>
                  <CardTitle as="h3" className="text-base">
                    {suggestion.title}
                  </CardTitle>
                  <CardDescription>{suggestion.why}</CardDescription>
                </CardHeader>
                <CardContent className="pt-3">
                  <ul className="flex flex-col gap-1 text-xs text-fg-muted">
                    {suggestion.basedOn.map((basis) => (
                      <li key={basis}>{basis}</li>
                    ))}
                  </ul>
                  {canEdit && (
                    <Button
                      className="mt-3"
                      size="sm"
                      disabled={busy}
                      onClick={() =>
                        void post({
                          kind: suggestion.kind,
                          title: suggestion.title,
                          date: suggestion.date,
                          notes: suggestion.why,
                          fromSuggestion: true,
                        })
                      }
                    >
                      Add to the calendar
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      {canEdit && <AddEntry busy={busy} onAdd={post} />}
    </div>
  );
}

function EventRow({ event, compact }: { readonly event: CalendarEvent; readonly compact?: boolean }) {
  return (
    <div className="flex flex-col gap-1">
      <div className="flex flex-wrap items-center gap-1.5">
        <Badge tone="info">{EVENT_LABEL[event.kind]}</Badge>
        <Badge tone={event.status === 'done' ? 'success' : event.status === 'skipped' ? 'neutral' : 'outline'}>
          {STATUS_LABEL[event.status]}
        </Badge>
      </div>
      <p className={compact ? 'text-xs font-medium' : 'text-sm font-medium'}>{event.title}</p>
      {!compact && event.notes && <p className="text-sm text-fg-muted">{event.notes}</p>}
      <p className="text-xs text-fg-muted">{ORIGIN_LABEL[event.origin]}</p>
    </div>
  );
}

function AddEntry({
  busy,
  onAdd,
}: {
  readonly busy: boolean;
  readonly onAdd: (body: Record<string, unknown>) => Promise<void>;
}) {
  const [kind, setKind] = useState<EventKind>('social');
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [notes, setNotes] = useState('');
  const [campaign, setCampaign] = useState('');

  return (
    <Card>
      <CardHeader>
        <CardTitle as="h2">Add an entry</CardTitle>
        <CardDescription>
          A calendar entry is a plan, not a schedule. Nothing is published or sent on the date —
          SeSha cannot publish or send.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4 pt-4">
        <Field label="What kind of activity" id="calendar-kind">
          {({ id }) => (
            <Select id={id} value={kind} onChange={(event) => setKind(event.target.value as EventKind)}>
              {EVENT_KINDS.map((candidate) => (
                <option key={candidate} value={candidate}>
                  {EVENT_LABEL[candidate]}
                </option>
              ))}
            </Select>
          )}
        </Field>
        <Field label="Title" id="calendar-title">
          {({ id }) => (
            <Input id={id} value={title} onChange={(event) => setTitle(event.target.value)} />
          )}
        </Field>
        <Field label="Date" id="calendar-date" hint="YYYY-MM-DD">
          {({ id }) => (
            <Input id={id} type="date" value={date} onChange={(event) => setDate(event.target.value)} />
          )}
        </Field>
        <Field label="Campaign (optional)" id="calendar-campaign">
          {({ id }) => (
            <Input id={id} value={campaign} onChange={(event) => setCampaign(event.target.value)} />
          )}
        </Field>
        <Field label="Notes (optional)" id="calendar-notes">
          {({ id }) => (
            <Textarea id={id} rows={3} value={notes} onChange={(event) => setNotes(event.target.value)} />
          )}
        </Field>
        <div>
          <Button
            disabled={busy || title.trim().length === 0 || date.length === 0}
            onClick={() =>
              void onAdd({
                kind,
                title,
                date,
                notes,
                ...(campaign.trim().length > 0 ? { campaign } : {}),
              })
            }
          >
            Add
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
