'use client';

import { useCallback, useState } from 'react';

import { readCsrfCookie } from '@/components/app/app-shell';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox, Field, Input } from '@/components/ui/field';
import {
  DIMENSION_LABEL,
  EVIDENCE_LABEL,
  EVIDENCE_MEANING,
  type CompetitorDimension,
} from '@/lib/competitors/types';

/**
 * Competitor intelligence, as the user sees it.
 *
 * TWO RULES THIS COMPONENT ENFORCES VISUALLY
 *
 * 1. A verified finding and an inference never look the same. They carry different
 *    badges, and a verified finding shows the URL it was read from with the time.
 *    A reader who cannot tell the two apart at a glance has been handed
 *    speculation about another business as though it were research.
 *
 * 2. The acknowledgement is shown IN FULL before it can be accepted, and the
 *    "Analyse" button is disabled until it is. A checkbox labelled "I agree" with
 *    the terms one click away is not informed consent.
 */

export interface CompetitorView {
  readonly id: string;
  readonly name: string;
  readonly websiteUrl: string | null;
  readonly source: string;
  readonly notes: string;
  readonly acknowledged: boolean;
  readonly lastAnalysedAt: string | null;
  readonly verifiedCount: number;
  readonly inferredCount: number;
}

export interface FindingView {
  readonly dimension: CompetitorDimension;
  readonly statement: string;
  readonly evidence:
    | { readonly kind: 'verified_public'; readonly sourceUrl: string; readonly observedAt: string; readonly quote?: string }
    | { readonly kind: 'ai_inference'; readonly basedOn: readonly string[] };
  readonly confidence: 'high' | 'medium' | 'low';
}

export interface AnalysisView {
  readonly id: string;
  readonly analysedAt: string;
  readonly findings: readonly FindingView[];
  readonly pagesRead: readonly { readonly url: string; readonly readAt: string }[];
  readonly limitations: readonly { readonly code: string; readonly detail: string }[];
  readonly notCovered: readonly { readonly dimension: CompetitorDimension; readonly why: string }[];
  readonly verifiedCount: number;
  readonly inferredCount: number;
}

export interface CompetitorPanelProps {
  readonly projectId: string | null;
  readonly competitors: readonly CompetitorView[];
  readonly policy: {
    readonly maxPages: number;
    readonly storesPageContent: boolean;
    readonly acknowledgement: string;
  };
  readonly canEdit: boolean;
}

export function CompetitorPanel({
  projectId,
  competitors,
  policy,
  canEdit,
}: CompetitorPanelProps) {
  const [rows, setRows] = useState<readonly CompetitorView[]>(competitors);
  const [name, setName] = useState('');
  const [website, setWebsite] = useState('');
  const [accepted, setAccepted] = useState<Record<string, boolean>>({});
  const [analysis, setAnalysis] = useState<AnalysisView | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const add = useCallback(async () => {
    if (!projectId || name.trim().length === 0) return;
    setBusy(true);
    setError(null);
    try {
      const response = await fetch('/api/competitors', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-csrf-token': readCsrfCookie() },
        body: JSON.stringify({ projectId, name, ...(website.trim() ? { websiteUrl: website } : {}) }),
      });
      const payload = (await response.json()) as { data?: { id: string }; message?: string };
      if (!response.ok || !payload.data) {
        setError(payload.message ?? 'That could not be added.');
        return;
      }
      setRows([
        ...rows,
        {
          id: payload.data.id,
          name: name.trim(),
          websiteUrl: website.trim() || null,
          source: 'user_added',
          notes: '',
          acknowledged: false,
          lastAnalysedAt: null,
          verifiedCount: 0,
          inferredCount: 0,
        },
      ]);
      setName('');
      setWebsite('');
    } catch {
      setError('The request could not be completed.');
    } finally {
      setBusy(false);
    }
  }, [name, projectId, rows, website]);

  const act = useCallback(
    async (id: string, action: 'acknowledge' | 'withdraw' | 'analyse') => {
      setBusy(true);
      setError(null);
      try {
        const response = await fetch(`/api/competitors/${id}`, {
          method: 'PATCH',
          headers: { 'content-type': 'application/json', 'x-csrf-token': readCsrfCookie() },
          body: JSON.stringify({
            action,
            ...(action === 'acknowledge' ? { accepted: accepted[id] === true } : {}),
          }),
        });
        const payload = (await response.json()) as {
          data?: { acknowledged?: boolean; analysis?: AnalysisView; id?: string };
          message?: string;
        };
        if (!response.ok) {
          setError(payload.message ?? 'That could not be done.');
          return;
        }
        if (action === 'analyse' && payload.data?.analysis) {
          setAnalysis({ ...payload.data.analysis, id: payload.data.id ?? '' });
          setOpenId(id);
          setRows(
            rows.map((row) =>
              row.id === id
                ? {
                    ...row,
                    lastAnalysedAt: payload.data!.analysis!.analysedAt,
                    verifiedCount: payload.data!.analysis!.verifiedCount,
                    inferredCount: payload.data!.analysis!.inferredCount,
                  }
                : row,
            ),
          );
          return;
        }
        setRows(
          rows.map((row) =>
            row.id === id ? { ...row, acknowledged: action === 'acknowledge' } : row,
          ),
        );
      } catch {
        setError('The request could not be completed.');
      } finally {
        setBusy(false);
      }
    },
    [accepted, rows],
  );

  if (!projectId) {
    return (
      <Alert tone="info" title="No project yet">
        Create a project and the competitors captured during onboarding appear here.
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <Alert tone="info" title="What this reads, and what it does not">
        <p>
          SeSha reads at most {policy.maxPages} publicly available pages per competitor, obeys
          their robots.txt, and{' '}
          {policy.storesPageContent ? 'stores what it read' : 'does not store their page content'}.
        </p>
        <p className="mt-2">
          Spend, traffic, revenue, customer counts and engagement are not observable from outside, so
          they are never shown and never estimated. Anything SeSha concludes rather than reads is
          labelled an inference.
        </p>
      </Alert>

      {canEdit ? (
        <Card>
          <CardHeader>
            <CardTitle as="h2" className="text-base">Add a competitor</CardTitle>
          </CardHeader>
          <div className="grid gap-4 border-t border-border p-5 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
            <Field id="competitor-panel-name" label="Name">
              {({ id }) => (
                <Input id={id} value={name} onChange={(event) => setName(event.target.value)} />
              )}
            </Field>
            <Field id="competitor-panel-website" label="Website" hint="Optional, but nothing can be read without it.">
              {({ id }) => (
                <Input id={id}
                  value={website}
                  onChange={(event) => setWebsite(event.target.value)}
                  placeholder="https://"
                  inputMode="url"
                />
              )}
            </Field>
            <Button type="button" onClick={add} disabled={busy || name.trim().length === 0}>
              Add
            </Button>
          </div>
        </Card>
      ) : null}

      {error ? (
        <Alert tone="danger" title="That did not work" live>
          {error}
        </Alert>
      ) : null}

      {rows.length === 0 ? (
        <Card tone="subtle">
          <div className="p-5 text-sm text-fg-muted">
            No competitors yet. Add one above, or add them during onboarding.
          </div>
        </Card>
      ) : (
        <ul className="space-y-4">
          {rows.map((competitor) => (
            <li key={competitor.id}>
              <Card>
                <CardHeader>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <CardTitle as="h2" className="text-base">{competitor.name}</CardTitle>
                    <div className="flex items-center gap-2">
                      {competitor.acknowledged ? (
                        <Badge tone="success">Research authorised</Badge>
                      ) : (
                        <Badge tone="outline">Not authorised</Badge>
                      )}
                      {competitor.lastAnalysedAt ? (
                        <Badge tone="info">
                          {competitor.verifiedCount} verified · {competitor.inferredCount} inferred
                        </Badge>
                      ) : null}
                    </div>
                  </div>
                  <CardDescription>
                    {competitor.websiteUrl ?? 'No website recorded, so nothing can be read.'}
                  </CardDescription>
                </CardHeader>

                <div className="space-y-4 border-t border-border p-5">
                  {!competitor.acknowledged ? (
                    <div className="space-y-3">
                      {/* The full wording, shown before the checkbox — not behind a link. */}
                      <p className="rounded-card bg-bg-subtle p-4 text-sm leading-relaxed text-fg-muted">
                        {policy.acknowledgement}
                      </p>
                      <Checkbox
                        // Unique per competitor, and REQUIRED: `Checkbox` uses
                        // this for both the input's id and the label's htmlFor.
                        // Without it the label was bound to nothing, which on a
                        // legal acknowledgement is the worst possible control to
                        // leave unlabelled for a screen-reader user.
                        id={`competitor-consent-${competitor.id}`}
                        label="I have read the above and I am asking SeSha to read these public pages."
                        checked={accepted[competitor.id] === true}
                        onChange={(event) =>
                          setAccepted({ ...accepted, [competitor.id]: event.target.checked })
                        }
                        disabled={!canEdit}
                      />
                      <Button
                        type="button"
                        onClick={() => act(competitor.id, 'acknowledge')}
                        disabled={busy || !canEdit || accepted[competitor.id] !== true}
                      >
                        Authorise research
                      </Button>
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      <Button
                        type="button"
                        onClick={() => act(competitor.id, 'analyse')}
                        disabled={busy || !canEdit || !competitor.websiteUrl}
                      >
                        {busy ? 'Reading…' : 'Analyse public pages'}
                      </Button>
                      <Button
                        type="button"
                        variant="secondary"
                        onClick={() => act(competitor.id, 'withdraw')}
                        disabled={busy || !canEdit}
                      >
                        Withdraw authorisation
                      </Button>
                    </div>
                  )}

                  {openId === competitor.id && analysis ? (
                    <AnalysisDetail analysis={analysis} />
                  ) : null}
                </div>
              </Card>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function AnalysisDetail({ analysis }: { readonly analysis: AnalysisView }) {
  const verified = analysis.findings.filter((finding) => finding.evidence.kind === 'verified_public');
  const inferred = analysis.findings.filter((finding) => finding.evidence.kind === 'ai_inference');

  return (
    <div className="space-y-5 border-t border-border pt-5">
      <div className="grid gap-4 lg:grid-cols-2">
        <FindingGroup
          title={EVIDENCE_LABEL.verified_public}
          meaning={EVIDENCE_MEANING.verified_public}
          tone="success"
          findings={verified}
        />
        <FindingGroup
          title={EVIDENCE_LABEL.ai_inference}
          meaning={EVIDENCE_MEANING.ai_inference}
          tone="warning"
          findings={inferred}
        />
      </div>

      {analysis.pagesRead.length > 0 ? (
        <div className="text-sm">
          <h4 className="font-medium">Pages read</h4>
          <ul className="mt-1 space-y-1 text-fg-muted">
            {analysis.pagesRead.map((page) => (
              <li key={page.url}>
                {page.url} — <time dateTime={page.readAt}>{page.readAt.slice(0, 16).replace('T', ' ')}</time>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {analysis.limitations.length > 0 ? (
        <Alert tone="info" title="Limits of this analysis">
          <ul className="ml-4 list-disc space-y-1">
            {analysis.limitations.map((limitation) => (
              <li key={limitation.code}>{limitation.detail}</li>
            ))}
          </ul>
        </Alert>
      ) : null}

      {analysis.notCovered.length > 0 ? (
        <div className="text-sm">
          <h4 className="font-medium">Nothing found for</h4>
          <ul className="mt-1 space-y-1 text-fg-muted">
            {analysis.notCovered.map((entry) => (
              <li key={entry.dimension}>
                <span className="font-medium">{DIMENSION_LABEL[entry.dimension]}: </span>
                {entry.why}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}

function FindingGroup({
  title,
  meaning,
  tone,
  findings,
}: {
  readonly title: string;
  readonly meaning: string;
  readonly tone: 'success' | 'warning';
  readonly findings: readonly FindingView[];
}) {
  return (
    <Card tone="outline">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Badge tone={tone}>{title}</Badge>
          <span className="text-xs text-fg-muted">{findings.length}</span>
        </div>
        <CardDescription>{meaning}</CardDescription>
      </CardHeader>
      {findings.length === 0 ? (
        <p className="border-t border-border px-5 py-4 text-sm text-fg-muted">Nothing here.</p>
      ) : (
        <ul className="divide-y divide-border border-t border-border">
          {findings.map((finding, index) => (
            <li key={index} className="px-5 py-4 text-sm">
              <div className="flex flex-wrap items-center gap-2">
                <Badge tone="outline">{DIMENSION_LABEL[finding.dimension]}</Badge>
                <span className="text-xs text-fg-muted">confidence: {finding.confidence}</span>
              </div>
              <p className="mt-2 leading-relaxed">{finding.statement}</p>
              {finding.evidence.kind === 'verified_public' ? (
                <p className="mt-2 text-xs text-fg-muted">
                  Read from {finding.evidence.sourceUrl} at{' '}
                  <time dateTime={finding.evidence.observedAt}>
                    {finding.evidence.observedAt.slice(0, 16).replace('T', ' ')}
                  </time>
                </p>
              ) : (
                <p className="mt-2 text-xs text-fg-muted">
                  Drawn from: {finding.evidence.basedOn.join('; ')}
                </p>
              )}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
