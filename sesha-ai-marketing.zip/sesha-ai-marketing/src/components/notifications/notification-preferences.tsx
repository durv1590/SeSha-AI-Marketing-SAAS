'use client';

import { useCallback, useState } from 'react';

import { readCsrfCookie } from '@/components/app/app-shell';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

/**
 * Notification preferences.
 *
 * A LOCKED ROW SHOWS THE REASON, NOT JUST A GREYED-OUT SWITCH
 * Security and billing notices cannot be switched off. A disabled toggle with no
 * explanation reads as a bug or as contempt; the sentence beside it says why,
 * and the reason is a good one.
 *
 * The email column is SHOWN AND DISABLED rather than hidden, with the reason.
 * A customer deciding whether this product is worth paying for should be able to
 * see what is not built yet.
 */

export interface PreferenceRowView {
  readonly kind: string;
  readonly label: string;
  readonly description: string;
  readonly inApp: boolean;
  readonly email: boolean;
  readonly locked: boolean;
  readonly lockedReason: string | null;
}

export interface ChannelView {
  readonly id: string;
  readonly label: string;
  readonly available: boolean;
  readonly unavailableReason: string | null;
}

export interface NotificationPreferencesProps {
  readonly preferences: readonly PreferenceRowView[];
  readonly channels: readonly ChannelView[];
}

export function NotificationPreferences({ preferences, channels }: NotificationPreferencesProps) {
  const [rows, setRows] = useState(preferences);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const unavailableChannels = channels.filter((channel) => !channel.available);

  const toggle = useCallback(
    async (kind: string, inApp: boolean) => {
      setBusy(true);
      setError(null);
      setMessage(null);
      try {
        const response = await fetch('/api/notifications/preferences', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
          body: JSON.stringify({ preferences: [{ kind, inApp }] }),
        });
        const payload = (await response.json()) as { message?: string };
        if (!response.ok) {
          // The server refuses rather than silently ignoring, so the switch goes
          // back to where it was and the reason is shown.
          setError(payload.message ?? 'That setting could not be saved.');
          return;
        }
        setRows((current) =>
          current.map((row) => (row.kind === kind ? { ...row, inApp } : row)),
        );
        setMessage('Saved.');
      } catch {
        setError('The request did not complete.');
      } finally {
        setBusy(false);
      }
    },
    [],
  );

  return (
    <div className="flex flex-col gap-6">
      {message && <Alert tone="success" live>{message}</Alert>}
      {error && <Alert tone="danger" live>{error}</Alert>}

      {unavailableChannels.map((channel) => (
        <Alert key={channel.id} tone="info" title={`${channel.label} is not available`}>
          {channel.unavailableReason}
        </Alert>
      ))}

      <div className="flex flex-col gap-3">
        {rows.map((row) => (
          <Card key={row.kind} tone={row.locked ? 'subtle' : 'default'}>
            <CardHeader>
              <div className="flex flex-wrap items-center gap-2">
                <CardTitle as="h3" className="text-base">
                  {row.label}
                </CardTitle>
                {row.locked && <Badge tone="warning">Always on</Badge>}
              </div>
              <CardDescription>{row.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-3 pt-3">
              {row.locked ? (
                <p className="text-sm leading-relaxed text-fg-muted">{row.lockedReason}</p>
              ) : (
                <div className="flex items-center gap-3">
                  <Button
                    size="sm"
                    variant={row.inApp ? 'secondary' : 'primary'}
                    disabled={busy}
                    onClick={() => void toggle(row.kind, !row.inApp)}
                    aria-pressed={row.inApp}
                  >
                    {row.inApp ? 'Switch off' : 'Switch on'}
                  </Button>
                  <span className="text-sm text-fg-muted">
                    {row.inApp ? 'You are told inside SeSha.' : 'You are not told about this.'}
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
