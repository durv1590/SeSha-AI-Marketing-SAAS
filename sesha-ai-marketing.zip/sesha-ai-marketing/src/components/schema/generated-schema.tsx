import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  GENERATED_KIND_LABEL,
  VALUE_SOURCE_LABEL,
  type GeneratedSchema,
} from '@/lib/schema/generate';

/**
 * Generated JSON-LD, with the provenance of every value.
 *
 * THREE LISTS, NOT ONE
 * Included (and where each value came from), omitted (and what to fill in), and
 * refused (and why it will never be filled in). A generator that showed only the
 * output would be indistinguishable from one that invented the gaps.
 *
 * The generator runs its own output through the validator, and that result is
 * shown here too: markup this product generates should pass the validator this
 * product ships, and if it does not, the user is entitled to see that.
 */
export interface GeneratedSchemaProps {
  readonly generated: GeneratedSchema;
}

export function GeneratedSchemaView({ generated }: GeneratedSchemaProps) {
  const invalid = generated.validation.counts.INVALID;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle as="h2" className="text-base">
            {GENERATED_KIND_LABEL[generated.kind]} markup, built from your own data
          </CardTitle>
          <CardDescription>
            Every value below came from a field you filled in or a page that was crawled. Nothing was
            inferred.
          </CardDescription>
        </CardHeader>
        <div className="border-t border-border p-4">
          <pre className="overflow-x-auto rounded bg-bg-muted p-3 text-xs leading-relaxed">
            <code>{generated.jsonLd}</code>
          </pre>
        </div>
      </Card>

      {invalid > 0 ? (
        <Alert tone="danger" title="This generated markup does not pass our own validator">
          That is a defect in SeSha, not in your data. {invalid} error
          {invalid === 1 ? '' : 's'} were found in what was just generated — please report it.
        </Alert>
      ) : (
        <Alert tone="success" title="Checked against our own validator">
          The markup above was validated with the same engine as the checker on this page, and it
          passes.
        </Alert>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle as="h2" className="text-base">Included</CardTitle>
            <CardDescription>{generated.included.length} value(s), with the source.</CardDescription>
          </CardHeader>
          <ul className="divide-y divide-border border-t border-border text-sm">
            {generated.included.map((value, index) => (
              <li key={`${value.property}-${index}`} className="px-4 py-3">
                <code className="text-xs">{value.property}</code>
                <p className="mt-1 text-xs text-fg-muted">
                  {VALUE_SOURCE_LABEL[value.source]} — {value.from}
                </p>
              </li>
            ))}
            {generated.included.length === 0 ? (
              <li className="px-4 py-3 text-fg-muted">Nothing could be filled in yet.</li>
            ) : null}
          </ul>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle as="h2" className="text-base">Missing</CardTitle>
            <CardDescription>Add these in the workspace and they appear here.</CardDescription>
          </CardHeader>
          <ul className="divide-y divide-border border-t border-border text-sm">
            {generated.omitted.map((value, index) => (
              <li key={`${value.property}-${index}`} className="px-4 py-3">
                <code className="text-xs">{value.property}</code>
                <p className="mt-1 text-xs text-fg-muted">{value.why}</p>
              </li>
            ))}
            {generated.omitted.length === 0 ? (
              <li className="px-4 py-3 text-fg-muted">Nothing missing.</li>
            ) : null}
          </ul>
        </Card>

        <Card tone="subtle">
          <CardHeader>
            <CardTitle as="h2" className="text-base">Never generated</CardTitle>
            <CardDescription>
              These must come from your own records, published exactly as they are.
            </CardDescription>
          </CardHeader>
          <ul className="divide-y divide-border border-t border-border text-sm">
            {generated.refused.map((value) => (
              <li key={value.property} className="px-4 py-3">
                <Badge tone="outline">{value.property}</Badge>
                <p className="mt-1 text-xs text-fg-muted">{value.why}</p>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}
