'use client';

import { useCallback, useState } from 'react';

import { readCsrfCookie } from '@/components/app/app-shell';
import { CorrectionView } from '@/components/schema/correction-view';
import { GeneratedSchemaView } from '@/components/schema/generated-schema';
import { ValidationReport } from '@/components/schema/validation-report';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Field, Select, Textarea } from '@/components/ui/field';
import type { Correction, ValidationResult } from '@/lib/schema-validator';
import { GENERATED_KINDS, GENERATED_KIND_LABEL, type GeneratedSchema } from '@/lib/schema/generate';

/**
 * The workspace validator: check, correct, generate, and compare with last time.
 *
 * WHY THE HISTORY IS ON THE SAME SCREEN
 * A validator is used twice: once to find out what is wrong, and then again after
 * a fix. The second visit is the one that matters, and it is worthless without the
 * first result to compare against. So the comparison appears automatically when a
 * previous run for the same source exists, and it says when the validator's own
 * version changed — because that difference is ours, not the user's.
 */

export interface HistoryEntry {
  readonly id: string;
  readonly checkedAt: string;
  readonly sourceKind: string;
  readonly sourceUrl: string | null;
  readonly validatorVersion: string;
  readonly overallStatus: string;
  readonly counts: Readonly<Record<string, number>>;
  readonly typesFound: readonly string[];
}

export interface Comparison {
  readonly fixed: readonly { readonly explanation: string }[];
  readonly introduced: readonly { readonly explanation: string }[];
  readonly unchanged: number;
  readonly versionChanged: boolean;
  readonly summary: string;
}

export interface ValidatorWorkspaceProps {
  readonly projectId: string | null;
  readonly crawledPages: readonly string[];
  readonly history: readonly HistoryEntry[];
  readonly canUse: boolean;
}

type Mode = 'paste' | 'page' | 'generate';

export function ValidatorWorkspace({
  projectId,
  crawledPages,
  history,
  canUse,
}: ValidatorWorkspaceProps) {
  const [mode, setMode] = useState<Mode>('paste');
  const [source, setSource] = useState('');
  const [pageUrl, setPageUrl] = useState(crawledPages[0] ?? '');
  const [generateKind, setGenerateKind] = useState<string>('organization');

  const [result, setResult] = useState<ValidationResult | null>(null);
  const [correction, setCorrection] = useState<Correction | null>(null);
  const [comparison, setComparison] = useState<Comparison | null>(null);
  const [generated, setGenerated] = useState<GeneratedSchema | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const run = useCallback(async () => {
    if (!projectId) return;
    setBusy(true);
    setError(null);
    setResult(null);
    setCorrection(null);
    setComparison(null);
    setGenerated(null);

    try {
      if (mode === 'generate') {
        const response = await fetch('/api/schema/generate', {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-csrf-token': readCsrfCookie() },
          body: JSON.stringify({ projectId, kind: generateKind, ...(pageUrl ? { pageUrl } : {}) }),
        });
        const payload = (await response.json()) as {
          data?: GeneratedSchema;
          message?: string;
        };
        if (!response.ok || !payload.data) {
          setError(payload.message ?? 'That could not be generated.');
          return;
        }
        setGenerated(payload.data);
        return;
      }

      const response = await fetch('/api/schema/validate', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-csrf-token': readCsrfCookie() },
        body: JSON.stringify(
          mode === 'paste'
            ? { projectId, sourceKind: 'pasted', source }
            : { projectId, sourceKind: 'page_url', url: pageUrl },
        ),
      });
      const payload = (await response.json()) as {
        data?: { result: ValidationResult; correction: Correction; comparison?: Comparison };
        message?: string;
      };
      if (!response.ok || !payload.data) {
        setError(payload.message ?? 'That could not be checked.');
        return;
      }
      setResult(payload.data.result);
      setCorrection(payload.data.correction);
      setComparison(payload.data.comparison ?? null);
    } catch {
      setError('The request could not be completed. Check your connection and try again.');
    } finally {
      setBusy(false);
    }
  }, [generateKind, mode, pageUrl, projectId, source]);

  if (!projectId) {
    return (
      <Alert tone="info" title="No project yet">
        Create a project to keep a validation history. The free tool on the public site checks markup
        without storing anything.
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle as="h2" className="text-base">What would you like to do?</CardTitle>
          <CardDescription>
            Checking a crawled page runs more checks than pasted markup: the canonical URL is known,
            so the markup can be checked against it.
          </CardDescription>
        </CardHeader>

        <div className="space-y-4 border-t border-border p-5">
          <div className="flex flex-wrap gap-2" role="group" aria-label="Mode">
            <Button
              type="button"
              variant={mode === 'paste' ? 'primary' : 'secondary'}
              onClick={() => setMode('paste')}
            >
              Check pasted markup
            </Button>
            <Button
              type="button"
              variant={mode === 'page' ? 'primary' : 'secondary'}
              onClick={() => setMode('page')}
              disabled={crawledPages.length === 0}
            >
              Check a crawled page
            </Button>
            <Button
              type="button"
              variant={mode === 'generate' ? 'primary' : 'secondary'}
              onClick={() => setMode('generate')}
            >
              Generate markup
            </Button>
          </div>

          {mode === 'page' && crawledPages.length === 0 ? (
            <Alert tone="info">
              No crawl has run for this project yet, so there is no stored page to check. Run a crawl
              from Website Audit first.
            </Alert>
          ) : null}

          {mode === 'paste' ? (
            <Field id="validator-workspace-json-ld-or-the-html-of-a-page"
              label="JSON-LD, or the HTML of a page"
              hint="Microdata and RDFa are read too. Nothing is fetched: only what you paste is checked."
            >
              {({ id }) => (
                <Textarea id={id}
                  value={source}
                  onChange={(event) => setSource(event.target.value)}
                  rows={10}
                  spellCheck={false}
                  placeholder='{"@context":"https://schema.org","@type":"LocalBusiness", …}'
                />
              )}
            </Field>
          ) : null}

          {mode === 'page' && crawledPages.length > 0 ? (
            <Field id="validator-workspace-page" label="Page" hint="From the most recent crawl of your site.">
              {({ id }) => (
                <Select id={id} value={pageUrl} onChange={(event) => setPageUrl(event.target.value)}>
                  {crawledPages.map((url) => (
                    <option key={url} value={url}>
                      {url}
                    </option>
                  ))}
                </Select>
              )}
            </Field>
          ) : null}

          {mode === 'generate' ? (
            <div className="grid gap-4 sm:grid-cols-2">
              <Field id="validator-workspace-what-to-generate" label="What to generate">
                {({ id }) => (
                  <Select id={id}
                    value={generateKind}
                    onChange={(event) => setGenerateKind(event.target.value)}
                  >
                    {GENERATED_KINDS.map((kind) => (
                      <option key={kind} value={kind}>
                        {GENERATED_KIND_LABEL[kind]}
                      </option>
                    ))}
                  </Select>
                )}
              </Field>
              {crawledPages.length > 0 ? (
                <Field id="validator-workspace-page-for-page-level-markup" label="Page (for page-level markup)" hint="Optional.">
                  {({ id }) => (
                    <Select id={id} value={pageUrl} onChange={(event) => setPageUrl(event.target.value)}>
                      <option value="">Not page-specific</option>
                      {crawledPages.map((url) => (
                        <option key={url} value={url}>
                          {url}
                        </option>
                      ))}
                    </Select>
                  )}
                </Field>
              ) : null}
            </div>
          ) : null}

          <Button
            type="button"
            onClick={run}
            disabled={
              busy ||
              !canUse ||
              (mode === 'paste' && source.trim().length === 0) ||
              (mode === 'page' && pageUrl.length === 0)
            }
          >
            {busy ? 'Working…' : mode === 'generate' ? 'Generate' : 'Check'}
          </Button>

          {!canUse ? (
            <p className="text-sm text-fg-muted">
              Your role can read results but not run a check.
            </p>
          ) : null}
        </div>
      </Card>

      {error ? (
        <Alert tone="danger" title="That did not work" live>
          {error}
        </Alert>
      ) : null}

      {comparison ? (
        <Alert
          tone={comparison.versionChanged ? 'warning' : 'info'}
          title="Compared with the last check of this source"
          live
        >
          <p>{comparison.summary}</p>
          {comparison.fixed.length > 0 ? (
            <p className="mt-2">
              <span className="font-medium">Resolved: </span>
              {comparison.fixed.length} finding(s) from last time are gone.
            </p>
          ) : null}
          {comparison.introduced.length > 0 ? (
            <p className="mt-1">
              <span className="font-medium">New: </span>
              {comparison.introduced.length} finding(s) were not there last time.
            </p>
          ) : null}
        </Alert>
      ) : null}

      {result ? <ValidationReport result={result} /> : null}
      {correction ? <CorrectionView correction={correction} /> : null}
      {generated ? <GeneratedSchemaView generated={generated} /> : null}

      {history.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle as="h2" className="text-base">History</CardTitle>
            <CardDescription>
              Every check is kept with the validator version that produced it, so a change between
              two runs can be attributed to your markup rather than to our rules.
            </CardDescription>
          </CardHeader>
          <div className="overflow-x-auto border-t border-border">
            <table className="w-full text-sm">
              <caption className="sr-only">Validation findings, by severity</caption>
              <thead>
                <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-fg-muted">
                  <th scope="col" className="px-4 py-2 font-medium">
                    When
                  </th>
                  <th scope="col" className="px-4 py-2 font-medium">
                    Source
                  </th>
                  <th scope="col" className="px-4 py-2 font-medium">
                    Result
                  </th>
                  <th scope="col" className="px-4 py-2 font-medium">
                    Types
                  </th>
                  <th scope="col" className="px-4 py-2 font-medium">
                    Validator
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {history.map((entry) => (
                  <tr key={entry.id}>
                    <td className="px-4 py-2 align-top">
                      <time dateTime={entry.checkedAt}>
                        {entry.checkedAt.replace('T', ' ').slice(0, 16)}
                      </time>
                    </td>
                    <td className="px-4 py-2 align-top text-fg-muted">
                      {entry.sourceUrl ?? 'Pasted markup'}
                    </td>
                    <td className="px-4 py-2 align-top">
                      <Badge
                        tone={
                          entry.overallStatus === 'INVALID'
                            ? 'danger'
                            : entry.overallStatus === 'WARNING'
                              ? 'warning'
                              : entry.overallStatus === 'VALID'
                                ? 'success'
                                : 'neutral'
                        }
                      >
                        {entry.overallStatus}
                      </Badge>
                    </td>
                    <td className="px-4 py-2 align-top text-fg-muted">
                      {entry.typesFound.length > 0 ? entry.typesFound.join(', ') : '—'}
                    </td>
                    <td className="px-4 py-2 align-top text-fg-muted">{entry.validatorVersion}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      ) : null}
    </div>
  );
}
