import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import type { Correction } from '@/lib/schema-validator';

/**
 * Before and after, plus what was deliberately NOT filled in.
 *
 * The refusals are rendered as prominently as the changes. A user looking at a
 * corrected document needs to know that the absent `aggregateRating` is a decision
 * rather than an oversight — otherwise the obvious next step is to add one, which
 * is exactly the outcome this refuses to help with.
 *
 * Placeholders are called out too. `<add address — for example …>` is visibly fake
 * on purpose, and the list above the code makes sure nobody pastes it as-is.
 */
export interface CorrectionViewProps {
  readonly correction: Correction;
}

export function CorrectionView({ correction }: CorrectionViewProps) {
  if (!correction.available) {
    return (
      <Alert tone="info" title="No corrected version">
        {correction.unavailableReason ?? 'Nothing could be corrected automatically.'}
      </Alert>
    );
  }

  return (
    <div className="space-y-4">
      {correction.placeholders.length > 0 ? (
        <Alert tone="warning" title="Replace these before you publish">
          <p>
            The suggested document below contains {correction.placeholders.length} placeholder
            {correction.placeholders.length === 1 ? '' : 's'} — {correction.placeholders.join(', ')}.
            They are written to be obviously fake. SeSha does not guess these values, because a
            plausible-looking guess gets published.
          </p>
        </Alert>
      ) : null}

      {correction.refusals.length > 0 ? (
        <Card tone="subtle">
          <CardHeader>
            <CardTitle as="h2" className="text-base">Deliberately left out</CardTitle>
            <CardDescription>
              These were not added, and not added as placeholders either.
            </CardDescription>
          </CardHeader>
          <ul className="space-y-2 border-t border-border px-5 py-4 text-sm">
            {correction.refusals.map((refusal) => (
              <li key={refusal.property} className="flex flex-wrap items-start gap-2">
                <Badge tone="outline">{refusal.property}</Badge>
                <span className="text-fg-muted">{refusal.why}</span>
              </li>
            ))}
          </ul>
        </Card>
      ) : null}

      {correction.changes.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle as="h2" className="text-base">What changed</CardTitle>
          </CardHeader>
          <ul className="ml-5 list-disc space-y-1 border-t border-border px-5 py-4 text-sm">
            {correction.changes.map((change, index) => (
              <li key={index}>{change}</li>
            ))}
          </ul>
        </Card>
      ) : null}

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle as="h2" className="text-base">Before</CardTitle>
          </CardHeader>
          <div className="border-t border-border p-4">
            <pre className="overflow-x-auto rounded bg-bg-muted p-3 text-xs leading-relaxed">
              <code>{correction.before}</code>
            </pre>
          </div>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle as="h2" className="text-base">Suggested</CardTitle>
          </CardHeader>
          <div className="border-t border-border p-4">
            <pre className="overflow-x-auto rounded bg-bg-muted p-3 text-xs leading-relaxed">
              <code>{correction.after}</code>
            </pre>
          </div>
        </Card>
      </div>
    </div>
  );
}
