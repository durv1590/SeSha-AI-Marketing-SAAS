import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  DIMENSION_LABEL,
  DIMENSION_MEANING,
  SOURCE_KIND_LABEL,
  SYNTAX_LABEL,
  VALIDATION_DIMENSIONS,
  issuesForDimension,
  type ValidationDimension,
  type ValidationIssue,
  type ValidationResult,
  type ValidationStatus,
} from '@/lib/schema-validator';
import { SEARCH_RULES_AS_OF } from '@/lib/schema-validator/registry';

/**
 * How a validation result is shown.
 *
 * THE GROUPING IS THE DESIGN
 * The brief requires schema.org validity, search-engine eligibility, general SEO
 * guidance and AI/AEO clarity to be distinguished and never represented as one
 * another. A single list sorted by severity would undo that no matter what each
 * row said, because a reader takes "12 issues" as one number about one thing.
 *
 * So the findings are grouped by DIMENSION, each group carries the sentence
 * saying what it may claim, and the counts are per group. There is no combined
 * "issues" total anywhere on this screen.
 *
 * NOT_EVALUATED findings are rendered too, in their own muted block. They are the
 * ones a user would never think to ask for — what the tool did not check — and
 * hiding them is how the absence of a finding comes to read as a pass.
 */

const STATUS_TONE: Record<ValidationStatus, 'danger' | 'warning' | 'info' | 'neutral' | 'success' | 'outline'> = {
  INVALID: 'danger',
  WARNING: 'warning',
  RECOMMENDATION: 'info',
  UNSUPPORTED: 'outline',
  NOT_EVALUATED: 'neutral',
  VALID: 'success',
};

const STATUS_LABEL: Record<ValidationStatus, string> = {
  INVALID: 'Invalid',
  WARNING: 'Warning',
  RECOMMENDATION: 'Recommendation',
  UNSUPPORTED: 'Not supported',
  NOT_EVALUATED: 'Not evaluated',
  VALID: 'Valid',
};

const OVERALL_SENTENCE: Record<ValidationStatus, string> = {
  VALID: 'The markup is valid schema.org.',
  INVALID: 'The markup has errors that stop it being read correctly.',
  WARNING: 'The markup is valid, with things worth changing.',
  RECOMMENDATION: 'The markup is valid. There are optional improvements.',
  NOT_EVALUATED: 'No structured data was found, so there was nothing to check.',
  UNSUPPORTED: 'The markup uses types this validator has no rules for.',
};

export interface ValidationReportProps {
  readonly result: ValidationResult;
}

export function ValidationReport({ result }: ValidationReportProps) {
  const notEvaluated = result.issues.filter((issue) => issue.status === 'NOT_EVALUATED');

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-center gap-3">
            <Badge tone={STATUS_TONE[result.overall]}>{STATUS_LABEL[result.overall]}</Badge>
            <CardTitle as="h2" className="text-lg">{OVERALL_SENTENCE[result.overall]}</CardTitle>
          </div>
          <CardDescription>
            {SOURCE_KIND_LABEL[result.sourceKind]}
            {result.sourceUrl ? ` — ${result.sourceUrl}` : ''} · checked{' '}
            <time dateTime={result.checkedAt}>{formatWhen(result.checkedAt)}</time> · validator{' '}
            {result.validatorVersion}
          </CardDescription>
        </CardHeader>

        <div className="border-t border-border px-5 py-4 text-sm">
          <dl className="grid gap-4 sm:grid-cols-3">
            <div>
              <dt className="text-xs uppercase tracking-wide text-fg-muted">Syntaxes found</dt>
              <dd className="mt-1 font-medium">
                {result.syntaxes.length > 0
                  ? result.syntaxes.map((syntax) => SYNTAX_LABEL[syntax]).join(', ')
                  : 'None'}
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wide text-fg-muted">Entities</dt>
              <dd className="mt-1 font-medium">{result.entities.length}</dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wide text-fg-muted">Types</dt>
              <dd className="mt-1 font-medium">
                {result.typesFound.length > 0 ? result.typesFound.join(', ') : '—'}
              </dd>
            </div>
          </dl>
        </div>
      </Card>

      {result.limitations.length > 0 ? (
        <Alert tone="info" title="How this document was read">
          <ul className="ml-4 list-disc space-y-1">
            {result.limitations.map((limitation) => (
              <li key={limitation.code}>{limitation.detail}</li>
            ))}
          </ul>
        </Alert>
      ) : null}

      {VALIDATION_DIMENSIONS.map((dimension) => (
        <DimensionSection
          key={dimension}
          dimension={dimension}
          issues={issuesForDimension(result.issues, dimension).filter(
            (issue) => issue.status !== 'NOT_EVALUATED',
          )}
        />
      ))}

      {notEvaluated.length > 0 ? (
        <Card tone="subtle">
          <CardHeader>
            <CardTitle as="h2" className="text-base">What was not checked</CardTitle>
            <CardDescription>
              Listed because the absence of a finding is not a pass. Nothing below is a problem with
              your markup.
            </CardDescription>
          </CardHeader>
          <ul className="space-y-3 border-t border-border px-5 py-4 text-sm text-fg-muted">
            {notEvaluated.map((issue, index) => (
              <li key={`${issue.check}-${index}`} className="flex gap-3">
                <Badge tone="neutral" className="shrink-0">
                  {DIMENSION_LABEL[issue.dimension]}
                </Badge>
                <span>{issue.explanation}</span>
              </li>
            ))}
          </ul>
        </Card>
      ) : null}
    </div>
  );
}

function DimensionSection({
  dimension,
  issues,
}: {
  readonly dimension: ValidationDimension;
  readonly issues: readonly ValidationIssue[];
}) {
  return (
    <section aria-labelledby={`dimension-${dimension}`}>
      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <CardTitle as="h2" id={`dimension-${dimension}`} className="text-base">
              {DIMENSION_LABEL[dimension]}
            </CardTitle>
            <span className="text-xs text-fg-muted">
              {issues.length === 0 ? 'Nothing to report' : `${issues.length} finding(s)`}
            </span>
          </div>
          {/* The sentence that says what this group may claim. Rendered every time,
              not behind a tooltip: it is the thing that stops one dimension being
              read as another. */}
          <CardDescription>{DIMENSION_MEANING[dimension]}</CardDescription>
          {dimension === 'SEARCH_ELIGIBILITY' ? (
            <CardDescription>
              Requirements last reviewed {SEARCH_RULES_AS_OF}. This tool does not contact any search
              engine.
            </CardDescription>
          ) : null}
        </CardHeader>

        {issues.length === 0 ? (
          <p className="border-t border-border px-5 py-4 text-sm text-fg-muted">
            No findings in this category.
          </p>
        ) : (
          <ul className="divide-y divide-border border-t border-border">
            {issues.map((issue, index) => (
              <li key={`${issue.check}-${issue.path}-${index}`} className="px-5 py-4">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone={STATUS_TONE[issue.status]}>{STATUS_LABEL[issue.status]}</Badge>
                  {issue.type ? <Badge tone="outline">{issue.type}</Badge> : null}
                  <code className="rounded bg-bg-muted px-1.5 py-0.5 text-xs text-fg-muted">
                    {issue.path}
                  </code>
                </div>

                <p className="mt-2 text-sm leading-relaxed">{issue.explanation}</p>

                {issue.found ? (
                  <p className="mt-2 text-sm text-fg-muted">
                    <span className="font-medium">Found: </span>
                    <code className="rounded bg-bg-muted px-1.5 py-0.5 text-xs">{issue.found}</code>
                  </p>
                ) : null}

                {issue.correctedExample ? (
                  <p className="mt-2 text-sm">
                    <span className="font-medium">What it should look like: </span>
                    <code className="rounded bg-bg-muted px-1.5 py-0.5 text-xs">
                      {issue.correctedExample}
                    </code>
                  </p>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </section>
  );
}

function formatWhen(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toISOString().replace('T', ' ').slice(0, 16);
}
