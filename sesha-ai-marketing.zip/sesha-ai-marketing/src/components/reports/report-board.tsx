'use client';

import { useCallback, useState } from 'react';

import { readCsrfCookie } from '@/components/app/app-shell';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Field, Select } from '@/components/ui/field';
import { REPORT_KINDS, REPORT_LABEL, REPORT_PURPOSE, type ReportKind } from '@/lib/reports/types';
import { EXPORT_FORMATS } from '@/lib/reports/export';

/**
 * Generating, exporting and sharing reports.
 *
 * THE SHARE TOKEN IS SHOWN ONCE, AND THE SCREEN SAYS SO
 * Only its hash is stored, so it genuinely cannot be shown again. A screen that
 * let someone assume they could come back for it would produce a second live
 * link every time they could not find the first.
 */

export interface ReportListView {
  readonly id: string;
  readonly kind: string;
  readonly title: string;
  readonly period: { readonly from: string; readonly to: string; readonly label: string };
  readonly connectedSources: readonly string[];
  readonly generatedAt: string;
  readonly points: number;
}

export interface ReportBoardProps {
  readonly projectId: string | null;
  readonly reports: readonly ReportListView[];
  readonly canGenerate: boolean;
}

export function ReportBoard({ projectId, reports, canGenerate }: ReportBoardProps) {
  const [kind, setKind] = useState<ReportKind>('weekly');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [shareLink, setShareLink] = useState<{ path: string; expiresAt: string } | null>(null);

  const generate = useCallback(async () => {
    if (!projectId) return;
    setBusy(true);
    setError(null);
    setMessage(null);
    setShareLink(null);
    try {
      const response = await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
        body: JSON.stringify({ projectId, kind }),
      });
      const payload = (await response.json()) as { message?: string };
      if (!response.ok) {
        setError(payload.message ?? 'That report could not be generated.');
        return;
      }
      setMessage(payload.message ?? 'Generated.');
    } catch {
      setError('The request did not complete.');
    } finally {
      setBusy(false);
    }
  }, [kind, projectId]);

  const share = useCallback(async (reportId: string) => {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const response = await fetch(`/api/reports/${reportId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
        body: JSON.stringify({}),
      });
      const payload = (await response.json()) as {
        message?: string;
        data?: { path?: string; expiresAt?: string };
      };
      if (!response.ok) {
        setError(payload.message ?? 'That link could not be created.');
        return;
      }
      if (payload.data?.path && payload.data.expiresAt) {
        setShareLink({ path: payload.data.path, expiresAt: payload.data.expiresAt });
      }
      setMessage(payload.message ?? 'Link created.');
    } catch {
      setError('The request did not complete.');
    } finally {
      setBusy(false);
    }
  }, []);

  if (!projectId) {
    return (
      <Alert tone="info" title="No project yet">
        Create a project and there is something to report on.
      </Alert>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      {message && <Alert tone="success" live>{message}</Alert>}
      {error && <Alert tone="danger" live>{error}</Alert>}

      {shareLink && (
        <Alert tone="warning" title="Copy this link now — it is shown once">
          <p className="break-all font-mono text-sm">{shareLink.path}</p>
          <p className="mt-2">
            Anyone with this link can read the report without signing in, until{' '}
            {shareLink.expiresAt.slice(0, 10)} or until you revoke it. Only a hash of it is stored, so
            SeSha cannot show it to you again.
          </p>
        </Alert>
      )}

      {canGenerate && (
        <Card>
          <CardHeader>
            <CardTitle as="h2">Generate a report</CardTitle>
            <CardDescription>
              A report is a snapshot. It records what was known when it was generated, including which
              data sources were connected, and it does not change afterwards.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4 pt-4">
            <Field label="Which report" id="report-kind" hint={REPORT_PURPOSE[kind]}>
              {({ id }) => (
                <Select id={id}
                  value={kind}
                  onChange={(event) => setKind(event.target.value as ReportKind)}
                >
                  {REPORT_KINDS.map((candidate) => (
                    <option key={candidate} value={candidate}>
                      {REPORT_LABEL[candidate]}
                    </option>
                  ))}
                </Select>
              )}
            </Field>
            <div>
              <Button disabled={busy} onClick={() => void generate()}>
                Generate
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold tracking-tight">Reports</h2>
        {reports.length === 0 ? (
          <p className="text-sm text-fg-muted">Nothing generated yet.</p>
        ) : (
          <div className="flex flex-col gap-4">
            {reports.map((report) => (
              <Card key={report.id}>
                <CardHeader>
                  <div className="flex flex-wrap items-center gap-2">
                    <CardTitle as="h3">{report.title}</CardTitle>
                    <Badge tone={report.connectedSources.length > 0 ? 'success' : 'neutral'}>
                      {report.connectedSources.length > 0
                        ? report.connectedSources.join(', ')
                        : 'No connected source'}
                    </Badge>
                  </div>
                  <CardDescription>
                    {report.period.label} · generated {report.generatedAt.slice(0, 10)} · {report.points}{' '}
                    points
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex flex-wrap gap-2 pt-3">
                  <a
                    href={`/app/reports/${report.id}`}
                    className="rounded-control border border-border px-3 py-1.5 text-sm font-medium"
                  >
                    Read
                  </a>
                  {EXPORT_FORMATS.map((format) => (
                    <a
                      key={format}
                      href={`/api/reports/${report.id}/export?format=${format}`}
                      className="rounded-control border border-border px-3 py-1.5 text-sm font-medium uppercase"
                    >
                      {format}
                    </a>
                  ))}
                  <Button size="sm" variant="secondary" disabled={busy} onClick={() => void share(report.id)}>
                    Share
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
