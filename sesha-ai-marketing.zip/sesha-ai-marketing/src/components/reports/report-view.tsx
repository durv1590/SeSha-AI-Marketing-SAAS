import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { SOURCE_LABEL, formatValue } from '@/lib/analytics/metrics';
import { NO_CONNECTED_DATA } from '@/lib/analytics/metrics';
import type { Report } from '@/lib/reports/types';

/**
 * Rendering a stored report.
 *
 * A server component: there is nothing interactive here, and the report is a
 * snapshot that never changes, so shipping JavaScript for it would be waste.
 *
 * Used both by the signed-in report page and by the public share page, which is
 * what guarantees the two show the same thing. A separate "public view" is how a
 * caveat ends up on one and not the other.
 */

export function ReportView({ report }: { readonly report: Report }) {
  return (
    <article className="flex flex-col gap-6">
      <header className="flex flex-col gap-2">
        <h1 className="text-2xl font-semibold tracking-tight">{report.title}</h1>
        <p className="text-sm text-fg-muted">
          {report.period.label} · {report.period.from.slice(0, 10)} to {report.period.to.slice(0, 10)} ·
          generated {report.generatedAt.slice(0, 10)}
        </p>
      </header>

      <Alert
        tone={report.provenance.anyConnected ? 'info' : 'warning'}
        title={report.provenance.anyConnected ? 'Where these figures come from' : NO_CONNECTED_DATA}
      >
        <p>{report.provenance.note}</p>
        <p className="mt-2">
          Every figure below states its source. Figures marked unavailable were not measured — they are
          not zero.
        </p>
      </Alert>

      {report.metrics.length > 0 && (
        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-semibold tracking-tight">Figures</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {report.metrics.map((metric) => {
              const formatted = formatValue(metric.value);
              return (
                <Card key={metric.id} tone={formatted === null ? 'subtle' : 'default'}>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <CardTitle as="h3" className="text-base">
                        {metric.definition.label}
                      </CardTitle>
                      <Badge tone={formatted === null ? 'neutral' : 'info'}>
                        {SOURCE_LABEL[metric.value.kind]}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-3">
                    {formatted === null ? (
                      metric.value.kind === 'unavailable' ? (
                        <>
                          <p className="text-sm leading-relaxed text-fg-muted">{metric.value.why}</p>
                          <p className="mt-2 text-sm font-medium">
                            {metric.value.whatWouldMakeItAvailable}
                          </p>
                        </>
                      ) : (
                        <p className="text-sm text-fg-muted">Not measured.</p>
                      )
                    ) : (
                      <>
                        <p className="text-2xl font-semibold tracking-tight">{formatted}</p>
                        {metric.value.kind === 'calculated' && (
                          <p className="mt-2 text-sm leading-relaxed text-fg-muted">
                            {metric.value.formula}
                          </p>
                        )}
                      </>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>
      )}

      {report.sections.map((section) => (
        <section key={section.id} className="flex flex-col gap-3">
          <h2 className="text-lg font-semibold tracking-tight">{section.question}</h2>
          {section.points.length === 0 ? (
            <p className="max-w-3xl text-sm leading-relaxed text-fg-muted">{section.emptyReason}</p>
          ) : (
            <ul className="flex max-w-3xl flex-col gap-3">
              {section.points.map((point, index) => (
                <li key={`${section.id}-${index}`} className="flex flex-col gap-1">
                  <p className="text-sm font-medium">{point.text}</p>
                  {point.detail && (
                    <p className="text-sm leading-relaxed text-fg-muted">{point.detail}</p>
                  )}
                  {point.evidence && point.evidence.length > 0 && (
                    <p className="text-xs text-fg-muted">From: {point.evidence.join(', ')}</p>
                  )}
                </li>
              ))}
            </ul>
          )}
        </section>
      ))}

      <CardDescription>
        This report is a snapshot of what was known when it was generated. It does not change.
      </CardDescription>
    </article>
  );
}
