import type { ReactNode } from 'react';

import { cn } from '@/lib/utils/cn';

export interface SectionHeaderProps {
  readonly eyebrow?: string;
  readonly heading: string;
  readonly intro?: string;
  /**
   * Heading level. Defaults to h2 — pages own their single h1, and sections
   * must never introduce a second one or skip a level.
   */
  readonly as?: 'h1' | 'h2' | 'h3';
  readonly align?: 'start' | 'center';
  readonly id?: string;
  readonly children?: ReactNode;
  readonly className?: string;
}

export function SectionHeader({
  eyebrow,
  heading,
  intro,
  as: Tag = 'h2',
  align = 'start',
  id,
  children,
  className,
}: SectionHeaderProps) {
  return (
    <div
      className={cn(
        'flex flex-col gap-4',
        align === 'center' && 'items-center text-center',
        align === 'center' ? 'mx-auto max-w-3xl' : 'max-w-3xl',
        className,
      )}
    >
      {eyebrow ? (
        <p className="text-sm font-semibold uppercase tracking-[0.12em] text-primary">{eyebrow}</p>
      ) : null}
      <Tag
        id={id}
        className={cn(
          'font-semibold text-balance',
          Tag === 'h1'
            ? 'text-4xl leading-[1.08] sm:text-5xl lg:text-[3.4rem]'
            : 'text-3xl leading-tight sm:text-4xl',
        )}
      >
        {heading}
      </Tag>
      {intro ? <p className="text-lg leading-relaxed text-fg-muted">{intro}</p> : null}
      {children}
    </div>
  );
}
