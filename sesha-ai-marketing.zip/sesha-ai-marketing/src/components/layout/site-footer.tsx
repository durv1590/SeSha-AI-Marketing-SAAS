import Link from 'next/link';

import { Container } from './container';
import { Logo } from './logo';
import { NewsletterForm } from './newsletter-form';
import { footerNav } from '@/content/nav';
import { formatPhone, organization } from '@/content/site';

/**
 * Site footer — home page section 23, and present on every page.
 *
 * It carries the bulk of the internal-linking architecture: every registered
 * route is reachable from here, so no page is orphaned regardless of where a
 * visitor (or a crawler) enters the site.
 */
export function SiteFooter() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border bg-bg-subtle">
      <Container className="py-14 lg:py-16">
        <div className="grid gap-12 lg:grid-cols-[1.1fr_2fr]">
          <div className="max-w-sm">
            <Logo />
            <p className="mt-4 text-sm leading-relaxed text-fg-muted">
              {organization.description}
            </p>
            <div className="mt-6">
              <NewsletterForm />
            </div>
          </div>

          <nav aria-label="Footer" className="grid grid-cols-2 gap-8 sm:grid-cols-4">
            {footerNav.map((group) => (
              <div key={group.label}>
                <h2 className="mb-3 text-xs font-semibold uppercase tracking-[0.12em] text-fg-subtle">
                  {group.label}
                </h2>
                <ul className="flex flex-col gap-2.5">
                  {group.links.map((link) => (
                    <li key={link.href}>
                      <Link
                        href={link.href}
                        className="text-sm text-fg-muted transition-colors duration-150 hover:text-fg hover:underline underline-offset-4"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </nav>
        </div>

        <div className="mt-12 flex flex-col gap-3 border-t border-border pt-6 text-sm text-fg-muted sm:flex-row sm:items-center sm:justify-between">
          <p>
            &copy; {year} {organization.legalName}. All rights reserved.
          </p>
          <p className="flex flex-wrap items-center gap-x-4 gap-y-1">
            <a
              href={`mailto:${organization.email}`}
              className="transition-colors hover:text-fg hover:underline underline-offset-4"
            >
              {organization.email}
            </a>
            {organization.telephone ? (
              <a
                href={`tel:${organization.telephone}`}
                className="transition-colors hover:text-fg hover:underline underline-offset-4"
              >
                {formatPhone(organization.telephone)}
              </a>
            ) : null}
          </p>
        </div>
      </Container>
    </footer>
  );
}
