'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useCallback, useEffect, useId, useRef, useState } from 'react';

import { Logo } from './logo';
import { ThemeToggle } from './theme';
import { Container } from './container';
import { Button } from '@/components/ui/button';
import { Icon } from '@/components/ui/icon';
import { flatNav, headerCta, primaryNav } from '@/content/nav';
import { normalizePath } from '@/lib/routes';
import { cn } from '@/lib/utils/cn';

/**
 * Site header.
 *
 * Accessibility behaviour implemented here:
 *  - each dropdown trigger is a real <button> with aria-expanded / aria-controls;
 *  - Escape closes an open menu and returns focus to its trigger;
 *  - a pointer press outside, or focus leaving the header, closes menus;
 *  - the mobile panel is a labelled region toggled by an aria-expanded button;
 *  - the current page is marked with aria-current on its link.
 *
 * Menus are CSS-hidden rather than unmounted so their links stay in the DOM for
 * crawlers — the internal-linking architecture depends on that.
 */
export function SiteHeader() {
  const pathname = usePathname();
  const currentPath = normalizePath(pathname ?? '/');
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const headerRef = useRef<HTMLElement>(null);
  const mobilePanelId = useId();

  // Any navigation closes everything.
  useEffect(() => {
    setOpenMenu(null);
    setMobileOpen(false);
  }, [pathname]);

  // Escape closes the open menu; pointer-down outside the header does too.
  useEffect(() => {
    if (!openMenu && !mobileOpen) return;

    function onKeyDown(event: KeyboardEvent) {
      if (event.key !== 'Escape') return;
      setOpenMenu(null);
      setMobileOpen(false);
    }
    function onPointerDown(event: PointerEvent) {
      if (!headerRef.current?.contains(event.target as Node)) {
        setOpenMenu(null);
        setMobileOpen(false);
      }
    }

    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('pointerdown', onPointerDown);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.removeEventListener('pointerdown', onPointerDown);
    };
  }, [openMenu, mobileOpen]);

  // Prevent the page behind the mobile panel from scrolling.
  useEffect(() => {
    if (!mobileOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = previous;
    };
  }, [mobileOpen]);

  const isCurrent = useCallback(
    (href: string) => currentPath === normalizePath(href),
    [currentPath],
  );

  const isWithin = useCallback(
    (href?: string) => Boolean(href && currentPath.startsWith(normalizePath(href))),
    [currentPath],
  );

  return (
    <header
      ref={headerRef}
      className="sticky top-0 z-50 border-b border-border bg-bg/85 backdrop-blur-md"
      onBlur={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget as Node)) setOpenMenu(null);
      }}
    >
      <Container className="flex h-16 items-center justify-between gap-4">
        <Logo />

        {/* ---------------------------- desktop nav --------------------------- */}
        <nav aria-label="Main" className="hidden items-center gap-1 lg:flex">
          {primaryNav.map((group) => {
            const menuId = `menu-${group.label.toLowerCase()}`;
            const open = openMenu === group.label;
            return (
              <div key={group.label} className="relative">
                <button
                  type="button"
                  aria-expanded={open}
                  aria-controls={menuId}
                  onClick={() => setOpenMenu(open ? null : group.label)}
                  className={cn(
                    'inline-flex items-center gap-1 rounded-control px-3 py-2 text-sm font-medium',
                    'transition-colors duration-150 hover:bg-bg-muted',
                    isWithin(group.href) || open ? 'text-fg' : 'text-fg-muted',
                  )}
                >
                  {group.label}
                  <Icon
                    name="chevron-down"
                    size={15}
                    className={cn('transition-transform duration-150', open && 'rotate-180')}
                  />
                </button>

                <div
                  id={menuId}
                  hidden={!open}
                  className={cn(
                    'absolute left-0 top-full z-50 mt-2 w-72 rounded-card border border-border',
                    'bg-surface-raised p-2 shadow-lg',
                  )}
                >
                  <ul className="flex flex-col">
                    {group.links.map((link) => (
                      <li key={link.href}>
                        <Link
                          href={link.href}
                          aria-current={isCurrent(link.href) ? 'page' : undefined}
                          className={cn(
                            'flex flex-col gap-0.5 rounded-control px-3 py-2.5',
                            'transition-colors duration-150 hover:bg-bg-muted',
                            isCurrent(link.href) && 'bg-primary-subtle',
                          )}
                        >
                          <span className="text-sm font-medium text-fg">{link.label}</span>
                          {link.description ? (
                            <span className="text-xs leading-snug text-fg-muted">
                              {link.description}
                            </span>
                          ) : null}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          })}

          {flatNav.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              aria-current={isCurrent(link.href) ? 'page' : undefined}
              className={cn(
                'rounded-control px-3 py-2 text-sm font-medium',
                'transition-colors duration-150 hover:bg-bg-muted',
                isCurrent(link.href) ? 'text-fg' : 'text-fg-muted',
              )}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-1.5">
          <ThemeToggle />
          <Button href={headerCta.href} size="sm" className="hidden sm:inline-flex">
            {headerCta.label}
          </Button>
          <button
            type="button"
            aria-expanded={mobileOpen}
            aria-controls={mobilePanelId}
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
            onClick={() => setMobileOpen((value) => !value)}
            className="inline-flex size-10 items-center justify-center rounded-control text-fg-muted hover:bg-bg-muted hover:text-fg lg:hidden"
          >
            <Icon name={mobileOpen ? 'close' : 'menu'} size={20} />
          </button>
        </div>
      </Container>

      {/* ----------------------------- mobile nav ---------------------------- */}
      <div
        id={mobilePanelId}
        hidden={!mobileOpen}
        className="max-h-[calc(100dvh-4rem)] overflow-y-auto border-t border-border bg-bg lg:hidden"
      >
        <nav aria-label="Mobile" className="px-5 py-5 sm:px-6">
          <ul className="flex flex-col gap-6">
            {primaryNav.map((group) => (
              <li key={group.label}>
                <p className="mb-2 text-xs font-semibold uppercase tracking-[0.12em] text-fg-subtle">
                  {group.label}
                </p>
                <ul className="flex flex-col">
                  {group.links.map((link) => (
                    <li key={link.href}>
                      <Link
                        href={link.href}
                        aria-current={isCurrent(link.href) ? 'page' : undefined}
                        className={cn(
                          'block rounded-control px-3 py-2.5 text-sm',
                          isCurrent(link.href)
                            ? 'bg-primary-subtle font-medium text-primary-subtle-fg'
                            : 'text-fg-muted hover:bg-bg-muted hover:text-fg',
                        )}
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </li>
            ))}
            <li>
              <ul className="flex flex-col border-t border-border pt-4">
                {flatNav.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      aria-current={isCurrent(link.href) ? 'page' : undefined}
                      className="block rounded-control px-3 py-2.5 text-sm text-fg-muted hover:bg-bg-muted hover:text-fg"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </li>
          </ul>
          <Button href={headerCta.href} block className="mt-6">
            {headerCta.label}
          </Button>
        </nav>
      </div>
    </header>
  );
}
