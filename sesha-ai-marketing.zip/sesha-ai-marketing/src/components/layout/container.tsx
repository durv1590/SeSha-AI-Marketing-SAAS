import type { ElementType, HTMLAttributes, ReactNode } from 'react';

import { cn } from '@/lib/utils/cn';

/** Horizontal page gutter. One place controls the site-wide measure. */
export function Container({
  className,
  as: Tag = 'div',
  ...props
}: HTMLAttributes<HTMLElement> & { as?: ElementType }) {
  return <Tag className={cn('mx-auto w-full max-w-content px-5 sm:px-6 lg:px-8', className)} {...props} />;
}

export interface SectionProps extends HTMLAttributes<HTMLElement> {
  readonly tone?: 'default' | 'subtle' | 'gradient';
  readonly spacing?: 'sm' | 'md' | 'lg';
  readonly children: ReactNode;
}

/** A page section with consistent vertical rhythm and an optional background. */
export function Section({
  tone = 'default',
  spacing = 'md',
  className,
  children,
  ...props
}: SectionProps) {
  return (
    <section
      className={cn(
        tone === 'subtle' && 'bg-bg-subtle',
        tone === 'gradient' && 'surface-gradient',
        spacing === 'sm' && 'py-12 sm:py-16',
        spacing === 'md' && 'py-16 sm:py-20 lg:py-24',
        spacing === 'lg' && 'py-20 sm:py-28 lg:py-32',
        className,
      )}
      {...props}
    >
      {children}
    </section>
  );
}
