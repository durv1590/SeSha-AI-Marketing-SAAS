import Link from 'next/link';

import { site } from '@/content/site';
import { cn } from '@/lib/utils/cn';

/** Wordmark + mark. Inline SVG so it needs no network request and themes. */
export function Logo({ className, href = '/' }: { readonly className?: string; readonly href?: string }) {
  return (
    <Link
      href={href}
      className={cn('inline-flex items-center gap-2.5 font-semibold tracking-tight', className)}
      aria-label={`${site.name} — home`}
    >
      <svg
        width="30"
        height="30"
        viewBox="0 0 32 32"
        fill="none"
        aria-hidden="true"
        focusable="false"
        className="shrink-0"
      >
        <rect width="32" height="32" rx="8" fill="var(--primary)" />
        <path
          d="M21 10.5c-1.4-1.3-3.6-1.9-5.4-1.3-1.9.6-2.9 2.3-2.2 3.8.6 1.3 2.4 1.8 4 2 1.6.3 3.4.8 4 2.2.6 1.6-.5 3.3-2.4 3.9-1.9.6-4.1-.1-5.5-1.5"
          stroke="var(--primary-fg)"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
      <span className="text-[0.95rem] leading-none">
        <span className="font-bold">SeSha</span>
        <span className="ml-1 font-medium text-fg-muted">AI Marketing</span>
      </span>
    </Link>
  );
}
