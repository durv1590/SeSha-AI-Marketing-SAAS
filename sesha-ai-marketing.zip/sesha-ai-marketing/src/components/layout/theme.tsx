'use client';

import { useEffect, useState } from 'react';

import { Icon } from '@/components/ui/icon';
import { cn } from '@/lib/utils/cn';

/**
 * Theme handling.
 *
 * Written in-house instead of adding a theme package, for two reasons: it is
 * about forty lines, and the no-flash script has to be inlined into <head>
 * under our content security policy anyway.
 *
 * How it works:
 *  - `themeScript` runs before first paint and sets the `dark` class from the
 *    stored preference, falling back to the OS setting. This is what prevents
 *    a white flash on a dark-mode load.
 *  - The toggle updates the class and stores the choice.
 *  - Storage access is wrapped in try/catch: it throws in some privacy modes.
 */

export const STORAGE_KEY = 'sesha-theme';

/** Inlined into <head>. Must stay small, synchronous and dependency-free. */
export const themeScript = `(function(){try{var s=localStorage.getItem('${STORAGE_KEY}');var m=window.matchMedia('(prefers-color-scheme: dark)').matches;var d=s==='dark'||(!s&&m);document.documentElement.classList.toggle('dark',d);document.documentElement.style.colorScheme=d?'dark':'light';}catch(e){}})();`;

type Theme = 'light' | 'dark';

function applyTheme(theme: Theme): void {
  document.documentElement.classList.toggle('dark', theme === 'dark');
  document.documentElement.style.colorScheme = theme;
  try {
    localStorage.setItem(STORAGE_KEY, theme);
  } catch {
    // Storage unavailable (private mode, blocked cookies): the toggle still
    // works for this page view, it just will not be remembered.
  }
}

export function ThemeToggle({ className }: { readonly className?: string }) {
  const [theme, setTheme] = useState<Theme | null>(null);

  // Read the theme the inline script already applied, after hydration, so the
  // server and client render the same markup.
  useEffect(() => {
    setTheme(document.documentElement.classList.contains('dark') ? 'dark' : 'light');
  }, []);

  const next: Theme = theme === 'dark' ? 'light' : 'dark';

  return (
    <button
      type="button"
      onClick={() => {
        applyTheme(next);
        setTheme(next);
      }}
      aria-label={theme === null ? 'Toggle colour theme' : `Switch to ${next} theme`}
      className={cn(
        'inline-flex size-10 items-center justify-center rounded-control',
        'text-fg-muted transition-colors duration-150 hover:bg-bg-muted hover:text-fg',
        className,
      )}
    >
      {/* Both icons render; CSS picks one, so there is nothing to hydrate-match. */}
      <Icon name="sun" size={18} className="dark:hidden" />
      <Icon name="moon" size={18} className="hidden dark:block" />
    </button>
  );
}
