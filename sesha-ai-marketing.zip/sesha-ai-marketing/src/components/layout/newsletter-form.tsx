'use client';

import { useRef, useState } from 'react';

import { Button } from '@/components/ui/button';
import { Field, Honeypot, Input } from '@/components/ui/field';

type State = { status: 'idle' | 'submitting' | 'ok' | 'error'; message?: string };

export function NewsletterForm() {
  const [state, setState] = useState<State>({ status: 'idle' });
  const formRef = useRef<HTMLFormElement>(null);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setState({ status: 'submitting' });

    const data = new FormData(event.currentTarget);
    try {
      const response = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: data.get('email'),
          website: data.get('website'),
        }),
      });
      const payload = (await response.json()) as { ok?: boolean; errors?: { email?: string }; message?: string };

      if (response.ok && payload.ok) {
        setState({ status: 'ok', message: payload.message ?? 'Thanks — you are on the list.' });
        formRef.current?.reset();
        return;
      }
      setState({
        status: 'error',
        message: payload.errors?.email ?? payload.message ?? 'That did not work. Please try again.',
      });
    } catch {
      setState({ status: 'error', message: 'Network error. Please try again.' });
    }
  }

  return (
    <form ref={formRef} onSubmit={onSubmit} noValidate className="relative flex flex-col gap-3">
      <Honeypot name="website" />
      <Field
        id="newsletter-email"
        label="Get occasional updates"
        hint="Product notes and practical SEO/AEO writing. Unsubscribe any time."
        error={state.status === 'error' ? state.message : undefined}
      >
        {({ id, describedBy, invalid }) => (
          <div className="flex flex-col gap-2 sm:flex-row">
            <Input
              id={id}
              name="email"
              type="email"
              autoComplete="email"
              required
              placeholder="you@company.com"
              aria-describedby={describedBy}
              aria-invalid={invalid || undefined}
            />
            <Button type="submit" disabled={state.status === 'submitting'} className="sm:w-auto">
              {state.status === 'submitting' ? 'Subscribing…' : 'Subscribe'}
            </Button>
          </div>
        )}
      </Field>
      <p role="status" aria-live="polite" className="min-h-5 text-xs text-success">
        {state.status === 'ok' ? state.message : ''}
      </p>
    </form>
  );
}
