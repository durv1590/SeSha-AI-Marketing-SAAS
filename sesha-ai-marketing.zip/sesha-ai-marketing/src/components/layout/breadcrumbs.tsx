import Link from 'next/link';

import { Icon } from '@/components/ui/icon';
import { getBreadcrumbs, type Crumb } from '@/lib/routes';

/**
 * Visible breadcrumb trail.
 *
 * Derived from the same route registry that generates BreadcrumbList
 * structured data, so the visible trail and the markup can never disagree —
 * which is the usual cause of invalid breadcrumb schema.
 */
export function Breadcrumbs({ path, trail }: { readonly path: string; readonly trail?: readonly Crumb[] }) {
  const crumbs = trail ?? getBreadcrumbs(path);
  if (crumbs.length <= 1) return null;

  return (
    <nav aria-label="Breadcrumb" className="mb-6">
      <ol className="flex flex-wrap items-center gap-1.5 text-sm text-fg-muted">
        {crumbs.map((crumb, index) => {
          const isLast = index === crumbs.length - 1;
          return (
            <li key={crumb.path} className="flex items-center gap-1.5">
              {index > 0 ? (
                <Icon name="chevron-down" size={14} className="-rotate-90 text-fg-subtle" />
              ) : null}
              {isLast ? (
                <span aria-current="page" className="font-medium text-fg">
                  {crumb.label}
                </span>
              ) : (
                <Link href={crumb.path} className="hover:text-fg hover:underline underline-offset-4">
                  {crumb.label}
                </Link>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
