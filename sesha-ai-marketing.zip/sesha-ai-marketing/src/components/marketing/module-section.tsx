import { Icon } from '@/components/ui/icon';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Container, Section } from '@/components/layout/container';
import type { PlatformModule } from '@/content/modules';
import { cn } from '@/lib/utils/cn';

/**
 * One platform module, rendered as a home-page section (sections 4–17).
 *
 * Layout alternates left/right by index to break up a long page without
 * animation. The summary sentence is written to stand alone, so each section is
 * independently extractable by an answer engine.
 */
export function ModuleSection({
  module,
  index,
}: {
  readonly module: PlatformModule;
  readonly index: number;
}) {
  const reversed = index % 2 === 1;

  return (
    <Section
      id={module.id}
      tone={reversed ? 'subtle' : 'default'}
      spacing="sm"
      aria-labelledby={`${module.id}-heading`}
    >
      <Container>
        <div
          className={cn(
            'grid items-center gap-10 lg:grid-cols-2 lg:gap-16',
            reversed && 'lg:[&>*:first-child]:order-2',
          )}
        >
          <div>
            <div className="flex items-center gap-3">
              <span className="inline-flex size-11 items-center justify-center rounded-control bg-primary-subtle text-primary-subtle-fg">
                <Icon name={module.icon} size={22} />
              </span>
              <Badge tone="outline">{module.name}</Badge>
            </div>

            <h2
              id={`${module.id}-heading`}
              className="mt-5 text-3xl font-semibold leading-tight tracking-tight text-balance"
            >
              {module.heading}
            </h2>

            <p className="mt-4 text-base leading-relaxed text-fg">{module.summary}</p>
            <p className="mt-3 text-base leading-relaxed text-fg-muted">{module.detail}</p>

            {module.href ? (
              <Button href={module.href} variant="link" className="mt-5">
                Learn more about {module.name}
                <Icon name="arrow-right" size={16} />
              </Button>
            ) : null}
          </div>

          <ul className="grid gap-3 rounded-card border border-border bg-surface p-6 shadow-sm">
            {module.capabilities.map((capability) => (
              <li key={capability} className="flex items-start gap-3 text-sm leading-relaxed">
                <Icon name="check" size={17} className="mt-0.5 shrink-0 text-primary" />
                <span className="text-fg-muted">{capability}</span>
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </Section>
  );
}
