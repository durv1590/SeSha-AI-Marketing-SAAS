import Link from 'next/link';

import { Icon } from '@/components/ui/icon';
import { Card, CardIcon } from '@/components/ui/card';
import type { PlatformModule } from '@/content/modules';
import { cn } from '@/lib/utils/cn';

/**
 * A module summarised as a card, used on /features and solution pages.
 *
 * When the module has a dedicated page, the whole card is made clickable by
 * stretching the link over it — while keeping exactly one real anchor, so the
 * tab order and the accessible name stay correct.
 */
export function FeatureCard({
  module,
  className,
  as: Heading = 'h3',
}: {
  readonly module: PlatformModule;
  readonly className?: string;
  /**
   * Heading level for the card title. Must be one level below whatever
   * heading introduces the grid, so the document outline never skips a level.
   */
  readonly as?: 'h2' | 'h3' | 'h4';
}) {
  const linked = Boolean(module.href);

  return (
    <Card
      interactive={linked}
      className={cn('relative flex h-full flex-col p-6', className)}
    >
      <CardIcon>
        <Icon name={module.icon} size={22} />
      </CardIcon>

      <Heading className="text-base font-semibold tracking-tight">
        {linked ? (
          <Link href={module.href!} className="after:absolute after:inset-0 after:content-['']">
            {module.name}
          </Link>
        ) : (
          module.name
        )}
      </Heading>

      <p className="mt-2 flex-1 text-sm leading-relaxed text-fg-muted">{module.summary}</p>

      {linked ? (
        <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary">
          Learn more
          <Icon name="arrow-right" size={15} />
        </span>
      ) : null}
    </Card>
  );
}

export function SimpleCard({
  title,
  body,
  icon,
  href,
}: {
  readonly title: string;
  readonly body: string;
  readonly icon?: Parameters<typeof Icon>[0]['name'];
  readonly href?: string;
}) {
  return (
    <Card interactive={Boolean(href)} className="relative flex h-full flex-col p-6">
      {icon ? (
        <CardIcon>
          <Icon name={icon} size={22} />
        </CardIcon>
      ) : null}
      <h3 className="text-base font-semibold tracking-tight">
        {href ? (
          <Link href={href} className="after:absolute after:inset-0 after:content-['']">
            {title}
          </Link>
        ) : (
          title
        )}
      </h3>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-fg-muted">{body}</p>
    </Card>
  );
}
