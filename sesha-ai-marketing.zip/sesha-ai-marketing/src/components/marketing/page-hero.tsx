import type { ReactNode } from 'react';

import { Breadcrumbs } from '@/components/layout/breadcrumbs';
import { Container, Section } from '@/components/layout/container';

/**
 * Standard page header: breadcrumb trail, the page's single h1, and an intro.
 *
 * Every non-home page uses this, which is what keeps the heading hierarchy
 * consistent site-wide — exactly one h1 per page, always the page title.
 */
export function PageHero({
  path,
  eyebrow,
  heading,
  intro,
  children,
}: {
  readonly path: string;
  readonly eyebrow?: string;
  readonly heading: string;
  readonly intro?: string;
  readonly children?: ReactNode;
}) {
  return (
    <Section tone="gradient" spacing="sm" className="border-b border-border">
      <Container>
        <Breadcrumbs path={path} />
        {eyebrow ? (
          <p className="text-sm font-semibold uppercase tracking-[0.12em] text-primary">{eyebrow}</p>
        ) : null}
        <h1 className="mt-3 max-w-4xl text-4xl font-semibold leading-[1.1] tracking-tight text-balance sm:text-5xl">
          {heading}
        </h1>
        {intro ? (
          <p className="mt-5 max-w-3xl text-lg leading-relaxed text-fg-muted">{intro}</p>
        ) : null}
        {children ? <div className="mt-8">{children}</div> : null}
      </Container>
    </Section>
  );
}
