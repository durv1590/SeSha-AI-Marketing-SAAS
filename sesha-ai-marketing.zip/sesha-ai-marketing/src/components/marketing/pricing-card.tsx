import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';
import type { PricingTier } from '@/content/pricing';
import { cn } from '@/lib/utils/cn';

/**
 * Pricing tier card.
 *
 * FABRICATION GUARD: when a tier is not `verified`, no currency figure is
 * rendered at all. An unconfirmed price is not displayed as a real one, and it
 * is separately excluded from structured data by `buildOffers()`.
 */
export function PricingCard({
  tier,
  as: Heading = 'h3',
}: {
  readonly tier: PricingTier;
  /** One level below the heading that introduces the plan grid. */
  readonly as?: 'h2' | 'h3';
}) {
  const showPrice = tier.verified && tier.monthlyPrice !== null;

  return (
    <Card
      className={cn(
        'flex h-full flex-col p-7',
        tier.featured && 'border-primary/40 ring-1 ring-primary/25',
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <Heading className="text-lg font-semibold tracking-tight">{tier.name}</Heading>
          <p className="mt-1 text-sm text-fg-muted">{tier.audience}</p>
        </div>
        {tier.featured ? <Badge tone="brand">Most popular</Badge> : null}
      </div>

      <div className="mt-6">
        {showPrice ? (
          <p className="flex items-baseline gap-1.5">
            <span className="text-4xl font-semibold tracking-tight">
              {new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: tier.currency,
                maximumFractionDigits: 0,
              }).format(tier.monthlyPrice!)}
            </span>
            <span className="text-sm text-fg-muted">/ month</span>
          </p>
        ) : (
          <p className="text-2xl font-semibold tracking-tight text-fg">
            Pricing on request
            <span className="mt-1.5 block text-sm font-normal leading-relaxed text-fg-muted">
              We publish prices once they are confirmed. Contact us for current pricing.
            </span>
          </p>
        )}
      </div>

      <p className="mt-5 text-sm leading-relaxed text-fg-muted">{tier.description}</p>

      <Button
        href={tier.cta.href}
        variant={tier.featured ? 'primary' : 'secondary'}
        block
        className="mt-6"
      >
        {tier.cta.label}
      </Button>

      <dl className="mt-7 grid grid-cols-3 gap-3 border-y border-border py-4">
        {tier.limits.map((limit) => (
          <div key={limit.label}>
            <dt className="text-xs uppercase tracking-[0.08em] text-fg-subtle">{limit.label}</dt>
            <dd className="mt-1 text-sm font-medium">{limit.value}</dd>
          </div>
        ))}
      </dl>

      <ul className="mt-6 flex flex-1 flex-col gap-2.5">
        {tier.includes.map((item) => (
          <li key={item} className="flex items-start gap-2.5 text-sm leading-relaxed">
            <Icon name="check" size={16} className="mt-0.5 shrink-0 text-primary" />
            <span className="text-fg-muted">{item}</span>
          </li>
        ))}
      </ul>
    </Card>
  );
}
