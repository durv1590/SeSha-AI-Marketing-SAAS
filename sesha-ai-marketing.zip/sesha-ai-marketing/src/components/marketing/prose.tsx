import type { Block } from '@/content/blocks';
import { Icon } from '@/components/ui/icon';
import { cn } from '@/lib/utils/cn';

/**
 * Renders typed content blocks as semantic HTML.
 *
 * The renderer — not the content author — controls which elements are emitted,
 * so the document outline stays valid: block headings are always <h2>, never a
 * level chosen ad hoc. Everything here is server-rendered, which is what makes
 * the content readable to answer engines without JavaScript.
 */
export function Prose({
  blocks,
  className,
}: {
  readonly blocks: readonly Block[];
  readonly className?: string;
}) {
  return (
    <div className={cn('flex flex-col gap-6', className)}>
      {blocks.map((block, index) => {
        switch (block.kind) {
          case 'heading':
            return (
              <h2
                key={block.id}
                id={block.id}
                className="mt-4 scroll-mt-24 text-2xl font-semibold tracking-tight"
              >
                {block.text}
              </h2>
            );

          case 'paragraph':
            return (
              <p key={index} className="text-base leading-relaxed text-fg-muted">
                {block.text}
              </p>
            );

          case 'list': {
            const items = block.items.map((item, itemIndex) => (
              <li key={itemIndex} className="pl-1.5">
                {item}
              </li>
            ));
            return block.ordered ? (
              <ol
                key={index}
                className="ml-5 flex list-decimal flex-col gap-2.5 text-base leading-relaxed text-fg-muted marker:text-fg-subtle"
              >
                {items}
              </ol>
            ) : (
              <ul
                key={index}
                className="ml-5 flex list-disc flex-col gap-2.5 text-base leading-relaxed text-fg-muted marker:text-fg-subtle"
              >
                {items}
              </ul>
            );
          }

          case 'callout':
            return (
              <aside
                key={index}
                className="flex gap-3 rounded-card border border-primary/25 bg-primary-subtle p-5"
              >
                <Icon name="spark" size={20} className="mt-0.5 text-primary-subtle-fg" />
                <div>
                  <p className="font-semibold text-primary-subtle-fg">{block.title}</p>
                  <p className="mt-1 text-sm leading-relaxed text-fg-muted">{block.text}</p>
                </div>
              </aside>
            );

          case 'definition':
            return (
              <dl
                key={index}
                className="rounded-card border border-border bg-bg-subtle p-5"
              >
                <dt className="text-sm font-semibold uppercase tracking-[0.1em] text-fg-subtle">
                  {block.term}
                </dt>
                <dd className="mt-2 text-base leading-relaxed text-fg">{block.text}</dd>
              </dl>
            );

          default:
            return null;
        }
      })}
    </div>
  );
}
