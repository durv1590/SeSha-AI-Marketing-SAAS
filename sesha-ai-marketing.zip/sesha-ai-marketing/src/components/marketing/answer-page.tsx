import { Accordion } from '@/components/ui/accordion';
import { Container, Section } from '@/components/layout/container';
import {
  ArticleMeta,
  DefinitionBlock,
  DirectAnswer,
  ExampleList,
  RelatedLinks,
} from '@/components/marketing/answer-block';
import { PageHero } from '@/components/marketing/page-hero';
import { Prose } from '@/components/marketing/prose';
import { authors } from '@/content/site';
import { headings } from '@/content/blocks';
import type { AnswerPage as AnswerPageContent } from '@/content/pages';

/**
 * Template for answer-first (AEO) pages.
 *
 * Enforces the structure rather than trusting an author to reproduce it:
 * definition, direct answer, table of contents, explanation, examples, FAQs,
 * related concepts, authorship and last-updated — in that order, every time.
 */
export function AnswerPageTemplate({
  path,
  page,
  eyebrow,
}: {
  readonly path: string;
  readonly page: AnswerPageContent;
  readonly eyebrow?: string;
}) {
  const author = authors[page.authorId];
  const toc = headings(page.blocks);

  return (
    <>
      <PageHero path={path} eyebrow={eyebrow} heading={page.title}>
        {author ? (
          <ArticleMeta
            authorName={author.name}
            authorRole={author.role}
            authorHref={author.url}
            lastUpdated={page.lastUpdated}
          />
        ) : null}
      </PageHero>

      <Section spacing="md">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[minmax(0,1fr)_16rem] lg:gap-16">
            <div className="flex max-w-3xl flex-col gap-10">
              <DefinitionBlock term={page.definitionTerm} definition={page.definition} />
              <DirectAnswer>{page.directAnswer}</DirectAnswer>
              <Prose blocks={page.blocks} />
              <ExampleList examples={page.examples} />

              <section aria-labelledby="page-faq-heading">
                <h2 id="page-faq-heading" className="text-2xl font-semibold tracking-tight">
                  Frequently asked questions
                </h2>
                <Accordion
                  className="mt-6"
                  items={page.faqs.map((f) => ({ question: f.question, answer: f.answer }))}
                />
              </section>

              <RelatedLinks links={page.related} />
            </div>

            {/* On-page navigation. Hidden on small screens where it would push
                the content down rather than help. */}
            {toc.length > 0 ? (
              <nav aria-label="On this page" className="hidden lg:block">
                <div className="sticky top-24">
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-fg-subtle">
                    On this page
                  </p>
                  <ul className="mt-4 flex flex-col gap-2.5 border-l border-border pl-4">
                    {toc.map((item) => (
                      <li key={item.id}>
                        <a
                          href={`#${item.id}`}
                          className="text-sm text-fg-muted transition-colors hover:text-fg"
                        >
                          {item.text}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </nav>
            ) : null}
          </div>
        </Container>
      </Section>
    </>
  );
}
