'use client';

import { useEffect, useRef, useState } from 'react';

import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Checkbox, Field, Honeypot, Input, Select, Textarea } from '@/components/ui/field';
import { CONTACT_TOPICS, type ContactSubmission } from '@/lib/validation/forms';

/**
 * Contact form.
 *
 * Validation runs on the SERVER — this component only displays what the server
 * returned. Client-side checks are a convenience, never a control, so the
 * browser is never the thing deciding whether input is acceptable.
 *
 * Anti-abuse: an off-screen honeypot plus a render timestamp the API uses for a
 * submit-speed check. Both are silent — a bot gets a normal-looking response.
 */

const topicLabels: Record<(typeof CONTACT_TOPICS)[number], string> = {
  product: 'Product question',
  pricing: 'Pricing',
  partnership: 'Partnership',
  support: 'Support',
  security: 'Security disclosure',
  other: 'Something else',
};

type Errors = Partial<Record<keyof ContactSubmission, string>>;
type Status = 'idle' | 'submitting' | 'ok' | 'error';

export function ContactForm() {
  const [status, setStatus] = useState<Status>('idle');
  const [errors, setErrors] = useState<Errors>({});
  const [message, setMessage] = useState<string>('');
  const renderedAt = useRef<number>(0);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    renderedAt.current = Date.now();
  }, []);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus('submitting');
    setErrors({});

    const data = new FormData(event.currentTarget);
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: data.get('name'),
          email: data.get('email'),
          company: data.get('company'),
          topic: data.get('topic'),
          message: data.get('message'),
          consent: data.get('consent') === 'on',
          website: data.get('website'),
          renderedAt: renderedAt.current,
        }),
      });

      const payload = (await response.json()) as {
        ok?: boolean;
        errors?: Errors;
        message?: string;
      };

      if (response.ok && payload.ok) {
        setStatus('ok');
        setMessage(payload.message ?? 'Thanks — your message is with the team.');
        formRef.current?.reset();
        renderedAt.current = Date.now();
        return;
      }

      setStatus('error');
      setErrors(payload.errors ?? {});
      setMessage(
        payload.message ??
          (payload.errors ? 'Please check the highlighted fields.' : 'Something went wrong.'),
      );
    } catch {
      setStatus('error');
      setMessage('Network error. Please try again, or email us directly.');
    }
  }

  if (status === 'ok') {
    return (
      <Alert tone="success" title="Message sent" live>
        {message}
      </Alert>
    );
  }

  return (
    <form ref={formRef} onSubmit={onSubmit} noValidate className="relative flex flex-col gap-5">
      <Honeypot name="website" />

      {status === 'error' && message ? (
        <Alert tone="danger" title="We could not send that" live>
          {message}
        </Alert>
      ) : null}

      <div className="grid gap-5 sm:grid-cols-2">
        <Field id="contact-name" label="Your name" required error={errors.name}>
          {({ id, describedBy, invalid }) => (
            <Input
              id={id}
              name="name"
              autoComplete="name"
              required
              aria-describedby={describedBy}
              aria-invalid={invalid || undefined}
            />
          )}
        </Field>

        <Field id="contact-email" label="Work email" required error={errors.email}>
          {({ id, describedBy, invalid }) => (
            <Input
              id={id}
              name="email"
              type="email"
              autoComplete="email"
              required
              aria-describedby={describedBy}
              aria-invalid={invalid || undefined}
            />
          )}
        </Field>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field id="contact-company" label="Company" hint="Optional">
          {({ id }) => <Input id={id} name="company" autoComplete="organization" />}
        </Field>

        <Field id="contact-topic" label="What is this about?" required error={errors.topic}>
          {({ id, describedBy, invalid }) => (
            <Select
              id={id}
              name="topic"
              defaultValue="product"
              required
              aria-describedby={describedBy}
              aria-invalid={invalid || undefined}
            >
              {CONTACT_TOPICS.map((topic) => (
                <option key={topic} value={topic}>
                  {topicLabels[topic]}
                </option>
              ))}
            </Select>
          )}
        </Field>
      </div>

      <Field
        id="contact-message"
        label="Message"
        hint="What are you trying to do, and what does your marketing look like today?"
        required
        error={errors.message}
      >
        {({ id, describedBy, invalid }) => (
          <Textarea
            id={id}
            name="message"
            required
            minLength={20}
            maxLength={5000}
            aria-describedby={describedBy}
            aria-invalid={invalid || undefined}
          />
        )}
      </Field>

      <Checkbox
        id="contact-consent"
        name="consent"
        required
        error={errors.consent}
        label={
          <>
            I agree that my details will be used to respond to this enquiry, as described in the{' '}
            <a href="/privacy" className="text-primary underline underline-offset-4">
              privacy policy
            </a>
            .
          </>
        }
      />

      <div className="flex items-center gap-4">
        <Button type="submit" size="lg" disabled={status === 'submitting'}>
          {status === 'submitting' ? 'Sending…' : 'Send message'}
        </Button>
        <p className="text-xs text-fg-muted">We reply to every message from a real person.</p>
      </div>
    </form>
  );
}
