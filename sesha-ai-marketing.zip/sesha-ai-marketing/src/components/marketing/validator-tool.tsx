'use client';

import { useId, useState } from 'react';

import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Icon } from '@/components/ui/icon';
import type { Severity, ValidationReport } from '@/lib/schema-validator/validate';
import { cn } from '@/lib/utils/cn';

/**
 * The structured-data validator UI.
 *
 * Validation runs server-side in /api/schema-validator, which keeps the rule
 * set in one place (the same module the site's own tests run against) and
 * keeps this component to presentation.
 *
 * The result panel is a live region so a screen-reader user hears that a report
 * arrived rather than having to go looking for it.
 */

const SAMPLES: Record<string, string> = {
  'Valid article': JSON.stringify(
    {
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: 'How answer engine optimisation works',
      description: 'A practical explanation of AEO.',
      url: 'https://example.com/blog/aeo',
      datePublished: '2026-01-05',
      dateModified: '2026-02-10',
      author: { '@type': 'Organization', name: 'Editorial Team' },
      publisher: { '@type': 'Organization', name: 'Example', url: 'https://example.com' },
      image: { '@type': 'ImageObject', url: 'https://example.com/cover.png' },
      mainEntityOfPage: { '@id': 'https://example.com/blog/aeo#webpage' },
    },
    null,
    2,
  ),
  'Broken breadcrumbs': JSON.stringify(
    {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 0, name: 'Home', item: 'https://example.com/' },
        { '@type': 'ListItem', position: 2, item: 'https://example.com/blog' },
      ],
    },
    null,
    2,
  ),
  'Invalid FAQ': JSON.stringify(
    {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: [
        { '@type': 'Question', name: 'What is AEO?', acceptedAnswer: { '@type': 'Answer' } },
        { '@type': 'Question', acceptedAnswer: { '@type': 'Answer', text: 'Yes.' } },
      ],
    },
    null,
    2,
  ),
};

const severityStyles: Record<Severity, { badge: string; icon: 'error' | 'alert' | 'info'; label: string }> = {
  error: { badge: 'bg-danger-subtle text-danger', icon: 'error', label: 'Error' },
  warning: { badge: 'bg-warning-subtle text-warning', icon: 'alert', label: 'Warning' },
  info: { badge: 'bg-info-subtle text-info', icon: 'info', label: 'Info' },
};

export function ValidatorTool() {
  const inputId = useId();
  const [source, setSource] = useState('');
  const [report, setReport] = useState<ValidationReport | null>(null);
  const [busy, setBusy] = useState(false);
  const [failure, setFailure] = useState<string | null>(null);

  async function validate() {
    setBusy(true);
    setFailure(null);
    try {
      const response = await fetch('/api/schema-validator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source }),
      });
      const payload = (await response.json()) as { data?: ValidationReport; message?: string };
      if (!response.ok || !payload.data) {
        setReport(null);
        setFailure(payload.message ?? 'Validation failed. Please try again.');
        return;
      }
      setReport(payload.data);
    } catch {
      setReport(null);
      setFailure('Network error. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <div className="flex flex-col gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-medium text-fg-muted">Load an example:</span>
          {Object.keys(SAMPLES).map((name) => (
            <Button
              key={name}
              variant="secondary"
              size="sm"
              onClick={() => {
                setSource(SAMPLES[name]!);
                setReport(null);
                setFailure(null);
              }}
            >
              {name}
            </Button>
          ))}
        </div>

        <div className="flex flex-col gap-1.5">
          <label htmlFor={inputId} className="text-sm font-medium">
            JSON-LD to validate
          </label>
          <p id={`${inputId}-hint`} className="text-xs text-fg-muted">
            Paste a JSON-LD object, an array, or a whole
            <code className="mx-1 rounded bg-bg-muted px-1 py-0.5 font-mono text-[0.8em]">
              &lt;script type=&quot;application/ld+json&quot;&gt;
            </code>
            block.
          </p>
          <textarea
            id={inputId}
            aria-describedby={`${inputId}-hint`}
            value={source}
            onChange={(event) => setSource(event.target.value)}
            spellCheck={false}
            rows={18}
            placeholder='{ "@context": "https://schema.org", "@type": "Organization", ... }'
            className="w-full rounded-control border border-border bg-surface p-3.5 font-mono text-xs leading-relaxed text-fg placeholder:text-fg-subtle"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Button onClick={validate} disabled={busy || source.trim().length === 0}>
            {busy ? 'Validating…' : 'Validate'}
          </Button>
          <Button
            variant="ghost"
            onClick={() => {
              setSource('');
              setReport(null);
              setFailure(null);
            }}
            disabled={source.length === 0}
          >
            Clear
          </Button>
        </div>
      </div>

      <div aria-live="polite" aria-atomic="false" className="flex flex-col gap-4">
        <h2 className="text-sm font-semibold uppercase tracking-[0.12em] text-fg-subtle">Result</h2>

        {failure ? (
          <Alert tone="danger" title="Could not validate">
            {failure}
          </Alert>
        ) : null}

        {!report && !failure ? (
          <div className="rounded-card border border-dashed border-border-strong p-8 text-center text-sm text-fg-muted">
            Paste structured data and select Validate. Nothing you enter is stored.
          </div>
        ) : null}

        {report ? (
          <>
            <div
              className={cn(
                'flex items-start gap-3 rounded-card border p-4',
                report.valid
                  ? 'border-success/30 bg-success-subtle'
                  : 'border-danger/30 bg-danger-subtle',
              )}
            >
              <Icon name={report.valid ? 'success' : 'error'} size={20} className="mt-0.5" />
              <div>
                <p className="font-semibold">
                  {report.valid ? 'No errors found' : `${report.counts.errors} error${report.counts.errors === 1 ? '' : 's'} found`}
                </p>
                <p className="mt-1 text-sm text-fg-muted">
                  {report.nodeCount} node{report.nodeCount === 1 ? '' : 's'} checked ·{' '}
                  {report.counts.warnings} warning{report.counts.warnings === 1 ? '' : 's'} ·{' '}
                  {report.counts.infos} note{report.counts.infos === 1 ? '' : 's'}
                </p>
              </div>
            </div>

            {report.typesFound.length > 0 ? (
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs text-fg-muted">Types found:</span>
                {report.typesFound.map((type) => (
                  <Badge key={type} tone="outline">
                    {type}
                  </Badge>
                ))}
              </div>
            ) : null}

            {report.messages.length > 0 ? (
              <ul className="flex flex-col gap-2.5">
                {report.messages.map((item, index) => {
                  const style = severityStyles[item.severity];
                  return (
                    <li
                      key={`${item.path}-${index}`}
                      className="rounded-control border border-border bg-surface p-3.5"
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className={cn(
                            'inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[0.7rem] font-semibold uppercase tracking-wide',
                            style.badge,
                          )}
                        >
                          <Icon name={style.icon} size={12} />
                          {style.label}
                        </span>
                        <code className="truncate font-mono text-xs text-fg-muted">{item.path}</code>
                      </div>
                      <p className="mt-2 text-sm leading-relaxed">{item.message}</p>
                    </li>
                  );
                })}
              </ul>
            ) : null}

            <p className="text-xs leading-relaxed text-fg-subtle">
              This tool checks structure and property completeness for the schema types it supports.
              It does not contact any search engine, and a clean result is not a guarantee of rich-result
              eligibility.
            </p>
          </>
        ) : null}
      </div>
    </div>
  );
}
