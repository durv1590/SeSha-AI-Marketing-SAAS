import { Accordion } from '@/components/ui/accordion';
import { Container, Section } from '@/components/layout/container';
import { SectionHeader } from '@/components/layout/section-header';

/**
 * FAQ section.
 *
 * Answers are server-rendered into native <details> elements, so they exist in
 * the HTML whether or not the disclosure is open and whether or not JavaScript
 * runs. That is what makes the matching FAQPage structured data honest: the
 * marked-up content is genuinely present on the page.
 */
export function FaqSection({
  id = 'faq',
  eyebrow,
  heading,
  intro,
  items,
  tone = 'subtle',
}: {
  readonly id?: string;
  readonly eyebrow?: string;
  readonly heading: string;
  readonly intro?: string;
  readonly items: readonly { readonly question: string; readonly answer: string }[];
  readonly tone?: 'default' | 'subtle';
}) {
  if (items.length === 0) return null;

  return (
    <Section id={id} tone={tone} aria-labelledby={`${id}-heading`}>
      <Container>
        <SectionHeader id={`${id}-heading`} eyebrow={eyebrow} heading={heading} intro={intro} />
        <Accordion
          className="mt-10"
          items={items.map((item) => ({ question: item.question, answer: item.answer }))}
        />
      </Container>
    </Section>
  );
}
