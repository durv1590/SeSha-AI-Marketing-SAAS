/** Numbered process steps — home section 18. Ordered list, so order is semantic. */
export function Steps({
  steps,
}: {
  readonly steps: readonly { readonly number: number; readonly title: string; readonly body: string }[];
}) {
  return (
    <ol className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
      {steps.map((step) => (
        <li
          key={step.number}
          className="relative rounded-card border border-border bg-surface p-6 shadow-sm"
        >
          <span
            aria-hidden="true"
            className="inline-flex size-9 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-fg"
          >
            {step.number}
          </span>
          <h3 className="mt-4 font-semibold tracking-tight">
            <span className="sr-only">Step {step.number}: </span>
            {step.title}
          </h3>
          <p className="mt-2 text-sm leading-relaxed text-fg-muted">{step.body}</p>
        </li>
      ))}
    </ol>
  );
}
