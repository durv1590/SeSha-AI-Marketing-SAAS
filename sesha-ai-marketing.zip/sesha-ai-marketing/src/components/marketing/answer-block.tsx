import Link from 'next/link';

import { Icon } from '@/components/ui/icon';
import { cn } from '@/lib/utils/cn';

/**
 * AEO building blocks.
 *
 * These components exist so that "answer-first structure" is a thing the code
 * enforces rather than a thing an author has to remember. Every AEO page uses
 * the same sequence: definition, direct answer, explanation, examples, FAQs,
 * related concepts, author and last-updated.
 *
 * All of it is server-rendered. Nothing essential is revealed by interaction.
 */

/** The definition, marked up as a description list so the pairing is explicit. */
export function DefinitionBlock({
  term,
  definition,
  className,
}: {
  readonly term: string;
  readonly definition: string;
  readonly className?: string;
}) {
  return (
    <dl className={cn('rounded-card border border-border bg-bg-subtle p-6', className)}>
      <dt className="text-xs font-semibold uppercase tracking-[0.12em] text-fg-subtle">{term}</dt>
      <dd className="mt-2.5 text-lg leading-relaxed text-fg">{definition}</dd>
    </dl>
  );
}

/**
 * The direct answer. Placed high on the page and written to survive being
 * quoted with no surrounding context.
 */
export function DirectAnswer({
  children,
  className,
}: {
  readonly children: React.ReactNode;
  readonly className?: string;
}) {
  return (
    <div
      className={cn(
        'rounded-card border-l-4 border-primary bg-primary-subtle/60 p-6',
        className,
      )}
    >
      <p className="mb-2 text-xs font-semibold uppercase tracking-[0.12em] text-primary-subtle-fg">
        The short answer
      </p>
      <p className="text-base leading-relaxed text-fg">{children}</p>
    </div>
  );
}

export function ExampleList({
  examples,
  heading = 'Examples',
}: {
  readonly examples: readonly { readonly title: string; readonly body: string }[];
  readonly heading?: string;
}) {
  if (examples.length === 0) return null;
  return (
    <section aria-labelledby="examples-heading">
      <h2 id="examples-heading" className="text-2xl font-semibold tracking-tight">
        {heading}
      </h2>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {examples.map((example) => (
          <div
            key={example.title}
            className="rounded-card border border-border bg-surface p-5"
          >
            <h3 className="font-semibold">{example.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-fg-muted">{example.body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export function RelatedLinks({
  links,
  heading = 'Related concepts',
}: {
  readonly links: readonly { readonly label: string; readonly href: string }[];
  readonly heading?: string;
}) {
  if (links.length === 0) return null;
  return (
    <section aria-labelledby="related-heading">
      <h2 id="related-heading" className="text-2xl font-semibold tracking-tight">
        {heading}
      </h2>
      <ul className="mt-5 flex flex-col gap-2">
        {links.map((link) => (
          <li key={`${link.href}-${link.label}`}>
            <Link
              href={link.href}
              className="group inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary-hover"
            >
              {link.label}
              <Icon
                name="arrow-right"
                size={16}
                className="transition-transform duration-150 group-hover:translate-x-0.5"
              />
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}

/**
 * Authorship and freshness. Answer engines favour content they can attribute,
 * so this is a content requirement rather than a decorative byline.
 */
export function ArticleMeta({
  authorName,
  authorRole,
  authorHref,
  lastUpdated,
  publishedAt,
  className,
}: {
  readonly authorName: string;
  readonly authorRole?: string;
  readonly authorHref?: string;
  readonly lastUpdated: string;
  readonly publishedAt?: string;
  readonly className?: string;
}) {
  const formatted = (value: string) =>
    new Date(`${value}T00:00:00Z`).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      timeZone: 'UTC',
    });

  return (
    <div
      className={cn(
        'flex flex-wrap items-center gap-x-5 gap-y-1.5 text-sm text-fg-muted',
        className,
      )}
    >
      <span>
        By{' '}
        {authorHref ? (
          <Link href={authorHref} className="font-medium text-fg hover:underline underline-offset-4">
            {authorName}
          </Link>
        ) : (
          <span className="font-medium text-fg">{authorName}</span>
        )}
        {authorRole ? <span className="text-fg-subtle"> · {authorRole}</span> : null}
      </span>
      {publishedAt ? (
        <span>
          Published <time dateTime={publishedAt}>{formatted(publishedAt)}</time>
        </span>
      ) : null}
      <span>
        Last updated <time dateTime={lastUpdated}>{formatted(lastUpdated)}</time>
      </span>
    </div>
  );
}
