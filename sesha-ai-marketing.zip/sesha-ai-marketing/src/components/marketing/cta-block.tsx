import { Button } from '@/components/ui/button';
import { Icon } from '@/components/ui/icon';
import { Container, Section } from '@/components/layout/container';

export function CtaBlock({
  id,
  heading,
  body,
  primary,
  secondary,
}: {
  readonly id?: string;
  readonly heading: string;
  readonly body: string;
  readonly primary: { readonly label: string; readonly href: string };
  readonly secondary?: { readonly label: string; readonly href: string };
}) {
  return (
    <Section id={id} tone="gradient" spacing="md" aria-labelledby={id ? `${id}-heading` : undefined}>
      <Container>
        <div className="mx-auto max-w-2xl text-center">
          <h2
            id={id ? `${id}-heading` : undefined}
            className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl"
          >
            {heading}
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-fg-muted">{body}</p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Button href={primary.href} size="lg">
              {primary.label}
              <Icon name="arrow-right" size={18} />
            </Button>
            {secondary ? (
              <Button href={secondary.href} size="lg" variant="secondary">
                {secondary.label}
              </Button>
            ) : null}
          </div>
        </div>
      </Container>
    </Section>
  );
}
