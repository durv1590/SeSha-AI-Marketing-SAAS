import { Button } from '@/components/ui/button';
import { Icon } from '@/components/ui/icon';
import { Container, Section } from '@/components/layout/container';
import { hero } from '@/content/home';

/**
 * Home hero — section 1.
 *
 * The h1 lives here and is the only h1 on the page. The headline is plain text
 * in the server-rendered HTML (no image, no canvas, no client-only rendering)
 * because it is the single most important string on the site for both search
 * and answer engines.
 */
export function Hero() {
  return (
    <Section tone="gradient" spacing="lg" className="relative overflow-hidden">
      <Container>
        <div className="max-w-3xl">
          <p className="inline-flex items-center gap-2 rounded-full border border-border bg-surface/70 px-3 py-1 text-xs font-medium text-fg-muted backdrop-blur">
            <Icon name="spark" size={14} className="text-primary" />
            {hero.eyebrow}
          </p>

          <h1 className="mt-6 text-4xl font-semibold leading-[1.06] tracking-tight text-balance sm:text-5xl lg:text-[3.5rem]">
            {hero.headline}
          </h1>

          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-fg-muted sm:text-xl">
            {hero.supporting}
          </p>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button href={hero.primaryCta.href} size="lg">
              {hero.primaryCta.label}
              <Icon name="arrow-right" size={18} />
            </Button>
            <Button href={hero.secondaryCta.href} size="lg" variant="secondary">
              {hero.secondaryCta.label}
            </Button>
          </div>

          <ul className="mt-10 flex flex-col gap-2.5">
            {hero.assurances.map((item) => (
              <li key={item} className="flex items-start gap-2.5 text-sm text-fg-muted">
                <Icon name="check" size={17} className="mt-0.5 text-primary" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </Section>
  );
}
