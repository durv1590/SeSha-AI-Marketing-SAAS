'use client';

import { useCallback, useState } from 'react';

import { readCsrfCookie } from '@/components/app/app-shell';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  ACTION_EFFECT,
  ACTION_LABEL,
  MAX_RUNS_PER_DAY,
  OPERATOR_LABEL,
  RULE_TEMPLATES,
  TRIGGER_LABEL,
  isActionKind,
  isTriggerKind,
  type Condition,
} from '@/lib/automation/types';

/**
 * Automations.
 *
 * THE FIRST THING ON THE SCREEN IS WHAT THIS CANNOT DO
 * A person arriving at an automation screen in a marketing product reasonably
 * assumes it sends things. It does not, it cannot, and finding that out after
 * building three rules is worse than being told at the top.
 *
 * Every action also shows its own effect sentence next to the toggle, so the
 * boundary is visible at the moment someone chooses an action rather than only
 * in a banner they scrolled past.
 */

export interface RuleView {
  readonly id: string;
  readonly name: string;
  readonly trigger: string;
  readonly conditions: readonly Condition[];
  readonly actions: readonly { readonly kind: string; readonly template: string; readonly offsetDays?: number }[];
  readonly enabled: boolean;
}

export interface AutomationBoardProps {
  readonly projectId: string | null;
  readonly rules: readonly RuleView[];
  readonly canEdit: boolean;
}

export function AutomationBoard({ projectId, rules, canEdit }: AutomationBoardProps) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const call = useCallback(
    async (url: string, method: string, body: Record<string, unknown>) => {
      setBusy(true);
      setError(null);
      setMessage(null);
      try {
        const response = await fetch(url, {
          method,
          headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
          body: JSON.stringify(body),
        });
        const payload = (await response.json()) as { message?: string };
        if (!response.ok) {
          setError(payload.message ?? 'That could not be saved.');
          return;
        }
        setMessage(payload.message ?? 'Saved.');
      } catch {
        setError('The request did not complete.');
      } finally {
        setBusy(false);
      }
    },
    [],
  );

  if (!projectId) {
    return (
      <Alert tone="info" title="No project yet">
        Create a project and automations have something to watch.
      </Alert>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <Alert tone="info" title="What SeSha automations do, and do not do">
        <p>
          Every automation produces something that waits for a person: a task, a follow-up, a draft, a
          calendar entry, a notification. None of them sends an email or a message, posts to a social
          platform, or spends money on advertising — SeSha cannot do any of those things, so no rule
          you build here can either.
        </p>
        <p className="mt-2">
          At most {MAX_RUNS_PER_DAY} runs a day across this organization. Runs that matched nothing are
          recorded too, so a rule that has quietly stopped firing is visible rather than invisible.
        </p>
      </Alert>

      {message && <Alert tone="success" live>{message}</Alert>}
      {error && <Alert tone="danger" live>{error}</Alert>}

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold tracking-tight">Your rules</h2>
        {rules.length === 0 ? (
          <p className="text-sm text-fg-muted">
            No rules yet. The starting points below are the common ones; each is added switched off.
          </p>
        ) : (
          <div className="flex flex-col gap-4">
            {rules.map((rule) => (
              <Card key={rule.id}>
                <CardHeader>
                  <div className="flex flex-wrap items-center gap-2">
                    <CardTitle as="h3">{rule.name}</CardTitle>
                    <Badge tone={rule.enabled ? 'success' : 'neutral'}>
                      {rule.enabled ? 'On' : 'Off'}
                    </Badge>
                  </div>
                  <CardDescription>
                    When: {isTriggerKind(rule.trigger) ? TRIGGER_LABEL[rule.trigger] : rule.trigger}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col gap-3 pt-3">
                  {rule.conditions.length > 0 && (
                    <div>
                      <p className="text-sm font-semibold">Only if</p>
                      <ul className="mt-1 flex flex-col gap-1 text-sm text-fg-muted">
                        {rule.conditions.map((condition, index) => (
                          <li key={`${condition.field}-${index}`}>
                            {condition.field} {OPERATOR_LABEL[condition.operator]}{' '}
                            {condition.value === undefined ? '' : String(condition.value)}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div>
                    <p className="text-sm font-semibold">Then</p>
                    <ul className="mt-1 flex flex-col gap-2 text-sm">
                      {rule.actions.map((action, index) => (
                        <li key={`${action.kind}-${index}`}>
                          <span className="font-medium">
                            {isActionKind(action.kind) ? ACTION_LABEL[action.kind] : action.kind}
                          </span>
                          : {action.template}
                          {isActionKind(action.kind) && (
                            <span className="block text-xs text-fg-muted">
                              {ACTION_EFFECT[action.kind]}
                            </span>
                          )}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {canEdit && (
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant={rule.enabled ? 'secondary' : 'primary'}
                        disabled={busy}
                        onClick={() =>
                          void call(`/api/automations/${rule.id}`, 'PATCH', { enabled: !rule.enabled })
                        }
                      >
                        {rule.enabled ? 'Switch off' : 'Switch on'}
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        disabled={busy}
                        onClick={() => void call(`/api/automations/${rule.id}`, 'DELETE', {})}
                      >
                        Remove
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>

      {canEdit && (
        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-semibold tracking-tight">Starting points</h2>
          <p className="max-w-3xl text-sm leading-relaxed text-fg-muted">
            Each is added switched off, so nothing starts happening because you looked at this page.
          </p>
          <div className="grid gap-4 sm:grid-cols-2">
            {RULE_TEMPLATES.map((template) => (
              <Card key={template.name} tone="subtle">
                <CardHeader>
                  <CardTitle as="h3" className="text-base">
                    {template.name}
                  </CardTitle>
                  <CardDescription>{template.description}</CardDescription>
                </CardHeader>
                <CardContent className="pt-3">
                  <ul className="flex flex-col gap-1 text-xs text-fg-muted">
                    {template.actions.map((action) => (
                      <li key={action.kind}>{ACTION_EFFECT[action.kind]}</li>
                    ))}
                  </ul>
                  <Button
                    className="mt-3"
                    size="sm"
                    disabled={busy}
                    onClick={() => void call('/api/automations', 'POST', { projectId, template: template.name })}
                  >
                    Add, switched off
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
