'use client';

import { useCallback, useState } from 'react';

import { readCsrfCookie } from '@/components/app/app-shell';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Field, Input, Select, Textarea } from '@/components/ui/field';
import {
  LEAD_SOURCES,
  LEAD_STAGES,
  SOURCE_LABEL,
  STAGE_LABEL,
  canTransition,
  type LeadSource,
  type LeadStage,
} from '@/lib/leads/types';

/**
 * The lead pipeline.
 *
 * WHY THE SCORE IS NEVER SHOWN ALONE
 * Every place the number appears, the rubric is one click away and the sentence
 * explaining what the number is sits under the list. A score with no visible
 * reasoning is an opinion wearing a measurement's clothes — and a salesperson who
 * cannot see why a lead scored 34 will either ignore the score or trust it for the
 * wrong reason.
 *
 * Stage moves that the pipeline refuses are DISABLED with the reason in the title
 * attribute, rather than accepted and then rejected by the server. The rules are
 * the same in both places; the interface just says so earlier.
 */

export interface LeadView {
  readonly id: string;
  readonly name: string;
  readonly email: string | null;
  readonly phone: string | null;
  readonly company: string | null;
  readonly source: string;
  readonly stage: LeadStage;
  readonly score: number;
  readonly scoreBasis: string;
  readonly lastActivityAt: string | null;
  readonly createdAt: string;
}

export interface LeadBoardProps {
  readonly projectId: string | null;
  readonly leads: readonly LeadView[];
  readonly counts: Readonly<Record<LeadStage, number>>;
  readonly scoreBasis: string;
  readonly canEdit: boolean;
}

const BAND_TONE = (score: number): 'success' | 'warning' | 'neutral' =>
  score >= 70 ? 'success' : score >= 40 ? 'warning' : 'neutral';

export function LeadBoard({ projectId, leads, counts, scoreBasis, canEdit }: LeadBoardProps) {
  const [rows, setRows] = useState<readonly LeadView[]>(leads);
  const [stageCounts, setStageCounts] = useState(counts);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [enquiry, setEnquiry] = useState('');
  const [source, setSource] = useState<LeadSource>('website_form');
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const add = useCallback(
    async (allowDuplicate = false) => {
      if (!projectId || name.trim().length === 0) return;
      setBusy(true);
      setError(null);
      setNotice(null);
      try {
        const response = await fetch('/api/leads', {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-csrf-token': readCsrfCookie() },
          body: JSON.stringify({
            projectId,
            name,
            email,
            phone,
            enquiry,
            source,
            ...(allowDuplicate ? { allowDuplicate: true } : {}),
          }),
        });
        const payload = (await response.json()) as {
          data?: { id: string; score: { total: number; basis: string } };
          message?: string;
          errors?: Record<string, string>;
        };
        if (response.status === 409) {
          // A duplicate is reported, not merged: the second enquiry has its own
          // context and silently folding it into the first loses that.
          setError(
            `${payload.message ?? 'This looks like a duplicate.'} Add it anyway if they really did enquire twice.`,
          );
          return;
        }
        if (!response.ok || !payload.data) {
          setError(payload.message ?? 'That could not be added.');
          return;
        }
        setRows([
          {
            id: payload.data.id,
            name: name.trim(),
            email: email.trim() || null,
            phone: phone.trim() || null,
            company: null,
            source,
            stage: 'new',
            score: payload.data.score.total,
            scoreBasis: payload.data.score.basis,
            lastActivityAt: new Date().toISOString(),
            createdAt: new Date().toISOString(),
          },
          ...rows,
        ]);
        setStageCounts({ ...stageCounts, new: stageCounts.new + 1 });
        setName('');
        setEmail('');
        setPhone('');
        setEnquiry('');
        setNotice('Added.');
      } catch {
        setError('The request could not be completed.');
      } finally {
        setBusy(false);
      }
    },
    [email, enquiry, name, phone, projectId, rows, source, stageCounts],
  );

  const move = useCallback(
    async (id: string, to: LeadStage) => {
      setBusy(true);
      setError(null);
      setNotice(null);
      const lostReason =
        to === 'lost'
          ? (globalThis.prompt?.('Why was this lost? (required)') ?? '').trim()
          : '';
      if (to === 'lost' && lostReason.length === 0) {
        setError('A lost lead needs a reason, so nothing was changed.');
        setBusy(false);
        return;
      }
      try {
        const response = await fetch(`/api/leads/${id}`, {
          method: 'PATCH',
          headers: { 'content-type': 'application/json', 'x-csrf-token': readCsrfCookie() },
          body: JSON.stringify({ stage: to, ...(lostReason ? { lostReason } : {}) }),
        });
        const payload = (await response.json()) as {
          data?: { stage: LeadStage; score: { total: number } };
          message?: string;
        };
        if (!response.ok || !payload.data) {
          setError(payload.message ?? 'That move was refused.');
          return;
        }
        setRows(
          rows.map((lead) =>
            lead.id === id
              ? { ...lead, stage: payload.data!.stage, score: payload.data!.score.total }
              : lead,
          ),
        );
        setNotice(`Moved to ${STAGE_LABEL[to]}.`);
      } catch {
        setError('The request could not be completed.');
      } finally {
        setBusy(false);
      }
    },
    [rows],
  );

  if (!projectId) {
    return (
      <Alert tone="info" title="No project yet">
        Create a project to start recording leads against it.
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle as="h2" className="text-base">Pipeline</CardTitle>
          <CardDescription>
            Every stage is shown, including the empty ones — a funnel that hides its gaps looks
            healthier than it is.
          </CardDescription>
        </CardHeader>
        <dl className="grid grid-cols-2 gap-4 border-t border-border p-5 sm:grid-cols-4 lg:grid-cols-7">
          {LEAD_STAGES.map((stage) => (
            <div key={stage}>
              <dt className="text-xs uppercase tracking-wide text-fg-muted">{STAGE_LABEL[stage]}</dt>
              <dd className="mt-1 text-2xl font-semibold tabular-nums">{stageCounts[stage]}</dd>
            </div>
          ))}
        </dl>
      </Card>

      {canEdit ? (
        <Card>
          <CardHeader>
            <CardTitle as="h2" className="text-base">Add a lead</CardTitle>
            <CardDescription>
              An email address, a phone number or a company — at least one, or there is no way to
              follow up.
            </CardDescription>
          </CardHeader>
          <div className="grid gap-4 border-t border-border p-5 sm:grid-cols-2">
            <Field id="lead-board-name" label="Name" required>
              {({ id }) => (
                <Input id={id} value={name} onChange={(event) => setName(event.target.value)} />
              )}
            </Field>
            <Field id="lead-board-source" label="Source">
              {({ id }) => (
                <Select id={id}
                  value={source}
                  onChange={(event) => setSource(event.target.value as LeadSource)}
                >
                  {LEAD_SOURCES.map((option) => (
                    <option key={option} value={option}>
                      {SOURCE_LABEL[option]}
                    </option>
                  ))}
                </Select>
              )}
            </Field>
            <Field id="lead-board-email" label="Email">
              {({ id }) => (
                <Input id={id}
                  type="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  inputMode="email"
                />
              )}
            </Field>
            <Field id="lead-board-phone" label="Phone">
              {({ id }) => (
                <Input id={id}
                  value={phone}
                  onChange={(event) => setPhone(event.target.value)}
                  inputMode="tel"
                />
              )}
            </Field>
            <div className="sm:col-span-2">
              <Field id="lead-board-what-did-they-ask-for" label="What did they ask for?">
                {({ id }) => (
                  <Textarea id={id}
                    value={enquiry}
                    onChange={(event) => setEnquiry(event.target.value)}
                    rows={3}
                  />
                )}
              </Field>
            </div>
            <div className="sm:col-span-2 flex flex-wrap gap-2">
              <Button type="button" onClick={() => add(false)} disabled={busy || name.trim().length === 0}>
                Add lead
              </Button>
              {error && error.includes('duplicate') ? (
                <Button type="button" variant="secondary" onClick={() => add(true)} disabled={busy}>
                  Add anyway
                </Button>
              ) : null}
            </div>
          </div>
        </Card>
      ) : null}

      {error ? (
        <Alert tone="danger" title="That did not work" live>
          {error}
        </Alert>
      ) : null}
      {notice ? (
        <Alert tone="success" live>
          {notice}
        </Alert>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle as="h2" className="text-base">Leads</CardTitle>
          <CardDescription>{scoreBasis}</CardDescription>
        </CardHeader>

        {rows.length === 0 ? (
          <p className="border-t border-border px-5 py-4 text-sm text-fg-muted">
            No leads yet.
          </p>
        ) : (
          <ul className="divide-y divide-border border-t border-border">
            {rows.map((lead) => (
              <li key={lead.id} className="px-5 py-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-medium">{lead.name}</p>
                    <p className="text-sm text-fg-muted">
                      {[lead.email, lead.phone, lead.company].filter(Boolean).join(' · ') || '—'}
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone="outline">{SOURCE_LABEL[lead.source as LeadSource] ?? lead.source}</Badge>
                    <Badge tone={BAND_TONE(lead.score)} title={lead.scoreBasis}>
                      {lead.score} / 100
                    </Badge>
                    <Badge tone="info">{STAGE_LABEL[lead.stage]}</Badge>
                  </div>
                </div>

                {canEdit ? (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {LEAD_STAGES.filter((stage) => stage !== lead.stage).map((stage) => {
                      const allowed = canTransition(lead.stage, stage);
                      return (
                        <Button
                          key={stage}
                          type="button"
                          size="sm"
                          variant={stage === 'lost' ? 'secondary' : 'subtle'}
                          onClick={() => move(lead.id, stage)}
                          disabled={busy || !allowed}
                          title={
                            allowed
                              ? `Move to ${STAGE_LABEL[stage]}`
                              : `${STAGE_LABEL[lead.stage]} cannot move straight to ${STAGE_LABEL[stage]} — move one stage at a time so the history stays true.`
                          }
                        >
                          {STAGE_LABEL[stage]}
                        </Button>
                      );
                    })}
                  </div>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
