import { Card } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

/**
 * The state an unbuilt feature renders in.
 *
 * It says what the feature will do, what phase it belongs to, and what you can
 * do in the meantime. It does NOT show fake charts, placeholder rows or a
 * disabled form that implies the feature is nearly there — that reads as broken
 * rather than as honest.
 */
export function ComingSoon({
  title,
  description,
  phase,
  whatItWillDo,
  availableNow,
}: {
  readonly title: string;
  readonly description: string;
  readonly phase: string;
  readonly whatItWillDo: readonly string[];
  readonly availableNow?: { readonly label: string; readonly href: string };
}) {
  return (
    <div className="mx-auto max-w-2xl">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
        <Badge tone="neutral">Not built yet</Badge>
      </div>
      <p className="mt-3 text-base leading-relaxed text-fg-muted">{description}</p>

      <Card className="mt-8 p-6">
        <p className="text-sm font-semibold">Planned for {phase}</p>
        <ul className="mt-4 flex flex-col gap-2.5">
          {whatItWillDo.map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm leading-relaxed">
              <Icon name="check" size={16} className="mt-0.5 shrink-0 text-fg-subtle" />
              <span className="text-fg-muted">{item}</span>
            </li>
          ))}
        </ul>
      </Card>

      {availableNow ? (
        <div className="mt-6 flex items-center gap-3">
          <p className="text-sm text-fg-muted">Available now:</p>
          <Button href={availableNow.href} variant="secondary" size="sm">
            {availableNow.label}
          </Button>
        </div>
      ) : null}
    </div>
  );
}
