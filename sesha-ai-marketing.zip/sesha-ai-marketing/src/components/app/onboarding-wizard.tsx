'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

import { readCsrfCookie } from './app-shell';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Checkbox, Field, Input, Select, Textarea } from '@/components/ui/field';
import { Icon } from '@/components/ui/icon';
import {
  BRAND_TONES,
  CRAWL_CONSENT_VERSION,
  CRAWL_LIMITS,
  INDUSTRIES,
  MARKETING_CHANNELS,
  MARKETING_GOALS,
  PRICE_RANGES,
} from '@/lib/validation/onboarding';
import { cn } from '@/lib/utils/cn';

/**
 * Onboarding wizard.
 *
 * Four steps: business, marketing profile, website access, review. Validation
 * is mirrored here for immediate feedback, but the server revalidates
 * everything — the field errors shown come from the API response.
 *
 * THE WEBSITE ACCESS STEP IS THE ONE THAT MATTERS. It is skippable, the consent
 * checkbox starts unchecked, and the disclosure states plainly what would be
 * accessed, why, the limits, how long data is kept and how to stop it. Entering
 * a website address on step 1 grants nothing.
 */

const STEPS = ['Business', 'Marketing', 'Website access', 'Review'] as const;

const label = (value: string) => value.replace(/[-_]/g, ' ');

export function OnboardingWizard({ websiteFromSignup }: { readonly websiteFromSignup?: string }) {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [message, setMessage] = useState<string | null>(null);

  const [business, setBusiness] = useState({
    name: '',
    industry: '',
    country: '',
    city: '',
    websiteUrl: websiteFromSignup ?? '',
  });

  const [profile, setProfile] = useState({
    targetAudience: '',
    productsServices: '',
    priceRange: '',
    marketingGoals: [] as string[],
    marketingChannels: [] as string[],
    tones: [] as string[],
    voiceNotes: '',
    competitors: [{ name: '', url: '' }],
  });

  /**
   * The type is explicit because `CRAWL_LIMITS` is `as const`.
   *
   * Without it, `maxPages` infers the LITERAL `100` and `retentionDays` the
   * literal `90` — so the two number inputs below could never be changed, and
   * every `setCrawl` from them was a type error. It worked at runtime, because
   * JavaScript does not care, which is exactly why it survived from Phase 2
   * until `.tsx` was first type-checked.
   */
  const [crawl, setCrawl] = useState<{
    consent: boolean;
    maxPages: number;
    retentionDays: number;
  }>({
    consent: false,
    maxPages: CRAWL_LIMITS.maxPagesDefault,
    retentionDays: CRAWL_LIMITS.retentionDaysDefault,
  });

  function toggle(list: string[], value: string): string[] {
    return list.includes(value) ? list.filter((item) => item !== value) : [...list, value];
  }

  async function submit() {
    setBusy(true);
    setErrors({});
    setMessage(null);

    const payload = {
      business,
      profile: {
        targetAudience: profile.targetAudience,
        productsServices: profile.productsServices,
        priceRange: profile.priceRange,
        marketingGoals: profile.marketingGoals,
        marketingChannels: profile.marketingChannels,
        brandVoice: { tones: profile.tones, notes: profile.voiceNotes },
        competitors: profile.competitors.filter((c) => c.name.trim().length > 0),
      },
      // Only sent when the box was actually ticked.
      crawlConsent:
        crawl.consent && business.websiteUrl
          ? {
              websiteUrl: business.websiteUrl,
              consent: true,
              consentVersion: CRAWL_CONSENT_VERSION,
              maxPages: crawl.maxPages,
              retentionDays: crawl.retentionDays,
              respectRobots: true,
            }
          : null,
    };

    try {
      const response = await fetch('/api/onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
        body: JSON.stringify(payload),
      });
      const body = (await response.json()) as {
        ok?: boolean;
        message?: string;
        errors?: Record<string, string>;
      };

      if (response.ok && body.ok) {
        router.push('/app');
        router.refresh();
        return;
      }
      setBusy(false);
      setErrors(body.errors ?? {});
      setMessage(body.message ?? 'Please check your answers.');
      // Send the user back to the step that failed.
      if (body.errors) {
        const keys = Object.keys(body.errors);
        if (keys.some((k) => ['name', 'industry', 'country', 'city', 'websiteUrl'].includes(k))) {
          setStep(0);
        } else if (keys.some((k) => k.startsWith('consent') || k === 'maxPages')) {
          setStep(2);
        } else {
          setStep(1);
        }
      }
    } catch {
      setBusy(false);
      setMessage('Network error. Please try again.');
    }
  }

  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col gap-8">
      <ol className="flex flex-wrap gap-2" aria-label="Setup progress">
        {STEPS.map((name, index) => (
          <li key={name}>
            <span
              aria-current={index === step ? 'step' : undefined}
              className={cn(
                'inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium',
                index === step
                  ? 'bg-primary text-primary-fg'
                  : index < step
                    ? 'bg-success-subtle text-success'
                    : 'bg-bg-muted text-fg-subtle',
              )}
            >
              {index < step ? <Icon name="check" size={13} /> : null}
              {name}
            </span>
          </li>
        ))}
      </ol>

      {message ? (
        <Alert tone="danger" live>
          {message}
        </Alert>
      ) : null}

      {/* ------------------------------ step 1 ------------------------------ */}
      {step === 0 ? (
        <Card className="p-6">
          <h2 className="text-lg font-semibold tracking-tight">About your business</h2>
          <div className="mt-6 flex flex-col gap-5">
            <Field id="ob-name" label="Business name" required error={errors.name}>
              {({ id }) => (
                <Input
                  id={id}
                  value={business.name}
                  onChange={(e) => setBusiness({ ...business, name: e.target.value })}
                  autoFocus
                />
              )}
            </Field>

            <Field id="ob-industry" label="Industry" required error={errors.industry}>
              {({ id }) => (
                <Select
                  id={id}
                  value={business.industry}
                  onChange={(e) => setBusiness({ ...business, industry: e.target.value })}
                >
                  <option value="">Choose an industry…</option>
                  {INDUSTRIES.map((value) => (
                    <option key={value} value={value}>
                      {label(value)}
                    </option>
                  ))}
                </Select>
              )}
            </Field>

            <div className="grid gap-5 sm:grid-cols-2">
              <Field id="ob-country" label="Country" required error={errors.country}>
                {({ id }) => (
                  <Input
                    id={id}
                    value={business.country}
                    onChange={(e) => setBusiness({ ...business, country: e.target.value })}
                  />
                )}
              </Field>
              <Field id="ob-city" label="City" required error={errors.city}>
                {({ id }) => (
                  <Input
                    id={id}
                    value={business.city}
                    onChange={(e) => setBusiness({ ...business, city: e.target.value })}
                  />
                )}
              </Field>
            </div>

            <Field
              id="ob-website"
              label="Website"
              hint="Optional. Entering it here does not give us permission to access it — you choose that later."
              error={errors.websiteUrl}
            >
              {({ id }) => (
                <Input
                  id={id}
                  inputMode="url"
                  placeholder="example.com"
                  value={business.websiteUrl}
                  onChange={(e) => setBusiness({ ...business, websiteUrl: e.target.value })}
                />
              )}
            </Field>
          </div>
        </Card>
      ) : null}

      {/* ------------------------------ step 2 ------------------------------ */}
      {step === 1 ? (
        <Card className="p-6">
          <h2 className="text-lg font-semibold tracking-tight">Your marketing profile</h2>
          <p className="mt-1 text-sm text-fg-muted">
            This becomes the context every module reads from.
          </p>

          <div className="mt-6 flex flex-col gap-6">
            <Field
              id="ob-audience"
              label="Who are you trying to reach?"
              required
              error={errors.targetAudience}
            >
              {({ id }) => (
                <Textarea
                  id={id}
                  rows={3}
                  value={profile.targetAudience}
                  onChange={(e) => setProfile({ ...profile, targetAudience: e.target.value })}
                />
              )}
            </Field>

            <Field
              id="ob-products"
              label="What do you sell?"
              required
              error={errors.productsServices}
            >
              {({ id }) => (
                <Textarea
                  id={id}
                  rows={3}
                  value={profile.productsServices}
                  onChange={(e) => setProfile({ ...profile, productsServices: e.target.value })}
                />
              )}
            </Field>

            <Field id="ob-price" label="Price range" required error={errors.priceRange}>
              {({ id }) => (
                <Select
                  id={id}
                  value={profile.priceRange}
                  onChange={(e) => setProfile({ ...profile, priceRange: e.target.value })}
                >
                  <option value="">Choose…</option>
                  {PRICE_RANGES.map((value) => (
                    <option key={value} value={value}>
                      {label(value)}
                    </option>
                  ))}
                </Select>
              )}
            </Field>

            <ChipGroup
              legend="Marketing goals"
              error={errors.marketingGoals}
              options={MARKETING_GOALS}
              selected={profile.marketingGoals}
              onToggle={(value) =>
                setProfile({ ...profile, marketingGoals: toggle(profile.marketingGoals, value) })
              }
            />

            <ChipGroup
              legend="Channels you use"
              error={errors.marketingChannels}
              options={MARKETING_CHANNELS}
              selected={profile.marketingChannels}
              onToggle={(value) =>
                setProfile({
                  ...profile,
                  marketingChannels: toggle(profile.marketingChannels, value),
                })
              }
            />

            <ChipGroup
              legend="Brand voice (up to three)"
              error={errors.brandVoice}
              options={BRAND_TONES}
              selected={profile.tones}
              onToggle={(value) => setProfile({ ...profile, tones: toggle(profile.tones, value) })}
            />

            <Field id="ob-voice-notes" label="Anything else about your voice?" hint="Optional">
              {({ id }) => (
                <Textarea
                  id={id}
                  rows={2}
                  value={profile.voiceNotes}
                  onChange={(e) => setProfile({ ...profile, voiceNotes: e.target.value })}
                />
              )}
            </Field>

            <fieldset>
              <legend className="text-sm font-medium">Competitors</legend>
              <p className="mt-1 text-xs text-fg-muted">Optional. Add up to ten.</p>
              <div className="mt-3 flex flex-col gap-3">
                {profile.competitors.map((competitor, index) => (
                  <div key={index} className="grid gap-2 sm:grid-cols-2">
                    <Input
                      aria-label={`Competitor ${index + 1} name`}
                      placeholder="Name"
                      value={competitor.name}
                      onChange={(e) => {
                        const next = [...profile.competitors];
                        next[index] = { ...competitor, name: e.target.value };
                        setProfile({ ...profile, competitors: next });
                      }}
                    />
                    <Input
                      aria-label={`Competitor ${index + 1} website`}
                      placeholder="Website (optional)"
                      value={competitor.url}
                      onChange={(e) => {
                        const next = [...profile.competitors];
                        next[index] = { ...competitor, url: e.target.value };
                        setProfile({ ...profile, competitors: next });
                      }}
                    />
                  </div>
                ))}
              </div>
              {errors.competitors ? (
                <p role="alert" className="mt-2 text-xs font-medium text-danger">
                  {errors.competitors}
                </p>
              ) : null}
              {profile.competitors.length < 10 ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="mt-3"
                  onClick={() =>
                    setProfile({
                      ...profile,
                      competitors: [...profile.competitors, { name: '', url: '' }],
                    })
                  }
                >
                  <Icon name="plus" size={15} />
                  Add another
                </Button>
              ) : null}
            </fieldset>
          </div>
        </Card>
      ) : null}

      {/* ------------------------------ step 3 ------------------------------ */}
      {step === 2 ? (
        <Card className="p-6">
          <h2 className="text-lg font-semibold tracking-tight">Website access</h2>

          {!business.websiteUrl ? (
            <p className="mt-4 text-sm leading-relaxed text-fg-muted">
              You did not enter a website, so there is nothing to request access to. You can add one
              later from settings.
            </p>
          ) : (
            <>
              <p className="mt-2 text-sm text-fg-muted">
                We would like your permission to read{' '}
                <span className="font-medium text-fg">{business.websiteUrl}</span>. This is entirely
                optional and everything else works without it.
              </p>

              <div className="mt-6 rounded-card border border-border bg-bg-subtle p-5">
                <h3 className="text-sm font-semibold">Exactly what this means</h3>
                <dl className="mt-4 flex flex-col gap-4 text-sm">
                  <ConsentRow term="What we would access">
                    Publicly available pages on that domain — the same HTML any visitor or search
                    engine receives. Never anything behind a login, and never another domain.
                  </ConsentRow>
                  <ConsentRow term="Why">
                    To audit your site&apos;s structure, metadata and structured data, and to ground
                    content suggestions in what you already publish.
                  </ConsentRow>
                  <ConsentRow term="Limits">
                    At most {crawl.maxPages} pages, at a polite request rate. We obey your
                    robots.txt, and we identify ourselves with a SeSha user agent.
                  </ConsentRow>
                  <ConsentRow term="How long we keep it">
                    {crawl.retentionDays} days, then it is deleted automatically.
                  </ConsentRow>
                  <ConsentRow term="Stopping and deleting">
                    You can withdraw permission at any time in settings, and delete everything
                    collected with one action. Withdrawal takes effect immediately.
                  </ConsentRow>
                  <ConsentRow term="Status today">
                    The crawler is not built yet — it arrives in a later phase. Granting permission
                    now records your consent; nothing is fetched until the feature ships.
                  </ConsentRow>
                </dl>
              </div>

              <div className="mt-6 grid gap-5 sm:grid-cols-2">
                <Field id="ob-maxpages" label="Maximum pages" error={errors.maxPages}>
                  {({ id }) => (
                    <Input
                      id={id}
                      type="number"
                      min={1}
                      max={CRAWL_LIMITS.maxPagesCeiling}
                      value={crawl.maxPages}
                      onChange={(e) => setCrawl({ ...crawl, maxPages: Number(e.target.value) })}
                    />
                  )}
                </Field>
                <Field id="ob-retention" label="Keep data for (days)" error={errors.retentionDays}>
                  {({ id }) => (
                    <Input
                      id={id}
                      type="number"
                      min={1}
                      max={CRAWL_LIMITS.retentionDaysCeiling}
                      value={crawl.retentionDays}
                      onChange={(e) => setCrawl({ ...crawl, retentionDays: Number(e.target.value) })}
                    />
                  )}
                </Field>
              </div>

              <div className="mt-6">
                <Checkbox
                  id="ob-consent"
                  checked={crawl.consent}
                  onChange={(e) => setCrawl({ ...crawl, consent: e.target.checked })}
                  error={errors.consentVersion}
                  label={
                    <>
                      I give SeSha permission to access {business.websiteUrl} on the terms above.
                      I understand I can withdraw this at any time.
                    </>
                  }
                />
                <p className="mt-3 text-xs text-fg-subtle">
                  Leave this unticked to continue without granting access.
                </p>
              </div>
            </>
          )}
        </Card>
      ) : null}

      {/* ------------------------------ step 4 ------------------------------ */}
      {step === 3 ? (
        <Card className="p-6">
          <h2 className="text-lg font-semibold tracking-tight">Review</h2>
          <dl className="mt-6 flex flex-col gap-4 text-sm">
            <ReviewRow term="Business">
              {business.name || '—'} · {label(business.industry) || '—'} · {business.city},{' '}
              {business.country}
            </ReviewRow>
            <ReviewRow term="Website">{business.websiteUrl || 'Not provided'}</ReviewRow>
            <ReviewRow term="Audience">{profile.targetAudience || '—'}</ReviewRow>
            <ReviewRow term="Goals">
              {profile.marketingGoals.map(label).join(', ') || '—'}
            </ReviewRow>
            <ReviewRow term="Channels">
              {profile.marketingChannels.map(label).join(', ') || '—'}
            </ReviewRow>
            <ReviewRow term="Voice">{profile.tones.map(label).join(', ') || '—'}</ReviewRow>
            <ReviewRow term="Website access">
              {crawl.consent && business.websiteUrl ? (
                <Badge tone="success">Granted — {crawl.maxPages} pages, {crawl.retentionDays} days</Badge>
              ) : (
                <Badge tone="neutral">Not granted</Badge>
              )}
            </ReviewRow>
          </dl>
        </Card>
      ) : null}

      <div className="flex items-center justify-between gap-3">
        <Button
          variant="ghost"
          onClick={() => setStep((s) => Math.max(0, s - 1))}
          disabled={step === 0 || busy}
        >
          Back
        </Button>

        {step < STEPS.length - 1 ? (
          <Button onClick={() => setStep((s) => Math.min(STEPS.length - 1, s + 1))}>
            Continue
            <Icon name="arrow-right" size={17} />
          </Button>
        ) : (
          <Button onClick={submit} disabled={busy} size="lg">
            {busy ? 'Setting up…' : 'Finish set-up'}
          </Button>
        )}
      </div>
    </div>
  );
}

function ChipGroup({
  legend,
  options,
  selected,
  onToggle,
  error,
}: {
  readonly legend: string;
  readonly options: readonly string[];
  readonly selected: readonly string[];
  readonly onToggle: (value: string) => void;
  readonly error?: string;
}) {
  return (
    <fieldset>
      <legend className="text-sm font-medium">{legend}</legend>
      <div className="mt-3 flex flex-wrap gap-2">
        {options.map((option) => {
          const active = selected.includes(option);
          return (
            <button
              key={option}
              type="button"
              aria-pressed={active}
              onClick={() => onToggle(option)}
              className={cn(
                'rounded-full border px-3 py-1.5 text-sm capitalize transition-colors duration-150',
                active
                  ? 'border-transparent bg-primary text-primary-fg'
                  : 'border-border-strong text-fg-muted hover:bg-bg-muted',
              )}
            >
              {option.replace(/[-_]/g, ' ')}
            </button>
          );
        })}
      </div>
      {error ? (
        <p role="alert" className="mt-2 text-xs font-medium text-danger">
          {error}
        </p>
      ) : null}
    </fieldset>
  );
}

function ConsentRow({ term, children }: { readonly term: string; readonly children: React.ReactNode }) {
  return (
    <div>
      <dt className="text-xs font-semibold uppercase tracking-[0.08em] text-fg-subtle">{term}</dt>
      <dd className="mt-1 leading-relaxed text-fg-muted">{children}</dd>
    </div>
  );
}

function ReviewRow({ term, children }: { readonly term: string; readonly children: React.ReactNode }) {
  return (
    <div className="grid gap-1 sm:grid-cols-[10rem_1fr]">
      <dt className="text-xs uppercase tracking-[0.08em] text-fg-subtle">{term}</dt>
      <dd className="leading-relaxed text-fg-muted">{children}</dd>
    </div>
  );
}
