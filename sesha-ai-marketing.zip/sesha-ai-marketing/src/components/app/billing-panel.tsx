'use client';

import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';

import { readCsrfCookie } from '@/components/app/app-shell';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { formatLimit, LIMIT_IDS, LIMITS, planChange, type PlanId } from '@/content/plans';
import type { PlanDefinition } from '@/content/plans';

/**
 * The billing screen's interactive half.
 *
 * WHAT THIS COMPONENT WILL NOT DO: collect a card. There is no card field here,
 * there is no card field anywhere, and there is no code path that would accept
 * one. Checkout hands off to the provider's own page; the only payment data that
 * ever comes back is a brand and four digits, which is all this screen shows.
 *
 * The confirm step for a downgrade is not decoration. Moving from Business to
 * Pro halves several limits at once, and the customer should read what they are
 * giving up before it happens rather than discover it the next time they are
 * refused.
 */

export interface BillingPanelProps {
  readonly currentPlan: PlanId;
  readonly plans: readonly PlanDefinition[];
  readonly providerConfigured: boolean;
  readonly providerMessage: string;
  readonly cancelAtPeriodEnd: boolean;
  readonly canManage: boolean;
}

type Pending = { readonly plan: PlanId; readonly direction: 'upgrade' | 'downgrade' } | null;

export function BillingPanel({
  currentPlan,
  plans,
  providerConfigured,
  providerMessage,
  cancelAtPeriodEnd,
  canManage,
}: BillingPanelProps) {
  const router = useRouter();
  const [pending, setPending] = useState<Pending>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, startTransition] = useTransition();

  async function send(body: Record<string, unknown>) {
    setError(null);
    setNotice(null);
    const response = await fetch('/api/billing', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify(body),
    });
    const payload = (await response.json().catch(() => null)) as
      | { readonly ok?: boolean; readonly message?: string }
      | null;

    if (!response.ok) {
      setError(payload?.message ?? 'That did not work. Please try again.');
      return;
    }
    setNotice(payload?.message ?? 'Saved.');
    setPending(null);
    startTransition(() => router.refresh());
  }

  const current = plans.find((plan) => plan.id === currentPlan);

  return (
    <div className="flex flex-col gap-6">
      {error ? (
        <p
          role="alert"
          className="rounded-control border border-danger/40 bg-danger-subtle px-3.5 py-2.5 text-sm text-danger"
        >
          {error}
        </p>
      ) : null}
      {notice ? (
        <p
          role="status"
          className="rounded-control border border-success/40 bg-success-subtle px-3.5 py-2.5 text-sm text-success"
        >
          {notice}
        </p>
      ) : null}

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold tracking-tight">Plans</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          {plans.map((plan) => {
          const isCurrent = plan.id === currentPlan;
          const direction = planChange(currentPlan, plan.id);

          return (
            <Card key={plan.id} tone={isCurrent ? 'default' : 'outline'}>
              <CardHeader>
                <div className="flex items-center justify-between gap-2">
                  <CardTitle as="h3">{plan.name}</CardTitle>
                  {isCurrent ? <Badge tone="brand">Your plan</Badge> : null}
                </div>
                <CardDescription>{plan.audience}</CardDescription>
              </CardHeader>

              <dl className="flex flex-col gap-1 px-6 py-4 text-sm">
                {LIMIT_IDS.slice(0, 6).map((id) => (
                  <div key={id} className="flex justify-between gap-3">
                    <dt className="text-fg-muted">{LIMITS[id].label}</dt>
                    <dd className="tabular-nums text-fg">{formatLimit(plan.limits[id])}</dd>
                  </div>
                ))}
              </dl>

              <div className="px-6 pb-6">
                {isCurrent ? (
                  <p className="text-xs text-fg-subtle">
                    {plan.requiresPayment
                      ? 'Included in your subscription.'
                      : 'Free, with no card and no expiry.'}
                  </p>
                ) : !canManage ? (
                  <p className="text-xs text-fg-subtle">
                    Only an owner or admin can change the plan.
                  </p>
                ) : plan.requiresPayment && !providerConfigured ? (
                  <p className="text-xs text-fg-subtle">
                    Cannot be bought yet — no payment provider is connected.
                  </p>
                ) : (
                  <Button
                    variant={direction === 'upgrade' ? 'primary' : 'secondary'}
                    size="sm"
                    disabled={busy}
                    onClick={() => {
                      if (direction === 'same') return;
                      setPending({ plan: plan.id, direction });
                    }}
                  >
                    {direction === 'upgrade' ? `Move to ${plan.name}` : `Downgrade to ${plan.name}`}
                  </Button>
                )}
              </div>
            </Card>
          );
          })}
        </div>
      </section>

      {pending ? (
        <Card tone="subtle">
          <CardHeader>
            <CardTitle as="h2">
              {pending.direction === 'upgrade' ? 'Confirm the change' : 'Read this first'}
            </CardTitle>
            <CardDescription>
              {pending.direction === 'downgrade'
                ? 'Nothing you have made is deleted. These limits get smaller, and SeSha will refuse new work once you are over them.'
                : 'These limits get larger straight away.'}
            </CardDescription>
          </CardHeader>

          <div className="overflow-x-auto px-6 pb-4">
            <table className="w-full min-w-[24rem] text-sm">
              <caption className="sr-only">Limit changes</caption>
              <thead>
                <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-fg-subtle">
                  <th scope="col" className="py-2 pr-4 font-medium">
                    Limit
                  </th>
                  <th scope="col" className="py-2 pr-4 text-right font-medium">
                    {current?.name ?? 'Now'}
                  </th>
                  <th scope="col" className="py-2 text-right font-medium">
                    {plans.find((plan) => plan.id === pending.plan)?.name ?? 'New'}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {changedLimits(plans, currentPlan, pending.plan).map((row) => (
                  <tr key={row.id}>
                    <th scope="row" className="py-2 pr-4 text-left font-normal text-fg">
                      {LIMITS[row.id].label}
                    </th>
                    <td className="py-2 pr-4 text-right tabular-nums text-fg-muted">
                      {formatLimit(row.from)}
                    </td>
                    <td className="py-2 text-right tabular-nums text-fg">{formatLimit(row.to)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex flex-wrap gap-2 px-6 pb-6">
            <Button
              size="sm"
              disabled={busy}
              onClick={() =>
                void send({
                  action: providerConfigured ? 'checkout' : 'change_plan',
                  plan: pending.plan,
                })
              }
            >
              {pending.direction === 'upgrade' ? 'Confirm' : 'Downgrade anyway'}
            </Button>
            <Button variant="ghost" size="sm" disabled={busy} onClick={() => setPending(null)}>
              Keep my plan
            </Button>
          </div>
        </Card>
      ) : null}

      {canManage ? (
        <Card>
          <CardHeader>
            <CardTitle as="h2">{cancelAtPeriodEnd ? 'Cancellation' : 'Cancel'}</CardTitle>
            <CardDescription>
              {cancelAtPeriodEnd
                ? 'Your subscription ends at the end of the current period. You keep full access until then, and read access afterwards.'
                : 'Cancelling stops the renewal. You keep everything you have made, and can always read and export it.'}
            </CardDescription>
          </CardHeader>
          <div className="flex flex-wrap gap-2 px-6 pb-6">
            {cancelAtPeriodEnd ? (
              <Button
                variant="secondary"
                size="sm"
                disabled={busy}
                onClick={() => void send({ action: 'resume' })}
              >
                Keep my subscription
              </Button>
            ) : (
              <Button
                variant="secondary"
                size="sm"
                disabled={busy}
                onClick={() => void send({ action: 'cancel' })}
              >
                Cancel at period end
              </Button>
            )}
          </div>
        </Card>
      ) : null}

      <p className="text-xs text-fg-subtle">{providerMessage}</p>
    </div>
  );
}

/** Only the limits that actually differ. A table of unchanged rows hides the change. */
function changedLimits(
  plans: readonly PlanDefinition[],
  from: PlanId,
  to: PlanId,
): readonly { readonly id: (typeof LIMIT_IDS)[number]; readonly from: number | null; readonly to: number | null }[] {
  const before = plans.find((plan) => plan.id === from);
  const after = plans.find((plan) => plan.id === to);
  if (!before || !after) return [];
  return LIMIT_IDS.filter((id) => before.limits[id] !== after.limits[id]).map((id) => ({
    id,
    from: before.limits[id],
    to: after.limits[id],
  }));
}
