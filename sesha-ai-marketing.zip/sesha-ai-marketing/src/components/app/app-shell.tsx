'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useRouter } from 'next/navigation';
import { useState, type ReactNode } from 'react';

import { Logo } from '@/components/layout/logo';
import { ThemeToggle } from '@/components/layout/theme';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Icon } from '@/components/ui/icon';
import { appNavGroups, type AppNavItem } from '@/content/app-nav';
import { can, type Permission, type Role } from '@/lib/auth/rbac';
import { cn } from '@/lib/utils/cn';

/**
 * Authenticated application shell.
 *
 * TWO THINGS THIS DOES CAREFULLY:
 *
 * 1. UNBUILT FEATURES ARE DISABLED, NOT FAKED. An item with status 'planned'
 *    renders as a non-interactive element with a "Soon" badge — never as a link
 *    to an empty screen that looks broken. The brief asks for exactly this.
 *
 * 2. PERMISSION-GATED ITEMS ARE HIDDEN, BUT THAT IS NOT THE CONTROL. Hiding a
 *    nav item is a courtesy for the user; the API route and the service layer
 *    are what actually refuse the action.
 */

export interface ShellUser {
  readonly name: string | null;
  readonly email: string;
  readonly role: Role;
  readonly emailVerified: boolean;
}

export function AppShell({
  user,
  children,
  banner,
}: {
  readonly user: ShellUser;
  readonly children: ReactNode;
  readonly banner?: ReactNode;
}) {
  const pathname = usePathname() ?? '/app';
  const router = useRouter();
  const [navOpen, setNavOpen] = useState(false);

  async function signOut() {
    await fetch('/api/auth/signout', {
      method: 'POST',
      headers: { 'x-csrf-token': readCsrfCookie() },
    });
    router.push('/sign-in');
    router.refresh();
  }

  return (
    <div className="flex min-h-dvh flex-col bg-bg-subtle">
      <a
        href="#main"
        className="skip-link rounded-control bg-primary px-4 py-2 text-sm font-medium text-primary-fg shadow-lg"
      >
        Skip to main content
      </a>

      <header className="sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-md">
        <div className="flex h-16 items-center justify-between gap-4 px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <button
              type="button"
              aria-expanded={navOpen}
              aria-controls="app-nav"
              aria-label={navOpen ? 'Close navigation' : 'Open navigation'}
              onClick={() => setNavOpen((open) => !open)}
              className="inline-flex size-10 items-center justify-center rounded-control text-fg-muted hover:bg-bg-muted hover:text-fg lg:hidden"
            >
              <Icon name={navOpen ? 'close' : 'menu'} size={20} />
            </button>
            <Logo href="/app" />
          </div>

          <div className="flex items-center gap-2">
            <ThemeToggle />
            <div className="hidden items-center gap-2 sm:flex">
              <span className="text-sm text-fg-muted">{user.name ?? user.email}</span>
              <Badge tone="outline">{user.role.replace('_', ' ')}</Badge>
            </div>
            <Button variant="ghost" size="icon" onClick={signOut} aria-label="Sign out">
              <Icon name="logout" size={18} />
            </Button>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        <nav
          id="app-nav"
          aria-label="Application"
          className={cn(
            'w-64 shrink-0 border-r border-border bg-bg px-3 py-5',
            navOpen ? 'block' : 'hidden lg:block',
          )}
        >
          <div className="flex flex-col gap-7">
            {appNavGroups.map((group) => (
              <div key={group.label}>
                <p className="mb-2 px-3 text-xs font-semibold uppercase tracking-[0.12em] text-fg-subtle">
                  {group.label}
                </p>
                <ul className="flex flex-col gap-0.5">
                  {group.items
                    .filter((item) => visibleTo(item, user.role))
                    .map((item) => (
                      <li key={item.href}>
                        <NavEntry item={item} active={isActive(pathname, item.href)} />
                      </li>
                    ))}
                </ul>
              </div>
            ))}
          </div>
        </nav>

        <div className="min-w-0 flex-1">
          {banner}
          <main id="main" tabIndex={-1} className="px-4 py-8 focus:outline-none sm:px-6 lg:px-8">
            <div className="mx-auto w-full max-w-6xl">{children}</div>
          </main>
        </div>
      </div>
    </div>
  );
}

function visibleTo(item: AppNavItem, role: Role): boolean {
  if (!item.permission) return true;
  return can(role, item.permission as Permission);
}

function isActive(pathname: string, href: string): boolean {
  if (href === '/app') return pathname === '/app';
  return pathname === href || pathname.startsWith(`${href}/`);
}

function NavEntry({ item, active }: { readonly item: AppNavItem; readonly active: boolean }) {
  const base =
    'flex items-center gap-2.5 rounded-control px-3 py-2 text-sm transition-colors duration-150';

  if (item.status === 'planned') {
    // Deliberately NOT a link. A disabled control with a reason beats a link to
    // a page that does not exist yet.
    return (
      <span
        aria-disabled="true"
        title={item.note}
        className={cn(base, 'cursor-not-allowed text-fg-subtle')}
      >
        <Icon name={item.icon as never} size={17} className="opacity-60" />
        <span className="flex-1">{item.label}</span>
        <Badge tone="neutral" className="text-[0.65rem]">
          Soon
        </Badge>
      </span>
    );
  }

  return (
    <Link
      href={item.href}
      aria-current={active ? 'page' : undefined}
      className={cn(
        base,
        active
          ? 'bg-primary-subtle font-medium text-primary-subtle-fg'
          : 'text-fg-muted hover:bg-bg-muted hover:text-fg',
      )}
    >
      <Icon name={item.icon as never} size={17} />
      {item.label}
    </Link>
  );
}

/** The CSRF cookie is readable by design — the client must echo it back. */
export function readCsrfCookie(): string {
  if (typeof document === 'undefined') return '';
  const match = document.cookie.match(/(?:^|;\s*)sesha_csrf=([^;]*)/);
  return match?.[1] ? decodeURIComponent(match[1]) : '';
}
