'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

import { readCsrfCookie } from './app-shell';
import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Field, Input } from '@/components/ui/field';
import { Modal } from '@/components/ui/modal';

/**
 * Danger-zone controls.
 *
 * Deletion requires re-entering the password (or a recent sign-in for an
 * OAuth-only account) AND typing the confirmation phrase. The typed phrase is a
 * UX guard against a mis-click; the password is the security control.
 */
export function DeleteAccountCard({ hasPassword }: { readonly hasPassword: boolean }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  const CONFIRM = 'delete my account';

  async function remove() {
    setBusy(true);
    setError(null);
    try {
      const response = await fetch('/api/account', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
        body: JSON.stringify({ password: password || null }),
      });
      const payload = (await response.json()) as { ok?: boolean; message?: string };

      if (response.ok && payload.ok) {
        router.push('/');
        router.refresh();
        return;
      }
      setBusy(false);
      setError(payload.message ?? 'Could not close the account.');
    } catch {
      setBusy(false);
      setError('Network error. Please try again.');
    }
  }

  return (
    <Card className="border-danger/30 p-6">
      <h2 className="font-semibold tracking-tight text-danger">Delete account</h2>
      <p className="mt-2 text-sm leading-relaxed text-fg-muted">
        Closing your account signs you out everywhere immediately and blocks sign-in. Your data is
        retained for 30 days in case it was a mistake, then permanently erased. Audit records are
        kept without personal details.
      </p>
      <Button variant="danger" size="sm" className="mt-4" onClick={() => setOpen(true)}>
        Delete my account
      </Button>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Delete your account?"
        description="This signs you out everywhere and blocks sign-in immediately."
        footer={
          <>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              disabled={busy || confirmText !== CONFIRM || (hasPassword && password.length === 0)}
              onClick={remove}
            >
              {busy ? 'Closing…' : 'Delete account'}
            </Button>
          </>
        }
      >
        <div className="flex flex-col gap-4">
          {error ? (
            <Alert tone="danger" live>
              {error}
            </Alert>
          ) : null}

          {hasPassword ? (
            <Field id="delete-password" label="Confirm your password" required>
              {({ id }) => (
                <Input
                  id={id}
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              )}
            </Field>
          ) : (
            <p className="text-sm text-fg-muted">
              Your account signs in with Google, so we rely on your recent sign-in instead of a
              password. If it has been a while, sign out and back in first.
            </p>
          )}

          <Field
            id="delete-confirm"
            label={`Type "${CONFIRM}" to confirm`}
            required
          >
            {({ id }) => (
              <Input
                id={id}
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                autoComplete="off"
              />
            )}
          </Field>
        </div>
      </Modal>
    </Card>
  );
}

/**
 * "Download my data". Phase 8 — the export endpoint existed with no way to reach
 * it from the product. It needs a recent sign-in, so a stale session is told to
 * sign in again rather than handed an error code.
 */
export function ExportDataCard() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function download() {
    setBusy(true);
    setError(null);
    try {
      const response = await fetch('/api/account/export');
      if (!response.ok) {
        const payload = (await response.json().catch(() => ({}))) as { message?: string };
        setError(payload.message ?? 'Could not prepare the export.');
        return;
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const anchor = window.document.createElement('a');
      anchor.href = url;
      anchor.download = `sesha-export-${new Date().toISOString().slice(0, 10)}.json`;
      anchor.click();
      URL.revokeObjectURL(url);
    } catch {
      setError('Network error. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card className="p-6">
      <h2 className="font-semibold tracking-tight">Download your data</h2>
      <p className="mt-2 text-sm leading-relaxed text-fg-muted">
        A complete, machine-readable copy of everything your organization created, as a JSON file.
        Passwords, tokens and card numbers are never included.
      </p>
      {error ? (
        <Alert tone="danger" className="mt-4" role="alert">
          {error}
        </Alert>
      ) : null}
      <Button className="mt-4" variant="secondary" onClick={download} disabled={busy}>
        {busy ? 'Preparing…' : 'Download export'}
      </Button>
    </Card>
  );
}
