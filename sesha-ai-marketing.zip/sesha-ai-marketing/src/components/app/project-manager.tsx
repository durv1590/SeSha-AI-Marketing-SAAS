'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

import { readCsrfCookie } from './app-shell';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Field, Input, Textarea } from '@/components/ui/field';
import { Modal } from '@/components/ui/modal';
import type { ProjectRow } from '@/lib/db/types';

/**
 * Project list with create and delete.
 *
 * Every mutation sends the CSRF token the server issued. Permission-gated
 * controls are hidden from roles that lack them — but the API refuses the
 * action regardless, which is where the actual control lives.
 */
export function ProjectManager({
  projects,
  canCreate,
  canDelete,
}: {
  readonly projects: readonly ProjectRow[];
  readonly canCreate: boolean;
  readonly canDelete: boolean;
}) {
  const router = useRouter();
  const [creating, setCreating] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [confirming, setConfirming] = useState<ProjectRow | null>(null);

  async function create(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setErrors({});
    setMessage(null);

    const data = new FormData(event.currentTarget);
    const response = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify({ name: data.get('name'), description: data.get('description') }),
    });
    const payload = (await response.json()) as {
      ok?: boolean;
      message?: string;
      errors?: Record<string, string>;
    };

    setBusy(false);
    if (response.ok && payload.ok) {
      setCreating(false);
      router.refresh();
      return;
    }
    setErrors(payload.errors ?? {});
    // A 402 means the plan limit was hit — the message explains the limit.
    setMessage(payload.message ?? 'Could not create the project.');
  }

  async function remove(project: ProjectRow) {
    setBusy(true);
    const response = await fetch(`/api/projects/${project.id}`, {
      method: 'DELETE',
      headers: { 'x-csrf-token': readCsrfCookie() },
    });
    const payload = (await response.json()) as { ok?: boolean; message?: string };
    setBusy(false);
    setConfirming(null);

    if (response.ok && payload.ok) {
      router.refresh();
      return;
    }
    setMessage(payload.message ?? 'Could not delete the project.');
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Projects</h1>
          <p className="mt-1 text-sm text-fg-muted">
            Each project keeps its own business data, brand, content and analytics.
          </p>
        </div>
        {canCreate ? (
          <Button onClick={() => setCreating((open) => !open)}>New project</Button>
        ) : null}
      </div>

      {message ? (
        <Alert tone="warning" live>
          {message}
        </Alert>
      ) : null}

      {creating ? (
        <Card className="p-6">
          <h2 className="font-semibold tracking-tight">New project</h2>
          <form onSubmit={create} noValidate className="mt-5 flex flex-col gap-5">
            <Field id="project-name" label="Project name" required error={errors.name}>
              {({ id, invalid }) => (
                <Input id={id} name="name" required autoFocus aria-invalid={invalid || undefined} />
              )}
            </Field>
            <Field id="project-description" label="Description" hint="Optional">
              {({ id }) => <Textarea id={id} name="description" rows={3} />}
            </Field>
            <div className="flex gap-3">
              <Button type="submit" disabled={busy}>
                {busy ? 'Creating…' : 'Create project'}
              </Button>
              <Button type="button" variant="ghost" onClick={() => setCreating(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {projects.map((project) => (
          <li key={project.id}>
            <Card className="flex h-full flex-col p-5">
              <div className="flex items-start justify-between gap-3">
                <h2 className="font-semibold tracking-tight">{project.name}</h2>
                <Badge tone={project.status === 'active' ? 'success' : 'neutral'}>
                  {project.status}
                </Badge>
              </div>
              <p className="mt-2 flex-1 text-sm text-fg-muted">
                {project.description || 'No description yet.'}
              </p>
              <p className="mt-3 font-mono text-xs text-fg-subtle">/{project.slug}</p>
              {canDelete ? (
                <Button
                  variant="ghost"
                  size="sm"
                  className="mt-4 self-start text-danger"
                  onClick={() => setConfirming(project)}
                >
                  Delete
                </Button>
              ) : null}
            </Card>
          </li>
        ))}
      </ul>

      <Modal
        open={confirming !== null}
        onClose={() => setConfirming(null)}
        title={`Delete ${confirming?.name ?? 'project'}?`}
        description="The project and everything in it will be removed from your workspace."
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirming(null)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              disabled={busy}
              onClick={() => confirming && remove(confirming)}
            >
              {busy ? 'Deleting…' : 'Delete project'}
            </Button>
          </>
        }
      >
        <p>
          This is a soft delete: the record is retained briefly so it can be restored by support,
          then permanently removed. It disappears from your workspace immediately.
        </p>
      </Modal>
    </div>
  );
}
