'use client';

import { ResendVerification } from '@/components/auth/recovery-forms';
import { Icon } from '@/components/ui/icon';

/**
 * Shown while an account's email address is unconfirmed.
 *
 * Sign-in is NOT blocked on verification — a bounced confirmation email would
 * otherwise strand the user completely. Instead the state is visible and the
 * resend control is one click away, and features that send email on the user's
 * behalf check verification separately.
 */
export function VerifyBanner({ email }: { readonly email: string }) {
  return (
    <div className="border-b border-warning/40 bg-warning-subtle px-4 py-3 sm:px-6 lg:px-8">
      <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center gap-3">
        <Icon name="mail" size={18} className="text-warning" />
        <p className="flex-1 text-sm">
          Confirm your email address to finish securing your account. We sent a link to{' '}
          <span className="font-medium">{email}</span>.
        </p>
        <ResendVerification email={email} />
      </div>
    </div>
  );
}
