import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { formatLimit, LIMITS } from '@/content/plans';
import type { LimitStatus } from '@/lib/quota';
import type { MetricTotal, UsageDashboard as UsageDashboardData } from '@/lib/usage/service';
import { cn } from '@/lib/utils/cn';

/**
 * The usage dashboard.
 *
 * THE HARD PART IS NOT THE BARS, IT IS THE THREE ZERO-LIKE STATES. A limit can
 * be unlimited (`null`), not included in the plan (`0`), or included and
 * unused — and all three render as an empty bar if you are careless. So:
 *
 *  - unlimited draws no bar at all, and says "Unlimited";
 *  - not included draws a full, muted bar and says "Not on this plan", never
 *    "0 of 0 used", which reads like a bug;
 *  - included and unused draws an empty bar with a real denominator.
 *
 * A limit raised by an override shows the reason. A customer whose screen
 * disagrees with the pricing page is owed an explanation on the same screen.
 */

export function UsageMeter({ status }: { readonly status: LimitStatus }) {
  const { limit } = status;
  const definition = LIMITS[limit.id];
  const unlimited = limit.value === null;
  const notIncluded = limit.value === 0;

  return (
    <div className="flex flex-col gap-1.5 py-3">
      <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
        <span className="text-sm font-medium text-fg">{definition.label}</span>
        <span className="text-sm text-fg-muted">
          {unlimited ? (
            'Unlimited'
          ) : notIncluded ? (
            'Not on this plan'
          ) : (
            <>
              {status.used.toLocaleString('en-IN')} of {formatLimit(limit.value)}
              {definition.unit ? ` ${definition.unit}` : ''}
            </>
          )}
        </span>
      </div>

      {unlimited ? null : (
        <div
          className="h-2 overflow-hidden rounded-full bg-bg-muted"
          role="progressbar"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={status.percentUsed ?? 0}
          aria-label={`${definition.label} used`}
        >
          <div
            className={cn(
              'h-full rounded-full transition-[width] duration-300 ease-out',
              notIncluded
                ? 'bg-border-strong'
                : status.exhausted
                  ? 'bg-danger'
                  : status.nearLimit
                    ? 'bg-warning'
                    : 'bg-primary',
            )}
            style={{ width: `${status.percentUsed ?? 0}%` }}
          />
        </div>
      )}

      <div className="flex flex-wrap items-center gap-2">
        {limit.kind === 'per_period' ? (
          <span className="text-xs text-fg-subtle">Resets monthly.</span>
        ) : (
          <span className="text-xs text-fg-subtle">A standing total, not a monthly one.</span>
        )}
        {status.exhausted && !notIncluded ? (
          <Badge tone="danger">Used up</Badge>
        ) : status.nearLimit && !notIncluded ? (
          <Badge tone="warning">Nearly used up</Badge>
        ) : null}
        {limit.source === 'override' && limit.override ? (
          <span className="text-xs text-fg-muted">
            Adjusted for your account: {limit.override.reason}
          </span>
        ) : null}
      </div>
    </div>
  );
}

export function UsageDashboardView({
  data,
  planName,
  writable,
  blockedReason,
}: {
  readonly data: UsageDashboardData;
  readonly planName: string;
  readonly writable: boolean;
  readonly blockedReason?: string | undefined;
}) {
  const perPeriod = data.limits.filter((status) => status.limit.kind === 'per_period');
  const absolute = data.limits.filter((status) => status.limit.kind === 'absolute');

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <CardTitle as="h2">{planName}</CardTitle>
              <CardDescription>
                This period started {formatDate(data.periodStart)} and resets{' '}
                {formatDate(data.resetsAt)}.
              </CardDescription>
            </div>
            {writable ? (
              <Badge tone="success">Active</Badge>
            ) : (
              <Badge tone="danger">Read-only</Badge>
            )}
          </div>
        </CardHeader>
        {blockedReason ? (
          <div className="px-6 pb-6 pt-4">
            <p className="rounded-control border border-warning/40 bg-warning-subtle px-3.5 py-2.5 text-sm text-warning">
              {blockedReason}
            </p>
          </div>
        ) : null}
      </Card>

      {data.pressure.length > 0 ? (
        <Card tone="subtle">
          <CardHeader>
            <CardTitle as="h2">Close to a limit</CardTitle>
            <CardDescription>
              {data.pressure.length === 1
                ? 'One limit is nearly used up.'
                : `${data.pressure.length} limits are nearly used up.`}
            </CardDescription>
          </CardHeader>
          <div className="divide-y divide-border px-6 pb-4">
            {data.pressure.map((status) => (
              <UsageMeter key={status.limit.id} status={status} />
            ))}
          </div>
        </Card>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle as="h2">This month</CardTitle>
          <CardDescription>Everything counted per period. Resets on the 1st, UTC.</CardDescription>
        </CardHeader>
        <div className="divide-y divide-border px-6 pb-4">
          {perPeriod.map((status) => (
            <UsageMeter key={status.limit.id} status={status} />
          ))}
        </div>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle as="h2">Totals</CardTitle>
          <CardDescription>
            These do not reset. Deleting a project frees its place immediately.
          </CardDescription>
        </CardHeader>
        <div className="divide-y divide-border px-6 pb-4">
          {absolute.map((status) => (
            <UsageMeter key={status.limit.id} status={status} />
          ))}
        </div>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle as="h2">What is counted</CardTitle>
          <CardDescription>
            Eight measurements, each with last month beside it for comparison.
          </CardDescription>
        </CardHeader>
        <div className="overflow-x-auto px-6 pb-6">
          <table className="w-full min-w-[32rem] text-sm">
            <caption className="sr-only">Usage this period against last period</caption>
            <thead>
              <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-fg-subtle">
                <th scope="col" className="py-2 pr-4 font-medium">
                  Measurement
                </th>
                <th scope="col" className="py-2 pr-4 text-right font-medium">
                  This month
                </th>
                <th scope="col" className="py-2 pr-4 text-right font-medium">
                  Last month
                </th>
                <th scope="col" className="py-2 text-right font-medium">
                  Change
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {data.tracked.map((metric) => (
                <tr key={metric.metric}>
                  <th scope="row" className="py-2 pr-4 text-left font-normal text-fg">
                    {metric.label}
                  </th>
                  <td className="py-2 pr-4 text-right tabular-nums text-fg">
                    {metric.total.toLocaleString('en-IN')}
                  </td>
                  <td className="py-2 pr-4 text-right tabular-nums text-fg-muted">
                    {metric.previousTotal.toLocaleString('en-IN')}
                  </td>
                  <td className="py-2 text-right tabular-nums text-fg-muted">
                    {changeLabel(metric)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {data.recentRefusals.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle as="h2">Recently refused</CardTitle>
            <CardDescription>
              Requests SeSha turned down for a limit, and the reason given at the time.
            </CardDescription>
          </CardHeader>
          <ul className="flex flex-col gap-3 px-6 pb-6 text-sm">
            {data.recentRefusals.map((refusal, index) => (
              <li key={`${refusal.limitId}-${refusal.refusedAt}-${index}`} className="flex flex-col">
                <span className="text-fg">{refusal.reason}</span>
                <span className="text-xs text-fg-subtle">{formatDateTime(refusal.refusedAt)}</span>
              </li>
            ))}
          </ul>
        </Card>
      ) : null}
    </div>
  );
}

/**
 * The change column.
 *
 * "No change" is written out rather than shown as 0%, and a rise from zero is
 * "new this month" rather than an infinite percentage.
 */
function changeLabel(metric: MetricTotal): string {
  if (metric.total === metric.previousTotal) return 'No change';
  if (metric.previousTotal === 0) return 'New this month';
  const delta = ((metric.total - metric.previousTotal) / metric.previousTotal) * 100;
  const rounded = Math.round(Math.abs(delta));
  if (rounded === 0) return metric.total > metric.previousTotal ? 'Slightly up' : 'Slightly down';
  return `${metric.total > metric.previousTotal ? '+' : '−'}${rounded}%`;
}

function formatDate(value: string): string {
  const date = new Date(value.length === 10 ? `${value}T00:00:00Z` : value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  });
}

function formatDateTime(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString('en-IN', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'UTC',
  });
}
