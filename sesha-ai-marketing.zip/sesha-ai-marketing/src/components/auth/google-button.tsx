import { Icon } from '@/components/ui/icon';

/**
 * Google sign-in entry point.
 *
 * A plain link, not a fetch: the flow is a top-level navigation to Google, and
 * the start route sets the httpOnly state cookie on the way out.
 *
 * When Google is not configured on a deployment, the control renders disabled
 * with an explanation instead of failing on click.
 */
export function GoogleButton({ configured }: { readonly configured: boolean }) {
  if (!configured) {
    return (
      <div className="rounded-control border border-dashed border-border-strong px-4 py-3 text-center">
        <p className="text-sm font-medium text-fg-muted">Google sign-in is not enabled</p>
        <p className="mt-1 text-xs text-fg-subtle">
          Set GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET and GOOGLE_REDIRECT_URI to turn it on.
        </p>
      </div>
    );
  }

  return (
    <a
      href="/api/auth/google/start"
      className="inline-flex h-11 w-full items-center justify-center gap-2.5 rounded-control border border-border-strong bg-surface px-5 text-sm font-medium text-fg shadow-xs transition-colors duration-150 hover:bg-bg-muted"
    >
      <Icon name="google" size={18} />
      Continue with Google
    </a>
  );
}

export function AuthDivider() {
  return (
    <div className="my-6 flex items-center gap-3">
      <span className="h-px flex-1 bg-border" />
      <span className="text-xs uppercase tracking-[0.12em] text-fg-subtle">or</span>
      <span className="h-px flex-1 bg-border" />
    </div>
  );
}
