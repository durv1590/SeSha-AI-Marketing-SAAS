'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';

import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Field, Input } from '@/components/ui/field';
import { PASSWORD_MIN_LENGTH } from '@/lib/auth/password';

/**
 * Forgot-password form.
 *
 * The confirmation is IDENTICAL whether or not the address has an account, and
 * it is shown immediately after submit. Anything else would make this page a
 * public tool for discovering who has an account.
 */
export function ForgotPasswordForm() {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'sent'>('idle');
  const [message, setMessage] = useState('');

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus('submitting');
    const data = new FormData(event.currentTarget);

    try {
      const response = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: data.get('email') }),
      });
      const payload = (await response.json()) as { message?: string };
      setMessage(payload.message ?? 'If that address has an account, a reset link is on its way.');
      setStatus('sent');
    } catch {
      setStatus('idle');
      setMessage('Network error. Please try again.');
    }
  }

  if (status === 'sent') {
    return (
      <div className="flex flex-col gap-5">
        <Alert tone="info" title="Check your email" live>
          {message}
        </Alert>
        <p className="text-sm leading-relaxed text-fg-muted">
          The link expires in 30 minutes and can be used once. If it does not arrive, check your
          spam folder before requesting another.
        </p>
        <Button href="/sign-in" variant="secondary" block>
          Back to sign in
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="flex flex-col gap-5">
      <Field id="forgot-email" label="Email" required>
        {({ id }) => (
          <Input id={id} name="email" type="email" autoComplete="email" required autoFocus />
        )}
      </Field>
      <Button type="submit" size="lg" block disabled={status === 'submitting'}>
        {status === 'submitting' ? 'Sending…' : 'Send reset link'}
      </Button>
    </form>
  );
}

/** Reset form. The token comes from the emailed link, never from the user. */
export function ResetPasswordForm() {
  const router = useRouter();
  const params = useSearchParams();
  const token = params.get('token') ?? '';
  const [status, setStatus] = useState<'idle' | 'submitting' | 'done'>('idle');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [message, setMessage] = useState<string | null>(null);

  if (!token) {
    return (
      <Alert tone="danger" title="Missing reset link">
        Open the link from your email. If it has expired,{' '}
        <a href="/forgot-password" className="underline underline-offset-4">
          request a new one
        </a>
        .
      </Alert>
    );
  }

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus('submitting');
    setErrors({});
    setMessage(null);

    const data = new FormData(event.currentTarget);
    const password = String(data.get('password') ?? '');
    if (password !== String(data.get('confirm') ?? '')) {
      setStatus('idle');
      setErrors({ confirm: 'The two passwords do not match.' });
      return;
    }

    try {
      const response = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, password }),
      });
      const payload = (await response.json()) as {
        ok?: boolean;
        message?: string;
        errors?: Record<string, string>;
      };

      if (response.ok && payload.ok) {
        setStatus('done');
        setMessage(payload.message ?? 'Password updated.');
        return;
      }
      setStatus('idle');
      setErrors(payload.errors ?? {});
      setMessage(payload.message ?? 'That link is no longer valid.');
    } catch {
      setStatus('idle');
      setMessage('Network error. Please try again.');
    }
  }

  if (status === 'done') {
    return (
      <div className="flex flex-col gap-5">
        <Alert tone="success" title="Password updated" live>
          {message} Every other device has been signed out.
        </Alert>
        <Button onClick={() => router.push('/sign-in')} size="lg" block>
          Sign in
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="flex flex-col gap-5">
      {message ? (
        <Alert tone="danger" live>
          {message}
        </Alert>
      ) : null}

      <Field
        id="reset-password"
        label="New password"
        hint={`At least ${PASSWORD_MIN_LENGTH} characters.`}
        required
        error={errors.password}
      >
        {({ id, invalid }) => (
          <Input
            id={id}
            name="password"
            type="password"
            autoComplete="new-password"
            minLength={PASSWORD_MIN_LENGTH}
            required
            autoFocus
            aria-invalid={invalid || undefined}
          />
        )}
      </Field>

      <Field id="reset-confirm" label="Confirm new password" required error={errors.confirm}>
        {({ id, invalid }) => (
          <Input
            id={id}
            name="confirm"
            type="password"
            autoComplete="new-password"
            required
            aria-invalid={invalid || undefined}
          />
        )}
      </Field>

      <Button type="submit" size="lg" block disabled={status === 'submitting'}>
        {status === 'submitting' ? 'Updating…' : 'Set new password'}
      </Button>
    </form>
  );
}

/** Consumes a verification token from the emailed link on mount. */
export function VerifyEmailPanel() {
  const params = useSearchParams();
  const token = params.get('token') ?? '';
  const [state, setState] = useState<'checking' | 'ok' | 'failed' | 'missing'>(
    token ? 'checking' : 'missing',
  );
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (!token) return;
    let cancelled = false;

    void (async () => {
      try {
        const response = await fetch('/api/auth/verify-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token }),
        });
        const payload = (await response.json()) as { ok?: boolean; message?: string };
        if (cancelled) return;
        if (response.ok && payload.ok) {
          setState('ok');
          setMessage(payload.message ?? 'Your email address is confirmed.');
        } else {
          setState('failed');
          setMessage(payload.message ?? 'That confirmation link is invalid or has expired.');
        }
      } catch {
        if (!cancelled) {
          setState('failed');
          setMessage('Network error. Please try again.');
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [token]);

  if (state === 'missing') {
    return (
      <Alert tone="danger" title="Missing confirmation link">
        Open the link from your email.
      </Alert>
    );
  }

  if (state === 'checking') {
    return (
      <p role="status" aria-live="polite" className="text-sm text-fg-muted">
        Confirming your email address…
      </p>
    );
  }

  return (
    <div className="flex flex-col gap-5">
      <Alert tone={state === 'ok' ? 'success' : 'danger'} live>
        {message}
      </Alert>
      <Button href={state === 'ok' ? '/app' : '/sign-in'} size="lg" block>
        {state === 'ok' ? 'Go to your workspace' : 'Back to sign in'}
      </Button>
    </div>
  );
}

/** Resend control, shown to signed-in users whose address is unconfirmed. */
export function ResendVerification({ email }: { readonly email: string }) {
  const [state, setState] = useState<'idle' | 'sending' | 'sent'>('idle');

  return (
    <div className="flex flex-wrap items-center gap-3">
      <Button
        variant="secondary"
        size="sm"
        disabled={state !== 'idle'}
        onClick={async () => {
          setState('sending');
          try {
            await fetch('/api/auth/resend-verification', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ email }),
            });
          } finally {
            setState('sent');
          }
        }}
      >
        {state === 'sent' ? 'Link sent' : state === 'sending' ? 'Sending…' : 'Resend confirmation'}
      </Button>
      <span role="status" aria-live="polite" className="text-xs text-fg-muted">
        {state === 'sent' ? 'Check your inbox.' : ''}
      </span>
    </div>
  );
}
