'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { useState } from 'react';

import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Field, Input } from '@/components/ui/field';

/**
 * Sign-in form.
 *
 * The error message is always the same for any credential failure, mirroring
 * what the API returns. Showing "no account with that email" here would undo
 * the enumeration protection the server went to some trouble to provide.
 */

const OAUTH_ERRORS: Record<string, string> = {
  cancelled: 'Google sign-in was cancelled.',
  invalid_request: 'That sign-in link was not valid. Please try again.',
  exchange_failed: 'We could not complete Google sign-in. Please try again.',
  verification_failed: 'We could not verify the Google response. Please try again.',
  email_unverified: 'Your Google account email is not verified. Verify it with Google first.',
  account_exists_use_password:
    'An account with that email already exists. Sign in with your password, then link Google in settings.',
  google_unavailable: 'Google sign-in is not enabled on this deployment.',
};

export function SignInForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [status, setStatus] = useState<'idle' | 'submitting'>('idle');
  const [message, setMessage] = useState<string | null>(
    OAUTH_ERRORS[params.get('error') ?? ''] ?? null,
  );

  /** Only a same-site path is ever used, so this cannot become an open redirect. */
  function safeNext(): string {
    const next = params.get('next');
    if (!next || !next.startsWith('/') || next.startsWith('//')) return '/app';
    return next;
  }

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus('submitting');
    setMessage(null);

    const data = new FormData(event.currentTarget);
    try {
      const response = await fetch('/api/auth/signin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: data.get('email'), password: data.get('password') }),
      });
      const payload = (await response.json()) as {
        ok?: boolean;
        message?: string;
        data?: { onboardingComplete?: boolean };
      };

      if (response.ok && payload.ok) {
        router.push(payload.data?.onboardingComplete ? safeNext() : '/onboarding');
        router.refresh();
        return;
      }
      setStatus('idle');
      setMessage(payload.message ?? 'Email or password is incorrect.');
    } catch {
      setStatus('idle');
      setMessage('Network error. Please try again.');
    }
  }

  return (
    <form onSubmit={onSubmit} noValidate className="flex flex-col gap-5">
      {message ? (
        <Alert tone="danger" live>
          {message}
        </Alert>
      ) : null}

      <Field id="signin-email" label="Email" required>
        {({ id }) => (
          <Input id={id} name="email" type="email" autoComplete="email" required autoFocus />
        )}
      </Field>

      <Field id="signin-password" label="Password" required>
        {({ id }) => (
          <Input id={id} name="password" type="password" autoComplete="current-password" required />
        )}
      </Field>

      <div className="flex items-center justify-between">
        <Link
          href="/forgot-password"
          className="text-sm font-medium text-primary hover:text-primary-hover"
        >
          Forgot your password?
        </Link>
      </div>

      <Button type="submit" size="lg" block disabled={status === 'submitting'}>
        {status === 'submitting' ? 'Signing in…' : 'Sign in'}
      </Button>
    </form>
  );
}
