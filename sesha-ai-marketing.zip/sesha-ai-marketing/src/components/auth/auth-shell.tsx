import Link from 'next/link';
import type { ReactNode } from 'react';

import { Logo } from '@/components/layout/logo';
import { Container } from '@/components/layout/container';

/**
 * Layout for the sign-in, sign-up and recovery pages.
 *
 * Narrow, centred, and free of the marketing navigation — someone here is
 * trying to get into an account, not browse. The page's single h1 lives here.
 */
export function AuthShell({
  title,
  intro,
  children,
  footer,
}: {
  readonly title: string;
  readonly intro?: string;
  readonly children: ReactNode;
  readonly footer?: ReactNode;
}) {
  return (
    <div className="surface-gradient flex min-h-dvh flex-col">
      {/*
        A skip link and a <main> landmark, which this route group did not have.
        Every other shell in the product has both; the auth pages were the gap.
        They are short, so the skip link saves only a few tabs — but the missing
        <main> is the real defect: a screen-reader user navigating by landmark
        found no main region at all on the one page where they are trying to get
        into their account.
      */}
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <Container
        id="main"
        tabIndex={-1}
        as="main"
        className="flex flex-1 flex-col items-center justify-center py-12 focus:outline-none"
      >
        <div className="w-full max-w-md">
          <div className="mb-8 flex justify-center">
            <Logo />
          </div>

          <div className="rounded-card border border-border bg-surface p-7 shadow-md sm:p-8">
            <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
            {intro ? <p className="mt-2 text-sm leading-relaxed text-fg-muted">{intro}</p> : null}
            <div className="mt-7">{children}</div>
          </div>

          {footer ? <div className="mt-6 text-center text-sm text-fg-muted">{footer}</div> : null}

          <p className="mt-8 text-center text-xs text-fg-subtle">
            <Link href="/privacy" className="hover:text-fg-muted hover:underline underline-offset-4">
              Privacy
            </Link>
            <span className="mx-2" aria-hidden="true">
              ·
            </span>
            <Link href="/terms" className="hover:text-fg-muted hover:underline underline-offset-4">
              Terms
            </Link>
            <span className="mx-2" aria-hidden="true">
              ·
            </span>
            <Link href="/security" className="hover:text-fg-muted hover:underline underline-offset-4">
              Security
            </Link>
          </p>
        </div>
      </Container>
    </div>
  );
}
