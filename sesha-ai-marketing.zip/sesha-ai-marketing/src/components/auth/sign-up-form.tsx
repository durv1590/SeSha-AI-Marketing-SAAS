'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Checkbox, Field, Honeypot, Input } from '@/components/ui/field';
import { PASSWORD_MIN_LENGTH } from '@/lib/auth/password';

/**
 * Registration form.
 *
 * Client-side length hinting is a convenience; the server runs the real policy
 * and its problems are what get displayed. On success the response is the same
 * whether or not the address was already registered, so this component shows
 * the same "check your email" screen either way — by design.
 */
export function SignUpForm() {
  const router = useRouter();
  const [status, setStatus] = useState<'idle' | 'submitting' | 'sent'>('idle');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [message, setMessage] = useState<string | null>(null);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus('submitting');
    setErrors({});
    setMessage(null);

    const data = new FormData(event.currentTarget);
    if (String(data.get('website') ?? '').length > 0) {
      // Honeypot filled: pretend it worked.
      setStatus('sent');
      return;
    }

    try {
      const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: data.get('name'),
          email: data.get('email'),
          password: data.get('password'),
        }),
      });
      const payload = (await response.json()) as {
        ok?: boolean;
        message?: string;
        errors?: Record<string, string>;
      };

      if (response.ok && payload.ok) {
        setStatus('sent');
        setMessage(payload.message ?? 'Check your email to confirm your address.');
        // A brand new account is signed straight in, so onboarding can start.
        router.refresh();
        return;
      }

      setStatus('idle');
      setErrors(payload.errors ?? {});
      setMessage(payload.message ?? 'Please check your details.');
    } catch {
      setStatus('idle');
      setMessage('Network error. Please try again.');
    }
  }

  if (status === 'sent') {
    return (
      <div className="flex flex-col gap-5">
        <Alert tone="success" title="Almost there" live>
          {message}
        </Alert>
        <p className="text-sm leading-relaxed text-fg-muted">
          We have sent a confirmation link. If an account already existed for that address, we have
          told its owner instead — either way, nothing else is revealed here.
        </p>
        <Button href="/onboarding" size="lg" block>
          Continue to set-up
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="relative flex flex-col gap-5">
      <Honeypot name="website" />

      {message && status === 'idle' ? (
        <Alert tone="danger" live>
          {message}
        </Alert>
      ) : null}

      <Field id="signup-name" label="Your name">
        {({ id }) => <Input id={id} name="name" autoComplete="name" autoFocus />}
      </Field>

      <Field id="signup-email" label="Work email" required error={errors.email}>
        {({ id, invalid }) => (
          <Input
            id={id}
            name="email"
            type="email"
            autoComplete="email"
            required
            aria-invalid={invalid || undefined}
          />
        )}
      </Field>

      <Field
        id="signup-password"
        label="Password"
        hint={`At least ${PASSWORD_MIN_LENGTH} characters. A few ordinary words beat one clever word.`}
        required
        error={errors.password}
      >
        {({ id, invalid }) => (
          <Input
            id={id}
            name="password"
            type="password"
            autoComplete="new-password"
            minLength={PASSWORD_MIN_LENGTH}
            required
            aria-invalid={invalid || undefined}
          />
        )}
      </Field>

      <Checkbox
        id="signup-terms"
        name="terms"
        required
        label={
          <>
            I agree to the{' '}
            <a href="/terms" className="text-primary underline underline-offset-4">
              terms of service
            </a>{' '}
            and{' '}
            <a href="/privacy" className="text-primary underline underline-offset-4">
              privacy policy
            </a>
            .
          </>
        }
      />

      <Button type="submit" size="lg" block disabled={status === 'submitting'}>
        {status === 'submitting' ? 'Creating your account…' : 'Create account'}
      </Button>
    </form>
  );
}
