'use client';

import { useMemo, useState } from 'react';

import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  NO_CONNECTED_DATA,
  SOURCE_LABEL,
  SOURCE_MEANING,
  change,
  formatValue,
  type MetricValue,
  type SourceKind,
} from '@/lib/analytics/metrics';

/**
 * The analytics board.
 *
 * THE RULE THIS COMPONENT EXISTS TO ENFORCE
 * There is no code path here that renders a number without its source label. A
 * metric with no figure renders the reason and what would make it available —
 * never a dash, never a zero, never a greyed-out "0" that a reader will take for
 * a measurement of nothing.
 *
 * That is why `MetricCard` switches on `value.kind` and has an `unavailable`
 * branch that returns early. A shared "render the number" path with a
 * `value ?? 0` in it is exactly how a fabricated zero gets onto a dashboard.
 */

export interface MetricView {
  readonly id: string;
  readonly label: string;
  readonly description: string;
  readonly group: string;
  readonly higherIsBetter: boolean;
  readonly value: MetricValue;
  readonly previous?: MetricValue;
}

export interface ConnectionView {
  readonly provider: string;
  readonly label: string;
  readonly connected: boolean;
  readonly howToConnect: string;
  readonly problem: string | null;
}

export interface MetricBoardProps {
  readonly metrics: readonly MetricView[];
  readonly connections: readonly ConnectionView[];
  readonly anyConnected: boolean;
  readonly explanation: string;
  readonly periodLabel: string;
}

const GROUP_LABEL: Readonly<Record<string, string>> = {
  pipeline: 'Your pipeline',
  audience: 'Audience',
  advertising: 'Advertising',
  search: 'Search',
  content: 'Content',
  technical: 'Technical',
};

const GROUP_ORDER = ['pipeline', 'technical', 'content', 'search', 'audience', 'advertising'];

export function MetricBoard({
  metrics,
  connections,
  anyConnected,
  explanation,
  periodLabel,
}: MetricBoardProps) {
  const [showSources, setShowSources] = useState(false);

  const grouped = useMemo(() => {
    const map = new Map<string, MetricView[]>();
    for (const metric of metrics) {
      const list = map.get(metric.group) ?? [];
      list.push(metric);
      map.set(metric.group, list);
    }
    return GROUP_ORDER.filter((group) => map.has(group)).map((group) => ({
      group,
      metrics: map.get(group) ?? [],
    }));
  }, [metrics]);

  const measured = metrics.filter((metric) => metric.value.kind !== 'unavailable').length;

  return (
    <div className="flex flex-col gap-6">
      {!anyConnected && (
        <Alert tone="info" title={NO_CONNECTED_DATA}>
          <p>{explanation}</p>
          <p className="mt-2">
            {measured} of {metrics.length} figures below are calculated from your own SeSha records.
            The rest are marked unavailable. They are not zero — they have not been measured.
          </p>
        </Alert>
      )}

      <div className="flex flex-wrap items-center gap-3">
        <Badge tone="neutral">{periodLabel}</Badge>
        <button
          type="button"
          onClick={() => setShowSources((current) => !current)}
          className="text-sm font-medium text-primary underline underline-offset-4"
        >
          {showSources ? 'Hide what the labels mean' : 'What do the source labels mean?'}
        </button>
      </div>

      {showSources && (
        <Card tone="subtle">
          <CardContent className="flex flex-col gap-3">
            {(Object.keys(SOURCE_LABEL) as SourceKind[]).map((kind) => (
              <div key={kind}>
                <p className="text-sm font-semibold">{SOURCE_LABEL[kind]}</p>
                <p className="text-sm leading-relaxed text-fg-muted">{SOURCE_MEANING[kind]}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {grouped.map(({ group, metrics: groupMetrics }) => (
        <section key={group} className="flex flex-col gap-3">
          <h2 className="text-lg font-semibold tracking-tight">{GROUP_LABEL[group] ?? group}</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {groupMetrics.map((metric) => (
              <MetricCard key={metric.id} metric={metric} />
            ))}
          </div>
        </section>
      ))}

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold tracking-tight">Data sources</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          {connections.map((connection) => (
            <Card key={connection.provider}>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <CardTitle as="h3">{connection.label}</CardTitle>
                  <Badge tone={connection.connected ? 'success' : 'neutral'}>
                    {connection.connected ? 'Connected' : 'Not connected'}
                  </Badge>
                </div>
                <CardDescription>
                  {connection.problem ?? connection.howToConnect}
                </CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}

function MetricCard({ metric }: { readonly metric: MetricView }) {
  const value = metric.value;

  // The early return is the point: there is no path from here to a rendered
  // number for a metric we do not have.
  if (value.kind === 'unavailable') {
    return (
      <Card tone="subtle">
        <CardHeader>
          <div className="flex items-center gap-2">
            <CardTitle as="h3" className="text-base">
              {metric.label}
            </CardTitle>
            <Badge tone="neutral">{SOURCE_LABEL.unavailable}</Badge>
          </div>
        </CardHeader>
        <CardContent className="pt-3">
          <p className="text-sm leading-relaxed text-fg-muted">{value.why}</p>
          <p className="mt-2 text-sm font-medium">{value.whatWouldMakeItAvailable}</p>
        </CardContent>
      </Card>
    );
  }

  if (value.kind === 'ai_estimate') {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <CardTitle as="h3" className="text-base">
              {metric.label}
            </CardTitle>
            <Badge tone="warning">{SOURCE_LABEL.ai_estimate}</Badge>
          </div>
        </CardHeader>
        <CardContent className="pt-3">
          <p className="text-xl font-semibold">{value.band.replace('_', ' ')}</p>
          <p className="mt-2 text-sm leading-relaxed text-fg-muted">{value.basis}</p>
        </CardContent>
      </Card>
    );
  }

  const formatted = formatValue(value);
  const movement = change(value, metric.previous);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <CardTitle as="h3" className="text-base">
            {metric.label}
          </CardTitle>
          <Badge tone="info">{SOURCE_LABEL[value.kind]}</Badge>
        </div>
      </CardHeader>
      <CardContent className="pt-3">
        <p className="text-2xl font-semibold tracking-tight">{formatted}</p>

        {movement && (
          <p className="mt-1 text-sm text-fg-muted">
            {movement.direction === 'flat'
              ? 'Unchanged from the period before.'
              : `${movement.direction === 'up' ? 'Up' : 'Down'} ${
                  movement.percent === null
                    ? Math.abs(movement.delta)
                    : `${Math.abs(Math.round(movement.percent))}%`
                } on the period before${
                  metric.higherIsBetter === (movement.direction === 'up')
                    ? '.'
                    : ' — the wrong direction.'
                }`}
          </p>
        )}

        <p className="mt-2 text-sm leading-relaxed text-fg-muted">{metric.description}</p>

        {value.kind === 'calculated' && (
          <details className="mt-3">
            <summary className="cursor-pointer text-sm font-medium text-primary">
              How this was worked out
            </summary>
            <p className="mt-2 text-sm leading-relaxed text-fg-muted">{value.formula}</p>
            {value.inputs.length > 0 && (
              <ul className="mt-2 flex flex-col gap-1 text-sm text-fg-muted">
                {value.inputs.map((input) => (
                  <li key={input.label}>
                    {input.label}: <strong>{input.value}</strong>
                  </li>
                ))}
              </ul>
            )}
            <p className="mt-2 text-xs text-fg-muted">As of {value.asOf}</p>
          </details>
        )}

        {value.kind === 'connected_api' && (
          <p className="mt-2 text-xs text-fg-muted">
            From {value.source}, read at {value.asOf}.
          </p>
        )}
        {value.kind === 'retrieved' && (
          <p className="mt-2 text-xs text-fg-muted">
            Read from {value.sourceUrl} at {value.asOf}.
          </p>
        )}
        {value.kind === 'user_provided' && (
          <p className="mt-2 text-xs text-fg-muted">
            Entered by {value.enteredBy} on {value.asOf}. SeSha has not checked it.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
