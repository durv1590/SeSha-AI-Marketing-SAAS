import { serializeJsonLd, type JsonLdNode } from '@/lib/schema';

/**
 * Renders one JSON-LD graph per page.
 *
 * The content is escaped by `serializeJsonLd` before injection so that a value
 * containing "</script>" cannot break out of the tag. One block per page keeps
 * @id cross-references resolvable inside a single graph.
 */
export function JsonLd({ graph }: { readonly graph: JsonLdNode }) {
  return (
    <script
      type="application/ld+json"
      // Content is machine-generated from typed data and escaped above.
      dangerouslySetInnerHTML={{ __html: serializeJsonLd(graph) }}
    />
  );
}
