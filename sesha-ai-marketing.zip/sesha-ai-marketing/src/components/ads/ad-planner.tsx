import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  AD_PLATFORMS,
  AD_PLATFORM_SPECS,
  AD_SPECS_AS_OF,
  OBJECTIVE_LABEL,
  adsDataStatus,
  type AdPlatform,
} from '@/lib/ads/platforms';
import { performanceStatus } from '@/lib/ads/plan';

/**
 * The advertising planning surface.
 *
 * THE SEPARATION THE BRIEF ASKS FOR, MADE VISIBLE
 * "Separate AI recommendations from live data." There is no live data — no ad
 * account is connected — so the honest rendering is not an empty "performance"
 * panel but a stated absence, at the top, before any plan. A screen with a blank
 * metrics row invites the reader to assume the numbers are coming.
 *
 * The platform limits are shown as the real numbers with the date they were
 * reviewed, because a character counter that is silently a year out of date is
 * worse than none.
 */
export interface AdPlanSummary {
  readonly id: string;
  readonly platform: AdPlatform;
  readonly objective: string;
  readonly campaignName: string;
  readonly reviewState: 'draft' | 'in_review' | 'approved' | 'rejected';
  /** Required whenever a plan is rejected — the reason it was turned down. */
  readonly reviewNote: string | null;
  readonly problems: readonly { readonly severity: string; readonly field: string; readonly message: string }[];
  readonly createdAt: string;
}

/**
 * How each review state is shown.
 *
 * A COMPLETE RECORD, not a ternary chain. It was a chain, and it had no branch
 * for `rejected` — a state Phase 6 added to `ad_plans` along with a mandatory
 * review note — so a plan someone had explicitly turned down rendered as
 * "Draft", in the same neutral grey as one nobody had looked at yet. The
 * reviewer's decision simply vanished from the screen.
 *
 * Typed as a full Record so the next state added to the database fails to
 * compile here, which is the only moment anyone is still thinking about it.
 */
const REVIEW_STATE: Readonly<
  Record<
    AdPlanSummary['reviewState'],
    { readonly label: string; readonly tone: 'neutral' | 'success' | 'warning' | 'danger' }
  >
> = {
  draft: { label: 'Draft', tone: 'neutral' },
  in_review: { label: 'In review', tone: 'warning' },
  approved: { label: 'Ready', tone: 'success' },
  rejected: { label: 'Rejected', tone: 'danger' },
};

export interface AdPlannerProps {
  readonly plans: readonly AdPlanSummary[];
}

export function AdPlanner({ plans }: AdPlannerProps) {
  const data = adsDataStatus();
  const performance = performanceStatus();

  return (
    <div className="space-y-6">
      <Alert tone="warning" title="No ad account is connected">
        <p>{data.message}</p>
        <p className="mt-2">{performance.reason}</p>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle as="h2" className="text-base">What each platform accepts</CardTitle>
          <CardDescription>
            Published specifications as reviewed {AD_SPECS_AS_OF}. Platforms change these; check
            before a large build.
          </CardDescription>
        </CardHeader>
        <div className="overflow-x-auto border-t border-border">
          <table className="w-full text-sm">
            <caption className="sr-only">Platform limits for this ad plan</caption>
            <thead>
              <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-fg-muted">
                <th scope="col" className="px-4 py-2 font-medium">Platform</th>
                <th scope="col" className="px-4 py-2 font-medium">Format</th>
                <th scope="col" className="px-4 py-2 font-medium">Headline</th>
                <th scope="col" className="px-4 py-2 font-medium">Description</th>
                <th scope="col" className="px-4 py-2 font-medium">Body</th>
                <th scope="col" className="px-4 py-2 font-medium">Objectives</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {AD_PLATFORMS.map((platform) => {
                const spec = AD_PLATFORM_SPECS[platform];
                return (
                  <tr key={platform}>
                    <td className="px-4 py-3 align-top font-medium">{spec.label}</td>
                    <td className="px-4 py-3 align-top text-fg-muted">{spec.format}</td>
                    <td className="px-4 py-3 align-top tabular-nums">
                      {spec.headline.maxCharacters} chars
                      <span className="block text-xs text-fg-muted">
                        {spec.headline.min}–{spec.headline.max} needed
                      </span>
                    </td>
                    <td className="px-4 py-3 align-top tabular-nums">
                      {spec.description.maxCharacters} chars
                      <span className="block text-xs text-fg-muted">
                        {spec.description.min}–{spec.description.max}
                      </span>
                    </td>
                    <td className="px-4 py-3 align-top tabular-nums">
                      {spec.primaryText ? `${spec.primaryText.maxCharacters} chars` : '—'}
                    </td>
                    <td className="px-4 py-3 align-top text-xs text-fg-muted">
                      {spec.objectives.map((objective) => OBJECTIVE_LABEL[objective]).join(', ')}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle as="h2" className="text-base">Your plans</CardTitle>
          <CardDescription>
            A plan is what you take to the platform. Nothing here uploads, spends or measures.
          </CardDescription>
        </CardHeader>
        {plans.length === 0 ? (
          <p className="border-t border-border px-5 py-4 text-sm text-fg-muted">
            No plans yet. Ask the AI Copilot for ad copy, or write a plan and save it here — the
            character limits above are enforced before it can be marked ready.
          </p>
        ) : (
          <ul className="divide-y divide-border border-t border-border">
            {plans.map((plan) => {
              const errors = plan.problems.filter((problem) => problem.severity === 'error');
              return (
                <li key={plan.id} className="px-5 py-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="font-medium">{plan.campaignName}</p>
                      <p className="text-sm text-fg-muted">
                        {AD_PLATFORM_SPECS[plan.platform].label} ·{' '}
                        {OBJECTIVE_LABEL[plan.objective as keyof typeof OBJECTIVE_LABEL] ?? plan.objective}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {errors.length > 0 ? (
                        <Badge tone="danger">{errors.length} error(s)</Badge>
                      ) : null}
                      <Badge tone={REVIEW_STATE[plan.reviewState].tone}>
                        {REVIEW_STATE[plan.reviewState].label}
                      </Badge>
                    </div>
                  </div>
                  {plan.reviewState === 'rejected' && plan.reviewNote ? (
                    <p className="mt-2 text-sm text-danger">
                      Rejected: {plan.reviewNote}
                    </p>
                  ) : null}
                  {plan.problems.length > 0 ? (
                    <ul className="mt-2 ml-4 list-disc space-y-1 text-sm text-fg-muted">
                      {plan.problems.map((problem, index) => (
                        <li key={index}>
                          <span className="font-medium">{problem.field}: </span>
                          {problem.message}
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}
