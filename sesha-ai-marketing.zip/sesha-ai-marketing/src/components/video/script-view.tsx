import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  HOOK_PATTERNS,
  VIDEO_PLATFORMS,
  VIDEO_PLATFORM_SPECS,
  VIDEO_SPECS_AS_OF,
  imageGenerationStatus,
  type VideoPlatform,
} from '@/lib/video/types';

/**
 * Video scripts and thumbnail concepts.
 *
 * THERE IS NO IMAGE ON THIS SCREEN, AND THAT IS STATED.
 * No image-generation API is connected. A thumbnail "concept" here is a written
 * brief — what is in frame, the overlay words, why that earns a click. A grey
 * placeholder box shaped like an image would be read as one that failed to load,
 * which is a quieter lie than an invented picture but still a lie.
 */
export interface ScriptSummary {
  readonly id: string;
  readonly platform: VideoPlatform;
  readonly topic: string;
  readonly totalSeconds: number;
  readonly reviewState: 'draft' | 'in_review' | 'approved';
  readonly problems: readonly { readonly severity: string; readonly field: string; readonly message: string }[];
  readonly createdAt: string;
}

export interface ScriptViewProps {
  readonly scripts: readonly ScriptSummary[];
}

export function ScriptView({ scripts }: ScriptViewProps) {
  const images = imageGenerationStatus();

  return (
    <div className="space-y-6">
      <Alert tone="info" title="No images are generated here">
        <p>{images.message}</p>
        <p className="mt-2">{images.whatYouGetInstead}</p>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle as="h2" className="text-base">Platform limits</CardTitle>
          <CardDescription>As reviewed {VIDEO_SPECS_AS_OF}.</CardDescription>
        </CardHeader>
        <div className="overflow-x-auto border-t border-border">
          <table className="w-full text-sm">
            <caption className="sr-only">Shot list, with durations</caption>
            <thead>
              <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-fg-muted">
                <th scope="col" className="px-4 py-2 font-medium">Platform</th>
                <th scope="col" className="px-4 py-2 font-medium">Ratio</th>
                <th scope="col" className="px-4 py-2 font-medium">Max length</th>
                <th scope="col" className="px-4 py-2 font-medium">Hook window</th>
                <th scope="col" className="px-4 py-2 font-medium">Captions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {VIDEO_PLATFORMS.map((platform) => {
                const spec = VIDEO_PLATFORM_SPECS[platform];
                return (
                  <tr key={platform}>
                    <td className="px-4 py-3 align-top font-medium">{spec.label}</td>
                    <td className="px-4 py-3 align-top text-fg-muted">{spec.aspectRatio}</td>
                    <td className="px-4 py-3 align-top tabular-nums">
                      {spec.maxSeconds >= 60 ? `${Math.round(spec.maxSeconds / 60)} min` : `${spec.maxSeconds}s`}
                    </td>
                    <td className="px-4 py-3 align-top tabular-nums">{spec.hookSeconds}s</td>
                    <td className="px-4 py-3 align-top text-xs text-fg-muted">
                      {spec.soundOffByDefault ? 'Required — plays muted' : 'Recommended'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle as="h2" className="text-base">Hooks that work</CardTitle>
          <CardDescription>
            Patterns, with the shape of each. None of these is a promise about views.
          </CardDescription>
        </CardHeader>
        <ul className="divide-y divide-border border-t border-border text-sm">
          {HOOK_PATTERNS.map((pattern) => (
            <li key={pattern.name} className="px-5 py-3">
              <p className="font-medium">{pattern.name}</p>
              <p className="mt-1 text-fg-muted">{pattern.shape}</p>
              <p className="mt-1 italic text-fg-muted">“{pattern.example}”</p>
            </li>
          ))}
        </ul>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle as="h2" className="text-base">Your scripts</CardTitle>
        </CardHeader>
        {scripts.length === 0 ? (
          <p className="border-t border-border px-5 py-4 text-sm text-fg-muted">
            No scripts yet. Ask the AI Copilot for a script and save it here — the scene durations are
            added up against the platform limit before it can be marked ready.
          </p>
        ) : (
          <ul className="divide-y divide-border border-t border-border">
            {scripts.map((script) => {
              const errors = script.problems.filter((problem) => problem.severity === 'error');
              return (
                <li key={script.id} className="px-5 py-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="font-medium">{script.topic}</p>
                      <p className="text-sm text-fg-muted">
                        {VIDEO_PLATFORM_SPECS[script.platform].label} · {script.totalSeconds}s
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {errors.length > 0 ? <Badge tone="danger">{errors.length} error(s)</Badge> : null}
                      <Badge tone={script.reviewState === 'approved' ? 'success' : 'neutral'}>
                        {script.reviewState === 'approved' ? 'Ready' : script.reviewState}
                      </Badge>
                    </div>
                  </div>
                  {script.problems.length > 0 ? (
                    <ul className="mt-2 ml-4 list-disc space-y-1 text-sm text-fg-muted">
                      {script.problems.map((problem, index) => (
                        <li key={index}>
                          <span className="font-medium">{problem.field}: </span>
                          {problem.message}
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}
