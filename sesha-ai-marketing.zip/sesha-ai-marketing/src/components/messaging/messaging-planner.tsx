import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  EMAIL_KINDS,
  EMAIL_KIND_LABEL,
  EMAIL_LIMITS,
  OPT_IN_LABEL,
  WHATSAPP_KINDS,
  WHATSAPP_KIND_LABEL,
  WHATSAPP_LIMITS,
  categoryFor,
  sendingStatus,
  type OptInBasis,
} from '@/lib/messaging/types';

/**
 * Email and WhatsApp planning.
 *
 * THE FIRST THING ON THE SCREEN IS WHAT THIS CANNOT DO.
 * SeSha cannot send. Saying so at the top, before any draft, is the difference
 * between a planner and a thing a user believes is a sending tool. The same
 * applies to the lawful-basis note: a user planning a campaign to a bought list
 * should meet that refusal before they write a subject line, not after.
 */
export interface MessagingPlanSummary {
  readonly id: string;
  readonly channel: 'email' | 'whatsapp';
  readonly kind: string;
  readonly category: string | null;
  readonly title: string;
  readonly optInBasis: string;
  readonly audienceNote: string;
  readonly reviewState: 'draft' | 'in_review' | 'approved';
  readonly problems: readonly { readonly severity: string; readonly field: string; readonly message: string }[];
  readonly createdAt: string;
}

export interface MessagingPlannerProps {
  readonly plans: readonly MessagingPlanSummary[];
}

export function MessagingPlanner({ plans }: MessagingPlannerProps) {
  const email = sendingStatus('email');
  const whatsapp = sendingStatus('whatsapp');

  return (
    <div className="space-y-6">
      <div className="grid gap-4 lg:grid-cols-2">
        <Alert tone="warning" title="SeSha cannot send email">
          <p>{email.message}</p>
          <p className="mt-2 text-xs">{email.whatWouldBeNeeded}</p>
        </Alert>
        <Alert tone="warning" title="SeSha cannot send WhatsApp messages">
          <p>{whatsapp.message}</p>
          <p className="mt-2 text-xs">{whatsapp.whatWouldBeNeeded}</p>
        </Alert>
      </div>

      <Card>
        <CardHeader>
          <CardTitle as="h2" className="text-base">Who you may message</CardTitle>
          <CardDescription>
            Every plan records this. Two of these answers mean SeSha will not plan the campaign at
            all.
          </CardDescription>
        </CardHeader>
        <ul className="divide-y divide-border border-t border-border text-sm">
          {(Object.keys(OPT_IN_LABEL) as OptInBasis[]).map((basis) => {
            const refused = basis === 'purchased_list' || basis === 'scraped' || basis === 'none';
            return (
              <li key={basis} className="flex flex-wrap items-start gap-3 px-5 py-3">
                <Badge tone={refused ? 'danger' : 'success'}>{refused ? 'Refused' : 'Allowed'}</Badge>
                <span className={refused ? 'text-fg-muted' : ''}>{OPT_IN_LABEL[basis]}</span>
              </li>
            );
          })}
        </ul>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle as="h2" className="text-base">Email</CardTitle>
            <CardDescription>
              Subject lines are cut at about {EMAIL_LIMITS.subjectCharacters} characters by most
              clients. A marketing email without an unsubscribe link cannot be marked ready.
            </CardDescription>
          </CardHeader>
          <ul className="divide-y divide-border border-t border-border text-sm">
            {EMAIL_KINDS.map((kind) => (
              <li key={kind} className="px-5 py-3">
                {EMAIL_KIND_LABEL[kind]}
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle as="h2" className="text-base">WhatsApp</CardTitle>
            <CardDescription>
              Written as official templates: body up to {WHATSAPP_LIMITS.bodyCharacters} characters,
              numbered placeholders, at most {WHATSAPP_LIMITS.maxButtons} buttons. The category is
              derived from the kind, not chosen.
            </CardDescription>
          </CardHeader>
          <ul className="divide-y divide-border border-t border-border text-sm">
            {WHATSAPP_KINDS.map((kind) => (
              <li key={kind} className="flex items-center justify-between px-5 py-3">
                <span>{WHATSAPP_KIND_LABEL[kind]}</span>
                <Badge tone={categoryFor(kind) === 'MARKETING' ? 'warning' : 'info'}>
                  {categoryFor(kind)}
                </Badge>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle as="h2" className="text-base">Your plans</CardTitle>
        </CardHeader>
        {plans.length === 0 ? (
          <p className="border-t border-border px-5 py-4 text-sm text-fg-muted">
            Nothing planned yet. Draft email and WhatsApp content in Content Studio, then save it here
            with the audience and the lawful basis recorded.
          </p>
        ) : (
          <ul className="divide-y divide-border border-t border-border">
            {plans.map((plan) => {
              const errors = plan.problems.filter((problem) => problem.severity === 'error');
              return (
                <li key={plan.id} className="px-5 py-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="font-medium">{plan.title || '(untitled)'}</p>
                      <p className="text-sm text-fg-muted">
                        {plan.channel === 'email' ? 'Email' : 'WhatsApp'} · {plan.kind}
                        {plan.category ? ` · ${plan.category}` : ''}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {errors.length > 0 ? <Badge tone="danger">{errors.length} error(s)</Badge> : null}
                      <Badge tone={plan.reviewState === 'approved' ? 'success' : 'neutral'}>
                        {plan.reviewState === 'approved' ? 'Ready to send yourself' : plan.reviewState}
                      </Badge>
                    </div>
                  </div>
                  <p className="mt-2 text-sm text-fg-muted">
                    <span className="font-medium">Audience: </span>
                    {plan.audienceNote || 'not described'} ·{' '}
                    {OPT_IN_LABEL[plan.optInBasis as OptInBasis] ?? plan.optInBasis}
                  </p>
                  {plan.problems.length > 0 ? (
                    <ul className="mt-2 ml-4 list-disc space-y-1 text-sm text-fg-muted">
                      {plan.problems.map((problem, index) => (
                        <li key={index}>
                          <span className="font-medium">{problem.field}: </span>
                          {problem.message}
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}
