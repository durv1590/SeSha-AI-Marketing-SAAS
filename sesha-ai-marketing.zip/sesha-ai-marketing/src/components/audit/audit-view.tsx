'use client';

import { useCallback, useState } from 'react';

import {
  FindingList,
  NotCheckedList,
  ScoreCard,
  SuppressedNotice,
  type NotCheckedItem,
} from '@/components/audit/finding-list';
import { AuditRunner, type JobKind } from '@/components/audit/audit-runner';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import type { Finding, Severity } from '@/lib/audit/finding';
import type { CrawlRow, ProjectRow } from '@/lib/db/types';

/**
 * The SEO and AEO audit screen.
 *
 * A tab per audit, and the crawl summary above both — because the first question
 * about any finding is "how much of my site did you actually read", and an audit
 * of 50 pages of a 500-page site means something different from a complete one.
 */

export interface StoredAudit {
  readonly id: string;
  readonly kind: 'seo' | 'aeo';
  readonly score: number;
  readonly scoreBasis: string;
  readonly findings: readonly Finding[];
  readonly stats: Readonly<Record<string, unknown>>;
  readonly notChecked: readonly NotCheckedItem[];
  readonly suppressed: readonly string[];
  readonly checkedAt: string;
}

export function AuditView({
  projects,
  crawl,
  seo,
  aeo,
  consentGranted,
  consentSite,
  canRequestCrawl,
  aeoDisclaimer,
}: {
  readonly projects: readonly ProjectRow[];
  readonly crawl: CrawlRow | null;
  readonly seo: StoredAudit | null;
  readonly aeo: StoredAudit | null;
  readonly consentGranted: boolean;
  readonly consentSite: string | null;
  readonly canRequestCrawl: boolean;
  readonly aeoDisclaimer: string;
}) {
  const [tab, setTab] = useState<'seo' | 'aeo'>('seo');

  // A finished job means the stored audit on screen is out of date.
  const reload = useCallback((kind: JobKind) => {
    void kind;
    if (typeof window !== 'undefined') window.location.reload();
  }, []);

  const current = tab === 'seo' ? seo : aeo;

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">SEO and AEO</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-fg-muted">
          SeSha reads your site with your permission and reports what it found, with the evidence
          for each finding. It reports no ranking, no traffic figure and no AI visibility score,
          because it cannot measure any of those.
        </p>
      </div>

      <AuditRunner
        projects={projects}
        consentGranted={consentGranted}
        consentSite={consentSite}
        hasCrawl={crawl !== null && crawl.pagesCrawled > 0}
        canRequestCrawl={canRequestCrawl}
        onFinished={reload}
      />

      {crawl ? <CrawlSummary crawl={crawl} /> : null}

      {crawl === null ? (
        <Card className="p-5">
          <p className="text-sm font-semibold">No crawl has run for this project yet</p>
          <p className="mt-1.5 text-sm leading-relaxed text-fg-muted">
            Start one above. Until then there is nothing to audit, and SeSha will not show a score
            or a finding it has not measured.
          </p>
        </Card>
      ) : (
        <>
          <div className="flex gap-1 border-b border-border" role="tablist" aria-label="Audit type">
            {(['seo', 'aeo'] as const).map((kind) => (
              <button
                key={kind}
                type="button"
                role="tab"
                aria-selected={tab === kind}
                onClick={() => setTab(kind)}
                className={`-mb-px border-b-2 px-4 py-2.5 text-sm font-medium transition-colors ${
                  tab === kind
                    ? 'border-primary text-fg'
                    : 'border-transparent text-fg-muted hover:text-fg'
                }`}
              >
                {kind === 'seo' ? 'Technical SEO' : 'Answer engines (AEO)'}
              </button>
            ))}
          </div>

          {tab === 'aeo' ? (
            <Alert tone="info" title="What this audit can and cannot tell you">
              {aeoDisclaimer}
            </Alert>
          ) : null}

          {current ? (
            <AuditBody audit={current} />
          ) : (
            <Card className="p-5">
              <p className="text-sm font-semibold">
                The {tab === 'seo' ? 'SEO' : 'AEO'} audit has not been run on this crawl
              </p>
              <p className="mt-1.5 text-sm leading-relaxed text-fg-muted">
                It reads the crawl already stored, so running it does not touch your site again.
              </p>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

function AuditBody({ audit }: { readonly audit: StoredAudit }) {
  const counts = countBySeverity(audit.findings);
  const categories = [...new Set(audit.findings.map((finding) => finding.category))];
  const [category, setCategory] = useState<string | null>(null);

  const shown = category
    ? audit.findings.filter((finding) => finding.category === category)
    : audit.findings;

  return (
    <div className="flex flex-col gap-5">
      <SuppressedNotice ids={audit.suppressed} />

      <ScoreCard
        score={audit.score}
        basis={audit.scoreBasis}
        counts={counts}
        title={audit.kind === 'seo' ? 'Technical SEO' : 'Answer engine readiness'}
      />

      <p className="text-xs text-fg-subtle">
        Checked {new Date(audit.checkedAt).toLocaleString('en-GB')}
      </p>

      <h2 className="text-lg font-semibold">
        {audit.findings.length === 0
          ? 'Findings'
          : `${audit.findings.length} finding${audit.findings.length === 1 ? '' : 's'}`}
      </h2>

      {categories.length > 1 ? (
        <div className="flex flex-wrap gap-1.5">
          <button
            type="button"
            onClick={() => setCategory(null)}
            aria-pressed={category === null}
            className="rounded-full border border-border px-3 py-1 text-xs font-medium aria-pressed:border-border-strong aria-pressed:bg-bg-muted"
          >
            All {audit.findings.length}
          </button>
          {categories.map((name) => (
            <button
              key={name}
              type="button"
              onClick={() => setCategory(name)}
              aria-pressed={category === name}
              className="rounded-full border border-border px-3 py-1 text-xs font-medium aria-pressed:border-border-strong aria-pressed:bg-bg-muted"
            >
              {name} {audit.findings.filter((finding) => finding.category === name).length}
            </button>
          ))}
        </div>
      ) : null}

      <FindingList findings={shown} />
      <NotCheckedList items={audit.notChecked} />
    </div>
  );
}

function countBySeverity(findings: readonly Finding[]): Record<Severity, number> {
  const counts: Record<Severity, number> = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
  for (const finding of findings) counts[finding.severity] += 1;
  return counts;
}

/**
 * What the crawl actually covered.
 *
 * Shown above the findings because it bounds everything below it: "50 of 500
 * pages" changes how a finding about "3 pages" should be read.
 */
function CrawlSummary({ crawl }: { readonly crawl: CrawlRow }) {
  return (
    <Card className="p-5">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <p className="text-sm font-semibold">What this crawl covered</p>
        <p className="text-xs text-fg-subtle">
          {new Date(crawl.startedAt).toLocaleString('en-GB')}
        </p>
      </div>

      <dl className="mt-3 grid grid-cols-2 gap-x-6 gap-y-3 sm:grid-cols-4">
        <Stat label="Pages read" value={String(crawl.pagesCrawled)} />
        <Stat label="Page limit" value={String(crawl.maxPages)} />
        <Stat label="Failed" value={String(crawl.pagesFailed)} />
        <Stat label="Depth" value={String(crawl.maxDepth)} />
      </dl>

      <div className="mt-4 flex flex-wrap gap-1.5">
        <Badge tone={crawl.respectRobots ? 'success' : 'warning'}>
          {crawl.respectRobots ? 'robots.txt respected' : 'robots.txt not consulted'}
        </Badge>
        <Badge tone={crawl.sitemapFound ? 'success' : 'outline'}>
          {crawl.sitemapFound ? 'sitemap used' : 'no sitemap'}
        </Badge>
        {crawl.cancelled ? <Badge tone="outline">cancelled partway</Badge> : null}
      </div>

      <p className="mt-3 text-xs leading-relaxed text-fg-subtle">{crawl.robotsSummary}</p>
      <p className="mt-1 text-xs leading-relaxed text-fg-subtle">{crawl.sitemapNote}</p>

      {crawl.stoppedEarly ? (
        <p className="mt-3 rounded-control bg-bg-muted p-3 text-xs leading-relaxed text-fg-muted">
          {crawl.stoppedEarly}
        </p>
      ) : null}

      <p className="mt-3 text-xs leading-relaxed text-fg-subtle">
        The page content from this crawl is deleted on{' '}
        {new Date(crawl.expiresAt).toLocaleDateString('en-GB')}, per the retention period you set
        when you authorised it.
      </p>
    </Card>
  );
}

function Stat({ label, value }: { readonly label: string; readonly value: string }) {
  return (
    <div>
      <dt className="text-xs text-fg-subtle">{label}</dt>
      <dd className="mt-0.5 text-lg font-semibold tabular-nums">{value}</dd>
    </div>
  );
}
