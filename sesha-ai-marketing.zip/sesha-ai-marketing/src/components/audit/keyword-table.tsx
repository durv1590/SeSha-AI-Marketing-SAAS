'use client';

import { useState } from 'react';

import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Field, Select } from '@/components/ui/field';
import {
  KEYWORD_KIND_LABELS,
  KEYWORD_SOURCE_LABELS,
  type KeywordKind,
  type KeywordSource,
} from '@/lib/keywords/types';

/**
 * The keyword table.
 *
 * The column that matters most is the one that says "Data unavailable". Every
 * competitor in this category prints a search-volume number; SeSha has no data
 * source for one, so it prints the absence instead, with the reason attached.
 *
 * What IS shown is real: relevance is measured against the crawled pages, and
 * `source` names the heading or title the query came from — so a user can see
 * the tool is reporting their own content back to them rather than inventing a
 * keyword list.
 */

export interface KeywordRowView {
  readonly id: string;
  readonly query: string;
  readonly kinds: readonly string[];
  readonly intent: string;
  readonly relevanceScore: number;
  readonly relevanceBasis: string;
  readonly coveringUrls: readonly string[];
  readonly volume: { readonly kind?: string; readonly label?: string; readonly why?: string };
  readonly competition: { readonly kind?: string; readonly label?: string };
  readonly priority: 'high' | 'medium' | 'low';
  readonly contentFormat: string;
  readonly entities: readonly string[];
  readonly source: string;
}

const PRIORITY_TONE = { high: 'danger', medium: 'warning', low: 'outline' } as const;

const FORMAT_LABELS: Record<string, string> = {
  'answer-section': 'Answer section',
  'faq-entry': 'FAQ entry',
  'how-to': 'How-to',
  comparison: 'Comparison',
  'landing-page': 'Landing page',
  'blog-post': 'Blog post',
  'product-page': 'Product page',
  'service-page': 'Service page',
  'location-page': 'Location page',
};

export function KeywordTable({
  keywords,
  dataNote,
  priorityBasis,
}: {
  readonly keywords: readonly KeywordRowView[];
  readonly dataNote: string;
  readonly priorityBasis: string;
}) {
  const [intent, setIntent] = useState<string>('');
  const [priority, setPriority] = useState<string>('');

  const shown = keywords.filter(
    (keyword) =>
      (intent === '' || keyword.intent === intent) &&
      (priority === '' || keyword.priority === priority),
  );

  if (keywords.length === 0) {
    return (
      <Card className="p-5">
        <p className="text-sm font-semibold">No keywords yet</p>
        <p className="mt-1.5 text-sm leading-relaxed text-fg-muted">
          Keywords are taken from your own page titles, headings and FAQ content when a crawl runs.
          SeSha does not generate a speculative list, so there is nothing here until it has read
          your site.
        </p>
      </Card>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Shown above the table, not below it: the absence of volume data is the
          first thing a reader needs to know, not a footnote they reach last. */}
      <div className="rounded-card border border-border bg-bg-muted p-4">
        <p className="text-sm leading-relaxed text-fg-muted">{dataNote}</p>
        <p className="mt-2 text-xs leading-relaxed text-fg-subtle">{priorityBasis}</p>
      </div>

      <div className="flex flex-wrap items-end gap-3">
        <Field id="kw-intent" label="Intent" className="min-w-40">
          {({ id }) => (
            <Select id={id} value={intent} onChange={(event) => setIntent(event.target.value)}>
              <option value="">All</option>
              {['informational', 'commercial', 'transactional', 'navigational'].map((value) => (
                <option key={value} value={value}>
                  {value}
                </option>
              ))}
            </Select>
          )}
        </Field>
        <Field id="kw-priority" label="Priority" className="min-w-40">
          {({ id }) => (
            <Select id={id} value={priority} onChange={(event) => setPriority(event.target.value)}>
              <option value="">All</option>
              {['high', 'medium', 'low'].map((value) => (
                <option key={value} value={value}>
                  {value}
                </option>
              ))}
            </Select>
          )}
        </Field>
        <p className="pb-2.5 text-xs text-fg-subtle">
          {shown.length} of {keywords.length}
        </p>
      </div>

      <Card className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[52rem] text-left text-sm">
            <caption className="sr-only">
              Queries found on your site, with how well your pages already cover each one. Search
              volume and competition are unavailable.
            </caption>
            <thead>
              <tr className="border-b border-border">
                <th scope="col" className="px-4 py-3 font-medium">Query</th>
                <th scope="col" className="px-4 py-3 font-medium">Intent</th>
                <th scope="col" className="px-4 py-3 font-medium">Your coverage</th>
                <th scope="col" className="px-4 py-3 font-medium">Volume</th>
                <th scope="col" className="px-4 py-3 font-medium">Competition</th>
                <th scope="col" className="px-4 py-3 font-medium">Priority</th>
                <th scope="col" className="px-4 py-3 font-medium">Format</th>
              </tr>
            </thead>
            <tbody>
              {shown.map((keyword) => (
                <tr key={keyword.id} className="border-b border-border last:border-0 align-top">
                  <td className="px-4 py-3">
                    <span className="block font-medium">{keyword.query}</span>
                    <span className="mt-1 block text-xs text-fg-subtle">
                      {KEYWORD_SOURCE_LABELS[keyword.source as KeywordSource] ?? keyword.source}
                    </span>
                    <span className="mt-1.5 flex flex-wrap gap-1">
                      {keyword.kinds.slice(0, 4).map((kind) => (
                        <Badge key={kind} tone="outline">
                          {KEYWORD_KIND_LABELS[kind as KeywordKind] ?? kind}
                        </Badge>
                      ))}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-fg-muted">{keyword.intent}</td>
                  <td className="px-4 py-3">
                    <span className="font-medium tabular-nums">{keyword.relevanceScore}</span>
                    <span className="text-fg-subtle">/100</span>
                    {keyword.coveringUrls.length > 0 ? (
                      <span className="mt-1 block truncate text-xs text-fg-subtle">
                        {keyword.coveringUrls[0]}
                      </span>
                    ) : (
                      <span className="mt-1 block text-xs text-fg-subtle">Not covered</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <Badge tone="neutral">{keyword.volume.label ?? 'Data unavailable'}</Badge>
                  </td>
                  <td className="px-4 py-3">
                    <Badge tone="neutral">{keyword.competition.label ?? 'Data unavailable'}</Badge>
                  </td>
                  <td className="px-4 py-3">
                    <Badge tone={PRIORITY_TONE[keyword.priority]}>{keyword.priority}</Badge>
                  </td>
                  <td className="px-4 py-3 text-fg-muted">
                    {FORMAT_LABELS[keyword.contentFormat] ?? keyword.contentFormat}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <details className="rounded-card border border-border bg-surface p-4">
        <summary className="cursor-pointer text-sm font-medium">
          How &ldquo;your coverage&rdquo; is measured
        </summary>
        <p className="mt-2 text-sm leading-relaxed text-fg-muted">
          {keywords[0]?.relevanceBasis ??
            'Measured against the text of the pages in the most recent crawl.'}
        </p>
        <p className="mt-2 text-sm leading-relaxed text-fg-muted">
          This is a measurement of your own site, not an estimate of anything external. A low score
          means your pages do not currently say much about that query &mdash; not that the query is
          unimportant, and not that it is searched for often.
        </p>
      </details>
    </div>
  );
}
