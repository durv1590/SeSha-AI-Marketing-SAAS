import { Badge } from '@/components/ui/badge';
import { Icon } from '@/components/ui/icon';
import {
  DATA_BASIS_LABELS,
  type Confidence,
  type DataBasis,
  type Finding,
  type Severity,
} from '@/lib/audit/finding';

/**
 * How an audit finding is shown.
 *
 * The brief requires every recommendation to carry issue, evidence, recommended
 * change, expected benefit, confidence and data basis. All six are rendered —
 * none is collapsed behind a toggle, because the point of stating the basis is
 * that the reader sees it at the same moment as the claim.
 *
 * `dataBasis` is shown as a plain-language label rather than a code, and a
 * `heuristic` finding says "a general rule, not a measurement of your site" —
 * which is the difference between advice and a finding about this website.
 */

const SEVERITY_TONE: Record<Severity, 'danger' | 'warning' | 'neutral' | 'outline' | 'info'> = {
  critical: 'danger',
  high: 'danger',
  medium: 'warning',
  low: 'neutral',
  info: 'info',
};

const SEVERITY_LABEL: Record<Severity, string> = {
  critical: 'Critical',
  high: 'High',
  medium: 'Medium',
  low: 'Low',
  info: 'For information',
};

const CONFIDENCE_LABEL: Record<Confidence, string> = {
  high: 'Measured directly',
  medium: 'Inferred from the crawl',
  low: 'A judgement to weigh yourself',
};

export function SeverityBadge({ severity }: { readonly severity: Severity }) {
  return <Badge tone={SEVERITY_TONE[severity]}>{SEVERITY_LABEL[severity]}</Badge>;
}

export function FindingCard({ finding }: { readonly finding: Finding }) {
  return (
    <article className="rounded-card border border-border bg-surface p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <h3 className="flex-1 text-base font-semibold leading-snug">{finding.issue}</h3>
        <span className="flex shrink-0 items-center gap-2">
          <SeverityBadge severity={finding.severity} />
          <Badge tone="outline">{finding.category}</Badge>
        </span>
      </div>

      <dl className="mt-4 flex flex-col gap-4">
        <div>
          <dt className="text-xs font-semibold uppercase tracking-wide text-fg-subtle">
            What we found
          </dt>
          <dd className="mt-1 text-sm leading-relaxed text-fg">{finding.evidence.observation}</dd>

          {finding.evidence.affectedCount !== undefined ? (
            <dd className="mt-1.5 text-xs text-fg-subtle">
              {finding.evidence.affectedCount}
              {finding.evidence.totalCount !== undefined
                ? ` of ${finding.evidence.totalCount}`
                : ''}{' '}
              affected
            </dd>
          ) : null}

          {finding.evidence.urls.length > 0 ? (
            <dd className="mt-2">
              <ul className="flex flex-col gap-1">
                {finding.evidence.urls.map((url) => (
                  <li key={url} className="truncate text-xs">
                    {/* Not a link: these are the user's own URLs, and an audit
                        that navigates away from itself is annoying. Shown as
                        text so they can be read and copied. */}
                    <code className="text-fg-muted">{url}</code>
                  </li>
                ))}
              </ul>
            </dd>
          ) : null}
        </div>

        <div>
          <dt className="text-xs font-semibold uppercase tracking-wide text-fg-subtle">
            What to change
          </dt>
          <dd className="mt-1 text-sm leading-relaxed text-fg">{finding.recommendation}</dd>
        </div>

        <div>
          <dt className="text-xs font-semibold uppercase tracking-wide text-fg-subtle">
            What that does
          </dt>
          <dd className="mt-1 text-sm leading-relaxed text-fg-muted">{finding.expectedBenefit}</dd>
        </div>
      </dl>

      <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1.5 border-t border-border pt-3 text-xs text-fg-subtle">
        <span className="flex items-center gap-1.5">
          <Icon name="info" size={13} />
          {DATA_BASIS_LABELS[finding.dataBasis]}
        </span>
        <span>Confidence: {CONFIDENCE_LABEL[finding.confidence]}</span>
      </div>
    </article>
  );
}

export function FindingList({ findings }: { readonly findings: readonly Finding[] }) {
  if (findings.length === 0) {
    return (
      <div className="rounded-card border border-border bg-surface p-5">
        <p className="text-sm font-semibold">Nothing was flagged in this area.</p>
        <p className="mt-1.5 text-sm leading-relaxed text-fg-muted">
          That means the checks SeSha runs found no problem &mdash; not that there is nothing left
          to improve. See what could not be checked, below.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      {findings.map((finding) => (
        <FindingCard key={finding.id} finding={finding} />
      ))}
    </div>
  );
}

/**
 * The score, shown with its basis attached.
 *
 * The basis is not a tooltip or a footnote: a number that looks like a
 * measurement is read as one, so the sentence saying it is our own weighting
 * sits directly beneath it.
 */
export function ScoreCard({
  score,
  basis,
  counts,
  title,
}: {
  readonly score: number;
  readonly basis: string;
  readonly counts: Readonly<Record<Severity, number>>;
  readonly title: string;
}) {
  return (
    <div className="rounded-card border border-border bg-surface p-5">
      <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
        <p className="text-sm font-semibold">{title}</p>
        <p className="text-3xl font-semibold tabular-nums">
          {score}
          <span className="text-base font-normal text-fg-subtle">/100</span>
        </p>
      </div>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {(['critical', 'high', 'medium', 'low', 'info'] as const)
          .filter((severity) => counts[severity] > 0)
          .map((severity) => (
            <Badge key={severity} tone={SEVERITY_TONE[severity]}>
              {counts[severity]} {SEVERITY_LABEL[severity].toLowerCase()}
            </Badge>
          ))}
      </div>

      <p className="mt-3 text-xs leading-relaxed text-fg-subtle">{basis}</p>
    </div>
  );
}

export interface NotCheckedItem {
  readonly area: string;
  readonly reason: string;
  readonly whatWouldHelp: string;
}

/**
 * What the audit could not assess.
 *
 * Shown as a peer of the findings rather than hidden at the bottom, because an
 * audit that silently omits an area reads as though the area is fine.
 */
export function NotCheckedList({ items }: { readonly items: readonly NotCheckedItem[] }) {
  if (items.length === 0) return null;

  return (
    <div className="rounded-card border border-border bg-bg-muted p-5">
      <h2 className="text-base font-semibold">What this audit could not check</h2>
      <p className="mt-1.5 text-sm leading-relaxed text-fg-muted">
        A crawl cannot measure everything. These areas are outside what SeSha can see, and their
        absence from the findings above does not mean they are fine.
      </p>
      <dl className="mt-4 flex flex-col gap-4">
        {items.map((item) => (
          <div key={item.area}>
            <dt className="text-sm font-medium">{item.area}</dt>
            <dd className="mt-1 text-sm leading-relaxed text-fg-muted">{item.reason}</dd>
            <dd className="mt-1 text-xs text-fg-subtle">
              <span className="font-medium">What would help:</span> {item.whatWouldHelp}
            </dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

/** Shown in development when the audit's own linter rejected a finding. */
export function SuppressedNotice({ ids }: { readonly ids: readonly string[] }) {
  if (ids.length === 0) return null;

  return (
    <div className="rounded-card border border-danger bg-danger-subtle p-4" role="alert">
      <p className="text-sm font-semibold">
        {ids.length} finding{ids.length === 1 ? '' : 's'} were withheld by the claims check
      </p>
      <p className="mt-1.5 text-sm leading-relaxed">
        A finding SeSha generated made a claim this product does not make &mdash; about AI
        ranking, citation, visibility or guaranteed traffic &mdash; so it was not shown. This is a
        bug in SeSha, not a problem with your site. Withheld: <code>{ids.join(', ')}</code>
      </p>
    </div>
  );
}

export { DATA_BASIS_LABELS, type DataBasis };
