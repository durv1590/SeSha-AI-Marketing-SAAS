'use client';

import { useCallback, useEffect, useRef, useState } from 'react';

import { readCsrfCookie } from '@/components/app/app-shell';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Field, Select } from '@/components/ui/field';
import type { ProjectRow } from '@/lib/db/types';

/**
 * The crawl and audit runner.
 *
 * A crawl takes minutes, so the interface queues a job and polls it. Three
 * decisions worth stating:
 *
 *  · POLLING STOPS on a terminal state. An interval that keeps running after the
 *    job finished is a battery drain and a pile of pointless requests.
 *  · CANCEL is always offered while a job is active, and the copy says what it
 *    does — a running crawl finishes its current page and keeps what it read,
 *    rather than discarding the work.
 *  · RETRY is offered only when the server says the failure is retryable. For a
 *    permanent failure the message explains why retrying would not help, rather
 *    than inviting the user to waste a minute finding out.
 */

export type JobKind = 'crawl' | 'seo_audit' | 'aeo_audit';

export interface JobView {
  readonly id: string;
  readonly kind: JobKind;
  readonly status: 'queued' | 'running' | 'completed' | 'failed' | 'cancelled';
  readonly progress: { readonly percent: number | null; readonly done: number; readonly total: number | null; readonly message: string };
  readonly cancelRequested: boolean;
  readonly attempts: number;
  readonly canRetry: boolean;
  readonly failure: string | null;
  readonly resultId: string | null;
}

const POLL_INTERVAL_MS = 2_000;

const STATUS_TONE: Record<JobView['status'], 'neutral' | 'info' | 'success' | 'danger' | 'outline'> = {
  queued: 'neutral',
  running: 'info',
  completed: 'success',
  failed: 'danger',
  cancelled: 'outline',
};

const KIND_LABEL: Record<JobKind, string> = {
  crawl: 'Crawl',
  seo_audit: 'SEO audit',
  aeo_audit: 'AEO audit',
};

function isTerminal(status: JobView['status']): boolean {
  return status === 'completed' || status === 'failed' || status === 'cancelled';
}

export function AuditRunner({
  projects,
  initialProjectId,
  consentGranted,
  consentSite,
  hasCrawl,
  canRequestCrawl,
  onFinished,
}: {
  readonly projects: readonly ProjectRow[];
  readonly initialProjectId?: string;
  readonly consentGranted: boolean;
  readonly consentSite: string | null;
  readonly hasCrawl: boolean;
  readonly canRequestCrawl: boolean;
  readonly onFinished?: (kind: JobKind) => void;
}) {
  const [projectId, setProjectId] = useState(initialProjectId ?? projects[0]?.id ?? '');
  const [job, setJob] = useState<JobView | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const stopPolling = useCallback(() => {
    if (timer.current) {
      clearTimeout(timer.current);
      timer.current = null;
    }
  }, []);

  const poll = useCallback(
    async (jobId: string) => {
      const response = await fetch(`/api/jobs/${jobId}`);
      const payload = (await response.json()) as { ok?: boolean; data?: JobView };
      if (payload.ok !== true || !payload.data) {
        stopPolling();
        return;
      }

      setJob(payload.data);

      if (isTerminal(payload.data.status)) {
        stopPolling();
        onFinished?.(payload.data.kind);
        return;
      }
      timer.current = setTimeout(() => void poll(jobId), POLL_INTERVAL_MS);
    },
    [onFinished, stopPolling],
  );

  // Clear the timer on unmount, so navigating away does not leave it running.
  useEffect(() => stopPolling, [stopPolling]);

  async function start(kind: JobKind) {
    setBusy(true);
    setError(null);
    setNotice(null);
    stopPolling();

    const url = kind === 'crawl' ? '/api/crawl' : '/api/audit';
    const body = kind === 'crawl'
      ? { projectId }
      : { projectId, kind: kind === 'seo_audit' ? 'seo' : 'aeo' };

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify(body),
    });
    const payload = (await response.json()) as { ok?: boolean; data?: JobView; message?: string };
    setBusy(false);

    if (payload.ok !== true || !payload.data) {
      setError(payload.message ?? 'That could not be started.');
      return;
    }

    setJob(payload.data);
    setNotice(payload.message ?? null);
    void poll(payload.data.id);
  }

  async function act(action: 'cancel' | 'retry') {
    if (!job) return;
    setBusy(true);
    setError(null);

    const response = await fetch(`/api/jobs/${job.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify({ action }),
    });
    const payload = (await response.json()) as { ok?: boolean; data?: JobView; message?: string };
    setBusy(false);

    if (payload.ok !== true || !payload.data) {
      setError(payload.message ?? 'That did not work.');
      return;
    }

    setJob(payload.data);
    setNotice(payload.message ?? null);
    if (!isTerminal(payload.data.status)) void poll(payload.data.id);
  }

  if (projects.length === 0) {
    return (
      <Alert tone="info" title="Create a project first">
        A crawl is authorised per project, against the website recorded for it.
        <span className="mt-3 block">
          <Button href="/app/projects" size="sm" variant="secondary">
            Go to projects
          </Button>
        </span>
      </Alert>
    );
  }

  const active = job !== null && !isTerminal(job.status);

  return (
    <Card className="flex flex-col gap-4 p-5">
      <div className="flex flex-wrap items-end gap-3">
        <Field id="audit-project" label="Project" className="min-w-56 flex-1">
          {({ id }) => (
            <Select
              id={id}
              value={projectId}
              disabled={active}
              onChange={(event) => {
                setProjectId(event.target.value);
                setJob(null);
                stopPolling();
              }}
            >
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.name}
                </option>
              ))}
            </Select>
          )}
        </Field>
      </div>

      {!consentGranted ? (
        <Alert tone="warning" title="Crawling is not authorised for this project">
          SeSha will not fetch a single page of your site without your explicit permission.
          Authorise it in the project&rsquo;s settings, where you can also set how many pages may be
          read and how long the data is kept.
          <span className="mt-3 block">
            <Button href="/app/settings" size="sm" variant="secondary">
              Review crawl permission
            </Button>
          </span>
        </Alert>
      ) : (
        <p className="text-sm leading-relaxed text-fg-muted">
          Authorised to crawl <code className="text-fg">{consentSite}</code>. SeSha identifies
          itself as <code className="text-fg">SeShaBot</code>, honours your robots.txt, and reads
          pages slowly enough to be less load than one visitor.
        </p>
      )}

      {error ? <Alert tone="danger" live>{error}</Alert> : null}
      {notice && !error ? <Alert tone="info" live>{notice}</Alert> : null}

      {job ? <JobStatus job={job} busy={busy} onAct={act} /> : null}

      <div className="flex flex-wrap gap-2">
        <Button
          onClick={() => void start('crawl')}
          disabled={busy || active || !consentGranted || !canRequestCrawl}
        >
          {hasCrawl ? 'Crawl again' : 'Start a crawl'}
        </Button>
        <Button
          variant="secondary"
          onClick={() => void start('seo_audit')}
          disabled={busy || active || !hasCrawl}
        >
          Run the SEO audit
        </Button>
        <Button
          variant="secondary"
          onClick={() => void start('aeo_audit')}
          disabled={busy || active || !hasCrawl}
        >
          Run the AEO audit
        </Button>
      </div>

      {!hasCrawl ? (
        <p className="text-xs leading-relaxed text-fg-subtle">
          The audits read the stored crawl rather than fetching your site again, so a crawl has to
          run first. After that you can re-run an audit as often as you like at no cost to your
          site.
        </p>
      ) : null}

      {!canRequestCrawl ? (
        <p className="text-xs leading-relaxed text-fg-subtle">
          Starting a crawl needs the manager role. You can still run the audits on the existing
          crawl.
        </p>
      ) : null}
    </Card>
  );
}

function JobStatus({
  job,
  busy,
  onAct,
}: {
  readonly job: JobView;
  readonly busy: boolean;
  readonly onAct: (action: 'cancel' | 'retry') => void;
}) {
  const active = !isTerminal(job.status);

  return (
    <div className="rounded-card border border-border bg-bg-muted p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="flex items-center gap-2">
          <span className="text-sm font-medium">{KIND_LABEL[job.kind]}</span>
          <Badge tone={STATUS_TONE[job.status]}>
            {job.cancelRequested && job.status === 'running' ? 'stopping' : job.status}
          </Badge>
          {job.attempts > 1 ? <Badge tone="outline">attempt {job.attempts}</Badge> : null}
        </span>

        <span className="flex items-center gap-2">
          {active ? (
            <Button size="sm" variant="secondary" onClick={() => onAct('cancel')} disabled={busy || job.cancelRequested}>
              {job.cancelRequested ? 'Stopping…' : 'Cancel'}
            </Button>
          ) : null}
          {job.status === 'failed' && job.canRetry ? (
            <Button size="sm" variant="secondary" onClick={() => onAct('retry')} disabled={busy}>
              Try again
            </Button>
          ) : null}
        </span>
      </div>

      {active ? (
        <div className="mt-3">
          {/* The bar shows a percentage only when the total is known; otherwise
              it is indeterminate rather than pretending to a figure. */}
          <div
            className="h-1.5 w-full overflow-hidden rounded-full bg-border"
            role="progressbar"
            aria-valuenow={job.progress.percent ?? undefined}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label={`${KIND_LABEL[job.kind]} progress`}
          >
            <div
              className="h-full rounded-full bg-primary transition-[width] duration-500"
              style={{ width: `${job.progress.percent ?? 8}%` }}
            />
          </div>
          <p className="mt-2 truncate text-xs text-fg-subtle" aria-live="polite">
            {job.progress.message || 'Starting…'}
            {job.progress.total !== null ? ` · ${job.progress.done} of ${job.progress.total}` : ''}
          </p>
        </div>
      ) : null}

      {job.status === 'failed' && job.failure ? (
        // Announced: a crawl that fails does so minutes after it was started,
        // long after the user has stopped watching this element.
        <p role="alert" className="mt-3 text-sm leading-relaxed text-danger">
          {job.failure}
        </p>
      ) : null}

      {job.status === 'failed' && !job.canRetry ? (
        <p className="mt-1.5 text-xs leading-relaxed text-fg-subtle">
          Retrying would not change this, so no retry is offered. Fix the cause and start again.
        </p>
      ) : null}

      {job.status === 'cancelled' ? (
        <p className="mt-3 text-sm leading-relaxed text-fg-muted">
          Stopped. Anything already read was kept, so a partial audit is still available.
        </p>
      ) : null}
    </div>
  );
}
