'use client';

import { useState } from 'react';

import { readCsrfCookie } from '@/components/app/app-shell';
import { ClaimWarnings } from '@/components/ai/provenance-view';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Field, Input, Select, Textarea } from '@/components/ui/field';
import { Icon } from '@/components/ui/icon';
import {
  PLATFORMS,
  PLATFORM_SPECS,
  POST_STATUSES,
  type Platform,
} from '@/lib/social/platforms';
import type { ClaimWarning } from '@/lib/ai/provenance';
import type { ProjectRow, SocialPostRow } from '@/lib/db/types';

/**
 * Social manager.
 *
 * The most important thing on this screen is the notice that nothing publishes.
 * It is not a footnote: every platform card states it, the status control has
 * no publish option, and the planner calls its dates "planned", not
 * "scheduled". A tool that looks like it posts for you, but does not, is worse
 * than one that never pretended.
 */

const STATUS_TONE: Record<string, 'outline' | 'neutral' | 'success'> = {
  idea: 'outline',
  draft: 'neutral',
  ready: 'success',
  archived: 'outline',
};

export function SocialManager({
  projects,
  posts,
  enabled,
  disabledReason,
}: {
  readonly projects: readonly ProjectRow[];
  readonly posts: readonly SocialPostRow[];
  readonly enabled: boolean;
  readonly disabledReason: string;
}) {
  const [projectId, setProjectId] = useState(projects[0]?.id ?? '');
  const [platform, setPlatform] = useState<Platform>('instagram');
  const [format, setFormat] = useState<string>(PLATFORM_SPECS.instagram.formats[0]!.id);
  const [idea, setIdea] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [drafts, setDrafts] = useState<
    { post: SocialPostRow | null; warnings: readonly ClaimWarning[]; issues: readonly { severity: string; message: string }[] }[]
  >([]);

  const spec = PLATFORM_SPECS[platform];

  async function generate(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setNotice(null);

    const response = await fetch('/api/social/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify({ projectId, platform, format, idea }),
    });
    const payload = (await response.json()) as Record<string, unknown>;
    setBusy(false);

    if (payload.ok !== true) {
      setNotice(typeof payload.message === 'string' ? payload.message : 'That did not work.');
      return;
    }

    const data = payload.data as Record<string, unknown>;
    setDrafts((current) => [
      {
        post: (data.post as SocialPostRow | null) ?? null,
        warnings: (data.warnings as ClaimWarning[]) ?? [],
        issues: (data.issues as { severity: string; message: string }[]) ?? [],
      },
      ...current,
    ]);
  }

  if (projects.length === 0) {
    return (
      <Alert tone="info" title="Create a project first">
        Social drafts are written from one project&rsquo;s brand voice and offering.
        <span className="mt-3 block">
          <Button href="/app/projects" size="sm" variant="secondary">
            Go to projects
          </Button>
        </span>
      </Alert>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Social</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-fg-muted">
          Draft posts for seven platforms, checked against each one&rsquo;s real character and
          hashtag limits.
        </p>
      </div>

      <Alert tone="info" title="SeSha does not publish to any platform">
        No official platform API is connected, so nothing here is posted, queued or scheduled. Posts
        reach a &ldquo;ready&rdquo; state, which means you can copy them and post them yourself.
        Connecting a real API is a later phase, and this notice will change when it happens.
      </Alert>

      {!enabled ? <Alert tone="warning" title="AI is not configured">{disabledReason}</Alert> : null}
      {notice ? <Alert tone="danger" live>{notice}</Alert> : null}

      <div className="grid gap-6 lg:grid-cols-[minmax(0,22rem)_minmax(0,1fr)]">
        <form className="flex flex-col gap-4" onSubmit={generate}>
          <Card className="flex flex-col gap-4 p-5">
            <Field id="social-project" label="Project">
              {({ id }) => (
                <Select id={id} value={projectId} onChange={(e) => setProjectId(e.target.value)}>
                  {projects.map((project) => (
                    <option key={project.id} value={project.id}>
                      {project.name}
                    </option>
                  ))}
                </Select>
              )}
            </Field>

            <Field id="social-platform" label="Platform" hint={spec.audienceNote}>
              {({ id, describedBy }) => (
                <Select
                  id={id}
                  aria-describedby={describedBy}
                  value={platform}
                  onChange={(e) => {
                    const next = e.target.value as Platform;
                    setPlatform(next);
                    setFormat(PLATFORM_SPECS[next].formats[0]!.id);
                  }}
                >
                  {PLATFORMS.map((value) => (
                    <option key={value} value={value}>
                      {PLATFORM_SPECS[value].label}
                    </option>
                  ))}
                </Select>
              )}
            </Field>

            <Field
              id="social-format"
              label="Format"
              hint={spec.formats.find((f) => f.id === format)?.notes}
            >
              {({ id, describedBy }) => (
                <Select
                  id={id}
                  aria-describedby={describedBy}
                  value={format}
                  onChange={(e) => setFormat(e.target.value)}
                >
                  {spec.formats.map((option) => (
                    <option key={option.id} value={option.id}>
                      {option.label}
                    </option>
                  ))}
                </Select>
              )}
            </Field>

            <Field id="social-idea" label="What is the post about?" required>
              {({ id }) => (
                <Textarea id={id} rows={3} value={idea} onChange={(e) => setIdea(e.target.value)} />
              )}
            </Field>

            <div className="rounded-card border border-border bg-bg-muted p-3.5 text-xs leading-relaxed text-fg-muted">
              <p className="font-medium text-fg">{spec.label} limits</p>
              <p className="mt-1">
                {spec.formats.find((f) => f.id === format)?.maxCharacters.toLocaleString()} characters,
                including hashtags.{' '}
                {spec.hashtags.supported
                  ? `About ${spec.hashtags.recommended} hashtags, never more than ${spec.hashtags.max}.`
                  : 'This platform does not use hashtags.'}
              </p>
              <p className="mt-2 text-fg-subtle">{spec.publishBlockedReason}</p>
            </div>

            <Button type="submit" block disabled={!enabled || busy || idea.trim().length < 3}>
              {busy ? 'Writing…' : 'Draft a post'}
            </Button>
          </Card>
        </form>

        <div className="flex flex-col gap-4">
          {drafts.map((draft, index) => (
            <Card key={draft.post?.id ?? index} className="p-5">
              <PostView post={draft.post} warnings={draft.warnings} issues={draft.issues} />
            </Card>
          ))}

          {drafts.length === 0 ? (
            <Card className="p-5">
              <p className="text-sm leading-relaxed text-fg-muted">
                Drafts appear here. Give each one a planned date to see it on the calendar — a
                planned date is a note to you, not a scheduled post.
              </p>
            </Card>
          ) : null}

          {posts.length > 0 ? (
            <Card className="p-5">
              <p className="text-sm font-semibold">Saved posts</p>
              <ul className="mt-3 flex flex-col divide-y divide-border">
                {posts.slice(0, 10).map((post) => (
                  <li key={post.id} className="flex items-start justify-between gap-3 py-3">
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm">{post.caption}</span>
                      <span className="mt-1 block text-xs text-fg-subtle">
                        {PLATFORM_SPECS[post.platform as Platform]?.label ?? post.platform}
                        {post.plannedFor ? ` · planned ${post.plannedFor}` : ''}
                      </span>
                    </span>
                    <Badge tone={STATUS_TONE[post.status] ?? 'outline'}>{post.status}</Badge>
                  </li>
                ))}
              </ul>
            </Card>
          ) : null}
        </div>
      </div>

      <PlatformTable />
    </div>
  );
}

function PostView({
  post,
  warnings,
  issues,
}: {
  readonly post: SocialPostRow | null;
  readonly warnings: readonly ClaimWarning[];
  readonly issues: readonly { severity: string; message: string }[];
}) {
  const [copied, setCopied] = useState(false);
  if (!post) return <p className="text-sm text-fg-muted">The draft was not saved.</p>;

  const full = [post.caption, post.hashtags.join(' ')].filter(Boolean).join('\n\n');
  const spec = PLATFORM_SPECS[post.platform as Platform];
  const format = spec?.formats.find((f) => f.id === post.format);
  const used = post.caption.length + (post.hashtags.length > 0 ? post.hashtags.join(' ').length + 1 : 0);

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="flex items-center gap-2">
          <Badge tone="neutral">{spec?.label ?? post.platform}</Badge>
          <Badge tone={STATUS_TONE[post.status] ?? 'outline'}>{post.status}</Badge>
        </span>
        <Button
          size="sm"
          variant="secondary"
          onClick={() => {
            void navigator.clipboard.writeText(full).then(
              () => setCopied(true),
              () => setCopied(false),
            );
          }}
        >
          <Icon name="copy" size={14} /> {copied ? 'Copied' : 'Copy'}
        </Button>
      </div>

      {warnings.length > 0 ? (
        <div className="mt-4">
          <ClaimWarnings warnings={warnings} />
        </div>
      ) : null}

      {issues.length > 0 ? (
        <ul className="mt-4 flex flex-col gap-1.5">
          {issues.map((issue, index) => (
            <li
              key={index}
              className={`text-sm ${issue.severity === 'error' ? 'text-danger' : 'text-fg-muted'}`}
            >
              {issue.message}
            </li>
          ))}
        </ul>
      ) : null}

      <p className="mt-4 whitespace-pre-wrap text-sm leading-relaxed">{post.caption}</p>

      {post.hashtags.length > 0 ? (
        <p className="mt-3 text-sm text-primary">{post.hashtags.join(' ')}</p>
      ) : null}

      <p className="mt-4 text-xs text-fg-subtle">
        {used.toLocaleString()} / {format?.maxCharacters.toLocaleString() ?? '—'} characters,
        hashtags included. This post is not published and will not be.
      </p>
    </>
  );
}

/** What each platform would need before publishing could ever work. */
function PlatformTable() {
  return (
    <Card className="p-5">
      <h2 className="text-base font-semibold">Why nothing publishes</h2>
      <p className="mt-2 text-sm leading-relaxed text-fg-muted">
        Publishing to any of these needs an approved application and an access token from the
        platform itself. None is connected, so SeSha drafts and you post.
      </p>
      <div className="mt-4 overflow-x-auto">
        <table className="w-full min-w-[36rem] text-left text-sm">
          <caption className="sr-only">Platform limits and what is connected</caption>
          <thead>
            <tr className="border-b border-border">
              <th scope="col" className="py-2 pr-4 font-medium">Platform</th>
              <th scope="col" className="py-2 pr-4 font-medium">Publishing</th>
              <th scope="col" className="py-2 font-medium">What it would require</th>
            </tr>
          </thead>
          <tbody>
            {PLATFORMS.map((id) => (
              <tr key={id} className="border-b border-border last:border-0">
                <td className="py-2.5 pr-4">{PLATFORM_SPECS[id].label}</td>
                <td className="py-2.5 pr-4">
                  <Badge tone="outline">Not connected</Badge>
                </td>
                <td className="py-2.5 text-fg-muted">{PLATFORM_SPECS[id].apiRequirement}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-4 text-xs text-fg-subtle">
        A post can be an {POST_STATUSES.join(', ')} — there is deliberately no published state.
      </p>
    </Card>
  );
}
