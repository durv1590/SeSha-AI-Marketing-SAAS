'use client';

import { useState } from 'react';

import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Field, Select } from '@/components/ui/field';
import { PLATFORM_SPECS, type Platform } from '@/lib/social/platforms';
import type { ProjectRow } from '@/lib/db/types';

/**
 * The planning calendar.
 *
 * It is a PLANNER, and the wording throughout says so. Nothing on this screen
 * triggers a publish, and the empty state says what the dates mean rather than
 * implying a queue that has not filled up yet.
 */

interface Entry {
  readonly date: string;
  readonly platform: string;
  readonly format: string;
  readonly caption: string;
  readonly status: string;
}

function monthRange(offset: number): { from: string; to: string; label: string } {
  const now = new Date();
  const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + offset, 1));
  const end = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + 1, 0));
  const iso = (date: Date) => date.toISOString().slice(0, 10);
  return {
    from: iso(start),
    to: iso(end),
    label: start.toLocaleDateString('en-GB', { month: 'long', year: 'numeric', timeZone: 'UTC' }),
  };
}

export function SocialCalendar({ projects }: { readonly projects: readonly ProjectRow[] }) {
  const [projectId, setProjectId] = useState(projects[0]?.id ?? '');
  const [offset, setOffset] = useState(0);
  const [entries, setEntries] = useState<Entry[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const range = monthRange(offset);

  async function load(id: string, monthOffset: number) {
    const target = monthRange(monthOffset);
    setBusy(true);
    setNotice(null);
    const response = await fetch(
      `/api/social/calendar?projectId=${encodeURIComponent(id)}&from=${target.from}&to=${target.to}`,
    );
    const payload = (await response.json()) as Record<string, unknown>;
    setBusy(false);

    if (payload.ok !== true) {
      setNotice(typeof payload.message === 'string' ? payload.message : 'Could not load the calendar.');
      return;
    }
    setEntries(((payload.data as Record<string, unknown>).entries as Entry[]) ?? []);
  }

  if (projects.length === 0) {
    return (
      <Alert tone="info" title="Create a project first">
        The calendar shows planned posts for one project.
        <span className="mt-3 block">
          <Button href="/app/projects" size="sm" variant="secondary">
            Go to projects
          </Button>
        </span>
      </Alert>
    );
  }

  const byDate = new Map<string, Entry[]>();
  for (const entry of entries ?? []) {
    const existing = byDate.get(entry.date);
    if (existing) existing.push(entry);
    else byDate.set(entry.date, [entry]);
  }
  const days = [...byDate.keys()].sort();

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Content calendar</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-fg-muted">
          A plan of what you intend to post and when. SeSha does not post any of it — these dates
          are notes to you, not a schedule the system acts on.
        </p>
      </div>

      {notice ? <Alert tone="danger" live>{notice}</Alert> : null}

      <div className="flex flex-wrap items-end gap-3">
        <Field id="cal-project" label="Project" className="min-w-56 flex-1">
          {({ id }) => (
            <Select
              id={id}
              value={projectId}
              onChange={(event) => {
                setProjectId(event.target.value);
                setEntries(null);
              }}
            >
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.name}
                </option>
              ))}
            </Select>
          )}
        </Field>

        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="secondary"
            onClick={() => {
              setOffset(offset - 1);
              void load(projectId, offset - 1);
            }}
            disabled={busy}
          >
            Previous
          </Button>
          <span className="min-w-36 text-center text-sm font-medium">{range.label}</span>
          <Button
            size="sm"
            variant="secondary"
            onClick={() => {
              setOffset(offset + 1);
              void load(projectId, offset + 1);
            }}
            disabled={busy}
          >
            Next
          </Button>
        </div>

        <Button variant="secondary" onClick={() => void load(projectId, offset)} disabled={busy}>
          {entries ? 'Refresh' : 'Load'}
        </Button>
      </div>

      {entries === null ? (
        <Card className="p-5">
          <p className="text-sm text-fg-muted">Choose a project and load a month to see planned posts.</p>
        </Card>
      ) : days.length === 0 ? (
        <Card className="p-5">
          <p className="text-sm font-semibold">Nothing planned for {range.label}</p>
          <p className="mt-2 text-sm leading-relaxed text-fg-muted">
            Draft a post in Social and give it a planned date to see it here.
          </p>
          <span className="mt-4 block">
            <Button href="/app/social" size="sm" variant="secondary">
              Go to Social
            </Button>
          </span>
        </Card>
      ) : (
        <div className="flex flex-col gap-3">
          {days.map((date) => (
            <Card key={date} className="p-5">
              <p className="text-sm font-semibold">
                {new Date(`${date}T00:00:00Z`).toLocaleDateString('en-GB', {
                  weekday: 'long',
                  day: 'numeric',
                  month: 'long',
                  timeZone: 'UTC',
                })}
              </p>
              <ul className="mt-3 flex flex-col divide-y divide-border">
                {(byDate.get(date) ?? []).map((entry, index) => (
                  <li key={index} className="flex items-start justify-between gap-3 py-2.5">
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm">{entry.caption}</span>
                      <span className="mt-1 block text-xs text-fg-subtle">
                        {PLATFORM_SPECS[entry.platform as Platform]?.label ?? entry.platform}
                      </span>
                    </span>
                    <Badge tone={entry.status === 'ready' ? 'success' : 'outline'}>{entry.status}</Badge>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
