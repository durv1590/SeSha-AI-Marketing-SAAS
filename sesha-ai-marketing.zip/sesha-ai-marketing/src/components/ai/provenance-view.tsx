import { Badge } from '@/components/ui/badge';
import { Icon } from '@/components/ui/icon';
import {
  PROVENANCE_DISPLAY,
  PROVENANCE_KINDS,
  isSourced,
  type ClaimWarning,
  type ProvenanceBlock,
  type ProvenanceKind,
} from '@/lib/ai/provenance';

/**
 * How an AI answer is shown.
 *
 * The brief's requirement is that every response distinguishes user-provided,
 * connected, retrieved, estimate, inference, recommendation and unavailable,
 * and never presents an assumption as a fact. That is enforced in the parser
 * and the linter; THIS is where the user can actually see it.
 *
 * Two decisions worth stating:
 *  · Sourced blocks are NOT badged. Labelling everything trains people to
 *    ignore the labels, and the thing that needs marking is the unsourced half.
 *  · Unavailable blocks are styled as information, not as an error. "We do not
 *    have your conversion data" is the system working correctly.
 */

const TONE: Record<ProvenanceKind, 'neutral' | 'brand' | 'info' | 'warning' | 'outline'> = {
  user_provided: 'neutral',
  connected: 'neutral',
  retrieved: 'neutral',
  ai_estimate: 'warning',
  ai_inference: 'warning',
  recommendation: 'brand',
  unavailable: 'info',
};

export function ProvenanceBadge({ kind }: { readonly kind: ProvenanceKind }) {
  const display = PROVENANCE_DISPLAY[kind];
  return (
    <Badge tone={TONE[kind]} title={display.description}>
      {display.label}
    </Badge>
  );
}

export function ProvenanceBlocks({
  blocks,
  className,
}: {
  readonly blocks: readonly ProvenanceBlock[];
  readonly className?: string;
}) {
  return (
    <div className={className}>
      {blocks.map((block, index) => (
        <div
          key={`${block.kind}-${index}`}
          className={
            isSourced(block.kind)
              ? 'mt-4 first:mt-0'
              : 'mt-4 border-l-2 border-border-strong pl-4 first:mt-0'
          }
        >
          {isSourced(block.kind) ? null : (
            <div className="mb-1.5 flex items-center gap-2">
              <ProvenanceBadge kind={block.kind} />
              {block.source ? (
                <span className="text-xs text-fg-subtle">
                  {block.source.type}
                  {block.source.label ? `: ${block.source.label}` : ''}
                </span>
              ) : null}
            </div>
          )}
          <p className="whitespace-pre-wrap text-sm leading-relaxed text-fg">{block.text}</p>
        </div>
      ))}
    </div>
  );
}

/**
 * Claim-linter output.
 *
 * An ERROR is shown before the answer, not after, because the point is that
 * the reader sees the caveat before they read the number.
 */
export function ClaimWarnings({ warnings }: { readonly warnings: readonly ClaimWarning[] }) {
  if (warnings.length === 0) return null;

  const errors = warnings.filter((warning) => warning.severity === 'error');
  const cautions = warnings.filter((warning) => warning.severity === 'warning');

  return (
    <div
      className={`rounded-card border p-3.5 ${
        errors.length > 0 ? 'border-danger bg-danger-subtle' : 'border-border bg-bg-muted'
      }`}
      role={errors.length > 0 ? 'alert' : undefined}
    >
      <p className="flex items-center gap-2 text-sm font-semibold">
        <Icon name={errors.length > 0 ? 'alert' : 'info'} size={16} />
        {errors.length > 0
          ? 'Check these claims before using this'
          : 'Some statements here are estimates'}
      </p>
      <ul className="mt-2.5 flex flex-col gap-2">
        {[...errors, ...cautions].map((warning, index) => (
          <li key={`${warning.blockIndex}-${index}`} className="text-sm leading-relaxed text-fg-muted">
            <span className="font-medium text-fg">{warning.message}</span>{' '}
            <span className="text-fg-subtle">“{warning.excerpt}”</span>
          </li>
        ))}
      </ul>
      <p className="mt-3 text-xs leading-relaxed text-fg-subtle">
        SeSha flags figures that did not come from your own data or a connected source. It cannot
        confirm whether they are true — verify anything you plan to publish.
      </p>
    </div>
  );
}

/** The legend, shown once per surface rather than beside every answer. */
export function ProvenanceLegend() {
  return (
    <details className="rounded-card border border-border bg-surface p-3.5">
      <summary className="cursor-pointer text-sm font-medium">What the labels mean</summary>
      <dl className="mt-3 flex flex-col gap-2.5">
        {PROVENANCE_KINDS.map((kind) => (
          <div key={kind} className="flex flex-col gap-1 sm:flex-row sm:items-baseline sm:gap-3">
            <dt className="shrink-0">
              <ProvenanceBadge kind={kind} />
            </dt>
            <dd className="text-sm leading-relaxed text-fg-muted">
              {PROVENANCE_DISPLAY[kind].description}
            </dd>
          </div>
        ))}
      </dl>
      <p className="mt-3 text-xs leading-relaxed text-fg-subtle">
        Only the first three are statements of fact. Everything else is the model reasoning, and is
        marked so you can tell the difference.
      </p>
    </details>
  );
}
