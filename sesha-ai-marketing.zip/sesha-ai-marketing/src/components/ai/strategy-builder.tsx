'use client';

import { useState } from 'react';

import { readCsrfCookie } from '@/components/app/app-shell';
import { ClaimWarnings, ProvenanceBlocks } from '@/components/ai/provenance-view';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Field, Select } from '@/components/ui/field';
import type { ClaimWarning, ProvenanceBlock } from '@/lib/ai/provenance';
import type { ProjectRow } from '@/lib/db/types';

/**
 * The marketing strategy builder.
 *
 * The plan is shown BEFORE anything is generated. A user seeing "Website &
 * Landing Page Strategy — limited until a site crawl runs" up front understands
 * why that section is thinner; the same section appearing confidently alongside
 * the others would read as complete when it is not.
 */

interface PlannedSection {
  readonly id: string;
  readonly label: string;
  readonly availability: 'full' | 'partial' | 'unavailable';
  readonly missing: readonly string[];
  readonly note: string | null;
}

interface StoredSection extends PlannedSection {
  readonly blocks: readonly ProvenanceBlock[] | null;
  readonly text: string | null;
  readonly warnings: readonly ClaimWarning[];
  readonly error: string | null;
}

const AVAILABILITY: Record<PlannedSection['availability'], { label: string; tone: 'success' | 'warning' | 'outline' }> = {
  full: { label: 'Ready', tone: 'success' },
  partial: { label: 'Limited', tone: 'warning' },
  unavailable: { label: 'Not available', tone: 'outline' },
};

export function StrategyBuilder({
  projects,
  enabled,
  disabledReason,
  canApprove,
}: {
  readonly projects: readonly ProjectRow[];
  readonly enabled: boolean;
  readonly disabledReason: string;
  readonly canApprove: boolean;
}) {
  const [projectId, setProjectId] = useState(projects[0]?.id ?? '');
  const [plan, setPlan] = useState<PlannedSection[] | null>(null);
  const [sections, setSections] = useState<StoredSection[] | null>(null);
  const [strategyId, setStrategyId] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  async function loadPlan(id: string) {
    setBusy(true);
    setNotice(null);
    const response = await fetch(
      `/api/strategy?projectId=${encodeURIComponent(id)}&plan=1`,
    );
    const payload = (await response.json()) as Record<string, unknown>;
    setBusy(false);
    if (payload.ok === true) setPlan(payload.data as PlannedSection[]);
    else setNotice(typeof payload.message === 'string' ? payload.message : 'Could not load the plan.');
  }

  async function generate() {
    setBusy(true);
    setNotice(null);
    setSections(null);

    const response = await fetch('/api/strategy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify({ projectId }),
    });
    const payload = (await response.json()) as Record<string, unknown>;
    setBusy(false);

    if (payload.ok !== true) {
      setNotice(typeof payload.message === 'string' ? payload.message : 'That did not work.');
      return;
    }

    const data = payload.data as Record<string, unknown>;
    const strategy = data.strategy as { id: string; status: string } | null;
    setSections(data.sections as StoredSection[]);
    setStrategyId(strategy?.id ?? null);
    setStatus(strategy?.status ?? null);
  }

  async function approve() {
    if (!strategyId) return;
    setBusy(true);
    const response = await fetch(`/api/strategy/${strategyId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify({ status: 'approved' }),
    });
    const payload = (await response.json()) as Record<string, unknown>;
    setBusy(false);

    if (payload.ok !== true) {
      // A 409 means the linter blocked it. The message says which claim.
      setNotice(typeof payload.message === 'string' ? payload.message : 'Could not approve.');
      return;
    }
    setStatus('approved');
    setNotice('Approved.');
  }

  if (projects.length === 0) {
    return (
      <Alert tone="info" title="Create a project first">
        A strategy is built from one project&rsquo;s business details and marketing profile.
        <span className="mt-3 block">
          <Button href="/app/projects" size="sm" variant="secondary">
            Go to projects
          </Button>
        </span>
      </Alert>
    );
  }

  const generatable = plan?.filter((section) => section.availability !== 'unavailable').length ?? 0;

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Marketing strategy</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-fg-muted">
          Seventeen sections, built from what this project actually contains. Sections that need
          information you have not provided are left out rather than filled in with plausible
          guesses.
        </p>
      </div>

      {!enabled ? <Alert tone="warning" title="AI is not configured">{disabledReason}</Alert> : null}
      {notice ? <Alert tone={notice === 'Approved.' ? 'success' : 'danger'} live>{notice}</Alert> : null}

      <div className="flex flex-wrap items-end gap-3">
        <Field id="strategy-project" label="Project" className="min-w-56 flex-1">
          {({ id }) => (
            <Select
              id={id}
              value={projectId}
              onChange={(event) => {
                setProjectId(event.target.value);
                setPlan(null);
                setSections(null);
                setStrategyId(null);
              }}
            >
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.name}
                </option>
              ))}
            </Select>
          )}
        </Field>
        <Button variant="secondary" onClick={() => void loadPlan(projectId)} disabled={busy}>
          {plan ? 'Refresh plan' : 'Check what can be built'}
        </Button>
      </div>

      {plan ? (
        <Card className="p-5">
          <p className="text-sm font-semibold">
            {generatable} of {plan.length} sections can be written now
          </p>
          <ul className="mt-4 flex flex-col divide-y divide-border">
            {plan.map((section) => (
              <li key={section.id} className="flex flex-col gap-1 py-3 sm:flex-row sm:items-baseline sm:gap-4">
                <span className="flex-1 text-sm font-medium">{section.label}</span>
                <span className="flex shrink-0 items-center gap-2">
                  <Badge tone={AVAILABILITY[section.availability].tone}>
                    {AVAILABILITY[section.availability].label}
                  </Badge>
                </span>
                {section.note ? (
                  <span className="w-full text-xs leading-relaxed text-fg-subtle sm:w-72">
                    {section.note}
                  </span>
                ) : null}
              </li>
            ))}
          </ul>

          <div className="mt-5 flex flex-wrap items-center gap-3">
            <Button onClick={() => void generate()} disabled={!enabled || busy || generatable === 0}>
              {busy ? 'Building…' : `Build ${generatable} sections`}
            </Button>
            <p className="text-xs text-fg-subtle">
              This runs one generation per section, so it takes a moment and counts against your
              monthly usage.
            </p>
          </div>
        </Card>
      ) : null}

      {sections ? (
        <div className="flex flex-col gap-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-lg font-semibold">Your strategy</h2>
            <span className="flex items-center gap-2">
              {status ? (
                <Badge tone={status === 'approved' ? 'success' : status === 'in_review' ? 'warning' : 'outline'}>
                  {status === 'in_review' ? 'Needs review' : status}
                </Badge>
              ) : null}
              {canApprove && status !== 'approved' ? (
                <Button size="sm" variant="secondary" onClick={() => void approve()} disabled={busy}>
                  Approve
                </Button>
              ) : null}
            </span>
          </div>

          {sections.map((section) => (
            <Card key={section.id} className="p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-base font-semibold">{section.label}</h3>
                <Badge tone={AVAILABILITY[section.availability].tone}>
                  {AVAILABILITY[section.availability].label}
                </Badge>
              </div>

              {section.note ? (
                <p className="mt-2 text-sm leading-relaxed text-fg-subtle">{section.note}</p>
              ) : null}

              {section.error ? (
                // role="alert" because this appears AFTER the user asked for
                // a section and the request failed. Without it a screen-reader
                // user is left waiting for a result that silently became an
                // error they were never told about.
                <p role="alert" className="mt-3 text-sm text-danger">
                  {section.error}
                </p>
              ) : null}

              {section.warnings.length > 0 ? (
                <div className="mt-4">
                  <ClaimWarnings warnings={section.warnings} />
                </div>
              ) : null}

              {section.blocks ? (
                <div className="mt-4">
                  <ProvenanceBlocks blocks={section.blocks} />
                </div>
              ) : (
                <p className="mt-3 text-sm leading-relaxed text-fg-muted">
                  Not written. {section.missing.length > 0
                    ? `This section needs ${section.missing.join(', ')}.`
                    : 'Nothing was generated for this section.'}
                </p>
              )}
            </Card>
          ))}
        </div>
      ) : null}
    </div>
  );
}
