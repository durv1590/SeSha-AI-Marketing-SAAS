'use client';

import { useState } from 'react';

import { readCsrfCookie } from '@/components/app/app-shell';
import { ClaimWarnings, ProvenanceBlocks, ProvenanceLegend } from '@/components/ai/provenance-view';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Checkbox, Field, Input, Select, Textarea } from '@/components/ui/field';
import { Icon } from '@/components/ui/icon';
import {
  ANSWER_INTENTS,
  CONTENT_FORMATS,
  FORMAT_SPECS,
  LANGUAGES,
  LANGUAGE_SPECS,
  LENGTH_PRESETS,
  SEARCH_INTENTS,
  TONES,
  targetWordCount,
  type ContentFormat,
  type Language,
  type LengthPreset,
} from '@/lib/content/types';
import type { ClaimWarning, ProvenanceBlock } from '@/lib/ai/provenance';
import type { ContentItemRow, ProjectRow } from '@/lib/db/types';

/**
 * Content Studio.
 *
 * The controls map one-to-one onto `ContentControls`, and the server validates
 * every one of them again — an unknown tone is rejected there, not quietly
 * replaced. The word target shown beside the length control is computed from
 * the same function the prompt uses, so the number on screen is the number the
 * model is asked for.
 */

interface Draft {
  readonly item: ContentItemRow | null;
  readonly blocks: readonly ProvenanceBlock[];
  readonly text: string;
  readonly warnings: readonly ClaimWarning[];
  readonly issues: readonly { readonly severity: string; readonly message: string }[];
}

export function ContentStudio({
  projects,
  recent,
  enabled,
  disabledReason,
}: {
  readonly projects: readonly ProjectRow[];
  readonly recent: readonly ContentItemRow[];
  readonly enabled: boolean;
  readonly disabledReason: string;
}) {
  const [projectId, setProjectId] = useState(projects[0]?.id ?? '');
  const [format, setFormat] = useState<ContentFormat>('blog');
  const [topic, setTopic] = useState('');
  const [language, setLanguage] = useState<Language>('en');
  const [tone, setTone] = useState<string>(TONES[0]);
  const [audience, setAudience] = useState('');
  const [length, setLength] = useState<LengthPreset>('standard');
  const [creativity, setCreativity] = useState(50);
  const [useBrandVoice, setUseBrandVoice] = useState(true);
  const [callToAction, setCallToAction] = useState('');
  const [searchIntent, setSearchIntent] = useState('');
  const [answerIntent, setAnswerIntent] = useState('');

  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [notice, setNotice] = useState<string | null>(null);

  const spec = FORMAT_SPECS[format];

  async function generate(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setErrors({});
    setNotice(null);

    const response = await fetch('/api/content/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify({
        projectId,
        format,
        topic,
        language,
        tone,
        audience,
        length,
        creativity,
        useBrandVoice,
        callToAction,
        searchIntent: searchIntent || null,
        answerIntent: answerIntent || null,
      }),
    });
    const payload = (await response.json()) as Record<string, unknown>;
    setBusy(false);

    if (payload.ok !== true) {
      setErrors((payload.errors as Record<string, string>) ?? {});
      setNotice(typeof payload.message === 'string' ? payload.message : 'That did not work.');
      return;
    }

    const data = payload.data as Record<string, unknown>;
    setDraft({
      item: (data.item as ContentItemRow | null) ?? null,
      blocks: data.blocks as ProvenanceBlock[],
      text: data.text as string,
      warnings: data.warnings as ClaimWarning[],
      issues: (data.issues as Draft['issues']) ?? [],
    });
  }

  if (projects.length === 0) {
    return (
      <Alert tone="info" title="Create a project first">
        Content Studio writes using one project&rsquo;s brand voice, audience and offering.
        <span className="mt-3 block">
          <Button href="/app/projects" size="sm" variant="secondary">
            Go to projects
          </Button>
        </span>
      </Alert>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Content Studio</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-fg-muted">
          Twenty formats, in English, Hindi or Hinglish. Everything produced here starts as a draft
          and is checked for claims that did not come from your own data.
        </p>
      </div>

      {!enabled ? <Alert tone="warning" title="AI is not configured">{disabledReason}</Alert> : null}
      {notice ? <Alert tone="danger" live>{notice}</Alert> : null}

      <div className="grid gap-6 lg:grid-cols-[minmax(0,22rem)_minmax(0,1fr)]">
        <form className="flex flex-col gap-4" onSubmit={generate}>
          <Card className="flex flex-col gap-4 p-5">
            <Field id="cs-project" label="Project">
              {({ id }) => (
                <Select id={id} value={projectId} onChange={(e) => setProjectId(e.target.value)}>
                  {projects.map((project) => (
                    <option key={project.id} value={project.id}>
                      {project.name}
                    </option>
                  ))}
                </Select>
              )}
            </Field>

            <Field id="cs-format" label="Format" hint={spec.structure}>
              {({ id, describedBy }) => (
                <Select
                  id={id}
                  aria-describedby={describedBy}
                  value={format}
                  onChange={(e) => setFormat(e.target.value as ContentFormat)}
                >
                  {CONTENT_FORMATS.map((value) => (
                    <option key={value} value={value}>
                      {FORMAT_SPECS[value].label}
                    </option>
                  ))}
                </Select>
              )}
            </Field>

            <Field
              id="cs-topic"
              label="Topic"
              required
              error={errors.topic}
              hint="What should this be about? Be specific."
            >
              {({ id, describedBy, invalid }) => (
                <Textarea
                  id={id}
                  rows={3}
                  aria-describedby={describedBy}
                  aria-invalid={invalid}
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                />
              )}
            </Field>

            <Field id="cs-language" label="Language" hint={LANGUAGE_SPECS[language].note}>
              {({ id, describedBy }) => (
                <Select
                  id={id}
                  aria-describedby={describedBy}
                  value={language}
                  onChange={(e) => setLanguage(e.target.value as Language)}
                >
                  {LANGUAGES.map((code) => (
                    <option key={code} value={code}>
                      {LANGUAGE_SPECS[code].label}
                    </option>
                  ))}
                </Select>
              )}
            </Field>

            <Field id="cs-tone" label="Tone" error={errors.tone}>
              {({ id }) => (
                <Select id={id} value={tone} onChange={(e) => setTone(e.target.value)}>
                  {TONES.map((value) => (
                    <option key={value} value={value}>
                      {value}
                    </option>
                  ))}
                </Select>
              )}
            </Field>

            <Field id="cs-audience" label="Audience" hint="Leave blank to use the project's audience.">
              {({ id, describedBy }) => (
                <Input
                  id={id}
                  aria-describedby={describedBy}
                  value={audience}
                  onChange={(e) => setAudience(e.target.value)}
                />
              )}
            </Field>

            <Field
              id="cs-length"
              label="Length"
              hint={`About ${targetWordCount(format, length)} words`}
            >
              {({ id, describedBy }) => (
                <Select
                  id={id}
                  aria-describedby={describedBy}
                  value={length}
                  onChange={(e) => setLength(e.target.value as LengthPreset)}
                >
                  {LENGTH_PRESETS.map((value) => (
                    <option key={value} value={value}>
                      {value}
                    </option>
                  ))}
                </Select>
              )}
            </Field>

            <Field
              id="cs-creativity"
              label={`Creativity: ${creativity}`}
              hint="Higher is more varied. Above about 70, check facts more carefully."
            >
              {({ id, describedBy }) => (
                <input
                  id={id}
                  aria-describedby={describedBy}
                  type="range"
                  min={0}
                  max={100}
                  step={5}
                  value={creativity}
                  className="w-full accent-[var(--color-primary)]"
                  onChange={(e) => setCreativity(Number(e.target.value))}
                />
              )}
            </Field>

            <Field id="cs-cta" label="Call to action" hint="Optional. Left blank, none is invented.">
              {({ id, describedBy }) => (
                <Input
                  id={id}
                  aria-describedby={describedBy}
                  value={callToAction}
                  onChange={(e) => setCallToAction(e.target.value)}
                />
              )}
            </Field>

            <Field id="cs-search-intent" label="Search intent">
              {({ id }) => (
                <Select id={id} value={searchIntent} onChange={(e) => setSearchIntent(e.target.value)}>
                  <option value="">Not specified</option>
                  {SEARCH_INTENTS.map((value) => (
                    <option key={value} value={value}>
                      {value}
                    </option>
                  ))}
                </Select>
              )}
            </Field>

            <Field id="cs-answer-intent" label="Answer intent" hint="Shapes the content for AI answer engines.">
              {({ id, describedBy }) => (
                <Select
                  id={id}
                  aria-describedby={describedBy}
                  value={answerIntent}
                  onChange={(e) => setAnswerIntent(e.target.value)}
                >
                  <option value="">Not specified</option>
                  {ANSWER_INTENTS.map((value) => (
                    <option key={value} value={value}>
                      {value}
                    </option>
                  ))}
                </Select>
              )}
            </Field>

            <Checkbox
              id="cs-brand-voice"
              label="Follow the project's brand voice"
              checked={useBrandVoice}
              onChange={(e) => setUseBrandVoice(e.target.checked)}
            />

            <Button type="submit" block disabled={!enabled || busy || topic.trim().length < 3}>
              {busy ? 'Writing…' : 'Generate'}
            </Button>
          </Card>
        </form>

        <div className="flex flex-col gap-5">
          {busy ? (
            <Card className="p-5">
              <p className="text-sm text-fg-subtle" aria-live="polite">
                Writing your {spec.label.toLowerCase()}&hellip;
              </p>
            </Card>
          ) : null}

          {draft ? <DraftView draft={draft} /> : null}

          {!draft && !busy ? (
            <Card className="p-5">
              <p className="text-sm leading-relaxed text-fg-muted">
                Your draft will appear here. Nothing is published from this screen — Content Studio
                produces text for you to review, edit and use wherever you publish.
              </p>
            </Card>
          ) : null}

          {recent.length > 0 ? (
            <Card className="p-5">
              <p className="text-sm font-semibold">Recent drafts</p>
              <ul className="mt-3 flex flex-col divide-y divide-border">
                {recent.slice(0, 8).map((item) => (
                  <li key={item.id} className="flex items-center justify-between gap-3 py-2.5">
                    <span className="min-w-0 flex-1 truncate text-sm">{item.title}</span>
                    <span className="flex shrink-0 items-center gap-2">
                      <Badge tone="neutral">{FORMAT_SPECS[item.format as ContentFormat]?.label ?? item.format}</Badge>
                      <Badge tone={item.status === 'in_review' ? 'warning' : 'outline'}>
                        {item.status.replace('_', ' ')}
                      </Badge>
                    </span>
                  </li>
                ))}
              </ul>
            </Card>
          ) : null}

          <ProvenanceLegend />
        </div>
      </div>
    </div>
  );
}

function DraftView({ draft }: { readonly draft: Draft }) {
  const [copied, setCopied] = useState(false);
  const errors = draft.issues.filter((issue) => issue.severity === 'error');
  const cautions = draft.issues.filter((issue) => issue.severity !== 'error');

  return (
    <Card className="p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm font-semibold">{draft.item ? draft.item.title : 'Draft'}</p>
        <span className="flex items-center gap-2">
          {draft.item ? (
            <Badge tone={draft.item.status === 'in_review' ? 'warning' : 'outline'}>
              {draft.item.status === 'in_review' ? 'Needs review' : 'Draft'}
            </Badge>
          ) : null}
          <Button
            size="sm"
            variant="secondary"
            onClick={() => {
              void navigator.clipboard.writeText(draft.text).then(
                () => setCopied(true),
                () => setCopied(false),
              );
            }}
          >
            <Icon name="copy" size={14} /> {copied ? 'Copied' : 'Copy'}
          </Button>
        </span>
      </div>

      {draft.warnings.length > 0 ? (
        <div className="mt-4">
          <ClaimWarnings warnings={draft.warnings} />
        </div>
      ) : null}

      {errors.length > 0 || cautions.length > 0 ? (
        <ul className="mt-4 flex flex-col gap-1.5">
          {[...errors, ...cautions].map((issue, index) => (
            <li
              key={index}
              className={`text-sm ${issue.severity === 'error' ? 'text-danger' : 'text-fg-muted'}`}
            >
              {issue.message}
            </li>
          ))}
        </ul>
      ) : null}

      <div className="mt-5">
        <ProvenanceBlocks blocks={draft.blocks} />
      </div>
    </Card>
  );
}
