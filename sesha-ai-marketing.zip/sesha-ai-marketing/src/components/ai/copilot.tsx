'use client';

import { useEffect, useRef, useState } from 'react';

import { readCsrfCookie } from '@/components/app/app-shell';
import { ClaimWarnings, ProvenanceBlocks, ProvenanceLegend } from '@/components/ai/provenance-view';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Field, Select, Textarea } from '@/components/ui/field';
import { Icon } from '@/components/ui/icon';
import { LANGUAGE_SPECS, LANGUAGES, TONES } from '@/lib/content/types';
import type { ClaimWarning, ProvenanceBlock } from '@/lib/ai/provenance';
import type { ContextSummary } from '@/lib/ai/context';
import type { ProjectRow } from '@/lib/db/types';

/**
 * The SeSha AI Copilot.
 *
 * Everything the brief asks for is here — copy, save, regenerate, shorten,
 * expand, translate, change tone, export — but note what is NOT here: a plain
 * text bubble. Each answer renders as provenance blocks, and every refinement
 * round-trips through the server so the rewritten text is linted again rather
 * than being edited client-side and trusted.
 */

interface Answer {
  readonly blocks: readonly ProvenanceBlock[];
  readonly text: string;
  readonly warnings: readonly ClaimWarning[];
  readonly safe: boolean;
  readonly meta?: { readonly model: string; readonly provider: string; readonly cached: boolean };
}

interface Turn {
  readonly id: string;
  readonly question: string;
  readonly answer: Answer | null;
  readonly error: string | null;
}

export function Copilot({
  projects,
  enabled,
  disabledReason,
}: {
  readonly projects: readonly ProjectRow[];
  readonly enabled: boolean;
  readonly disabledReason: string;
}) {
  const [projectId, setProjectId] = useState(projects[0]?.id ?? '');
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [prompt, setPrompt] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [context, setContext] = useState<ContextSummary | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, [turns]);

  async function post(url: string, body: unknown): Promise<Record<string, unknown>> {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify(body),
    });
    const payload = (await response.json()) as Record<string, unknown>;
    return { ...payload, status: response.status };
  }

  async function ask(question: string, replaceTurnId?: string) {
    if (question.trim().length === 0 || projectId.length === 0) return;

    const turnId = replaceTurnId ?? `t${Date.now()}`;
    if (!replaceTurnId) {
      setTurns((current) => [...current, { id: turnId, question, answer: null, error: null }]);
      setPrompt('');
    }
    setBusy(turnId);
    setNotice(null);

    const payload = await post('/api/ai/chat', { prompt: question, projectId, conversationId });
    setBusy(null);

    if (payload.ok !== true) {
      const message = typeof payload.message === 'string' ? payload.message : 'That did not work.';
      setTurns((current) =>
        current.map((turn) => (turn.id === turnId ? { ...turn, answer: null, error: message } : turn)),
      );
      return;
    }

    const data = payload.data as Record<string, unknown>;
    if (typeof data.conversationId === 'string') setConversationId(data.conversationId);
    if (data.context) setContext(data.context as ContextSummary);

    setTurns((current) =>
      current.map((turn) =>
        turn.id === turnId
          ? {
              ...turn,
              error: null,
              answer: {
                blocks: data.blocks as ProvenanceBlock[],
                text: data.text as string,
                warnings: data.warnings as ClaimWarning[],
                safe: data.safe === true,
                meta: data.meta as Answer['meta'],
              },
            }
          : turn,
      ),
    );
  }

  async function applyRefinement(turn: Turn, refinement: string, target?: string) {
    if (!turn.answer) return;
    setBusy(turn.id);
    setNotice(null);

    const payload = await post('/api/ai/refine', {
      refinement,
      target,
      text: turn.answer.text,
      projectId,
    });
    setBusy(null);

    if (payload.ok !== true) {
      setNotice(typeof payload.message === 'string' ? payload.message : 'That rewrite did not work.');
      return;
    }

    const data = payload.data as Record<string, unknown>;
    setTurns((current) =>
      current.map((item) =>
        item.id === turn.id
          ? {
              ...item,
              answer: {
                blocks: data.blocks as ProvenanceBlock[],
                text: data.text as string,
                warnings: data.warnings as ClaimWarning[],
                safe: data.safe === true,
              },
            }
          : item,
      ),
    );
  }

  async function copy(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      setNotice('Copied to the clipboard.');
    } catch {
      setNotice('Your browser blocked the clipboard. Select the text and copy it manually.');
    }
  }

  async function exportAnswer(turn: Turn, format: string) {
    if (!turn.answer) return;
    const response = await fetch('/api/ai/export', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify({ blocks: turn.answer.blocks, format, title: turn.question }),
    });

    if (!response.ok) {
      setNotice('That could not be exported.');
      return;
    }

    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${format === 'json' ? 'answer.json' : format === 'md' ? 'answer.md' : 'answer.txt'}`;
    link.click();
    URL.revokeObjectURL(url);
  }

  if (projects.length === 0) {
    return (
      <Alert tone="info" title="Create a project first">
        The Copilot answers using one project&rsquo;s business details, marketing profile and brand
        voice. Without a project there is nothing for it to reason about.
        <span className="mt-3 block">
          <Button href="/app/projects" size="sm" variant="secondary">
            Go to projects
          </Button>
        </span>
      </Alert>
    );
  }

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-5">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">AI Copilot</h1>
        <p className="mt-2 text-sm leading-relaxed text-fg-muted">
          Ask about your marketing. Every answer is labelled with where it came from, and anything
          the model worked out for itself is marked as such.
        </p>
      </div>

      {!enabled ? <Alert tone="warning" title="AI is not configured">{disabledReason}</Alert> : null}

      <div className="flex flex-wrap items-end gap-3">
        <Field id="copilot-project" label="Project" className="min-w-56 flex-1">
          {({ id }) => (
            <Select
              id={id}
              value={projectId}
              onChange={(event) => {
                setProjectId(event.target.value);
                setConversationId(null);
                setTurns([]);
                setContext(null);
              }}
            >
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.name}
                </option>
              ))}
            </Select>
          )}
        </Field>
        {turns.length > 0 ? (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setTurns([]);
              setConversationId(null);
            }}
          >
            New conversation
          </Button>
        ) : null}
      </div>

      {context ? <ContextPanel context={context} /> : null}

      {notice ? (
        <Alert tone="info" live>
          {notice}
        </Alert>
      ) : null}

      <div className="flex flex-col gap-5">
        {turns.map((turn) => (
          <div key={turn.id} className="flex flex-col gap-3">
            <div className="self-end rounded-card bg-primary-subtle px-4 py-2.5 text-sm text-primary-subtle-fg">
              {turn.question}
            </div>

            {turn.error ? (
              <Alert tone="danger" title="That did not work">
                {turn.error}
                <span className="mt-3 block">
                  <Button size="sm" variant="secondary" onClick={() => void ask(turn.question, turn.id)}>
                    Try again
                  </Button>
                </span>
              </Alert>
            ) : null}

            {busy === turn.id && !turn.answer ? (
              <p className="text-sm text-fg-subtle" aria-live="polite">
                Thinking&hellip;
              </p>
            ) : null}

            {turn.answer ? (
              <Card className="p-5">
                {turn.answer.warnings.length > 0 ? (
                  <div className="mb-4">
                    <ClaimWarnings warnings={turn.answer.warnings} />
                  </div>
                ) : null}

                <ProvenanceBlocks blocks={turn.answer.blocks} />

                <AnswerActions
                  busy={busy === turn.id}
                  onCopy={() => void copy(turn.answer!.text)}
                  onRegenerate={() => void ask(turn.question, turn.id)}
                  onRefine={(refinement, target) => void applyRefinement(turn, refinement, target)}
                  onExport={(format) => void exportAnswer(turn, format)}
                />

                {turn.answer.meta ? (
                  <p className="mt-3 text-xs text-fg-subtle">
                    {turn.answer.meta.model}
                    {turn.answer.meta.cached ? ' · from cache' : ''}
                  </p>
                ) : null}
              </Card>
            ) : null}
          </div>
        ))}
        <div ref={endRef} />
      </div>

      <form
        className="flex flex-col gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          void ask(prompt);
        }}
      >
        <Field id="copilot-prompt" label="Your question">
          {({ id }) => (
            <Textarea
              id={id}
              rows={3}
              value={prompt}
              disabled={!enabled}
              placeholder="What should I post about this week?"
              onChange={(event) => setPrompt(event.target.value)}
            />
          )}
        </Field>
        <div className="flex items-center justify-between gap-3">
          <p className="text-xs text-fg-subtle">
            The Copilot only knows what is in this project. It will say so when something is missing.
          </p>
          <Button type="submit" disabled={!enabled || busy !== null || prompt.trim().length === 0}>
            {busy ? 'Working…' : 'Ask'}
          </Button>
        </div>
      </form>

      <ProvenanceLegend />
    </div>
  );
}

/** What the model was given, and what it was not. */
function ContextPanel({ context }: { readonly context: ContextSummary }) {
  return (
    <Card className="p-4">
      <p className="text-sm font-semibold">What the Copilot is working from</p>
      <div className="mt-2.5 flex flex-wrap gap-1.5">
        {context.present.map((item) => (
          <Badge key={item} tone="success">
            {item}
          </Badge>
        ))}
        {context.missing.map((item) => (
          <Badge key={item} tone="outline">
            {item}: not available
          </Badge>
        ))}
      </div>
      {context.missing.length > 0 ? (
        <p className="mt-2.5 text-xs leading-relaxed text-fg-subtle">
          Missing inputs are not guessed at. Fill them in to get more specific answers.
        </p>
      ) : null}
    </Card>
  );
}

function AnswerActions({
  busy,
  onCopy,
  onRegenerate,
  onRefine,
  onExport,
}: {
  readonly busy: boolean;
  readonly onCopy: () => void;
  readonly onRegenerate: () => void;
  readonly onRefine: (refinement: string, target?: string) => void;
  readonly onExport: (format: string) => void;
}) {
  const [tone, setTone] = useState<string>(TONES[0]);
  const [language, setLanguage] = useState<string>('hi');

  return (
    <div className="mt-4 flex flex-col gap-3 border-t border-border pt-4">
      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant="secondary" onClick={onCopy} disabled={busy}>
          <Icon name="copy" size={14} /> Copy
        </Button>
        <Button size="sm" variant="secondary" onClick={onRegenerate} disabled={busy}>
          Regenerate
        </Button>
        <Button size="sm" variant="ghost" onClick={() => onRefine('shorten')} disabled={busy}>
          Shorten
        </Button>
        <Button size="sm" variant="ghost" onClick={() => onRefine('expand')} disabled={busy}>
          Expand
        </Button>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <label className="text-xs text-fg-subtle" htmlFor="refine-tone">
          Tone
        </label>
        <Select
          id="refine-tone"
          className="h-9 w-auto text-sm"
          value={tone}
          onChange={(event) => setTone(event.target.value)}
        >
          {TONES.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </Select>
        <Button size="sm" variant="ghost" onClick={() => onRefine('change_tone', tone)} disabled={busy}>
          Change tone
        </Button>

        <label className="ml-2 text-xs text-fg-subtle" htmlFor="refine-language">
          Language
        </label>
        <Select
          id="refine-language"
          className="h-9 w-auto text-sm"
          value={language}
          onChange={(event) => setLanguage(event.target.value)}
        >
          {LANGUAGES.map((code) => (
            <option key={code} value={code}>
              {LANGUAGE_SPECS[code].label}
            </option>
          ))}
        </Select>
        <Button
          size="sm"
          variant="ghost"
          onClick={() => onRefine('translate', LANGUAGE_SPECS[language as 'en'].label)}
          disabled={busy}
        >
          Translate
        </Button>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs text-fg-subtle">Export</span>
        {(['txt', 'md', 'json'] as const).map((format) => (
          <Button key={format} size="sm" variant="ghost" onClick={() => onExport(format)} disabled={busy}>
            .{format}
          </Button>
        ))}
      </div>
    </div>
  );
}
