'use client';

import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';

import { readCsrfCookie } from '@/components/app/app-shell';
import { Button } from '@/components/ui/button';
import { Field, Input, Textarea } from '@/components/ui/field';
import { PLANS_BY_RANK } from '@/content/plans';

/**
 * The editor for one feature flag's rule.
 *
 * THE PRECEDENCE IS PRINTED ON THE FORM, not buried in a doc comment, because a
 * rule with a rollout percentage AND an exclusion list AND a plan gate is not
 * obvious from the fields alone — and someone setting one at 2am should not have
 * to reason it out. The order the evaluator uses is: kill switch, then
 * exclusions, then named accounts, then plans, then the percentage, then the
 * declared default.
 *
 * The percentage is a COHORT, not a dice roll: the same account gets the same
 * answer every time, and two flags at the same percentage pick different
 * accounts.
 */

export interface FlagRuleValue {
  readonly disabled: boolean;
  readonly organizationIds: readonly string[];
  readonly excludedOrganizationIds: readonly string[];
  readonly plans: readonly string[];
  readonly rolloutPercent: number;
}

export function FlagRuleEditor({
  flagKey,
  label,
  rule,
}: {
  readonly flagKey: string;
  readonly label: string;
  readonly rule: FlagRuleValue | null;
}) {
  const router = useRouter();
  const [busy, startTransition] = useTransition();
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [disabled, setDisabled] = useState(rule?.disabled ?? false);
  const [percent, setPercent] = useState(String(rule?.rolloutPercent ?? 0));
  const [plans, setPlans] = useState<readonly string[]>(rule?.plans ?? []);
  const [included, setIncluded] = useState((rule?.organizationIds ?? []).join('\n'));
  const [excluded, setExcluded] = useState((rule?.excludedOrganizationIds ?? []).join('\n'));

  async function save() {
    setError(null);
    setNotice(null);

    const parsed = Number(percent.trim());
    if (!Number.isInteger(parsed) || parsed < 0 || parsed > 100) {
      setError('The percentage must be a whole number between 0 and 100.');
      return;
    }

    const response = await fetch('/api/admin/flags', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify({
        key: flagKey,
        disabled,
        rolloutPercent: parsed,
        plans,
        organizationIds: lines(included),
        excludedOrganizationIds: lines(excluded),
      }),
    });
    const payload = (await response.json().catch(() => null)) as
      | { readonly message?: string; readonly errors?: Record<string, string> }
      | null;

    if (response.status === 403 && payload?.errors?.needsSudo) {
      setError('Confirm your password again before changing a flag.');
      return;
    }
    if (!response.ok) {
      setError(payload?.message ?? 'That rule was refused.');
      return;
    }
    setNotice('Saved. It applies to the next request each account makes.');
    startTransition(() => router.refresh());
  }

  if (!open) {
    return (
      <Button variant="ghost" size="sm" onClick={() => setOpen(true)}>
        {rule ? 'Edit rule' : 'Add a rule'}
      </Button>
    );
  }

  return (
    <div className="mt-3 flex flex-col gap-4 rounded-control border border-border bg-bg-subtle p-4">
      <p className="text-xs leading-relaxed text-fg-muted">
        Checked in this order: <strong>off for everyone</strong>, then <strong>excluded</strong>,
        then <strong>named accounts</strong>, then <strong>plans</strong>, then the{' '}
        <strong>percentage</strong>, then the flag&rsquo;s declared default. The first one that
        matches decides.
      </p>

      {error ? (
        <p role="alert" className="text-sm font-medium text-danger">
          {error}
        </p>
      ) : null}
      {notice ? (
        <p role="status" className="text-sm font-medium text-success">
          {notice}
        </p>
      ) : null}

      <label className="flex items-start gap-2 text-sm">
        <input
          type="checkbox"
          checked={disabled}
          onChange={(event) => setDisabled(event.target.checked)}
          className="mt-0.5"
        />
        <span>
          <span className="font-medium">Off for everyone</span>
          <span className="block text-xs text-fg-muted">
            The kill switch. Beats every other setting below, including a named account.
          </span>
        </span>
      </label>

      <fieldset className="flex flex-col gap-2">
        <legend className="text-sm font-medium">On for these plans</legend>
        <div className="flex flex-wrap gap-3">
          {PLANS_BY_RANK.map((plan) => (
            <label key={plan.id} className="flex items-center gap-1.5 text-sm">
              <input
                type="checkbox"
                checked={plans.includes(plan.id)}
                onChange={(event) =>
                  setPlans((current) =>
                    event.target.checked
                      ? [...current, plan.id]
                      : current.filter((entry) => entry !== plan.id),
                  )
                }
              />
              {plan.name}
            </label>
          ))}
        </div>
      </fieldset>

      <Field
        id={`${flagKey}-percent`}
        label="Percentage of other accounts"
        hint="A stable cohort, not a coin flip: the same account always gets the same answer, and two flags at the same percentage pick different accounts."
      >
        {({ id, describedBy }) => (
          <Input
            id={id}
            type="text"
            inputMode="numeric"
            value={percent}
            aria-describedby={describedBy}
            onChange={(event) => setPercent(event.target.value)}
            className="w-24"
          />
        )}
      </Field>

      <Field
        id={`${flagKey}-included`}
        label="Always on for these accounts"
        hint="One organization id per line."
      >
        {({ id, describedBy }) => (
          <Textarea
            id={id}
            rows={3}
            value={included}
            aria-describedby={describedBy}
            onChange={(event) => setIncluded(event.target.value)}
          />
        )}
      </Field>

      <Field
        id={`${flagKey}-excluded`}
        label="Never on for these accounts"
        hint="One per line. Beats the named list, the plans and the percentage."
      >
        {({ id, describedBy }) => (
          <Textarea
            id={id}
            rows={3}
            value={excluded}
            aria-describedby={describedBy}
            onChange={(event) => setExcluded(event.target.value)}
          />
        )}
      </Field>

      <div className="flex flex-wrap gap-2">
        <Button size="sm" disabled={busy} onClick={() => void save()}>
          Save {label}
        </Button>
        <Button variant="ghost" size="sm" disabled={busy} onClick={() => setOpen(false)}>
          Cancel
        </Button>
      </div>
    </div>
  );
}

function lines(value: string): readonly string[] {
  return value
    .split('\n')
    .map((entry) => entry.trim())
    .filter((entry) => entry.length > 0);
}
