'use client';

import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';

import { readCsrfCookie } from '@/components/app/app-shell';
import { Button } from '@/components/ui/button';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Field, Input, Select, Textarea } from '@/components/ui/field';
import { STAFF_ROLES, STAFF_ROLE_DESCRIPTION, STAFF_ROLE_LABEL, type StaffRole } from '@/lib/admin/auth';

/**
 * Granting and revoking platform access.
 *
 * THE MOST DANGEROUS FORM IN THE PRODUCT. It is the power to grant power, so:
 *
 *  - the reason is required, and it is the field that makes a stale grant
 *    removable by someone who was not there when it was made;
 *  - the role descriptions are shown beside the choice rather than in a tooltip,
 *    because "engineer" and "platform owner" are not self-explanatory and the
 *    difference is the ability to grant this again;
 *  - revoking asks for confirmation, and the service separately refuses to
 *    revoke the last platform owner — with nobody holding that role, access
 *    cannot be restored without direct database access.
 */

export function GrantStaffForm() {
  const router = useRouter();
  const [busy, startTransition] = useTransition();
  const [userId, setUserId] = useState('');
  const [role, setRole] = useState<StaffRole>('support');
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  async function submit() {
    setError(null);
    setNotice(null);
    setFieldErrors({});

    const response = await fetch('/api/admin/staff', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify({ userId: userId.trim(), role, reason }),
    });
    const payload = (await response.json().catch(() => null)) as
      | { readonly message?: string; readonly errors?: Record<string, string> }
      | null;

    if (response.status === 403 && payload?.errors?.needsSudo) {
      setError('Confirm your password again before granting platform access.');
      return;
    }
    if (!response.ok) {
      if (payload?.errors) setFieldErrors(payload.errors);
      setError(payload?.message ?? 'That grant was refused.');
      return;
    }
    setNotice('Granted. It takes effect on their next request.');
    setUserId('');
    setReason('');
    startTransition(() => router.refresh());
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle as="h2">Grant platform access</CardTitle>
        <CardDescription>
          This is separate from any organization role. A user who owns their own workspace is not
          platform staff, and platform staff is not membership of any account.
        </CardDescription>
      </CardHeader>

      <div className="flex flex-col gap-4 px-6 pb-6">
        {error ? (
          <p
            role="alert"
            className="rounded-control border border-danger/40 bg-danger-subtle px-3.5 py-2.5 text-sm text-danger"
          >
            {error}
          </p>
        ) : null}
        {notice ? (
          <p
            role="status"
            className="rounded-control border border-success/40 bg-success-subtle px-3.5 py-2.5 text-sm text-success"
          >
            {notice}
          </p>
        ) : null}

        <Field
          id="grant-user"
          label="User id"
          hint="The user must already have a SeSha account. This does not create one."
          error={fieldErrors.userId}
          required
        >
          {({ id, describedBy, invalid }) => (
            <Input
              id={id}
              value={userId}
              aria-describedby={describedBy}
              aria-invalid={invalid}
              onChange={(event) => setUserId(event.target.value)}
            />
          )}
        </Field>

        <Field id="grant-role" label="Role" error={fieldErrors.role} required>
          {({ id }) => (
            <Select
              id={id}
              value={role}
              onChange={(event) => setRole(event.target.value as StaffRole)}
            >
              {STAFF_ROLES.map((entry) => (
                <option key={entry} value={entry}>
                  {STAFF_ROLE_LABEL[entry]}
                </option>
              ))}
            </Select>
          )}
        </Field>

        <p className="text-xs leading-relaxed text-fg-muted">{STAFF_ROLE_DESCRIPTION[role]}</p>

        <Field
          id="grant-reason"
          label="Reason"
          hint="Required. An unexplained staff row is the one nobody removes when someone changes team."
          error={fieldErrors.reason}
          required
        >
          {({ id, describedBy, invalid }) => (
            <Textarea
              id={id}
              rows={2}
              value={reason}
              aria-describedby={describedBy}
              aria-invalid={invalid}
              onChange={(event) => setReason(event.target.value)}
            />
          )}
        </Field>

        <div>
          <Button size="sm" disabled={busy} onClick={() => void submit()}>
            Grant access
          </Button>
        </div>
      </div>
    </Card>
  );
}

export function RevokeStaffButton({
  userId,
  label,
}: {
  readonly userId: string;
  readonly label: string;
}) {
  const router = useRouter();
  const [busy, startTransition] = useTransition();
  const [confirming, setConfirming] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function revoke() {
    setError(null);
    const response = await fetch('/api/admin/staff', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify({ userId, revoke: true }),
    });
    const payload = (await response.json().catch(() => null)) as
      | { readonly message?: string; readonly errors?: Record<string, string> }
      | null;

    if (response.status === 403 && payload?.errors?.needsSudo) {
      setError('Confirm your password again first.');
      return;
    }
    if (!response.ok) {
      setError(payload?.message ?? 'That could not be revoked.');
      return;
    }
    setConfirming(false);
    startTransition(() => router.refresh());
  }

  return (
    <span className="flex flex-col items-start gap-1">
      {confirming ? (
        <span className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-fg-muted">Revoke access for {label}?</span>
          <Button variant="secondary" size="sm" disabled={busy} onClick={() => void revoke()}>
            Yes, revoke
          </Button>
          <Button variant="ghost" size="sm" disabled={busy} onClick={() => setConfirming(false)}>
            Keep
          </Button>
        </span>
      ) : (
        <Button variant="ghost" size="sm" disabled={busy} onClick={() => setConfirming(true)}>
          Revoke
        </Button>
      )}
      {error ? (
        <span role="alert" className="text-xs text-danger">
          {error}
        </span>
      ) : null}
    </span>
  );
}
