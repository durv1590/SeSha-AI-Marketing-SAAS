import type { ReactNode } from 'react';

import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

/**
 * Shared admin-panel furniture.
 *
 * `NotMeasured` exists because the honest answer to several operational
 * questions is "we do not record that", and an admin panel is precisely where
 * that answer must be visible. A dashboard that silently omits what it cannot
 * measure teaches its readers to believe it measures everything.
 */

export function AdminPageHeader({
  title,
  summary,
  actions,
}: {
  readonly title: string;
  readonly summary: string;
  readonly actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-start justify-between gap-3">
      <div className="min-w-0">
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
        <p className="mt-1 max-w-2xl text-sm text-fg-muted">{summary}</p>
      </div>
      {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
    </div>
  );
}

export function Stat({
  label,
  value,
  note,
}: {
  readonly label: string;
  readonly value: string | number;
  readonly note?: string;
}) {
  return (
    <Card className="p-4">
      <p className="text-xs uppercase tracking-wide text-fg-subtle">{label}</p>
      <p className="mt-1 text-2xl font-semibold tabular-nums tracking-tight">
        {typeof value === 'number' ? value.toLocaleString('en-IN') : value}
      </p>
      {note ? <p className="mt-1 text-xs text-fg-muted">{note}</p> : null}
    </Card>
  );
}

export function StatGrid({ children }: { readonly children: ReactNode }) {
  return <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{children}</div>;
}

export function AdminTable({
  caption,
  head,
  children,
  empty,
  minWidth = '40rem',
}: {
  readonly caption: string;
  readonly head: readonly string[];
  readonly children: ReactNode;
  readonly empty?: string;
  readonly minWidth?: string;
}) {
  const hasRows = Array.isArray(children) ? children.length > 0 : Boolean(children);
  if (!hasRows) {
    return <p className="px-6 pb-6 text-sm text-fg-muted">{empty ?? 'Nothing to show.'}</p>;
  }

  return (
    <div className="overflow-x-auto px-6 pb-6">
      <table className="w-full text-sm" style={{ minWidth }}>
        <caption className="sr-only">{caption}</caption>
        <thead>
          <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-fg-subtle">
            {head.map((label, index) => (
              <th
                key={label}
                scope="col"
                className={index === 0 ? 'py-2 pr-4 font-medium' : 'py-2 pr-4 font-medium'}
              >
                {label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-border">{children}</tbody>
      </table>
    </div>
  );
}

export function NotMeasured({ items }: { readonly items: readonly string[] }) {
  if (items.length === 0) return null;
  return (
    <Card tone="subtle">
      <CardHeader>
        <CardTitle as="h2">Not measured</CardTitle>
        <CardDescription>
          Listed rather than left out. Anything below is not recorded by this deployment, so no
          figure for it is shown anywhere in the panel.
        </CardDescription>
      </CardHeader>
      <ul className="flex list-disc flex-col gap-1.5 px-6 pb-6 pl-11 text-sm text-fg-muted">
        {items.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
    </Card>
  );
}

export function CountRow({ counts }: { readonly counts: Readonly<Record<string, number>> }) {
  const entries = Object.entries(counts).filter(([, value]) => value > 0);
  if (entries.length === 0) {
    return <p className="text-sm text-fg-muted">None recorded.</p>;
  }
  return (
    <ul className="flex flex-wrap gap-2">
      {entries.map(([key, value]) => (
        <li key={key}>
          <Badge tone="outline">
            {key.replace(/_/g, ' ')}: {value.toLocaleString('en-IN')}
          </Badge>
        </li>
      ))}
    </ul>
  );
}

export function formatDateTime(value: Date | string): string {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'UTC',
  });
}

export function shortId(value: string | null): string {
  if (!value) return '—';
  return value.length > 12 ? `${value.slice(0, 8)}…` : value;
}
