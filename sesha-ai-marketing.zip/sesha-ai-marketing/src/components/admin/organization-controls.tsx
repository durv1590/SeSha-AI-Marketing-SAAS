'use client';

import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';

import { readCsrfCookie } from '@/components/app/app-shell';
import { Button } from '@/components/ui/button';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Field, Input, Select, Textarea } from '@/components/ui/field';
import { LIMITS, LIMIT_IDS, PLANS_BY_RANK, formatLimit, type LimitId, type PlanId } from '@/content/plans';

/**
 * The two write controls on an organization: override a limit, change the plan.
 *
 * BOTH REQUIRE A REASON, AND THE REASON IS NOT A FORMALITY. It is stored, it is
 * shown to the customer on their own usage screen for an override, and it is the
 * only thing that makes the change removable six months later by someone who was
 * not there. So the field is required here as well as in the service — the
 * service is the guarantee, this is the courtesy of failing before the request.
 *
 * A 403 carrying `needsSudo` is surfaced as "confirm your password", not as an
 * error. Staff who are told "forbidden" when they merely need to re-authenticate
 * learn to distrust the panel.
 */

export function OrganizationControls({
  organizationId,
  currentPlan,
  limits,
}: {
  readonly organizationId: string;
  readonly currentPlan: PlanId;
  readonly limits: readonly {
    readonly limitId: LimitId;
    readonly value: number | null;
    readonly source: 'plan' | 'override';
  }[];
}) {
  const router = useRouter();
  const [busy, startTransition] = useTransition();
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  const [limitId, setLimitId] = useState<LimitId>('ai_requests');
  const [limitValue, setLimitValue] = useState('');
  const [limitReason, setLimitReason] = useState('');
  const [plan, setPlan] = useState<PlanId>(currentPlan);
  const [planReason, setPlanReason] = useState('');

  async function post(path: string, body: Record<string, unknown>) {
    setError(null);
    setNotice(null);
    setFieldErrors({});

    const response = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify(body),
    });
    const payload = (await response.json().catch(() => null)) as
      | { readonly message?: string; readonly errors?: Record<string, string> }
      | null;

    if (response.status === 403 && payload?.errors?.needsSudo) {
      setError('Confirm your password again before making changes, then come back to this page.');
      return false;
    }
    if (!response.ok) {
      if (payload?.errors) setFieldErrors(payload.errors);
      setError(payload?.message ?? 'That did not work.');
      return false;
    }
    setNotice(payload?.message ?? 'Saved.');
    startTransition(() => router.refresh());
    return true;
  }

  const selected = limits.find((entry) => entry.limitId === limitId);

  return (
    <div className="flex flex-col gap-4">
      {error ? (
        <p
          role="alert"
          className="rounded-control border border-danger/40 bg-danger-subtle px-3.5 py-2.5 text-sm text-danger"
        >
          {error}
        </p>
      ) : null}
      {notice ? (
        <p
          role="status"
          className="rounded-control border border-success/40 bg-success-subtle px-3.5 py-2.5 text-sm text-success"
        >
          {notice}
        </p>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle as="h2">Override a limit</CardTitle>
          <CardDescription>
            Applies to this organization only. The reason you give is shown to them on their own
            usage screen.
          </CardDescription>
        </CardHeader>

        <div className="flex flex-col gap-4 px-6 pb-6">
          <Field id="override-limit" label="Limit">
            {({ id }) => (
              <Select
                id={id}
                value={limitId}
                onChange={(event) => setLimitId(event.target.value as LimitId)}
              >
                {LIMIT_IDS.map((entry) => (
                  <option key={entry} value={entry}>
                    {LIMITS[entry].label}
                  </option>
                ))}
              </Select>
            )}
          </Field>

          <Field
            id="override-value"
            label="New value"
            hint={
              selected
                ? `Currently ${formatLimit(selected.value)}${selected.source === 'override' ? ' (already overridden)' : ' from the plan'}. Leave blank and use "unlimited" for no ceiling.`
                : 'A whole number of zero or more.'
            }
            error={fieldErrors.value}
            required
          >
            {({ id, describedBy, invalid }) => (
              <Input
                id={id}
                type="text"
                inputMode="numeric"
                value={limitValue}
                placeholder="e.g. 500, or: unlimited"
                aria-describedby={describedBy}
                aria-invalid={invalid}
                onChange={(event) => setLimitValue(event.target.value)}
              />
            )}
          </Field>

          <Field
            id="override-reason"
            label="Reason"
            hint="Shown to the customer. Write it as if they will read it, because they will."
            error={fieldErrors.reason}
            required
          >
            {({ id, describedBy, invalid }) => (
              <Textarea
                id={id}
                rows={2}
                value={limitReason}
                aria-describedby={describedBy}
                aria-invalid={invalid}
                onChange={(event) => setLimitReason(event.target.value)}
              />
            )}
          </Field>

          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              disabled={busy}
              onClick={() => {
                const trimmed = limitValue.trim().toLowerCase();
                // `Number('')` is 0, and 0 means "not included in this plan" —
                // an empty box must never be read as taking the feature away.
                if (trimmed.length === 0) {
                  setFieldErrors({ value: 'Enter a number, or the word "unlimited".' });
                  setError('Please check the value.');
                  return;
                }
                const value = trimmed === 'unlimited' || trimmed === 'null' ? null : Number(trimmed);
                if (value !== null && (!Number.isInteger(value) || value < 0)) {
                  setFieldErrors({ value: 'A whole number of zero or more, or "unlimited".' });
                  setError('Please check the value.');
                  return;
                }
                void post('/api/admin/limits', {
                  organizationId,
                  limitId,
                  value,
                  reason: limitReason,
                });
              }}
            >
              Save override
            </Button>
            {selected?.source === 'override' ? (
              <Button
                variant="secondary"
                size="sm"
                disabled={busy}
                onClick={() =>
                  void post('/api/admin/limits', {
                    organizationId,
                    limitId,
                    clear: true,
                    reason: limitReason || 'Removed; back to the plan default.',
                  })
                }
              >
                Remove this override
              </Button>
            ) : null}
          </div>
        </div>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle as="h2">Change the plan</CardTitle>
          <CardDescription>
            Moves this account only, with no payment taken. Recorded in their billing history as a
            staff change, so it is never mistaken for something they did.
          </CardDescription>
        </CardHeader>

        <div className="flex flex-col gap-4 px-6 pb-6">
          <Field id="plan-id" label="Plan">
            {({ id }) => (
              <Select
                id={id}
                value={plan}
                onChange={(event) => setPlan(event.target.value as PlanId)}
              >
                {PLANS_BY_RANK.map((definition) => (
                  <option key={definition.id} value={definition.id}>
                    {definition.name}
                    {definition.id === currentPlan ? ' — current' : ''}
                  </option>
                ))}
              </Select>
            )}
          </Field>

          <Field id="plan-reason" label="Reason" error={fieldErrors.reason} required>
            {({ id, describedBy, invalid }) => (
              <Textarea
                id={id}
                rows={2}
                value={planReason}
                placeholder="Support case #…, agreed with…"
                aria-describedby={describedBy}
                aria-invalid={invalid}
                onChange={(event) => setPlanReason(event.target.value)}
              />
            )}
          </Field>

          <Button
            size="sm"
            disabled={busy || plan === currentPlan}
            onClick={() =>
              void post('/api/admin/plans', { organizationId, plan, reason: planReason })
            }
          >
            {plan === currentPlan ? 'Already on this plan' : 'Change plan'}
          </Button>
        </div>
      </Card>
    </div>
  );
}
