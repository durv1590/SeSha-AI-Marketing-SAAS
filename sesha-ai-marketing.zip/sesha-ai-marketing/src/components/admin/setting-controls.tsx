'use client';

import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';

import { readCsrfCookie } from '@/components/app/app-shell';
import { Button } from '@/components/ui/button';
import { Field, Input, Textarea } from '@/components/ui/field';

/**
 * The editor for one system setting.
 *
 * THE SHAPE DRIVES THE CONTROL, and the control is chosen by the declared shape
 * rather than guessed from the current value: a `string_list` that happens to be
 * empty is still a list, and a `number` that happens to be 0 is still a number.
 * Guessing from the value is how a boolean ends up as a text box the first time
 * nobody has set it.
 *
 * The server re-validates everything — bounds, length, and the narrow-only
 * direction on the crawler ceiling. Nothing here is the guarantee.
 */

export function SettingEditor({
  settingKey,
  label,
  shape,
  value,
  isDefault,
}: {
  readonly settingKey: string;
  readonly label: string;
  readonly shape: string;
  readonly value: unknown;
  readonly isDefault: boolean;
}) {
  const router = useRouter();
  const [busy, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [draft, setDraft] = useState(() => toText(shape, value));
  const [checked, setChecked] = useState(value === true);

  async function save(next: unknown) {
    setError(null);
    setNotice(null);

    const response = await fetch('/api/admin/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify({ key: settingKey, value: next }),
    });
    const payload = (await response.json().catch(() => null)) as
      | { readonly message?: string; readonly errors?: Record<string, string> }
      | null;

    if (response.status === 403 && payload?.errors?.needsSudo) {
      setError('Confirm your password again before changing configuration.');
      return;
    }
    if (!response.ok) {
      setError(payload?.message ?? 'That value was refused.');
      return;
    }
    setNotice('Saved.');
    startTransition(() => router.refresh());
  }

  const control =
    shape === 'boolean' ? (
      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={checked}
          disabled={busy}
          onChange={(event) => {
            setChecked(event.target.checked);
            void save(event.target.checked);
          }}
        />
        <span>{checked ? 'On' : 'Off'}</span>
      </label>
    ) : (
      <div className="flex flex-col gap-2">
        <Field
          id={`setting-${settingKey}`}
          label={label}
          hint={
            shape === 'string_list'
              ? 'One value per line.'
              : shape === 'number'
                ? 'A whole number.'
                : undefined
          }
        >
          {({ id, describedBy }) =>
            shape === 'string_list' || shape === 'string' ? (
              <Textarea
                id={id}
                rows={shape === 'string_list' ? 4 : 3}
                value={draft}
                aria-describedby={describedBy}
                onChange={(event) => setDraft(event.target.value)}
              />
            ) : (
              <Input
                id={id}
                type="text"
                inputMode="numeric"
                value={draft}
                aria-describedby={describedBy}
                onChange={(event) => setDraft(event.target.value)}
                className="w-32"
              />
            )
          }
        </Field>

        <div>
          <Button
            size="sm"
            disabled={busy}
            onClick={() => {
              const parsed = fromText(shape, draft);
              if (parsed === INVALID) {
                setError('That is not a whole number.');
                return;
              }
              void save(parsed);
            }}
          >
            Save
          </Button>
        </div>
      </div>
    );

  return (
    <div className="flex flex-col gap-2">
      {control}
      {isDefault ? (
        <p className="text-xs text-fg-subtle">
          Never changed — this is the value declared in the code.
        </p>
      ) : null}
      {error ? (
        <p role="alert" className="text-sm font-medium text-danger">
          {error}
        </p>
      ) : null}
      {notice ? (
        <p role="status" className="text-sm font-medium text-success">
          {notice}
        </p>
      ) : null}
    </div>
  );
}

const INVALID = Symbol('invalid');

function toText(shape: string, value: unknown): string {
  if (shape === 'string_list') {
    return Array.isArray(value) ? value.map(String).join('\n') : '';
  }
  if (value === null || value === undefined) return '';
  return String(value);
}

function fromText(shape: string, text: string): unknown {
  if (shape === 'string_list') {
    return text
      .split('\n')
      .map((entry) => entry.trim())
      .filter((entry) => entry.length > 0);
  }
  if (shape === 'number') {
    const trimmed = text.trim();
    // `Number('')` is 0. An empty box is not a zero.
    if (trimmed.length === 0) return INVALID;
    const parsed = Number(trimmed);
    return Number.isInteger(parsed) ? parsed : INVALID;
  }
  return text;
}
