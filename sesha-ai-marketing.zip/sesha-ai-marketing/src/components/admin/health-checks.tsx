import { Badge } from '@/components/ui/badge';
import type { HealthReport } from '@/lib/admin/service';

/**
 * The health check list.
 *
 * `unknown` gets its own tone and its own word. A check that could not be
 * performed is not a pass, and rendering it green because it is not red is how a
 * status page ends up lying.
 */

const TONE = {
  ok: 'success',
  warn: 'warning',
  fail: 'danger',
  unknown: 'neutral',
} as const;

const WORD = {
  ok: 'OK',
  warn: 'Attention',
  fail: 'Failing',
  unknown: 'Not known',
} as const;

export function HealthChecks({ checks }: { readonly checks: HealthReport['checks'] }) {
  return (
    <ul className="flex flex-col divide-y divide-border text-sm">
      {checks.map((check) => (
        <li key={check.id} className="flex flex-col gap-1 py-3 first:pt-0 last:pb-0">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="font-medium text-fg">{check.label}</span>
            <Badge tone={TONE[check.state]}>{WORD[check.state]}</Badge>
          </div>
          <p className="text-fg-muted">{check.detail}</p>
        </li>
      ))}
    </ul>
  );
}
