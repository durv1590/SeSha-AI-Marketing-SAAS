'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import type { ReactNode } from 'react';

import { Badge } from '@/components/ui/badge';
import { ADMIN_NAV } from '@/content/admin-nav';
import type { AdminPermission, StaffRole } from '@/lib/admin/auth';
import { cn } from '@/lib/utils/cn';

/**
 * The admin panel shell.
 *
 * VISUALLY DISTINCT FROM THE CUSTOMER APP, ON PURPOSE. Staff can see across every
 * tenant here, and a panel that looked like the ordinary workspace would make it
 * possible to forget that. The dark header and the permanent banner are a
 * reminder of whose data is on screen, not decoration.
 *
 * The sudo notice is shown rather than hidden: a staff member who will be asked
 * to re-authenticate the moment they try to change something should know that
 * before they fill in a form, not after.
 */

export function AdminShell({
  role,
  roleLabel,
  permissions,
  sudo,
  children,
}: {
  readonly role: StaffRole;
  readonly roleLabel: string;
  readonly permissions: readonly AdminPermission[];
  readonly sudo: boolean;
  readonly children: ReactNode;
}) {
  const pathname = usePathname() ?? '/admin';
  const held = new Set<string>(permissions);

  return (
    <div className="min-h-dvh bg-bg">
      <a
        href="#admin-main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-control focus:bg-surface focus:px-4 focus:py-2 focus:text-sm"
      >
        Skip to content
      </a>

      <header className="border-b border-border-strong bg-fg text-bg">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-baseline gap-3">
            <span className="text-sm font-semibold uppercase tracking-widest">
              SeSha platform
            </span>
            <span className="text-xs opacity-70">{roleLabel}</span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            {sudo ? (
              <Badge tone="success">Re-authenticated</Badge>
            ) : (
              <Badge tone="warning">Sign-in confirmation needed to change anything</Badge>
            )}
            <Link href="/app" className="underline underline-offset-2 opacity-80 hover:opacity-100">
              Leave the panel
            </Link>
          </div>
        </div>
      </header>

      <p className="border-b border-warning/40 bg-warning-subtle px-4 py-2 text-center text-xs text-warning sm:px-6">
        You are looking at other people&rsquo;s accounts. Every page you open is recorded against
        your name, including this one.
      </p>

      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-6 sm:px-6 lg:flex-row">
        <nav aria-label="Admin" className="lg:w-56 lg:shrink-0">
          <ul className="flex flex-col gap-5">
            {ADMIN_NAV.map((group) => {
              const items = group.items.filter((item) => held.has(item.permission));
              if (items.length === 0) return null;
              return (
                <li key={group.label}>
                  <p className="mb-1.5 text-xs font-medium uppercase tracking-wide text-fg-subtle">
                    {group.label}
                  </p>
                  <ul className="flex flex-col gap-0.5">
                    {items.map((item) => {
                      const active =
                        item.href === '/admin'
                          ? pathname === '/admin'
                          : pathname === item.href || pathname.startsWith(`${item.href}/`);
                      return (
                        <li key={item.href}>
                          <Link
                            href={item.href}
                            aria-current={active ? 'page' : undefined}
                            className={cn(
                              'block rounded-control px-3 py-1.5 text-sm transition-colors',
                              active
                                ? 'bg-primary-subtle font-medium text-primary-subtle-fg'
                                : 'text-fg-muted hover:bg-bg-muted hover:text-fg',
                            )}
                          >
                            {item.label}
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </li>
              );
            })}
          </ul>

          <p className="mt-6 text-xs leading-relaxed text-fg-subtle">
            Your role is <strong className="font-medium text-fg-muted">{role}</strong>. Screens you
            cannot open are not listed.
          </p>
        </nav>

        <main id="admin-main" className="min-w-0 flex-1">
          {children}
        </main>
      </div>
    </div>
  );
}
