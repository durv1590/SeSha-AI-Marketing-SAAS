'use client';

import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';

import { readCsrfCookie } from '@/components/app/app-shell';
import { Button } from '@/components/ui/button';

/**
 * The two one-click triage actions: resolve an error, move feedback along.
 *
 * Both are small enough that a form would be ceremony, but neither is a
 * navigation — so they are buttons that post, not links that look like buttons.
 * A refusal is shown in place rather than as a banner at the top of a long list,
 * because by the time you have scrolled to row forty you will not see a banner.
 */

function useAction() {
  const router = useRouter();
  const [busy, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  async function post(path: string, body: Record<string, unknown>) {
    setError(null);
    const response = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': readCsrfCookie() },
      body: JSON.stringify(body),
    });
    const payload = (await response.json().catch(() => null)) as
      | { readonly message?: string; readonly errors?: Record<string, string> }
      | null;

    if (response.status === 403 && payload?.errors?.needsSudo) {
      setError('Confirm your password again first.');
      return;
    }
    if (!response.ok) {
      setError(payload?.message ?? 'That did not work.');
      return;
    }
    startTransition(() => router.refresh());
  }

  return { busy, error, post };
}

export function ResolveErrorButton({ fingerprint }: { readonly fingerprint: string }) {
  const { busy, error, post } = useAction();

  return (
    <span className="flex flex-col items-start gap-1">
      <Button
        variant="ghost"
        size="sm"
        disabled={busy}
        onClick={() => void post('/api/admin/errors', { fingerprint })}
      >
        Mark resolved
      </Button>
      {error ? (
        <span role="alert" className="text-xs text-danger">
          {error}
        </span>
      ) : null}
    </span>
  );
}

const NEXT_STATUS = {
  new: { to: 'triaged', label: 'Mark triaged' },
  triaged: { to: 'answered', label: 'Mark answered' },
  answered: { to: 'closed', label: 'Close' },
  closed: null,
} as const;

export function FeedbackStatusButton({
  id,
  status,
}: {
  readonly id: string;
  readonly status: 'new' | 'triaged' | 'answered' | 'closed';
}) {
  const { busy, error, post } = useAction();
  const next = NEXT_STATUS[status];

  if (!next) {
    return <span className="text-xs text-fg-subtle">Closed.</span>;
  }

  return (
    <span className="flex flex-col items-start gap-1">
      <Button
        variant="ghost"
        size="sm"
        disabled={busy}
        onClick={() => void post('/api/admin/feedback', { id, status: next.to })}
      >
        {next.label}
      </Button>
      {error ? (
        <span role="alert" className="text-xs text-danger">
          {error}
        </span>
      ) : null}
    </span>
  );
}
