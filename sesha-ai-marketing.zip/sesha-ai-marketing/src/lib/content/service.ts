/**
 * Content Studio service.
 *
 * Generation and CRUD for the 20 content formats. Every path is tenant-scoped
 * and every generated item lands as a DRAFT — there is no code path that writes
 * `approved` except an explicit human review call.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { enforceOrThrow } from '@/lib/quota/service';
import { periodStartOf } from '@/lib/usage/metrics';
import { assertTenant, type TenantContext } from '@/lib/tenant';
import { generatedByFrom, reviewStatusFor, runAgent, type AiServiceContext } from '@/lib/ai/service';
import { blocksToText, type ProvenanceBlock } from '@/lib/ai/provenance';
import type { RunResult } from '@/lib/ai/orchestrator';
import type { ContentItemRow, ReviewStatus } from '@/lib/db/types';
import {
  ANSWER_INTENTS,
  DEFAULT_CONTROLS,
  LENGTH_PRESETS,
  TONES,
  SEARCH_INTENTS,
  buildContentBrief,
  checkContent,
  creativityToTemperature,
  isContentFormat,
  isLanguage,
  type ContentControls,
  type ContentIssue,
} from './types';

export interface ContentServiceContext extends AiServiceContext {}

/* -------------------------------------------------------------------------- */
/* Validation                                                                 */
/* -------------------------------------------------------------------------- */

export interface ControlsValidation {
  readonly ok: boolean;
  readonly controls?: ContentControls;
  readonly errors: Record<string, string>;
}

const MAX_TOPIC = 400;
const MAX_AUDIENCE = 200;
const MAX_CTA = 200;

function oneOf<T extends string>(values: readonly T[], raw: unknown): T | null {
  return typeof raw === 'string' && (values as readonly string[]).includes(raw) ? (raw as T) : null;
}

function text(raw: unknown, max: number): string {
  return typeof raw === 'string' ? raw.trim().slice(0, max) : '';
}

/**
 * Validates the studio controls.
 *
 * Unknown enum values are rejected rather than coerced to a default, because a
 * silently-substituted tone produces content the user did not ask for and
 * cannot tell apart from content they did.
 */
export function validateControls(input: Record<string, unknown>): ControlsValidation {
  const errors: Record<string, string> = {};

  const format = isContentFormat(input.format) ? input.format : null;
  if (!format) errors.format = 'Choose a content format.';

  const topic = text(input.topic, MAX_TOPIC);
  if (topic.length < 3) errors.topic = 'Describe the topic in at least a few words.';

  const language = input.language === undefined ? DEFAULT_CONTROLS.language : isLanguage(input.language) ? input.language : null;
  if (!language) errors.language = 'Choose a supported language.';

  const tone = input.tone === undefined ? DEFAULT_CONTROLS.tone : oneOf(TONES, input.tone);
  if (!tone) errors.tone = 'Choose a supported tone.';

  const length = input.length === undefined ? DEFAULT_CONTROLS.length : oneOf(LENGTH_PRESETS, input.length);
  if (!length) errors.length = 'Choose a length.';

  let creativity = DEFAULT_CONTROLS.creativity;
  if (input.creativity !== undefined) {
    const value = Number(input.creativity);
    if (!Number.isFinite(value) || value < 0 || value > 100) {
      errors.creativity = 'Creativity must be between 0 and 100.';
    } else {
      creativity = Math.round(value);
    }
  }

  let searchIntent: ContentControls['searchIntent'] = null;
  if (input.searchIntent !== undefined && input.searchIntent !== null) {
    searchIntent = oneOf(SEARCH_INTENTS, input.searchIntent);
    if (!searchIntent) errors.searchIntent = 'Choose a supported search intent.';
  }

  let answerIntent: ContentControls['answerIntent'] = null;
  if (input.answerIntent !== undefined && input.answerIntent !== null) {
    answerIntent = oneOf(ANSWER_INTENTS, input.answerIntent);
    if (!answerIntent) errors.answerIntent = 'Choose a supported answer intent.';
  }

  if (Object.keys(errors).length > 0 || !format || !language || !tone || !length) {
    return { ok: false, errors };
  }

  return {
    ok: true,
    errors: {},
    controls: {
      format,
      topic,
      language,
      tone,
      length,
      creativity,
      audience: text(input.audience, MAX_AUDIENCE),
      useBrandVoice: input.useBrandVoice === undefined ? DEFAULT_CONTROLS.useBrandVoice : input.useBrandVoice === true,
      callToAction: text(input.callToAction, MAX_CTA),
      searchIntent,
      answerIntent,
    },
  };
}

/* -------------------------------------------------------------------------- */
/* Generation                                                                 */
/* -------------------------------------------------------------------------- */

export interface GenerateContentInput {
  readonly projectId: string;
  readonly controls: ContentControls;
  /** When false, the result is returned but not persisted. */
  readonly save?: boolean;
}

export interface GenerateContentResult {
  readonly ok: boolean;
  readonly result: RunResult;
  readonly item: ContentItemRow | null;
  readonly issues: readonly ContentIssue[];
}

/** A title taken from the topic, never invented by the model. */
export function titleFor(controls: ContentControls): string {
  const topic = controls.topic.trim();
  const trimmed = topic.length > 80 ? `${topic.slice(0, 77).trimEnd()}…` : topic;
  return trimmed.length > 0 ? trimmed : 'Untitled';
}

export async function generateContent(
  context: ContentServiceContext,
  tenant: TenantContext,
  input: GenerateContentInput,
): Promise<GenerateContentResult> {
  requirePermission(tenant.role, 'content:create');

  // Checked BEFORE the provider is called. Refusing afterwards means we paid
  // for the generation and then declined to hand it over.
  // `AiServiceContext.now` returns epoch millis; the quota service takes a Date.
  await enforceOrThrow({ db: context.db, now: () => new Date(context.now?.() ?? Date.now()) }, tenant.organizationId, 'content_generations', {
    projectId: input.projectId,
    userId: tenant.userId,
  });

  const result = await runAgent(context, tenant, {
    agent: 'content',
    prompt: buildContentBrief(input.controls),
    projectId: input.projectId,
    temperature: creativityToTemperature(input.controls.creativity),
  });

  if (!result.ok) {
    return { ok: false, result, item: null, issues: [] };
  }

  const body = blocksToText(result.response.blocks);
  const issues = checkContent(body, input.controls);

  if (input.save === false) {
    return { ok: true, result, item: null, issues };
  }

  const item = await context.db.content.create({
    organizationId: tenant.organizationId,
    projectId: input.projectId,
    createdBy: tenant.userId,
    format: input.controls.format,
    title: titleFor(input.controls),
    body,
    language: input.controls.language,
    tone: input.controls.tone,
    audience: input.controls.audience || null,
    lengthPreset: input.controls.length,
    creativity: input.controls.creativity,
    callToAction: input.controls.callToAction || null,
    searchIntent: input.controls.searchIntent,
    answerIntent: input.controls.answerIntent,
    status: reviewStatusFor(result.response.warnings),
    blocks: result.response.blocks as readonly ProvenanceBlock[],
    claimWarnings: result.response.warnings,
    generatedBy: generatedByFrom(result.record),
  });

  // The `content_generations` limit is measured from `content_item`. Without
  // this record the limit was checked above but never consumed.
  await context.db.usage.record({
    organizationId: tenant.organizationId,
    projectId: input.projectId,
    metric: 'content_item',
    quantity: 1,
    periodStart: periodStartOf(new Date(context.now?.() ?? Date.now())),
  });

  return { ok: true, result, item, issues };
}

/* -------------------------------------------------------------------------- */
/* CRUD                                                                       */
/* -------------------------------------------------------------------------- */

export async function listContent(
  context: ContentServiceContext,
  tenant: TenantContext,
  projectId: string,
  limit?: number,
): Promise<ContentItemRow[]> {
  requirePermission(tenant.role, 'content:read');
  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  assertTenant(tenant, project, 'Project');
  return context.db.content.listForProject(tenant.organizationId, projectId, limit);
}

export async function getContent(
  context: ContentServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<ContentItemRow> {
  requirePermission(tenant.role, 'content:read');
  const item = await context.db.content.findById(tenant.organizationId, id);
  return assertTenant(tenant, item, 'Content item');
}

export interface ContentPatch {
  readonly title?: string;
  readonly body?: string;
  readonly status?: ReviewStatus;
}

/**
 * Updates an item.
 *
 * Editing the body clears the AI provenance blocks and marks the item as
 * human-edited: the stored provenance described the *generated* text, and
 * keeping it against text a person rewrote would be a false attribution.
 * Moving to `approved` needs the publish permission, not merely edit rights.
 */
export async function updateContent(
  context: ContentServiceContext,
  tenant: TenantContext,
  id: string,
  patch: ContentPatch,
): Promise<ContentItemRow> {
  requirePermission(tenant.role, 'content:create');

  const existing = assertTenant(
    tenant,
    await context.db.content.findById(tenant.organizationId, id),
    'Content item',
  );

  // Mutable while it is assembled; the row type itself stays readonly.
  const next: { -readonly [K in keyof ContentItemRow]?: ContentItemRow[K] } = {};

  if (patch.title !== undefined) next.title = patch.title.trim().slice(0, 200);

  if (patch.body !== undefined && patch.body !== existing.body) {
    next.body = patch.body;
    next.blocks = [];
    next.claimWarnings = [];
    next.generatedBy = { ...existing.generatedBy, humanEdited: true };
  }

  if (patch.status !== undefined && patch.status !== existing.status) {
    if (patch.status === 'approved') {
      requirePermission(tenant.role, 'content:publish');
      next.reviewedBy = tenant.userId;
      next.reviewedAt = new Date();
    }
    next.status = patch.status;
  }

  const updated = await context.db.content.update(tenant.organizationId, id, next);
  return assertTenant(tenant, updated, 'Content item');
}

export async function deleteContent(
  context: ContentServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<void> {
  requirePermission(tenant.role, 'content:create');
  assertTenant(tenant, await context.db.content.findById(tenant.organizationId, id), 'Content item');
  await context.db.content.softDelete(tenant.organizationId, id, new Date(context.now?.() ?? Date.now()));
}
