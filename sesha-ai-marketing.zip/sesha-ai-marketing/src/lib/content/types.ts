/**
 * Content Studio domain.
 *
 * The twenty formats from the Phase 3 brief, each with the constraints that
 * actually apply to it, plus the generation controls and the three supported
 * languages.
 *
 * WHY THE CONSTRAINTS LIVE HERE RATHER THAN IN A PROMPT: a character limit that
 * only exists as a sentence in a prompt is a suggestion. Here it is data, the
 * validator enforces it before generation and the linter checks the output
 * after, so an X post cannot come back at 400 characters and be saved.
 *
 * Framework-free and fully unit tested.
 */

export const CONTENT_FORMATS = [
  'blog',
  'article',
  'website-copy',
  'landing-page',
  'product-description',
  'social-post',
  'instagram-caption',
  'linkedin-post',
  'x-post',
  'youtube-script',
  'reels-script',
  'shorts-script',
  'ad-copy',
  'email',
  'newsletter',
  'whatsapp',
  'sms',
  'faq',
  'how-to',
  'comparison',
] as const;

export type ContentFormat = (typeof CONTENT_FORMATS)[number];

export interface FormatSpec {
  readonly id: ContentFormat;
  readonly label: string;
  readonly group: 'long-form' | 'web' | 'social' | 'video' | 'messaging' | 'advertising' | 'support';
  readonly description: string;
  /** Hard ceiling where the destination enforces one. */
  readonly maxCharacters?: number;
  /** Target word count for the default length preset. */
  readonly defaultWords: number;
  /** Whether search intent is a meaningful control for this format. */
  readonly supportsSearchIntent: boolean;
  /** Whether answer intent (AEO) is a meaningful control. */
  readonly supportsAnswerIntent: boolean;
  readonly supportsHashtags: boolean;
  /** Structural guidance handed to the content agent. */
  readonly structure: string;
}

export const FORMAT_SPECS: Record<ContentFormat, FormatSpec> = {
  blog: {
    id: 'blog', label: 'Blog post', group: 'long-form',
    description: 'A structured piece for your own site, written to be found and read.',
    defaultWords: 900, supportsSearchIntent: true, supportsAnswerIntent: true, supportsHashtags: false,
    structure: 'A direct answer in the first paragraph, then H2 sections, then a short conclusion. No preamble before the answer.',
  },
  article: {
    id: 'article', label: 'Article', group: 'long-form',
    description: 'A longer editorial piece, typically for a publication or resource hub.',
    defaultWords: 1400, supportsSearchIntent: true, supportsAnswerIntent: true, supportsHashtags: false,
    structure: 'An argument with a clear thesis, supporting sections and a conclusion that does not merely restate.',
  },
  'website-copy': {
    id: 'website-copy', label: 'Website copy', group: 'web',
    description: 'Copy for a page on your site: about, services, a section block.',
    defaultWords: 400, supportsSearchIntent: true, supportsAnswerIntent: false, supportsHashtags: false,
    structure: 'A heading, a supporting sentence, then scannable sections. Short paragraphs.',
  },
  'landing-page': {
    id: 'landing-page', label: 'Landing page', group: 'web',
    description: 'A single-purpose page built around one conversion.',
    defaultWords: 500, supportsSearchIntent: true, supportsAnswerIntent: false, supportsHashtags: false,
    structure: 'Headline, sub-headline, the problem, what you offer, what is included, objections answered, one call to action repeated.',
  },
  'product-description': {
    id: 'product-description', label: 'Product description', group: 'web',
    description: 'Copy for a single product or service.',
    defaultWords: 180, supportsSearchIntent: true, supportsAnswerIntent: false, supportsHashtags: false,
    structure: 'What it is, who it is for, what is distinctive, then specifics. Never invent a specification.',
  },
  'social-post': {
    id: 'social-post', label: 'Social post (generic)', group: 'social',
    description: 'A platform-neutral post you can adapt.',
    maxCharacters: 1200, defaultWords: 90, supportsSearchIntent: false, supportsAnswerIntent: false, supportsHashtags: true,
    structure: 'One idea. A hook in the first line, then the point, then a call to action.',
  },
  'instagram-caption': {
    id: 'instagram-caption', label: 'Instagram caption', group: 'social',
    description: 'A caption for a feed post or carousel.',
    maxCharacters: 2200, defaultWords: 80, supportsSearchIntent: false, supportsAnswerIntent: false, supportsHashtags: true,
    structure: 'A hook that survives the "more" truncation at roughly 125 characters, then the body, then hashtags on their own line.',
  },
  'linkedin-post': {
    id: 'linkedin-post', label: 'LinkedIn post', group: 'social',
    description: 'A professional-audience post.',
    maxCharacters: 3000, defaultWords: 150, supportsSearchIntent: false, supportsAnswerIntent: false, supportsHashtags: true,
    structure: 'A specific opening line, short paragraphs with line breaks, a concrete point. No engagement bait.',
  },
  'x-post': {
    id: 'x-post', label: 'X post', group: 'social',
    description: 'A single short post.',
    maxCharacters: 280, defaultWords: 35, supportsSearchIntent: false, supportsAnswerIntent: false, supportsHashtags: true,
    structure: 'One complete thought within the limit. At most two hashtags.',
  },
  'youtube-script': {
    id: 'youtube-script', label: 'YouTube script', group: 'video',
    description: 'A script for a long-form video.',
    defaultWords: 800, supportsSearchIntent: true, supportsAnswerIntent: false, supportsHashtags: false,
    structure: 'A hook in the first fifteen seconds, then sections with spoken cues. Mark [VISUAL] where a shot is needed.',
  },
  'reels-script': {
    id: 'reels-script', label: 'Reels script', group: 'video',
    description: 'A short vertical video script, roughly 30 to 60 seconds.',
    defaultWords: 130, supportsSearchIntent: false, supportsAnswerIntent: false, supportsHashtags: true,
    structure: 'A hook in the first three seconds. Timestamped beats. On-screen text marked [TEXT].',
  },
  'shorts-script': {
    id: 'shorts-script', label: 'Shorts script', group: 'video',
    description: 'A very short vertical video script, under 60 seconds.',
    defaultWords: 110, supportsSearchIntent: false, supportsAnswerIntent: false, supportsHashtags: true,
    structure: 'One idea, one payoff. A hook in the first two seconds, then beats, then the call to action.',
  },
  'ad-copy': {
    id: 'ad-copy', label: 'Ad copy', group: 'advertising',
    description: 'Headline and body variants for a paid placement.',
    maxCharacters: 900, defaultWords: 70, supportsSearchIntent: true, supportsAnswerIntent: false, supportsHashtags: false,
    structure: 'Three headline options and two body options, each a distinct angle rather than a reworded version.',
  },
  email: {
    id: 'email', label: 'Email', group: 'messaging',
    description: 'A one-to-one or campaign email.',
    defaultWords: 200, supportsSearchIntent: false, supportsAnswerIntent: false, supportsHashtags: false,
    structure: 'A subject line, a preview line, then the body. One ask. Say why you are writing in the first sentence.',
  },
  newsletter: {
    id: 'newsletter', label: 'Newsletter', group: 'messaging',
    description: 'A recurring email to a subscribed list.',
    defaultWords: 450, supportsSearchIntent: false, supportsAnswerIntent: false, supportsHashtags: false,
    structure: 'A subject line, a short intro, two or three sections, a single closing action.',
  },
  whatsapp: {
    id: 'whatsapp', label: 'WhatsApp message', group: 'messaging',
    description: 'A short message for WhatsApp Business.',
    maxCharacters: 1024, defaultWords: 60, supportsSearchIntent: false, supportsAnswerIntent: false, supportsHashtags: false,
    structure: 'Conversational, short lines. Identify the business in the first line. One clear action.',
  },
  sms: {
    id: 'sms', label: 'SMS', group: 'messaging',
    description: 'A text message.',
    maxCharacters: 320, defaultWords: 30, supportsSearchIntent: false, supportsAnswerIntent: false, supportsHashtags: false,
    structure: 'Under two segments. Business name, the point, one link or action. Include opt-out wording where required.',
  },
  faq: {
    id: 'faq', label: 'FAQ', group: 'support',
    description: 'Questions and answers, structured for answer engines.',
    defaultWords: 500, supportsSearchIntent: true, supportsAnswerIntent: true, supportsHashtags: false,
    structure: 'Each answer opens with a complete, quotable sentence that makes sense with no surrounding context, then supporting detail.',
  },
  'how-to': {
    id: 'how-to', label: 'How-to guide', group: 'support',
    description: 'Step-by-step instructions.',
    defaultWords: 700, supportsSearchIntent: true, supportsAnswerIntent: true, supportsHashtags: false,
    structure: 'What the reader will achieve, what they need, then numbered steps each with one action.',
  },
  comparison: {
    id: 'comparison', label: 'Comparison', group: 'support',
    description: 'A structured comparison between options.',
    defaultWords: 800, supportsSearchIntent: true, supportsAnswerIntent: true, supportsHashtags: false,
    structure: 'State the criteria first, then compare against them, then say who each option suits. Never invent a competitor fact.',
  },
};

export function isContentFormat(value: unknown): value is ContentFormat {
  return typeof value === 'string' && (CONTENT_FORMATS as readonly string[]).includes(value);
}

/* -------------------------------------------------------------------------- */
/* Languages                                                                  */
/* -------------------------------------------------------------------------- */

export const LANGUAGES = ['en', 'hi', 'hinglish'] as const;
export type Language = (typeof LANGUAGES)[number];

export interface LanguageSpec {
  readonly id: Language;
  readonly label: string;
  readonly nativeLabel: string;
  readonly script: 'latin' | 'devanagari' | 'latin-mixed';
  /**
   * Written for the MODEL: long, prescriptive, and not suitable for a screen.
   */
  readonly instruction: string;
  /**
   * Written for the PERSON choosing, one line, shown under the language field.
   *
   * Added after the Content Studio was found rendering `LANGUAGE_SPECS[…].note`
   * on a type that had no such property — so the hint had been silently empty
   * since Phase 3. `.tsx` was not type-checked, so nothing said a word.
   * Rendering `instruction` instead would have been the wrong repair: it is
   * addressed to the model, in the imperative, and none of it is news to the
   * person who just picked the language.
   */
  readonly note: string;
}

export const LANGUAGE_SPECS: Record<Language, LanguageSpec> = {
  en: {
    id: 'en', label: 'English', nativeLabel: 'English', script: 'latin',
    note: 'Indian English conventions — lakh and crore, DD/MM dates.',
    instruction: 'Write in English. Use Indian English conventions where the audience is Indian (lakh, crore, DD/MM dates) unless the context indicates otherwise.',
  },
  hi: {
    id: 'hi', label: 'Hindi', nativeLabel: 'हिन्दी', script: 'devanagari',
    note: 'Devanagari script. Everyday Hindi, not literary — common English words stay in English.',
    instruction: 'Write in Hindi, in Devanagari script. Use natural contemporary Hindi, not literary Sanskritised Hindi. Keep widely used English loanwords (website, online, offer) rather than forcing uncommon translations.',
  },
  hinglish: {
    id: 'hinglish', label: 'Hinglish', nativeLabel: 'Hinglish', script: 'latin-mixed',
    note: 'Roman script, Hindi and English mixed the way people write online.',
    instruction: 'Write in Hinglish: Hindi and English code-mixed, in Roman script, as urban Indian audiences actually write online. Hindi grammar with English nouns and verbs is normal ("aapka business grow karne ke liye"). Do NOT write English sentences with a few Hindi words dropped in, and do not use Devanagari.',
  },
};

export function isLanguage(value: unknown): value is Language {
  return typeof value === 'string' && (LANGUAGES as readonly string[]).includes(value);
}

/* -------------------------------------------------------------------------- */
/* Controls                                                                   */
/* -------------------------------------------------------------------------- */

export const TONES = [
  'professional', 'friendly', 'authoritative', 'playful',
  'technical', 'empathetic', 'direct', 'inspirational',
] as const;
export type Tone = (typeof TONES)[number];

export const LENGTH_PRESETS = ['short', 'standard', 'long'] as const;
export type LengthPreset = (typeof LENGTH_PRESETS)[number];

/** Multipliers applied to a format's default word count. */
export const LENGTH_MULTIPLIERS: Record<LengthPreset, number> = {
  short: 0.5,
  standard: 1,
  long: 1.8,
};

export const SEARCH_INTENTS = ['informational', 'commercial', 'transactional', 'navigational'] as const;
export type SearchIntent = (typeof SEARCH_INTENTS)[number];

export const ANSWER_INTENTS = ['definition', 'comparison', 'how-to', 'evaluation', 'none'] as const;
export type AnswerIntent = (typeof ANSWER_INTENTS)[number];

export interface ContentControls {
  readonly format: ContentFormat;
  readonly language: Language;
  readonly tone: Tone;
  readonly audience: string;
  readonly length: LengthPreset;
  /** 0–100. Mapped to provider temperature by `creativityToTemperature`. */
  readonly creativity: number;
  readonly useBrandVoice: boolean;
  readonly callToAction: string;
  readonly searchIntent: SearchIntent | null;
  readonly answerIntent: AnswerIntent | null;
  readonly topic: string;
}

export const DEFAULT_CONTROLS: Omit<ContentControls, 'format' | 'topic'> = {
  language: 'en',
  tone: 'professional',
  audience: '',
  length: 'standard',
  creativity: 50,
  useBrandVoice: true,
  callToAction: '',
  searchIntent: null,
  answerIntent: null,
};

/**
 * Maps the 0–100 creativity slider to a provider temperature.
 *
 * Capped at 0.9 rather than 1.0: above that, output quality degrades faster
 * than it gets more interesting, and hallucination rates rise — which matters
 * more here than usual, because fabrication is the failure mode we care about.
 */
export function creativityToTemperature(creativity: number): number {
  const clamped = Math.max(0, Math.min(100, creativity));
  return Math.round((clamped / 100) * 0.9 * 100) / 100;
}

export function targetWordCount(format: ContentFormat, length: LengthPreset): number {
  return Math.round(FORMAT_SPECS[format].defaultWords * LENGTH_MULTIPLIERS[length]);
}

/* -------------------------------------------------------------------------- */
/* Prompt construction                                                        */
/* -------------------------------------------------------------------------- */

/** Turns the controls into the instruction the content agent receives. */
export function buildContentBrief(controls: ContentControls): string {
  const spec = FORMAT_SPECS[controls.format];
  const words = targetWordCount(controls.format, controls.length);

  const lines: string[] = [
    `FORMAT: ${spec.label}`,
    `STRUCTURE: ${spec.structure}`,
    `TOPIC: ${controls.topic}`,
    `LANGUAGE: ${LANGUAGE_SPECS[controls.language].instruction}`,
    `TONE: ${controls.tone}`,
    `TARGET LENGTH: about ${words} words.`,
  ];

  if (spec.maxCharacters) {
    lines.push(
      `HARD LIMIT: ${spec.maxCharacters} characters. This is enforced after generation — exceed it and the draft is rejected.`,
    );
  }
  if (controls.audience.trim()) {
    lines.push(`AUDIENCE: ${controls.audience.trim()}`);
  } else {
    lines.push('AUDIENCE: use the target audience from the workspace context.');
  }
  lines.push(
    controls.useBrandVoice
      ? 'BRAND VOICE: apply the brand voice from the workspace context. If none is given, say so and use a plain professional register.'
      : 'BRAND VOICE: not applied for this piece. Use a neutral professional register.',
  );
  if (controls.callToAction.trim()) {
    lines.push(`CALL TO ACTION: end with this action — ${controls.callToAction.trim()}`);
  }
  if (spec.supportsSearchIntent && controls.searchIntent) {
    lines.push(`SEARCH INTENT: ${controls.searchIntent}. Match what someone with this intent needs.`);
  }
  if (spec.supportsAnswerIntent && controls.answerIntent && controls.answerIntent !== 'none') {
    lines.push(
      `ANSWER INTENT: ${controls.answerIntent}. Open with a self-contained sentence that answers it and survives being quoted alone.`,
    );
  }
  if (spec.supportsHashtags) {
    lines.push('HASHTAGS: include relevant hashtags at the end. Do not invent a branded hashtag.');
  }

  return lines.join('\n');
}

/* -------------------------------------------------------------------------- */
/* Output checks                                                              */
/* -------------------------------------------------------------------------- */

export interface ContentIssue {
  readonly severity: 'error' | 'warning';
  readonly field: string;
  readonly message: string;
}

/**
 * Checks generated content against the constraints that were requested.
 *
 * This runs AFTER generation, because a prompt cannot guarantee a character
 * count. An X post over 280 characters is an ERROR — it is unusable — while a
 * word count that missed the target is a warning.
 */
export function checkContent(body: string, controls: ContentControls): ContentIssue[] {
  const issues: ContentIssue[] = [];
  const spec = FORMAT_SPECS[controls.format];
  const text = body.trim();

  if (text.length === 0) {
    return [{ severity: 'error', field: 'body', message: 'The draft is empty.' }];
  }

  if (spec.maxCharacters && text.length > spec.maxCharacters) {
    issues.push({
      severity: 'error',
      field: 'body',
      message: `${text.length} characters exceeds the ${spec.maxCharacters}-character limit for ${spec.label}.`,
    });
  }

  const words = text.split(/\s+/).filter(Boolean).length;
  const target = targetWordCount(controls.format, controls.length);
  if (words < target * 0.5) {
    issues.push({
      severity: 'warning',
      field: 'length',
      message: `${words} words is well short of the ~${target} requested.`,
    });
  } else if (words > target * 2) {
    issues.push({
      severity: 'warning',
      field: 'length',
      message: `${words} words is well over the ~${target} requested.`,
    });
  }

  // Script check: the surest sign the language control was ignored.
  const devanagari = (text.match(/[ऀ-ॿ]/g) ?? []).length;
  const ratio = devanagari / text.length;

  if (controls.language === 'hi' && ratio < 0.2) {
    issues.push({
      severity: 'error',
      field: 'language',
      message: 'Hindi was requested but the draft is not in Devanagari script.',
    });
  }
  if (controls.language === 'hinglish' && devanagari > 0) {
    issues.push({
      severity: 'error',
      field: 'language',
      message: 'Hinglish must be in Roman script, but the draft contains Devanagari.',
    });
  }
  if (controls.language === 'en' && ratio > 0.05) {
    issues.push({
      severity: 'error',
      field: 'language',
      message: 'English was requested but the draft contains Devanagari script.',
    });
  }

  // Unfilled placeholders are fine — they are honest — but the user must see them.
  const placeholders = text.match(/\[[A-Z][A-Za-z \-_]{2,40}\]/g);
  if (placeholders && placeholders.length > 0) {
    issues.push({
      severity: 'warning',
      field: 'body',
      message: `Contains ${placeholders.length} placeholder(s) to fill in: ${[...new Set(placeholders)].slice(0, 5).join(', ')}`,
    });
  }

  return issues;
}
