/**
 * Reliability primitives: timeouts, retries, circuit breakers, idempotency.
 *
 * THE ORGANISING IDEA: every one of these can make things WORSE if applied
 * carelessly, and the careless version is usually the shorter one. So each has a
 * rule about when it must not be used, and each enforces that rule rather than
 * documenting it.
 *
 *  · A RETRY on a non-idempotent operation duplicates it. `retry()` therefore
 *    takes an explicit `idempotent` flag and refuses to retry without it — you
 *    cannot get retries by forgetting to think about it.
 *  · A RETRY WITHOUT JITTER turns one downstream blip into a synchronised
 *    stampede from every instance at once. Jitter is not an option here.
 *  · A RETRY ON A 4xx is pointless load: the request was wrong and will stay
 *    wrong. Only failures classified as transient are retried.
 *  · A CIRCUIT BREAKER on something with no fallback just converts a slow
 *    failure into a fast one. That is still worth having for a shared
 *    dependency, and worthless for a per-user one — so breakers are named and
 *    scoped deliberately, not wrapped around everything.
 *  · A TIMEOUT that leaves the work running underneath is a memory leak with
 *    good manners. `withTimeout` takes an `AbortSignal` so the work can actually
 *    stop, and says plainly in its type that the caller must honour it.
 */

/* -------------------------------------------------------------------------- */
/* Timeouts                                                                   */
/* -------------------------------------------------------------------------- */

export class TimeoutError extends Error {
  readonly code = 'ETIMEDOUT' as const;
  constructor(readonly ms: number, label?: string) {
    super(`${label ?? 'Operation'} exceeded its ${ms}ms budget.`);
    this.name = 'TimeoutError';
  }
}

/**
 * Runs `fn` with a deadline.
 *
 * `fn` RECEIVES AN ABORT SIGNAL AND IS EXPECTED TO HONOUR IT. Without that, a
 * timeout only stops the caller waiting — the work continues, holding its
 * connection and its memory, and a service under load ends up with more
 * abandoned work in flight than live work. The signal is a required parameter
 * rather than an option so the obligation is visible at every call site.
 */
export async function withTimeout<T>(
  ms: number,
  fn: (signal: AbortSignal) => Promise<T>,
  label?: string,
): Promise<T> {
  const controller = new AbortController();
  let timer: ReturnType<typeof setTimeout> | undefined;

  const deadline = new Promise<never>((_resolve, reject) => {
    timer = setTimeout(() => {
      controller.abort();
      reject(new TimeoutError(ms, label));
    }, ms);
    timer.unref?.();
  });

  try {
    return await Promise.race([fn(controller.signal), deadline]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

/* -------------------------------------------------------------------------- */
/* Retries                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Which failures are worth trying again.
 *
 * A NARROW LIST ON PURPOSE. The default for an unrecognised error is NOT to
 * retry: retrying something we do not understand doubles the load for no reason
 * we can name, and the failure mode of getting this wrong is a retry storm
 * against a service that is already struggling.
 */
export const TRANSIENT_CODES: readonly string[] = [
  'ETIMEDOUT',
  'ECONNRESET',
  'ECONNREFUSED',
  'EPIPE',
  'EAI_AGAIN',
  'ENOTFOUND',
  'EHOSTUNREACH',
  'ENETUNREACH',
  'ERR_SOCKET_CONNECTION_TIMEOUT',
];

/** HTTP statuses worth another go. 429 and the 5xx family, and nothing else. */
export function isRetryableStatus(status: number): boolean {
  if (status === 429) return true;
  // 501 Not Implemented will never start working; 505 likewise.
  if (status === 501 || status === 505) return false;
  return status >= 500 && status < 600;
}

export function isTransient(error: unknown): boolean {
  if (error instanceof TimeoutError) return true;
  if (typeof error === 'object' && error !== null) {
    const code = (error as { code?: unknown }).code;
    if (typeof code === 'string' && TRANSIENT_CODES.includes(code)) return true;
    const status = (error as { status?: unknown }).status;
    if (typeof status === 'number' && isRetryableStatus(status)) return true;
  }
  return false;
}

export interface RetryOptions {
  /**
   * REQUIRED, and there is no default.
   *
   * Retrying a non-idempotent operation duplicates it — a second charge, a
   * second email, a second row. Making the caller state this every time is the
   * point: it cannot be acquired by omission.
   */
  readonly idempotent: true;
  readonly attempts?: number;
  readonly baseDelayMs?: number;
  readonly maxDelayMs?: number;
  /** Injected in tests. Real callers leave it alone. */
  readonly sleep?: (ms: number) => Promise<void>;
  readonly random?: () => number;
  readonly onRetry?: (info: { attempt: number; delayMs: number; error: unknown }) => void;
  readonly isRetryable?: (error: unknown) => boolean;
}

export const DEFAULT_ATTEMPTS = 3;
export const DEFAULT_BASE_DELAY_MS = 200;
export const DEFAULT_MAX_DELAY_MS = 5_000;

/**
 * Exponential backoff with FULL JITTER.
 *
 * Full jitter — a uniform pick between 0 and the computed ceiling — rather than
 * the ceiling itself, or the ceiling plus a small wobble. When a dependency
 * returns, every waiting client retries at once; without jitter they all arrive
 * in the same millisecond and knock it over again. Full jitter spreads them
 * across the whole window, and is the variant AWS measured as best for exactly
 * this.
 */
export function backoffDelay(
  attempt: number,
  options: { baseDelayMs?: number; maxDelayMs?: number; random?: () => number } = {},
): number {
  const base = options.baseDelayMs ?? DEFAULT_BASE_DELAY_MS;
  const max = options.maxDelayMs ?? DEFAULT_MAX_DELAY_MS;
  const random = options.random ?? Math.random;
  const ceiling = Math.min(max, base * 2 ** Math.max(0, attempt - 1));
  return Math.floor(random() * ceiling);
}

export async function retry<T>(fn: () => Promise<T>, options: RetryOptions): Promise<T> {
  const attempts = Math.max(1, options.attempts ?? DEFAULT_ATTEMPTS);
  const retryable = options.isRetryable ?? isTransient;
  const sleep = options.sleep ?? ((ms: number) => new Promise((resolve) => setTimeout(resolve, ms)));

  let lastError: unknown;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      // The last attempt does not sleep before giving up, and a permanent
      // failure is not slept on at all.
      if (attempt === attempts || !retryable(error)) throw error;
      const delayMs = backoffDelay(attempt, options);
      options.onRetry?.({ attempt, delayMs, error });
      await sleep(delayMs);
    }
  }
  throw lastError;
}

/* -------------------------------------------------------------------------- */
/* Circuit breaker                                                            */
/* -------------------------------------------------------------------------- */

export const BREAKER_STATES = ['closed', 'open', 'half_open'] as const;
export type BreakerState = (typeof BREAKER_STATES)[number];

export class CircuitOpenError extends Error {
  readonly code = 'ECIRCUITOPEN' as const;
  constructor(
    readonly breaker: string,
    readonly retryAfterMs: number,
  ) {
    super(`${breaker} is unavailable. Not retried for another ${Math.ceil(retryAfterMs / 1000)}s.`);
    this.name = 'CircuitOpenError';
  }
}

export interface BreakerOptions {
  readonly failureThreshold?: number;
  readonly resetAfterMs?: number;
  /** Successes needed in half-open before closing again. */
  readonly successThreshold?: number;
  readonly now?: () => number;
  readonly onStateChange?: (from: BreakerState, to: BreakerState) => void;
  /**
   * Which errors count against the dependency. Defaults to all. An AI provider
   * refusing one prompt's content is not an outage, and must not open the
   * breaker for every other customer.
   */
  readonly isFailure?: (error: unknown) => boolean;
}

/**
 * A circuit breaker.
 *
 * WHEN TO USE ONE: a SHARED dependency whose failure would otherwise make every
 * request slow rather than fast — an AI provider, a payment provider, an SMTP
 * server. The value is not that it fixes anything; it is that a hundred callers
 * waiting fifteen seconds each for the same dead service is worse than a hundred
 * callers being told immediately.
 *
 * WHEN NOT TO USE ONE: anything per-user or per-tenant. One customer's bad URL
 * must never open a breaker that another customer's crawl then trips over, and a
 * breaker keyed per user is just a slower map.
 *
 * HALF-OPEN LETS EXACTLY ONE REQUEST THROUGH. Letting several through is how a
 * recovering service gets knocked over by the probe.
 */
export class CircuitBreaker {
  private state: BreakerState = 'closed';
  private failures = 0;
  private successes = 0;
  private openedAt = 0;
  private probeInFlight = false;

  constructor(
    readonly name: string,
    private readonly options: BreakerOptions = {},
  ) {}

  private get now(): number {
    return (this.options.now ?? Date.now)();
  }

  private transition(to: BreakerState): void {
    if (this.state === to) return;
    const from = this.state;
    this.state = to;
    this.options.onStateChange?.(from, to);
  }

  currentState(): BreakerState {
    // Reading the state also advances it out of `open` when the window is up,
    // so a caller polling the state sees the same thing `run()` would do.
    if (this.state === 'open' && this.now - this.openedAt >= (this.options.resetAfterMs ?? 30_000)) {
      this.transition('half_open');
      this.successes = 0;
      this.probeInFlight = false;
    }
    return this.state;
  }

  async run<T>(fn: () => Promise<T>): Promise<T> {
    const state = this.currentState();

    if (state === 'open') {
      const retryAfterMs = (this.options.resetAfterMs ?? 30_000) - (this.now - this.openedAt);
      throw new CircuitOpenError(this.name, Math.max(0, retryAfterMs));
    }

    if (state === 'half_open') {
      if (this.probeInFlight) {
        // Someone else is already testing the water.
        throw new CircuitOpenError(this.name, 0);
      }
      this.probeInFlight = true;
    }

    try {
      const result = await fn();
      this.recordSuccess();
      return result;
    } catch (error) {
      if (this.options.isFailure?.(error) ?? true) this.recordFailure();
      throw error;
    } finally {
      if (this.state === 'half_open') this.probeInFlight = false;
    }
  }

  private recordSuccess(): void {
    if (this.state === 'half_open') {
      this.successes += 1;
      if (this.successes >= (this.options.successThreshold ?? 1)) {
        this.transition('closed');
        this.failures = 0;
        this.successes = 0;
      }
      return;
    }
    // A success in the closed state clears the count. Failures have to be
    // consecutive to open the breaker; a steady trickle of unrelated errors
    // among mostly-successful traffic is not an outage.
    this.failures = 0;
  }

  private recordFailure(): void {
    if (this.state === 'half_open') {
      // The probe failed: straight back to open, with a fresh window.
      this.openedAt = this.now;
      this.transition('open');
      this.successes = 0;
      return;
    }
    this.failures += 1;
    if (this.failures >= (this.options.failureThreshold ?? 5)) {
      this.openedAt = this.now;
      this.transition('open');
    }
  }

  /** For the admin panel and for tests. */
  report(): { state: BreakerState; failures: number } {
    return { state: this.currentState(), failures: this.failures };
  }
}

/* -------------------------------------------------------------------------- */
/* Idempotency                                                                */
/* -------------------------------------------------------------------------- */

export interface IdempotencyRecord<T> {
  readonly key: string;
  readonly result: T;
  readonly storedAt: number;
}

/**
 * Runs an operation at most once per key.
 *
 * THE CONCURRENT CASE IS THE WHOLE POINT. A naive "have I seen this key"
 * check-then-act still runs the operation twice when two requests arrive
 * together, which is precisely when a double-submit happens. So the in-flight
 * PROMISE is stored, not just the finished result, and the second caller awaits
 * the first one's work rather than starting its own.
 *
 * A FAILED OPERATION IS NOT CACHED. Remembering a failure would mean a transient
 * error becomes permanent for that key, and the caller's natural response —
 * retry with the same key — would be defeated by the very mechanism meant to
 * make retrying safe.
 */
export class IdempotencyStore<T> {
  private readonly settled = new Map<string, IdempotencyRecord<T>>();
  private readonly inFlight = new Map<string, Promise<T>>();

  constructor(
    private readonly ttlMs = 24 * 60 * 60 * 1000,
    private readonly now: () => number = Date.now,
  ) {}

  async once(key: string, fn: () => Promise<T>): Promise<{ result: T; replayed: boolean }> {
    const existing = this.settled.get(key);
    if (existing && this.now() - existing.storedAt < this.ttlMs) {
      return { result: existing.result, replayed: true };
    }
    if (existing) this.settled.delete(key);

    const running = this.inFlight.get(key);
    if (running) return { result: await running, replayed: true };

    const promise = fn();
    this.inFlight.set(key, promise);
    try {
      const result = await promise;
      this.settled.set(key, { key, result, storedAt: this.now() });
      return { result, replayed: false };
    } finally {
      // Always cleared: a failure must leave the key free to try again.
      this.inFlight.delete(key);
    }
  }

  forget(key: string): void {
    this.settled.delete(key);
    this.inFlight.delete(key);
  }

  get size(): number {
    return this.settled.size;
  }
}

/* -------------------------------------------------------------------------- */
/* Graceful degradation                                                       */
/* -------------------------------------------------------------------------- */

export interface Degraded<T> {
  readonly ok: false;
  readonly reason: string;
  readonly fallback: T;
}

export type Attempted<T> = { readonly ok: true; readonly value: T } | Degraded<T>;

/**
 * Runs something optional, and returns a stated fallback if it fails.
 *
 * FOR THINGS THE PAGE CAN DO WITHOUT. A dashboard that returns 500 because one
 * secondary panel could not load is a worse product than one that renders and
 * says that panel is unavailable — which is the same principle as Phase 6's
 * "no connected data available" rather than a fabricated zero.
 *
 * It returns a DISCRIMINATED RESULT rather than silently substituting, so the
 * caller has to decide what to show and cannot accidentally present a fallback
 * as though it were real. That is the same technique as `MetricValue`.
 */
export async function attempt<T>(
  fn: () => Promise<T>,
  fallback: T,
  describe: (error: unknown) => string = () => 'This part could not be loaded.',
): Promise<Attempted<T>> {
  try {
    return { ok: true, value: await fn() };
  } catch (error) {
    return { ok: false, reason: describe(error), fallback };
  }
}
