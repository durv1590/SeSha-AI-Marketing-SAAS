/**
 * Computing the metrics SeSha genuinely has.
 *
 * Every function here returns a `calculated` value carrying its FORMULA and its
 * INPUTS, so a user who distrusts a number can check the arithmetic rather than
 * taking it on faith. That is the whole difference between this and an analytics
 * dashboard that shows 43% and expects to be believed.
 *
 * WHAT IS NOT HERE
 * There is no function that produces a traffic, impression, click or follower
 * figure, because SeSha cannot know one. The absence is the feature: a helper
 * called `estimateTraffic` would be used within a week.
 *
 * Pure functions over plain inputs. No database access, no clock of their own.
 *
 * Framework-free and fully unit tested.
 */

import {
  METRICS,
  unavailable,
  type CalculationInput,
  type MetricUnit,
  type MetricValue,
} from './metrics';
import { whyUnavailable } from './connections';
import type { RequiredSource } from './metrics';

function calculated(
  value: number,
  unit: MetricUnit,
  formula: string,
  inputs: readonly CalculationInput[],
  asOf: string,
): MetricValue {
  return { kind: 'calculated', value, unit, formula, inputs, asOf };
}

/* -------------------------------------------------------------------------- */
/* Pipeline                                                                   */
/* -------------------------------------------------------------------------- */

export interface LeadFacts {
  readonly total: number;
  readonly won: number;
  readonly lost: number;
  readonly open: number;
  readonly inPeriod: number;
  readonly asOf: string;
}

export function leadsMetric(facts: LeadFacts): MetricValue {
  return calculated(
    facts.inPeriod,
    'count',
    'Leads created inside the period, counted from your own pipeline.',
    [{ label: 'Leads in period', value: facts.inPeriod }, { label: 'Leads in total', value: facts.total }],
    facts.asOf,
  );
}

/**
 * Pipeline conversion.
 *
 * DELIBERATELY NOT CALLED "conversion rate" without qualification. A website
 * conversion rate is visitors who converted, and SeSha cannot see visitors.
 * This is won ÷ closed, from the customer's own pipeline, and the formula says so
 * — so nobody reads it as the other thing.
 *
 * Unavailable rather than zero when nothing has closed: 0% would say "you convert
 * nobody", which is a different and false claim from "nothing has closed yet".
 */
export function conversionMetric(facts: LeadFacts): MetricValue {
  const closed = facts.won + facts.lost;
  if (closed === 0) {
    return {
      kind: 'unavailable',
      label: 'Nothing closed yet',
      why:
        'No lead has been marked Won or Lost, so there is no conversion to calculate. Showing 0% would claim you convert nobody, which is a different thing from having no closed deals.',
      whatWouldMakeItAvailable: 'Mark a lead Won or Lost and this appears.',
    };
  }
  return calculated(
    (facts.won / closed) * 100,
    'percent',
    'Leads marked Won ÷ leads marked Won or Lost. Open leads are excluded, because a deal still in progress has not converted or failed to.',
    [
      { label: 'Won', value: facts.won },
      { label: 'Lost', value: facts.lost },
      { label: 'Still open (excluded)', value: facts.open },
    ],
    facts.asOf,
  );
}

/* -------------------------------------------------------------------------- */
/* Technical                                                                  */
/* -------------------------------------------------------------------------- */

export interface AuditFacts {
  readonly score: number;
  readonly basis: string;
  readonly findingCount: number;
  readonly checkedAt: string;
}

/**
 * The SEO or AEO score.
 *
 * The score's own basis — "SeSha's own weighting, not a Google measurement" —
 * is carried into the formula, so the sentence travels with the number onto the
 * analytics screen as well as the audit screen.
 */
export function auditScoreMetric(facts: AuditFacts | null, kind: 'seo' | 'aeo'): MetricValue {
  if (!facts) {
    return {
      kind: 'unavailable',
      label: 'No audit yet',
      why: `No ${kind.toUpperCase()} audit has been run for this project, so there is no score.`,
      whatWouldMakeItAvailable: 'Run a crawl, then the audit, from Website Audit.',
    };
  }
  return calculated(
    facts.score,
    'score',
    facts.basis,
    [{ label: 'Findings weighed', value: facts.findingCount }],
    facts.checkedAt,
  );
}

export interface ValidationFacts {
  readonly invalid: number;
  readonly warnings: number;
  readonly checkedAt: string;
  readonly validatorVersion: string;
}

export function schemaIssuesMetric(facts: ValidationFacts | null): MetricValue {
  if (!facts) {
    return {
      kind: 'unavailable',
      label: 'Nothing validated yet',
      why: 'No structured data has been validated for this project.',
      whatWouldMakeItAvailable: 'Check a page or paste your markup in Schema Validator.',
    };
  }
  return calculated(
    facts.invalid,
    'count',
    `Findings with status INVALID in your most recent validation (validator ${facts.validatorVersion}). Warnings and recommendations are counted separately and are not errors.`,
    [
      { label: 'Invalid', value: facts.invalid },
      { label: 'Warnings (not counted here)', value: facts.warnings },
    ],
    facts.checkedAt,
  );
}

export interface CrawlFacts {
  readonly pagesCrawled: number;
  readonly pagesFailed: number;
  readonly finishedAt: string;
  readonly stoppedEarly: string | null;
}

export function crawlErrorsMetric(facts: CrawlFacts | null): MetricValue {
  if (!facts) {
    return {
      kind: 'unavailable',
      label: 'No crawl yet',
      why: 'No crawl has run for this project, so nothing is known about which pages could be read.',
      whatWouldMakeItAvailable: 'Authorise and run a crawl from Website Audit.',
    };
  }
  return calculated(
    facts.pagesFailed,
    'count',
    facts.stoppedEarly
      ? `Pages the crawler could not read on the last run. Note that the crawl stopped early (${facts.stoppedEarly}), so this counts only the pages it reached.`
      : 'Pages the crawler could not read on the last run.',
    [
      { label: 'Pages read', value: facts.pagesCrawled },
      { label: 'Pages failed', value: facts.pagesFailed },
    ],
    facts.finishedAt,
  );
}

export interface CoverageFacts {
  readonly keywordsTracked: number;
  readonly keywordsCovered: number;
  readonly asOf: string;
}

/**
 * Content coverage.
 *
 * Unavailable rather than 0% when no keywords are tracked: "0% coverage" says
 * your content covers nothing, which is false when the truth is that nothing has
 * been measured.
 */
export function contentCoverageMetric(facts: CoverageFacts | null): MetricValue {
  if (!facts || facts.keywordsTracked === 0) {
    return {
      kind: 'unavailable',
      label: 'No keywords tracked yet',
      why:
        'No keywords have been extracted for this project, so there is nothing to measure coverage against. A 0% here would claim your content covers nothing.',
      whatWouldMakeItAvailable: 'Run a crawl — keywords are extracted from your own pages.',
    };
  }
  return calculated(
    (facts.keywordsCovered / facts.keywordsTracked) * 100,
    'percent',
    'Tracked keywords with at least one crawled page addressing them ÷ all tracked keywords.',
    [
      { label: 'Covered', value: facts.keywordsCovered },
      { label: 'Tracked', value: facts.keywordsTracked },
    ],
    facts.asOf,
  );
}

/* -------------------------------------------------------------------------- */
/* Everything that needs a connection                                         */
/* -------------------------------------------------------------------------- */

/**
 * The value for a metric that needs a connection which does not exist.
 *
 * One function, so every such metric gets the same honest shape and the same
 * specific instruction. There is no branch anywhere that returns a number here.
 */
export function unavailableForConnection(requires: RequiredSource): MetricValue {
  const reason = whyUnavailable(requires);
  return unavailable(reason.why, reason.whatWouldMakeItAvailable);
}

/**
 * Metrics that are partly knowable, and where saying only "unavailable" would be
 * its own small lie.
 *
 * `content_performance` is the case: SeSha knows how much content was created
 * and approved, and knows nothing about how it performed. Reporting the whole
 * metric as unavailable hides real information; reporting the count as
 * "performance" would be a category error. So the count is returned with a
 * formula that says exactly what it is and what it is not.
 */
export function contentActivityMetric(facts: {
  readonly created: number;
  readonly approved: number;
  readonly asOf: string;
} | null): MetricValue {
  if (!facts || facts.created === 0) {
    return unavailableForConnection(METRICS.content_performance.requires);
  }
  return calculated(
    facts.created,
    'count',
    'Content items created in the period. This is ACTIVITY, not performance: how these pieces actually did needs a website analytics account, which is not connected.',
    [
      { label: 'Created', value: facts.created },
      { label: 'Approved', value: facts.approved },
    ],
    facts.asOf,
  );
}
