/**
 * Analytics service.
 *
 * Assembles the nineteen metrics from rows this database genuinely has, and
 * marks every other one unavailable with the specific account that would supply
 * it. There is exactly one code path that produces a figure — `compute.ts` — and
 * it cannot produce one for a metric that needs a connection.
 *
 * THE PREVIOUS PERIOD IS COMPUTED, NOT STORED
 * A stored "last week's traffic" would be a number with no provenance the moment
 * its source changed. The comparison period is recomputed from the same rows by
 * the same functions, so a change shown on screen is a change in the underlying
 * records, not a change in how they were summarised.
 */

import { assertTenant, type TenantContext } from '@/lib/tenant';
import { requirePermission } from '@/lib/auth/rbac';
import type { Database } from '@/lib/db/repositories';

import {
  METRICS,
  METRIC_IDS,
  type AnalyticsReport,
  type Metric,
  type MetricId,
  type MetricPeriod,
  type MetricValue,
} from './metrics';
import { analyticsStatus, connectionStates, type ConnectionState } from './connections';
import {
  auditScoreMetric,
  contentActivityMetric,
  contentCoverageMetric,
  conversionMetric,
  crawlErrorsMetric,
  leadsMetric,
  schemaIssuesMetric,
  unavailableForConnection,
  type LeadFacts,
} from './compute';

export interface AnalyticsServiceContext {
  readonly db: Database;
  readonly now?: () => Date;
}

function clock(context: AnalyticsServiceContext): Date {
  return context.now?.() ?? new Date();
}

/** Builds a period ending at `to`, covering `days`. */
export function periodOf(to: Date, days: number, label: string): MetricPeriod {
  const from = new Date(to.getTime() - days * 86_400_000);
  return { from: from.toISOString(), to: to.toISOString(), label };
}

/** The period immediately before another, of the same length. */
export function previousPeriod(period: MetricPeriod): MetricPeriod {
  const from = new Date(period.from);
  const to = new Date(period.to);
  const span = to.getTime() - from.getTime();
  return {
    from: new Date(from.getTime() - span).toISOString(),
    to: period.from,
    label: 'the period before',
  };
}

/* -------------------------------------------------------------------------- */
/* Facts                                                                      */
/* -------------------------------------------------------------------------- */

interface ProjectFacts {
  readonly leads: LeadFacts;
  readonly audits: { readonly seo: Parameters<typeof auditScoreMetric>[0]; readonly aeo: Parameters<typeof auditScoreMetric>[0] };
  readonly validation: Parameters<typeof schemaIssuesMetric>[0];
  readonly crawl: Parameters<typeof crawlErrorsMetric>[0];
  readonly coverage: Parameters<typeof contentCoverageMetric>[0];
  readonly content: Parameters<typeof contentActivityMetric>[0];
}

async function gather(
  context: AnalyticsServiceContext,
  organizationId: string,
  projectId: string,
  period: MetricPeriod,
): Promise<ProjectFacts> {
  const db = context.db;
  const from = new Date(period.from);
  const to = new Date(period.to);
  const inWindow = (at: Date): boolean => at.getTime() > from.getTime() && at.getTime() <= to.getTime();

  const leadRows = await db.leads.listForProject(organizationId, projectId);
  const created = leadRows.filter((row) => inWindow(row.createdAt));

  const seo = await db.audits.findLatest(organizationId, projectId, 'seo');
  const aeo = await db.audits.findLatest(organizationId, projectId, 'aeo');
  const [validation = null] = await db.schemaValidations.listForProject(organizationId, projectId, 1);
  const crawl = await db.crawls.findLatest(organizationId, projectId);
  const keywords = await db.keywords.listForProject(organizationId, projectId);
  const contentRows = await db.content.listForProject(organizationId, projectId);
  const contentInPeriod = contentRows.filter((row) => inWindow(row.createdAt));

  return {
    leads: {
      total: leadRows.length,
      won: leadRows.filter((row) => row.stage === 'won').length,
      lost: leadRows.filter((row) => row.stage === 'lost').length,
      open: leadRows.filter((row) => row.stage !== 'won' && row.stage !== 'lost').length,
      inPeriod: created.length,
      asOf: period.to,
    },
    audits: {
      seo: seo
        ? {
            score: seo.score,
            basis: seo.scoreBasis,
            findingCount: seo.findings.length,
            checkedAt: seo.checkedAt.toISOString(),
          }
        : null,
      aeo: aeo
        ? {
            score: aeo.score,
            basis: aeo.scoreBasis,
            findingCount: aeo.findings.length,
            checkedAt: aeo.checkedAt.toISOString(),
          }
        : null,
    },
    validation: validation
      ? {
          // `counts` is keyed by ValidationStatus. Only INVALID means the markup
          // is wrong: WARNING and RECOMMENDATION are advice, and counting them as
          // errors would report a clean site as broken.
          invalid: validation.counts.INVALID ?? 0,
          warnings: validation.counts.WARNING ?? 0,
          checkedAt: validation.checkedAt.toISOString(),
          validatorVersion: validation.validatorVersion,
        }
      : null,
    crawl: crawl
      ? {
          pagesCrawled: crawl.pagesCrawled,
          pagesFailed: crawl.pagesFailed,
          finishedAt: (crawl.finishedAt ?? crawl.startedAt).toISOString(),
          stoppedEarly: crawl.stoppedEarly,
        }
      : null,
    coverage:
      keywords.length > 0
        ? {
            keywordsTracked: keywords.length,
            keywordsCovered: keywords.filter((row) => row.coveringUrls.length > 0).length,
            asOf: period.to,
          }
        : null,
    content:
      contentInPeriod.length > 0
        ? {
            created: contentInPeriod.length,
            approved: contentInPeriod.filter((row) => row.status === 'approved').length,
            asOf: period.to,
          }
        : null,
  };
}

/**
 * The value for one metric.
 *
 * A single switch over every metric id, so adding a metric to `METRIC_IDS`
 * without deciding how it is produced is a compile error rather than a silent
 * blank on a screen.
 */
function valueFor(id: MetricId, facts: ProjectFacts): MetricValue {
  switch (id) {
    case 'leads':
      return leadsMetric(facts.leads);
    case 'conversion':
      return conversionMetric(facts.leads);
    case 'seo_score':
      return auditScoreMetric(facts.audits.seo, 'seo');
    case 'aeo_score':
      return auditScoreMetric(facts.audits.aeo, 'aeo');
    case 'schema_issues':
      return schemaIssuesMetric(facts.validation);
    case 'crawl_errors':
      return crawlErrorsMetric(facts.crawl);
    case 'content_coverage':
      return contentCoverageMetric(facts.coverage);
    case 'content_performance':
      return contentActivityMetric(facts.content);
    case 'traffic':
    case 'engagement':
    case 'reach':
    case 'impressions':
    case 'ctr':
    case 'cpc':
    case 'cpa':
    case 'roas':
    case 'followers':
    case 'campaign_performance':
    case 'organic_search':
      return unavailableForConnection(METRICS[id].requires);
  }
}

/* -------------------------------------------------------------------------- */
/* The service                                                                */
/* -------------------------------------------------------------------------- */

export async function connectionsFor(
  context: AnalyticsServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<readonly ConnectionState[]> {
  requirePermission(tenant.role, 'analytics:read');
  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  assertTenant(tenant, project, 'Project');
  const rows = await context.db.dataConnections.list(tenant.organizationId, projectId);
  return connectionStates(
    rows.map((row) => ({
      provider: row.provider,
      connectedAt: row.connectedAt,
      disconnectedAt: row.disconnectedAt,
      lastSyncedAt: row.lastSyncedAt,
      problem: row.problem,
    })),
  );
}

export interface AnalyticsOptions {
  readonly days?: number;
  readonly label?: string;
  /** Restrict to a subset. Used by the report generator. */
  readonly only?: readonly MetricId[];
}

export async function analyticsFor(
  context: AnalyticsServiceContext,
  tenant: TenantContext,
  projectId: string,
  options: AnalyticsOptions = {},
): Promise<AnalyticsReport> {
  requirePermission(tenant.role, 'analytics:read');
  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  assertTenant(tenant, project, 'Project');

  const now = clock(context);
  const days = options.days ?? 30;
  const period = periodOf(now, days, options.label ?? `Last ${days} days`);
  const earlier = previousPeriod(period);

  const current = await gather(context, tenant.organizationId, projectId, period);
  const before = await gather(context, tenant.organizationId, projectId, earlier);
  const states = await connectionsFor(context, tenant, projectId);

  const wanted = options.only ?? METRIC_IDS;
  const metrics: Metric[] = wanted.map((id) => {
    const value = valueFor(id, current);
    const previous = valueFor(id, before);
    return {
      id,
      definition: METRICS[id],
      value,
      // Only offered when the earlier period produced something comparable.
      // `change()` refuses the comparison anyway; not carrying it at all keeps a
      // screen from rendering "vs unavailable".
      ...(previous.kind === value.kind && previous.kind !== 'unavailable' ? { previous } : {}),
    };
  });

  const status = analyticsStatus(states);
  return {
    period,
    generatedAt: now.toISOString(),
    metrics,
    anyConnected: status.anyConnected,
    counts: {
      available: metrics.filter((metric) => metric.value.kind !== 'unavailable').length,
      unavailable: metrics.filter((metric) => metric.value.kind === 'unavailable').length,
    },
  };
}
