/**
 * Analytics: the metric vocabulary, and the type that makes a fake number
 * impossible to write.
 *
 * THE PROBLEM THIS FILE SOLVES
 * An analytics screen is the single most tempting place in a marketing product to
 * invent a number. Nothing on it is obviously wrong — a plausible traffic figure
 * looks exactly like a real one — and the user has no way to check. The brief is
 * blunt about it: *"If no connected data exists, display 'No connected data
 * available.' Never fabricate analytics."*
 *
 * So `MetricValue` is a discriminated union with NO variant that carries a bare
 * number. Every variant that has a figure also carries where it came from:
 *
 *   · connected_api  — read from a connected account, with the source and an as-of.
 *   · user_provided  — a figure the customer typed in themselves.
 *   · retrieved      — read from their own website by our crawler.
 *   · calculated     — computed by SeSha from rows in this database, WITH the
 *                      formula and the inputs, so the arithmetic is checkable.
 *   · ai_estimate    — a model's guess. Carries a magnitude band, never a precise
 *                      figure, and is never used for a metric that can be measured.
 *   · unavailable    — we do not have it. Carries WHY, and what would make it
 *                      available.
 *
 * This is the same move as `SearchVolume` in Phase 4 and `BudgetRecommendation` in
 * Phase 5: the honest version is the only one the type system permits.
 *
 * WHAT SeSha GENUINELY KNOWS TODAY
 * No analytics, ads or social account is connected, so most of the nineteen
 * metrics the brief names are `unavailable`. But some are genuinely first-party:
 * leads and pipeline conversion come from this product's own lead table, and the
 * SEO score, AEO score, schema issues, crawl errors and content coverage come
 * from this product's own audits, validations and crawls. Those are `calculated`,
 * with the formula shown.
 *
 * Reporting a metric we DO have as "no data" would be its own kind of dishonesty,
 * so the registry says, per metric, which source kinds are even possible.
 *
 * Framework-free and fully unit tested.
 */

/** The six labels the brief names. */
export const SOURCE_KINDS = [
  'connected_api',
  'user_provided',
  'retrieved',
  'calculated',
  'ai_estimate',
  'unavailable',
] as const;

export type SourceKind = (typeof SOURCE_KINDS)[number];

export const SOURCE_LABEL: Readonly<Record<SourceKind, string>> = {
  connected_api: 'Connected API',
  user_provided: 'You told us',
  retrieved: 'Read from your site',
  calculated: 'Calculated by SeSha',
  ai_estimate: 'AI estimate',
  unavailable: 'Unavailable',
};

export const SOURCE_MEANING: Readonly<Record<SourceKind, string>> = {
  connected_api:
    'Read directly from an account you connected. The figure is theirs, not ours, and it carries the time it was read.',
  user_provided: 'A figure you entered. SeSha has not checked it.',
  retrieved: 'Read from your own website by the SeSha crawler, with the time it was read.',
  calculated:
    'Worked out by SeSha from your own records in this product. The formula and the inputs are shown, so you can check the arithmetic.',
  ai_estimate:
    'A model\'s estimate. Shown as a range, never as a precise figure, and never used where the real number could be measured.',
  unavailable:
    'SeSha does not have this. Nothing is shown in its place — no estimate, no placeholder, no zero.',
};

/** The sentence shown when a whole screen has nothing connected. */
export const NO_CONNECTED_DATA = 'No connected data available.';

/* -------------------------------------------------------------------------- */
/* The value                                                                  */
/* -------------------------------------------------------------------------- */

export type MetricUnit =
  | 'count'
  | 'percent'
  | 'currency'
  | 'score'
  | 'ratio'
  | 'duration_days';

/** How precise an AI estimate is allowed to be. Never a specific figure. */
export type EstimateBand = 'very_low' | 'low' | 'moderate' | 'high' | 'very_high';

/** One input to a calculation, named so the arithmetic can be followed. */
export interface CalculationInput {
  readonly label: string;
  readonly value: number;
}

/**
 * A metric's value.
 *
 * There is deliberately no `{ value: number }` variant. Every figure arrives with
 * its provenance attached, or it does not arrive at all.
 */
export type MetricValue =
  | {
      readonly kind: 'connected_api';
      readonly value: number;
      readonly unit: MetricUnit;
      /** Which account this came from. */
      readonly source: string;
      readonly asOf: string;
    }
  | {
      readonly kind: 'user_provided';
      readonly value: number;
      readonly unit: MetricUnit;
      readonly enteredBy: string;
      readonly asOf: string;
    }
  | {
      readonly kind: 'retrieved';
      readonly value: number;
      readonly unit: MetricUnit;
      readonly sourceUrl: string;
      readonly asOf: string;
    }
  | {
      readonly kind: 'calculated';
      readonly value: number;
      readonly unit: MetricUnit;
      /** In words: "leads marked Won ÷ all leads". */
      readonly formula: string;
      readonly inputs: readonly CalculationInput[];
      readonly asOf: string;
    }
  | {
      readonly kind: 'ai_estimate';
      readonly band: EstimateBand;
      readonly basis: string;
    }
  | {
      readonly kind: 'unavailable';
      readonly label: typeof NO_CONNECTED_DATA | string;
      /** Why we do not have it. Always specific to this metric. */
      readonly why: string;
      /** What the customer would have to do. Never vague. */
      readonly whatWouldMakeItAvailable: string;
    };

export function isAvailable(value: MetricValue): boolean {
  return value.kind !== 'unavailable';
}

/** True when the value carries an actual figure (an estimate does not). */
export function hasFigure(
  value: MetricValue,
): value is Extract<MetricValue, { readonly value: number }> {
  return (
    value.kind === 'connected_api' ||
    value.kind === 'user_provided' ||
    value.kind === 'retrieved' ||
    value.kind === 'calculated'
  );
}

/**
 * Builds an unavailable value.
 *
 * A helper rather than an inline object because every unavailable metric must
 * carry both a reason and a route to fixing it, and a helper is harder to
 * shortcut than a convention.
 */
export function unavailable(why: string, whatWouldMakeItAvailable: string): MetricValue {
  return { kind: 'unavailable', label: NO_CONNECTED_DATA, why, whatWouldMakeItAvailable };
}

/* -------------------------------------------------------------------------- */
/* The metrics                                                                */
/* -------------------------------------------------------------------------- */

/** The nineteen metrics the brief names, in its order. */
export const METRIC_IDS = [
  'leads',
  'conversion',
  'traffic',
  'engagement',
  'reach',
  'impressions',
  'ctr',
  'cpc',
  'cpa',
  'roas',
  'followers',
  'content_performance',
  'campaign_performance',
  'organic_search',
  'seo_score',
  'aeo_score',
  'schema_issues',
  'crawl_errors',
  'content_coverage',
] as const;

export type MetricId = (typeof METRIC_IDS)[number];

/**
 * What a data source would have to be connected for a metric to exist.
 *
 * Named individually rather than as "an analytics tool", because the difference
 * matters: a customer who connects Google Analytics still will not get CPC.
 */
export type RequiredSource =
  | 'analytics'
  | 'search_console'
  | 'ads_account'
  | 'social_account'
  | 'none';

export const SOURCE_NAME: Readonly<Record<RequiredSource, string>> = {
  analytics: 'a website analytics account',
  search_console: 'a search console account',
  ads_account: 'an advertising account',
  social_account: 'a social account',
  none: 'nothing — SeSha has this already',
};

export interface MetricDefinition {
  readonly id: MetricId;
  readonly label: string;
  /** One sentence: what this measures, in the user's language. */
  readonly description: string;
  readonly unit: MetricUnit;
  /** Which source kinds this metric could ever legitimately have. */
  readonly possibleSources: readonly SourceKind[];
  /** What must be connected. `none` means SeSha computes it from its own data. */
  readonly requires: RequiredSource;
  /** The group it is shown under. */
  readonly group: 'pipeline' | 'audience' | 'advertising' | 'search' | 'content' | 'technical';
  /**
   * True when a higher number is better. Used for direction arrows — and for
   * `crawl_errors` and `schema_issues` it is false, which a chart that assumes
   * "up is good" would get exactly wrong.
   */
  readonly higherIsBetter: boolean;
}

export const METRICS: Readonly<Record<MetricId, MetricDefinition>> = {
  leads: {
    id: 'leads',
    label: 'Leads',
    description: 'Enquiries recorded in your pipeline.',
    unit: 'count',
    possibleSources: ['calculated'],
    requires: 'none',
    group: 'pipeline',
    higherIsBetter: true,
  },
  conversion: {
    id: 'conversion',
    label: 'Pipeline conversion',
    description: 'The share of leads you have marked Won.',
    unit: 'percent',
    possibleSources: ['calculated'],
    requires: 'none',
    group: 'pipeline',
    higherIsBetter: true,
  },
  traffic: {
    id: 'traffic',
    label: 'Traffic',
    description: 'Sessions and users on your website.',
    unit: 'count',
    possibleSources: ['connected_api', 'unavailable'],
    requires: 'analytics',
    group: 'audience',
    higherIsBetter: true,
  },
  engagement: {
    id: 'engagement',
    label: 'Engagement',
    description: 'Reactions, comments and shares on your posts.',
    unit: 'count',
    possibleSources: ['connected_api', 'unavailable'],
    requires: 'social_account',
    group: 'audience',
    higherIsBetter: true,
  },
  reach: {
    id: 'reach',
    label: 'Reach',
    description: 'How many distinct people saw your content.',
    unit: 'count',
    possibleSources: ['connected_api', 'unavailable'],
    requires: 'social_account',
    group: 'audience',
    higherIsBetter: true,
  },
  impressions: {
    id: 'impressions',
    label: 'Impressions',
    description: 'How many times your content was displayed.',
    unit: 'count',
    possibleSources: ['connected_api', 'unavailable'],
    requires: 'ads_account',
    group: 'advertising',
    higherIsBetter: true,
  },
  ctr: {
    id: 'ctr',
    label: 'Click-through rate',
    description: 'Clicks divided by impressions.',
    unit: 'percent',
    possibleSources: ['connected_api', 'unavailable'],
    requires: 'ads_account',
    group: 'advertising',
    higherIsBetter: true,
  },
  cpc: {
    id: 'cpc',
    label: 'Cost per click',
    description: 'What you paid, on average, for each click.',
    unit: 'currency',
    possibleSources: ['connected_api', 'unavailable'],
    requires: 'ads_account',
    group: 'advertising',
    higherIsBetter: false,
  },
  cpa: {
    id: 'cpa',
    label: 'Cost per acquisition',
    description: 'What you paid, on average, for each result.',
    unit: 'currency',
    possibleSources: ['connected_api', 'unavailable'],
    requires: 'ads_account',
    group: 'advertising',
    higherIsBetter: false,
  },
  roas: {
    id: 'roas',
    label: 'Return on ad spend',
    description: 'Revenue attributed to advertising, divided by the spend.',
    unit: 'ratio',
    possibleSources: ['connected_api', 'unavailable'],
    requires: 'ads_account',
    group: 'advertising',
    higherIsBetter: true,
  },
  followers: {
    id: 'followers',
    label: 'Followers',
    description: 'People following your social accounts.',
    unit: 'count',
    possibleSources: ['connected_api', 'unavailable'],
    requires: 'social_account',
    group: 'audience',
    higherIsBetter: true,
  },
  content_performance: {
    id: 'content_performance',
    label: 'Content performance',
    description: 'How the content you published actually did.',
    unit: 'count',
    possibleSources: ['connected_api', 'unavailable'],
    requires: 'analytics',
    group: 'content',
    higherIsBetter: true,
  },
  campaign_performance: {
    id: 'campaign_performance',
    label: 'Campaign performance',
    description: 'How your advertising campaigns actually did.',
    unit: 'count',
    possibleSources: ['connected_api', 'unavailable'],
    requires: 'ads_account',
    group: 'advertising',
    higherIsBetter: true,
  },
  organic_search: {
    id: 'organic_search',
    label: 'Organic search',
    description: 'Clicks and impressions from search results.',
    unit: 'count',
    possibleSources: ['connected_api', 'unavailable'],
    requires: 'search_console',
    group: 'search',
    higherIsBetter: true,
  },
  seo_score: {
    id: 'seo_score',
    label: 'SEO score',
    description: "SeSha's own weighting of the SEO findings from your last crawl.",
    unit: 'score',
    possibleSources: ['calculated'],
    requires: 'none',
    group: 'technical',
    higherIsBetter: true,
  },
  aeo_score: {
    id: 'aeo_score',
    label: 'AEO score',
    description: "SeSha's own weighting of the AEO findings from your last crawl.",
    unit: 'score',
    possibleSources: ['calculated'],
    requires: 'none',
    group: 'technical',
    higherIsBetter: true,
  },
  schema_issues: {
    id: 'schema_issues',
    label: 'Schema issues',
    description: 'Structured-data problems found in your most recent validation.',
    unit: 'count',
    possibleSources: ['calculated'],
    requires: 'none',
    group: 'technical',
    higherIsBetter: false,
  },
  crawl_errors: {
    id: 'crawl_errors',
    label: 'Crawl errors',
    description: 'Pages the crawler could not read on your last run.',
    unit: 'count',
    possibleSources: ['calculated'],
    requires: 'none',
    group: 'technical',
    higherIsBetter: false,
  },
  content_coverage: {
    id: 'content_coverage',
    label: 'Content coverage',
    description: 'The share of your tracked keywords that a crawled page addresses.',
    unit: 'percent',
    possibleSources: ['calculated'],
    requires: 'none',
    group: 'content',
    higherIsBetter: true,
  },
};

/** Metrics SeSha can compute from its own records today. */
export const FIRST_PARTY_METRICS: readonly MetricId[] = METRIC_IDS.filter(
  (id) => METRICS[id].requires === 'none',
);

/** Metrics that need something connected before they can exist at all. */
export const CONNECTION_DEPENDENT_METRICS: readonly MetricId[] = METRIC_IDS.filter(
  (id) => METRICS[id].requires !== 'none',
);

export function isMetricId(value: unknown): value is MetricId {
  return typeof value === 'string' && (METRIC_IDS as readonly string[]).includes(value);
}

/* -------------------------------------------------------------------------- */
/* The report                                                                 */
/* -------------------------------------------------------------------------- */

export interface Metric {
  readonly id: MetricId;
  readonly definition: MetricDefinition;
  readonly value: MetricValue;
  /**
   * The same metric one period earlier, where it can be computed. Absent rather
   * than zero when there is no earlier period — a "0% change" against a period
   * that does not exist is a fabricated comparison.
   */
  readonly previous?: MetricValue;
}

export interface MetricPeriod {
  readonly from: string;
  readonly to: string;
  readonly label: string;
}

export interface AnalyticsReport {
  readonly period: MetricPeriod;
  readonly generatedAt: string;
  readonly metrics: readonly Metric[];
  /** True when NOTHING at all is connected. Drives the headline message. */
  readonly anyConnected: boolean;
  /** Counts, so a screen can summarise without walking the list. */
  readonly counts: {
    readonly available: number;
    readonly unavailable: number;
  };
}

/**
 * A change between two periods.
 *
 * Returns null unless BOTH values carry a real figure of the same kind. A
 * comparison between a calculated figure and an estimate is not a change, it is
 * two different things subtracted from each other.
 */
export function change(
  current: MetricValue,
  previous: MetricValue | undefined,
): { readonly delta: number; readonly percent: number | null; readonly direction: 'up' | 'down' | 'flat' } | null {
  if (!previous) return null;
  if (!hasFigure(current) || !hasFigure(previous)) return null;
  if (current.kind !== previous.kind) return null;

  const delta = current.value - previous.value;
  const percent = previous.value === 0 ? null : (delta / previous.value) * 100;
  return {
    delta,
    percent,
    direction: delta > 0 ? 'up' : delta < 0 ? 'down' : 'flat',
  };
}

/** Formats a figure for display. Returns null for anything without one. */
export function formatValue(value: MetricValue, currency = 'INR'): string | null {
  if (!hasFigure(value)) return null;
  switch (value.unit) {
    case 'percent':
      return `${round(value.value, 1)}%`;
    case 'currency':
      return `${currency} ${round(value.value, 2).toLocaleString('en-IN')}`;
    case 'score':
      return `${Math.round(value.value)} / 100`;
    case 'ratio':
      return `${round(value.value, 2)}×`;
    case 'duration_days':
      return `${round(value.value, 1)} days`;
    default:
      return Math.round(value.value).toLocaleString('en-IN');
  }
}

function round(value: number, places: number): number {
  const factor = 10 ** places;
  return Math.round(value * factor) / factor;
}
