/**
 * Data connections: the single place that says what is and is not connected.
 *
 * The same shape as `publishingStatus()` (Phase 3), `adsDataStatus()` and
 * `sendingStatus()` (Phase 5). One function every screen reads, so no screen can
 * drift into implying a connection exists, and there is one place to change when
 * one genuinely does.
 *
 * WHY THIS IS A TABLE AND NOT A BOOLEAN
 * "Connected" is not one state. A customer may connect analytics and not ads, and
 * the metrics that become available are completely different. A single flag would
 * force every screen to guess, and guessing here means showing a user a metric
 * that cannot exist.
 *
 * Framework-free and fully unit tested.
 */

import { SOURCE_NAME, type RequiredSource } from './metrics';

export const CONNECTION_PROVIDERS = [
  'google_analytics',
  'google_search_console',
  'google_ads',
  'meta_ads',
  'meta_pages',
  'linkedin_pages',
] as const;

export type ConnectionProvider = (typeof CONNECTION_PROVIDERS)[number];

export interface ConnectionDefinition {
  readonly id: ConnectionProvider;
  readonly label: string;
  /** Which family of metrics this unlocks. */
  readonly provides: RequiredSource;
  /** What a customer has to do, in their words. */
  readonly howToConnect: string;
}

export const CONNECTION_DEFINITIONS: Readonly<Record<ConnectionProvider, ConnectionDefinition>> = {
  google_analytics: {
    id: 'google_analytics',
    label: 'Google Analytics',
    provides: 'analytics',
    howToConnect:
      'Sign in with the Google account that owns the property and grant read-only access. SeSha never needs write access to analytics.',
  },
  google_search_console: {
    id: 'google_search_console',
    label: 'Google Search Console',
    provides: 'search_console',
    howToConnect:
      'Sign in with the Google account that has the property verified, and grant read-only access.',
  },
  google_ads: {
    id: 'google_ads',
    label: 'Google Ads',
    provides: 'ads_account',
    howToConnect: 'Grant read access to the ads account. SeSha does not request permission to spend.',
  },
  meta_ads: {
    id: 'meta_ads',
    label: 'Meta Ads',
    provides: 'ads_account',
    howToConnect: 'Grant read access through Meta Business. SeSha does not request permission to spend.',
  },
  meta_pages: {
    id: 'meta_pages',
    label: 'Facebook and Instagram pages',
    provides: 'social_account',
    howToConnect: 'Grant read access to the page insights through Meta Business.',
  },
  linkedin_pages: {
    id: 'linkedin_pages',
    label: 'LinkedIn page',
    provides: 'social_account',
    howToConnect: 'Grant read access to the page analytics.',
  },
};

export interface ConnectionState {
  readonly provider: ConnectionProvider;
  readonly definition: ConnectionDefinition;
  readonly connected: boolean;
  /** When it was connected, for a live connection. */
  readonly connectedAt?: string;
  /** When data was last read, for a live connection. */
  readonly lastSyncedAt?: string | null;
  /** Set when a connection exists but is not currently usable. */
  readonly problem?: string;
}

/**
 * The state of every connection for an organization.
 *
 * Takes the stored rows rather than reading the database itself, so it stays
 * framework-free and testable. A provider with no row is simply not connected —
 * absence is the honest default.
 */
export function connectionStates(
  rows: readonly {
    readonly provider: string;
    readonly connectedAt: Date | null;
    readonly disconnectedAt: Date | null;
    readonly lastSyncedAt: Date | null;
    readonly problem: string | null;
  }[],
): readonly ConnectionState[] {
  return CONNECTION_PROVIDERS.map((provider) => {
    const row = rows.find((candidate) => candidate.provider === provider);
    const live = row !== undefined && row.connectedAt !== null && row.disconnectedAt === null;
    return {
      provider,
      definition: CONNECTION_DEFINITIONS[provider],
      connected: live,
      ...(live && row.connectedAt ? { connectedAt: row.connectedAt.toISOString() } : {}),
      ...(live ? { lastSyncedAt: row.lastSyncedAt?.toISOString() ?? null } : {}),
      ...(live && row.problem ? { problem: row.problem } : {}),
    };
  });
}

/** Which metric families are currently available. */
export function availableSources(states: readonly ConnectionState[]): ReadonlySet<RequiredSource> {
  const available = new Set<RequiredSource>(['none']);
  for (const state of states) {
    if (state.connected && !state.problem) available.add(state.definition.provides);
  }
  return available;
}

export function anyConnected(states: readonly ConnectionState[]): boolean {
  return states.some((state) => state.connected);
}

/**
 * The sentence explaining why a metric is missing.
 *
 * Names the specific thing to connect. "Connect a data source" would leave the
 * customer to work out which one, and for half these metrics the obvious guess
 * (analytics) is the wrong answer.
 */
export function whyUnavailable(requires: RequiredSource): {
  readonly why: string;
  readonly whatWouldMakeItAvailable: string;
} {
  const options = CONNECTION_PROVIDERS.filter(
    (provider) => CONNECTION_DEFINITIONS[provider].provides === requires,
  ).map((provider) => CONNECTION_DEFINITIONS[provider].label);

  return {
    why: `This can only come from ${SOURCE_NAME[requires]}, and none is connected. SeSha will not estimate it.`,
    whatWouldMakeItAvailable:
      options.length > 0
        ? `Connect ${options.join(' or ')} in Settings. The figure then comes from them, with the time it was read.`
        : 'Connect the account that holds this data.',
  };
}

/**
 * Whether SeSha can read live data at all.
 *
 * The one function every analytics surface calls before rendering anything.
 */
export function analyticsStatus(states: readonly ConnectionState[]): {
  readonly anyConnected: boolean;
  readonly message: string;
} {
  if (anyConnected(states)) {
    const live = states.filter((state) => state.connected).map((state) => state.definition.label);
    return {
      anyConnected: true,
      message: `Reading from ${live.join(', ')}. Everything else on this screen is either calculated from your own SeSha records or marked unavailable.`,
    };
  }
  return {
    anyConnected: false,
    message:
      'No analytics, advertising or social account is connected, so nothing on this screen is a measurement of your audience. What is shown is calculated from your own records inside SeSha — leads, audits, validations and crawls — and everything else says so.',
  };
}
