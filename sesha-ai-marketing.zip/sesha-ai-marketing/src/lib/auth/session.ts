/**
 * Session lifecycle.
 *
 * DESIGN: server-side sessions, opaque tokens, not JWTs.
 *
 * A JWT cannot be revoked before it expires without a server-side denylist —
 * at which point you have server-side session state anyway, with worse
 * ergonomics. Sign-out, "log out all devices", account deletion and role
 * changes all need immediate effect, so the session row is the source of truth
 * and the cookie holds only a random lookup token.
 *
 * THREE INDEPENDENT EXPIRY RULES, all enforced on every request:
 *   1. `expiresAt`         — the session's own expiry.
 *   2. idle timeout        — no activity for SESSION_IDLE_TIMEOUT.
 *   3. absolute lifetime   — SESSION_ABSOLUTE_LIFETIME since creation,
 *                            regardless of activity. Forces periodic re-auth so
 *                            a stolen token cannot be renewed forever.
 *
 * SESSION FIXATION: the token is rotated on every privilege change — sign-in,
 * password change, email verification, role change. `rotateSession()` is the
 * only correct response to "this user just became more privileged".
 *
 * The core here is framework-free and fully unit tested. `current-session.ts`
 * adapts it to Next.js cookies.
 */

import {
  SESSION_ABSOLUTE_LIFETIME,
  SESSION_IDLE_TIMEOUT,
  TOKEN_LIFETIMES,
  generateToken,
  hashToken,
  type IssuedToken,
} from './tokens';
import type { Role } from './rbac';

export interface SessionRecord {
  readonly id: string;
  readonly userId: string;
  /** SHA-256 of the token the client holds. The token itself is never stored. */
  readonly tokenHash: string;
  readonly createdAt: Date;
  readonly expiresAt: Date;
  readonly lastActiveAt: Date;
  readonly revokedAt: Date | null;
  /** Set when the user re-authenticated, for sensitive-action gating. */
  readonly sudoUntil: Date | null;
  readonly userAgent: string | null;
  /** Hashed, never the raw address — a session table should not be a log of IPs. */
  readonly ipHash: string | null;
}

export interface SessionUser {
  readonly id: string;
  readonly email: string;
  readonly name: string | null;
  readonly emailVerifiedAt: Date | null;
  readonly organizationId: string;
  readonly role: Role;
  readonly onboardingCompletedAt: Date | null;
}

export interface ActiveSession {
  readonly session: SessionRecord;
  readonly user: SessionUser;
}

export type SessionInvalidReason =
  | 'no-token'
  | 'not-found'
  | 'revoked'
  | 'expired'
  | 'idle-timeout'
  | 'absolute-timeout';

export type SessionValidation =
  | { readonly valid: true; readonly session: SessionRecord; readonly shouldRefresh: boolean }
  | { readonly valid: false; readonly reason: SessionInvalidReason };

/**
 * Validates a session record against all three expiry rules.
 *
 * Pure: takes the record and the current time, returns a verdict. No I/O, so
 * every branch is unit tested.
 */
export function validateSessionRecord(
  record: SessionRecord | null | undefined,
  now: number = Date.now(),
): SessionValidation {
  if (!record) return { valid: false, reason: 'not-found' };

  if (record.revokedAt !== null) return { valid: false, reason: 'revoked' };

  if (record.expiresAt.getTime() <= now) return { valid: false, reason: 'expired' };

  if (now - record.createdAt.getTime() >= SESSION_ABSOLUTE_LIFETIME) {
    return { valid: false, reason: 'absolute-timeout' };
  }

  if (now - record.lastActiveAt.getTime() >= SESSION_IDLE_TIMEOUT) {
    return { valid: false, reason: 'idle-timeout' };
  }

  // Only write `lastActiveAt` when it is meaningfully stale, so a busy session
  // does not issue a database write on every single request.
  const shouldRefresh = now - record.lastActiveAt.getTime() > REFRESH_THRESHOLD_MS;

  return { valid: true, session: record, shouldRefresh };
}

/** One hour: frequent enough for an accurate idle timeout, rare enough to be cheap. */
export const REFRESH_THRESHOLD_MS = 60 * 60 * 1000;

export interface NewSessionInput {
  readonly userId: string;
  readonly userAgent?: string | null;
  readonly ipHash?: string | null;
  /** Mark the session as freshly authenticated (enables sensitive actions). */
  readonly sudo?: boolean;
}

export interface NewSession {
  readonly token: string;
  readonly record: Omit<SessionRecord, 'id'>;
}

export function createSessionRecord(input: NewSessionInput, now: number = Date.now()): NewSession {
  const issued: IssuedToken = generateToken(TOKEN_LIFETIMES.session, now);
  return {
    token: issued.token,
    record: {
      userId: input.userId,
      tokenHash: issued.hash,
      createdAt: new Date(now),
      expiresAt: issued.expiresAt,
      lastActiveAt: new Date(now),
      revokedAt: null,
      sudoUntil: input.sudo ? new Date(now + TOKEN_LIFETIMES.sudo) : null,
      userAgent: input.userAgent ?? null,
      ipHash: input.ipHash ?? null,
    },
  };
}

/**
 * True when the session was authenticated recently enough to permit a sensitive
 * action (account deletion, email change, disabling a security control).
 */
export function isSudo(record: SessionRecord, now: number = Date.now()): boolean {
  return record.sudoUntil !== null && record.sudoUntil.getTime() > now;
}

/**
 * Whether the application secret is set and long enough to be worth anything.
 *
 * EXISTS SO NOTHING OUTSIDE `lib/auth` READS THE SECRET ITSELF. The admin
 * panel's health check needs to report whether AUTH_SECRET is configured, and
 * doing that with its own `process.env.AUTH_SECRET` would put a second reader
 * of the most sensitive variable in the product into a service file — where the
 * next person to need "the secret, just to check something" would copy it.
 * `tests/ai-security.test.ts` and the Phase 7 gate both assert that secrets are
 * read in exactly one place per concern; this is that place for this one.
 *
 * Returns a BOOLEAN, never the value. A caller that only needs to know whether
 * something is configured must not be handed the thing itself.
 */
export function authSecretIsConfigured(): boolean {
  const secret = process.env.AUTH_SECRET;
  return typeof secret === 'string' && secret.length >= 32;
}

/**
 * The scheduler's bearer secret for `POST /api/internal/maintenance`. Read here
 * because secrets are read only inside `lib/auth` (the Phase 7 gate enforces it).
 */
export function cronSecret(): string | undefined {
  return process.env.CRON_SECRET;
}

export function hashIpAddress(address: string | null | undefined, secret: string): string | null {
  if (!address) return null;
  // Keyed hash: an unsalted IP hash is trivially reversible by brute force,
  // since the whole IPv4 space is 2^32.
  return hashToken(`${secret}:${address}`);
}

/* -------------------------------------------------------------------------- */
/* Cookies                                                                    */
/* -------------------------------------------------------------------------- */

export const SESSION_COOKIE = 'sesha_session';

export interface CookieOptions {
  readonly httpOnly: boolean;
  readonly secure: boolean;
  readonly sameSite: 'lax' | 'strict' | 'none';
  readonly path: string;
  readonly maxAge?: number;
}

/**
 * Session cookie attributes.
 *
 *  · httpOnly       — JavaScript cannot read it, so XSS cannot exfiltrate it.
 *  · secure         — HTTPS only in production.
 *  · sameSite: lax  — blocks cross-site POSTs while still allowing a normal
 *                     top-level navigation into the app from an email link.
 *                     'strict' would sign users out whenever they arrive from
 *                     any external link, which pushes people to stay signed in
 *                     on shared machines.
 *  · path: '/'      — the public site needs it too, to show signed-in state.
 */
export function sessionCookieOptions(isProduction: boolean, maxAgeSeconds?: number): CookieOptions {
  return {
    httpOnly: true,
    secure: isProduction,
    sameSite: 'lax',
    path: '/',
    ...(maxAgeSeconds !== undefined ? { maxAge: maxAgeSeconds } : {}),
  };
}

/** The CSRF cookie is deliberately readable by JavaScript — the client must echo it back. */
export function csrfCookieOptions(isProduction: boolean, maxAgeSeconds?: number): CookieOptions {
  return {
    httpOnly: false,
    secure: isProduction,
    sameSite: 'lax',
    path: '/',
    ...(maxAgeSeconds !== undefined ? { maxAge: maxAgeSeconds } : {}),
  };
}

export function sessionMaxAgeSeconds(): number {
  return Math.floor(TOKEN_LIFETIMES.session / 1000);
}
