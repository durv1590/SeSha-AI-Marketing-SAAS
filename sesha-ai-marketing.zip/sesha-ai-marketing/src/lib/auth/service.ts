/**
 * Authentication service — the actual flows.
 *
 * Framework-free on purpose: every function takes the database and returns a
 * plain result, so `tests/auth-flow.test.ts` runs real sign-up, sign-in,
 * verification, reset, session validation and deletion end to end. The Next.js
 * route handlers are thin wrappers that translate HTTP to these calls.
 *
 * SECURITY DECISIONS ENCODED HERE
 *  · Sign-up and password reset NEVER reveal whether an email is registered.
 *    Both return the same response either way; the difference is only in which
 *    email gets sent. Account enumeration is the most commonly shipped auth bug.
 *  · Sign-in spends the same CPU on a missing account as on a real one
 *    (`dummyVerify`), so response time is not an enumeration oracle either.
 *  · The session token is rotated on every privilege change — sign-in, password
 *    change, email verification — which is what prevents session fixation.
 *  · A password change revokes every other session. An attacker with a stolen
 *    session must not survive the user's response to being compromised.
 *  · Every outcome is written to the audit log, including failures and denials.
 */

import { createHash, randomUUID } from 'node:crypto';

import { checkPasswordPolicy, dummyVerify, passwordHasher } from './password';
import {
  ACCOUNT_POLICY,
  ADDRESS_POLICY,
  accountKey,
  addressKey,
  type LockoutStore,
} from './lockout';
import { createSessionRecord, hashIpAddress, validateSessionRecord, type SessionUser } from './session';
import { TOKEN_LIFETIMES, generateToken, hashToken } from './tokens';
import type { Role } from './rbac';
import type { Database } from '@/lib/db/repositories';
import type { MembershipRow, SessionRow, UserRow } from '@/lib/db/types';

export interface ServiceContext {
  readonly db: Database;
  readonly lockout: LockoutStore;
  /** Keyed hashing of IP addresses, and CSRF signing. Never logged. */
  readonly secret: string;
  readonly now?: () => number;
}

export interface RequestMeta {
  readonly ipAddress?: string | null;
  readonly userAgent?: string | null;
}

function clock(context: ServiceContext): number {
  return context.now?.() ?? Date.now();
}

/** Memberships use owner/admin/manager/team_member/user; RBAC uses four roles. */
export function toRole(membershipRole: MembershipRow['role']): Role {
  return membershipRole === 'owner' ? 'admin' : membershipRole;
}

function slugify(value: string): string {
  const base = value
    .normalize('NFKD')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
  return base.length > 0 ? base : 'workspace';
}

async function audit(
  context: ServiceContext,
  entry: {
    organizationId?: string | null;
    actorId?: string | null;
    action: string;
    entityType: string;
    entityId?: string | null;
    outcome: 'success' | 'failure' | 'denied';
    metadata?: Record<string, unknown>;
    meta?: RequestMeta;
  },
): Promise<void> {
  await context.db.audit.record({
    organizationId: entry.organizationId ?? null,
    actorId: entry.actorId ?? null,
    action: entry.action,
    entityType: entry.entityType,
    entityId: entry.entityId ?? null,
    outcome: entry.outcome,
    metadata: entry.metadata ?? {},
    ipHash: hashIpAddress(entry.meta?.ipAddress, context.secret),
    userAgent: entry.meta?.userAgent ?? null,
  });
}

/* -------------------------------------------------------------------------- */
/* Sign up                                                                    */
/* -------------------------------------------------------------------------- */

export interface SignUpInput {
  readonly email: string;
  readonly password: string;
  readonly name?: string | null;
  readonly organizationName?: string | null;
}

export type SignUpResult =
  | {
      readonly ok: true;
      /** Present only for a genuinely new account — the caller emails it. */
      readonly verificationToken: string | null;
      readonly userId: string | null;
    }
  | { readonly ok: false; readonly problems: readonly string[] };

/**
 * Creates an account, its organization, the owner membership and a trial
 * subscription.
 *
 * ENUMERATION: when the address already has an account, this returns
 * `{ ok: true, userId: null, verificationToken: null }` — identical in shape to
 * success. The caller must send a "someone tried to sign up with your address"
 * email instead of a verification email, and must not vary its HTTP response.
 */
export async function signUp(
  context: ServiceContext,
  input: SignUpInput,
  meta: RequestMeta = {},
): Promise<SignUpResult> {
  const now = clock(context);
  const email = input.email.trim().toLowerCase();

  const policy = checkPasswordPolicy(input.password, [email, input.name ?? '']);
  if (!policy.ok) return { ok: false, problems: policy.problems };

  const existing = await context.db.users.findByEmail(email);
  if (existing) {
    await audit(context, {
      action: 'auth.signup.duplicate',
      entityType: 'user',
      entityId: existing.id,
      outcome: 'failure',
      metadata: { reason: 'email-already-registered' },
      meta,
    });
    // Deliberately indistinguishable from success.
    return { ok: true, verificationToken: null, userId: null };
  }

  const passwordHash = await passwordHasher.hash(input.password);
  const user = await context.db.users.create({ email, name: input.name ?? null, passwordHash });

  const organizationName = input.organizationName?.trim() || `${input.name ?? email.split('@')[0]}'s workspace`;
  const organization = await context.db.organizations.create({
    name: organizationName,
    slug: `${slugify(organizationName)}-${randomUUID().slice(0, 8)}`,
  });

  await context.db.memberships.create({
    organizationId: organization.id,
    userId: user.id,
    role: 'owner',
    createdAt: new Date(now),
  });

  await context.db.subscriptions.create({
    organizationId: organization.id,
    plan: 'free',
    status: 'trialing',
    externalCustomerId: null,
    externalSubscriptionId: null,
    currentPeriodStart: new Date(now),
    currentPeriodEnd: null,
    cancelAtPeriodEnd: false,
    pastDueSince: null,
    canceledAt: null,
    provider: null,
    paymentBrand: null,
    paymentLast4: null,
    paymentExpiryMonth: null,
    paymentExpiryYear: null,
    trialEndsAt: new Date(now + 14 * 24 * 60 * 60 * 1000),
  });

  const issued = generateToken(TOKEN_LIFETIMES.emailVerification, now);
  await context.db.emailVerification.create({
    userId: user.id,
    tokenHash: issued.hash,
    email,
    expiresAt: issued.expiresAt,
  });

  await audit(context, {
    organizationId: organization.id,
    actorId: user.id,
    action: 'auth.signup',
    entityType: 'user',
    entityId: user.id,
    outcome: 'success',
    meta,
  });

  return { ok: true, verificationToken: issued.token, userId: user.id };
}

/* -------------------------------------------------------------------------- */
/* Sign in                                                                    */
/* -------------------------------------------------------------------------- */

export type SignInResult =
  | { readonly ok: true; readonly token: string; readonly session: SessionRow; readonly user: UserRow }
  | {
      readonly ok: false;
      readonly reason: 'invalid-credentials' | 'locked' | 'oauth-only';
      readonly retryAfterSeconds?: number;
    };

export async function signIn(
  context: ServiceContext,
  input: { email: string; password: string },
  meta: RequestMeta = {},
): Promise<SignInResult> {
  const now = clock(context);
  const email = input.email.trim().toLowerCase();
  const addressId = meta.ipAddress ?? 'unknown';

  // Both counters are checked before any expensive work.
  const accountStatus = context.lockout.status(accountKey(email), ACCOUNT_POLICY, now);
  const addressStatus = context.lockout.status(addressKey(addressId), ADDRESS_POLICY, now);
  if (accountStatus.locked || addressStatus.locked) {
    await audit(context, {
      action: 'auth.signin.locked',
      entityType: 'user',
      outcome: 'denied',
      metadata: { scope: accountStatus.locked ? 'account' : 'address' },
      meta,
    });
    return {
      ok: false,
      reason: 'locked',
      retryAfterSeconds: Math.max(accountStatus.retryAfterSeconds, addressStatus.retryAfterSeconds),
    };
  }

  const user = await context.db.users.findByEmail(email);

  if (!user || user.passwordHash === null) {
    // Spend the same CPU as a real verification so timing does not leak
    // whether the account exists (or is OAuth-only).
    await dummyVerify(input.password);
    context.lockout.recordFailure(accountKey(email), ACCOUNT_POLICY, now);
    context.lockout.recordFailure(addressKey(addressId), ADDRESS_POLICY, now);
    await audit(context, {
      action: 'auth.signin.failed',
      entityType: 'user',
      entityId: user?.id ?? null,
      outcome: 'failure',
      metadata: { reason: user ? 'oauth-only' : 'no-such-user' },
      meta,
    });
    // Same reason string either way — the client must not learn the difference.
    return { ok: false, reason: 'invalid-credentials' };
  }

  const valid = await passwordHasher.verify(input.password, user.passwordHash);
  if (!valid) {
    const failure = context.lockout.recordFailure(accountKey(email), ACCOUNT_POLICY, now);
    context.lockout.recordFailure(addressKey(addressId), ADDRESS_POLICY, now);
    await audit(context, {
      action: 'auth.signin.failed',
      actorId: user.id,
      entityType: 'user',
      entityId: user.id,
      outcome: 'failure',
      metadata: { reason: 'bad-password', failuresRemaining: failure.failuresRemaining },
      meta,
    });
    return { ok: false, reason: 'invalid-credentials' };
  }

  // Success: clear the account counter, leave the address counter alone so one
  // valid login does not reset an attacker's budget.
  context.lockout.clear(accountKey(email));

  // Opportunistic upgrade if the cost parameters have since been raised.
  if (passwordHasher.needsRehash(user.passwordHash)) {
    await context.db.users.setPassword(user.id, await passwordHasher.hash(input.password), new Date(now));
  }

  const created = await startSession(context, user.id, meta, { sudo: true });
  await context.db.users.recordLogin(user.id, new Date(now));

  await audit(context, {
    actorId: user.id,
    action: 'auth.signin',
    entityType: 'session',
    entityId: created.session.id,
    outcome: 'success',
    meta,
  });

  return { ok: true, token: created.token, session: created.session, user };
}

async function startSession(
  context: ServiceContext,
  userId: string,
  meta: RequestMeta,
  options: { sudo?: boolean } = {},
): Promise<{ token: string; session: SessionRow }> {
  const now = clock(context);
  const created = createSessionRecord(
    {
      userId,
      userAgent: meta.userAgent ?? null,
      ipHash: hashIpAddress(meta.ipAddress, context.secret),
      sudo: options.sudo ?? false,
    },
    now,
  );
  const session = await context.db.sessions.create(created.record);
  return { token: created.token, session };
}

/* -------------------------------------------------------------------------- */
/* Session resolution                                                         */
/* -------------------------------------------------------------------------- */

export interface ResolvedSession {
  readonly session: SessionRow;
  readonly user: SessionUser;
}

/**
 * Turns a raw session token into a session plus the user's role in their
 * organization. Returns null for every failure mode — expired, revoked, idle,
 * deleted user — so callers cannot accidentally treat a bad session as good.
 */
export async function resolveSession(
  context: ServiceContext,
  token: string | null | undefined,
): Promise<ResolvedSession | null> {
  if (!token) return null;
  const now = clock(context);

  const record = await context.db.sessions.findByTokenHash(hashToken(token));
  const validation = validateSessionRecord(record, now);
  if (!validation.valid) return null;

  const user = await context.db.users.findById(validation.session.userId);
  // A soft-deleted user's sessions stop working immediately, even if the
  // session row itself is still live.
  if (!user || user.deletedAt !== null) return null;

  const memberships = await context.db.memberships.findForUser(user.id);
  const membership = memberships[0];
  if (!membership) return null;

  if (validation.shouldRefresh) {
    await context.db.sessions.touch(validation.session.id, new Date(now));
  }

  return {
    session: validation.session,
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      emailVerifiedAt: user.emailVerifiedAt,
      organizationId: membership.organizationId,
      role: toRole(membership.role),
      onboardingCompletedAt: user.onboardingCompletedAt,
    },
  };
}

export async function signOut(
  context: ServiceContext,
  sessionId: string,
  meta: RequestMeta = {},
): Promise<void> {
  const now = clock(context);
  await context.db.sessions.revoke(sessionId, new Date(now));
  await audit(context, {
    action: 'auth.signout',
    entityType: 'session',
    entityId: sessionId,
    outcome: 'success',
    meta,
  });
}

/* -------------------------------------------------------------------------- */
/* Email verification                                                         */
/* -------------------------------------------------------------------------- */

export type VerifyEmailResult =
  | { readonly ok: true; readonly userId: string; readonly token: string }
  | { readonly ok: false; readonly reason: 'invalid-or-expired' };

/**
 * Consumes a verification token. Single-use and expiry are enforced by the
 * repository's `consume`. The session is ROTATED on success, because verifying
 * an email is a privilege change.
 */
export async function verifyEmail(
  context: ServiceContext,
  rawToken: string,
  meta: RequestMeta = {},
): Promise<VerifyEmailResult> {
  const now = clock(context);
  const tokenHash = hashToken(rawToken);

  const record = await context.db.emailVerification.findByTokenHash(tokenHash);
  const consumed = await context.db.emailVerification.consume(tokenHash, new Date(now));
  if (!record || !consumed) {
    await audit(context, {
      action: 'auth.verify_email.failed',
      entityType: 'user',
      outcome: 'failure',
      meta,
    });
    return { ok: false, reason: 'invalid-or-expired' };
  }

  await context.db.users.markEmailVerified(record.userId, new Date(now));
  // Privilege change -> new session token.
  await context.db.sessions.revokeAllForUser(record.userId, new Date(now));
  const created = await startSession(context, record.userId, meta, { sudo: false });

  await audit(context, {
    actorId: record.userId,
    action: 'auth.verify_email',
    entityType: 'user',
    entityId: record.userId,
    outcome: 'success',
    meta,
  });

  return { ok: true, userId: record.userId, token: created.token };
}

export async function resendVerification(
  context: ServiceContext,
  email: string,
): Promise<{ token: string; userId: string } | null> {
  const now = clock(context);
  const user = await context.db.users.findByEmail(email);
  if (!user || user.emailVerifiedAt !== null) return null;

  await context.db.emailVerification.invalidateAllForUser(user.id, new Date(now));
  const issued = generateToken(TOKEN_LIFETIMES.emailVerification, now);
  await context.db.emailVerification.create({
    userId: user.id,
    tokenHash: issued.hash,
    email: user.email,
    expiresAt: issued.expiresAt,
  });
  return { token: issued.token, userId: user.id };
}

/* -------------------------------------------------------------------------- */
/* Password reset                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Always returns void. The caller sends the same HTTP response whether or not
 * the address exists — otherwise the reset form becomes an account-enumeration
 * endpoint, which is the classic way this gets shipped wrong.
 */
export async function requestPasswordReset(
  context: ServiceContext,
  email: string,
  meta: RequestMeta = {},
): Promise<{ token: string; userId: string } | null> {
  const now = clock(context);
  const user = await context.db.users.findByEmail(email);

  if (!user) {
    await audit(context, {
      action: 'auth.password_reset.requested',
      entityType: 'user',
      outcome: 'failure',
      metadata: { reason: 'no-such-user' },
      meta,
    });
    return null;
  }

  // Issuing a new link invalidates any outstanding one.
  await context.db.passwordReset.invalidateAllForUser(user.id, new Date(now));

  const issued = generateToken(TOKEN_LIFETIMES.passwordReset, now);
  await context.db.passwordReset.create({
    userId: user.id,
    tokenHash: issued.hash,
    expiresAt: issued.expiresAt,
    ipHash: hashIpAddress(meta.ipAddress, context.secret),
  });

  await audit(context, {
    actorId: user.id,
    action: 'auth.password_reset.requested',
    entityType: 'user',
    entityId: user.id,
    outcome: 'success',
    meta,
  });

  return { token: issued.token, userId: user.id };
}

export type ResetPasswordResult =
  | { readonly ok: true; readonly userId: string }
  | { readonly ok: false; readonly reason: 'invalid-or-expired' | 'weak-password'; readonly problems?: readonly string[] };

export async function resetPassword(
  context: ServiceContext,
  rawToken: string,
  newPassword: string,
  meta: RequestMeta = {},
): Promise<ResetPasswordResult> {
  const now = clock(context);
  const tokenHash = hashToken(rawToken);

  const record = await context.db.passwordReset.findByTokenHash(tokenHash);
  if (!record) return { ok: false, reason: 'invalid-or-expired' };

  const user = await context.db.users.findById(record.userId);
  if (!user || user.deletedAt !== null) return { ok: false, reason: 'invalid-or-expired' };

  const policy = checkPasswordPolicy(newPassword, [user.email, user.name ?? '']);
  if (!policy.ok) {
    // Do NOT consume the token on a weak password — the user should be able to
    // try again with a better one rather than request a whole new link.
    return { ok: false, reason: 'weak-password', problems: policy.problems };
  }

  const consumed = await context.db.passwordReset.consume(tokenHash, new Date(now));
  if (!consumed) {
    await audit(context, {
      action: 'auth.password_reset.failed',
      entityType: 'user',
      entityId: record.userId,
      outcome: 'failure',
      metadata: { reason: 'token-used-or-expired' },
      meta,
    });
    return { ok: false, reason: 'invalid-or-expired' };
  }

  await context.db.users.setPassword(user.id, await passwordHasher.hash(newPassword), new Date(now));

  // A password reset is the user's response to being compromised: every
  // existing session must die, and the lockout counter is cleared so they are
  // not locked out of the account they just recovered.
  const revoked = await context.db.sessions.revokeAllForUser(user.id, new Date(now));
  context.lockout.clear(accountKey(user.email));

  await audit(context, {
    actorId: user.id,
    action: 'auth.password_reset.completed',
    entityType: 'user',
    entityId: user.id,
    outcome: 'success',
    metadata: { sessionsRevoked: revoked },
    meta,
  });

  return { ok: true, userId: user.id };
}

/* -------------------------------------------------------------------------- */
/* Password change (signed in)                                                */
/* -------------------------------------------------------------------------- */

export async function changePassword(
  context: ServiceContext,
  input: { userId: string; currentPassword: string; newPassword: string; currentSessionId: string },
  meta: RequestMeta = {},
): Promise<
  | { ok: true; token: string; session: SessionRow }
  | { ok: false; reason: 'invalid-credentials' | 'weak-password'; problems?: readonly string[] }
> {
  const now = clock(context);
  const user = await context.db.users.findById(input.userId);
  if (!user || user.passwordHash === null) return { ok: false, reason: 'invalid-credentials' };

  if (!(await passwordHasher.verify(input.currentPassword, user.passwordHash))) {
    await audit(context, {
      actorId: user.id,
      action: 'auth.password_change.failed',
      entityType: 'user',
      entityId: user.id,
      outcome: 'failure',
      meta,
    });
    return { ok: false, reason: 'invalid-credentials' };
  }

  const policy = checkPasswordPolicy(input.newPassword, [user.email, user.name ?? '']);
  if (!policy.ok) return { ok: false, reason: 'weak-password', problems: policy.problems };

  await context.db.users.setPassword(user.id, await passwordHasher.hash(input.newPassword), new Date(now));

  /**
   * THE TOKEN IS ROTATED, not preserved.
   *
   * The header of `session.ts` has said since Phase 2 that "the token is rotated
   * on every privilege change — sign-in, password change, email verification"
   * and named `rotateSession()` as the only correct response. No such function
   * existed, and this line used to keep the current session alive by passing it
   * as `exceptSessionId` — so a password change left the old token valid. Anyone
   * holding it kept their access, which is the one thing a person changing their
   * password is trying to prevent.
   *
   * Rotation here is revoke-and-reissue rather than an in-place token swap: the
   * old row survives as revoked, which is better for an audit trail than
   * overwriting the hash, and it needs no new repository method.
   */
  await context.db.sessions.revokeAllForUser(user.id, new Date(now));
  await context.db.passwordReset.invalidateAllForUser(user.id, new Date(now));

  // Sudo is granted: the user has just proved their password, which is exactly
  // what the sudo window represents. Making them re-enter it seconds later
  // would teach them to type it on demand.
  const rotated = await startSession(context, user.id, meta, { sudo: true });

  await audit(context, {
    actorId: user.id,
    action: 'auth.password_change',
    entityType: 'user',
    entityId: user.id,
    outcome: 'success',
    meta,
  });

  return { ok: true, token: rotated.token, session: rotated.session };
}

/* -------------------------------------------------------------------------- */
/* Account deletion                                                           */
/* -------------------------------------------------------------------------- */

/**
 * Stage 1 of deletion: immediate from the user's point of view.
 * Sign-in stops working, every session dies, outstanding tokens are void.
 * Stage 2 (anonymisation) is the scheduled `anonymize_deleted_user` job in
 * db/migrations/0002_accounts.sql, after the retention window.
 */
export async function deleteAccount(
  context: ServiceContext,
  input: { userId: string; password: string | null; organizationId: string },
  meta: RequestMeta = {},
): Promise<{ ok: true } | { ok: false; reason: 'invalid-credentials' }> {
  const now = clock(context);
  const user = await context.db.users.findById(input.userId);
  if (!user) return { ok: false, reason: 'invalid-credentials' };

  // Password-backed accounts must re-authenticate. OAuth-only accounts rely on
  // the session's sudo window, checked by the caller.
  if (user.passwordHash !== null) {
    if (!input.password || !(await passwordHasher.verify(input.password, user.passwordHash))) {
      await audit(context, {
        organizationId: input.organizationId,
        actorId: user.id,
        action: 'account.delete.failed',
        entityType: 'user',
        entityId: user.id,
        outcome: 'denied',
        metadata: { reason: 'reauthentication-failed' },
        meta,
      });
      return { ok: false, reason: 'invalid-credentials' };
    }
  }

  await context.db.users.softDelete(user.id, new Date(now));
  await context.db.sessions.revokeAllForUser(user.id, new Date(now));
  await context.db.passwordReset.invalidateAllForUser(user.id, new Date(now));
  await context.db.emailVerification.invalidateAllForUser(user.id, new Date(now));
  await context.db.oauth.unlink(user.id, 'google');

  await audit(context, {
    organizationId: input.organizationId,
    actorId: user.id,
    action: 'account.delete.requested',
    entityType: 'user',
    entityId: user.id,
    outcome: 'success',
    metadata: { stage: 'soft-delete', anonymizeAfterDays: 30 },
    meta,
  });

  return { ok: true };
}

/* -------------------------------------------------------------------------- */
/* OAuth account resolution                                                   */
/* -------------------------------------------------------------------------- */

export interface OAuthIdentity {
  readonly provider: 'google';
  readonly providerUserId: string;
  readonly email: string | null;
  readonly emailVerified: boolean;
  readonly name: string | null;
}

export type OAuthSignInResult =
  | { readonly ok: true; readonly token: string; readonly userId: string; readonly created: boolean }
  | { readonly ok: false; readonly reason: 'email-unverified' | 'email-taken' };

/**
 * Signs in (or registers) from a verified OAuth identity.
 *
 * TWO RULES THAT MATTER:
 *  1. An UNVERIFIED provider email is rejected outright. Accepting it would let
 *     anyone who can set an unverified email on a provider account take over the
 *     matching local account.
 *  2. Linking by email to an existing PASSWORD account is refused. Otherwise a
 *     provider-side email change becomes an account-takeover path. The user must
 *     sign in and link the provider deliberately from settings.
 */
export async function signInWithOAuth(
  context: ServiceContext,
  identity: OAuthIdentity,
  meta: RequestMeta = {},
): Promise<OAuthSignInResult> {
  const now = clock(context);

  const existingLink = await context.db.oauth.findByProviderUserId(
    identity.provider,
    identity.providerUserId,
  );

  if (existingLink) {
    const user = await context.db.users.findById(existingLink.userId);
    if (user && user.deletedAt === null) {
      await context.db.oauth.recordLogin(existingLink.id, new Date(now));
      const created = await startSession(context, user.id, meta, { sudo: true });
      await context.db.users.recordLogin(user.id, new Date(now));
      await audit(context, {
        actorId: user.id,
        action: 'auth.signin.oauth',
        entityType: 'session',
        entityId: created.session.id,
        outcome: 'success',
        metadata: { provider: identity.provider },
        meta,
      });
      return { ok: true, token: created.token, userId: user.id, created: false };
    }
  }

  if (!identity.email || !identity.emailVerified) {
    await audit(context, {
      action: 'auth.signin.oauth.denied',
      entityType: 'user',
      outcome: 'denied',
      metadata: { provider: identity.provider, reason: 'email-unverified' },
      meta,
    });
    return { ok: false, reason: 'email-unverified' };
  }

  const byEmail = await context.db.users.findByEmail(identity.email);
  if (byEmail) {
    if (byEmail.passwordHash !== null) {
      await audit(context, {
        actorId: byEmail.id,
        action: 'auth.signin.oauth.denied',
        entityType: 'user',
        entityId: byEmail.id,
        outcome: 'denied',
        metadata: { provider: identity.provider, reason: 'email-belongs-to-password-account' },
        meta,
      });
      return { ok: false, reason: 'email-taken' };
    }
    // An OAuth-only account with the same address: safe to attach.
    const link = await context.db.oauth.link({
      userId: byEmail.id,
      provider: identity.provider,
      providerUserId: identity.providerUserId,
      email: identity.email,
      emailVerified: identity.emailVerified,
    });
    await context.db.oauth.recordLogin(link.id, new Date(now));
    const created = await startSession(context, byEmail.id, meta, { sudo: true });
    return { ok: true, token: created.token, userId: byEmail.id, created: false };
  }

  // New account. The provider has already verified the address, so it is
  // created verified — there is nothing left for us to confirm.
  const user = await context.db.users.create({
    email: identity.email,
    name: identity.name,
    passwordHash: null,
    emailVerifiedAt: new Date(now),
  });

  const organizationName = `${identity.name ?? identity.email.split('@')[0]}'s workspace`;
  const organization = await context.db.organizations.create({
    name: organizationName,
    slug: `${slugify(organizationName)}-${randomUUID().slice(0, 8)}`,
  });
  await context.db.memberships.create({
    organizationId: organization.id,
    userId: user.id,
    role: 'owner',
    createdAt: new Date(now),
  });
  await context.db.subscriptions.create({
    organizationId: organization.id,
    plan: 'free',
    status: 'trialing',
    externalCustomerId: null,
    externalSubscriptionId: null,
    currentPeriodStart: new Date(now),
    currentPeriodEnd: null,
    cancelAtPeriodEnd: false,
    pastDueSince: null,
    canceledAt: null,
    provider: null,
    paymentBrand: null,
    paymentLast4: null,
    paymentExpiryMonth: null,
    paymentExpiryYear: null,
    trialEndsAt: new Date(now + 14 * 24 * 60 * 60 * 1000),
  });

  await context.db.oauth.link({
    userId: user.id,
    provider: identity.provider,
    providerUserId: identity.providerUserId,
    email: identity.email,
    emailVerified: true,
  });

  const created = await startSession(context, user.id, meta, { sudo: true });
  await audit(context, {
    organizationId: organization.id,
    actorId: user.id,
    action: 'auth.signup.oauth',
    entityType: 'user',
    entityId: user.id,
    outcome: 'success',
    metadata: { provider: identity.provider },
    meta,
  });

  return { ok: true, token: created.token, userId: user.id, created: true };
}

/** Stable, non-reversible id for correlating logs without storing an address. */
export function fingerprint(value: string, secret: string): string {
  return createHash('sha256').update(`${secret}:${value}`).digest('hex').slice(0, 16);
}
