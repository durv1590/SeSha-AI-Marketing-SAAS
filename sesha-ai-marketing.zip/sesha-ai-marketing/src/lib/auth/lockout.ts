/**
 * Brute-force protection for sign-in.
 *
 * TWO INDEPENDENT COUNTERS, because each alone is bypassable:
 *
 *  1. PER ACCOUNT — stops an attacker guessing one account's password from many
 *     addresses (a botnet defeats a per-IP limit alone).
 *  2. PER CLIENT ADDRESS — stops credential stuffing, where an attacker tries
 *     one common password against thousands of accounts (a per-account limit
 *     never trips, because each account sees one attempt).
 *
 * Lockout is TEMPORARY and backs off exponentially. Permanent lockout turns a
 * brute-force attempt into a denial-of-service against the real user: anyone
 * who knows an email address could lock its owner out indefinitely.
 *
 * A successful sign-in clears the account counter. The address counter is NOT
 * cleared, so one valid login among many failures does not reset an attacker's
 * budget.
 *
 * Framework-free, deterministic (`now` is injectable) and fully unit tested.
 */

export interface AttemptRecord {
  failures: number;
  firstFailureAt: number;
  lockedUntil: number | null;
}

export interface LockoutStatus {
  readonly locked: boolean;
  readonly retryAfterSeconds: number;
  readonly failuresRemaining: number;
}

export interface LockoutPolicy {
  /** Failures tolerated before the first lockout. */
  readonly threshold: number;
  /** Base lockout, doubled for each subsequent lockout. */
  readonly baseLockoutMs: number;
  readonly maxLockoutMs: number;
  /** Counters reset after this long with no failures. */
  readonly windowMs: number;
}

const MINUTE = 60 * 1000;

export const ACCOUNT_POLICY: LockoutPolicy = {
  threshold: 5,
  baseLockoutMs: 1 * MINUTE,
  maxLockoutMs: 60 * MINUTE,
  windowMs: 30 * MINUTE,
};

/** Looser, because an address may legitimately be a shared office NAT. */
export const ADDRESS_POLICY: LockoutPolicy = {
  threshold: 20,
  baseLockoutMs: 2 * MINUTE,
  maxLockoutMs: 120 * MINUTE,
  windowMs: 60 * MINUTE,
};

export interface LockoutStore {
  status(key: string, policy: LockoutPolicy, now?: number): LockoutStatus;
  recordFailure(key: string, policy: LockoutPolicy, now?: number): LockoutStatus;
  clear(key: string): void;
}

export class MemoryLockoutStore implements LockoutStore {
  private readonly records = new Map<string, AttemptRecord>();

  status(key: string, policy: LockoutPolicy, now: number = Date.now()): LockoutStatus {
    const record = this.records.get(key);
    if (!record) {
      return { locked: false, retryAfterSeconds: 0, failuresRemaining: policy.threshold };
    }
    if (record.lockedUntil !== null && record.lockedUntil > now) {
      return {
        locked: true,
        retryAfterSeconds: Math.ceil((record.lockedUntil - now) / 1000),
        failuresRemaining: 0,
      };
    }
    if (now - record.firstFailureAt > policy.windowMs) {
      this.records.delete(key);
      return { locked: false, retryAfterSeconds: 0, failuresRemaining: policy.threshold };
    }
    return {
      locked: false,
      retryAfterSeconds: 0,
      failuresRemaining: Math.max(0, policy.threshold - record.failures),
    };
  }

  recordFailure(key: string, policy: LockoutPolicy, now: number = Date.now()): LockoutStatus {
    const existing = this.records.get(key);

    if (!existing || now - existing.firstFailureAt > policy.windowMs) {
      const record: AttemptRecord = { failures: 1, firstFailureAt: now, lockedUntil: null };
      this.records.set(key, record);
      this.evictExpired(now, policy);
      return {
        locked: false,
        retryAfterSeconds: 0,
        failuresRemaining: policy.threshold - 1,
      };
    }

    existing.failures += 1;

    if (existing.failures >= policy.threshold) {
      // Exponential back-off on each lockout past the threshold.
      const overage = existing.failures - policy.threshold;
      const duration = Math.min(policy.baseLockoutMs * 2 ** overage, policy.maxLockoutMs);
      existing.lockedUntil = now + duration;
      return {
        locked: true,
        retryAfterSeconds: Math.ceil(duration / 1000),
        failuresRemaining: 0,
      };
    }

    return {
      locked: false,
      retryAfterSeconds: 0,
      failuresRemaining: policy.threshold - existing.failures,
    };
  }

  clear(key: string): void {
    this.records.delete(key);
  }

  private evictExpired(now: number, policy: LockoutPolicy): void {
    if (this.records.size < 10_000) return;
    for (const [key, record] of this.records) {
      const unlocked = record.lockedUntil === null || record.lockedUntil <= now;
      if (unlocked && now - record.firstFailureAt > policy.windowMs) {
        this.records.delete(key);
      }
    }
  }
}

/**
 * Phase 2 uses an in-process store, which is correct for a single instance.
 * A multi-instance deployment MUST replace this with a shared store (Redis, or
 * the `login_attempts` table in db/schema.sql) or an attacker simply spreads
 * attempts across instances. The interface above is the seam.
 */
export const lockoutStore: LockoutStore = new MemoryLockoutStore();

export function accountKey(email: string): string {
  return `account:${email.trim().toLowerCase()}`;
}

export function addressKey(address: string): string {
  return `address:${address}`;
}
