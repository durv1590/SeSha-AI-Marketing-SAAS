/**
 * Password hashing.
 *
 * ALGORITHM CHOICE
 * scrypt, from Node's built-in `crypto`. scrypt is a memory-hard KDF and is an
 * accepted OWASP password-storage choice alongside Argon2id and bcrypt. It is
 * used here rather than Argon2id for one honest reason: Argon2 requires a
 * native npm package, and this project was developed in an environment with no
 * registry access. scrypt is a legitimate production choice, not a compromise
 * on security — but the `PasswordHasher` interface below exists so swapping to
 * Argon2id is a single-file change if you prefer it.
 *
 * PARAMETERS
 * N=2^16 (65536), r=8, p=1, 64-byte output. That is ~64 MiB of memory per
 * hash, above the OWASP minimum of 32 MiB for scrypt at r=8,p=1. Raising N
 * later is safe: the cost parameters are stored in the hash string, old hashes
 * keep verifying, and `needsRehash()` tells you which ones to upgrade on next
 * successful sign-in.
 *
 * STORAGE FORMAT
 *   scrypt$<N>$<r>$<p>$<keylen>$<salt-b64url>$<hash-b64url>
 * Self-describing, so a parameter change never invalidates existing passwords.
 *
 * Plaintext passwords are never stored, never logged, and never returned.
 */

import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';

const scrypt = promisify(scryptCallback) as (
  password: string | Buffer,
  salt: string | Buffer,
  keylen: number,
  options: { N: number; r: number; p: number; maxmem: number },
) => Promise<Buffer>;

export interface ScryptParams {
  readonly N: number;
  readonly r: number;
  readonly p: number;
  readonly keylen: number;
}

/** Current parameters. Raise N over time; old hashes keep working. */
export const CURRENT_PARAMS: ScryptParams = { N: 65_536, r: 8, p: 1, keylen: 64 };

const SALT_BYTES = 16;
const ALGORITHM = 'scrypt';

/** Node's default maxmem (32 MiB) is below what N=65536 needs; size it from the params. */
function maxmemFor(params: ScryptParams): number {
  return 256 * params.N * params.r * 2;
}

function b64url(buffer: Buffer): string {
  return buffer.toString('base64url');
}

export interface PasswordHasher {
  hash(password: string): Promise<string>;
  verify(password: string, stored: string): Promise<boolean>;
  needsRehash(stored: string): boolean;
}

/* -------------------------------------------------------------------------- */
/* Policy                                                                     */
/* -------------------------------------------------------------------------- */

export const PASSWORD_MIN_LENGTH = 12;
/** bcrypt truncates at 72 bytes; scrypt does not, but a cap bounds CPU cost. */
export const PASSWORD_MAX_LENGTH = 200;

export interface PasswordPolicyResult {
  readonly ok: boolean;
  readonly problems: readonly string[];
}

/**
 * Length-first policy, following NIST SP 800-63B: long passphrases beat
 * composition rules. We check length, a small blocklist, and trivial patterns —
 * we do NOT demand a symbol and a digit and an uppercase, which pushes people
 * toward `Password1!` and into password reuse.
 */
export function checkPasswordPolicy(password: string, context: readonly string[] = []): PasswordPolicyResult {
  const problems: string[] = [];
  const value = password.normalize('NFKC');

  if (value.length < PASSWORD_MIN_LENGTH) {
    problems.push(`Use at least ${PASSWORD_MIN_LENGTH} characters.`);
  }
  if (value.length > PASSWORD_MAX_LENGTH) {
    problems.push(`Use at most ${PASSWORD_MAX_LENGTH} characters.`);
  }
  if (/^(.)\1+$/.test(value)) {
    problems.push('Avoid a single repeated character.');
  }
  if (COMMON_PASSWORDS.has(value.toLowerCase())) {
    problems.push('That password appears in breach lists. Choose another.');
  }
  for (const item of context) {
    const trimmed = item.trim().toLowerCase();
    if (trimmed.length >= 4 && value.toLowerCase().includes(trimmed)) {
      problems.push('Do not include your name or email address in your password.');
      break;
    }
  }

  return { ok: problems.length === 0, problems };
}

/**
 * A deliberately small blocklist. In production, check candidate passwords
 * against a breach corpus (for example the Have I Been Pwned k-anonymity range
 * API) — that is a network call, so it belongs in the API route, not here.
 */
const COMMON_PASSWORDS = new Set([
  'password', 'password1', 'password123', 'passw0rd', '123456', '12345678',
  '123456789', '1234567890', 'qwerty', 'qwertyuiop', 'letmein', 'welcome',
  'admin', 'administrator', 'iloveyou', 'monkey', 'dragon', 'football',
  'baseball', 'sunshine', 'princess', 'abc123', 'changeme', 'secret',
  'trustno1', 'passwordpassword', 'correcthorsebatterystaple',
]);

/* -------------------------------------------------------------------------- */
/* Hashing                                                                    */
/* -------------------------------------------------------------------------- */

class ScryptHasher implements PasswordHasher {
  async hash(password: string): Promise<string> {
    const params = CURRENT_PARAMS;
    const salt = randomBytes(SALT_BYTES);
    const derived = await scrypt(password.normalize('NFKC'), salt, params.keylen, {
      N: params.N,
      r: params.r,
      p: params.p,
      maxmem: maxmemFor(params),
    });
    return [
      ALGORITHM,
      params.N,
      params.r,
      params.p,
      params.keylen,
      b64url(salt),
      b64url(derived),
    ].join('$');
  }

  /**
   * Constant-time verification. Returns false for any malformed stored value
   * rather than throwing, so a corrupted row cannot become an auth bypass or a
   * 500 that leaks a stack trace.
   */
  async verify(password: string, stored: string): Promise<boolean> {
    const parsed = parseHash(stored);
    if (!parsed) return false;

    let derived: Buffer;
    try {
      derived = await scrypt(password.normalize('NFKC'), parsed.salt, parsed.params.keylen, {
        N: parsed.params.N,
        r: parsed.params.r,
        p: parsed.params.p,
        maxmem: maxmemFor(parsed.params),
      });
    } catch {
      return false;
    }

    if (derived.length !== parsed.hash.length) return false;
    return timingSafeEqual(derived, parsed.hash);
  }

  /** True when a stored hash uses weaker parameters than the current policy. */
  needsRehash(stored: string): boolean {
    const parsed = parseHash(stored);
    if (!parsed) return true;
    return (
      parsed.params.N < CURRENT_PARAMS.N ||
      parsed.params.r < CURRENT_PARAMS.r ||
      parsed.params.keylen < CURRENT_PARAMS.keylen
    );
  }
}

interface ParsedHash {
  readonly params: ScryptParams;
  readonly salt: Buffer;
  readonly hash: Buffer;
}

export function parseHash(stored: unknown): ParsedHash | null {
  if (typeof stored !== 'string') return null;
  const parts = stored.split('$');
  if (parts.length !== 7) return null;
  const [algorithm, n, r, p, keylen, salt, hash] = parts;
  if (algorithm !== ALGORITHM) return null;

  const params: ScryptParams = {
    N: Number(n),
    r: Number(r),
    p: Number(p),
    keylen: Number(keylen),
  };
  if (
    !Number.isInteger(params.N) ||
    !Number.isInteger(params.r) ||
    !Number.isInteger(params.p) ||
    !Number.isInteger(params.keylen) ||
    params.N < 1024 ||
    params.r < 1 ||
    params.p < 1 ||
    params.keylen < 32 ||
    // Guard against a hostile stored value forcing a huge allocation.
    params.N > 2 ** 20 ||
    params.r > 64 ||
    params.p > 16 ||
    params.keylen > 256
  ) {
    return null;
  }

  try {
    return {
      params,
      salt: Buffer.from(salt ?? '', 'base64url'),
      hash: Buffer.from(hash ?? '', 'base64url'),
    };
  } catch {
    return null;
  }
}

export const passwordHasher: PasswordHasher = new ScryptHasher();

/**
 * A pre-computed hash of a random value, used to spend the same CPU time when
 * an account does not exist as when it does.
 *
 * Without this, "no such user" returns in microseconds while a real user costs
 * ~100ms of scrypt — a timing oracle that lets an attacker enumerate which
 * email addresses have accounts. Sign-in MUST call this on the miss path.
 */
let dummyHashPromise: Promise<string> | null = null;

export async function dummyVerify(password: string): Promise<false> {
  dummyHashPromise ??= passwordHasher.hash(randomBytes(32).toString('base64url'));
  const dummy = await dummyHashPromise;
  await passwordHasher.verify(password, dummy);
  return false;
}
