/**
 * Role-based access control.
 *
 * THE MODEL
 * Roles are per-organization, not global: the same person can be an Admin of
 * their own organization and a Team Member of a client's. A permission check is
 * therefore always (user, organization, permission) — never (user, permission).
 *
 * Roles are ordered, and each inherits everything below it:
 *   user < team_member < manager < admin
 *
 * WHERE THIS IS ENFORCED
 * This module is the single definition of who may do what. It is called from
 * API route handlers and from the repository layer, and PostgreSQL row-level
 * security (db/schema.sql) is a second, independent barrier. The UI also uses
 * it to hide controls — but hiding a control is a courtesy, never a control.
 *
 * Framework-free and fully unit tested.
 */

export const ROLES = ['user', 'team_member', 'manager', 'admin'] as const;
export type Role = (typeof ROLES)[number];

/** Higher rank inherits every permission of the ranks below it. */
const RANK: Record<Role, number> = {
  user: 0,
  team_member: 1,
  manager: 2,
  admin: 3,
};

export function isRole(value: unknown): value is Role {
  return typeof value === 'string' && (ROLES as readonly string[]).includes(value);
}

export function hasAtLeast(role: Role, required: Role): boolean {
  return RANK[role] >= RANK[required];
}

/* -------------------------------------------------------------------------- */
/* Permissions                                                                */
/* -------------------------------------------------------------------------- */

export const PERMISSIONS = [
  // Projects
  'project:read',
  'project:create',
  'project:update',
  'project:delete',
  // Business profile and brand
  'business:read',
  'business:update',
  'brand:read',
  'brand:update',
  // Content and campaigns
  'content:read',
  'content:create',
  'content:publish',
  'campaign:read',
  'campaign:manage',
  // Leads and analytics
  'lead:read',
  'lead:manage',
  'analytics:read',
  // Organization administration
  'member:read',
  'member:invite',
  'member:remove',
  'member:change_role',
  'billing:read',
  'billing:manage',
  'organization:update',
  'organization:delete',
  'audit:read',
  // Website crawling — separate because it touches a third-party system
  'crawl:request',
  'crawl:delete',
] as const;

export type Permission = (typeof PERMISSIONS)[number];

/**
 * The minimum role each permission requires.
 *
 * Written as "minimum role" rather than per-role permission lists so that a new
 * permission cannot be accidentally granted to admin only, or forgotten for a
 * role. `tests/authz.test.ts` asserts every permission has an entry.
 */
const MINIMUM_ROLE: Record<Permission, Role> = {
  'project:read': 'user',
  'project:create': 'manager',
  'project:update': 'team_member',
  'project:delete': 'admin',

  'business:read': 'user',
  'business:update': 'manager',
  'brand:read': 'user',
  'brand:update': 'manager',

  'content:read': 'user',
  'content:create': 'team_member',
  'content:publish': 'manager',
  'campaign:read': 'user',
  'campaign:manage': 'manager',

  'lead:read': 'team_member',
  'lead:manage': 'manager',
  'analytics:read': 'team_member',

  'member:read': 'team_member',
  'member:invite': 'manager',
  'member:remove': 'admin',
  'member:change_role': 'admin',
  'billing:read': 'manager',
  'billing:manage': 'admin',
  'organization:update': 'admin',
  'organization:delete': 'admin',
  'audit:read': 'admin',

  'crawl:request': 'manager',
  'crawl:delete': 'manager',
};

export function can(role: Role, permission: Permission): boolean {
  const required = MINIMUM_ROLE[permission];
  if (!required) return false;
  return hasAtLeast(role, required);
}

export function permissionsFor(role: Role): Permission[] {
  return PERMISSIONS.filter((permission) => can(role, permission));
}

/** The minimum role a permission needs — used by the UI to explain a denial. */
export function minimumRoleFor(permission: Permission): Role | undefined {
  return MINIMUM_ROLE[permission];
}

/* -------------------------------------------------------------------------- */
/* Authorization errors                                                       */
/* -------------------------------------------------------------------------- */

export class AuthorizationError extends Error {
  readonly code = 'FORBIDDEN' as const;
  readonly permission: Permission | undefined;

  constructor(message: string, permission?: Permission) {
    super(message);
    this.name = 'AuthorizationError';
    this.permission = permission;
  }
}

export class AuthenticationError extends Error {
  readonly code = 'UNAUTHENTICATED' as const;

  constructor(message = 'Sign in to continue.') {
    super(message);
    this.name = 'AuthenticationError';
  }
}

/** Throws unless the role carries the permission. Use at every mutation. */
export function requirePermission(role: Role, permission: Permission): void {
  if (!can(role, permission)) {
    const required = minimumRoleFor(permission);
    throw new AuthorizationError(
      `This action requires the ${required ?? 'admin'} role.`,
      permission,
    );
  }
}

export const ROLE_LABELS: Record<Role, string> = {
  user: 'User',
  team_member: 'Team Member',
  manager: 'Manager',
  admin: 'Admin',
};

export const ROLE_DESCRIPTIONS: Record<Role, string> = {
  user: 'Can view projects, business details, brand and content.',
  team_member: 'Can create and edit content, and view leads and analytics.',
  manager: 'Can create projects, publish content, run campaigns and invite members.',
  admin: 'Full control, including billing, member roles and deletion.',
};
