import { cookies, headers } from 'next/headers';

import { getDatabase } from '@/lib/db';
import { lockoutStore } from './lockout';
import { resolveSession, type ResolvedSession, type ServiceContext } from './service';
import { SESSION_COOKIE, csrfCookieOptions, sessionCookieOptions, sessionMaxAgeSeconds } from './session';
import { CSRF_COOKIE, issueCsrfToken } from './csrf';

/**
 * Next.js adapter for the framework-free auth service.
 *
 * Everything security-relevant lives in ./service.ts and its siblings; this
 * file only translates between Next's cookie/header APIs and those functions.
 * Keeping the split means the whole auth flow stays unit-testable without a
 * server (see tests/auth-flow.test.ts).
 */

export const isProduction = process.env.NODE_ENV === 'production';

/**
 * The application secret, used for keyed IP hashing and CSRF signing.
 *
 * In production a missing secret is a hard failure: falling back to a
 * predictable default would make CSRF tokens forgeable, and it would do so
 * silently, which is the worst possible failure mode.
 */
export function appSecret(): string {
  const secret = process.env.AUTH_SECRET;
  if (secret && secret.length >= 32) return secret;
  if (isProduction) {
    throw new Error(
      'AUTH_SECRET is missing or shorter than 32 bytes. Generate one with: openssl rand -base64 48',
    );
  }
  return 'development-only-insecure-secret-do-not-ship-0000';
}

export function serviceContext(): ServiceContext {
  return { db: getDatabase(), lockout: lockoutStore, secret: appSecret() };
}

/** Resolves the signed-in user, or null. Safe to call from any server component. */
export async function getCurrentSession(): Promise<ResolvedSession | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value ?? null;
  return resolveSession(serviceContext(), token);
}

/** For layouts and pages that must have a user. Redirect is the caller's job. */
export async function requireCurrentSession(): Promise<ResolvedSession> {
  const session = await getCurrentSession();
  if (!session) throw new Error('UNAUTHENTICATED');
  return session;
}

/** Sets the session cookie and issues a matching CSRF token. */
export async function establishSession(token: string, sessionId: string): Promise<void> {
  const store = await cookies();
  store.set(SESSION_COOKIE, token, sessionCookieOptions(isProduction, sessionMaxAgeSeconds()));
  store.set(
    CSRF_COOKIE,
    issueCsrfToken(sessionId, appSecret()),
    csrfCookieOptions(isProduction, sessionMaxAgeSeconds()),
  );
}

export async function clearSessionCookies(): Promise<void> {
  const store = await cookies();
  store.set(SESSION_COOKIE, '', sessionCookieOptions(isProduction, 0));
  store.set(CSRF_COOKIE, '', csrfCookieOptions(isProduction, 0));
}

/** Client address and user agent, for rate limiting and audit records. */
export async function requestMeta(): Promise<{ ipAddress: string | null; userAgent: string | null }> {
  const headerList = await headers();
  const forwarded = headerList.get('x-forwarded-for');
  const ipAddress = forwarded?.split(',')[0]?.trim() ?? headerList.get('x-real-ip') ?? null;
  return { ipAddress, userAgent: headerList.get('user-agent') };
}
