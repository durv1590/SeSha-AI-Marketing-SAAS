/**
 * Opaque token generation and storage.
 *
 * USED FOR: session tokens, email-verification links, password-reset links.
 *
 * THE RULE THESE ALL FOLLOW
 * The token the user holds is high-entropy random bytes. What the DATABASE
 * stores is a SHA-256 hash of that token. A database leak therefore yields no
 * usable sessions and no usable reset links — the attacker has hashes, and the
 * only thing that verifies against them is the original token they do not have.
 *
 * SHA-256 without a salt is correct here and would be wrong for passwords. The
 * input is already 256 bits of uniform randomness, so there is nothing to brute
 * force and nothing to rainbow-table; the slow, salted KDF in password.ts
 * exists because human-chosen passwords have low entropy. Using scrypt for
 * session lookups would add ~100ms to every authenticated request for no gain.
 *
 * Framework-free and fully unit tested.
 */

import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

/** 256 bits. Well beyond any feasible online or offline guessing attack. */
export const TOKEN_BYTES = 32;

export interface IssuedToken {
  /** Given to the user once, in a cookie or an email link. Never stored. */
  readonly token: string;
  /** Stored in the database. Safe to log at debug level; useless on its own. */
  readonly hash: string;
  readonly expiresAt: Date;
}

export interface TokenLifetimes {
  readonly session: number;
  readonly emailVerification: number;
  readonly passwordReset: number;
  /** Re-authentication window for sensitive actions (account deletion). */
  readonly sudo: number;
}

const MINUTE = 60 * 1000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

export const TOKEN_LIFETIMES: TokenLifetimes = {
  session: 30 * DAY,
  emailVerification: 24 * HOUR,
  // Short on purpose: a reset link is a full account takeover if intercepted.
  passwordReset: 30 * MINUTE,
  sudo: 15 * MINUTE,
};

/** Absolute session cap, independent of activity. Forces periodic re-auth. */
export const SESSION_ABSOLUTE_LIFETIME = 90 * DAY;
/** Sliding window: a session idle longer than this expires. */
export const SESSION_IDLE_TIMEOUT = 14 * DAY;

export function generateToken(lifetimeMs: number, now: number = Date.now()): IssuedToken {
  const token = randomBytes(TOKEN_BYTES).toString('base64url');
  return {
    token,
    hash: hashToken(token),
    expiresAt: new Date(now + lifetimeMs),
  };
}

/** SHA-256, hex. Deterministic, so a lookup is a single indexed query. */
export function hashToken(token: string): string {
  return createHash('sha256').update(token, 'utf8').digest('hex');
}

/**
 * Constant-time comparison of two token hashes.
 *
 * Lookups go through an indexed equality query on the hash, which is already
 * constant-time from the attacker's perspective. This exists for the cases
 * where a hash is compared in application code.
 */
export function tokensMatch(a: string, b: string): boolean {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const left = Buffer.from(a, 'utf8');
  const right = Buffer.from(b, 'utf8');
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

export function isExpired(expiresAt: Date | string | null | undefined, now: number = Date.now()): boolean {
  if (!expiresAt) return true;
  const time = expiresAt instanceof Date ? expiresAt.getTime() : Date.parse(expiresAt);
  if (!Number.isFinite(time)) return true;
  return time <= now;
}

/**
 * A short, human-typable code for email verification, as an alternative to
 * clicking a link. Digits only, so it survives being read over the phone.
 * Lower entropy than a link token, which is why it is rate-limited and
 * attempt-capped at the call site.
 */
export function generateNumericCode(digits = 6): string {
  const max = 10 ** digits;
  // Rejection sampling: `% max` on raw bytes would bias the low digits.
  const limit = Math.floor(0xff_ff_ff_ff / max) * max;
  let value: number;
  do {
    value = randomBytes(4).readUInt32BE(0);
  } while (value >= limit);
  return String(value % max).padStart(digits, '0');
}
