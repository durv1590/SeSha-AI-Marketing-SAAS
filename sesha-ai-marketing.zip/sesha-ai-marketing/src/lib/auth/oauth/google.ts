/**
 * Google Sign-In — OAuth 2.0 Authorization Code flow with PKCE.
 *
 * Implemented directly against Google's OpenID Connect endpoints using `fetch`
 * and Node's `crypto`, with no auth library. That is a deliberate choice: it
 * adds no dependency, and every security-relevant step is visible and testable
 * rather than hidden behind configuration.
 *
 * THE FOUR CHECKS THAT MATTER, all implemented below:
 *
 *  1. STATE — a random value stored in an httpOnly cookie and compared on the
 *     callback. Without it, an attacker can complete the flow in the victim's
 *     browser and link their own Google account to the victim's session (login
 *     CSRF).
 *
 *  2. PKCE — a random verifier, its SHA-256 challenge sent up front, the
 *     verifier sent at exchange. Without it, an intercepted authorization code
 *     can be redeemed by whoever stole it.
 *
 *  3. NONCE — random, sent in the request and required to match inside the ID
 *     token. This is what stops a token minted for a different session being
 *     replayed into this one.
 *
 *  4. ID TOKEN SIGNATURE AND CLAIMS — verified against Google's published JWKS
 *     (RS256), then `iss`, `aud`, `exp`, `iat` and `nonce` are all checked.
 *     Decoding a JWT without verifying its signature is the single most common
 *     OAuth implementation bug; `verifyIdToken` refuses to return an identity
 *     until every check has passed.
 *
 * `email_verified` is enforced by the caller (`signInWithOAuth`), which refuses
 * an unverified address.
 */

import { createHash, createPublicKey, createVerify, randomBytes, timingSafeEqual } from 'node:crypto';

export const GOOGLE_AUTH_ENDPOINT = 'https://accounts.google.com/o/oauth2/v2/auth';
export const GOOGLE_TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token';
export const GOOGLE_JWKS_URI = 'https://www.googleapis.com/oauth2/v3/certs';
export const GOOGLE_ISSUERS = ['https://accounts.google.com', 'accounts.google.com'] as const;

export interface GoogleConfig {
  readonly clientId: string;
  readonly clientSecret: string;
  readonly redirectUri: string;
}

export function readGoogleConfig(): GoogleConfig | null {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
  const redirectUri = process.env.GOOGLE_REDIRECT_URI;
  if (!clientId || !clientSecret || !redirectUri) return null;
  return { clientId, clientSecret, redirectUri };
}

export const googleIsConfigured = (): boolean => readGoogleConfig() !== null;

/* -------------------------------------------------------------------------- */
/* PKCE and state                                                             */
/* -------------------------------------------------------------------------- */

export interface AuthorizationRequest {
  readonly url: string;
  /** All three go into a short-lived httpOnly cookie, never into the URL alone. */
  readonly state: string;
  readonly nonce: string;
  readonly codeVerifier: string;
}

/** RFC 7636: 43–128 characters from the unreserved set. 32 bytes base64url = 43. */
export function generateCodeVerifier(): string {
  return randomBytes(32).toString('base64url');
}

/** S256 challenge. The `plain` method is not implemented, on purpose. */
export function deriveCodeChallenge(verifier: string): string {
  return createHash('sha256').update(verifier, 'ascii').digest('base64url');
}

export function buildAuthorizationUrl(
  config: GoogleConfig,
  options: { state?: string; nonce?: string; codeVerifier?: string; loginHint?: string } = {},
): AuthorizationRequest {
  const state = options.state ?? randomBytes(24).toString('base64url');
  const nonce = options.nonce ?? randomBytes(24).toString('base64url');
  const codeVerifier = options.codeVerifier ?? generateCodeVerifier();

  const url = new URL(GOOGLE_AUTH_ENDPOINT);
  url.searchParams.set('client_id', config.clientId);
  url.searchParams.set('redirect_uri', config.redirectUri);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('scope', 'openid email profile');
  url.searchParams.set('state', state);
  url.searchParams.set('nonce', nonce);
  url.searchParams.set('code_challenge', deriveCodeChallenge(codeVerifier));
  url.searchParams.set('code_challenge_method', 'S256');
  // No refresh token is requested: we do not call Google APIs on the user's
  // behalf, so storing long-lived credentials would be an unnecessary liability.
  url.searchParams.set('access_type', 'online');
  url.searchParams.set('prompt', 'select_account');
  if (options.loginHint) url.searchParams.set('login_hint', options.loginHint);

  return { url: url.toString(), state, nonce, codeVerifier };
}

export function statesMatch(a: string | null | undefined, b: string | null | undefined): boolean {
  if (!a || !b) return false;
  const left = Buffer.from(a, 'utf8');
  const right = Buffer.from(b, 'utf8');
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

/* -------------------------------------------------------------------------- */
/* Token exchange                                                             */
/* -------------------------------------------------------------------------- */

export interface TokenResponse {
  readonly id_token: string;
  readonly access_token?: string;
  readonly expires_in?: number;
  readonly token_type?: string;
}

export type ExchangeResult =
  | { readonly ok: true; readonly tokens: TokenResponse }
  | { readonly ok: false; readonly error: string };

export async function exchangeCode(
  config: GoogleConfig,
  code: string,
  codeVerifier: string,
  fetchImpl: typeof fetch = fetch,
): Promise<ExchangeResult> {
  const body = new URLSearchParams({
    code,
    client_id: config.clientId,
    client_secret: config.clientSecret,
    redirect_uri: config.redirectUri,
    grant_type: 'authorization_code',
    code_verifier: codeVerifier,
  });

  try {
    const response = await fetchImpl(GOOGLE_TOKEN_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
      body: body.toString(),
    });

    if (!response.ok) {
      // Never surface the provider's raw error to the browser — it can contain
      // the client_id and other configuration detail.
      return { ok: false, error: `token_endpoint_status_${response.status}` };
    }

    const payload = (await response.json()) as Partial<TokenResponse>;
    if (typeof payload.id_token !== 'string') {
      return { ok: false, error: 'missing_id_token' };
    }
    return { ok: true, tokens: payload as TokenResponse };
  } catch {
    return { ok: false, error: 'token_endpoint_unreachable' };
  }
}

/* -------------------------------------------------------------------------- */
/* ID token verification                                                      */
/* -------------------------------------------------------------------------- */

interface Jwk {
  readonly kty: string;
  readonly kid: string;
  readonly n?: string;
  readonly e?: string;
  readonly alg?: string;
  readonly use?: string;
}

export interface IdTokenClaims {
  readonly iss: string;
  readonly aud: string | string[];
  readonly sub: string;
  readonly exp: number;
  readonly iat: number;
  readonly nonce?: string;
  readonly email?: string;
  readonly email_verified?: boolean;
  readonly name?: string;
  readonly picture?: string;
  readonly hd?: string;
}

export type VerifyResult =
  | { readonly ok: true; readonly claims: IdTokenClaims }
  | { readonly ok: false; readonly error: VerifyError };

export type VerifyError =
  | 'malformed'
  | 'unsupported_algorithm'
  | 'unknown_key'
  | 'bad_signature'
  | 'bad_issuer'
  | 'bad_audience'
  | 'expired'
  | 'issued_in_future'
  | 'nonce_mismatch'
  | 'missing_subject';

/** Small clock-skew allowance, so a correct token is not rejected by drift. */
const CLOCK_SKEW_SECONDS = 60;

function decodeSegment(segment: string): unknown {
  return JSON.parse(Buffer.from(segment, 'base64url').toString('utf8')) as unknown;
}

/**
 * Verifies signature and claims. Returns claims ONLY when every check passes.
 *
 * `jwks` is injected rather than fetched here so the verification logic is
 * testable without network access — `fetchGoogleJwks` does the fetching.
 */
export function verifyIdToken(
  idToken: string,
  jwks: readonly Jwk[],
  expected: { clientId: string; nonce?: string | null },
  now: number = Date.now(),
): VerifyResult {
  const parts = idToken.split('.');
  if (parts.length !== 3) return { ok: false, error: 'malformed' };
  const [headerSegment, payloadSegment, signatureSegment] = parts as [string, string, string];

  let header: { alg?: string; kid?: string };
  let claims: IdTokenClaims;
  try {
    header = decodeSegment(headerSegment) as { alg?: string; kid?: string };
    claims = decodeSegment(payloadSegment) as IdTokenClaims;
  } catch {
    return { ok: false, error: 'malformed' };
  }

  // Only RS256. Accepting "none", or letting the token choose a symmetric
  // algorithm, is the classic JWT confusion attack.
  if (header.alg !== 'RS256') return { ok: false, error: 'unsupported_algorithm' };

  const key = jwks.find((candidate) => candidate.kid === header.kid && candidate.kty === 'RSA');
  if (!key || !key.n || !key.e) return { ok: false, error: 'unknown_key' };

  let verified = false;
  try {
    const publicKey = createPublicKey({
      key: { kty: 'RSA', n: key.n, e: key.e },
      format: 'jwk',
    });
    verified = createVerify('RSA-SHA256')
      .update(`${headerSegment}.${payloadSegment}`)
      .verify(publicKey, Buffer.from(signatureSegment, 'base64url'));
  } catch {
    return { ok: false, error: 'bad_signature' };
  }
  if (!verified) return { ok: false, error: 'bad_signature' };

  // Signature is good; now the claims.
  if (!GOOGLE_ISSUERS.includes(claims.iss as (typeof GOOGLE_ISSUERS)[number])) {
    return { ok: false, error: 'bad_issuer' };
  }

  const audiences = Array.isArray(claims.aud) ? claims.aud : [claims.aud];
  if (!audiences.includes(expected.clientId)) return { ok: false, error: 'bad_audience' };

  const nowSeconds = Math.floor(now / 1000);
  if (typeof claims.exp !== 'number' || claims.exp + CLOCK_SKEW_SECONDS < nowSeconds) {
    return { ok: false, error: 'expired' };
  }
  if (typeof claims.iat !== 'number' || claims.iat - CLOCK_SKEW_SECONDS > nowSeconds) {
    return { ok: false, error: 'issued_in_future' };
  }

  if (expected.nonce) {
    if (!claims.nonce || !statesMatch(claims.nonce, expected.nonce)) {
      return { ok: false, error: 'nonce_mismatch' };
    }
  }

  if (typeof claims.sub !== 'string' || claims.sub.length === 0) {
    return { ok: false, error: 'missing_subject' };
  }

  return { ok: true, claims };
}

/* -------------------------------------------------------------------------- */
/* JWKS                                                                       */
/* -------------------------------------------------------------------------- */

let jwksCache: { keys: Jwk[]; fetchedAt: number } | null = null;
const JWKS_TTL_MS = 60 * 60 * 1000;

/**
 * Fetches and caches Google's signing keys.
 *
 * Cached because Google rotates keys slowly and a fetch per sign-in would make
 * the provider a hard dependency of every login. On a cache miss for an unknown
 * `kid`, the caller should refetch once — `fetchGoogleJwks(true)` forces it.
 */
export async function fetchGoogleJwks(
  force = false,
  fetchImpl: typeof fetch = fetch,
  now: number = Date.now(),
): Promise<Jwk[]> {
  if (!force && jwksCache && now - jwksCache.fetchedAt < JWKS_TTL_MS) {
    return jwksCache.keys;
  }
  const response = await fetchImpl(GOOGLE_JWKS_URI, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    if (jwksCache) return jwksCache.keys;
    throw new Error(`Could not fetch Google signing keys (${response.status}).`);
  }
  const payload = (await response.json()) as { keys?: Jwk[] };
  const keys = Array.isArray(payload.keys) ? payload.keys : [];
  jwksCache = { keys, fetchedAt: now };
  return keys;
}

/** Test helper. */
export function clearJwksCache(): void {
  jwksCache = null;
}

/** Maps verified claims onto the provider-agnostic identity the service takes. */
export function toIdentity(claims: IdTokenClaims): {
  provider: 'google';
  providerUserId: string;
  email: string | null;
  emailVerified: boolean;
  name: string | null;
} {
  return {
    provider: 'google',
    providerUserId: claims.sub,
    email: claims.email ?? null,
    emailVerified: claims.email_verified === true,
    name: claims.name ?? null,
  };
}
