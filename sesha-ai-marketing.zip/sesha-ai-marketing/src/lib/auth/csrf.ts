/**
 * CSRF protection.
 *
 * STRATEGY: signed double-submit cookie.
 *
 * A random value is placed in a cookie and, HMAC-signed and bound to the
 * session, sent to the client to echo back in a header or form field. A request
 * is accepted only when the header value verifies against the cookie value AND
 * the signature binds it to the current session.
 *
 * Why signed rather than plain double-submit: an attacker who can write a
 * cookie on a sibling subdomain can otherwise set both halves and forge a
 * request. Binding the token to the session id with an HMAC the attacker cannot
 * compute closes that.
 *
 * Defence in depth, not the only layer. SameSite=Lax on the session cookie
 * blocks the common cross-site POST, and the Origin check below blocks the rest.
 * All three run.
 *
 * Framework-free and fully unit tested.
 */

import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';

const CSRF_BYTES = 24;
export const CSRF_COOKIE = 'sesha_csrf';
export const CSRF_HEADER = 'x-csrf-token';
export const CSRF_FIELD = 'csrfToken';

/** Methods that cannot change state and therefore need no CSRF token. */
const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

export function isSafeMethod(method: string): boolean {
  return SAFE_METHODS.has(method.toUpperCase());
}

/**
 * Issues a token bound to a session.
 * Format: <random-b64url>.<hmac-b64url>
 */
export function issueCsrfToken(sessionId: string, secret: string): string {
  const value = randomBytes(CSRF_BYTES).toString('base64url');
  return `${value}.${sign(value, sessionId, secret)}`;
}

function sign(value: string, sessionId: string, secret: string): string {
  return createHmac('sha256', secret).update(`${value}.${sessionId}`).digest('base64url');
}

function constantTimeEqual(a: string, b: string): boolean {
  const left = Buffer.from(a, 'utf8');
  const right = Buffer.from(b, 'utf8');
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

export type CsrfFailure =
  | 'missing-cookie'
  | 'missing-token'
  | 'mismatch'
  | 'bad-signature'
  | 'malformed';

export type CsrfResult = { readonly ok: true } | { readonly ok: false; readonly reason: CsrfFailure };

/**
 * Verifies a state-changing request.
 * `cookieValue` is the token from the CSRF cookie; `submitted` is the value
 * from the request header or form body.
 */
export function verifyCsrf(
  cookieValue: string | null | undefined,
  submitted: string | null | undefined,
  sessionId: string,
  secret: string,
): CsrfResult {
  if (!cookieValue) return { ok: false, reason: 'missing-cookie' };
  if (!submitted) return { ok: false, reason: 'missing-token' };
  if (!constantTimeEqual(cookieValue, submitted)) return { ok: false, reason: 'mismatch' };

  const parts = cookieValue.split('.');
  if (parts.length !== 2) return { ok: false, reason: 'malformed' };
  const [value, signature] = parts;
  if (!value || !signature) return { ok: false, reason: 'malformed' };

  if (!constantTimeEqual(signature, sign(value, sessionId, secret))) {
    return { ok: false, reason: 'bad-signature' };
  }
  return { ok: true };
}

/**
 * Origin / Referer check.
 *
 * A cross-site POST from a browser always carries an Origin header, so a
 * mismatch is a forgery. A REQUEST WITH NO ORIGIN IS REJECTED for state-changing
 * methods: same-origin fetch and form posts both send it, and accepting the
 * absence would hand an attacker a trivial bypass.
 */
export function verifyOrigin(
  origin: string | null | undefined,
  referer: string | null | undefined,
  allowedOrigin: string,
): boolean {
  const expected = normalizeOrigin(allowedOrigin);
  if (!expected) return false;

  if (origin) return normalizeOrigin(origin) === expected;

  // Some older clients omit Origin on same-origin form posts but send Referer.
  if (referer) {
    try {
      return normalizeOrigin(new URL(referer).origin) === expected;
    } catch {
      return false;
    }
  }
  return false;
}

function normalizeOrigin(value: string): string | null {
  try {
    const url = new URL(value);
    return url.origin.toLowerCase();
  } catch {
    return null;
  }
}
