/**
 * Authentication architecture — Phase 2 placeholder.
 *
 * NOTHING here is wired up, and that is deliberate: the Phase 1 site has no
 * accounts, so shipping a half-built auth system would add attack surface for
 * no capability. What this module does is fix the CONTRACT, so Phase 2 fills in
 * implementations rather than inventing a shape.
 *
 * Decisions recorded now (so Phase 2 does not re-litigate them):
 *  - Sessions are server-side records referenced by an opaque, random token in
 *    an httpOnly, Secure, SameSite=Lax cookie. Not a JWT in localStorage.
 *  - Passwords are hashed with Argon2id. Never MD5, SHA-*, or a bare bcrypt
 *    round count chosen by vibes.
 *  - Every mutating request carries a CSRF token checked against the session.
 *  - Authorisation is checked at the data layer by organization_id, never only
 *    in the UI.
 *  - Sign-in attempts are rate-limited per account AND per client address.
 */

export type Role = 'owner' | 'admin' | 'editor' | 'viewer';

export interface SessionUser {
  readonly id: string;
  readonly email: string;
  readonly name: string | null;
  readonly organizationId: string;
  readonly role: Role;
}

export interface Session {
  readonly user: SessionUser;
  readonly expiresAt: Date;
}

/** Phase 1 has no sessions. Always null — never throws, so callers stay simple. */
export async function getSession(): Promise<Session | null> {
  return null;
}

export async function requireSession(): Promise<Session> {
  throw new Error('Authentication is not available in Phase 1.');
}

const roleRank: Record<Role, number> = { viewer: 0, editor: 1, admin: 2, owner: 3 };

/** Role comparison, usable now so permission checks are written consistently. */
export function hasAtLeast(role: Role, required: Role): boolean {
  return roleRank[role] >= roleRank[required];
}

export const authIsEnabled = false;
