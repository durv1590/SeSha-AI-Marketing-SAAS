/**
 * Transactional email.
 *
 * Phase 2 has no SMTP provider wired up, so this module DOES NOT SEND EMAIL.
 * It logs a structured record that a message was due, with the link redacted
 * unless `EMAIL_DEBUG=true` in development.
 *
 * That is a deliberate, visible gap rather than a hidden one: pretending to
 * send would leave users waiting for a verification link that never arrives.
 * `emailIsConfigured` is false, the dashboard surfaces it, and the deployment
 * checklist in README calls it out.
 *
 * To enable: set SMTP_URL and implement `deliver()` with your provider.
 */

import { site } from '@/content/site';

export const emailIsConfigured: boolean = Boolean(process.env.SMTP_URL);

export interface OutboundEmail {
  readonly to: string;
  readonly subject: string;
  readonly text: string;
  /** Never logged in production. */
  readonly actionUrl?: string;
}

function baseUrl(): string {
  return (process.env.NEXT_PUBLIC_SITE_URL ?? site.url).replace(/\/+$/, '');
}

function redactedDomain(address: string): string {
  return `***@${address.split('@')[1] ?? 'unknown'}`;
}

async function deliver(message: OutboundEmail): Promise<void> {
  if (!emailIsConfigured) {
    const showLink = process.env.EMAIL_DEBUG === 'true' && process.env.NODE_ENV !== 'production';
    console.warn(
      JSON.stringify({
        event: 'email.not_sent',
        reason: 'SMTP_URL is not configured',
        to: redactedDomain(message.to),
        subject: message.subject,
        // In development this is how you complete a signup without a mailbox.
        ...(showLink && message.actionUrl ? { actionUrl: message.actionUrl } : {}),
      }),
    );
    return;
  }

  // Phase 3: deliver through the configured provider. Kept as an explicit
  // throw rather than a silent no-op so a misconfiguration is loud.
  throw new Error('SMTP_URL is set but no email provider is implemented yet.');
}

export async function sendVerificationEmail(to: string, token: string): Promise<void> {
  const actionUrl = `${baseUrl()}/verify-email?token=${encodeURIComponent(token)}`;
  await deliver({
    to,
    subject: `Confirm your email for ${site.shortName}`,
    text: `Confirm your email address to finish setting up your ${site.name} account:\n\n${actionUrl}\n\nThis link expires in 24 hours. If you did not create an account, you can ignore this message.`,
    actionUrl,
  });
}

/**
 * Sent to the OWNER of an address when someone tries to sign up with it again.
 *
 * This is what makes enumeration-safe signup honest: the person trying to
 * register learns nothing, and the actual account holder is told.
 */
export async function sendDuplicateSignupEmail(to: string): Promise<void> {
  await deliver({
    to,
    subject: `Someone tried to sign up with your email`,
    text: `Someone tried to create a ${site.name} account with this address, which already has one.\n\nIf that was you, sign in instead: ${baseUrl()}/sign-in\nIf you have forgotten your password: ${baseUrl()}/forgot-password\n\nIf it was not you, no action is needed — no account was created and nothing has changed.`,
  });
}

export async function sendPasswordResetEmail(to: string, token: string): Promise<void> {
  const actionUrl = `${baseUrl()}/reset-password?token=${encodeURIComponent(token)}`;
  await deliver({
    to,
    subject: `Reset your ${site.shortName} password`,
    text: `Use this link to choose a new password:\n\n${actionUrl}\n\nThis link expires in 30 minutes and can be used once. If you did not request it, you can ignore this message — your password has not changed.`,
    actionUrl,
  });
}

export async function sendPasswordChangedEmail(to: string): Promise<void> {
  await deliver({
    to,
    subject: `Your ${site.shortName} password was changed`,
    text: `Your password was just changed, and every other signed-in device has been signed out.\n\nIf this was not you, reset your password immediately: ${baseUrl()}/forgot-password`,
  });
}
