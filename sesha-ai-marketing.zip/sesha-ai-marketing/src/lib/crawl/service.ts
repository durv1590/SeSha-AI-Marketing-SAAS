/**
 * Crawl and audit service.
 *
 * CONSENT IS CHECKED HERE, AND IT IS CHECKED TWICE.
 * Once when the job is queued, and again when the worker picks it up — because a
 * user can withdraw consent in the minutes between the two, and a crawl that
 * started under a grant that no longer exists is a crawl with no authorisation.
 * The second check is the one that matters.
 *
 * The limits applied are the intersection of the plan ceiling and the consent
 * record's own `maxPages`. Neither can raise the other.
 *
 * WHAT RUNS WHERE
 * This module queues jobs and executes them; it does not decide when. In this
 * deployment a job is executed inline after being queued (there is no separate
 * worker process yet), which is why `runJob` is exported separately from
 * `requestCrawl` — a real worker calls the same function.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { enforceOrThrow } from '@/lib/quota/service';
import { NotFoundError, assertTenant, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type {
  AuditRow,
  CrawlConsentRow,
  CrawlRow,
  CrawledPageRow,
  JobRow,
  KeywordRow,
  Plan,
} from '@/lib/db/types';
import {
  crawlSite,
  resolveLimits,
  type CrawlGrant,
  type CrawlLimits,
  type CrawlReport,
  type FetchOptions,
  type PageData,
} from '@/lib/crawler';
import { auditSeo } from '@/lib/audit/seo';
import { auditAeo } from '@/lib/audit/aeo';
import { extractKeywords } from '@/lib/keywords/extract';
import {
  MAX_ATTEMPTS,
  STALE_RUNNING_MS,
  canRetry,
  canTransition,
  explainFailure,
  isStale,
  progressOf,
  retryDelayMs,
  type JobKind,
} from '@/lib/jobs/types';

export interface CrawlServiceContext {
  readonly db: Database;
  readonly now?: () => number;
  /** Injected in tests so a crawl runs against a fake transport. */
  readonly fetchOptions?: FetchOptions;
  readonly sleep?: (ms: number) => Promise<void>;
}

function clock(context: CrawlServiceContext): number {
  return context.now?.() ?? Date.now();
}

export class ConsentRequiredError extends Error {
  readonly code = 'NO_CONSENT' as const;
  constructor(message = 'Crawling this site has not been authorised for this project.') {
    super(message);
    this.name = 'ConsentRequiredError';
  }
}

export class JobConflictError extends Error {
  readonly code = 'JOB_ACTIVE' as const;
  constructor(public readonly existingJobId: string) {
    super('A job of this kind is already running for this project.');
    this.name = 'JobConflictError';
  }
}

/* -------------------------------------------------------------------------- */
/* Consent                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Resolves the grant for a project, or refuses.
 *
 * Refuses when there is no consent record, when it has been revoked, when its
 * data has already been deleted, or when the requested site is not the one the
 * user consented to. The last case matters: a consent record authorises ONE
 * site, and crawling a different one on the strength of it is not authorised.
 */
export async function resolveGrant(
  context: CrawlServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<{ grant: CrawlGrant; consent: CrawlConsentRow }> {
  const consent = await context.db.crawlConsents.findActiveForProject(tenant.organizationId, projectId);

  if (!consent) throw new ConsentRequiredError();
  if (consent.revokedAt !== null) {
    throw new ConsentRequiredError('Crawl permission for this project has been withdrawn.');
  }
  if (consent.websiteUrl.trim().length === 0) {
    throw new ConsentRequiredError('The consent record names no website to crawl.');
  }

  return {
    consent,
    grant: {
      websiteUrl: consent.websiteUrl,
      respectRobots: consent.respectRobots,
      maxPages: consent.maxPages,
      grantedAt: consent.grantedAt,
    },
  };
}

async function planFor(context: CrawlServiceContext, organizationId: string): Promise<Plan> {
  const subscription = await context.db.subscriptions.findForOrganization(organizationId);
  return subscription?.plan ?? 'free';
}

/* -------------------------------------------------------------------------- */
/* Queueing                                                                   */
/* -------------------------------------------------------------------------- */

export interface RequestJobInput {
  readonly projectId: string;
  readonly kind: JobKind;
  /** Narrows the plan ceiling; can never raise it. */
  readonly maxPages?: number;
  readonly maxDepth?: number;
}

/**
 * Queues a job.
 *
 * Refuses a second job of the same kind for the same project — the database has
 * a partial unique index saying the same thing, and this is the check that
 * produces a usable message rather than a constraint violation.
 */
export async function requestJob(
  context: CrawlServiceContext,
  tenant: TenantContext,
  input: RequestJobInput,
): Promise<JobRow> {
  requirePermission(tenant.role, input.kind === 'crawl' ? 'crawl:request' : 'content:create');

  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, input.projectId),
    'Project',
  );

  // The plan limit, checked BEFORE the job is queued. Refusing after a crawl has
  // run would mean we paid for the work and then told the customer they were not
  // allowed to have it.
  // `CrawlServiceContext.now` returns epoch millis and the quota service takes a
  // Date; adapted here rather than changing a contract four phases old.
  await enforceOrThrow(
    { db: context.db, now: () => new Date(clock(context)) },
    tenant.organizationId,
    input.kind === 'crawl' ? 'website_crawls' : input.kind === 'seo_audit' ? 'seo_audits' : 'aeo_audits',
    { projectId: project.id, userId: tenant.userId },
  );

  // Consent is required to queue a crawl at all. An audit runs on stored pages,
  // so it does not need a live grant — but it does need a crawl to have happened.
  if (input.kind === 'crawl') {
    await resolveGrant(context, tenant, project.id);
  } else {
    const latest = await context.db.crawls.findLatest(tenant.organizationId, project.id);
    if (!latest || latest.pagesCrawled === 0) {
      throw new ConsentRequiredError(
        'There is no completed crawl for this project yet, so there is nothing to audit.',
      );
    }
  }

  const active = await context.db.jobs.findActive(tenant.organizationId, project.id, input.kind);
  if (active) throw new JobConflictError(active.id);

  const plan = await planFor(context, tenant.organizationId);
  const limits = resolveLimits(plan, {
    ...(input.maxPages === undefined ? {} : { maxPages: input.maxPages }),
    ...(input.maxDepth === undefined ? {} : { maxDepth: input.maxDepth }),
  });

  return context.db.jobs.create({
    organizationId: tenant.organizationId,
    projectId: project.id,
    createdBy: tenant.userId,
    kind: input.kind,
    input: { maxPages: limits.maxPages, maxDepth: limits.maxDepth },
  });
}

/* -------------------------------------------------------------------------- */
/* Execution                                                                  */
/* -------------------------------------------------------------------------- */

export interface JobOutcome {
  readonly job: JobRow;
  readonly crawl?: CrawlRow;
  readonly audit?: AuditRow;
}

/**
 * Runs one claimed job to completion.
 *
 * Takes an already-claimed job (status RUNNING) so that claiming and executing
 * are separate concerns: the claim must be atomic, the execution must not hold a
 * lock for minutes.
 */
export async function runJob(context: CrawlServiceContext, job: JobRow): Promise<JobOutcome> {
  if (job.status !== 'running') {
    throw new Error(`runJob was given a ${job.status} job; it must be claimed first.`);
  }
  if (!job.projectId) {
    const failed = await fail(context, job, 'worker_error', 'The job has no project.');
    return { job: failed };
  }

  const tenant: TenantContext = {
    userId: job.createdBy ?? '',
    organizationId: job.organizationId,
    // A job runs with the authority it was created with. Admin here so the
    // service-level permission checks pass for work the user already authorised;
    // tenant scoping is what actually constrains it.
    role: 'admin',
  };

  try {
    if (job.kind === 'crawl') return await executeCrawl(context, job, tenant);
    return await executeAudit(context, job, tenant, job.kind === 'seo_audit' ? 'seo' : 'aeo');
  } catch (error) {
    // An unexpected throw is a bug, not a user error. Recorded as such, with
    // nothing from the exception in the stored detail.
    const failed = await fail(context, job, 'worker_error', null);
    void error;
    return { job: failed };
  }
}

async function executeCrawl(
  context: CrawlServiceContext,
  job: JobRow,
  tenant: TenantContext,
): Promise<JobOutcome> {
  const projectId = job.projectId!;

  // SECOND CONSENT CHECK. The user may have withdrawn permission since queueing,
  // and this is the check that stops a crawl running without authorisation.
  let grant: CrawlGrant;
  let consent: CrawlConsentRow;
  try {
    const resolved = await resolveGrant(context, tenant, projectId);
    grant = resolved.grant;
    consent = resolved.consent;
  } catch (error) {
    const message = error instanceof ConsentRequiredError ? error.message : null;
    return { job: await fail(context, job, 'consent_revoked', message) };
  }

  const plan = await planFor(context, job.organizationId);
  const requested = job.input as { maxPages?: number; maxDepth?: number };
  const limits: CrawlLimits = resolveLimits(plan, {
    ...(typeof requested.maxPages === 'number' ? { maxPages: requested.maxPages } : {}),
    ...(typeof requested.maxDepth === 'number' ? { maxDepth: requested.maxDepth } : {}),
  });

  await context.db.jobs.updateProgress(job.id, 0, limits.maxPages, 'Checking robots.txt…');

  const outcome = await crawlSite(grant, {
    limits,
    ...(context.fetchOptions ? { fetchOptions: context.fetchOptions } : {}),
    ...(context.now ? { now: context.now } : {}),
    ...(context.sleep ? { sleep: context.sleep } : {}),
    onProgress: async (progress) => {
      const done = progress.fetched + progress.failed;
      const message = progress.currentUrl
        ? `Reading ${progress.currentUrl}`
        : `Read ${progress.fetched} pages`;
      await context.db.jobs.updateProgress(job.id, done, progress.budget, message);
    },
    isCancelled: async () => {
      const current = await context.db.jobs.findById(job.organizationId, job.id);
      return current?.cancelRequested === true;
    },
  });

  if (!outcome.ok) {
    return { job: await fail(context, job, outcome.code, outcome.reason) };
  }

  const report = outcome.report;

  if (report.cancelled) {
    // Partial results are still stored: the user asked to stop, not to discard.
    const crawl = await persistCrawl(context, job, report, consent, true);
    const cancelledJob = await transition(context, job, 'cancelled', { resultId: crawl.id });
    return { job: cancelledJob, crawl };
  }

  if (report.pages.length === 0) {
    const detail = report.failures[0]?.reason ?? null;
    return { job: await fail(context, job, 'nothing_crawled', detail) };
  }

  const crawl = await persistCrawl(context, job, report, consent, false);

  // Keywords come from the crawl, so they are extracted here rather than needing
  // their own job.
  const keywords = extractKeywords(report);
  await context.db.keywords.replaceForProject(
    job.organizationId,
    job.projectId!,
    keywords.keywords.map((keyword) => toKeywordRow(keyword, job, crawl.id)),
  );

  // Two metrics: pages (the unit of work) and runs (the fair-use limit). One
  // 300-page crawl and three 1-page crawls are different kinds of cost.
  const periodStart = metricPeriod(clock(context));
  await context.db.usage.record({
    organizationId: job.organizationId,
    projectId: job.projectId,
    metric: 'crawl_page',
    quantity: report.pages.length,
    periodStart,
  });
  await context.db.usage.record({
    organizationId: job.organizationId,
    projectId: job.projectId,
    metric: 'crawl_run',
    quantity: 1,
    periodStart,
  });

  const done = await transition(context, job, 'completed', { resultId: crawl.id });
  return { job: done, crawl };
}

/** The first day of the billing month, which is how usage is bucketed. */
function metricPeriod(at: number): string {
  return new Date(at).toISOString().slice(0, 7) + '-01';
}

async function persistCrawl(
  context: CrawlServiceContext,
  job: JobRow,
  report: CrawlReport,
  consent: CrawlConsentRow,
  cancelled: boolean,
): Promise<CrawlRow> {
  // Retention comes from the consent record, which is where the user agreed to it.
  const expiresAt = new Date(clock(context) + consent.retentionDays * 24 * 60 * 60 * 1000);

  const crawl = await context.db.crawls.create({
    organizationId: job.organizationId,
    projectId: job.projectId!,
    jobId: job.id,
    consentId: consent.id,
    startedBy: job.createdBy,
    siteUrl: report.siteUrl,
    maxPages: report.limits.maxPages,
    maxDepth: report.limits.maxDepth,
    respectRobots: report.robots.respected,
    crawlDelayMs: report.robots.crawlDelayMs,
    pagesCrawled: report.pages.length,
    pagesFailed: report.failures.length,
    robotsFound: report.robots.found,
    robotsReadable: report.robots.readable,
    robotsSummary: report.robots.summary,
    sitemapFound: report.sitemap.found,
    sitemapNote: report.sitemap.note,
    sitemapUrlsFound: report.sitemap.urls.length,
    failures: report.failures,
    skipped: report.skipped,
    stoppedEarly: report.stoppedEarly,
    cancelled,
    startedAt: report.startedAt,
    finishedAt: report.finishedAt,
    expiresAt,
  });

  await context.db.crawls.savePages(
    crawl.id,
    report.pages.map((page) => toPageRow(page, job.organizationId, crawl.id)),
  );

  return crawl;
}

async function executeAudit(
  context: CrawlServiceContext,
  job: JobRow,
  tenant: TenantContext,
  kind: 'seo' | 'aeo',
): Promise<JobOutcome> {
  const projectId = job.projectId!;

  const crawl = await context.db.crawls.findLatest(tenant.organizationId, projectId);
  if (!crawl) {
    return { job: await fail(context, job, 'nothing_crawled', 'No crawl has been run for this project.') };
  }

  await context.db.jobs.updateProgress(job.id, 0, 1, 'Reading the stored crawl…');

  const pages = await context.db.crawls.listPages(tenant.organizationId, crawl.id);
  if (pages.length === 0) {
    return {
      job: await fail(
        context,
        job,
        'nothing_crawled',
        'The stored pages for that crawl have been deleted, so there is nothing to audit.',
      ),
    };
  }

  // An audit runs on the STORED crawl, which is what makes it re-runnable
  // without fetching the site again.
  const report = reportFromStorage(crawl, pages);
  const result = kind === 'seo' ? auditSeo(report) : auditAeo(report);

  const audit = await context.db.audits.create({
    organizationId: tenant.organizationId,
    projectId,
    crawlId: crawl.id,
    jobId: job.id,
    kind,
    score: result.score.score,
    scoreBasis: result.score.basis,
    findings: result.findings,
    stats: result.stats as unknown as Record<string, unknown>,
    notChecked: result.notChecked,
    suppressed: result.suppressed,
    checkedAt: result.checkedAt,
  });

  // PHASE 7: audits now record usage. Before this, `usage_records` permitted an
  // `audit_run` metric that nothing ever wrote — a limit that existed in the
  // database constraint and was counted nowhere. SEO and AEO are recorded
  // separately because the brief gives them separate limits.
  await context.db.usage.record({
    organizationId: tenant.organizationId,
    projectId,
    metric: kind === 'seo' ? 'seo_audit' : 'aeo_audit',
    quantity: 1,
    periodStart: metricPeriod(clock(context)),
  });

  await context.db.jobs.updateProgress(job.id, 1, 1, 'Done.');
  const done = await transition(context, job, 'completed', { resultId: audit.id });
  return { job: done, audit };
}

/* -------------------------------------------------------------------------- */
/* State transitions                                                          */
/* -------------------------------------------------------------------------- */

async function transition(
  context: CrawlServiceContext,
  job: JobRow,
  to: JobRow['status'],
  detail?: { readonly resultId?: string; readonly failureCode?: string; readonly failureDetail?: string },
): Promise<JobRow> {
  if (!canTransition(job.status, to)) {
    // The state machine is the authority; a disallowed transition is a bug.
    throw new Error(`A ${job.status} job cannot become ${to}.`);
  }
  const updated = await context.db.jobs.finish(job.id, to, new Date(clock(context)), detail);
  return updated ?? job;
}

async function fail(
  context: CrawlServiceContext,
  job: JobRow,
  code: string,
  detail: string | null,
): Promise<JobRow> {
  const updated = await context.db.jobs.finish(job.id, 'failed', new Date(clock(context)), {
    failureCode: code,
    ...(detail ? { failureDetail: detail.slice(0, 500) } : {}),
  });
  return updated ?? job;
}

/* -------------------------------------------------------------------------- */
/* Cancellation and retry                                                     */
/* -------------------------------------------------------------------------- */

export async function cancelJob(
  context: CrawlServiceContext,
  tenant: TenantContext,
  jobId: string,
): Promise<JobRow> {
  requirePermission(tenant.role, 'content:create');

  const existing = assertTenant(
    tenant,
    await context.db.jobs.findById(tenant.organizationId, jobId),
    'Job',
  );

  if (existing.status === 'completed' || existing.status === 'failed') {
    // Not an error: the user clicked cancel on something that had just finished.
    return existing;
  }

  const updated = await context.db.jobs.requestCancel(tenant.organizationId, jobId);
  return updated ?? existing;
}

export async function retryJob(
  context: CrawlServiceContext,
  tenant: TenantContext,
  jobId: string,
): Promise<JobRow> {
  requirePermission(tenant.role, 'content:create');

  const existing = assertTenant(
    tenant,
    await context.db.jobs.findById(tenant.organizationId, jobId),
    'Job',
  );

  if (!canRetry(existing.attempts, existing.failureCode)) {
    throw new RetryNotAllowedError(
      existing.attempts >= MAX_ATTEMPTS
        ? `This job has already been attempted ${existing.attempts} times.`
        : `${explainFailure(existing.failureCode)} Retrying will not change that.`,
    );
  }

  // Another job may have been queued since this one failed.
  const active = await context.db.jobs.findActive(
    tenant.organizationId,
    existing.projectId ?? '',
    existing.kind,
  );
  if (active) throw new JobConflictError(active.id);

  const notBefore = new Date(clock(context) + retryDelayMs(existing.attempts));
  const requeued = await context.db.jobs.requeue(tenant.organizationId, jobId, notBefore);
  if (!requeued) throw new NotFoundError('Job');
  return requeued;
}

export class RetryNotAllowedError extends Error {
  readonly code = 'RETRY_NOT_ALLOWED' as const;
  constructor(message: string) {
    super(message);
    this.name = 'RetryNotAllowedError';
  }
}

export interface RecoveryOutcome {
  /** Returned to the queue for another attempt. */
  readonly requeued: number;
  /** Out of attempts, and failed for good. */
  readonly abandoned: number;
}

/**
 * Recovers jobs whose worker died mid-run.
 *
 * WITHOUT THIS a crashed worker leaves a job RUNNING forever, the unique index
 * blocks the user from starting another, and the customer sees a crawl that
 * never finishes and never errors — the failure mode that looks like a hang,
 * which is the hardest kind to diagnose from a support ticket.
 *
 * REQUEUE FIRST, FAIL ONLY WHEN OUT OF ATTEMPTS. Until Phase 8 this function
 * only ever failed a stale job, which threw away work that was usually
 * perfectly retryable: the worker dying says nothing about whether the job
 * would have succeeded. A deploy that rolls pods mid-crawl is the common cause,
 * and it is exactly the case where retrying works.
 *
 * `attempts` is the bound, so a job that kills its worker repeatedly — the
 * genuinely poisonous one, which would otherwise take down every worker that
 * picks it up in turn — is abandoned rather than cycled forever.
 */
export async function reapStaleJobs(context: CrawlServiceContext): Promise<RecoveryOutcome> {
  const now = new Date(clock(context));
  const stale = await context.db.jobs.findStale(new Date(now.getTime() - STALE_RUNNING_MS));

  let requeued = 0;
  let abandoned = 0;

  for (const job of stale) {
    if (!isStale(job.startedAt, now)) continue;

    if (job.attempts < MAX_ATTEMPTS) {
      // `worker_lost` is not in the retryable-code list on purpose: that list
      // is about failures the JOB reported, and this job reported nothing. The
      // decision here is made on attempts alone.
      const notBefore = new Date(now.getTime() + retryDelayMs(job.attempts));
      await context.db.jobs.requeue(job.organizationId, job.id, notBefore);
      requeued += 1;
      continue;
    }

    await context.db.jobs.finish(job.id, 'failed', now, {
      failureCode: 'worker_error',
      failureDetail: `The job stopped responding ${MAX_ATTEMPTS} times and was ended. This usually means it is too large; try a smaller page limit.`,
    });
    abandoned += 1;
  }

  return { requeued, abandoned };
}

/* -------------------------------------------------------------------------- */
/* Reading                                                                    */
/* -------------------------------------------------------------------------- */

export async function getJob(
  context: CrawlServiceContext,
  tenant: TenantContext,
  jobId: string,
): Promise<JobRow> {
  requirePermission(tenant.role, 'content:read');
  return assertTenant(tenant, await context.db.jobs.findById(tenant.organizationId, jobId), 'Job');
}

export async function listJobs(
  context: CrawlServiceContext,
  tenant: TenantContext,
  projectId: string,
  kind?: JobKind,
): Promise<JobRow[]> {
  requirePermission(tenant.role, 'content:read');
  assertTenant(tenant, await context.db.projects.findById(tenant.organizationId, projectId), 'Project');
  return context.db.jobs.listForProject(tenant.organizationId, projectId, kind);
}

export interface JobView {
  readonly id: string;
  readonly kind: JobKind;
  readonly status: JobRow['status'];
  readonly progress: ReturnType<typeof progressOf>;
  readonly cancelRequested: boolean;
  readonly attempts: number;
  readonly canRetry: boolean;
  readonly failure: string | null;
  readonly resultId: string | null;
  readonly queuedAt: Date;
  readonly finishedAt: Date | null;
}

/** The shape the interface polls. Never exposes internal failure detail. */
export function toJobView(job: JobRow): JobView {
  return {
    id: job.id,
    kind: job.kind,
    status: job.status,
    progress: progressOf(job.progressDone, job.progressTotal, job.progressMessage),
    cancelRequested: job.cancelRequested,
    attempts: job.attempts,
    canRetry: job.status === 'failed' && canRetry(job.attempts, job.failureCode),
    failure: job.status === 'failed' ? explainFailure(job.failureCode, job.failureDetail) : null,
    resultId: job.resultId,
    queuedAt: job.queuedAt,
    finishedAt: job.finishedAt,
  };
}

export async function getLatestAudit(
  context: CrawlServiceContext,
  tenant: TenantContext,
  projectId: string,
  kind: 'seo' | 'aeo',
): Promise<AuditRow | null> {
  requirePermission(tenant.role, 'content:read');
  assertTenant(tenant, await context.db.projects.findById(tenant.organizationId, projectId), 'Project');
  return context.db.audits.findLatest(tenant.organizationId, projectId, kind);
}

export async function getLatestCrawl(
  context: CrawlServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<CrawlRow | null> {
  requirePermission(tenant.role, 'content:read');
  assertTenant(tenant, await context.db.projects.findById(tenant.organizationId, projectId), 'Project');
  return context.db.crawls.findLatest(tenant.organizationId, projectId);
}

export async function listKeywords(
  context: CrawlServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<KeywordRow[]> {
  requirePermission(tenant.role, 'content:read');
  assertTenant(tenant, await context.db.projects.findById(tenant.organizationId, projectId), 'Project');
  return context.db.keywords.listForProject(tenant.organizationId, projectId);
}

/* -------------------------------------------------------------------------- */
/* Retention                                                                  */
/* -------------------------------------------------------------------------- */

/**
 * Deletes stored page content whose retention period has passed.
 *
 * A HARD delete, deliberately. The crawl row is kept — it is the record that a
 * crawl happened, which the consent trail needs — but the page content, which
 * is the user's own website text, is removed.
 */
export async function deleteExpiredCrawlData(context: CrawlServiceContext): Promise<number> {
  const expired = await context.db.crawls.findExpired(new Date(clock(context)));
  let deleted = 0;
  for (const crawl of expired) {
    deleted += await context.db.crawls.deletePages(crawl.id);
  }
  return deleted;
}

/**
 * Deletes everything crawled under a withdrawn consent record.
 *
 * Called when a user revokes consent. Revocation that left the previously
 * crawled content in place would not be revocation.
 */
export async function deleteCrawlDataForConsent(
  context: CrawlServiceContext,
  tenant: TenantContext,
  consentId: string,
): Promise<number> {
  requirePermission(tenant.role, 'crawl:delete');
  const crawls = await context.db.crawls.listForConsent(tenant.organizationId, consentId);
  let deleted = 0;
  for (const crawl of crawls) {
    deleted += await context.db.crawls.deletePages(crawl.id);
  }
  return deleted;
}

/* -------------------------------------------------------------------------- */
/* Row conversion                                                             */
/* -------------------------------------------------------------------------- */

function toPageRow(
  page: PageData,
  organizationId: string,
  crawlId: string,
): Omit<CrawledPageRow, 'id' | 'createdAt'> {
  return {
    organizationId,
    crawlId,
    url: page.url,
    status: page.status,
    https: page.https,
    title: page.title,
    metaDescription: page.metaDescription,
    h1: page.h1,
    h2: page.h2,
    h3: page.h3,
    textContent: page.text,
    wordCount: page.wordCount,
    links: page.links,
    images: page.images,
    canonical: page.canonical,
    robotsDirectives: page.robots as unknown as Record<string, unknown>,
    structuredData: page.structuredData,
    structuredDataErrors: page.structuredDataErrors,
    faqs: page.faqs,
    author: page.author,
    publisher: page.publisher,
    publishedAtRaw: page.publishedAt,
    modifiedAtRaw: page.modifiedAt,
    entitySignals: page.entities as unknown as Record<string, unknown>,
    openGraph: page.openGraph,
    lang: page.lang,
    hasViewportMeta: page.hasViewportMeta,
    hasCharset: page.hasCharset,
    bytes: page.bytes,
    responseTimeMs: page.responseTimeMs,
    truncated: page.truncated,
    crawledAt: page.crawledAt,
  };
}

function toKeywordRow(
  keyword: ReturnType<typeof extractKeywords>['keywords'][number],
  job: JobRow,
  crawlId: string,
): Omit<KeywordRow, 'id' | 'createdAt' | 'updatedAt'> {
  return {
    organizationId: job.organizationId,
    projectId: job.projectId!,
    crawlId,
    query: keyword.query,
    kinds: keyword.kinds,
    intent: keyword.intent,
    relevanceScore: keyword.relevance.score,
    relevanceBasis: keyword.relevance.basis,
    coveringUrls: keyword.relevance.coveringUrls,
    volume: keyword.volume as unknown as Record<string, unknown>,
    competition: keyword.competition as unknown as Record<string, unknown>,
    priority: keyword.priority,
    contentFormat: keyword.contentFormat,
    entities: keyword.entities,
    source: keyword.source,
  };
}

/**
 * Rebuilds a `CrawlReport` from stored rows, so an audit can run without
 * re-crawling. The fields an audit does not read are reconstructed as empty
 * rather than faked.
 */
export function reportFromStorage(crawl: CrawlRow, pages: readonly CrawledPageRow[]): CrawlReport {
  return {
    siteUrl: crawl.siteUrl,
    startedAt: crawl.startedAt,
    finishedAt: crawl.finishedAt ?? crawl.startedAt,
    pages: pages.map(pageFromRow),
    failures: crawl.failures as CrawlReport['failures'],
    robots: {
      url: `${new URL(crawl.siteUrl).origin}/robots.txt`,
      found: crawl.robotsFound,
      readable: crawl.robotsReadable,
      respected: crawl.respectRobots,
      summary: crawl.robotsSummary,
      sitemapsDeclared: [],
      blockedCount: Number((crawl.skipped as Record<string, number>).robots ?? 0),
      crawlDelayMs: crawl.crawlDelayMs,
    },
    sitemap: {
      found: crawl.sitemapFound,
      // The URL list is not stored per crawl; the count is. An audit that needs
      // the list reads it from the pages instead of being handed a fabricated one.
      urls: [],
      locations: [],
      kind: null,
      truncated: false,
      note: crawl.sitemapNote,
    },
    skipped: crawl.skipped,
    limits: resolveLimits('agency', { maxPages: crawl.maxPages, maxDepth: crawl.maxDepth }),
    stoppedEarly: crawl.stoppedEarly,
    cancelled: crawl.cancelled,
  };
}

function pageFromRow(row: CrawledPageRow): PageData {
  return {
    url: row.url,
    status: row.status,
    https: row.https,
    title: row.title,
    metaDescription: row.metaDescription,
    h1: row.h1,
    h2: row.h2,
    h3: row.h3,
    text: row.textContent,
    wordCount: row.wordCount,
    links: row.links as PageData['links'],
    images: row.images as PageData['images'],
    canonical: row.canonical,
    robots: row.robotsDirectives as unknown as PageData['robots'],
    structuredData: row.structuredData,
    structuredDataErrors: row.structuredDataErrors,
    faqs: row.faqs as PageData['faqs'],
    author: row.author,
    publisher: row.publisher,
    publishedAt: row.publishedAtRaw,
    modifiedAt: row.modifiedAtRaw,
    entities: row.entitySignals as unknown as PageData['entities'],
    lang: row.lang,
    hasViewportMeta: row.hasViewportMeta,
    hasCharset: row.hasCharset,
    openGraph: row.openGraph,
    bytes: row.bytes,
    responseTimeMs: row.responseTimeMs,
    crawledAt: row.crawledAt,
    truncated: row.truncated,
  };
}
