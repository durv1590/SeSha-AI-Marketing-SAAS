/**
 * Usage recording and the usage dashboard.
 *
 * RECORDING IS BEST-EFFORT AND NEVER BLOCKS THE WORK.
 * `record()` swallows a storage failure and reports the error instead of
 * throwing. That is a deliberate trade: if the usage table is unavailable, the
 * right outcome is that the customer's crawl still runs and we lose a counter —
 * not that the product stops working because bookkeeping failed. The opposite
 * choice turns a metering outage into an outage.
 *
 * THE DASHBOARD SHOWS WHAT IS MEASURED AND SAYS WHAT IS NOT.
 * Same discipline as Phase 6: a metric with no rows shows zero USED against a
 * real limit, which is true and useful; a metric that is not measured at all is
 * not shown as zero. `TRACKED_METRICS` is the list that has counters behind it.
 */

import type { Database } from '@/lib/db/repositories';
import type { UsageMetric as RowMetric } from '@/lib/db/types';
import { LIMIT_IDS, type LimitId, type PlanId } from '@/content/plans';
import type { EffectiveLimits } from '@/lib/plans/resolve';
import { limitStatus, pressurePoints, type LimitStatus } from '@/lib/quota';

import {
  MEASURES,
  METRIC_LABEL,
  TRACKED_METRICS,
  isWritableMetric,
  limitForMetric,
  periodResetAt,
  periodStartOf,
  previousPeriodStart,
  type UsageMetric,
} from './metrics';

export interface UsageServiceContext {
  readonly db: Database;
  readonly now?: () => Date;
}

function clock(context: UsageServiceContext): Date {
  return context.now?.() ?? new Date();
}

/* -------------------------------------------------------------------------- */
/* Recording                                                                  */
/* -------------------------------------------------------------------------- */

export interface RecordUsageInput {
  readonly organizationId: string;
  readonly projectId?: string | null;
  readonly metric: UsageMetric;
  readonly quantity?: number;
}

/**
 * Records usage.
 *
 * Refuses to write `audit_run` — the legacy value that could not distinguish
 * SEO from AEO. Writing it again would restore the ambiguity Phase 7 fixed, so
 * the guard is here rather than only in a comment.
 */
export async function record(
  context: UsageServiceContext,
  input: RecordUsageInput,
): Promise<void> {
  const quantity = Math.max(1, Math.floor(input.quantity ?? 1));
  if (!isWritableMetric(input.metric)) {
    // Loud in development, silent in production: a bad metric name is a bug in
    // our code, and it must not take a customer's request down with it.
    if (process.env.NODE_ENV !== 'production') {
      throw new Error(`"${input.metric}" is not a metric that may be written.`);
    }
    return;
  }

  try {
    await context.db.usage.record({
      organizationId: input.organizationId,
      projectId: input.projectId ?? null,
      metric: input.metric as RowMetric,
      quantity,
      periodStart: periodStartOf(clock(context)),
    });
  } catch {
    // Bookkeeping must not break the product. See the header.
  }
}

/** Records several metrics for one action — a generation and its tokens. */
export async function recordMany(
  context: UsageServiceContext,
  organizationId: string,
  entries: readonly { readonly metric: UsageMetric; readonly quantity?: number }[],
  projectId?: string | null,
): Promise<void> {
  for (const entry of entries) {
    await record(context, {
      organizationId,
      ...(projectId === undefined ? {} : { projectId }),
      metric: entry.metric,
      ...(entry.quantity === undefined ? {} : { quantity: entry.quantity }),
    });
  }
}

/* -------------------------------------------------------------------------- */
/* Measuring                                                                  */
/* -------------------------------------------------------------------------- */

/**
 * How much of one limit is used.
 *
 * The single place that knows the difference between summing usage rows for a
 * period and counting live rows for a capacity limit. Getting this wrong is how
 * a product either resets a customer's project count every month or never
 * resets their AI allowance.
 */
export async function usedFor(
  context: UsageServiceContext,
  organizationId: string,
  limitId: LimitId,
  periodStart: string,
): Promise<number> {
  const measure = MEASURES[limitId];

  if (measure.kind === 'per_period') {
    let total = 0;
    for (const metric of measure.metrics) {
      total += await context.db.usage.totalFor(organizationId, metric as RowMetric, periodStart);
    }
    return total;
  }

  switch (measure.countable) {
    case 'projects':
      return context.db.projects.countForOrganization(organizationId);
    case 'memberships':
      return (await context.db.memberships.listForOrganization(organizationId)).length;
    case 'automation_rules': {
      // Rules are per project, and the limit is per organization, so every
      // project's rules are counted. A per-project limit would let one customer
      // create unlimited automations by creating projects.
      const projects = await context.db.projects.listForOrganization(organizationId);
      let total = 0;
      for (const project of projects) {
        total += (await context.db.automation.listRules(organizationId, project.id)).length;
      }
      return total;
    }
  }
}

/** Every limit's usage, for the dashboard and for the admin panel. */
export async function usageSnapshot(
  context: UsageServiceContext,
  organizationId: string,
  limits: EffectiveLimits,
  periodStart: string,
): Promise<readonly LimitStatus[]> {
  const statuses: LimitStatus[] = [];
  for (const id of LIMIT_IDS) {
    const used = await usedFor(context, organizationId, id, periodStart);
    statuses.push(limitStatus(limits[id], used));
  }
  return statuses;
}

/* -------------------------------------------------------------------------- */
/* The dashboard                                                              */
/* -------------------------------------------------------------------------- */

export interface MetricTotal {
  readonly metric: UsageMetric;
  readonly label: string;
  readonly total: number;
  readonly previousTotal: number;
  /** The limit this counts against, when it counts against one. */
  readonly limitId: LimitId | null;
}

export interface UsageDashboard {
  readonly plan: PlanId;
  readonly periodStart: string;
  readonly resetsAt: string;
  /** Every limit with its usage, worst first for the pressure list. */
  readonly limits: readonly LimitStatus[];
  readonly pressure: readonly LimitStatus[];
  /** The eight things the brief asks to track, with a month-on-month figure. */
  readonly tracked: readonly MetricTotal[];
  /** Recent refusals, so "why was I blocked" has an answer on the screen. */
  readonly recentRefusals: readonly {
    readonly limitId: string;
    readonly reason: string;
    readonly refusedAt: string;
  }[];
}

export async function dashboard(
  context: UsageServiceContext,
  organizationId: string,
  plan: PlanId,
  limits: EffectiveLimits,
): Promise<UsageDashboard> {
  const now = clock(context);
  const periodStart = periodStartOf(now);
  const previous = previousPeriodStart(periodStart);

  const statuses = await usageSnapshot(context, organizationId, limits, periodStart);

  const tracked: MetricTotal[] = [];
  for (const metric of TRACKED_METRICS) {
    tracked.push({
      metric,
      label: METRIC_LABEL[metric],
      total: await context.db.usage.totalFor(organizationId, metric as RowMetric, periodStart),
      previousTotal: await context.db.usage.totalFor(organizationId, metric as RowMetric, previous),
      limitId: limitForMetric(metric),
    });
  }

  const refusals = await context.db.quotaRefusals.listForOrganization(organizationId, 10);

  return {
    plan,
    periodStart,
    resetsAt: periodResetAt(periodStart),
    limits: statuses,
    pressure: pressurePoints(statuses),
    tracked,
    recentRefusals: refusals.map((row) => ({
      limitId: row.limitId,
      reason: row.reason,
      refusedAt: row.refusedAt.toISOString(),
    })),
  };
}
