/**
 * Usage: what is counted, and how each limit is measured.
 *
 * THE MAPPING IN THIS FILE IS THE CRUX OF PHASE 7.
 * A plan limit is worthless unless something counts the thing it limits, and the
 * two vocabularies did not line up when this phase started:
 *
 *   · the brief names eleven LIMITS and eight things to TRACK;
 *   · Phases 2–6 had already accumulated a `usage_records.metric` vocabulary
 *     with fourteen values, written from a dozen call sites.
 *
 * Inventing a third vocabulary would have left three sets to keep in sync. So
 * `MEASURES` states, per limit, exactly how it is measured — and because it is a
 * total `Record<LimitId, Measure>`, a limit added to the registry without a way
 * to measure it **does not compile**. That is the property worth having: the
 * failure mode of a quota system is silently not enforcing something.
 *
 * ONE GAP HAD TO BE FIXED IN THE DATA, NOT PAPERED OVER.
 * The brief gives SEO audits and AEO audits SEPARATE limits, but Phases 4–6
 * recorded both as a single `audit_run` metric. With one counter the two limits
 * cannot be enforced independently — an organization that used its whole SEO
 * allowance would find its AEO allowance gone too. Migration 0007 adds
 * `seo_audit` and `aeo_audit`, and `audit_run` is kept as a legacy value that is
 * read but never written, because rows already exist under it.
 */

import { LIMIT_IDS, type LimitId } from '@/content/plans';

/* -------------------------------------------------------------------------- */
/* The metric vocabulary                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Everything the product counts.
 *
 * The eight the brief names to track, the values earlier phases already write,
 * and `api_call`, which is new in Phase 7.
 */
export const USAGE_METRICS = [
  /* AI */
  'ai_generation',
  'ai_tokens',
  /* Content */
  'content_item',
  /* Crawler */
  'crawl_run',
  'crawl_page',
  /* Audits — separate, because the limits are separate */
  'seo_audit',
  'aeo_audit',
  /* Structured data */
  'schema_validation',
  /* Reporting */
  'report',
  'report_export',
  /* Platform */
  'api_call',
  'automation_run',
  'seat',
  /* Other countable work from earlier phases */
  'competitor_analysis',
  'lead',
  'calendar_event',
  /**
   * LEGACY. Written by Phases 4–6 for both SEO and AEO audits. Read when
   * totalling historical usage, never written again — see the header.
   */
  'audit_run',
] as const;

export type UsageMetric = (typeof USAGE_METRICS)[number];

/** Values that may still be written. `audit_run` is deliberately absent. */
export const WRITABLE_METRICS: readonly UsageMetric[] = USAGE_METRICS.filter(
  (metric) => metric !== 'audit_run',
);

export function isUsageMetric(value: unknown): value is UsageMetric {
  return typeof value === 'string' && (USAGE_METRICS as readonly string[]).includes(value);
}

export function isWritableMetric(value: unknown): value is UsageMetric {
  return isUsageMetric(value) && (WRITABLE_METRICS as readonly string[]).includes(value);
}

export const METRIC_LABEL: Readonly<Record<UsageMetric, string>> = {
  ai_generation: 'AI requests',
  ai_tokens: 'AI tokens',
  content_item: 'Content generated',
  crawl_run: 'Crawls',
  crawl_page: 'Pages crawled',
  seo_audit: 'SEO audits',
  aeo_audit: 'AEO audits',
  schema_validation: 'Schema validations',
  report: 'Reports generated',
  report_export: 'Report exports',
  api_call: 'API calls',
  automation_run: 'Automation runs',
  seat: 'Seats',
  competitor_analysis: 'Competitor analyses',
  lead: 'Leads recorded',
  calendar_event: 'Calendar entries',
  audit_run: 'Audits (before SEO and AEO were counted separately)',
};

/** The eight the brief asks to track, for the dashboard and the gate test. */
export const TRACKED_METRICS: readonly UsageMetric[] = [
  'ai_generation',
  'ai_tokens',
  'content_item',
  'crawl_run',
  'seo_audit',
  'aeo_audit',
  'schema_validation',
  'report',
  'api_call',
];

/* -------------------------------------------------------------------------- */
/* How each limit is measured                                                 */
/* -------------------------------------------------------------------------- */

/**
 * A per-period limit is measured by summing usage rows in the billing month.
 *
 * `metrics` is a list because one limit can be fed by more than one recorded
 * value — the audit case, where historical `audit_run` rows have to keep
 * counting against the SEO allowance or a customer's used quota would appear to
 * drop when we changed the vocabulary.
 */
export interface PeriodMeasure {
  readonly kind: 'per_period';
  readonly metrics: readonly UsageMetric[];
}

/**
 * An absolute limit is measured by counting live rows.
 *
 * `countable` names WHAT is counted, and `lib/quota` holds the one function that
 * knows how to count each. Deliberately not a callback here: this module stays
 * free of database access so it can be unit-tested as data.
 */
export interface AbsoluteMeasure {
  readonly kind: 'absolute';
  readonly countable: 'projects' | 'memberships' | 'automation_rules';
}

export type Measure = PeriodMeasure | AbsoluteMeasure;

/**
 * Every limit, and how it is measured. Total by construction.
 */
export const MEASURES: Readonly<Record<LimitId, Measure>> = {
  ai_requests: { kind: 'per_period', metrics: ['ai_generation'] },
  tokens: { kind: 'per_period', metrics: ['ai_tokens'] },
  content_generations: { kind: 'per_period', metrics: ['content_item'] },
  website_crawls: { kind: 'per_period', metrics: ['crawl_run'] },
  // `audit_run` is included in BOTH audit limits, which is the honest choice
  // given it recorded both kinds indistinguishably. It over-counts rather than
  // under-counts, and over-counting a historical month cannot let someone exceed
  // a limit they have already paid for — under-counting could.
  seo_audits: { kind: 'per_period', metrics: ['seo_audit', 'audit_run'] },
  aeo_audits: { kind: 'per_period', metrics: ['aeo_audit', 'audit_run'] },
  schema_validations: { kind: 'per_period', metrics: ['schema_validation'] },
  projects: { kind: 'absolute', countable: 'projects' },
  team_members: { kind: 'absolute', countable: 'memberships' },
  reports: { kind: 'per_period', metrics: ['report'] },
  automations: { kind: 'absolute', countable: 'automation_rules' },
};

/** The limit a recorded metric counts against, if any. Used by the dashboard. */
export function limitForMetric(metric: UsageMetric): LimitId | null {
  for (const id of LIMIT_IDS) {
    const measure = MEASURES[id];
    if (measure.kind === 'per_period' && measure.metrics.includes(metric)) return id;
  }
  return null;
}

/* -------------------------------------------------------------------------- */
/* Billing periods                                                            */
/* -------------------------------------------------------------------------- */

/**
 * The first day of the billing month, as `YYYY-MM-DD`.
 *
 * `usage_records.period_start` is a date so a month's usage is one indexed
 * range. UTC deliberately: a tenant-local month boundary would make the same
 * request land in two different periods depending on who looked.
 */
export function periodStartOf(at: Date): string {
  const year = at.getUTCFullYear();
  const month = String(at.getUTCMonth() + 1).padStart(2, '0');
  return `${year}-${month}-01`;
}

/** The period before a given one, for a month-on-month comparison. */
export function previousPeriodStart(periodStart: string): string {
  const [year, month] = periodStart.split('-').map(Number);
  if (!year || !month) return periodStart;
  const date = new Date(Date.UTC(year, month - 1, 1));
  date.setUTCMonth(date.getUTCMonth() - 1);
  return periodStartOf(date);
}

/**
 * When the current period resets, as an ISO string.
 *
 * Shown next to an exhausted quota, because "you have run out" without "this
 * resets on the 1st" is the kind of message that generates a support ticket.
 */
export function periodResetAt(periodStart: string): string {
  const [year, month] = periodStart.split('-').map(Number);
  if (!year || !month) return periodStart;
  return new Date(Date.UTC(year, month, 1)).toISOString();
}

/** Whole days until the period resets, from `at`. Never negative. */
export function daysUntilReset(periodStart: string, at: Date): number {
  const reset = new Date(periodResetAt(periodStart)).getTime();
  const days = Math.ceil((reset - at.getTime()) / 86_400_000);
  return days > 0 ? days : 0;
}
