/**
 * Row types.
 *
 * These mirror db/schema.sql exactly, so the repository interfaces are typed
 * against the real eventual shape rather than against whatever the current
 * adapter happens to store. `tests/database.test.ts` checks the table list here
 * against the migrations.
 *
 * Naming: rows use snake_case to match the database. Everything above the
 * repository layer uses camelCase; repositories are the translation boundary.
 */

export type Uuid = string;
/** ISO 8601 string. Dates cross the repository boundary as Date objects. */
export type Timestamp = string;

/**
 * The four plans, as migration 0007 leaves them.
 *
 * Phases 1-6 used `starter | growth | agency`; 0007 widens the CHECK, migrates
 * the rows upward (starter -> pro, growth -> business) and narrows it again, so
 * only these four can be stored. `resolvePlanId()` in `content/plans.ts` still
 * accepts the old spellings on READ, defensively — a row written by an older
 * deployment during a rolling release must not crash a screen.
 */
export type Plan = 'free' | 'pro' | 'business' | 'agency';
export type SubscriptionStatus =
  | 'trialing'
  | 'active'
  | 'past_due'
  | 'canceled'
  | 'paused'
  /** Checkout started and not finished. Not the same as active. */
  | 'incomplete';
export type ProjectStatus = 'active' | 'paused' | 'archived';
export type PriceRange = 'budget' | 'mid_market' | 'premium' | 'luxury' | 'varies';
/**
 * The kinds a notification row may carry.
 *
 * A superset of `src/lib/notifications/types.ts`: 'content', 'lead' and 'report'
 * are the Phase 2 spellings and are kept because rows written under them already
 * exist, and rewriting history to tidy an enum is worse than carrying six extra
 * characters. New code uses the Phase 6 names; migration 0006 widens the CHECK
 * to cover both.
 */
export type NotificationKind =
  | 'security'
  | 'billing'
  | 'system'
  | 'content'
  | 'lead'
  | 'report'
  | 'report_ready'
  | 'new_lead'
  | 'campaign_changed'
  | 'content_scheduled'
  | 'schema_error'
  | 'audit_complete'
  | 'crawl_complete'
  | 'validation_complete';
export type AiSurface = 'copilot' | 'content' | 'seo' | 'aeo' | 'campaign' | 'report';
export type AiRole = 'user' | 'assistant' | 'system';
export type ReviewState = 'pending' | 'approved' | 'rejected' | 'not_applicable';
export type UsageMetric =
  | 'ai_generation'
  /** Input + output tokens. Tracked separately from generation count because
   *  one long strategy can cost more than fifty captions. */
  | 'ai_tokens'
  | 'content_item'
  | 'crawl_page'
  | 'crawl_run'
  | 'audit_run'
  | 'report'
  | 'automation_run'
  | 'seat'
  /* Phase 5 */
  | 'schema_validation'
  | 'competitor_analysis'
  | 'lead'
  /* Phase 6 */
  | 'calendar_event'
  | 'report_export'
  /**
   * Phase 7. `seo_audit` and `aeo_audit` replace the single `audit_run`, which
   * could not enforce two separate limits. `audit_run` is still readable
   * because rows exist under it; `WRITABLE_METRICS` excludes it.
   */
  | 'seo_audit'
  | 'aeo_audit'
  | 'api_call';

/* -------------------------------------------------------------------------- */
/* Identity                                                                   */
/* -------------------------------------------------------------------------- */

export interface OrganizationRow {
  readonly id: Uuid;
  readonly name: string;
  readonly slug: string;
  readonly plan: Plan;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface UserRow {
  readonly id: Uuid;
  readonly email: string;
  readonly name: string | null;
  /** scrypt encoded hash. NULL means the account is OAuth-only. */
  readonly passwordHash: string | null;
  readonly emailVerifiedAt: Date | null;
  readonly onboardingCompletedAt: Date | null;
  readonly passwordChangedAt: Date | null;
  readonly deletedAt: Date | null;
  readonly deletionRequestedAt: Date | null;
  readonly lastLoginAt: Date | null;
  readonly locale: string;
  readonly timezone: string | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface MembershipRow {
  readonly organizationId: Uuid;
  readonly userId: Uuid;
  readonly role: 'owner' | 'admin' | 'manager' | 'team_member' | 'user';
  readonly createdAt: Date;
}

export interface OAuthAccountRow {
  readonly id: Uuid;
  readonly userId: Uuid;
  readonly provider: 'google';
  readonly providerUserId: string;
  readonly email: string | null;
  readonly emailVerified: boolean;
  readonly createdAt: Date;
  readonly lastLoginAt: Date | null;
}

export interface SessionRow {
  readonly id: Uuid;
  readonly userId: Uuid;
  readonly tokenHash: string;
  readonly userAgent: string | null;
  readonly ipHash: string | null;
  readonly createdAt: Date;
  readonly lastActiveAt: Date;
  readonly expiresAt: Date;
  readonly revokedAt: Date | null;
  readonly sudoUntil: Date | null;
}

export interface VerificationTokenRow {
  readonly id: Uuid;
  readonly userId: Uuid;
  readonly tokenHash: string;
  readonly email: string;
  readonly expiresAt: Date;
  readonly usedAt: Date | null;
  readonly createdAt: Date;
}

export interface PasswordResetRow {
  readonly id: Uuid;
  readonly userId: Uuid;
  readonly tokenHash: string;
  readonly expiresAt: Date;
  readonly usedAt: Date | null;
  readonly ipHash: string | null;
  readonly createdAt: Date;
}

/* -------------------------------------------------------------------------- */
/* Customer data — every row carries organizationId                           */
/* -------------------------------------------------------------------------- */

export interface BusinessRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly name: string;
  readonly industry: string | null;
  readonly country: string | null;
  readonly city: string | null;
  readonly websiteUrl: string | null;
  readonly createdBy: Uuid | null;
  readonly deletedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface ProjectRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly businessId: Uuid | null;
  readonly name: string;
  readonly slug: string;
  readonly description: string | null;
  readonly status: ProjectStatus;
  readonly createdBy: Uuid | null;
  readonly deletedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface MarketingProfileRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly targetAudience: string | null;
  readonly productsServices: string | null;
  readonly priceRange: PriceRange | null;
  readonly marketingGoals: readonly string[];
  readonly marketingChannels: readonly string[];
  readonly brandVoice: Readonly<Record<string, unknown>>;
  readonly competitors: readonly { readonly name: string; readonly url?: string }[];
  readonly completeness: number;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface CrawlConsentRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly websiteUrl: string;
  readonly grantedBy: Uuid | null;
  readonly grantedAt: Date;
  readonly revokedAt: Date | null;
  readonly consentVersion: string;
  readonly maxPages: number;
  readonly respectRobots: boolean;
  readonly retentionDays: number;
  readonly dataDeletedAt: Date | null;
}

export interface SubscriptionRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly plan: Plan;
  readonly status: SubscriptionStatus;
  readonly externalCustomerId: string | null;
  readonly externalSubscriptionId: string | null;
  readonly currentPeriodStart: Date | null;
  readonly currentPeriodEnd: Date | null;
  readonly cancelAtPeriodEnd: boolean;
  readonly trialEndsAt: Date | null;
  /**
   * When the payment first failed, so the grace window can be measured. A
   * `past_due` row without it gives the customer the benefit of the doubt — a
   * missing timestamp is our bookkeeping problem, not theirs.
   */
  readonly pastDueSince: Date | null;
  readonly canceledAt: Date | null;
  readonly provider: string | null;
  /**
   * DISPLAY METADATA ONLY. There is deliberately no field here — and no column
   * in any migration — for a card number, token, CVV or bank detail. These four
   * are what every provider returns and none of them can charge anybody.
   */
  readonly paymentBrand: string | null;
  readonly paymentLast4: string | null;
  readonly paymentExpiryMonth: number | null;
  readonly paymentExpiryYear: number | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface UsageRow {
  readonly id: string;
  readonly organizationId: Uuid;
  readonly projectId: Uuid | null;
  readonly metric: UsageMetric;
  readonly quantity: number;
  readonly periodStart: string;
  readonly recordedAt: Date;
}

export interface NotificationRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly userId: Uuid;
  readonly projectId: Uuid | null;
  readonly kind: NotificationKind;
  readonly title: string;
  readonly body: string | null;
  readonly actionUrl: string | null;
  readonly readAt: Date | null;
  readonly createdAt: Date;
}

export interface AiConversationRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly userId: Uuid | null;
  readonly title: string | null;
  readonly surface: AiSurface;
  readonly archivedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface AiMessageRow {
  readonly id: Uuid;
  readonly conversationId: Uuid;
  readonly organizationId: Uuid;
  readonly role: AiRole;
  readonly content: string;
  readonly contextSources: readonly { readonly type: string; readonly id: string }[];
  readonly reviewState: ReviewState;
  readonly tokenCount: number | null;
  readonly createdAt: Date;
}

export interface BrandKitRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly voice: string | null;
  readonly toneRules: string | null;
  readonly terminology: Readonly<Record<string, unknown>>;
  readonly palette: Readonly<Record<string, unknown>>;
  readonly logoUrl: string | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface AuditLogRow {
  readonly id: string;
  readonly organizationId: Uuid | null;
  readonly actorId: Uuid | null;
  readonly action: string;
  readonly entityType: string;
  readonly entityId: string | null;
  readonly outcome: 'success' | 'failure' | 'denied';
  readonly metadata: Readonly<Record<string, unknown>>;
  readonly ipHash: string | null;
  readonly userAgent: string | null;
  readonly createdAt: Date;
}

/* -------------------------------------------------------------------------- */
/* Phase 3 — AI output                                                        */
/* -------------------------------------------------------------------------- */

export type ReviewStatus = 'draft' | 'in_review' | 'approved' | 'archived';

/** Recorded on every generated artefact, so its origin is never guesswork. */
export interface GeneratedBy {
  readonly provider?: string;
  readonly model?: string;
  readonly agent?: string;
  readonly at?: string;
  readonly cached?: boolean;
  /** Set once a person edits the generated text, so authorship is not implied. */
  readonly humanEdited?: boolean;
  /** True for an artefact a person wrote from scratch. */
  readonly human?: boolean;
}

export interface ContentItemRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly createdBy: Uuid | null;
  readonly format: string;
  readonly title: string;
  readonly body: string;
  readonly language: 'en' | 'hi' | 'hinglish';
  readonly tone: string | null;
  readonly audience: string | null;
  readonly lengthPreset: string | null;
  readonly creativity: number | null;
  readonly callToAction: string | null;
  readonly searchIntent: string | null;
  readonly answerIntent: string | null;
  readonly status: ReviewStatus;
  readonly reviewedBy: Uuid | null;
  readonly reviewedAt: Date | null;
  readonly blocks: readonly unknown[];
  readonly claimWarnings: readonly unknown[];
  readonly generatedBy: GeneratedBy;
  readonly deletedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface StrategyRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly createdBy: Uuid | null;
  readonly title: string;
  readonly sections: Readonly<Record<string, unknown>>;
  readonly blocks: readonly unknown[];
  readonly claimWarnings: readonly unknown[];
  readonly generatedBy: GeneratedBy;
  readonly status: ReviewStatus;
  readonly deletedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/** No 'published' status: no platform API is connected. See lib/social. */
export type SocialPostStatus = 'idea' | 'draft' | 'ready' | 'archived';

export interface SocialPostRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly createdBy: Uuid | null;
  readonly platform: string;
  readonly format: string;
  readonly caption: string;
  readonly hashtags: readonly string[];
  readonly idea: string | null;
  readonly status: SocialPostStatus;
  readonly plannedFor: string | null;
  readonly blocks: readonly unknown[];
  readonly generatedBy: GeneratedBy;
  readonly deletedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/**
 * Every table the application knows about.
 * `tests/database.test.ts` asserts this matches db/migrations exactly, so a
 * table added to one and not the other fails the test run.
 */
/* -------------------------------------------------------------------------- */
/* Phase 4 — crawler, audits, keywords, jobs                                  */
/* -------------------------------------------------------------------------- */

export type JobKindRow = 'crawl' | 'seo_audit' | 'aeo_audit';
export type JobStatusRow = 'queued' | 'running' | 'completed' | 'failed' | 'cancelled';

export interface JobRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid | null;
  readonly createdBy: Uuid | null;
  readonly kind: JobKindRow;
  readonly status: JobStatusRow;
  readonly progressDone: number;
  readonly progressTotal: number | null;
  readonly progressMessage: string;
  /** A cancellation REQUEST. The worker polls it and stops cleanly. */
  readonly cancelRequested: boolean;
  readonly attempts: number;
  readonly failureCode: string | null;
  readonly failureDetail: string | null;
  readonly input: Readonly<Record<string, unknown>>;
  readonly resultId: Uuid | null;
  /** A retry may not run before this time. */
  readonly notBefore: Date | null;
  readonly queuedAt: Date;
  readonly startedAt: Date | null;
  readonly finishedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface CrawlRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly jobId: Uuid | null;
  /** The consent record that authorised this crawl. */
  readonly consentId: Uuid | null;
  readonly startedBy: Uuid | null;
  readonly siteUrl: string;
  readonly maxPages: number;
  readonly maxDepth: number;
  readonly respectRobots: boolean;
  readonly crawlDelayMs: number;
  readonly pagesCrawled: number;
  readonly pagesFailed: number;
  readonly robotsFound: boolean;
  readonly robotsReadable: boolean;
  readonly robotsSummary: string;
  readonly sitemapFound: boolean;
  readonly sitemapNote: string;
  readonly sitemapUrlsFound: number;
  readonly failures: readonly unknown[];
  readonly skipped: Readonly<Record<string, number>>;
  readonly stoppedEarly: string | null;
  readonly cancelled: boolean;
  readonly startedAt: Date;
  readonly finishedAt: Date | null;
  /** When the stored page content must be deleted, from the consent record. */
  readonly expiresAt: Date;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/**
 * One crawled page. The RAW HTML IS NOT STORED — only the extracted fields,
 * because the audit needs those and keeping a copy of someone's whole site is a
 * liability with no corresponding benefit.
 */
export interface CrawledPageRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly crawlId: Uuid;
  readonly url: string;
  readonly status: number;
  readonly https: boolean;
  readonly title: string | null;
  readonly metaDescription: string | null;
  readonly h1: readonly string[];
  readonly h2: readonly string[];
  readonly h3: readonly string[];
  readonly textContent: string;
  readonly wordCount: number;
  readonly links: readonly unknown[];
  readonly images: readonly unknown[];
  readonly canonical: string | null;
  readonly robotsDirectives: Readonly<Record<string, unknown>>;
  readonly structuredData: readonly unknown[];
  readonly structuredDataErrors: readonly string[];
  readonly faqs: readonly unknown[];
  readonly author: string | null;
  readonly publisher: string | null;
  readonly publishedAtRaw: string | null;
  readonly modifiedAtRaw: string | null;
  readonly entitySignals: Readonly<Record<string, unknown>>;
  readonly openGraph: Readonly<Record<string, string>>;
  readonly lang: string | null;
  readonly hasViewportMeta: boolean;
  readonly hasCharset: boolean;
  readonly bytes: number;
  readonly responseTimeMs: number;
  readonly truncated: boolean;
  /** The brief: store the crawl timestamp. Per page, not per crawl. */
  readonly crawledAt: Date;
  readonly createdAt: Date;
}

export interface AuditRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly crawlId: Uuid;
  readonly jobId: Uuid | null;
  readonly kind: 'seo' | 'aeo';
  readonly score: number;
  /** Stored with the score so the number is never shown without it. */
  readonly scoreBasis: string;
  readonly findings: readonly unknown[];
  readonly stats: Readonly<Record<string, unknown>>;
  readonly notChecked: readonly unknown[];
  readonly suppressed: readonly string[];
  readonly checkedAt: Date;
  readonly createdAt: Date;
}

/**
 * A keyword row.
 *
 * NOTE THE ABSENCE of `searchVolume: number | null` and `competition: number |
 * null`. Those values are unknown to this product, and a nullable number column
 * invites a future writer to fill it with an estimate that then reads as a
 * measurement. Both are discriminated unions carrying their own provenance.
 */
export interface KeywordRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly crawlId: Uuid | null;
  readonly query: string;
  readonly kinds: readonly string[];
  readonly intent: 'informational' | 'commercial' | 'transactional' | 'navigational';
  readonly relevanceScore: number;
  readonly relevanceBasis: string;
  readonly coveringUrls: readonly string[];
  readonly volume: Readonly<Record<string, unknown>>;
  readonly competition: Readonly<Record<string, unknown>>;
  readonly priority: 'high' | 'medium' | 'low';
  readonly contentFormat: string;
  readonly entities: readonly string[];
  readonly source: 'page_heading' | 'page_title' | 'faq' | 'user_provided' | 'ai_suggested';
  readonly createdAt: Date;
  readonly updatedAt: Date;
}


/* -------------------------------------------------------------------------- */
/* Phase 5 — schema validation, competitors, ads, leads, messaging, video      */
/* -------------------------------------------------------------------------- */

/**
 * One structured-data validation run.
 *
 * `validatorVersion` is not optional. A history without it is not comparable: a
 * finding that appears between two runs could be a change in the customer's
 * markup or a change in our own rules, and there would be no way to tell which.
 */
export interface SchemaValidationRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly createdBy: Uuid | null;
  readonly sourceKind: 'pasted' | 'page_url' | 'website_url';
  readonly sourceUrl: string | null;
  readonly canonicalUrl: string | null;
  readonly syntaxes: readonly string[];
  readonly validatorVersion: string;
  readonly overallStatus: string;
  readonly counts: Readonly<Record<string, number>>;
  readonly typesFound: readonly string[];
  readonly entities: readonly Readonly<Record<string, unknown>>[];
  readonly issues: readonly Readonly<Record<string, unknown>>[];
  readonly limitations: readonly Readonly<Record<string, unknown>>[];
  readonly checkedAt: Date;
  readonly createdAt: Date;
}

export interface CompetitorRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly createdBy: Uuid | null;
  readonly name: string;
  readonly websiteUrl: string | null;
  readonly source: 'onboarding' | 'user_added';
  readonly notes: string;
  readonly deletedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/**
 * The authorisation for reading a competitor's public pages.
 *
 * A competitor cannot consent. What is recorded is that a named person at the
 * customer asked for public pages to be read, having been shown what that means —
 * a dated, versioned, attributable act, the same shape as a crawl consent.
 */
export interface CompetitorAcknowledgementRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly competitorId: Uuid;
  readonly acknowledgedBy: Uuid | null;
  readonly acknowledgedAt: Date;
  readonly revokedAt: Date | null;
  readonly statementVersion: string;
  readonly maxPages: number;
  readonly createdAt: Date;
}

/** Findings only. The third party's page content is deliberately not stored. */
export interface CompetitorAnalysisRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly competitorId: Uuid;
  readonly acknowledgementId: Uuid | null;
  readonly jobId: Uuid | null;
  readonly createdBy: Uuid | null;
  readonly analysedAt: Date;
  readonly findings: readonly Readonly<Record<string, unknown>>[];
  readonly pagesRead: readonly Readonly<Record<string, unknown>>[];
  readonly limitations: readonly Readonly<Record<string, unknown>>[];
  readonly notCovered: readonly Readonly<Record<string, unknown>>[];
  readonly verifiedCount: number;
  readonly inferredCount: number;
  readonly createdAt: Date;
}

/**
 * An advertising plan.
 *
 * No `platformCampaignId`, no `spend`, no performance fields: no ad account is
 * connected, so a column recording what a campaign did could never be written
 * truthfully.
 */
export interface AdPlanRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly createdBy: Uuid | null;
  readonly platform: 'google_ads' | 'meta' | 'instagram' | 'linkedin' | 'youtube';
  readonly objective: string;
  readonly campaignName: string;
  readonly plan: Readonly<Record<string, unknown>>;
  readonly problems: readonly Readonly<Record<string, unknown>>[];
  /**
   * 'rejected' was added in Phase 6 (migration 0006). Phase 5 had no way to say
   * no to a plan, which meant a decision could only be made in one direction.
   */
  readonly reviewState: 'draft' | 'in_review' | 'approved' | 'rejected';
  /** Required when rejected: the author has to know what to change. */
  readonly reviewNote: string | null;
  readonly reviewedBy: Uuid | null;
  readonly reviewedAt: Date | null;
  readonly deletedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/**
 * A lead.
 *
 * `email` is nullable on purpose: in this market a great many enquiries arrive by
 * phone or WhatsApp with no email address, and a required email would force
 * whoever took the call to invent one.
 *
 * The score is stored WITH its components and basis. A bare total would be the
 * opaque score this product exists not to show.
 */
export interface LeadRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid | null;
  readonly createdBy: Uuid | null;
  readonly ownerUserId: Uuid | null;
  readonly name: string;
  readonly email: string | null;
  readonly phone: string | null;
  readonly company: string | null;
  readonly enquiry: string;
  readonly source: string;
  readonly sourcePath: string | null;
  readonly sourceCampaign: string | null;
  readonly stage: 'new' | 'contacted' | 'qualified' | 'proposal' | 'negotiation' | 'won' | 'lost';
  readonly score: number;
  readonly scoreComponents: readonly Readonly<Record<string, unknown>>[];
  readonly scoreBasis: string;
  readonly scoredAt: Date | null;
  readonly optInBasis: string;
  readonly lostReason: string | null;
  readonly lastActivityAt: Date | null;
  readonly deletedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/** An activity or a follow-up. A follow-up is an activity with a due date. */
export interface LeadActivityRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly leadId: Uuid;
  readonly createdBy: Uuid | null;
  readonly kind: string;
  readonly note: string;
  readonly occurredAt: Date;
  readonly dueAt: Date | null;
  readonly completedAt: Date | null;
  readonly fromStage: string | null;
  readonly toStage: string | null;
  readonly createdAt: Date;
}

/**
 * An email or WhatsApp plan.
 *
 * Note what is absent: no `sentAt`, no `scheduledAt`, no 'sent' review state and
 * no recipient list. SeSha cannot send, so there is nothing to record having
 * sent — and `optInBasis` cannot hold a forbidden value, because the service
 * refuses the plan and the database CHECK refuses the row.
 */
export interface MessagingPlanRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly createdBy: Uuid | null;
  readonly channel: 'email' | 'whatsapp';
  readonly kind: string;
  readonly category: 'MARKETING' | 'UTILITY' | 'AUTHENTICATION' | null;
  readonly title: string;
  readonly plan: Readonly<Record<string, unknown>>;
  readonly problems: readonly Readonly<Record<string, unknown>>[];
  readonly optInBasis: 'explicit_opt_in' | 'existing_customer' | 'enquiry_reply' | 'contract_necessity';
  readonly audienceNote: string;
  readonly reviewState: 'draft' | 'in_review' | 'approved';
  readonly deletedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/** A video script. Thumbnail concepts are written briefs; there is no image. */
export interface VideoScriptRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly createdBy: Uuid | null;
  readonly platform: 'youtube_long' | 'youtube_shorts' | 'instagram_reels' | 'linkedin_video';
  readonly topic: string;
  readonly totalSeconds: number;
  readonly script: Readonly<Record<string, unknown>>;
  readonly problems: readonly Readonly<Record<string, unknown>>[];
  readonly reviewState: 'draft' | 'in_review' | 'approved';
  readonly deletedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/* -------------------------------------------------------------------------- */
/* Phase 6: analytics, calendar, automation, reports, notifications           */
/* -------------------------------------------------------------------------- */

/**
 * A connected data source.
 *
 * Note what is absent: no access token. Token custody belongs with the
 * credential store, not with a row that reporting queries join against — that is
 * how a token ends up in a log line. `externalAccountId` is the non-secret handle.
 *
 * A provider with no row is not connected. There is no 'pending' state, because
 * a screen would round it up to "connected".
 */
export interface DataConnectionRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid | null;
  readonly provider:
    | 'google_analytics'
    | 'google_search_console'
    | 'google_ads'
    | 'meta_ads'
    | 'meta_pages'
    | 'linkedin_pages';
  readonly externalAccountId: string | null;
  readonly connectedBy: Uuid | null;
  readonly connectedAt: Date | null;
  readonly disconnectedAt: Date | null;
  readonly lastSyncedAt: Date | null;
  readonly problem: string | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/**
 * An entry on the marketing calendar.
 *
 * `eventDate` is a date string (YYYY-MM-DD), not a Date. A marketing calendar is
 * a calendar of days; an instant forces a timezone decision that would move an
 * entry across a date boundary for a colleague in another country.
 *
 * There is no 'scheduled' or 'published' status. Nothing fires on a date.
 */
export interface CalendarEventRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly kind: string;
  readonly title: string;
  readonly notes: string;
  readonly eventDate: string;
  readonly status: 'planned' | 'done' | 'skipped';
  readonly origin: 'manual' | 'derived' | 'accepted_suggestion';
  readonly sourceKind: string | null;
  readonly sourceId: Uuid | null;
  readonly campaign: string | null;
  readonly createdBy: Uuid | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/** An automation rule: trigger, conditions, actions. */
export interface AutomationRuleRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly name: string;
  readonly triggerKind: string;
  readonly conditions: readonly Readonly<Record<string, unknown>>[];
  readonly actions: readonly Readonly<Record<string, unknown>>[];
  readonly enabled: boolean;
  readonly createdBy: Uuid | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

/**
 * One evaluation of one rule.
 *
 * Written even when nothing matched, with the condition that failed. A rule that
 * quietly stops matching is otherwise indistinguishable from one that never runs.
 */
export interface AutomationRunRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly ruleId: Uuid;
  readonly triggerKind: string;
  readonly subjectId: Uuid | null;
  readonly matched: boolean;
  readonly skipReason: string | null;
  readonly actionsTaken: readonly Readonly<Record<string, unknown>>[];
  readonly ranAt: Date;
}

/**
 * A generated report.
 *
 * `document` is the RENDERED report, stored whole, including every metric with
 * its provenance. A shared link sent in March must show what it showed in March;
 * regenerating on read would silently rewrite history.
 */
export interface ReportRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly projectId: Uuid;
  readonly kind: string;
  readonly title: string;
  readonly periodFrom: string;
  readonly periodTo: string;
  readonly periodLabel: string;
  readonly document: Readonly<Record<string, unknown>>;
  readonly connectedSources: readonly string[];
  readonly generatedBy: Uuid | null;
  readonly generatedAt: Date;
}

/** A share link. Only the hash of the token is here; the token is shown once. */
export interface ReportShareRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly reportId: Uuid;
  readonly tokenHash: string;
  readonly createdBy: Uuid | null;
  readonly createdAt: Date;
  readonly expiresAt: Date;
  readonly revokedAt: Date | null;
  readonly lastViewedAt: Date | null;
  readonly viewCount: number;
}

/**
 * One user's preference for one kind of notification.
 *
 * A kind with no row gets the application default, so a new notification kind
 * does not arrive switched off for every existing user.
 */
export interface NotificationPreferenceRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly userId: Uuid;
  readonly kind: string;
  readonly inApp: boolean;
  readonly email: boolean;
  readonly updatedAt: Date;
}

/* -------------------------------------------------------------------------- */
/* Phase 7: plans, usage, billing, the admin platform, feature flags         */
/* -------------------------------------------------------------------------- */

/** An admin-set limit for one organization. `value` null means unlimited. */
export interface PlanLimitOverrideRow {
  readonly id: Uuid;
  readonly organizationId: Uuid;
  readonly limitId: string;
  readonly value: number | null;
  /** Required. An override nobody can explain is one nobody dares remove. */
  readonly reason: string;
  readonly setBy: Uuid | null;
  readonly setAt: Date;
}

/**
 * A refused request, recorded.
 *
 * Separate from `usage_records` on purpose: a `refused` flag there would mean
 * every total had to remember to filter it, and a forgotten filter over-counts
 * usage — which wrongly BLOCKS a paying customer. `used`/`limit` are frozen at
 * the moment of refusal so a later limit change does not rewrite the history of
 * why someone was blocked.
 */
export interface QuotaRefusalRow {
  readonly id: string;
  readonly organizationId: Uuid;
  readonly projectId: Uuid | null;
  readonly userId: Uuid | null;
  readonly limitId: string;
  readonly reason: 'period_exhausted' | 'at_capacity' | 'not_included' | 'subscription_blocked';
  readonly plan: string;
  readonly usedAtRefusal: number;
  readonly limitAtRefusal: number | null;
  readonly periodStart: string;
  readonly refusedAt: Date;
}

/**
 * Platform staff. THE ONLY thing that grants admin access.
 *
 * An organization `admin` (memberships.role) is a CUSTOMER and is not staff. A
 * revoked row grants nothing, and is checked on every request rather than
 * trusted from a session that could be thirty days old.
 */
export interface PlatformStaffRow {
  readonly id: Uuid;
  readonly userId: Uuid;
  readonly role: 'support' | 'engineer' | 'platform_owner';
  readonly grantedBy: Uuid | null;
  readonly grantedAt: Date;
  readonly revokedBy: Uuid | null;
  readonly revokedAt: Date | null;
  /** Why this person has platform access. Required. */
  readonly reason: string;
}

/**
 * One admin action, INCLUDING a read.
 *
 * "Who looked at which customer" is the question an audit log exists to answer,
 * and a log of writes only cannot answer it. `targetOrganizationId` is
 * deliberately not a foreign key: deleting a tenant must not erase the record of
 * what staff did to it.
 */
export interface AdminActionRow {
  readonly id: string;
  readonly staffUserId: Uuid | null;
  readonly staffRole: string;
  readonly permission: string;
  readonly action: string;
  readonly kind: 'read' | 'write';
  readonly targetType: string;
  readonly targetId: string | null;
  readonly targetOrganizationId: Uuid | null;
  /** Never customer content: an audit log is not a second copy of their data. */
  readonly metadata: Readonly<Record<string, unknown>>;
  readonly outcome: 'success' | 'failure' | 'denied';
  readonly sessionId: Uuid | null;
  readonly ipHash: string | null;
  readonly createdAt: Date;
}

/**
 * A subscription lifecycle event.
 *
 * `externalEventId` is UNIQUE in the database. Providers retry webhooks and
 * deliver them out of order; without an idempotency key a retried
 * `payment_succeeded` is applied twice. `applied: false` rows are kept because
 * an ignored webhook is normal and must be visible rather than silent.
 */
export interface BillingEventRow {
  readonly id: string;
  readonly organizationId: Uuid;
  readonly externalEventId: string | null;
  readonly provider: string;
  readonly event: string;
  readonly statusBefore: string | null;
  readonly statusAfter: string | null;
  readonly planBefore: string | null;
  readonly planAfter: string | null;
  readonly applied: boolean;
  readonly note: string | null;
  /** A SUMMARY, never the raw provider payload. */
  readonly payloadSummary: Readonly<Record<string, unknown>>;
  readonly occurredAt: Date;
}

/** One stored rule for one feature flag. `disabled` is the kill switch. */
export interface FeatureFlagRuleRow {
  readonly key: string;
  readonly disabled: boolean;
  readonly organizationIds: readonly Uuid[];
  readonly excludedOrganizationIds: readonly Uuid[];
  readonly plans: readonly string[];
  readonly rolloutPercent: number;
  readonly updatedBy: Uuid | null;
  readonly updatedAt: Date;
}

/** A platform setting. The permitted keys are a registry in code, not a CHECK. */
export interface SystemSettingRow {
  readonly key: string;
  readonly value: unknown;
  readonly updatedBy: Uuid | null;
  readonly updatedAt: Date;
}

/**
 * A grouped error.
 *
 * NO STACK TRACE AND NO REQUEST BODY. A stack can contain a token read from a
 * header and a body can contain a customer's content; this table is read by
 * staff, so it holds only what is needed to find the problem in the code.
 */
export interface ErrorEventRow {
  readonly id: string;
  readonly fingerprint: string;
  readonly severity: 'warning' | 'error' | 'critical';
  readonly source: string;
  readonly message: string;
  readonly organizationId: Uuid | null;
  readonly occurrences: number;
  readonly firstSeenAt: Date;
  readonly lastSeenAt: Date;
  readonly resolvedAt: Date | null;
  readonly resolvedBy: Uuid | null;
}

export interface FeedbackRow {
  readonly id: Uuid;
  readonly organizationId: Uuid | null;
  readonly userId: Uuid | null;
  readonly kind: 'bug' | 'idea' | 'praise' | 'other';
  readonly message: string;
  readonly surface: string | null;
  readonly status: 'new' | 'triaged' | 'answered' | 'closed';
  readonly triagedBy: Uuid | null;
  readonly triagedAt: Date | null;
  readonly createdAt: Date;
}

export const TABLES = [
  'organizations',
  'users',
  'memberships',
  'sessions',
  'workspaces',
  'brand_kits',
  'posts',
  'contact_submissions',
  'newsletter_subscribers',
  'leads',
  'audit_log',
  'oauth_accounts',
  'email_verification_tokens',
  'password_reset_tokens',
  'login_attempts',
  'businesses',
  'projects',
  'marketing_profiles',
  'website_crawl_consents',
  'subscriptions',
  'usage_records',
  'notifications',
  'ai_conversations',
  'ai_messages',
  'content_items',
  'strategies',
  'social_posts',
  'jobs',
  'crawls',
  'crawled_pages',
  'audits',
  'keywords',
  'schema_validations',
  'competitors',
  'competitor_acknowledgements',
  'competitor_analyses',
  'ad_plans',
  'lead_activities',
  'messaging_plans',
  'video_scripts',
  'data_connections',
  'calendar_events',
  'automation_rules',
  'automation_runs',
  'reports',
  'report_shares',
  'notification_preferences',
  'quota_refusals',
  'plan_limit_overrides',
  'platform_staff',
  'admin_actions',
  'billing_events',
  'feature_flag_rules',
  'system_settings',
  'error_events',
  'feedback',
  'idempotency_keys',
] as const;

export type TableName = (typeof TABLES)[number];

/** Tables that use `deleted_at` rather than a hard delete. */
export const SOFT_DELETE_TABLES: readonly TableName[] = [
  'users',
  'businesses',
  'projects',
  'content_items',
  'strategies',
  'social_posts',
  'competitors',
  'ad_plans',
  'leads',
  'messaging_plans',
  'video_scripts',
];
