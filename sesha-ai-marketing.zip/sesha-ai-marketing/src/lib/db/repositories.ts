/**
 * Repository interfaces.
 *
 * API routes and services depend on these, never on a driver. The Phase 2
 * adapter is an in-memory store (./memory-store.ts) so the whole authentication
 * and tenancy flow is genuinely executable and testable; the PostgreSQL adapter
 * that replaces it implements the same interfaces against db/schema.sql.
 *
 * TENANCY RULE, enforced by every method signature below: anything that reads
 * or writes customer data takes an `organizationId`. There is deliberately no
 * `findById(id)` for a tenant-scoped row — only `findById(organizationId, id)` —
 * so it is not possible to write a query that forgets the tenant filter.
 */

import type {
  AdPlanRow,
  AdminActionRow,
  BillingEventRow,
  ErrorEventRow,
  FeatureFlagRuleRow,
  FeedbackRow,
  PlanLimitOverrideRow,
  PlatformStaffRow,
  QuotaRefusalRow,
  SystemSettingRow,
  AutomationRuleRow,
  AutomationRunRow,
  CalendarEventRow,
  DataConnectionRow,
  NotificationPreferenceRow,
  ReportRow,
  ReportShareRow,
  AiConversationRow,
  AiMessageRow,
  AuditLogRow,
  AuditRow,
  ContentItemRow,
  CompetitorAcknowledgementRow,
  CompetitorAnalysisRow,
  CompetitorRow,
  CrawlRow,
  CrawledPageRow,
  JobRow,
  KeywordRow,
  LeadActivityRow,
  LeadRow,
  MessagingPlanRow,
  SchemaValidationRow,
  VideoScriptRow,
  SocialPostRow,
  StrategyRow,
  BrandKitRow,
  BusinessRow,
  CrawlConsentRow,
  MarketingProfileRow,
  MembershipRow,
  NotificationRow,
  OAuthAccountRow,
  OrganizationRow,
  PasswordResetRow,
  ProjectRow,
  SessionRow,
  SubscriptionRow,
  UsageRow,
  UserRow,
  Uuid,
  VerificationTokenRow,
} from './types';

/* -------------------------------------------------------------------------- */
/* Identity                                                                   */
/* -------------------------------------------------------------------------- */

export interface CreateUserInput {
  readonly email: string;
  readonly name: string | null;
  readonly passwordHash: string | null;
  readonly emailVerifiedAt?: Date | null;
}

export interface UserRepository {
  /** Live accounts only — a soft-deleted user must not be able to sign in. */
  findByEmail(email: string): Promise<UserRow | null>;
  findById(id: Uuid): Promise<UserRow | null>;
  create(input: CreateUserInput): Promise<UserRow>;
  update(id: Uuid, patch: Partial<Omit<UserRow, 'id' | 'createdAt'>>): Promise<UserRow>;
  markEmailVerified(id: Uuid, at: Date): Promise<void>;
  setPassword(id: Uuid, passwordHash: string, at: Date): Promise<void>;
  recordLogin(id: Uuid, at: Date): Promise<void>;
  /** Stage 1 of deletion: blocks sign-in immediately, keeps the row. */
  softDelete(id: Uuid, at: Date): Promise<void>;
}

export interface OAuthRepository {
  findByProviderUserId(provider: 'google', providerUserId: string): Promise<OAuthAccountRow | null>;
  listForUser(userId: Uuid): Promise<OAuthAccountRow[]>;
  link(input: {
    userId: Uuid;
    provider: 'google';
    providerUserId: string;
    email: string | null;
    emailVerified: boolean;
  }): Promise<OAuthAccountRow>;
  recordLogin(id: Uuid, at: Date): Promise<void>;
  unlink(userId: Uuid, provider: 'google'): Promise<void>;
}

export interface SessionRepository {
  create(input: Omit<SessionRow, 'id'>): Promise<SessionRow>;
  findByTokenHash(tokenHash: string): Promise<SessionRow | null>;
  touch(id: Uuid, at: Date): Promise<void>;
  revoke(id: Uuid, at: Date): Promise<void>;
  /** Sign out everywhere. Called on password change and account deletion. */
  revokeAllForUser(userId: Uuid, at: Date, exceptSessionId?: Uuid): Promise<number>;
  listActiveForUser(userId: Uuid, now: Date): Promise<SessionRow[]>;
  grantSudo(id: Uuid, until: Date): Promise<void>;
}

export interface TokenRepository<T> {
  create(input: Omit<T, 'id' | 'createdAt' | 'usedAt'>): Promise<T>;
  findByTokenHash(tokenHash: string): Promise<T | null>;
  /** Single-use: returns false if already consumed or expired. */
  consume(tokenHash: string, at: Date): Promise<boolean>;
  invalidateAllForUser(userId: Uuid, at: Date): Promise<void>;
}

export type VerificationTokenRepository = TokenRepository<VerificationTokenRow>;
export type PasswordResetRepository = TokenRepository<PasswordResetRow>;

export interface OrganizationRepository {
  create(input: { name: string; slug: string }): Promise<OrganizationRow>;
  findById(id: Uuid): Promise<OrganizationRow | null>;
  findBySlug(slug: string): Promise<OrganizationRow | null>;
}

export interface MembershipRepository {
  create(input: MembershipRow): Promise<MembershipRow>;
  findForUser(userId: Uuid): Promise<MembershipRow[]>;
  find(organizationId: Uuid, userId: Uuid): Promise<MembershipRow | null>;
  listForOrganization(organizationId: Uuid): Promise<MembershipRow[]>;
  updateRole(organizationId: Uuid, userId: Uuid, role: MembershipRow['role']): Promise<void>;
  remove(organizationId: Uuid, userId: Uuid): Promise<void>;
}

/* -------------------------------------------------------------------------- */
/* Customer data — every signature is tenant-scoped                           */
/* -------------------------------------------------------------------------- */

export interface BusinessRepository {
  create(input: Omit<BusinessRow, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>): Promise<BusinessRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<BusinessRow | null>;
  listForOrganization(organizationId: Uuid): Promise<BusinessRow[]>;
  update(organizationId: Uuid, id: Uuid, patch: Partial<BusinessRow>): Promise<BusinessRow | null>;
  softDelete(organizationId: Uuid, id: Uuid, at: Date): Promise<void>;
}

export interface ProjectRepository {
  create(input: Omit<ProjectRow, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>): Promise<ProjectRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<ProjectRow | null>;
  findBySlug(organizationId: Uuid, slug: string): Promise<ProjectRow | null>;
  listForOrganization(organizationId: Uuid): Promise<ProjectRow[]>;
  update(organizationId: Uuid, id: Uuid, patch: Partial<ProjectRow>): Promise<ProjectRow | null>;
  softDelete(organizationId: Uuid, id: Uuid, at: Date): Promise<void>;
  countForOrganization(organizationId: Uuid): Promise<number>;
}

export interface MarketingProfileRepository {
  upsert(
    input: Omit<MarketingProfileRow, 'id' | 'createdAt' | 'updatedAt' | 'completeness'>,
  ): Promise<MarketingProfileRow>;
  findByProject(organizationId: Uuid, projectId: Uuid): Promise<MarketingProfileRow | null>;
}

export interface CrawlConsentRepository {
  grant(input: Omit<CrawlConsentRow, 'id' | 'grantedAt' | 'revokedAt' | 'dataDeletedAt'>): Promise<CrawlConsentRow>;
  findActiveForProject(organizationId: Uuid, projectId: Uuid): Promise<CrawlConsentRow | null>;
  /**
   * Looks a record up by its own id, scoped to the organization.
   *
   * Needed because revocation is reached from a settings screen that knows the
   * consent id and not the project. Deriving the project from the request
   * context instead is how revocation silently stopped working.
   */
  findById(organizationId: Uuid, id: Uuid): Promise<CrawlConsentRow | null>;
  listForProject(organizationId: Uuid, projectId: Uuid): Promise<CrawlConsentRow[]>;
  revoke(organizationId: Uuid, id: Uuid, at: Date): Promise<void>;
  /** Marks crawled data erased. The crawler itself arrives in a later phase. */
  markDataDeleted(organizationId: Uuid, id: Uuid, at: Date): Promise<void>;
}

export interface BrandKitRepository {
  upsert(input: Omit<BrandKitRow, 'id' | 'createdAt' | 'updatedAt'>): Promise<BrandKitRow>;
  findByProject(organizationId: Uuid, projectId: Uuid): Promise<BrandKitRow | null>;
}

export interface SubscriptionRepository {
  create(input: Omit<SubscriptionRow, 'id' | 'createdAt' | 'updatedAt'>): Promise<SubscriptionRow>;
  findForOrganization(organizationId: Uuid): Promise<SubscriptionRow | null>;
  update(organizationId: Uuid, patch: Partial<SubscriptionRow>): Promise<SubscriptionRow | null>;
}

export interface UsageRepository {
  record(input: Omit<UsageRow, 'id' | 'recordedAt'>): Promise<void>;
  totalFor(organizationId: Uuid, metric: UsageRow['metric'], periodStart: string): Promise<number>;
  listForPeriod(organizationId: Uuid, periodStart: string): Promise<UsageRow[]>;
}

export interface NotificationRepository {
  create(input: Omit<NotificationRow, 'id' | 'createdAt' | 'readAt'>): Promise<NotificationRow>;
  listForUser(organizationId: Uuid, userId: Uuid, limit?: number): Promise<NotificationRow[]>;
  countUnread(organizationId: Uuid, userId: Uuid): Promise<number>;
  markRead(organizationId: Uuid, id: Uuid, at: Date): Promise<void>;
}

export interface AiConversationRepository {
  create(input: Omit<AiConversationRow, 'id' | 'createdAt' | 'updatedAt' | 'archivedAt'>): Promise<AiConversationRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<AiConversationRow | null>;
  listForProject(organizationId: Uuid, projectId: Uuid): Promise<AiConversationRow[]>;
  appendMessage(input: Omit<AiMessageRow, 'id' | 'createdAt'>): Promise<AiMessageRow>;
  listMessages(organizationId: Uuid, conversationId: Uuid): Promise<AiMessageRow[]>;
}

/* -------------------------------------------------------------------------- */
/* Phase 3 — generated artefacts                                              */
/* -------------------------------------------------------------------------- */

export interface ContentRepository {
  create(input: Omit<ContentItemRow, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt' | 'reviewedBy' | 'reviewedAt'>): Promise<ContentItemRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<ContentItemRow | null>;
  listForProject(organizationId: Uuid, projectId: Uuid, limit?: number): Promise<ContentItemRow[]>;
  update(organizationId: Uuid, id: Uuid, patch: Partial<ContentItemRow>): Promise<ContentItemRow | null>;
  softDelete(organizationId: Uuid, id: Uuid, at: Date): Promise<void>;
}

export interface StrategyRepository {
  create(input: Omit<StrategyRow, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>): Promise<StrategyRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<StrategyRow | null>;
  listForProject(organizationId: Uuid, projectId: Uuid): Promise<StrategyRow[]>;
  findApproved(organizationId: Uuid, projectId: Uuid): Promise<StrategyRow | null>;
  update(organizationId: Uuid, id: Uuid, patch: Partial<StrategyRow>): Promise<StrategyRow | null>;
  softDelete(organizationId: Uuid, id: Uuid, at: Date): Promise<void>;
}

export interface SocialPostRepository {
  create(input: Omit<SocialPostRow, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>): Promise<SocialPostRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<SocialPostRow | null>;
  listForProject(organizationId: Uuid, projectId: Uuid): Promise<SocialPostRow[]>;
  listForCalendar(organizationId: Uuid, projectId: Uuid, from: string, to: string): Promise<SocialPostRow[]>;
  update(organizationId: Uuid, id: Uuid, patch: Partial<SocialPostRow>): Promise<SocialPostRow | null>;
  softDelete(organizationId: Uuid, id: Uuid, at: Date): Promise<void>;
}

/* -------------------------------------------------------------------------- */
/* Phase 4 — jobs, crawls, audits, keywords                                   */
/* -------------------------------------------------------------------------- */

/**
 * Background jobs.
 *
 * `claimNext` is the worker's entry point and must be ATOMIC: two workers
 * calling it concurrently must not receive the same job. A PostgreSQL adapter
 * implements it with `UPDATE ... WHERE id = (SELECT ... FOR UPDATE SKIP LOCKED)`;
 * the in-memory adapter is single-threaded so a plain read-then-write is safe
 * there. The interface exists to make that requirement explicit.
 */
export interface JobRepository {
  create(input: Omit<JobRow,
    'id' | 'createdAt' | 'updatedAt' | 'queuedAt' | 'startedAt' | 'finishedAt' |
    'status' | 'attempts' | 'progressDone' | 'progressTotal' | 'progressMessage' |
    'cancelRequested' | 'failureCode' | 'failureDetail' | 'resultId' | 'notBefore'
  > & { readonly notBefore?: Date | null }): Promise<JobRow>;

  findById(organizationId: Uuid, id: Uuid): Promise<JobRow | null>;
  listForProject(organizationId: Uuid, projectId: Uuid, kind?: JobRow['kind']): Promise<JobRow[]>;
  /** The active job of a kind, if any. Used to refuse a duplicate. */
  findActive(organizationId: Uuid, projectId: Uuid, kind: JobRow['kind']): Promise<JobRow | null>;

  /** ATOMIC claim. Returns null when nothing is runnable. */
  claimNext(now: Date, kinds?: readonly JobRow['kind'][]): Promise<JobRow | null>;

  updateProgress(id: Uuid, done: number, total: number | null, message: string): Promise<void>;
  /** Records the cancellation REQUEST; the worker acknowledges it. */
  requestCancel(organizationId: Uuid, id: Uuid): Promise<JobRow | null>;
  finish(id: Uuid, status: JobRow['status'], at: Date, detail?: {
    readonly failureCode?: string;
    readonly failureDetail?: string;
    readonly resultId?: Uuid;
  }): Promise<JobRow | null>;
  /** Moves a failed job back to queued for another attempt. */
  requeue(organizationId: Uuid, id: Uuid, notBefore: Date): Promise<JobRow | null>;
  /** Jobs stuck in RUNNING past the staleness window. */
  findStale(before: Date): Promise<JobRow[]>;
}

export interface CrawlRepository {
  create(input: Omit<CrawlRow, 'id' | 'createdAt' | 'updatedAt'>): Promise<CrawlRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<CrawlRow | null>;
  listForProject(organizationId: Uuid, projectId: Uuid, limit?: number): Promise<CrawlRow[]>;
  findLatest(organizationId: Uuid, projectId: Uuid): Promise<CrawlRow | null>;
  update(organizationId: Uuid, id: Uuid, patch: Partial<CrawlRow>): Promise<CrawlRow | null>;

  savePages(crawlId: Uuid, pages: readonly Omit<CrawledPageRow, 'id' | 'createdAt'>[]): Promise<number>;
  listPages(organizationId: Uuid, crawlId: Uuid): Promise<CrawledPageRow[]>;

  /** Crawls whose retention period has passed. */
  findExpired(before: Date): Promise<CrawlRow[]>;
  /**
   * HARD delete of stored page content. Not a soft delete: a user who withdraws
   * consent or whose retention period lapses asked for the data to be gone.
   */
  deletePages(crawlId: Uuid): Promise<number>;
  /** Every crawl performed under one consent record. */
  listForConsent(organizationId: Uuid, consentId: Uuid): Promise<CrawlRow[]>;
}

export interface AuditRepository {
  create(input: Omit<AuditRow, 'id' | 'createdAt'>): Promise<AuditRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<AuditRow | null>;
  findLatest(organizationId: Uuid, projectId: Uuid, kind: AuditRow['kind']): Promise<AuditRow | null>;
  listForProject(organizationId: Uuid, projectId: Uuid, kind?: AuditRow['kind']): Promise<AuditRow[]>;
  listForCrawl(organizationId: Uuid, crawlId: Uuid): Promise<AuditRow[]>;
}

export interface KeywordRepository {
  /** Replaces the project's set: a new crawl supersedes the previous list. */
  replaceForProject(
    organizationId: Uuid,
    projectId: Uuid,
    keywords: readonly Omit<KeywordRow, 'id' | 'createdAt' | 'updatedAt'>[],
  ): Promise<number>;
  listForProject(organizationId: Uuid, projectId: Uuid): Promise<KeywordRow[]>;
  remove(organizationId: Uuid, id: Uuid): Promise<void>;
}


/* -------------------------------------------------------------------------- */
/* Phase 5 — schema history, competitors, ads, leads, messaging, video         */
/* -------------------------------------------------------------------------- */

export interface SchemaValidationRepository {
  create(input: Omit<SchemaValidationRow, 'id' | 'createdAt'>): Promise<SchemaValidationRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<SchemaValidationRow | null>;
  listForProject(organizationId: Uuid, projectId: Uuid, limit?: number): Promise<SchemaValidationRow[]>;
  /**
   * The run before `before` for the same source, which is what a comparison over
   * time needs. Scoped by source because comparing a pasted snippet against a
   * crawled page would produce a diff that means nothing.
   */
  findPreviousForSource(
    organizationId: Uuid,
    projectId: Uuid,
    sourceUrl: string | null,
    before: Date,
  ): Promise<SchemaValidationRow | null>;
}

export interface CompetitorRepository {
  create(input: Omit<CompetitorRow, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>): Promise<CompetitorRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<CompetitorRow | null>;
  findByName(organizationId: Uuid, projectId: Uuid, name: string): Promise<CompetitorRow | null>;
  listForProject(organizationId: Uuid, projectId: Uuid): Promise<CompetitorRow[]>;
  update(organizationId: Uuid, id: Uuid, patch: Partial<CompetitorRow>): Promise<CompetitorRow | null>;
  softDelete(organizationId: Uuid, id: Uuid, at: Date): Promise<void>;
}

/**
 * Competitor research acknowledgements.
 *
 * `findLive` is the gate every analysis passes through. It returns null for a
 * revoked acknowledgement, so revocation takes effect immediately rather than at
 * the next analysis.
 */
export interface CompetitorAcknowledgementRepository {
  create(
    input: Omit<CompetitorAcknowledgementRow, 'id' | 'createdAt' | 'revokedAt'>,
  ): Promise<CompetitorAcknowledgementRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<CompetitorAcknowledgementRow | null>;
  findLive(organizationId: Uuid, competitorId: Uuid): Promise<CompetitorAcknowledgementRow | null>;
  revoke(organizationId: Uuid, id: Uuid, at: Date): Promise<CompetitorAcknowledgementRow | null>;
}

export interface CompetitorAnalysisRepository {
  create(input: Omit<CompetitorAnalysisRow, 'id' | 'createdAt'>): Promise<CompetitorAnalysisRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<CompetitorAnalysisRow | null>;
  findLatest(organizationId: Uuid, competitorId: Uuid): Promise<CompetitorAnalysisRow | null>;
  listForCompetitor(organizationId: Uuid, competitorId: Uuid, limit?: number): Promise<CompetitorAnalysisRow[]>;
  listForProject(organizationId: Uuid, projectId: Uuid, limit?: number): Promise<CompetitorAnalysisRow[]>;
  /** Analyses performed under one acknowledgement, for the RESTRICT rule. */
  listForAcknowledgement(organizationId: Uuid, acknowledgementId: Uuid): Promise<CompetitorAnalysisRow[]>;
}

export interface AdPlanRepository {
  create(input: Omit<AdPlanRow, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>): Promise<AdPlanRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<AdPlanRow | null>;
  listForProject(organizationId: Uuid, projectId: Uuid, platform?: AdPlanRow['platform']): Promise<AdPlanRow[]>;
  update(organizationId: Uuid, id: Uuid, patch: Partial<AdPlanRow>): Promise<AdPlanRow | null>;
  softDelete(organizationId: Uuid, id: Uuid, at: Date): Promise<void>;
}

export interface LeadRepository {
  create(input: Omit<LeadRow, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>): Promise<LeadRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<LeadRow | null>;
  listForProject(
    organizationId: Uuid,
    projectId: Uuid,
    filter?: { readonly stage?: LeadRow['stage']; readonly ownerUserId?: Uuid },
  ): Promise<LeadRow[]>;
  /** Duplicate detection before creating a lead. */
  findByEmail(organizationId: Uuid, projectId: Uuid, email: string): Promise<LeadRow | null>;
  findByPhone(organizationId: Uuid, projectId: Uuid, phone: string): Promise<LeadRow | null>;
  update(organizationId: Uuid, id: Uuid, patch: Partial<LeadRow>): Promise<LeadRow | null>;
  softDelete(organizationId: Uuid, id: Uuid, at: Date): Promise<void>;
}

export interface LeadActivityRepository {
  create(input: Omit<LeadActivityRow, 'id' | 'createdAt'>): Promise<LeadActivityRow>;
  listForLead(organizationId: Uuid, leadId: Uuid): Promise<LeadActivityRow[]>;
  /** Open follow-ups, soonest first. The "what is due" query. */
  listDue(organizationId: Uuid, before: Date): Promise<LeadActivityRow[]>;
  complete(organizationId: Uuid, id: Uuid, at: Date): Promise<LeadActivityRow | null>;
}

export interface MessagingPlanRepository {
  create(input: Omit<MessagingPlanRow, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>): Promise<MessagingPlanRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<MessagingPlanRow | null>;
  listForProject(
    organizationId: Uuid,
    projectId: Uuid,
    channel?: MessagingPlanRow['channel'],
  ): Promise<MessagingPlanRow[]>;
  update(organizationId: Uuid, id: Uuid, patch: Partial<MessagingPlanRow>): Promise<MessagingPlanRow | null>;
  softDelete(organizationId: Uuid, id: Uuid, at: Date): Promise<void>;
}

export interface VideoScriptRepository {
  create(input: Omit<VideoScriptRow, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>): Promise<VideoScriptRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<VideoScriptRow | null>;
  listForProject(organizationId: Uuid, projectId: Uuid): Promise<VideoScriptRow[]>;
  update(organizationId: Uuid, id: Uuid, patch: Partial<VideoScriptRow>): Promise<VideoScriptRow | null>;
  softDelete(organizationId: Uuid, id: Uuid, at: Date): Promise<void>;
}

/* -------------------------------------------------------------------------- */
/* Phase 6: analytics, calendar, automation, reports, notifications           */
/* -------------------------------------------------------------------------- */

export interface DataConnectionRepository {
  /** Every provider row for an organization. A provider with no row is not connected. */
  list(organizationId: Uuid, projectId: Uuid | null): Promise<DataConnectionRow[]>;
  findByProvider(
    organizationId: Uuid,
    projectId: Uuid | null,
    provider: DataConnectionRow['provider'],
  ): Promise<DataConnectionRow | null>;
  connect(input: Omit<DataConnectionRow, 'id' | 'createdAt' | 'updatedAt'>): Promise<DataConnectionRow>;
  disconnect(organizationId: Uuid, id: Uuid, at: Date): Promise<DataConnectionRow | null>;
}

export interface CalendarRepository {
  create(input: Omit<CalendarEventRow, 'id' | 'createdAt' | 'updatedAt'>): Promise<CalendarEventRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<CalendarEventRow | null>;
  /** Entries in a date range, inclusive at both ends. Dates are YYYY-MM-DD. */
  listInRange(
    organizationId: Uuid,
    projectId: Uuid,
    from: string,
    to: string,
  ): Promise<CalendarEventRow[]>;
  listForCampaign(organizationId: Uuid, campaign: string): Promise<CalendarEventRow[]>;
  /** Used to avoid creating a second derived entry for the same source record. */
  findBySource(organizationId: Uuid, sourceKind: string, sourceId: Uuid): Promise<CalendarEventRow | null>;
  update(organizationId: Uuid, id: Uuid, patch: Partial<CalendarEventRow>): Promise<CalendarEventRow | null>;
  remove(organizationId: Uuid, id: Uuid): Promise<void>;
}

export interface AutomationRepository {
  createRule(input: Omit<AutomationRuleRow, 'id' | 'createdAt' | 'updatedAt'>): Promise<AutomationRuleRow>;
  findRule(organizationId: Uuid, id: Uuid): Promise<AutomationRuleRow | null>;
  listRules(organizationId: Uuid, projectId: Uuid): Promise<AutomationRuleRow[]>;
  /** Enabled rules listening for one trigger. The evaluation query. */
  listEnabledFor(organizationId: Uuid, projectId: Uuid, triggerKind: string): Promise<AutomationRuleRow[]>;
  updateRule(organizationId: Uuid, id: Uuid, patch: Partial<AutomationRuleRow>): Promise<AutomationRuleRow | null>;
  removeRule(organizationId: Uuid, id: Uuid): Promise<void>;
  recordRun(input: Omit<AutomationRunRow, 'id'>): Promise<AutomationRunRow>;
  listRuns(organizationId: Uuid, ruleId: Uuid, limit?: number): Promise<AutomationRunRow[]>;
  /** Runs today, for the daily ceiling. Counts non-matches too: they cost work. */
  countRunsSince(organizationId: Uuid, since: Date): Promise<number>;
}

export interface ReportRepository {
  create(input: Omit<ReportRow, 'id'>): Promise<ReportRow>;
  findById(organizationId: Uuid, id: Uuid): Promise<ReportRow | null>;
  listForProject(organizationId: Uuid, projectId: Uuid, limit?: number): Promise<ReportRow[]>;
  remove(organizationId: Uuid, id: Uuid): Promise<void>;
}

export interface ReportShareRepository {
  create(input: Omit<ReportShareRow, 'id' | 'createdAt' | 'lastViewedAt' | 'viewCount'>): Promise<ReportShareRow>;
  /**
   * Looks a share up by the HASH of its token, with no organization filter —
   * this is the one deliberately un-tenanted read in the codebase, because the
   * caller is an anonymous visitor who has no organization. The token is the
   * only credential, which is why it is random, hashed, expiring and revocable.
   */
  findByTokenHash(tokenHash: string): Promise<ReportShareRow | null>;
  listForReport(organizationId: Uuid, reportId: Uuid): Promise<ReportShareRow[]>;
  revoke(organizationId: Uuid, id: Uuid, at: Date): Promise<ReportShareRow | null>;
  recordView(id: Uuid, at: Date): Promise<void>;
}

export interface NotificationPreferenceRepository {
  /** Stored rows only. A kind with no row takes the application default. */
  listForUser(organizationId: Uuid, userId: Uuid): Promise<NotificationPreferenceRow[]>;
  set(
    organizationId: Uuid,
    userId: Uuid,
    kind: string,
    patch: { readonly inApp?: boolean; readonly email?: boolean },
    at: Date,
  ): Promise<NotificationPreferenceRow>;
}

/* -------------------------------------------------------------------------- */
/* Phase 7: plans, usage, billing, the admin platform, feature flags         */
/* -------------------------------------------------------------------------- */

export interface PlanLimitRepository {
  listForOrganization(organizationId: Uuid): Promise<PlanLimitOverrideRow[]>;
  set(
    organizationId: Uuid,
    limitId: string,
    value: number | null,
    reason: string,
    setBy: Uuid | null,
    at: Date,
  ): Promise<PlanLimitOverrideRow>;
  clear(organizationId: Uuid, limitId: string): Promise<void>;
}

export interface QuotaRefusalRepository {
  record(input: Omit<QuotaRefusalRow, 'id' | 'refusedAt'> & { readonly refusedAt?: Date }): Promise<void>;
  listForOrganization(organizationId: Uuid, limit?: number): Promise<QuotaRefusalRow[]>;
  /** Refusals per limit since a date, across every tenant. Admin only. */
  countByLimitSince(since: Date): Promise<Record<string, number>>;
}

/**
 * Platform staff.
 *
 * NOT tenant-scoped, because platform staff are not tenant data. This is one of
 * only three repositories in the codebase whose methods do not take an
 * `organizationId`, and the others are `users` and `sessions` — identity, which
 * is also not tenant data.
 */
export interface PlatformStaffRepository {
  findByUser(userId: Uuid): Promise<PlatformStaffRow | null>;
  list(includeRevoked?: boolean): Promise<PlatformStaffRow[]>;
  grant(input: {
    readonly userId: Uuid;
    readonly role: PlatformStaffRow['role'];
    readonly grantedBy: Uuid;
    readonly reason: string;
    readonly at: Date;
  }): Promise<PlatformStaffRow>;
  revoke(userId: Uuid, revokedBy: Uuid, at: Date): Promise<PlatformStaffRow | null>;
  countActive(): Promise<number>;
}

export interface AdminActionRepository {
  record(input: Omit<AdminActionRow, 'id' | 'createdAt'>): Promise<void>;
  list(filter?: {
    readonly staffUserId?: Uuid;
    readonly targetOrganizationId?: Uuid;
    readonly kind?: 'read' | 'write';
    readonly limit?: number;
  }): Promise<AdminActionRow[]>;
}

export interface BillingEventRepository {
  /**
   * Records an event, refusing a duplicate.
   *
   * Returns null when `externalEventId` has already been seen — the caller then
   * knows not to apply the transition again. The database's UNIQUE constraint is
   * the real guarantee; this is the readable half of it.
   */
  record(input: Omit<BillingEventRow, 'id' | 'occurredAt'> & { readonly occurredAt?: Date }): Promise<BillingEventRow | null>;
  listForOrganization(organizationId: Uuid, limit?: number): Promise<BillingEventRow[]>;
  /** Across every tenant, for the admin panel. */
  listRecent(limit?: number): Promise<BillingEventRow[]>;
}

export interface FeatureFlagRepository {
  list(): Promise<FeatureFlagRuleRow[]>;
  find(key: string): Promise<FeatureFlagRuleRow | null>;
  upsert(input: Omit<FeatureFlagRuleRow, 'updatedAt'> & { readonly updatedAt?: Date }): Promise<FeatureFlagRuleRow>;
  remove(key: string): Promise<void>;
}

export interface SystemSettingRepository {
  get(key: string): Promise<SystemSettingRow | null>;
  list(prefix?: string): Promise<SystemSettingRow[]>;
  set(key: string, value: unknown, updatedBy: Uuid | null, at: Date): Promise<SystemSettingRow>;
  remove(key: string): Promise<void>;
}

export interface ErrorEventRepository {
  /** Upserts by fingerprint, incrementing the occurrence count. */
  record(input: {
    readonly fingerprint: string;
    readonly severity: ErrorEventRow['severity'];
    readonly source: string;
    readonly message: string;
    readonly organizationId: Uuid | null;
    readonly at: Date;
  }): Promise<ErrorEventRow>;
  listOpen(limit?: number): Promise<ErrorEventRow[]>;
  resolve(fingerprint: string, resolvedBy: Uuid, at: Date): Promise<ErrorEventRow | null>;
  countSince(since: Date): Promise<number>;
}

export interface FeedbackRepository {
  create(input: Omit<FeedbackRow, 'id' | 'createdAt' | 'status' | 'triagedBy' | 'triagedAt'>): Promise<FeedbackRow>;
  list(filter?: { readonly status?: FeedbackRow['status']; readonly limit?: number }): Promise<FeedbackRow[]>;
  setStatus(id: Uuid, status: FeedbackRow['status'], triagedBy: Uuid, at: Date): Promise<FeedbackRow | null>;
}

/**
 * Cross-tenant reads for the admin panel. THE DELIBERATE EXCEPTION.
 *
 * Every other repository method in this file takes an `organizationId` so it is
 * not possible to write a query that forgets the tenant filter. The admin panel
 * has to read across tenants by definition, and the honest way to allow that is
 * ONE narrow interface that says so in its name — not by relaxing the methods
 * every tenant-facing service already uses.
 *
 * WHAT IS NOT HERE, AND WHY
 * There is no method that returns customer CONTENT — no lead, no article, no
 * report body, no message. Support needs to know that an organization exists,
 * what plan it is on, how much it has used and whether its jobs are failing.
 * None of that requires reading what the customer wrote. A panel that showed a
 * support engineer every lead's email address would be a privacy incident with
 * a dashboard.
 */
export interface AdminReadRepository {
  countOrganizations(): Promise<number>;
  countUsers(): Promise<number>;
  countProjects(): Promise<number>;
  /** Metadata only, newest first. */
  listOrganizations(filter?: {
    readonly plan?: string;
    readonly status?: string;
    readonly query?: string;
    readonly limit?: number;
  }): Promise<
    readonly {
      readonly organization: OrganizationRow;
      readonly subscription: SubscriptionRow | null;
      readonly memberCount: number;
      readonly projectCount: number;
    }[]
  >;
  findOrganization(organizationId: Uuid): Promise<{
    readonly organization: OrganizationRow;
    readonly subscription: SubscriptionRow | null;
    readonly members: readonly { readonly user: UserRow; readonly role: MembershipRow['role'] }[];
    readonly businesses: readonly BusinessRow[];
    readonly projects: readonly ProjectRow[];
  } | null>;
  /** Usage totals for one organization in one period. */
  usageFor(organizationId: Uuid, periodStart: string): Promise<Record<string, number>>;
  /** Usage totals across every tenant, for the platform view. */
  usageTotals(periodStart: string): Promise<Record<string, number>>;
  /** Jobs across every tenant, for the crawl and schema job surfaces. */
  listJobs(filter?: {
    readonly kind?: string;
    readonly status?: string;
    readonly limit?: number;
  }): Promise<JobRow[]>;
  countJobsByStatus(): Promise<Record<string, number>>;
  /** Recent AI generations, as counts. Never the prompts or the outputs. */
  aiUsageSince(since: Date): Promise<{ readonly requests: number; readonly tokens: number }>;
  /** Security-relevant audit entries across every tenant. */
  listSecurityEvents(limit?: number): Promise<AuditLogRow[]>;
  countReports(): Promise<number>;
}

/* -------------------------------------------------------------------------- */
/* Public-site inbound (Phase 1)                                              */
/* -------------------------------------------------------------------------- */
// These are NOT tenant-scoped: they capture submissions from the public
// marketing site, which has no signed-in user and no organization.

export interface ContactSubmissionInput {
  readonly name: string;
  readonly email: string;
  readonly company: string;
  readonly topic: string;
  readonly message: string;
  readonly sourcePath?: string | null;
}

export interface ContactRepository {
  create(submission: ContactSubmissionInput): Promise<void>;
}

export interface NewsletterRepository {
  subscribe(email: string): Promise<void>;
}

export interface AuditLogRepository {
  record(input: Omit<AuditLogRow, 'id' | 'createdAt'>): Promise<void>;
  list(organizationId: Uuid, limit?: number): Promise<AuditLogRow[]>;
}

/* -------------------------------------------------------------------------- */
/* The database facade                                                        */
/* -------------------------------------------------------------------------- */

export interface Database {
  readonly users: UserRepository;
  readonly oauth: OAuthRepository;
  readonly sessions: SessionRepository;
  readonly emailVerification: VerificationTokenRepository;
  readonly passwordReset: PasswordResetRepository;
  readonly organizations: OrganizationRepository;
  readonly memberships: MembershipRepository;
  readonly businesses: BusinessRepository;
  readonly projects: ProjectRepository;
  readonly marketingProfiles: MarketingProfileRepository;
  readonly crawlConsents: CrawlConsentRepository;
  readonly brandKits: BrandKitRepository;
  readonly subscriptions: SubscriptionRepository;
  readonly usage: UsageRepository;
  readonly notifications: NotificationRepository;
  readonly aiConversations: AiConversationRepository;
  readonly audit: AuditLogRepository;
  readonly content: ContentRepository;
  readonly strategies: StrategyRepository;
  readonly socialPosts: SocialPostRepository;
  readonly jobs: JobRepository;
  readonly crawls: CrawlRepository;
  readonly audits: AuditRepository;
  readonly keywords: KeywordRepository;
  readonly schemaValidations: SchemaValidationRepository;
  readonly competitors: CompetitorRepository;
  readonly competitorAcknowledgements: CompetitorAcknowledgementRepository;
  readonly competitorAnalyses: CompetitorAnalysisRepository;
  readonly adPlans: AdPlanRepository;
  readonly leads: LeadRepository;
  readonly leadActivities: LeadActivityRepository;
  readonly messagingPlans: MessagingPlanRepository;
  readonly videoScripts: VideoScriptRepository;
  readonly dataConnections: DataConnectionRepository;
  readonly calendar: CalendarRepository;
  readonly automation: AutomationRepository;
  readonly reports: ReportRepository;
  readonly reportShares: ReportShareRepository;
  readonly notificationPreferences: NotificationPreferenceRepository;
  readonly planLimits: PlanLimitRepository;
  readonly quotaRefusals: QuotaRefusalRepository;
  readonly platformStaff: PlatformStaffRepository;
  readonly adminActions: AdminActionRepository;
  readonly billingEvents: BillingEventRepository;
  readonly featureFlags: FeatureFlagRepository;
  readonly systemSettings: SystemSettingRepository;
  readonly errors: ErrorEventRepository;
  readonly feedback: FeedbackRepository;
  readonly adminRead: AdminReadRepository;
  readonly contact: ContactRepository;
  readonly newsletter: NewsletterRepository;
  /** Test and development only. A PostgreSQL adapter must not implement this. */
  reset?(): void;
}
