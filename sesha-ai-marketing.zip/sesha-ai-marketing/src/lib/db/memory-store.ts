/**
 * In-memory database adapter.
 *
 * PURPOSE AND LIMITS — read before using this anywhere near production.
 *
 * This is a complete, working implementation of every repository interface,
 * which is what makes the authentication, tenancy and onboarding flows genuinely
 * executable and testable (`tests/auth-flow.test.ts` runs real sign-up, sign-in,
 * verification, reset and deletion against it).
 *
 * It is NOT a production database:
 *   · state lives in one process and is lost on restart;
 *   · it does not survive more than one server instance;
 *   · there are no transactions, so a multi-step failure leaves partial state.
 *
 * `getDatabase()` in ./index.ts refuses to select this adapter in production
 * unless explicitly overridden, so it cannot be reached by accident.
 *
 * TENANT FILTERING IS IMPLEMENTED HERE TOO. Every scoped method filters by
 * organizationId exactly as the SQL adapter's WHERE clause will, so the
 * isolation tests exercise real behaviour rather than a permissive stub.
 */

import { randomUUID } from 'node:crypto';

import type {
  AdPlanRow,
  AdminActionRow,
  BillingEventRow,
  ErrorEventRow,
  FeatureFlagRuleRow,
  FeedbackRow,
  PlanLimitOverrideRow,
  PlatformStaffRow,
  QuotaRefusalRow,
  SystemSettingRow,
  AutomationRuleRow,
  AutomationRunRow,
  CalendarEventRow,
  DataConnectionRow,
  NotificationPreferenceRow,
  ReportRow,
  ReportShareRow,
  AiConversationRow,
  AiMessageRow,
  AuditLogRow,
  AuditRow,
  BrandKitRow,
  ContentItemRow,
  CompetitorAcknowledgementRow,
  CompetitorAnalysisRow,
  CompetitorRow,
  CrawlRow,
  CrawledPageRow,
  JobRow,
  KeywordRow,
  LeadActivityRow,
  LeadRow,
  MessagingPlanRow,
  SchemaValidationRow,
  VideoScriptRow,
  SocialPostRow,
  StrategyRow,
  BusinessRow,
  CrawlConsentRow,
  MarketingProfileRow,
  MembershipRow,
  NotificationRow,
  OAuthAccountRow,
  OrganizationRow,
  PasswordResetRow,
  ProjectRow,
  SessionRow,
  SubscriptionRow,
  UsageRow,
  UserRow,
  Uuid,
  VerificationTokenRow,
} from './types';
import type {
  AdPlanRepository,
  AdminActionRepository,
  AdminReadRepository,
  BillingEventRepository,
  ErrorEventRepository,
  FeatureFlagRepository,
  FeedbackRepository,
  PlanLimitRepository,
  PlatformStaffRepository,
  QuotaRefusalRepository,
  SystemSettingRepository,
  AutomationRepository,
  CalendarRepository,
  DataConnectionRepository,
  NotificationPreferenceRepository,
  ReportRepository,
  ReportShareRepository,
  AiConversationRepository,
  AuditLogRepository,
  AuditRepository,
  CompetitorAcknowledgementRepository,
  CompetitorAnalysisRepository,
  CompetitorRepository,
  LeadActivityRepository,
  LeadRepository,
  MessagingPlanRepository,
  SchemaValidationRepository,
  VideoScriptRepository,
  ContentRepository,
  CrawlRepository,
  JobRepository,
  KeywordRepository,
  SocialPostRepository,
  StrategyRepository,
  ContactRepository,
  ContactSubmissionInput,
  NewsletterRepository,
  BrandKitRepository,
  BusinessRepository,
  CrawlConsentRepository,
  CreateUserInput,
  Database,
  MarketingProfileRepository,
  MembershipRepository,
  NotificationRepository,
  OAuthRepository,
  OrganizationRepository,
  PasswordResetRepository,
  ProjectRepository,
  SessionRepository,
  SubscriptionRepository,
  UsageRepository,
  UserRepository,
  VerificationTokenRepository,
} from './repositories';

function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

/** Marketing-profile completeness, 0–100. Stored so lists need not recompute. */
export function profileCompleteness(
  profile: Pick<
    MarketingProfileRow,
    'targetAudience' | 'productsServices' | 'priceRange' | 'marketingGoals' | 'marketingChannels' | 'brandVoice' | 'competitors'
  >,
): number {
  const checks = [
    Boolean(profile.targetAudience?.trim()),
    Boolean(profile.productsServices?.trim()),
    Boolean(profile.priceRange),
    profile.marketingGoals.length > 0,
    profile.marketingChannels.length > 0,
    Object.keys(profile.brandVoice).length > 0,
    profile.competitors.length > 0,
  ];
  const met = checks.filter(Boolean).length;
  return Math.round((met / checks.length) * 100);
}

interface Tables {
  users: UserRow[];
  oauth: OAuthAccountRow[];
  sessions: SessionRow[];
  emailVerification: VerificationTokenRow[];
  passwordReset: PasswordResetRow[];
  organizations: OrganizationRow[];
  memberships: MembershipRow[];
  businesses: BusinessRow[];
  projects: ProjectRow[];
  marketingProfiles: MarketingProfileRow[];
  crawlConsents: CrawlConsentRow[];
  brandKits: BrandKitRow[];
  subscriptions: SubscriptionRow[];
  usage: UsageRow[];
  notifications: NotificationRow[];
  aiConversations: AiConversationRow[];
  aiMessages: AiMessageRow[];
  content: ContentItemRow[];
  strategies: StrategyRow[];
  socialPosts: SocialPostRow[];
  jobs: JobRow[];
  crawls: CrawlRow[];
  crawledPages: CrawledPageRow[];
  audits: AuditRow[];
  keywords: KeywordRow[];
  schemaValidations: SchemaValidationRow[];
  competitors: CompetitorRow[];
  competitorAcknowledgements: CompetitorAcknowledgementRow[];
  competitorAnalyses: CompetitorAnalysisRow[];
  adPlans: AdPlanRow[];
  leads: LeadRow[];
  leadActivities: LeadActivityRow[];
  messagingPlans: MessagingPlanRow[];
  videoScripts: VideoScriptRow[];
  dataConnections: DataConnectionRow[];
  calendarEvents: CalendarEventRow[];
  automationRules: AutomationRuleRow[];
  automationRuns: AutomationRunRow[];
  reports: ReportRow[];
  reportShares: ReportShareRow[];
  notificationPreferences: NotificationPreferenceRow[];
  planLimitOverrides: PlanLimitOverrideRow[];
  quotaRefusals: QuotaRefusalRow[];
  platformStaff: PlatformStaffRow[];
  adminActions: AdminActionRow[];
  billingEvents: BillingEventRow[];
  featureFlagRules: FeatureFlagRuleRow[];
  systemSettings: SystemSettingRow[];
  errorEvents: ErrorEventRow[];
  feedback: FeedbackRow[];
  audit: AuditLogRow[];
}

function emptyTables(): Tables {
  return {
    users: [],
    oauth: [],
    sessions: [],
    emailVerification: [],
    passwordReset: [],
    organizations: [],
    memberships: [],
    businesses: [],
    projects: [],
    marketingProfiles: [],
    crawlConsents: [],
    brandKits: [],
    subscriptions: [],
    usage: [],
    notifications: [],
    aiConversations: [],
    aiMessages: [],
    content: [],
    strategies: [],
    socialPosts: [],
    jobs: [],
    crawls: [],
    crawledPages: [],
    audits: [],
    keywords: [],
    schemaValidations: [],
    competitors: [],
    competitorAcknowledgements: [],
    competitorAnalyses: [],
    adPlans: [],
    leads: [],
    leadActivities: [],
    messagingPlans: [],
    videoScripts: [],
    dataConnections: [],
    calendarEvents: [],
    automationRules: [],
    automationRuns: [],
    reports: [],
    reportShares: [],
    notificationPreferences: [],
    planLimitOverrides: [],
    quotaRefusals: [],
    platformStaff: [],
    adminActions: [],
    billingEvents: [],
    featureFlagRules: [],
    systemSettings: [],
    errorEvents: [],
    feedback: [],
    audit: [],
  };
}

export class MemoryDatabase implements Database {
  private t: Tables = emptyTables();

  reset(): void {
    this.t = emptyTables();
  }

  /* ------------------------------ users --------------------------------- */

  readonly users: UserRepository = {
    findByEmail: async (email) => {
      const target = normalizeEmail(email);
      // Soft-deleted accounts must not be findable for sign-in.
      return this.t.users.find((u) => u.email === target && u.deletedAt === null) ?? null;
    },
    findById: async (id) => this.t.users.find((u) => u.id === id) ?? null,
    create: async (input: CreateUserInput) => {
      const now = new Date();
      const row: UserRow = {
        id: randomUUID(),
        email: normalizeEmail(input.email),
        name: input.name,
        passwordHash: input.passwordHash,
        emailVerifiedAt: input.emailVerifiedAt ?? null,
        onboardingCompletedAt: null,
        passwordChangedAt: input.passwordHash ? now : null,
        deletedAt: null,
        deletionRequestedAt: null,
        lastLoginAt: null,
        locale: 'en',
        timezone: null,
        createdAt: now,
        updatedAt: now,
      };
      this.t.users.push(row);
      return row;
    },
    update: async (id, patch) => {
      const index = this.t.users.findIndex((u) => u.id === id);
      if (index === -1) throw new Error('User not found.');
      const updated = { ...this.t.users[index]!, ...patch, updatedAt: new Date() } as UserRow;
      this.t.users[index] = updated;
      return updated;
    },
    markEmailVerified: async (id, at) => {
      await this.users.update(id, { emailVerifiedAt: at });
    },
    setPassword: async (id, passwordHash, at) => {
      await this.users.update(id, { passwordHash, passwordChangedAt: at });
    },
    recordLogin: async (id, at) => {
      await this.users.update(id, { lastLoginAt: at });
    },
    softDelete: async (id, at) => {
      await this.users.update(id, { deletedAt: at, deletionRequestedAt: at });
    },
  };

  /* ------------------------------ oauth --------------------------------- */

  readonly oauth: OAuthRepository = {
    findByProviderUserId: async (provider, providerUserId) =>
      this.t.oauth.find((a) => a.provider === provider && a.providerUserId === providerUserId) ?? null,
    listForUser: async (userId) => this.t.oauth.filter((a) => a.userId === userId),
    link: async (input) => {
      const row: OAuthAccountRow = {
        id: randomUUID(),
        userId: input.userId,
        provider: input.provider,
        providerUserId: input.providerUserId,
        email: input.email ? normalizeEmail(input.email) : null,
        emailVerified: input.emailVerified,
        createdAt: new Date(),
        lastLoginAt: null,
      };
      this.t.oauth.push(row);
      return row;
    },
    recordLogin: async (id, at) => {
      const index = this.t.oauth.findIndex((a) => a.id === id);
      if (index !== -1) this.t.oauth[index] = { ...this.t.oauth[index]!, lastLoginAt: at };
    },
    unlink: async (userId, provider) => {
      this.t.oauth = this.t.oauth.filter((a) => !(a.userId === userId && a.provider === provider));
    },
  };

  /* ----------------------------- sessions -------------------------------- */

  readonly sessions: SessionRepository = {
    create: async (input) => {
      const row: SessionRow = { id: randomUUID(), ...input };
      this.t.sessions.push(row);
      return row;
    },
    findByTokenHash: async (tokenHash) =>
      this.t.sessions.find((s) => s.tokenHash === tokenHash) ?? null,
    touch: async (id, at) => {
      const index = this.t.sessions.findIndex((s) => s.id === id);
      if (index !== -1) this.t.sessions[index] = { ...this.t.sessions[index]!, lastActiveAt: at };
    },
    revoke: async (id, at) => {
      const index = this.t.sessions.findIndex((s) => s.id === id);
      if (index !== -1) this.t.sessions[index] = { ...this.t.sessions[index]!, revokedAt: at };
    },
    revokeAllForUser: async (userId, at, exceptSessionId) => {
      let revoked = 0;
      this.t.sessions = this.t.sessions.map((s) => {
        if (s.userId !== userId || s.revokedAt !== null || s.id === exceptSessionId) return s;
        revoked += 1;
        return { ...s, revokedAt: at };
      });
      return revoked;
    },
    listActiveForUser: async (userId, now) =>
      this.t.sessions.filter(
        (s) => s.userId === userId && s.revokedAt === null && s.expiresAt.getTime() > now.getTime(),
      ),
    grantSudo: async (id, until) => {
      const index = this.t.sessions.findIndex((s) => s.id === id);
      if (index !== -1) this.t.sessions[index] = { ...this.t.sessions[index]!, sudoUntil: until };
    },
  };

  /* ------------------------------ tokens --------------------------------- */

  readonly emailVerification: VerificationTokenRepository = {
    create: async (input) => {
      const row: VerificationTokenRow = {
        id: randomUUID(),
        createdAt: new Date(),
        usedAt: null,
        ...input,
      };
      this.t.emailVerification.push(row);
      return row;
    },
    findByTokenHash: async (tokenHash) =>
      this.t.emailVerification.find((t) => t.tokenHash === tokenHash) ?? null,
    consume: async (tokenHash, at) => {
      const index = this.t.emailVerification.findIndex((t) => t.tokenHash === tokenHash);
      if (index === -1) return false;
      const row = this.t.emailVerification[index]!;
      // Single use, and never after expiry.
      if (row.usedAt !== null) return false;
      if (row.expiresAt.getTime() <= at.getTime()) return false;
      this.t.emailVerification[index] = { ...row, usedAt: at };
      return true;
    },
    invalidateAllForUser: async (userId, at) => {
      this.t.emailVerification = this.t.emailVerification.map((t) =>
        t.userId === userId && t.usedAt === null ? { ...t, usedAt: at } : t,
      );
    },
  };

  readonly passwordReset: PasswordResetRepository = {
    create: async (input) => {
      const row: PasswordResetRow = {
        id: randomUUID(),
        createdAt: new Date(),
        usedAt: null,
        ...input,
      };
      this.t.passwordReset.push(row);
      return row;
    },
    findByTokenHash: async (tokenHash) =>
      this.t.passwordReset.find((t) => t.tokenHash === tokenHash) ?? null,
    consume: async (tokenHash, at) => {
      const index = this.t.passwordReset.findIndex((t) => t.tokenHash === tokenHash);
      if (index === -1) return false;
      const row = this.t.passwordReset[index]!;
      if (row.usedAt !== null) return false;
      if (row.expiresAt.getTime() <= at.getTime()) return false;
      this.t.passwordReset[index] = { ...row, usedAt: at };
      return true;
    },
    invalidateAllForUser: async (userId, at) => {
      this.t.passwordReset = this.t.passwordReset.map((t) =>
        t.userId === userId && t.usedAt === null ? { ...t, usedAt: at } : t,
      );
    },
  };

  /* --------------------------- organizations ----------------------------- */

  readonly organizations: OrganizationRepository = {
    create: async (input) => {
      const now = new Date();
      const row: OrganizationRow = {
        id: randomUUID(),
        name: input.name,
        slug: input.slug.toLowerCase(),
        plan: 'free',
        createdAt: now,
        updatedAt: now,
      };
      this.t.organizations.push(row);
      return row;
    },
    findById: async (id) => this.t.organizations.find((o) => o.id === id) ?? null,
    findBySlug: async (slug) =>
      this.t.organizations.find((o) => o.slug === slug.toLowerCase()) ?? null,
  };

  readonly memberships: MembershipRepository = {
    create: async (input) => {
      this.t.memberships.push(input);
      return input;
    },
    findForUser: async (userId) => this.t.memberships.filter((m) => m.userId === userId),
    find: async (organizationId, userId) =>
      this.t.memberships.find((m) => m.organizationId === organizationId && m.userId === userId) ??
      null,
    listForOrganization: async (organizationId) =>
      this.t.memberships.filter((m) => m.organizationId === organizationId),
    updateRole: async (organizationId, userId, role) => {
      const index = this.t.memberships.findIndex(
        (m) => m.organizationId === organizationId && m.userId === userId,
      );
      if (index !== -1) this.t.memberships[index] = { ...this.t.memberships[index]!, role };
    },
    remove: async (organizationId, userId) => {
      this.t.memberships = this.t.memberships.filter(
        (m) => !(m.organizationId === organizationId && m.userId === userId),
      );
    },
  };

  /* ----------------------------- businesses ------------------------------ */

  readonly businesses: BusinessRepository = {
    create: async (input) => {
      const now = new Date();
      const row: BusinessRow = { id: randomUUID(), deletedAt: null, createdAt: now, updatedAt: now, ...input };
      this.t.businesses.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.businesses.find(
        (b) => b.id === id && b.organizationId === organizationId && b.deletedAt === null,
      ) ?? null,
    listForOrganization: async (organizationId) =>
      this.t.businesses.filter((b) => b.organizationId === organizationId && b.deletedAt === null),
    update: async (organizationId, id, patch) => {
      const index = this.t.businesses.findIndex(
        (b) => b.id === id && b.organizationId === organizationId && b.deletedAt === null,
      );
      if (index === -1) return null;
      const updated = { ...this.t.businesses[index]!, ...patch, updatedAt: new Date() };
      this.t.businesses[index] = updated;
      return updated;
    },
    softDelete: async (organizationId, id, at) => {
      await this.businesses.update(organizationId, id, { deletedAt: at });
    },
  };

  /* ------------------------------ projects ------------------------------- */

  readonly projects: ProjectRepository = {
    create: async (input) => {
      const now = new Date();
      const row: ProjectRow = { id: randomUUID(), deletedAt: null, createdAt: now, updatedAt: now, ...input };
      this.t.projects.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.projects.find(
        (p) => p.id === id && p.organizationId === organizationId && p.deletedAt === null,
      ) ?? null,
    findBySlug: async (organizationId, slug) =>
      this.t.projects.find(
        (p) =>
          p.slug.toLowerCase() === slug.toLowerCase() &&
          p.organizationId === organizationId &&
          p.deletedAt === null,
      ) ?? null,
    listForOrganization: async (organizationId) =>
      this.t.projects.filter((p) => p.organizationId === organizationId && p.deletedAt === null),
    update: async (organizationId, id, patch) => {
      const index = this.t.projects.findIndex(
        (p) => p.id === id && p.organizationId === organizationId && p.deletedAt === null,
      );
      if (index === -1) return null;
      const updated = { ...this.t.projects[index]!, ...patch, updatedAt: new Date() };
      this.t.projects[index] = updated;
      return updated;
    },
    softDelete: async (organizationId, id, at) => {
      await this.projects.update(organizationId, id, { deletedAt: at });
    },
    countForOrganization: async (organizationId) =>
      this.t.projects.filter((p) => p.organizationId === organizationId && p.deletedAt === null)
        .length,
  };

  /* ------------------------- marketing profiles -------------------------- */

  readonly marketingProfiles: MarketingProfileRepository = {
    upsert: async (input) => {
      const now = new Date();
      const completeness = profileCompleteness(input);
      const index = this.t.marketingProfiles.findIndex(
        (p) => p.projectId === input.projectId && p.organizationId === input.organizationId,
      );
      if (index !== -1) {
        const updated = { ...this.t.marketingProfiles[index]!, ...input, completeness, updatedAt: now };
        this.t.marketingProfiles[index] = updated;
        return updated;
      }
      const row: MarketingProfileRow = {
        id: randomUUID(),
        createdAt: now,
        updatedAt: now,
        completeness,
        ...input,
      };
      this.t.marketingProfiles.push(row);
      return row;
    },
    findByProject: async (organizationId, projectId) =>
      this.t.marketingProfiles.find(
        (p) => p.projectId === projectId && p.organizationId === organizationId,
      ) ?? null,
  };

  /* ----------------------------- crawl consent --------------------------- */

  readonly crawlConsents: CrawlConsentRepository = {
    grant: async (input) => {
      const row: CrawlConsentRow = {
        id: randomUUID(),
        grantedAt: new Date(),
        revokedAt: null,
        dataDeletedAt: null,
        ...input,
      };
      this.t.crawlConsents.push(row);
      return row;
    },
    findActiveForProject: async (organizationId, projectId) =>
      this.t.crawlConsents.find(
        (c) => c.organizationId === organizationId && c.projectId === projectId && c.revokedAt === null,
      ) ?? null,
    findById: async (organizationId, id) =>
      this.t.crawlConsents.find((c) => c.id === id && c.organizationId === organizationId) ?? null,

    listForProject: async (organizationId, projectId) =>
      this.t.crawlConsents.filter(
        (c) => c.organizationId === organizationId && c.projectId === projectId,
      ),
    revoke: async (organizationId, id, at) => {
      const index = this.t.crawlConsents.findIndex(
        (c) => c.id === id && c.organizationId === organizationId,
      );
      if (index !== -1) this.t.crawlConsents[index] = { ...this.t.crawlConsents[index]!, revokedAt: at };
    },
    markDataDeleted: async (organizationId, id, at) => {
      const index = this.t.crawlConsents.findIndex(
        (c) => c.id === id && c.organizationId === organizationId,
      );
      if (index !== -1) {
        this.t.crawlConsents[index] = { ...this.t.crawlConsents[index]!, dataDeletedAt: at };
      }
    },
  };

  /* ------------------------------ brand kits ------------------------------ */

  readonly brandKits: BrandKitRepository = {
    upsert: async (input) => {
      const now = new Date();
      const index = this.t.brandKits.findIndex(
        (b) => b.projectId === input.projectId && b.organizationId === input.organizationId,
      );
      if (index !== -1) {
        const updated = { ...this.t.brandKits[index]!, ...input, updatedAt: now };
        this.t.brandKits[index] = updated;
        return updated;
      }
      const row: BrandKitRow = { id: randomUUID(), createdAt: now, updatedAt: now, ...input };
      this.t.brandKits.push(row);
      return row;
    },
    findByProject: async (organizationId, projectId) =>
      this.t.brandKits.find(
        (b) => b.projectId === projectId && b.organizationId === organizationId,
      ) ?? null,
  };

  /* --------------------------- subscriptions ------------------------------ */

  readonly subscriptions: SubscriptionRepository = {
    create: async (input) => {
      const now = new Date();
      const row: SubscriptionRow = { id: randomUUID(), createdAt: now, updatedAt: now, ...input };
      this.t.subscriptions.push(row);
      return row;
    },
    findForOrganization: async (organizationId) =>
      this.t.subscriptions.find((s) => s.organizationId === organizationId) ?? null,
    update: async (organizationId, patch) => {
      const index = this.t.subscriptions.findIndex((s) => s.organizationId === organizationId);
      if (index === -1) return null;
      const updated = { ...this.t.subscriptions[index]!, ...patch, updatedAt: new Date() };
      this.t.subscriptions[index] = updated;
      return updated;
    },
  };

  readonly usage: UsageRepository = {
    record: async (input) => {
      this.t.usage.push({ id: randomUUID(), recordedAt: new Date(), ...input });
    },
    totalFor: async (organizationId, metric, periodStart) =>
      this.t.usage
        .filter(
          (u) =>
            u.organizationId === organizationId &&
            u.metric === metric &&
            u.periodStart === periodStart,
        )
        .reduce((total, u) => total + u.quantity, 0),
    listForPeriod: async (organizationId, periodStart) =>
      this.t.usage.filter(
        (u) => u.organizationId === organizationId && u.periodStart === periodStart,
      ),
  };

  readonly notifications: NotificationRepository = {
    create: async (input) => {
      const row: NotificationRow = { id: randomUUID(), createdAt: new Date(), readAt: null, ...input };
      this.t.notifications.push(row);
      return row;
    },
    listForUser: async (organizationId, userId, limit = 50) =>
      this.t.notifications
        .filter((n) => n.organizationId === organizationId && n.userId === userId)
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, limit),
    countUnread: async (organizationId, userId) =>
      this.t.notifications.filter(
        (n) => n.organizationId === organizationId && n.userId === userId && n.readAt === null,
      ).length,
    markRead: async (organizationId, id, at) => {
      const index = this.t.notifications.findIndex(
        (n) => n.id === id && n.organizationId === organizationId,
      );
      if (index !== -1) this.t.notifications[index] = { ...this.t.notifications[index]!, readAt: at };
    },
  };

  readonly aiConversations: AiConversationRepository = {
    create: async (input) => {
      const now = new Date();
      const row: AiConversationRow = {
        id: randomUUID(),
        createdAt: now,
        updatedAt: now,
        archivedAt: null,
        ...input,
      };
      this.t.aiConversations.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.aiConversations.find((c) => c.id === id && c.organizationId === organizationId) ?? null,
    listForProject: async (organizationId, projectId) =>
      this.t.aiConversations.filter(
        (c) => c.organizationId === organizationId && c.projectId === projectId && c.archivedAt === null,
      ),
    appendMessage: async (input) => {
      const row: AiMessageRow = { id: randomUUID(), createdAt: new Date(), ...input };
      this.t.aiMessages.push(row);
      return row;
    },
    listMessages: async (organizationId, conversationId) =>
      this.t.aiMessages.filter(
        (m) => m.conversationId === conversationId && m.organizationId === organizationId,
      ),
  };

  /* ------------------------- generated artefacts ------------------------- */
  // Every method filters by organizationId exactly as the SQL WHERE clause
  // will, so the isolation tests exercise real behaviour.

  readonly content: ContentRepository = {
    create: async (input) => {
      const now = new Date();
      const row: ContentItemRow = {
        id: randomUUID(),
        reviewedBy: null,
        reviewedAt: null,
        deletedAt: null,
        createdAt: now,
        updatedAt: now,
        ...input,
      };
      this.t.content.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.content.find(
        (c) => c.id === id && c.organizationId === organizationId && c.deletedAt === null,
      ) ?? null,
    listForProject: async (organizationId, projectId, limit = 100) =>
      this.t.content
        .filter(
          (c) =>
            c.organizationId === organizationId &&
            c.projectId === projectId &&
            c.deletedAt === null,
        )
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, limit),
    update: async (organizationId, id, patch) => {
      const index = this.t.content.findIndex(
        (c) => c.id === id && c.organizationId === organizationId && c.deletedAt === null,
      );
      if (index === -1) return null;
      const updated = { ...this.t.content[index]!, ...patch, updatedAt: new Date() };
      this.t.content[index] = updated;
      return updated;
    },
    softDelete: async (organizationId, id, at) => {
      await this.content.update(organizationId, id, { deletedAt: at });
    },
  };

  readonly strategies: StrategyRepository = {
    create: async (input) => {
      const now = new Date();
      const row: StrategyRow = {
        id: randomUUID(),
        deletedAt: null,
        createdAt: now,
        updatedAt: now,
        ...input,
      };
      this.t.strategies.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.strategies.find(
        (s) => s.id === id && s.organizationId === organizationId && s.deletedAt === null,
      ) ?? null,
    listForProject: async (organizationId, projectId) =>
      this.t.strategies
        .filter(
          (s) =>
            s.organizationId === organizationId &&
            s.projectId === projectId &&
            s.deletedAt === null,
        )
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()),
    findApproved: async (organizationId, projectId) =>
      this.t.strategies.find(
        (s) =>
          s.organizationId === organizationId &&
          s.projectId === projectId &&
          s.status === 'approved' &&
          s.deletedAt === null,
      ) ?? null,
    update: async (organizationId, id, patch) => {
      const index = this.t.strategies.findIndex(
        (s) => s.id === id && s.organizationId === organizationId && s.deletedAt === null,
      );
      if (index === -1) return null;
      const current = this.t.strategies[index]!;
      // Mirrors the partial unique index: at most one approved strategy per
      // project. Approving a new one supersedes the previous.
      if (patch.status === 'approved') {
        this.t.strategies = this.t.strategies.map((s) =>
          s.projectId === current.projectId && s.id !== id && s.status === 'approved'
            ? { ...s, status: 'archived' as const }
            : s,
        );
      }
      const refreshed = this.t.strategies.findIndex((s) => s.id === id);
      const updated = { ...this.t.strategies[refreshed]!, ...patch, updatedAt: new Date() };
      this.t.strategies[refreshed] = updated;
      return updated;
    },
    softDelete: async (organizationId, id, at) => {
      await this.strategies.update(organizationId, id, { deletedAt: at });
    },
  };

  readonly socialPosts: SocialPostRepository = {
    create: async (input) => {
      const now = new Date();
      const row: SocialPostRow = {
        id: randomUUID(),
        deletedAt: null,
        createdAt: now,
        updatedAt: now,
        ...input,
      };
      this.t.socialPosts.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.socialPosts.find(
        (p) => p.id === id && p.organizationId === organizationId && p.deletedAt === null,
      ) ?? null,
    listForProject: async (organizationId, projectId) =>
      this.t.socialPosts.filter(
        (p) =>
          p.organizationId === organizationId &&
          p.projectId === projectId &&
          p.deletedAt === null,
      ),
    listForCalendar: async (organizationId, projectId, from, to) =>
      this.t.socialPosts
        .filter(
          (p) =>
            p.organizationId === organizationId &&
            p.projectId === projectId &&
            p.deletedAt === null &&
            p.plannedFor !== null &&
            p.plannedFor >= from &&
            p.plannedFor <= to,
        )
        .sort((a, b) => (a.plannedFor ?? '').localeCompare(b.plannedFor ?? '')),
    update: async (organizationId, id, patch) => {
      const index = this.t.socialPosts.findIndex(
        (p) => p.id === id && p.organizationId === organizationId && p.deletedAt === null,
      );
      if (index === -1) return null;
      const updated = { ...this.t.socialPosts[index]!, ...patch, updatedAt: new Date() };
      this.t.socialPosts[index] = updated;
      return updated;
    },
    softDelete: async (organizationId, id, at) => {
      await this.socialPosts.update(organizationId, id, { deletedAt: at });
    },
  };

  /*
   * Public-site submissions. Phase 1's posture is preserved deliberately: the
   * message body and the subscriber address are NOT retained, only the fact of
   * receipt plus an email domain, so logs never become a store of personal
   * data. A PostgreSQL adapter writes the full row to contact_submissions.
   */
  readonly contact: ContactRepository = {
    create: async (submission: ContactSubmissionInput) => {
      console.info(
        JSON.stringify({
          event: 'contact.submission.received',
          topic: submission.topic,
          emailDomain: `***@${submission.email.split('@')[1] ?? 'unknown'}`,
          messageLength: submission.message.length,
          at: new Date().toISOString(),
        }),
      );
    },
  };

  readonly newsletter: NewsletterRepository = {
    subscribe: async (email: string) => {
      console.info(
        JSON.stringify({
          event: 'newsletter.subscribe.received',
          emailDomain: `***@${email.split('@')[1] ?? 'unknown'}`,
          at: new Date().toISOString(),
        }),
      );
    },
  };

  /* ------------------------------- jobs ---------------------------------- */

  readonly jobs: JobRepository = {
    create: async (input) => {
      const now = new Date();
      const row: JobRow = {
        id: randomUUID(),
        organizationId: input.organizationId,
        projectId: input.projectId,
        createdBy: input.createdBy,
        kind: input.kind,
        status: 'queued',
        progressDone: 0,
        progressTotal: null,
        progressMessage: '',
        cancelRequested: false,
        attempts: 0,
        failureCode: null,
        failureDetail: null,
        input: input.input,
        resultId: null,
        notBefore: input.notBefore ?? null,
        queuedAt: now,
        startedAt: null,
        finishedAt: null,
        createdAt: now,
        updatedAt: now,
      };
      this.t.jobs.push(row);
      return row;
    },

    findById: async (organizationId, id) =>
      this.t.jobs.find((job) => job.id === id && job.organizationId === organizationId) ?? null,

    listForProject: async (organizationId, projectId, kind) =>
      this.t.jobs
        .filter((job) =>
          job.organizationId === organizationId &&
          job.projectId === projectId &&
          (kind === undefined || job.kind === kind))
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()),

    findActive: async (organizationId, projectId, kind) =>
      this.t.jobs.find((job) =>
        job.organizationId === organizationId &&
        job.projectId === projectId &&
        job.kind === kind &&
        (job.status === 'queued' || job.status === 'running')) ?? null,

    // Single-threaded, so read-then-write is atomic here. A PostgreSQL adapter
    // must use SELECT ... FOR UPDATE SKIP LOCKED; see the interface comment.
    claimNext: async (now, kinds) => {
      const index = this.t.jobs.findIndex((job) =>
        job.status === 'queued' &&
        (job.notBefore === null || job.notBefore <= now) &&
        (kinds === undefined || kinds.includes(job.kind)));
      if (index === -1) return null;

      const existing = this.t.jobs[index]!;
      const claimed: JobRow = {
        ...existing,
        status: 'running',
        attempts: existing.attempts + 1,
        startedAt: now,
        updatedAt: now,
      };
      this.t.jobs[index] = claimed;
      return claimed;
    },

    updateProgress: async (id, done, total, message) => {
      const index = this.t.jobs.findIndex((job) => job.id === id);
      if (index === -1) return;
      this.t.jobs[index] = {
        ...this.t.jobs[index]!,
        progressDone: done,
        progressTotal: total,
        progressMessage: message.slice(0, 300),
        updatedAt: new Date(),
      };
    },

    requestCancel: async (organizationId, id) => {
      const index = this.t.jobs.findIndex(
        (job) => job.id === id && job.organizationId === organizationId,
      );
      if (index === -1) return null;
      const existing = this.t.jobs[index]!;

      // A queued job can be cancelled outright — no worker has it yet.
      if (existing.status === 'queued') {
        const cancelled: JobRow = {
          ...existing,
          status: 'cancelled',
          cancelRequested: true,
          finishedAt: new Date(),
          updatedAt: new Date(),
        };
        this.t.jobs[index] = cancelled;
        return cancelled;
      }
      if (existing.status !== 'running') return existing;

      // A running job is only ASKED to stop; it transitions itself.
      const requested: JobRow = { ...existing, cancelRequested: true, updatedAt: new Date() };
      this.t.jobs[index] = requested;
      return requested;
    },

    finish: async (id, status, at, detail) => {
      const index = this.t.jobs.findIndex((job) => job.id === id);
      if (index === -1) return null;
      const finished: JobRow = {
        ...this.t.jobs[index]!,
        status,
        finishedAt: at,
        updatedAt: at,
        failureCode: detail?.failureCode ?? null,
        failureDetail: detail?.failureDetail ?? null,
        resultId: detail?.resultId ?? this.t.jobs[index]!.resultId,
      };
      this.t.jobs[index] = finished;
      return finished;
    },

    requeue: async (organizationId, id, notBefore) => {
      const index = this.t.jobs.findIndex(
        (job) => job.id === id && job.organizationId === organizationId,
      );
      if (index === -1) return null;
      const requeued: JobRow = {
        ...this.t.jobs[index]!,
        status: 'queued',
        finishedAt: null,
        failureCode: null,
        failureDetail: null,
        cancelRequested: false,
        progressDone: 0,
        progressMessage: '',
        notBefore,
        updatedAt: new Date(),
      };
      this.t.jobs[index] = requeued;
      return requeued;
    },

    findStale: async (before) =>
      this.t.jobs.filter(
        (job) => job.status === 'running' && job.startedAt !== null && job.startedAt < before,
      ),
  };

  /* ------------------------------ crawls --------------------------------- */

  readonly crawls: CrawlRepository = {
    create: async (input) => {
      const now = new Date();
      const row: CrawlRow = { id: randomUUID(), createdAt: now, updatedAt: now, ...input };
      this.t.crawls.push(row);
      return row;
    },

    findById: async (organizationId, id) =>
      this.t.crawls.find((crawl) => crawl.id === id && crawl.organizationId === organizationId) ?? null,

    listForProject: async (organizationId, projectId, limit = 20) =>
      this.t.crawls
        .filter((crawl) => crawl.organizationId === organizationId && crawl.projectId === projectId)
        .sort((a, b) => b.startedAt.getTime() - a.startedAt.getTime())
        .slice(0, limit),

    findLatest: async (organizationId, projectId) =>
      this.t.crawls
        .filter((crawl) => crawl.organizationId === organizationId && crawl.projectId === projectId)
        .sort((a, b) => b.startedAt.getTime() - a.startedAt.getTime())[0] ?? null,

    update: async (organizationId, id, patch) => {
      const index = this.t.crawls.findIndex(
        (crawl) => crawl.id === id && crawl.organizationId === organizationId,
      );
      if (index === -1) return null;
      const updated: CrawlRow = { ...this.t.crawls[index]!, ...patch, updatedAt: new Date() };
      this.t.crawls[index] = updated;
      return updated;
    },

    savePages: async (crawlId, pages) => {
      let written = 0;
      for (const page of pages) {
        // UNIQUE (crawl_id, url) in the schema; enforced here too.
        const duplicate = this.t.crawledPages.some(
          (existing) => existing.crawlId === crawlId && existing.url === page.url,
        );
        if (duplicate) continue;
        this.t.crawledPages.push({ id: randomUUID(), createdAt: new Date(), ...page });
        written += 1;
      }
      return written;
    },

    listPages: async (organizationId, crawlId) =>
      this.t.crawledPages.filter(
        (page) => page.crawlId === crawlId && page.organizationId === organizationId,
      ),

    findExpired: async (before) => this.t.crawls.filter((crawl) => crawl.expiresAt < before),

    // A HARD delete. A user who withdraws consent asked for the data to be gone.
    deletePages: async (crawlId) => {
      const before = this.t.crawledPages.length;
      this.t.crawledPages = this.t.crawledPages.filter((page) => page.crawlId !== crawlId);
      return before - this.t.crawledPages.length;
    },

    listForConsent: async (organizationId, consentId) =>
      this.t.crawls.filter(
        (crawl) => crawl.organizationId === organizationId && crawl.consentId === consentId,
      ),
  };

  /* ------------------------------ audits --------------------------------- */

  readonly audits: AuditRepository = {
    create: async (input) => {
      const row: AuditRow = { id: randomUUID(), createdAt: new Date(), ...input };
      this.t.audits.push(row);
      return row;
    },

    findById: async (organizationId, id) =>
      this.t.audits.find((audit) => audit.id === id && audit.organizationId === organizationId) ?? null,

    findLatest: async (organizationId, projectId, kind) =>
      this.t.audits
        .filter((audit) =>
          audit.organizationId === organizationId &&
          audit.projectId === projectId &&
          audit.kind === kind)
        .sort((a, b) => b.checkedAt.getTime() - a.checkedAt.getTime())[0] ?? null,

    listForProject: async (organizationId, projectId, kind) =>
      this.t.audits
        .filter((audit) =>
          audit.organizationId === organizationId &&
          audit.projectId === projectId &&
          (kind === undefined || audit.kind === kind))
        .sort((a, b) => b.checkedAt.getTime() - a.checkedAt.getTime()),

    listForCrawl: async (organizationId, crawlId) =>
      this.t.audits.filter(
        (audit) => audit.crawlId === crawlId && audit.organizationId === organizationId,
      ),
  };

  /* ----------------------------- keywords -------------------------------- */

  readonly keywords: KeywordRepository = {
    replaceForProject: async (organizationId, projectId, keywords) => {
      this.t.keywords = this.t.keywords.filter(
        (keyword) => !(keyword.organizationId === organizationId && keyword.projectId === projectId),
      );
      const now = new Date();
      for (const keyword of keywords) {
        this.t.keywords.push({ id: randomUUID(), createdAt: now, updatedAt: now, ...keyword });
      }
      return keywords.length;
    },

    listForProject: async (organizationId, projectId) =>
      this.t.keywords.filter(
        (keyword) => keyword.organizationId === organizationId && keyword.projectId === projectId,
      ),

    remove: async (organizationId, id) => {
      this.t.keywords = this.t.keywords.filter(
        (keyword) => !(keyword.id === id && keyword.organizationId === organizationId),
      );
    },
  };


  /* --------------------- schema validation history ----------------------- */

  readonly schemaValidations: SchemaValidationRepository = {
    create: async (input) => {
      const row: SchemaValidationRow = { id: randomUUID(), createdAt: new Date(), ...input };
      this.t.schemaValidations.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.schemaValidations.find(
        (row) => row.id === id && row.organizationId === organizationId,
      ) ?? null,
    listForProject: async (organizationId, projectId, limit = 50) =>
      this.t.schemaValidations
        .filter((row) => row.organizationId === organizationId && row.projectId === projectId)
        .sort((a, b) => b.checkedAt.getTime() - a.checkedAt.getTime())
        .slice(0, limit),
    findPreviousForSource: async (organizationId, projectId, sourceUrl, before) =>
      this.t.schemaValidations
        .filter(
          (row) =>
            row.organizationId === organizationId &&
            row.projectId === projectId &&
            row.sourceUrl === sourceUrl &&
            // `<=`, not `<`: this is called BEFORE the new row is stored, so
            // nothing at exactly `before` can be the run being compared. With a
            // strict `<`, two checks landing in the same millisecond — which
            // happens in tests and on a fast machine — silently lost their
            // comparison.
            row.checkedAt.getTime() <= before.getTime(),
        )
        .sort((a, b) => b.checkedAt.getTime() - a.checkedAt.getTime())[0] ?? null,
  };

  /* ----------------------------- competitors ----------------------------- */

  readonly competitors: CompetitorRepository = {
    create: async (input) => {
      const now = new Date();
      const row: CompetitorRow = { id: randomUUID(), deletedAt: null, createdAt: now, updatedAt: now, ...input };
      this.t.competitors.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.competitors.find(
        (row) => row.id === id && row.organizationId === organizationId && row.deletedAt === null,
      ) ?? null,
    findByName: async (organizationId, projectId, name) =>
      this.t.competitors.find(
        (row) =>
          row.organizationId === organizationId &&
          row.projectId === projectId &&
          row.deletedAt === null &&
          row.name.trim().toLowerCase() === name.trim().toLowerCase(),
      ) ?? null,
    listForProject: async (organizationId, projectId) =>
      this.t.competitors
        .filter(
          (row) =>
            row.organizationId === organizationId &&
            row.projectId === projectId &&
            row.deletedAt === null,
        )
        .sort((a, b) => a.name.localeCompare(b.name)),
    update: async (organizationId, id, patch) => {
      const index = this.t.competitors.findIndex(
        (row) => row.id === id && row.organizationId === organizationId && row.deletedAt === null,
      );
      if (index === -1) return null;
      const updated = { ...this.t.competitors[index]!, ...patch, updatedAt: new Date() } as CompetitorRow;
      this.t.competitors[index] = updated;
      return updated;
    },
    softDelete: async (organizationId, id, at) => {
      const index = this.t.competitors.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index === -1) return;
      this.t.competitors[index] = { ...this.t.competitors[index]!, deletedAt: at, updatedAt: at };
    },
  };

  readonly competitorAcknowledgements: CompetitorAcknowledgementRepository = {
    create: async (input) => {
      // One live acknowledgement per competitor, as the partial unique index
      // enforces in PostgreSQL.
      const now = new Date();
      for (let index = 0; index < this.t.competitorAcknowledgements.length; index += 1) {
        const existing = this.t.competitorAcknowledgements[index]!;
        if (existing.competitorId === input.competitorId && existing.revokedAt === null) {
          this.t.competitorAcknowledgements[index] = { ...existing, revokedAt: now };
        }
      }
      const row: CompetitorAcknowledgementRow = {
        id: randomUUID(),
        revokedAt: null,
        createdAt: now,
        ...input,
      };
      this.t.competitorAcknowledgements.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.competitorAcknowledgements.find(
        (row) => row.id === id && row.organizationId === organizationId,
      ) ?? null,
    findLive: async (organizationId, competitorId) =>
      this.t.competitorAcknowledgements.find(
        (row) =>
          row.organizationId === organizationId &&
          row.competitorId === competitorId &&
          row.revokedAt === null,
      ) ?? null,
    revoke: async (organizationId, id, at) => {
      const index = this.t.competitorAcknowledgements.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index === -1) return null;
      const updated = { ...this.t.competitorAcknowledgements[index]!, revokedAt: at };
      this.t.competitorAcknowledgements[index] = updated;
      return updated;
    },
  };

  readonly competitorAnalyses: CompetitorAnalysisRepository = {
    create: async (input) => {
      const row: CompetitorAnalysisRow = { id: randomUUID(), createdAt: new Date(), ...input };
      this.t.competitorAnalyses.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.competitorAnalyses.find(
        (row) => row.id === id && row.organizationId === organizationId,
      ) ?? null,
    findLatest: async (organizationId, competitorId) =>
      this.t.competitorAnalyses
        .filter((row) => row.organizationId === organizationId && row.competitorId === competitorId)
        .sort((a, b) => b.analysedAt.getTime() - a.analysedAt.getTime())[0] ?? null,
    listForCompetitor: async (organizationId, competitorId, limit = 20) =>
      this.t.competitorAnalyses
        .filter((row) => row.organizationId === organizationId && row.competitorId === competitorId)
        .sort((a, b) => b.analysedAt.getTime() - a.analysedAt.getTime())
        .slice(0, limit),
    listForProject: async (organizationId, projectId, limit = 50) =>
      this.t.competitorAnalyses
        .filter((row) => row.organizationId === organizationId && row.projectId === projectId)
        .sort((a, b) => b.analysedAt.getTime() - a.analysedAt.getTime())
        .slice(0, limit),
    listForAcknowledgement: async (organizationId, acknowledgementId) =>
      this.t.competitorAnalyses.filter(
        (row) => row.organizationId === organizationId && row.acknowledgementId === acknowledgementId,
      ),
  };

  /* ------------------------------ ad plans ------------------------------- */

  readonly adPlans: AdPlanRepository = {
    create: async (input) => {
      const now = new Date();
      const row: AdPlanRow = { id: randomUUID(), deletedAt: null, createdAt: now, updatedAt: now, ...input };
      this.t.adPlans.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.adPlans.find(
        (row) => row.id === id && row.organizationId === organizationId && row.deletedAt === null,
      ) ?? null,
    listForProject: async (organizationId, projectId, platform) =>
      this.t.adPlans
        .filter(
          (row) =>
            row.organizationId === organizationId &&
            row.projectId === projectId &&
            row.deletedAt === null &&
            (platform === undefined || row.platform === platform),
        )
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()),
    update: async (organizationId, id, patch) => {
      const index = this.t.adPlans.findIndex(
        (row) => row.id === id && row.organizationId === organizationId && row.deletedAt === null,
      );
      if (index === -1) return null;
      const updated = { ...this.t.adPlans[index]!, ...patch, updatedAt: new Date() } as AdPlanRow;
      this.t.adPlans[index] = updated;
      return updated;
    },
    softDelete: async (organizationId, id, at) => {
      const index = this.t.adPlans.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index === -1) return;
      this.t.adPlans[index] = { ...this.t.adPlans[index]!, deletedAt: at, updatedAt: at };
    },
  };

  /* -------------------------------- leads -------------------------------- */

  readonly leads: LeadRepository = {
    create: async (input) => {
      const now = new Date();
      const row: LeadRow = { id: randomUUID(), deletedAt: null, createdAt: now, updatedAt: now, ...input };
      this.t.leads.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.leads.find(
        (row) => row.id === id && row.organizationId === organizationId && row.deletedAt === null,
      ) ?? null,
    listForProject: async (organizationId, projectId, filter) =>
      this.t.leads
        .filter(
          (row) =>
            row.organizationId === organizationId &&
            row.projectId === projectId &&
            row.deletedAt === null &&
            (filter?.stage === undefined || row.stage === filter.stage) &&
            (filter?.ownerUserId === undefined || row.ownerUserId === filter.ownerUserId),
        )
        .sort((a, b) => b.score - a.score || b.createdAt.getTime() - a.createdAt.getTime()),
    findByEmail: async (organizationId, projectId, email) => {
      const target = email.trim().toLowerCase();
      return (
        this.t.leads.find(
          (row) =>
            row.organizationId === organizationId &&
            row.projectId === projectId &&
            row.deletedAt === null &&
            (row.email ?? '').trim().toLowerCase() === target,
        ) ?? null
      );
    },
    findByPhone: async (organizationId, projectId, phone) => {
      // Compared on digits only: +91 712 000 0000 and 0712-000-0000 are the same
      // number written two ways, and a duplicate check that misses that is not a
      // duplicate check.
      const target = digitsOf(phone);
      if (target.length === 0) return null;
      return (
        this.t.leads.find(
          (row) =>
            row.organizationId === organizationId &&
            row.projectId === projectId &&
            row.deletedAt === null &&
            row.phone !== null &&
            digitsOf(row.phone).endsWith(target.slice(-10)),
        ) ?? null
      );
    },
    update: async (organizationId, id, patch) => {
      const index = this.t.leads.findIndex(
        (row) => row.id === id && row.organizationId === organizationId && row.deletedAt === null,
      );
      if (index === -1) return null;
      const updated = { ...this.t.leads[index]!, ...patch, updatedAt: new Date() } as LeadRow;
      this.t.leads[index] = updated;
      return updated;
    },
    softDelete: async (organizationId, id, at) => {
      const index = this.t.leads.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index === -1) return;
      this.t.leads[index] = { ...this.t.leads[index]!, deletedAt: at, updatedAt: at };
    },
  };

  readonly leadActivities: LeadActivityRepository = {
    create: async (input) => {
      const row: LeadActivityRow = { id: randomUUID(), createdAt: new Date(), ...input };
      this.t.leadActivities.push(row);
      return row;
    },
    listForLead: async (organizationId, leadId) =>
      this.t.leadActivities
        .filter((row) => row.organizationId === organizationId && row.leadId === leadId)
        .sort((a, b) => b.occurredAt.getTime() - a.occurredAt.getTime()),
    listDue: async (organizationId, before) =>
      this.t.leadActivities
        .filter(
          (row) =>
            row.organizationId === organizationId &&
            row.dueAt !== null &&
            row.completedAt === null &&
            row.dueAt.getTime() <= before.getTime(),
        )
        .sort((a, b) => (a.dueAt?.getTime() ?? 0) - (b.dueAt?.getTime() ?? 0)),
    complete: async (organizationId, id, at) => {
      const index = this.t.leadActivities.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index === -1) return null;
      const updated = { ...this.t.leadActivities[index]!, completedAt: at };
      this.t.leadActivities[index] = updated;
      return updated;
    },
  };

  /* --------------------------- messaging plans --------------------------- */

  readonly messagingPlans: MessagingPlanRepository = {
    create: async (input) => {
      const now = new Date();
      const row: MessagingPlanRow = { id: randomUUID(), deletedAt: null, createdAt: now, updatedAt: now, ...input };
      this.t.messagingPlans.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.messagingPlans.find(
        (row) => row.id === id && row.organizationId === organizationId && row.deletedAt === null,
      ) ?? null,
    listForProject: async (organizationId, projectId, channel) =>
      this.t.messagingPlans
        .filter(
          (row) =>
            row.organizationId === organizationId &&
            row.projectId === projectId &&
            row.deletedAt === null &&
            (channel === undefined || row.channel === channel),
        )
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()),
    update: async (organizationId, id, patch) => {
      const index = this.t.messagingPlans.findIndex(
        (row) => row.id === id && row.organizationId === organizationId && row.deletedAt === null,
      );
      if (index === -1) return null;
      const updated = { ...this.t.messagingPlans[index]!, ...patch, updatedAt: new Date() } as MessagingPlanRow;
      this.t.messagingPlans[index] = updated;
      return updated;
    },
    softDelete: async (organizationId, id, at) => {
      const index = this.t.messagingPlans.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index === -1) return;
      this.t.messagingPlans[index] = { ...this.t.messagingPlans[index]!, deletedAt: at, updatedAt: at };
    },
  };

  /* ---------------------------- video scripts ---------------------------- */

  readonly videoScripts: VideoScriptRepository = {
    create: async (input) => {
      const now = new Date();
      const row: VideoScriptRow = { id: randomUUID(), deletedAt: null, createdAt: now, updatedAt: now, ...input };
      this.t.videoScripts.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.videoScripts.find(
        (row) => row.id === id && row.organizationId === organizationId && row.deletedAt === null,
      ) ?? null,
    listForProject: async (organizationId, projectId) =>
      this.t.videoScripts
        .filter(
          (row) =>
            row.organizationId === organizationId &&
            row.projectId === projectId &&
            row.deletedAt === null,
        )
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()),
    update: async (organizationId, id, patch) => {
      const index = this.t.videoScripts.findIndex(
        (row) => row.id === id && row.organizationId === organizationId && row.deletedAt === null,
      );
      if (index === -1) return null;
      const updated = { ...this.t.videoScripts[index]!, ...patch, updatedAt: new Date() } as VideoScriptRow;
      this.t.videoScripts[index] = updated;
      return updated;
    },
    softDelete: async (organizationId, id, at) => {
      const index = this.t.videoScripts.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index === -1) return;
      this.t.videoScripts[index] = { ...this.t.videoScripts[index]!, deletedAt: at, updatedAt: at };
    },
  };

  /* -------------------------- data connections --------------------------- */

  readonly dataConnections: DataConnectionRepository = {
    list: async (organizationId, projectId) =>
      this.t.dataConnections.filter(
        (row) => row.organizationId === organizationId && row.projectId === projectId,
      ),
    findByProvider: async (organizationId, projectId, provider) =>
      this.t.dataConnections.find(
        (row) =>
          row.organizationId === organizationId &&
          row.projectId === projectId &&
          row.provider === provider,
      ) ?? null,
    connect: async (input) => {
      const now = new Date();
      const existing = this.t.dataConnections.findIndex(
        (row) =>
          row.organizationId === input.organizationId &&
          row.projectId === input.projectId &&
          row.provider === input.provider,
      );
      // Reconnecting reuses the row, exactly as the UNIQUE constraint forces the
      // SQL adapter to. A second row would make "connected" ambiguous.
      if (existing !== -1) {
        const updated: DataConnectionRow = {
          ...this.t.dataConnections[existing]!,
          ...input,
          disconnectedAt: null,
          updatedAt: now,
        };
        this.t.dataConnections[existing] = updated;
        return updated;
      }
      const row: DataConnectionRow = { id: randomUUID(), createdAt: now, updatedAt: now, ...input };
      this.t.dataConnections.push(row);
      return row;
    },
    disconnect: async (organizationId, id, at) => {
      const index = this.t.dataConnections.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index === -1) return null;
      const updated: DataConnectionRow = {
        ...this.t.dataConnections[index]!,
        disconnectedAt: at,
        updatedAt: at,
      };
      this.t.dataConnections[index] = updated;
      return updated;
    },
  };

  /* ------------------------------ calendar ------------------------------- */

  readonly calendar: CalendarRepository = {
    create: async (input) => {
      const now = new Date();
      const row: CalendarEventRow = { id: randomUUID(), createdAt: now, updatedAt: now, ...input };
      this.t.calendarEvents.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.calendarEvents.find((row) => row.id === id && row.organizationId === organizationId) ?? null,
    listInRange: async (organizationId, projectId, from, to) =>
      this.t.calendarEvents
        .filter(
          (row) =>
            row.organizationId === organizationId &&
            row.projectId === projectId &&
            row.eventDate >= from &&
            row.eventDate <= to,
        )
        .sort((a, b) => (a.eventDate === b.eventDate ? a.title.localeCompare(b.title) : a.eventDate.localeCompare(b.eventDate))),
    listForCampaign: async (organizationId, campaign) =>
      this.t.calendarEvents
        .filter((row) => row.organizationId === organizationId && row.campaign === campaign)
        .sort((a, b) => a.eventDate.localeCompare(b.eventDate)),
    findBySource: async (organizationId, sourceKind, sourceId) =>
      this.t.calendarEvents.find(
        (row) =>
          row.organizationId === organizationId &&
          row.sourceKind === sourceKind &&
          row.sourceId === sourceId,
      ) ?? null,
    update: async (organizationId, id, patch) => {
      const index = this.t.calendarEvents.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index === -1) return null;
      const updated = { ...this.t.calendarEvents[index]!, ...patch, updatedAt: new Date() } as CalendarEventRow;
      this.t.calendarEvents[index] = updated;
      return updated;
    },
    remove: async (organizationId, id) => {
      const index = this.t.calendarEvents.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index !== -1) this.t.calendarEvents.splice(index, 1);
    },
  };

  /* ----------------------------- automation ------------------------------ */

  readonly automation: AutomationRepository = {
    createRule: async (input) => {
      const now = new Date();
      const row: AutomationRuleRow = { id: randomUUID(), createdAt: now, updatedAt: now, ...input };
      this.t.automationRules.push(row);
      return row;
    },
    findRule: async (organizationId, id) =>
      this.t.automationRules.find((row) => row.id === id && row.organizationId === organizationId) ?? null,
    listRules: async (organizationId, projectId) =>
      this.t.automationRules
        .filter((row) => row.organizationId === organizationId && row.projectId === projectId)
        .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime()),
    listEnabledFor: async (organizationId, projectId, triggerKind) =>
      this.t.automationRules.filter(
        (row) =>
          row.organizationId === organizationId &&
          row.projectId === projectId &&
          row.enabled &&
          row.triggerKind === triggerKind,
      ),
    updateRule: async (organizationId, id, patch) => {
      const index = this.t.automationRules.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index === -1) return null;
      const updated = { ...this.t.automationRules[index]!, ...patch, updatedAt: new Date() } as AutomationRuleRow;
      this.t.automationRules[index] = updated;
      return updated;
    },
    removeRule: async (organizationId, id) => {
      const index = this.t.automationRules.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index === -1) return;
      this.t.automationRules.splice(index, 1);
      // The SQL adapter cascades; do the same here so a test cannot pass against
      // orphaned run history that production would have removed.
      this.t.automationRuns = this.t.automationRuns.filter((row) => row.ruleId !== id);
    },
    recordRun: async (input) => {
      const row: AutomationRunRow = { id: randomUUID(), ...input };
      this.t.automationRuns.push(row);
      return row;
    },
    listRuns: async (organizationId, ruleId, limit = 50) =>
      this.t.automationRuns
        .filter((row) => row.organizationId === organizationId && row.ruleId === ruleId)
        .sort((a, b) => b.ranAt.getTime() - a.ranAt.getTime())
        .slice(0, limit),
    countRunsSince: async (organizationId, since) =>
      this.t.automationRuns.filter(
        (row) => row.organizationId === organizationId && row.ranAt.getTime() >= since.getTime(),
      ).length,
  };

  /* ------------------------------- reports ------------------------------- */

  readonly reports: ReportRepository = {
    create: async (input) => {
      const row: ReportRow = { id: randomUUID(), ...input };
      this.t.reports.push(row);
      return row;
    },
    findById: async (organizationId, id) =>
      this.t.reports.find((row) => row.id === id && row.organizationId === organizationId) ?? null,
    listForProject: async (organizationId, projectId, limit = 50) =>
      this.t.reports
        .filter((row) => row.organizationId === organizationId && row.projectId === projectId)
        .sort((a, b) => b.generatedAt.getTime() - a.generatedAt.getTime())
        .slice(0, limit),
    remove: async (organizationId, id) => {
      const index = this.t.reports.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index === -1) return;
      this.t.reports.splice(index, 1);
      this.t.reportShares = this.t.reportShares.filter((row) => row.reportId !== id);
    },
  };

  readonly reportShares: ReportShareRepository = {
    create: async (input) => {
      const row: ReportShareRow = {
        id: randomUUID(),
        createdAt: new Date(),
        lastViewedAt: null,
        viewCount: 0,
        ...input,
      };
      this.t.reportShares.push(row);
      return row;
    },
    // No organization filter, deliberately: the caller is an anonymous visitor
    // whose only credential is the token. See the interface for why that is safe.
    findByTokenHash: async (tokenHash) =>
      this.t.reportShares.find((row) => row.tokenHash === tokenHash) ?? null,
    listForReport: async (organizationId, reportId) =>
      this.t.reportShares
        .filter((row) => row.organizationId === organizationId && row.reportId === reportId)
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()),
    revoke: async (organizationId, id, at) => {
      const index = this.t.reportShares.findIndex(
        (row) => row.id === id && row.organizationId === organizationId,
      );
      if (index === -1) return null;
      const updated: ReportShareRow = { ...this.t.reportShares[index]!, revokedAt: at };
      this.t.reportShares[index] = updated;
      return updated;
    },
    recordView: async (id, at) => {
      const index = this.t.reportShares.findIndex((row) => row.id === id);
      if (index === -1) return;
      const row = this.t.reportShares[index]!;
      this.t.reportShares[index] = { ...row, lastViewedAt: at, viewCount: row.viewCount + 1 };
    },
  };

  /* ------------------- notification preferences -------------------------- */

  readonly notificationPreferences: NotificationPreferenceRepository = {
    listForUser: async (organizationId, userId) =>
      this.t.notificationPreferences.filter(
        (row) => row.organizationId === organizationId && row.userId === userId,
      ),
    set: async (organizationId, userId, kind, patch, at) => {
      const index = this.t.notificationPreferences.findIndex(
        (row) => row.organizationId === organizationId && row.userId === userId && row.kind === kind,
      );
      if (index !== -1) {
        const updated: NotificationPreferenceRow = {
          ...this.t.notificationPreferences[index]!,
          ...(patch.inApp === undefined ? {} : { inApp: patch.inApp }),
          ...(patch.email === undefined ? {} : { email: patch.email }),
          updatedAt: at,
        };
        this.t.notificationPreferences[index] = updated;
        return updated;
      }
      const row: NotificationPreferenceRow = {
        id: randomUUID(),
        organizationId,
        userId,
        kind,
        inApp: patch.inApp ?? true,
        email: patch.email ?? false,
        updatedAt: at,
      };
      this.t.notificationPreferences.push(row);
      return row;
    },
  };

  /* --------------------------- plan limits ------------------------------- */

  readonly planLimits: PlanLimitRepository = {
    listForOrganization: async (organizationId) =>
      this.t.planLimitOverrides.filter((row) => row.organizationId === organizationId),
    set: async (organizationId, limitId, value, reason, setBy, at) => {
      const index = this.t.planLimitOverrides.findIndex(
        (row) => row.organizationId === organizationId && row.limitId === limitId,
      );
      const row: PlanLimitOverrideRow = {
        id: index === -1 ? randomUUID() : this.t.planLimitOverrides[index]!.id,
        organizationId,
        limitId,
        value,
        reason,
        setBy,
        setAt: at,
      };
      // Upsert, exactly as the UNIQUE (organization_id, limit_id) constraint
      // forces the SQL adapter to. Two rows would make the effective limit
      // depend on which one the query happened to find first.
      if (index === -1) this.t.planLimitOverrides.push(row);
      else this.t.planLimitOverrides[index] = row;
      return row;
    },
    clear: async (organizationId, limitId) => {
      this.t.planLimitOverrides = this.t.planLimitOverrides.filter(
        (row) => !(row.organizationId === organizationId && row.limitId === limitId),
      );
    },
  };

  /* -------------------------- quota refusals ----------------------------- */

  readonly quotaRefusals: QuotaRefusalRepository = {
    record: async (input) => {
      this.t.quotaRefusals.push({
        id: String(this.t.quotaRefusals.length + 1),
        ...input,
        refusedAt: input.refusedAt ?? new Date(),
      });
    },
    listForOrganization: async (organizationId, limit = 100) =>
      this.t.quotaRefusals
        .filter((row) => row.organizationId === organizationId)
        .sort((a, b) => b.refusedAt.getTime() - a.refusedAt.getTime())
        .slice(0, limit),
    countByLimitSince: async (since) => {
      const counts: Record<string, number> = {};
      for (const row of this.t.quotaRefusals) {
        if (row.refusedAt.getTime() < since.getTime()) continue;
        counts[row.limitId] = (counts[row.limitId] ?? 0) + 1;
      }
      return counts;
    },
  };

  /* -------------------------- platform staff ----------------------------- */

  readonly platformStaff: PlatformStaffRepository = {
    findByUser: async (userId) => this.t.platformStaff.find((row) => row.userId === userId) ?? null,
    list: async (includeRevoked = false) =>
      this.t.platformStaff
        .filter((row) => includeRevoked || row.revokedAt === null)
        .sort((a, b) => b.grantedAt.getTime() - a.grantedAt.getTime()),
    grant: async (input) => {
      const index = this.t.platformStaff.findIndex((row) => row.userId === input.userId);
      const row: PlatformStaffRow = {
        id: index === -1 ? randomUUID() : this.t.platformStaff[index]!.id,
        userId: input.userId,
        role: input.role,
        grantedBy: input.grantedBy,
        grantedAt: input.at,
        // Re-granting CLEARS the revocation, as the UNIQUE (user_id) constraint
        // forces. Leaving it set would produce a row that is simultaneously
        // granted and revoked, and `staffRoleFrom` would read it as revoked —
        // silently refusing someone who had just been given access.
        revokedBy: null,
        revokedAt: null,
        reason: input.reason,
      };
      if (index === -1) this.t.platformStaff.push(row);
      else this.t.platformStaff[index] = row;
      return row;
    },
    revoke: async (userId, revokedBy, at) => {
      const index = this.t.platformStaff.findIndex((row) => row.userId === userId);
      if (index === -1) return null;
      const row: PlatformStaffRow = {
        ...this.t.platformStaff[index]!,
        revokedBy,
        revokedAt: at,
      };
      this.t.platformStaff[index] = row;
      return row;
    },
    countActive: async () => this.t.platformStaff.filter((row) => row.revokedAt === null).length,
  };

  /* --------------------------- admin actions ----------------------------- */

  readonly adminActions: AdminActionRepository = {
    record: async (input) => {
      this.t.adminActions.push({
        id: String(this.t.adminActions.length + 1),
        createdAt: new Date(),
        ...input,
      });
    },
    list: async (filter = {}) =>
      this.t.adminActions
        .filter((row) => filter.staffUserId === undefined || row.staffUserId === filter.staffUserId)
        .filter(
          (row) =>
            filter.targetOrganizationId === undefined ||
            row.targetOrganizationId === filter.targetOrganizationId,
        )
        .filter((row) => filter.kind === undefined || row.kind === filter.kind)
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, filter.limit ?? 200),
  };

  /* --------------------------- billing events ---------------------------- */

  readonly billingEvents: BillingEventRepository = {
    record: async (input) => {
      // The idempotency check. A provider retries and delivers out of order; a
      // second row for the same event id would apply a transition twice.
      if (input.externalEventId) {
        const seen = this.t.billingEvents.some(
          (row) => row.externalEventId === input.externalEventId,
        );
        if (seen) return null;
      }
      const row: BillingEventRow = {
        id: String(this.t.billingEvents.length + 1),
        occurredAt: input.occurredAt ?? new Date(),
        ...input,
      };
      this.t.billingEvents.push(row);
      return row;
    },
    listForOrganization: async (organizationId, limit = 50) =>
      this.t.billingEvents
        .filter((row) => row.organizationId === organizationId)
        .sort((a, b) => b.occurredAt.getTime() - a.occurredAt.getTime())
        .slice(0, limit),
    listRecent: async (limit = 100) =>
      [...this.t.billingEvents]
        .sort((a, b) => b.occurredAt.getTime() - a.occurredAt.getTime())
        .slice(0, limit),
  };

  /* --------------------------- feature flags ----------------------------- */

  readonly featureFlags: FeatureFlagRepository = {
    list: async () => [...this.t.featureFlagRules],
    find: async (key) => this.t.featureFlagRules.find((row) => row.key === key) ?? null,
    upsert: async (input) => {
      const row: FeatureFlagRuleRow = { ...input, updatedAt: input.updatedAt ?? new Date() };
      const index = this.t.featureFlagRules.findIndex((candidate) => candidate.key === input.key);
      if (index === -1) this.t.featureFlagRules.push(row);
      else this.t.featureFlagRules[index] = row;
      return row;
    },
    remove: async (key) => {
      this.t.featureFlagRules = this.t.featureFlagRules.filter((row) => row.key !== key);
    },
  };

  /* -------------------------- system settings ---------------------------- */

  readonly systemSettings: SystemSettingRepository = {
    get: async (key) => this.t.systemSettings.find((row) => row.key === key) ?? null,
    list: async (prefix) =>
      this.t.systemSettings
        .filter((row) => prefix === undefined || row.key.startsWith(prefix))
        .sort((a, b) => a.key.localeCompare(b.key)),
    set: async (key, value, updatedBy, at) => {
      const row: SystemSettingRow = { key, value, updatedBy, updatedAt: at };
      const index = this.t.systemSettings.findIndex((candidate) => candidate.key === key);
      if (index === -1) this.t.systemSettings.push(row);
      else this.t.systemSettings[index] = row;
      return row;
    },
    remove: async (key) => {
      this.t.systemSettings = this.t.systemSettings.filter((row) => row.key !== key);
    },
  };

  /* ------------------------------- errors -------------------------------- */

  readonly errors: ErrorEventRepository = {
    record: async (input) => {
      const index = this.t.errorEvents.findIndex((row) => row.fingerprint === input.fingerprint);
      if (index !== -1) {
        const existing = this.t.errorEvents[index]!;
        const row: ErrorEventRow = {
          ...existing,
          occurrences: existing.occurrences + 1,
          lastSeenAt: input.at,
          // A recurrence REOPENS a resolved error. Silently leaving it resolved
          // is how a fixed-then-regressed bug stays invisible.
          resolvedAt: null,
          resolvedBy: null,
          severity: input.severity,
          message: input.message,
        };
        this.t.errorEvents[index] = row;
        return row;
      }
      const row: ErrorEventRow = {
        id: String(this.t.errorEvents.length + 1),
        fingerprint: input.fingerprint,
        severity: input.severity,
        source: input.source,
        message: input.message,
        organizationId: input.organizationId,
        occurrences: 1,
        firstSeenAt: input.at,
        lastSeenAt: input.at,
        resolvedAt: null,
        resolvedBy: null,
      };
      this.t.errorEvents.push(row);
      return row;
    },
    listOpen: async (limit = 50) =>
      this.t.errorEvents
        .filter((row) => row.resolvedAt === null)
        .sort((a, b) => b.lastSeenAt.getTime() - a.lastSeenAt.getTime())
        .slice(0, limit),
    resolve: async (fingerprint, resolvedBy, at) => {
      const index = this.t.errorEvents.findIndex((row) => row.fingerprint === fingerprint);
      if (index === -1) return null;
      const row: ErrorEventRow = { ...this.t.errorEvents[index]!, resolvedAt: at, resolvedBy };
      this.t.errorEvents[index] = row;
      return row;
    },
    countSince: async (since) =>
      this.t.errorEvents
        .filter((row) => row.lastSeenAt.getTime() >= since.getTime())
        .reduce((total, row) => total + row.occurrences, 0),
  };

  /* ------------------------------ feedback ------------------------------- */

  readonly feedback: FeedbackRepository = {
    create: async (input) => {
      const row: FeedbackRow = {
        id: randomUUID(),
        status: 'new',
        triagedBy: null,
        triagedAt: null,
        createdAt: new Date(),
        ...input,
      };
      this.t.feedback.push(row);
      return row;
    },
    list: async (filter = {}) =>
      this.t.feedback
        .filter((row) => filter.status === undefined || row.status === filter.status)
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, filter.limit ?? 100),
    setStatus: async (id, status, triagedBy, at) => {
      const index = this.t.feedback.findIndex((row) => row.id === id);
      if (index === -1) return null;
      const row: FeedbackRow = { ...this.t.feedback[index]!, status, triagedBy, triagedAt: at };
      this.t.feedback[index] = row;
      return row;
    },
  };

  /* ---------------------------- admin reads ------------------------------ */
  /*
   * THE DELIBERATE CROSS-TENANT SEAM. Every method here reads across tenants,
   * which is why they live behind one interface whose name says so rather than
   * by relaxing the tenant-scoped repositories.
   *
   * Nothing here returns customer CONTENT — no lead, no article, no report body.
   * Support needs to know an organization exists, what plan it is on and whether
   * its jobs are failing; none of that requires reading what the customer wrote.
   */

  readonly adminRead: AdminReadRepository = {
    countOrganizations: async () => this.t.organizations.length,
    countUsers: async () => this.t.users.filter((row) => row.deletedAt === null).length,
    countProjects: async () => this.t.projects.filter((row) => row.deletedAt === null).length,
    countReports: async () => this.t.reports.length,

    listOrganizations: async (filter = {}) => {
      const query = filter.query?.trim().toLowerCase() ?? '';
      return this.t.organizations
        .map((organization) => {
          const subscription =
            this.t.subscriptions.find((row) => row.organizationId === organization.id) ?? null;
          return {
            organization,
            subscription,
            memberCount: this.t.memberships.filter(
              (row) => row.organizationId === organization.id,
            ).length,
            projectCount: this.t.projects.filter(
              (row) => row.organizationId === organization.id && row.deletedAt === null,
            ).length,
          };
        })
        .filter((entry) => filter.plan === undefined || entry.organization.plan === filter.plan)
        .filter(
          (entry) => filter.status === undefined || entry.subscription?.status === filter.status,
        )
        .filter(
          (entry) =>
            query.length === 0 ||
            entry.organization.name.toLowerCase().includes(query) ||
            entry.organization.slug.toLowerCase().includes(query),
        )
        .sort((a, b) => b.organization.createdAt.getTime() - a.organization.createdAt.getTime())
        .slice(0, filter.limit ?? 50);
    },

    findOrganization: async (organizationId) => {
      const organization = this.t.organizations.find((row) => row.id === organizationId);
      if (!organization) return null;
      const members = this.t.memberships
        .filter((row) => row.organizationId === organizationId)
        .map((membership) => {
          const user = this.t.users.find((row) => row.id === membership.userId);
          return user ? { user, role: membership.role } : null;
        })
        .filter((entry): entry is { user: UserRow; role: MembershipRow['role'] } => entry !== null);
      return {
        organization,
        subscription:
          this.t.subscriptions.find((row) => row.organizationId === organizationId) ?? null,
        members,
        businesses: this.t.businesses.filter(
          (row) => row.organizationId === organizationId && row.deletedAt === null,
        ),
        projects: this.t.projects.filter(
          (row) => row.organizationId === organizationId && row.deletedAt === null,
        ),
      };
    },

    usageFor: async (organizationId, periodStart) => {
      const totals: Record<string, number> = {};
      for (const row of this.t.usage) {
        if (row.organizationId !== organizationId || row.periodStart !== periodStart) continue;
        totals[row.metric] = (totals[row.metric] ?? 0) + row.quantity;
      }
      return totals;
    },

    usageTotals: async (periodStart) => {
      const totals: Record<string, number> = {};
      for (const row of this.t.usage) {
        if (row.periodStart !== periodStart) continue;
        totals[row.metric] = (totals[row.metric] ?? 0) + row.quantity;
      }
      return totals;
    },

    listJobs: async (filter = {}) =>
      this.t.jobs
        .filter((row) => filter.kind === undefined || row.kind === filter.kind)
        .filter((row) => filter.status === undefined || row.status === filter.status)
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, filter.limit ?? 100),

    countJobsByStatus: async () => {
      const counts: Record<string, number> = {};
      for (const row of this.t.jobs) counts[row.status] = (counts[row.status] ?? 0) + 1;
      return counts;
    },

    aiUsageSince: async (since) => {
      let requests = 0;
      let tokens = 0;
      for (const row of this.t.usage) {
        if (row.recordedAt.getTime() < since.getTime()) continue;
        if (row.metric === 'ai_generation') requests += row.quantity;
        if (row.metric === 'ai_tokens') tokens += row.quantity;
      }
      return { requests, tokens };
    },

    listSecurityEvents: async (limit = 100) =>
      this.t.audit
        .filter(
          (row) =>
            row.outcome === 'denied' ||
            /^(auth|session|password|oauth|account|admin|report\.share)/.test(row.action),
        )
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, limit),
  };

  readonly audit: AuditLogRepository = {
    record: async (input) => {
      this.t.audit.push({ id: randomUUID(), createdAt: new Date(), ...input });
    },
    list: async (organizationId, limit = 100) =>
      this.t.audit
        .filter((a) => a.organizationId === organizationId)
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, limit),
  };
}

/** Digits only, for comparing two spellings of one phone number. */
function digitsOf(value: string): string {
  return value.replace(/\D+/g, '');
}
