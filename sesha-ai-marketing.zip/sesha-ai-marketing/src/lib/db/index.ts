/**
 * Database selection.
 *
 * Phase 2 ships an in-memory adapter so the application actually runs and every
 * flow is testable. A PostgreSQL adapter implementing the same interfaces (see
 * ./repositories.ts) replaces it without touching a single call site.
 *
 * THE PRODUCTION GUARD BELOW IS LOAD-BEARING: silently falling back to an
 * in-memory store in production would look like a working deployment while
 * losing every account on restart. It refuses to start instead.
 */

import { MemoryDatabase } from './memory-store';
import type { Database } from './repositories';

export * from './repositories';
export * from './types';
export { profileCompleteness } from './memory-store';

let instance: Database | null = null;

export function readDatabaseConfig(): { connectionString: string } | null {
  const connectionString = process.env.DATABASE_URL;
  return connectionString ? { connectionString } : null;
}

export const databaseIsConfigured: boolean = readDatabaseConfig() !== null;

export function getDatabase(): Database {
  if (instance) return instance;

  if (databaseIsConfigured) {
    // Phase 3: return new PostgresDatabase(readDatabaseConfig()!).
    throw new Error(
      'DATABASE_URL is set, but the PostgreSQL adapter is not implemented yet. ' +
        'Unset DATABASE_URL to use the in-memory adapter, or implement PostgresDatabase.',
    );
  }

  if (process.env.NODE_ENV === 'production' && process.env.ALLOW_MEMORY_DB !== 'true') {
    throw new Error(
      'No DATABASE_URL in production. The in-memory adapter loses all data on restart ' +
        'and cannot be shared between instances. Set DATABASE_URL, or set ' +
        'ALLOW_MEMORY_DB=true if you are deliberately running a throwaway demo.',
    );
  }

  instance = new MemoryDatabase();
  return instance;
}

/** Test helper. Never called by application code. */
export function resetDatabase(): void {
  instance = null;
}

/**
 * PostgreSQL adapter notes, recorded so the decision is not relitigated:
 *  - one module-scoped `pg` Pool, never a client per request;
 *  - parameterised queries only — no string interpolation, ever;
 *  - after checkout, set `app.current_organization` so row-level security
 *    applies (see src/lib/tenant/index.ts → rlsStatement);
 *  - multi-step writes (sign-up creates user + organization + membership +
 *    subscription) run in a transaction; the in-memory adapter cannot do this,
 *    which is one reason it is not production-safe.
 */
