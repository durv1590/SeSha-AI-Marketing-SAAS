/**
 * Analysing a competitor from public pages.
 *
 * WHY THIS DOES NOT REUSE THE PHASE 4 CRAWLER WHOLESALE
 * The Phase 4 crawler exists to read a site the customer has consented to, on the
 * customer's own authority. A competitor has given nobody consent, so the same
 * machinery pointed at them would be a crawler with no authorisation story at
 * all. The Phase 4 report said this explicitly and left it for a later phase;
 * this is that phase, and the answer is a deliberately narrower instrument:
 *
 *  · the SAME safety policy — SSRF, DNS pinning, redirect re-validation, size and
 *    time limits, robots.txt failing closed. All of it, unchanged. Nothing about
 *    a competitor makes private-network scanning acceptable.
 *  · A HARD CAP OF A FEW PAGES per competitor, not a site crawl. Enough to read
 *    how they present themselves; not enough to be a burden or to constitute
 *    systematic extraction.
 *  · a REQUIRED ACKNOWLEDGEMENT from the user that they are asking for public
 *    information about a named third party. Consent cannot come from the
 *    competitor, so the authorisation recorded is the user's own, and it names
 *    them.
 *  · ANALYSIS ONLY — the page text is read, findings are derived, and the page
 *    content is NOT stored. Keeping a copy of a third party's site is a liability
 *    with no benefit to the analysis.
 *
 * The deterministic findings in this file are the verified half. The inferred
 * half comes from the AI layer and is labelled `ai_inference` by construction.
 *
 * Framework-free and fully unit tested.
 */

import { parseDocument } from '@/lib/schema-validator/parse';
import { validateSchema } from '@/lib/schema-validator/engine';

import {
  COMPETITOR_DIMENSIONS,
  DIMENSION_SCOPE,
  countFindings,
  isInferenceOnly,
  lintCompetitorFindings,
  type AnalysisLimitation,
  type CompetitorAnalysis,
  type CompetitorDimension,
  type CompetitorFinding,
} from './types';

/**
 * How much of a competitor's site may be read. Deliberately small.
 *
 * Three pages is enough to read a home page, a pricing or products page and one
 * more; it is not a crawl. `maxPages` here is an absolute ceiling and there is no
 * plan, setting or request that raises it.
 */
export const COMPETITOR_FETCH_POLICY = {
  maxPages: 3,
  maxDepth: 1,
  /** One request at a time, with a gap. A competitor did not ask for our load. */
  concurrency: 1,
  delayMs: 2_000,
  maxBytesPerPage: 1_500_000,
  timeoutMsPerPage: 15_000,
  /** Page content is analysed and discarded. */
  storesPageContent: false,
} as const;

/**
 * The sentence a user must accept before a competitor is analysed, in the words
 * the interface shows. Stored with the acknowledgement record.
 */
export const COMPETITOR_ACKNOWLEDGEMENT =
  'I am asking SeSha to read publicly available pages on this company\'s website and summarise what is there. I understand that at most three pages are read, that robots.txt is obeyed, that no page content is stored, and that anything SeSha concludes rather than reads is labelled as an inference rather than a fact.';

export const COMPETITOR_ACKNOWLEDGEMENT_VERSION = '2026-09-1';

/** What a page gave us. Produced by the caller, which did the fetching. */
export interface CompetitorPage {
  readonly url: string;
  readonly readAt: string;
  readonly status: number;
  readonly title?: string;
  readonly metaDescription?: string;
  readonly h1: readonly string[];
  readonly h2: readonly string[];
  readonly textContent: string;
  readonly internalLinks: readonly string[];
  readonly externalLinks: readonly string[];
  readonly imageCount: number;
  readonly imagesWithAlt: number;
  readonly html?: string;
  readonly isHttps: boolean;
}

export interface AnalyzeInput {
  readonly competitorName: string;
  readonly website?: string;
  readonly pages: readonly CompetitorPage[];
  /** The user's own positioning, for the differentiation dimension. */
  readonly ownPositioning?: string;
  /** Pages that could not be read, with the reason. Reported, not hidden. */
  readonly unreadable?: readonly { readonly url: string; readonly reason: string }[];
  readonly now?: () => Date;
}

/** Social networks recognised from an outbound link. */
const SOCIAL_HOSTS: Readonly<Record<string, string>> = {
  'facebook.com': 'Facebook',
  'instagram.com': 'Instagram',
  'linkedin.com': 'LinkedIn',
  'x.com': 'X',
  'twitter.com': 'X',
  'youtube.com': 'YouTube',
  'pinterest.com': 'Pinterest',
  'whatsapp.com': 'WhatsApp',
  'wa.me': 'WhatsApp',
  'threads.net': 'Threads',
  'tiktok.com': 'TikTok',
};

/**
 * Scripts whose presence is evidence that a site runs advertising.
 *
 * This is the honest ceiling of advertising analysis from outside: the presence
 * of a conversion pixel shows they measure campaigns. It says nothing about
 * spend, reach or performance, and the finding's wording must not imply it does.
 */
const AD_SIGNALS: readonly { readonly pattern: RegExp; readonly label: string }[] = [
  { pattern: /googletagmanager\.com|gtag\(/i, label: 'Google Tag Manager or gtag' },
  { pattern: /google-analytics\.com|analytics\.google\.com/i, label: 'Google Analytics' },
  { pattern: /googleads\.g\.doubleclick\.net|googleadservices\.com|\/pagead\//i, label: 'Google Ads conversion tracking' },
  { pattern: /connect\.facebook\.net|fbq\(/i, label: 'Meta pixel' },
  { pattern: /snap\.licdn\.com|linkedin\.com\/px/i, label: 'LinkedIn insight tag' },
  { pattern: /static\.ads-twitter\.com/i, label: 'X pixel' },
  { pattern: /analytics\.tiktok\.com/i, label: 'TikTok pixel' },
];

export function analyzeCompetitor(input: AnalyzeInput): CompetitorAnalysis {
  const now = input.now ?? (() => new Date());
  const analysedAt = now().toISOString();
  const raw: CompetitorFinding[] = [];
  const limitations: AnalysisLimitation[] = [];

  const pages = input.pages.filter((page) => page.status >= 200 && page.status < 300);

  if (pages.length === 0) {
    limitations.push({
      code: 'nothing_read',
      detail:
        'No page could be read, so everything below is absent rather than negative. A site that blocks automated reading, or that renders its content with JavaScript, produces this result.',
    });
  }

  for (const entry of input.unreadable ?? []) {
    limitations.push({ code: 'page_unreadable', detail: `${entry.url} could not be read: ${entry.reason}` });
  }

  limitations.push({
    code: 'pages_capped',
    detail: `At most ${COMPETITOR_FETCH_POLICY.maxPages} pages are read per competitor, so this is how they present themselves on those pages — not a survey of their whole site.`,
  });
  limitations.push({
    code: 'no_javascript',
    detail:
      'Pages are read as delivered, without running JavaScript. Content loaded by a script — and markup injected by a tag manager — is not seen.',
  });
  limitations.push({
    code: 'no_private_data',
    detail:
      'Only public pages are read. Spend, budgets, traffic, revenue, customer counts and engagement are not observable from outside and are never estimated.',
  });

  const home = pages[0];

  /* ------------------------------------------------------- positioning */
  if (home) {
    const statement = firstSentence(home.metaDescription ?? home.h1[0] ?? home.title ?? '');
    if (statement) {
      raw.push({
        dimension: 'positioning',
        statement: `They describe themselves as: "${truncate(statement, 160)}".`,
        evidence: {
          kind: 'verified_public',
          sourceUrl: home.url,
          observedAt: home.readAt,
          quote: statement,
        },
        confidence: 'high',
      });
    }
    if (home.h1.length === 0) {
      raw.push({
        dimension: 'seo',
        statement: 'Their home page has no H1 heading.',
        evidence: { kind: 'verified_public', sourceUrl: home.url, observedAt: home.readAt },
        confidence: 'high',
      });
    } else if (home.h1.length > 1) {
      raw.push({
        dimension: 'seo',
        statement: `Their home page has ${home.h1.length} H1 headings.`,
        evidence: { kind: 'verified_public', sourceUrl: home.url, observedAt: home.readAt },
        confidence: 'high',
      });
    }
  }

  /* ------------------------------------------------- products/services */
  for (const page of pages) {
    const offerings = extractOfferings(page);
    if (offerings.length === 0) continue;
    const dimension: CompetitorDimension = /service|consult|agency|support/i.test(page.textContent)
      ? 'services'
      : 'products';
    raw.push({
      dimension,
      statement: `Their ${page.url === home?.url ? 'home page' : 'page'} names: ${offerings.slice(0, 6).join(', ')}.`,
      evidence: {
        kind: 'verified_public',
        sourceUrl: page.url,
        observedAt: page.readAt,
        quote: offerings.join(', '),
      },
      confidence: 'medium',
    });
    break;
  }

  /* ------------------------------------------------------------ content */
  const wordCounts = pages.map((page) => countWords(page.textContent));
  if (wordCounts.length > 0) {
    const median = wordCounts.slice().sort((a, b) => a - b)[Math.floor(wordCounts.length / 2)]!;
    raw.push({
      dimension: 'content',
      statement: `The pages read carry around ${median} words each.`,
      evidence: {
        kind: 'verified_public',
        sourceUrl: pages[0]!.url,
        observedAt: pages[0]!.readAt,
        quote: `${median}`,
      },
      confidence: 'high',
    });
  }

  /* ---------------------------------------------------------------- seo */
  for (const page of pages) {
    if (!page.title || page.title.trim().length === 0) {
      raw.push({
        dimension: 'seo',
        statement: `${page.url} has no title element.`,
        evidence: { kind: 'verified_public', sourceUrl: page.url, observedAt: page.readAt },
        confidence: 'high',
      });
    }
    if (!page.metaDescription) {
      raw.push({
        dimension: 'seo',
        statement: `${page.url} has no meta description.`,
        evidence: { kind: 'verified_public', sourceUrl: page.url, observedAt: page.readAt },
        confidence: 'high',
      });
    }
    if (!page.isHttps) {
      raw.push({
        dimension: 'seo',
        statement: `${page.url} is served over http rather than https.`,
        evidence: { kind: 'verified_public', sourceUrl: page.url, observedAt: page.readAt },
        confidence: 'high',
      });
    }
  }
  if (home && home.imageCount > 0) {
    const missing = home.imageCount - home.imagesWithAlt;
    if (missing > 0) {
      raw.push({
        dimension: 'seo',
        statement: `${missing} of ${home.imageCount} images on their home page have no alt text.`,
        evidence: { kind: 'verified_public', sourceUrl: home.url, observedAt: home.readAt },
        confidence: 'high',
      });
    }
  }

  /* ------------------------------------------------- structured data + aeo */
  let markupFound = false;
  for (const page of pages) {
    if (!page.html) continue;
    const parsed = parseDocument(page.html);
    if (parsed.nodes.length === 0) continue;
    markupFound = true;
    const result = validateSchema({ source: page.html, sourceKind: 'page_url', sourceUrl: page.url, now });
    raw.push({
      dimension: 'structured_data',
      statement: `They publish ${result.typesFound.join(', ')} markup (${parsed.syntaxes.join(', ')}), which our validator reads as ${result.overall}.`,
      evidence: {
        kind: 'verified_public',
        sourceUrl: page.url,
        observedAt: page.readAt,
        quote: result.typesFound.join(', '),
      },
      confidence: 'high',
    });
    if (result.typesFound.includes('FAQPage')) {
      raw.push({
        dimension: 'aeo',
        statement: 'Their page publishes FAQ markup, so their answers are stated in a form an AI system can read directly.',
        evidence: { kind: 'verified_public', sourceUrl: page.url, observedAt: page.readAt },
        confidence: 'high',
      });
    }
    break;
  }
  if (!markupFound && pages.length > 0) {
    raw.push({
      dimension: 'structured_data',
      statement: 'No structured data was found on the pages read.',
      evidence: { kind: 'verified_public', sourceUrl: pages[0]!.url, observedAt: pages[0]!.readAt },
      confidence: 'medium',
    });
  }

  /* ------------------------------------------------------------- social */
  const profiles = new Map<string, string>();
  for (const page of pages) {
    for (const link of page.externalLinks) {
      const host = hostOf(link);
      if (!host) continue;
      for (const [needle, label] of Object.entries(SOCIAL_HOSTS)) {
        if (host === needle || host.endsWith(`.${needle}`)) {
          if (!profiles.has(label)) profiles.set(label, link);
        }
      }
    }
  }
  if (profiles.size > 0 && pages[0]) {
    raw.push({
      dimension: 'social',
      statement: `They link to ${[...profiles.keys()].join(', ')}. Follower counts and engagement are not read.`,
      evidence: {
        kind: 'verified_public',
        sourceUrl: pages[0].url,
        observedAt: pages[0].readAt,
        quote: [...profiles.values()].join(' '),
      },
      confidence: 'high',
    });
  } else if (pages.length > 0 && pages[0]) {
    raw.push({
      dimension: 'social',
      statement: 'No social profile links were found on the pages read.',
      evidence: { kind: 'verified_public', sourceUrl: pages[0].url, observedAt: pages[0].readAt },
      confidence: 'low',
    });
  }

  /* -------------------------------------------------------- advertising */
  const signals = new Set<string>();
  for (const page of pages) {
    if (!page.html) continue;
    for (const signal of AD_SIGNALS) {
      if (signal.pattern.test(page.html)) signals.add(signal.label);
    }
  }
  if (signals.size > 0 && pages[0]) {
    raw.push({
      dimension: 'advertising',
      statement: `Their pages load ${[...signals].join(', ')}, which shows they measure campaigns. What they spend, who they target and how it performs cannot be seen from outside.`,
      evidence: {
        kind: 'verified_public',
        sourceUrl: pages[0].url,
        observedAt: pages[0].readAt,
        quote: [...signals].join(', '),
      },
      confidence: 'medium',
    });
  } else if (pages.length > 0 && pages[0]) {
    raw.push({
      dimension: 'advertising',
      statement:
        'No advertising or analytics tracking was detected on the pages read. That is not proof they do not advertise — tracking can be server-side or added by a tag manager.',
      evidence: { kind: 'verified_public', sourceUrl: pages[0].url, observedAt: pages[0].readAt },
      confidence: 'low',
    });
  }

  const linted = lintCompetitorFindings(raw);
  const findings = linted.findings;
  if (linted.dropped.length > 0) {
    limitations.push({
      code: 'findings_dropped',
      detail: `${linted.dropped.length} draft finding(s) were discarded for claiming something a public page cannot show.`,
    });
  }

  const covered = new Set(findings.map((finding) => finding.dimension));
  const notCovered = COMPETITOR_DIMENSIONS.filter((dimension) => !covered.has(dimension)).map(
    (dimension) => ({
      dimension,
      why: isInferenceOnly(dimension)
        ? `${DIMENSION_SCOPE[dimension]} Nothing was inferred here: the AI layer produces these, and it has not been asked yet or returned nothing usable.`
        : `Nothing was observable on the pages read. ${DIMENSION_SCOPE[dimension]}`,
    }),
  );

  const counts = countFindings(findings);
  return {
    competitorName: input.competitorName,
    ...(input.website ? { website: input.website } : {}),
    analysedAt,
    findings,
    pagesRead: pages.map((page) => ({ url: page.url, readAt: page.readAt })),
    limitations,
    counts: {
      verified: counts.verified,
      inferred: counts.inferred,
      dimensionsCovered: covered.size,
      dimensionsNotCovered: notCovered.length,
    },
    notCovered,
  };
}

/**
 * Merges AI-inferred findings into an analysis.
 *
 * Kept separate from `analyzeCompetitor` so that the verified half can be
 * produced, stored and displayed with no model involved at all — and so that a
 * model failure degrades the feature rather than breaking it. Every finding added
 * here is forced to `ai_inference` regardless of what the caller passed, and then
 * linted.
 */
export function withInferences(
  analysis: CompetitorAnalysis,
  inferences: readonly {
    readonly dimension: CompetitorDimension;
    readonly statement: string;
    readonly basedOn: readonly string[];
    readonly confidence?: 'high' | 'medium' | 'low';
  }[],
): CompetitorAnalysis {
  const forced: CompetitorFinding[] = inferences.map((entry) => ({
    dimension: entry.dimension,
    statement: entry.statement,
    // Not `entry.kind`: there is no way for a caller to mark a model's conclusion
    // as verified, by mistake or otherwise.
    evidence: { kind: 'ai_inference', basedOn: entry.basedOn },
    confidence: entry.confidence ?? 'low',
  }));

  const linted = lintCompetitorFindings(forced);
  const findings = [...analysis.findings, ...linted.findings];
  const covered = new Set(findings.map((finding) => finding.dimension));
  const notCovered = analysis.notCovered.filter((entry) => !covered.has(entry.dimension));
  const counts = countFindings(findings);

  return {
    ...analysis,
    findings,
    counts: {
      verified: counts.verified,
      inferred: counts.inferred,
      dimensionsCovered: covered.size,
      dimensionsNotCovered: notCovered.length,
    },
    notCovered,
    limitations:
      linted.dropped.length > 0
        ? [
            ...analysis.limitations,
            {
              code: 'inferences_dropped',
              detail: `${linted.dropped.length} AI inference(s) were discarded for stating a figure that cannot be known from public pages.`,
            },
          ]
        : analysis.limitations,
  };
}

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function firstSentence(text: string): string {
  const trimmed = text.replace(/\s+/g, ' ').trim();
  if (trimmed.length === 0) return '';
  const match = /^(.{20,200}?[.!?])(\s|$)/.exec(trimmed);
  return match?.[1] ?? trimmed.slice(0, 200);
}

function truncate(text: string, limit: number): string {
  return text.length > limit ? `${text.slice(0, limit)}…` : text;
}

function countWords(text: string): number {
  return text.split(/\s+/).filter((word) => word.length > 0).length;
}

function hostOf(url: string): string | null {
  try {
    return new URL(url).hostname.toLowerCase().replace(/^www\./, '');
  } catch {
    return null;
  }
}

/**
 * Offerings named on a page, taken from its H2 headings.
 *
 * Headings are used rather than body text because a heading is a claim the site
 * makes about its own structure. Guessing product names out of prose would
 * produce confident nonsense, which is the thing this whole feature is built to
 * avoid.
 */
function extractOfferings(page: CompetitorPage): string[] {
  return page.h2
    .map((heading) => heading.replace(/\s+/g, ' ').trim())
    .filter((heading) => heading.length > 2 && heading.length <= 60)
    .filter((heading) => !/^(?:about|contact|faq|frequently|testimonial|review|blog|news|why |how )/i.test(heading))
    .slice(0, 8);
}
