/**
 * Competitor intelligence service.
 *
 * THE AUTHORISATION RULE, WHICH IS THE WHOLE POINT OF THIS FILE
 * A competitor cannot consent to being read. So the authorisation recorded is the
 * customer's own acknowledgement, and — exactly as with crawl consent in Phase 4 —
 * it is checked TWICE: when the analysis is requested, and again immediately
 * before any page is fetched. A user can withdraw the acknowledgement in between,
 * and an analysis that proceeds on a withdrawn acknowledgement has no
 * authorisation at all.
 *
 * THE FETCH USES THE PHASE 4 SAFETY POLICY, UNCHANGED
 * `safeFetch` with SSRF checks, DNS pinning, redirect re-validation, size and
 * time limits; robots.txt consulted and failing closed. Nothing about a
 * competitor makes private-network scanning acceptable, and a second fetch path
 * with its own weaker rules is exactly how a second SSRF hole gets introduced.
 *
 * WHAT IS STORED: findings. Not page content. Keeping a copy of a third party's
 * website is a liability with no benefit to the analysis.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { assertTenant, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { CompetitorAnalysisRow, CompetitorRow } from '@/lib/db/types';
import {
  DEFAULT_MAX_REDIRECTS,
  NO_ROBOTS,
  ROBOTS_UNAVAILABLE,
  checkUrl,
  extractPage,
  isAllowed,
  parseRobots,
  robotsUrlFor,
  safeFetch,
  type FetchOptions,
  type Robots,
} from '@/lib/crawler';

import {
  COMPETITOR_ACKNOWLEDGEMENT_VERSION,
  COMPETITOR_FETCH_POLICY,
  analyzeCompetitor,
  type CompetitorPage,
} from './analyze';
import type { CompetitorAnalysis } from './types';

export interface CompetitorServiceContext {
  readonly db: Database;
  readonly now?: () => Date;
  /** Injected in tests so an analysis runs against a fake transport. */
  readonly fetchOptions?: FetchOptions;
}

function clock(context: CompetitorServiceContext): Date {
  return context.now?.() ?? new Date();
}

export class AcknowledgementRequiredError extends Error {
  readonly code = 'NO_ACKNOWLEDGEMENT' as const;
  constructor(
    message = 'Reading this competitor\'s public pages has not been authorised. Accept the research statement first.',
  ) {
    super(message);
    this.name = 'AcknowledgementRequiredError';
  }
}

export class CompetitorInputError extends Error {
  readonly code = 'INVALID_INPUT' as const;
  constructor(message: string) {
    super(message);
    this.name = 'CompetitorInputError';
  }
}

/* -------------------------------------------------------------------------- */
/* Competitors                                                                */
/* -------------------------------------------------------------------------- */

export async function addCompetitor(
  context: CompetitorServiceContext,
  tenant: TenantContext,
  input: {
    readonly projectId: string;
    readonly name: string;
    readonly websiteUrl?: string;
    readonly notes?: string;
    readonly source?: 'onboarding' | 'user_added';
  },
): Promise<CompetitorRow> {
  requirePermission(tenant.role, 'content:create');

  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, input.projectId),
    'Project',
  );

  const name = input.name.trim();
  if (name.length === 0) throw new CompetitorInputError('The competitor needs a name.');
  if (name.length > 120) throw new CompetitorInputError('That name is too long.');

  const existing = await context.db.competitors.findByName(tenant.organizationId, project.id, name);
  if (existing) throw new CompetitorInputError(`"${name}" is already on this project's list.`);

  let websiteUrl: string | null = null;
  if (input.websiteUrl && input.websiteUrl.trim().length > 0) {
    // The same URL policy as the crawler: a competitor URL pointing at a private
    // address is the same attack as a first-party one pointing there.
    const verdict = checkUrl(input.websiteUrl.trim());
    if (!verdict.ok) {
      throw new CompetitorInputError(`That website address cannot be used: ${verdict.reason}`);
    }
    websiteUrl = verdict.url.toString();
  }

  return context.db.competitors.create({
    organizationId: tenant.organizationId,
    projectId: project.id,
    createdBy: tenant.userId,
    name,
    websiteUrl,
    source: input.source ?? 'user_added',
    notes: input.notes?.trim() ?? '',
  });
}

export async function listCompetitors(
  context: CompetitorServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<CompetitorRow[]> {
  requirePermission(tenant.role, 'content:read');
  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, projectId),
    'Project',
  );
  return context.db.competitors.listForProject(tenant.organizationId, project.id);
}

export async function removeCompetitor(
  context: CompetitorServiceContext,
  tenant: TenantContext,
  competitorId: string,
): Promise<void> {
  requirePermission(tenant.role, 'content:create');
  const competitor = assertTenant(
    tenant,
    await context.db.competitors.findById(tenant.organizationId, competitorId),
    'Competitor',
  );
  await context.db.competitors.softDelete(tenant.organizationId, competitor.id, clock(context));
}

/* -------------------------------------------------------------------------- */
/* Acknowledgement                                                            */
/* -------------------------------------------------------------------------- */

export async function acknowledgeResearch(
  context: CompetitorServiceContext,
  tenant: TenantContext,
  competitorId: string,
  accepted: boolean,
): Promise<void> {
  requirePermission(tenant.role, 'content:create');

  const competitor = assertTenant(
    tenant,
    await context.db.competitors.findById(tenant.organizationId, competitorId),
    'Competitor',
  );

  if (!accepted) {
    throw new AcknowledgementRequiredError(
      'The research statement was not accepted, so nothing was recorded and no page will be read.',
    );
  }

  await context.db.competitorAcknowledgements.create({
    organizationId: tenant.organizationId,
    projectId: competitor.projectId,
    competitorId: competitor.id,
    acknowledgedBy: tenant.userId,
    acknowledgedAt: clock(context),
    statementVersion: COMPETITOR_ACKNOWLEDGEMENT_VERSION,
    maxPages: COMPETITOR_FETCH_POLICY.maxPages,
  });
}

/**
 * Withdraws the acknowledgement.
 *
 * Past analyses are kept: they are the customer's own record of work already
 * done, and the acknowledgement row survives too because analyses reference it
 * (ON DELETE RESTRICT). What stops is any further reading.
 */
export async function withdrawAcknowledgement(
  context: CompetitorServiceContext,
  tenant: TenantContext,
  competitorId: string,
): Promise<void> {
  requirePermission(tenant.role, 'content:create');

  const competitor = assertTenant(
    tenant,
    await context.db.competitors.findById(tenant.organizationId, competitorId),
    'Competitor',
  );
  const live = await context.db.competitorAcknowledgements.findLive(
    tenant.organizationId,
    competitor.id,
  );
  if (!live) return;
  await context.db.competitorAcknowledgements.revoke(tenant.organizationId, live.id, clock(context));
}

/* -------------------------------------------------------------------------- */
/* Analysis                                                                   */
/* -------------------------------------------------------------------------- */

export interface AnalyseOutcome {
  readonly analysis: CompetitorAnalysis;
  readonly stored: CompetitorAnalysisRow;
}

/**
 * Reads a few public pages and derives the verified findings.
 *
 * The acknowledgement is checked here AND inside `readPages`, immediately before
 * the first request. `tests/competitors.test.ts` fails if the second check is
 * removed.
 */
export async function analyseCompetitor(
  context: CompetitorServiceContext,
  tenant: TenantContext,
  competitorId: string,
): Promise<AnalyseOutcome> {
  requirePermission(tenant.role, 'content:create');

  const competitor = assertTenant(
    tenant,
    await context.db.competitors.findById(tenant.organizationId, competitorId),
    'Competitor',
  );

  const acknowledgement = await context.db.competitorAcknowledgements.findLive(
    tenant.organizationId,
    competitor.id,
  );
  if (!acknowledgement) throw new AcknowledgementRequiredError();

  if (!competitor.websiteUrl) {
    throw new CompetitorInputError(
      'This competitor has no website recorded, so there is nothing public to read. Add their address first.',
    );
  }

  const { pages, unreadable } = await readPages(context, tenant, competitor);

  const profile = await context.db.marketingProfiles.findByProject(
    tenant.organizationId,
    competitor.projectId,
  );

  const analysis = analyzeCompetitor({
    competitorName: competitor.name,
    website: competitor.websiteUrl,
    pages,
    ...(profile?.targetAudience ? { ownPositioning: profile.targetAudience } : {}),
    unreadable,
    now: () => clock(context),
  });

  const stored = await context.db.competitorAnalyses.create({
    organizationId: tenant.organizationId,
    projectId: competitor.projectId,
    competitorId: competitor.id,
    acknowledgementId: acknowledgement.id,
    jobId: null,
    createdBy: tenant.userId,
    analysedAt: new Date(analysis.analysedAt),
    findings: analysis.findings as unknown as readonly Readonly<Record<string, unknown>>[],
    pagesRead: analysis.pagesRead as unknown as readonly Readonly<Record<string, unknown>>[],
    limitations: analysis.limitations as unknown as readonly Readonly<Record<string, unknown>>[],
    notCovered: analysis.notCovered as unknown as readonly Readonly<Record<string, unknown>>[],
    verifiedCount: analysis.counts.verified,
    inferredCount: analysis.counts.inferred,
  });

  await context.db.usage.record({
    organizationId: tenant.organizationId,
    projectId: competitor.projectId,
    metric: 'competitor_analysis',
    quantity: 1,
    periodStart: metricPeriod(clock(context)),
  });

  return { analysis, stored };
}

/**
 * Fetches at most `COMPETITOR_FETCH_POLICY.maxPages` public pages.
 *
 * robots.txt is consulted first and fails closed, as in Phase 4: if it cannot be
 * read, nothing is fetched. A competitor who has asked automated readers to stay
 * away is a competitor whose pages we do not read.
 */
async function readPages(
  context: CompetitorServiceContext,
  tenant: TenantContext,
  competitor: CompetitorRow,
): Promise<{
  readonly pages: readonly CompetitorPage[];
  readonly unreadable: readonly { readonly url: string; readonly reason: string }[];
}> {
  // SECOND CHECK. The first was in `analyseCompetitor`; an acknowledgement can be
  // withdrawn between the two, and this is the one immediately before a request.
  const live = await context.db.competitorAcknowledgements.findLive(
    tenant.organizationId,
    competitor.id,
  );
  if (!live) throw new AcknowledgementRequiredError();

  const pages: CompetitorPage[] = [];
  const unreadable: { url: string; reason: string }[] = [];

  const base = competitor.websiteUrl!;
  const origin = new URL(base).origin;

  /* --------------------------------------------------------- robots.txt */
  // Identical handling to the Phase 4 crawler, including failing closed: a 5xx
  // or a timeout means we do not read anything. A competitor who has asked
  // automated readers to stay away is a competitor whose pages we do not read.
  let robots: Robots = NO_ROBOTS;
  const fetchedRobots = await safeFetch(robotsUrlFor(base), {
    ...context.fetchOptions,
    accept: 'text/plain,*/*;q=0.5',
  });
  if (fetchedRobots.ok && fetchedRobots.status === 200) {
    robots = parseRobots(fetchedRobots.body);
  } else if (fetchedRobots.ok && fetchedRobots.status === 404) {
    robots = NO_ROBOTS;
  } else {
    robots = ROBOTS_UNAVAILABLE;
  }

  if (robots.source === 'unavailable') {
    unreadable.push({
      url: robotsUrlFor(base),
      reason:
        'robots.txt could not be read, so nothing was fetched. This tool fails closed rather than assuming permission.',
    });
    return { pages, unreadable };
  }

  const candidates = [base, `${origin}/about`, `${origin}/pricing`].slice(
    0,
    Math.min(COMPETITOR_FETCH_POLICY.maxPages, live.maxPages),
  );

  for (const candidate of candidates) {
    const decision = isAllowed(robots, candidate);
    if (!decision.allowed) {
      unreadable.push({
        url: candidate,
        reason: `their robots.txt asks automated readers not to fetch it (${decision.reason})`,
      });
      continue;
    }

    const startedAt = Date.now();
    const response = await safeFetch(candidate, {
      ...context.fetchOptions,
      maxBytes: COMPETITOR_FETCH_POLICY.maxBytesPerPage,
      timeoutMs: COMPETITOR_FETCH_POLICY.timeoutMsPerPage,
      maxRedirects: DEFAULT_MAX_REDIRECTS,
    });

    if (!response.ok) {
      unreadable.push({ url: candidate, reason: response.reason });
      continue;
    }

    const readAt = clock(context);
    const extracted = extractPage({
      url: response.url,
      html: response.body,
      status: response.status,
      bytes: Buffer.byteLength(response.body, 'utf8'),
      responseTimeMs: Date.now() - startedAt,
      crawledAt: readAt,
    });

    pages.push({
      url: extracted.url,
      readAt: extracted.crawledAt.toISOString(),
      status: extracted.status,
      ...(extracted.title ? { title: extracted.title } : {}),
      ...(extracted.metaDescription ? { metaDescription: extracted.metaDescription } : {}),
      h1: extracted.h1,
      h2: extracted.h2,
      textContent: extracted.text,
      internalLinks: extracted.links.filter((link) => link.internal).map((link) => link.url),
      externalLinks: extracted.links.filter((link) => !link.internal).map((link) => link.url),
      imageCount: extracted.images.length,
      imagesWithAlt: extracted.images.filter((image) => (image.alt ?? '').trim().length > 0).length,
      // The raw body is used for tracking-signal detection and is NOT persisted:
      // `CompetitorAnalysisRow` has no column for page content.
      html: response.body,
      isHttps: extracted.https,
    });
  }

  return { pages, unreadable };
}

export async function listAnalyses(
  context: CompetitorServiceContext,
  tenant: TenantContext,
  competitorId: string,
): Promise<CompetitorAnalysisRow[]> {
  requirePermission(tenant.role, 'content:read');
  const competitor = assertTenant(
    tenant,
    await context.db.competitors.findById(tenant.organizationId, competitorId),
    'Competitor',
  );
  return context.db.competitorAnalyses.listForCompetitor(tenant.organizationId, competitor.id);
}

export async function latestAnalysis(
  context: CompetitorServiceContext,
  tenant: TenantContext,
  competitorId: string,
): Promise<CompetitorAnalysisRow | null> {
  requirePermission(tenant.role, 'content:read');
  const competitor = assertTenant(
    tenant,
    await context.db.competitors.findById(tenant.organizationId, competitorId),
    'Competitor',
  );
  return context.db.competitorAnalyses.findLatest(tenant.organizationId, competitor.id);
}

/** The first day of the billing month, which is how usage is bucketed. */
function metricPeriod(at: Date): string {
  return `${at.toISOString().slice(0, 7)}-01`;
}
