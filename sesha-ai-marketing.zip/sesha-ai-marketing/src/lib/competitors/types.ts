/**
 * Competitor intelligence: the vocabulary, and the line down the middle of it.
 *
 * THE LINE
 * Everything this feature produces is one of two things, and they are never
 * mixed:
 *
 *  · VERIFIED PUBLIC — something that was actually read from a public page, with
 *    the URL it was read from and the time it was read. "Their pricing page lists
 *    three tiers" is this, if we read the pricing page.
 *  · AI INFERENCE — a conclusion drawn by a model from that material. "They are
 *    moving upmarket" is this, always, no matter how obvious it seems.
 *
 * The type system enforces it: `CompetitorFinding.evidence` is a discriminated
 * union, and the `verified_public` variant cannot be constructed without a source
 * URL and an observation time. There is no way to record a verified fact without
 * saying where it came from.
 *
 * WHY THIS MATTERS MORE HERE THAN ANYWHERE ELSE IN THE PRODUCT
 * These findings are about a third party. A confident invented claim about a
 * competitor's pricing, funding or customers is not a marketing inaccuracy — it
 * is a statement about another business that the user may repeat in a pitch.
 *
 * Framework-free and fully unit tested.
 */

/** The thirteen areas the brief names. */
export const COMPETITOR_DIMENSIONS = [
  'positioning',
  'products',
  'services',
  'content',
  'seo',
  'aeo',
  'social',
  'advertising',
  'structured_data',
  'strengths',
  'weaknesses',
  'opportunities',
  'differentiation',
] as const;

export type CompetitorDimension = (typeof COMPETITOR_DIMENSIONS)[number];

export const DIMENSION_LABEL: Readonly<Record<CompetitorDimension, string>> = {
  positioning: 'Positioning',
  products: 'Products',
  services: 'Services',
  content: 'Content',
  seo: 'SEO',
  aeo: 'AEO',
  social: 'Social',
  advertising: 'Advertising observations',
  structured_data: 'Structured data',
  strengths: 'Strengths',
  weaknesses: 'Weaknesses',
  opportunities: 'Opportunities',
  differentiation: 'Differentiation',
};

/**
 * What each dimension can and cannot be known from public pages.
 *
 * `advertising` is the one worth reading twice: you cannot see someone's ad spend
 * or performance from their website. What is observable is the evidence that they
 * run ads at all — tracking pixels, campaign parameters in their own links,
 * landing pages that exist for no organic reason. The label says "observations"
 * for that reason and the interface repeats it.
 */
export const DIMENSION_SCOPE: Readonly<Record<CompetitorDimension, string>> = {
  positioning: 'What they say about themselves in their own words, read from their pages.',
  products: 'Products named on their public pages.',
  services: 'Services named on their public pages.',
  content: 'The kinds of content published publicly, and how recently.',
  seo: 'What their markup and page structure show: titles, headings, internal linking, metadata.',
  aeo: 'Whether their pages state facts in a form an AI system can quote: structured data, clear answers, named entities.',
  social: 'Profiles they link to publicly. Follower counts and engagement are NOT read.',
  advertising:
    'Evidence that they advertise — tracking scripts, campaign parameters, landing pages with no organic route in. Spend, budgets, performance and audience targeting cannot be seen from outside and are never estimated.',
  structured_data: 'The schema.org markup their pages publish, validated with the same engine as your own.',
  strengths: 'An inference. Drawn from the observations above, and labelled as a conclusion.',
  weaknesses: 'An inference. Drawn from the observations above, and labelled as a conclusion.',
  opportunities: 'An inference about where you could differentiate. Always a recommendation.',
  differentiation: 'An inference comparing their stated positioning with yours.',
};

/**
 * Dimensions that can carry verified observations, versus those that are
 * inference by their nature. Strengths, weaknesses, opportunities and
 * differentiation are conclusions — there is no public page that states them.
 */
export const INFERENCE_ONLY_DIMENSIONS: readonly CompetitorDimension[] = [
  'strengths',
  'weaknesses',
  'opportunities',
  'differentiation',
];

export function isInferenceOnly(dimension: CompetitorDimension): boolean {
  return INFERENCE_ONLY_DIMENSIONS.includes(dimension);
}

export type EvidenceKind = 'verified_public' | 'ai_inference';

export const EVIDENCE_LABEL: Readonly<Record<EvidenceKind, string>> = {
  verified_public: 'Verified / public data',
  ai_inference: 'AI inference',
};

export const EVIDENCE_MEANING: Readonly<Record<EvidenceKind, string>> = {
  verified_public:
    'Read directly from a public page, with the URL and the time it was read. You can check it yourself.',
  ai_inference:
    'A conclusion drawn from what was read. It may be wrong, and it is not a statement of fact about another business.',
};

/**
 * Evidence for a finding.
 *
 * The `verified_public` variant REQUIRES `sourceUrl` and `observedAt`: a verified
 * fact with no source is indistinguishable from an invented one, so the type does
 * not permit it.
 */
export type Evidence =
  | {
      readonly kind: 'verified_public';
      readonly sourceUrl: string;
      readonly observedAt: string;
      /** The exact text read, where the finding is about wording. */
      readonly quote?: string;
    }
  | {
      readonly kind: 'ai_inference';
      /** What the inference was drawn FROM. Never empty. */
      readonly basedOn: readonly string[];
    };

export type Confidence = 'high' | 'medium' | 'low';

export interface CompetitorFinding {
  readonly dimension: CompetitorDimension;
  /** One sentence. Present tense, no adjectives the evidence does not support. */
  readonly statement: string;
  readonly evidence: Evidence;
  readonly confidence: Confidence;
}

export interface CompetitorProfile {
  readonly name: string;
  readonly website?: string;
  /** Where the competitor came from. Onboarding captures a list. */
  readonly source: 'onboarding' | 'user_added';
}

export interface AnalysisLimitation {
  readonly code: string;
  readonly detail: string;
}

export interface CompetitorAnalysis {
  readonly competitorName: string;
  readonly website?: string;
  readonly analysedAt: string;
  readonly findings: readonly CompetitorFinding[];
  /** Pages actually read, so the whole analysis is auditable. */
  readonly pagesRead: readonly { readonly url: string; readonly readAt: string }[];
  readonly limitations: readonly AnalysisLimitation[];
  readonly counts: {
    readonly verified: number;
    readonly inferred: number;
    readonly dimensionsCovered: number;
    readonly dimensionsNotCovered: number;
  };
  /** Dimensions with no finding at all, named rather than left blank. */
  readonly notCovered: readonly { readonly dimension: CompetitorDimension; readonly why: string }[];
}

/**
 * Things this feature must never claim, with the reason.
 *
 * Checked by `lintCompetitorFindings`, which DROPS a finding that makes one of
 * these claims rather than flagging it — the same decision as the Phase 4 audit
 * linter, for the same reason: a flagged finding is still on screen.
 */
export const FORBIDDEN_CLAIMS: readonly { readonly label: string; readonly pattern: RegExp }[] = [
  {
    label: 'a revenue, funding or spend figure',
    pattern:
      /\b(?:revenue|turnover|funding|raised|valuation|ad spend|advertising spend|budget) (?:of|is|was|at)\s*[₹$€£]?\s*[\d]/i,
  },
  {
    label: 'a traffic or visitor figure',
    pattern: /\b\d[\d,.]*\s*(?:k|m|million|lakh|crore)?\s*(?:monthly )?(?:visitors|visits|sessions|traffic)\b/i,
  },
  {
    label: 'a customer or employee count',
    pattern: /\b(?:they have|has)\s+(?:over\s+|about\s+|around\s+)?\d[\d,.]*\s*(?:\+)?\s*(?:customers|clients|employees|staff|users)\b/i,
  },
  {
    label: 'a follower or engagement count',
    pattern: /\b\d[\d,.]*\s*(?:k|m)?\s*(?:followers|subscribers|likes|engagement rate)\b/i,
  },
  {
    label: 'a conversion or performance rate',
    pattern: /\b(?:conversion|click-through|ctr|bounce) rate (?:of|is)\s*\d/i,
  },
  {
    label: 'a ranking position',
    pattern: /\b(?:ranks?|ranking|position)\s+(?:#|number\s+)?\d+\s+(?:for|on)\b/i,
  },
  {
    label: 'an allegation of wrongdoing',
    pattern: /\b(?:illegal|fraudulent|scam|stole|plagiaris|copied our|fake reviews)\b/i,
  },
];

export interface LintOutcome {
  readonly findings: readonly CompetitorFinding[];
  readonly dropped: readonly { readonly statement: string; readonly reason: string }[];
}

/**
 * Drops findings that claim what cannot be known from public pages.
 *
 * A verified finding is exempt from the numeric patterns ONLY when its quote
 * actually contains the figure: if a competitor's own page says "trusted by 400
 * businesses", repeating that with the source is reporting, not inventing. The
 * quote requirement is what makes that distinction safe — without it, this
 * exemption would be a hole big enough to drive every fabricated number through.
 */
export function lintCompetitorFindings(
  findings: readonly CompetitorFinding[],
): LintOutcome {
  const kept: CompetitorFinding[] = [];
  const dropped: { statement: string; reason: string }[] = [];

  for (const finding of findings) {
    if (finding.statement.trim().length === 0) {
      dropped.push({ statement: finding.statement, reason: 'the statement was empty' });
      continue;
    }

    if (finding.evidence.kind === 'ai_inference' && finding.evidence.basedOn.length === 0) {
      dropped.push({
        statement: finding.statement,
        reason: 'an inference must say what it was drawn from',
      });
      continue;
    }

    if (finding.evidence.kind === 'verified_public' && !isInferenceOnly(finding.dimension)) {
      const quote = finding.evidence.quote ?? '';
      const offending = FORBIDDEN_CLAIMS.find((rule) => rule.pattern.test(finding.statement));
      if (offending) {
        // Quoted from the competitor's own page, with the figure present in the
        // quote: reporting. Otherwise: invented.
        const quoted = quote.length > 0 && containsFigureFrom(finding.statement, quote);
        if (!quoted) {
          dropped.push({
            statement: finding.statement,
            reason: `it states ${offending.label}, which cannot be read from a public page`,
          });
          continue;
        }
      }
      kept.push(finding);
      continue;
    }

    const offending = FORBIDDEN_CLAIMS.find((rule) => rule.pattern.test(finding.statement));
    if (offending) {
      dropped.push({
        statement: finding.statement,
        reason: `an inference may not state ${offending.label}`,
      });
      continue;
    }
    kept.push(finding);
  }

  return { findings: kept, dropped };
}

/** Whether the numbers in a statement actually appear in its quote. */
function containsFigureFrom(statement: string, quote: string): boolean {
  const numbers = statement.match(/\d[\d,.]*/g) ?? [];
  if (numbers.length === 0) return false;
  return numbers.every((number) => quote.includes(number));
}

export function countFindings(
  findings: readonly CompetitorFinding[],
): { readonly verified: number; readonly inferred: number } {
  let verified = 0;
  let inferred = 0;
  for (const finding of findings) {
    if (finding.evidence.kind === 'verified_public') verified += 1;
    else inferred += 1;
  }
  return { verified, inferred };
}
