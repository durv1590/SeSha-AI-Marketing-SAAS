/**
 * Billing service: trial, upgrade, downgrade, cancellation, renewal, failure.
 *
 * TWO RULES GOVERN THIS FILE.
 *
 * 1. **A PLAN CHANGE IS NEVER APPLIED FROM A CLIENT REQUEST.** `changePlan()`
 *    asks the PROVIDER to change it and then waits for the webhook. The
 *    temptation is to update the row optimistically so the screen feels fast;
 *    the result is a customer on the Agency plan who never paid for it, because
 *    the provider declined and nothing reconciled. The only exception is a
 *    DOWNGRADE to a free plan, which takes nothing from us and which the
 *    customer is entitled to have work immediately.
 *
 * 2. **EVERY WEBHOOK IS IDEMPOTENT.** Providers retry and deliver out of order.
 *    `applyWebhook()` records the event first — the database's UNIQUE constraint
 *    on `external_event_id` is the guarantee — and a duplicate is reported as
 *    already-applied rather than replayed. An event with no transition from the
 *    current state is recorded with `applied: false` and a reason, because an
 *    ignored webhook is normal and must be visible rather than silent.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { assertTenant, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { SubscriptionRow } from '@/lib/db/types';
import { PLAN_DEFINITIONS, isPlanId, planChange, type PlanId } from '@/content/plans';
import { planOf } from '@/lib/plans/service';

import {
  applyEvent,
  billingStatus,
  nullProvider,
  type PaymentProvider,
  type SubscriptionEvent,
  type SubscriptionStatus,
} from './types';

export interface BillingServiceContext {
  readonly db: Database;
  readonly provider?: PaymentProvider;
  readonly now?: () => Date;
}

function clock(context: BillingServiceContext): Date {
  return context.now?.() ?? new Date();
}

function providerOf(context: BillingServiceContext): PaymentProvider {
  return context.provider ?? nullProvider;
}

export class BillingError extends Error {
  readonly code = 'BILLING_UNAVAILABLE' as const;
  constructor(message: string) {
    super(message);
    this.name = 'BillingError';
  }
}

/* -------------------------------------------------------------------------- */
/* Reading                                                                    */
/* -------------------------------------------------------------------------- */

export interface BillingView {
  readonly plan: PlanId;
  readonly status: SubscriptionStatus;
  readonly currentPeriodEnd: string | null;
  readonly trialEndsAt: string | null;
  readonly cancelAtPeriodEnd: boolean;
  readonly pastDueSince: string | null;
  /** Display metadata only. Never anything chargeable. */
  readonly paymentMethod: {
    readonly brand: string;
    readonly last4: string;
    readonly expiryMonth: number | null;
    readonly expiryYear: number | null;
  } | null;
  readonly provider: { readonly configured: boolean; readonly message: string };
  readonly availablePlans: readonly PlanId[];
  readonly history: readonly {
    readonly event: string;
    readonly applied: boolean;
    readonly note: string | null;
    readonly occurredAt: string;
  }[];
}

export async function billingView(
  context: BillingServiceContext,
  tenant: TenantContext,
): Promise<BillingView> {
  requirePermission(tenant.role, 'billing:read');
  const subscription = await context.db.subscriptions.findForOrganization(tenant.organizationId);
  const events = await context.db.billingEvents.listForOrganization(tenant.organizationId, 20);
  const status = (subscription?.status ?? 'incomplete') as SubscriptionStatus;

  return {
    plan: planOf(subscription),
    status,
    currentPeriodEnd: subscription?.currentPeriodEnd?.toISOString() ?? null,
    trialEndsAt: subscription?.trialEndsAt?.toISOString() ?? null,
    cancelAtPeriodEnd: subscription?.cancelAtPeriodEnd ?? false,
    pastDueSince: subscription?.pastDueSince?.toISOString() ?? null,
    paymentMethod:
      subscription?.paymentBrand && subscription.paymentLast4
        ? {
            brand: subscription.paymentBrand,
            last4: subscription.paymentLast4,
            expiryMonth: subscription.paymentExpiryMonth,
            expiryYear: subscription.paymentExpiryYear,
          }
        : null,
    provider: billingStatus(providerOf(context)),
    availablePlans: Object.keys(PLAN_DEFINITIONS) as PlanId[],
    history: events.map((row) => ({
      event: row.event,
      applied: row.applied,
      note: row.note,
      occurredAt: row.occurredAt.toISOString(),
    })),
  };
}

/* -------------------------------------------------------------------------- */
/* Starting a plan                                                            */
/* -------------------------------------------------------------------------- */

export interface CheckoutResult {
  readonly url: string;
  readonly expiresAt: string;
}

/**
 * Starts a checkout with the provider.
 *
 * Nothing is written to the subscription here. The customer has not paid yet,
 * and a row that says otherwise is the bug this whole file is arranged to avoid.
 */
export async function startCheckout(
  context: BillingServiceContext,
  tenant: TenantContext,
  plan: PlanId,
  returnUrl: string,
): Promise<CheckoutResult> {
  requirePermission(tenant.role, 'billing:manage');
  if (!isPlanId(plan)) throw new BillingError('That is not a plan SeSha offers.');

  const provider = providerOf(context);
  if (!provider.configured) {
    throw new BillingError(billingStatus(provider).message);
  }
  if (!PLAN_DEFINITIONS[plan].requiresPayment) {
    throw new BillingError(
      `The ${PLAN_DEFINITIONS[plan].name} plan needs no payment, so there is nothing to check out.`,
    );
  }

  const outcome = await provider.createCheckout({
    organizationId: tenant.organizationId,
    plan,
    returnUrl,
    reference: `${tenant.organizationId}:${plan}:${clock(context).getTime()}`,
  });
  if (!outcome.ok) throw new BillingError(outcome.reason);

  return { url: outcome.value.url, expiresAt: outcome.value.expiresAt };
}

/* -------------------------------------------------------------------------- */
/* Changing a plan                                                            */
/* -------------------------------------------------------------------------- */

export interface PlanChangeResult {
  readonly applied: boolean;
  readonly plan: PlanId;
  readonly message: string;
}

/**
 * Upgrade or downgrade.
 *
 * An upgrade to a paid plan needs the provider. A downgrade to `free` is applied
 * immediately and deliberately: it takes money away from us, not from the
 * customer, so there is nobody to defraud and no reason to make them wait.
 *
 * A DOWNGRADE THAT WOULD PUT THEM OVER A LIMIT IS ALLOWED, and nothing is
 * deleted. `checkLimit` then refuses NEW work until they are back inside the
 * limit, and the usage screen shows which one. Deleting a customer's eleventh
 * project because they downgraded would be indefensible; silently letting them
 * keep unlimited projects on a capped plan would make the cap meaningless. This
 * is the honest third option.
 */
export async function changePlan(
  context: BillingServiceContext,
  tenant: TenantContext,
  plan: PlanId,
): Promise<PlanChangeResult> {
  requirePermission(tenant.role, 'billing:manage');
  if (!isPlanId(plan)) throw new BillingError('That is not a plan SeSha offers.');

  const subscription = await context.db.subscriptions.findForOrganization(tenant.organizationId);
  const current = planOf(subscription);
  if (current === plan) {
    return { applied: false, plan: current, message: `You are already on ${PLAN_DEFINITIONS[plan].name}.` };
  }

  const direction = planChange(current, plan);
  const now = clock(context);

  // The one case applied without the provider. See the doc comment.
  if (direction === 'downgrade' && !PLAN_DEFINITIONS[plan].requiresPayment) {
    await context.db.subscriptions.update(tenant.organizationId, {
      plan,
      status: 'active',
      cancelAtPeriodEnd: false,
    });
    await recordEvent(context, tenant.organizationId, {
      event: 'plan_changed',
      statusBefore: subscription?.status ?? null,
      statusAfter: 'active',
      planBefore: current,
      planAfter: plan,
      applied: true,
      note: 'Downgraded to a free plan, applied immediately.',
      at: now,
    });
    return {
      applied: true,
      plan,
      message: `You are on ${PLAN_DEFINITIONS[plan].name}. Nothing has been deleted — if you are over a limit, existing work stays and new work is paused until you are back inside it.`,
    };
  }

  const provider = providerOf(context);
  if (!provider.configured) {
    throw new BillingError(billingStatus(provider).message);
  }
  if (!subscription?.externalSubscriptionId) {
    throw new BillingError(
      'There is no subscription with the payment provider yet. Start a checkout instead.',
    );
  }

  const outcome = await provider.changePlan(subscription.externalSubscriptionId, plan);
  if (!outcome.ok) throw new BillingError(outcome.reason);

  // Still not applied locally: the webhook is what confirms it.
  return {
    applied: false,
    plan: current,
    message: `The ${direction} was requested. It takes effect when the payment provider confirms it, usually within a few seconds.`,
  };
}

/* -------------------------------------------------------------------------- */
/* Cancelling                                                                 */
/* -------------------------------------------------------------------------- */

/**
 * Requests cancellation at the end of the paid period.
 *
 * Not immediately: they have paid to the end of the period and keep it. The row
 * gets `cancelAtPeriodEnd`, the status stays as it was, and the provider's
 * `cancellation_effective` webhook ends it when the period actually ends.
 */
export async function cancel(
  context: BillingServiceContext,
  tenant: TenantContext,
  immediately = false,
): Promise<{ readonly message: string }> {
  requirePermission(tenant.role, 'billing:manage');
  const subscription = await context.db.subscriptions.findForOrganization(tenant.organizationId);
  const found = assertTenant(tenant, subscription, 'Subscription');
  const now = clock(context);

  const provider = providerOf(context);
  if (found.externalSubscriptionId && provider.configured) {
    const outcome = await provider.cancel(found.externalSubscriptionId, !immediately);
    if (!outcome.ok) throw new BillingError(outcome.reason);
  }

  if (immediately) {
    await context.db.subscriptions.update(tenant.organizationId, {
      status: 'canceled',
      canceledAt: now,
      cancelAtPeriodEnd: false,
    });
    await recordEvent(context, tenant.organizationId, {
      event: 'cancellation_effective',
      statusBefore: found.status,
      statusAfter: 'canceled',
      applied: true,
      note: 'Cancelled immediately at the customer’s request.',
      at: now,
    });
    return {
      message:
        'Cancelled. Everything you have is still here and still exports — nothing has been deleted.',
    };
  }

  await context.db.subscriptions.update(tenant.organizationId, { cancelAtPeriodEnd: true });
  await recordEvent(context, tenant.organizationId, {
    event: 'cancellation_requested',
    statusBefore: found.status,
    statusAfter: found.status,
    applied: true,
    note: 'Will end when the current period does.',
    at: now,
  });

  const ends = found.currentPeriodEnd?.toISOString().slice(0, 10);
  return {
    message: ends
      ? `Cancellation scheduled for ${ends}. You keep everything until then, and you can undo this at any point before it.`
      : 'Cancellation scheduled for the end of the current period. You can undo this at any point before then.',
  };
}

export async function resumeCancellation(
  context: BillingServiceContext,
  tenant: TenantContext,
): Promise<{ readonly message: string }> {
  requirePermission(tenant.role, 'billing:manage');
  const subscription = await context.db.subscriptions.findForOrganization(tenant.organizationId);
  assertTenant(tenant, subscription, 'Subscription');
  await context.db.subscriptions.update(tenant.organizationId, { cancelAtPeriodEnd: false });
  return { message: 'Cancellation withdrawn. Your subscription continues as before.' };
}

/* -------------------------------------------------------------------------- */
/* Webhooks                                                                   */
/* -------------------------------------------------------------------------- */

export interface WebhookInput {
  readonly organizationId: string;
  readonly event: SubscriptionEvent;
  /** The provider's own id. Required for idempotency; absent means unverified. */
  readonly externalEventId: string | null;
  readonly plan?: PlanId;
  readonly currentPeriodStart?: Date | null;
  readonly currentPeriodEnd?: Date | null;
  readonly paymentMethod?: {
    readonly brand: string;
    readonly last4: string;
    readonly expiryMonth: number | null;
    readonly expiryYear: number | null;
  } | null;
  /** A SUMMARY. Never the raw provider payload. */
  readonly summary?: Readonly<Record<string, unknown>>;
}

export type WebhookOutcome =
  | { readonly ok: true; readonly applied: boolean; readonly status: SubscriptionStatus; readonly note?: string }
  | { readonly ok: false; readonly reason: string };

/**
 * Applies a verified provider event.
 *
 * THE CALLER MUST HAVE VERIFIED THE SIGNATURE ALREADY. This function does not
 * and cannot — it does not see the raw body. The route calls
 * `provider.verifyWebhook(rawBody, signature)` first, and the null provider
 * returns false, so no webhook is ever applied while no provider is connected.
 */
export async function applyWebhook(
  context: BillingServiceContext,
  input: WebhookInput,
): Promise<WebhookOutcome> {
  const now = clock(context);
  const subscription = await context.db.subscriptions.findForOrganization(input.organizationId);
  if (!subscription) {
    return { ok: false, reason: 'No subscription for that organization.' };
  }

  const before = subscription.status as SubscriptionStatus;
  const transition = applyEvent(before, input.event);

  // Recorded FIRST, so the unique constraint on external_event_id rejects a
  // replay before any state is changed.
  const recorded = await context.db.billingEvents.record({
    organizationId: input.organizationId,
    externalEventId: input.externalEventId,
    provider: providerOf(context).name,
    event: input.event,
    statusBefore: before,
    statusAfter: transition.status,
    planBefore: subscription.plan,
    planAfter: input.plan ?? subscription.plan,
    applied: transition.changed || input.plan !== undefined,
    note: transition.note ?? null,
    payloadSummary: input.summary ?? {},
    occurredAt: now,
  });

  if (recorded === null) {
    return {
      ok: true,
      applied: false,
      status: before,
      note: 'Already processed. Providers retry; this one had been seen before.',
    };
  }

  const patch = buildPatch(subscription, input, transition.status, before, now);
  if (Object.keys(patch).length > 0) {
    await context.db.subscriptions.update(input.organizationId, patch);
  }

  return {
    ok: true,
    applied: transition.changed || Object.keys(patch).length > 0,
    status: transition.status,
    ...(transition.note ? { note: transition.note } : {}),
  };
}

function buildPatch(
  subscription: SubscriptionRow,
  input: WebhookInput,
  status: SubscriptionStatus,
  before: SubscriptionStatus,
  now: Date,
): Partial<SubscriptionRow> {
  const patch: Record<string, unknown> = {};

  if (status !== before) patch.status = status;
  if (input.plan && input.plan !== subscription.plan) patch.plan = input.plan;
  if (input.currentPeriodStart !== undefined) patch.currentPeriodStart = input.currentPeriodStart;
  if (input.currentPeriodEnd !== undefined) patch.currentPeriodEnd = input.currentPeriodEnd;

  // The grace window opens when the payment FIRST fails and is not restarted by
  // a repeat failure — otherwise a provider retrying a declined card every day
  // would extend the window forever and the account would never be paused.
  if (status === 'past_due' && subscription.pastDueSince === null) {
    patch.pastDueSince = now;
  }
  if (status !== 'past_due' && subscription.pastDueSince !== null) {
    patch.pastDueSince = null;
  }
  if (status === 'canceled' && subscription.canceledAt === null) {
    patch.canceledAt = now;
    patch.cancelAtPeriodEnd = false;
  }

  if (input.paymentMethod !== undefined) {
    patch.paymentBrand = input.paymentMethod?.brand ?? null;
    patch.paymentLast4 = input.paymentMethod?.last4 ?? null;
    patch.paymentExpiryMonth = input.paymentMethod?.expiryMonth ?? null;
    patch.paymentExpiryYear = input.paymentMethod?.expiryYear ?? null;
  }

  return patch as Partial<SubscriptionRow>;
}

async function recordEvent(
  context: BillingServiceContext,
  organizationId: string,
  input: {
    readonly event: SubscriptionEvent;
    readonly statusBefore: string | null;
    readonly statusAfter: string | null;
    readonly planBefore?: string | null;
    readonly planAfter?: string | null;
    readonly applied: boolean;
    readonly note: string | null;
    readonly at: Date;
  },
): Promise<void> {
  await context.db.billingEvents.record({
    organizationId,
    // No external id: this event originated here, not at the provider. Leaving
    // it null keeps the idempotency key free for real provider events.
    externalEventId: null,
    provider: providerOf(context).name,
    event: input.event,
    statusBefore: input.statusBefore,
    statusAfter: input.statusAfter,
    planBefore: input.planBefore ?? null,
    planAfter: input.planAfter ?? null,
    applied: input.applied,
    note: input.note,
    payloadSummary: {},
    occurredAt: input.at,
  });
}
