/**
 * Billing: the provider abstraction and the subscription state machine.
 *
 * WHAT THIS FILE REFUSES TO HOLD
 * No card number, no CVV, no expiry, no bank detail, no raw webhook payload.
 * Not as a nullable column, not "temporarily", not behind a flag. The brief says
 * *"do not store sensitive payment data unless required and properly handled"*,
 * and the honest reading is that SeSha never requires it: the customer enters
 * their card on the PROVIDER's hosted page, and what comes back is an opaque
 * identifier. `PaymentMethodSummary` below is the complete set of what may be
 * kept — brand, last four, expiry month and year — which is display metadata
 * every provider returns and none of which can be used to charge anybody.
 *
 * `tests/billing.test.ts` scans this module and the billing service for the
 * field names a card object would have, and fails if one appears. That is a
 * crude check, and it is there because the expensive version of this mistake is
 * a PCI incident rather than a bug report.
 *
 * WHY THERE IS A PROVIDER INTERFACE AT ALL WHEN NONE IS CONNECTED
 * The same reason `sendingStatus()` exists for email (Phase 5). The interface
 * states exactly what SeSha needs from a payment provider, the null
 * implementation refuses every call with a reason, and `billingStatus()` is the
 * one function every screen reads before offering to charge anyone. Without it,
 * the upgrade button would be the lie — a control that looks live and silently
 * does nothing.
 *
 * Framework-free and fully unit tested.
 */

import type { PlanId } from '@/content/plans';

/* -------------------------------------------------------------------------- */
/* Subscription state                                                         */
/* -------------------------------------------------------------------------- */

/**
 * The states the brief names, plus the two the state machine needs to be honest.
 *
 * `incomplete` exists because a checkout that was started and not finished is
 * not the same as an active subscription, and treating it as one grants access
 * to someone who never paid. `paused` is carried over from Phase 2.
 */
export const SUBSCRIPTION_STATUSES = [
  'trialing',
  'active',
  'past_due',
  'canceled',
  'paused',
  'incomplete',
] as const;

export type SubscriptionStatus = (typeof SUBSCRIPTION_STATUSES)[number];

export const STATUS_LABEL: Readonly<Record<SubscriptionStatus, string>> = {
  trialing: 'Trial',
  active: 'Active',
  past_due: 'Payment failed',
  canceled: 'Cancelled',
  paused: 'Paused',
  incomplete: 'Not finished',
};

/**
 * What the customer sees, per state. Written to be read by a worried person.
 */
export const STATUS_EXPLANATION: Readonly<Record<SubscriptionStatus, string>> = {
  trialing: 'You are on a trial. Nothing has been charged yet.',
  active: 'Your subscription is active.',
  past_due:
    'The last payment did not go through. Your work is intact and everything still opens — update the payment method and it resumes. Nothing is deleted.',
  canceled:
    'This subscription is cancelled. Your data is still here and still exports; you can start again whenever you want.',
  paused: 'This subscription is paused. Nothing is being charged.',
  incomplete: 'Checkout was started but not finished, so nothing has changed yet.',
};

/**
 * The badge colour for each state.
 *
 * TYPED AS A COMPLETE RECORD, AND KEPT HERE RATHER THAN IN EACH SCREEN. It was
 * originally a local constant in two pages, and both were missing `paused` —
 * every status but that one was listed, so both screens fell through to a
 * `?? 'neutral'` that made the omission invisible. Nothing failed, and nothing
 * would have, until someone paused a subscription and wondered why it looked
 * like an ordinary cancelled one.
 *
 * `Record<SubscriptionStatus, …>` is what makes that impossible: adding a
 * seventh status now fails to compile here, which is the only moment anyone is
 * still thinking about what its colour should be.
 */
export const STATUS_TONE: Readonly<
  Record<SubscriptionStatus, 'neutral' | 'brand' | 'success' | 'warning' | 'danger' | 'info'>
> = {
  trialing: 'info',
  active: 'success',
  // A failed payment is a warning, not a danger: the customer keeps working
  // through the grace window, and a red badge would overstate it.
  past_due: 'warning',
  canceled: 'neutral',
  paused: 'neutral',
  incomplete: 'warning',
};

export function isSubscriptionStatus(value: unknown): value is SubscriptionStatus {
  return typeof value === 'string' && (SUBSCRIPTION_STATUSES as readonly string[]).includes(value);
}

/* -------------------------------------------------------------------------- */
/* What a state means for access                                              */
/* -------------------------------------------------------------------------- */

/**
 * How long a failed payment keeps working before writes stop.
 *
 * Seven days, and the number matters. A card expires, a bank declines a routine
 * charge, a finance team is on holiday — cutting a paying customer off the
 * moment a webhook arrives punishes them for their bank's behaviour. Seven days
 * is long enough for a person to notice an email and short enough that it is not
 * a free month.
 */
export const PAST_DUE_GRACE_DAYS = 7;

export interface AccessDecision {
  /** Can they open the product and read their work? Almost always yes. */
  readonly readable: boolean;
  /** Can they create new things and spend quota? */
  readonly writable: boolean;
  readonly reason?: string;
}

/**
 * What a subscription state permits.
 *
 * READ ACCESS IS NEVER REVOKED. Not on cancellation, not on non-payment. A
 * customer's content, leads, audits and reports are theirs, and holding them
 * hostage to collect a debt is both wrong and — under most data-protection
 * regimes — illegal. Cancelling stops writes and stops charges; it does not turn
 * the archive off.
 */
export function accessFor(
  status: SubscriptionStatus,
  options: { readonly pastDueSince?: Date | null; readonly now: Date },
): AccessDecision {
  switch (status) {
    case 'active':
    case 'trialing':
      return { readable: true, writable: true };

    case 'past_due': {
      const since = options.pastDueSince ?? null;
      if (!since) {
        // No recorded start to the grace window: give the benefit of the doubt.
        // A missing timestamp is our bookkeeping problem, not the customer's.
        return { readable: true, writable: true };
      }
      const days = (options.now.getTime() - since.getTime()) / 86_400_000;
      if (days <= PAST_DUE_GRACE_DAYS) {
        return { readable: true, writable: true };
      }
      return {
        readable: true,
        writable: false,
        reason: `The last payment has been outstanding for more than ${PAST_DUE_GRACE_DAYS} days, so new work is paused. Everything you have is still here and still exports. Updating the payment method restores it immediately.`,
      };
    }

    case 'canceled':
      return {
        readable: true,
        writable: false,
        reason:
          'This subscription is cancelled, so nothing new can be created. Everything you have is still here and still exports. Choose a plan to start again.',
      };

    case 'paused':
      return {
        readable: true,
        writable: false,
        reason: 'This subscription is paused. Resume it to start creating again.',
      };

    case 'incomplete':
      return {
        readable: true,
        writable: false,
        reason: 'Checkout was not finished, so the plan has not started. Nothing has been charged.',
      };
  }
}

/* -------------------------------------------------------------------------- */
/* Transitions                                                                */
/* -------------------------------------------------------------------------- */

export const SUBSCRIPTION_EVENTS = [
  'trial_started',
  'checkout_completed',
  'payment_succeeded',
  'payment_failed',
  'renewed',
  'plan_changed',
  'cancellation_requested',
  'cancellation_effective',
  'paused',
  'resumed',
] as const;

export type SubscriptionEvent = (typeof SUBSCRIPTION_EVENTS)[number];

/**
 * What each event is called on a customer's own billing history.
 *
 * Written in the past tense and in plain words, because this list is read by
 * someone trying to work out what happened to their account — usually at the
 * moment something has gone wrong. `payment_failed` is "Payment did not go
 * through", not "Payment failure": the first describes an event, the second
 * sounds like a verdict on the person.
 */
export const EVENT_LABEL: Readonly<Record<SubscriptionEvent, string>> = {
  trial_started: 'Trial started',
  checkout_completed: 'Checkout completed',
  payment_succeeded: 'Payment received',
  payment_failed: 'Payment did not go through',
  renewed: 'Renewed',
  plan_changed: 'Plan changed',
  cancellation_requested: 'Cancellation requested',
  cancellation_effective: 'Subscription ended',
  paused: 'Paused',
  resumed: 'Resumed',
};

/**
 * The state machine, as data.
 *
 * A map rather than a switch so the whole thing can be walked by a test: every
 * state must be reachable, and no event may leave a state in a value that is not
 * a status. A webhook arriving in the wrong order is normal — providers retry and
 * deliver out of order — so an event with no transition from the current state is
 * IGNORED rather than treated as an error. Throwing would mean a retried
 * `payment_succeeded` could break an active subscription.
 */
export const TRANSITIONS: Readonly<
  Record<SubscriptionStatus, Partial<Record<SubscriptionEvent, SubscriptionStatus>>>
> = {
  incomplete: {
    checkout_completed: 'active',
    trial_started: 'trialing',
    payment_succeeded: 'active',
    cancellation_effective: 'canceled',
  },
  trialing: {
    checkout_completed: 'active',
    payment_succeeded: 'active',
    payment_failed: 'past_due',
    plan_changed: 'trialing',
    cancellation_requested: 'trialing',
    cancellation_effective: 'canceled',
    paused: 'paused',
  },
  active: {
    payment_failed: 'past_due',
    payment_succeeded: 'active',
    renewed: 'active',
    plan_changed: 'active',
    // Requesting cancellation does NOT end the subscription: the customer has
    // paid to the end of the period and keeps it. `cancelAtPeriodEnd` is set,
    // and `cancellation_effective` arrives when the period actually ends.
    cancellation_requested: 'active',
    cancellation_effective: 'canceled',
    paused: 'paused',
  },
  past_due: {
    payment_succeeded: 'active',
    renewed: 'active',
    payment_failed: 'past_due',
    cancellation_requested: 'past_due',
    cancellation_effective: 'canceled',
    paused: 'paused',
  },
  paused: {
    resumed: 'active',
    payment_succeeded: 'active',
    cancellation_effective: 'canceled',
  },
  canceled: {
    // A cancelled subscription restarts only through a new checkout.
    checkout_completed: 'active',
    trial_started: 'trialing',
  },
};

export interface TransitionResult {
  readonly status: SubscriptionStatus;
  readonly changed: boolean;
  /** Why nothing changed, when nothing did. Recorded, never silent. */
  readonly note?: string;
}

export function applyEvent(
  status: SubscriptionStatus,
  event: SubscriptionEvent,
): TransitionResult {
  const next = TRANSITIONS[status][event];
  if (next === undefined) {
    return {
      status,
      changed: false,
      note: `"${event}" does not apply to a ${STATUS_LABEL[status].toLowerCase()} subscription. Ignored — providers deliver webhooks out of order and retry them.`,
    };
  }
  if (next === status) {
    return { status, changed: false, note: `Already ${STATUS_LABEL[status].toLowerCase()}.` };
  }
  return { status: next, changed: true };
}

/* -------------------------------------------------------------------------- */
/* The provider abstraction                                                   */
/* -------------------------------------------------------------------------- */

/**
 * The complete set of payment data SeSha may keep.
 *
 * Display metadata only. Nothing here can be used to charge anyone, and there is
 * deliberately no field for a token, a number, a CVV or a bank account.
 */
export interface PaymentMethodSummary {
  /** 'visa', 'mastercard', 'upi', … as the provider labels it. */
  readonly brand: string;
  /** Exactly four digits, or an empty string for methods that have none. */
  readonly last4: string;
  readonly expiryMonth: number | null;
  readonly expiryYear: number | null;
}

export interface CheckoutRequest {
  readonly organizationId: string;
  readonly plan: PlanId;
  /** Where the provider returns the customer to. Must be our own origin. */
  readonly returnUrl: string;
  /** Opaque to us; the provider echoes it back on the webhook. */
  readonly reference: string;
}

export interface CheckoutSession {
  /** The provider's hosted page. The card is entered THERE, never here. */
  readonly url: string;
  readonly externalId: string;
  readonly expiresAt: string;
}

export interface ProviderSubscription {
  readonly externalId: string;
  readonly status: SubscriptionStatus;
  readonly plan: PlanId;
  readonly currentPeriodStart: string | null;
  readonly currentPeriodEnd: string | null;
  readonly cancelAtPeriodEnd: boolean;
  readonly paymentMethod: PaymentMethodSummary | null;
}

export type BillingOutcome<T> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly reason: string };

/**
 * What SeSha needs from a payment provider. Nothing more.
 *
 * Note what is absent: no method takes a card, and no method returns one. A
 * provider implementation that needed either would not fit this interface, which
 * is the point.
 */
export interface PaymentProvider {
  readonly name: string;
  /** False for the null provider, which is the only one that exists today. */
  readonly configured: boolean;

  createCheckout(request: CheckoutRequest): Promise<BillingOutcome<CheckoutSession>>;
  /** A hosted page where the customer manages their own card and invoices. */
  createPortalSession(
    externalCustomerId: string,
    returnUrl: string,
  ): Promise<BillingOutcome<{ readonly url: string }>>;
  changePlan(
    externalSubscriptionId: string,
    plan: PlanId,
  ): Promise<BillingOutcome<ProviderSubscription>>;
  cancel(
    externalSubscriptionId: string,
    atPeriodEnd: boolean,
  ): Promise<BillingOutcome<ProviderSubscription>>;
  fetchSubscription(externalSubscriptionId: string): Promise<BillingOutcome<ProviderSubscription>>;
  /**
   * Verifies a webhook came from the provider.
   *
   * Takes the RAW body, because every provider signs the bytes and re-serialising
   * parsed JSON changes them. A provider that cannot verify is not connected.
   */
  verifyWebhook(rawBody: string, signature: string): boolean;
}

/* -------------------------------------------------------------------------- */
/* The null provider                                                          */
/* -------------------------------------------------------------------------- */

const NOT_CONFIGURED =
  'No payment provider is connected, so SeSha cannot take a payment. Nothing was charged and nothing was changed.';

/**
 * The provider that refuses everything, and says why.
 *
 * This is what ships. It exists so every call site is written against a real
 * interface and the refusal is visible in the interface rather than discovered
 * when a customer clicks Upgrade.
 */
export const nullProvider: PaymentProvider = {
  name: 'none',
  configured: false,
  createCheckout: async () => ({ ok: false, reason: NOT_CONFIGURED }),
  createPortalSession: async () => ({ ok: false, reason: NOT_CONFIGURED }),
  changePlan: async () => ({ ok: false, reason: NOT_CONFIGURED }),
  cancel: async () => ({ ok: false, reason: NOT_CONFIGURED }),
  fetchSubscription: async () => ({ ok: false, reason: NOT_CONFIGURED }),
  // Never true. An unverifiable webhook must not be trusted, and returning true
  // here would make the null provider the most dangerous object in the codebase.
  verifyWebhook: () => false,
};

/**
 * The single gate every screen reads before offering to charge anyone.
 *
 * Same shape as `publishingStatus()` (Phase 3), `sendingStatus()` (Phase 5) and
 * `analyticsStatus()` (Phase 6).
 */
export function billingStatus(provider: PaymentProvider = nullProvider): {
  readonly configured: boolean;
  readonly message: string;
} {
  if (provider.configured) {
    return {
      configured: true,
      message: `Payments are handled by ${provider.name}. Your card details are entered on their page and are never stored by SeSha.`,
    };
  }
  return {
    configured: false,
    message:
      'No payment provider is connected yet, so no plan can be bought and nothing can be charged. Plan limits still apply — every account is on its assigned plan. Connect a provider to enable checkout.',
  };
}
