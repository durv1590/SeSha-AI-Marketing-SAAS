/**
 * A minimal variant helper, in the spirit of class-variance-authority.
 *
 * Written in-house rather than added as a dependency: the API surface we
 * actually use is a base class string, a set of named variant maps, defaults
 * and compound rules. That is ~40 lines and removes a dependency from the
 * production bundle.
 */

import { cn } from './cn';

type VariantMap = Record<string, Record<string, string>>;

/**
 * A boolean variant is declared with the string keys `true` and `false`, because
 * an object literal has string keys — so `keyof` gives `'true' | 'false'` and a
 * real boolean would not be assignable.
 *
 * That was a genuine type error at every `<Button block>` call site, invisible
 * for seven phases because `.tsx` was never type-checked. It never broke at
 * runtime — `resolve()` below does `String(chosen)` — so only the compiler ever
 * had anything to say about it, and nothing was asking the compiler.
 *
 * The condition is wrapped in a tuple so it does NOT distribute: boolean is
 * offered only when the whole key union is exactly the two flag keys, never when
 * `'true'` happens to be one option among several.
 */
type BooleanIfFlagVariant<Keys> = [Keys] extends ['true' | 'false'] ? boolean : never;

type VariantSelection<V extends VariantMap> = {
  [K in keyof V]?: keyof V[K] | BooleanIfFlagVariant<keyof V[K]> | null | undefined;
};

export interface VariantConfig<V extends VariantMap> {
  readonly base?: string;
  readonly variants: V;
  readonly defaultVariants?: VariantSelection<V>;
  /**
   * Classes applied only when every listed variant matches, e.g. a ghost
   * button at small size needing tighter padding than either rule alone.
   */
  readonly compoundVariants?: readonly (VariantSelection<V> & { class: string })[];
}

export type VariantProps<F> = F extends (props: infer P) => string ? NonNullable<P> : never;

export function tv<V extends VariantMap>(config: VariantConfig<V>) {
  return function resolve(
    props?: VariantSelection<V> & { class?: string; className?: string },
  ): string {
    const selection = { ...config.defaultVariants, ...props } as VariantSelection<V>;
    const classes: string[] = [];

    if (config.base) classes.push(config.base);

    for (const groupName of Object.keys(config.variants)) {
      const chosen = selection[groupName as keyof V];
      if (chosen === null || chosen === undefined) continue;
      const group = config.variants[groupName];
      const resolved = group?.[String(chosen)];
      if (resolved) classes.push(resolved);
    }

    for (const compound of config.compoundVariants ?? []) {
      const { class: compoundClass, ...conditions } = compound;
      const matches = Object.entries(conditions).every(
        ([key, value]) => String(selection[key as keyof V]) === String(value),
      );
      if (matches) classes.push(compoundClass);
    }

    return cn(classes, props?.class, props?.className);
  };
}
