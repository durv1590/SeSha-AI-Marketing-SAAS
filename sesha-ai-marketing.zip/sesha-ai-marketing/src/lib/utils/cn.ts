import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Conditional class names with Tailwind conflict resolution.
 *
 * `clsx` handles conditional/array/object inputs; `twMerge` resolves conflicts
 * so a later class actually wins. Without twMerge, `cn('p-4', 'p-2')` emits
 * both and CSS source order — not argument order — decides, which makes the
 * `className` override prop on every component unreliable.
 *
 * These are the only two runtime dependencies beyond React and Next.
 */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}
