/**
 * Notifications, and the preferences that govern them.
 *
 * THE BRIEF'S SENTENCE IS THE DESIGN
 * *"Users must control notification preferences."* That is not a settings screen
 * — it is a rule about where the decision lives. So `shouldNotify()` is the only
 * way anything in this codebase reaches a user, it takes the preference as an
 * argument, and there is no bypass. A feature that wants to notify someone cannot
 * decide on its own that its message is important enough.
 *
 * TWO KINDS ARE NOT OPTIONAL, AND SAY SO
 * Security and billing notifications cannot be switched off. A product that lets
 * someone mute "your password was changed" is a product that helps an attacker
 * stay hidden, and one that lets someone mute "your card failed" surprises them
 * with a dead account. `ALWAYS_ON` names them, the interface renders them as
 * locked WITH the reason, and `shouldNotify` ignores the preference for them —
 * rather than quietly appearing to accept a setting it will not honour.
 *
 * WHAT CHANNELS EXIST TODAY
 * In-app only. SeSha cannot send email (Phase 5: no provider is connected), so
 * an email toggle here would be a switch wired to nothing. `CHANNELS` carries an
 * `available` flag and the reason, and the settings screen shows email as
 * unavailable rather than hiding it — a customer deciding whether to buy should
 * be able to see what is not built yet.
 *
 * Framework-free and fully unit tested.
 */

/* -------------------------------------------------------------------------- */
/* Kinds                                                                      */
/* -------------------------------------------------------------------------- */

/**
 * The eight events the brief names, plus the three the product already had.
 *
 * `security`, `billing` and `system` come from Phase 2 and are kept, because the
 * existing table's CHECK constraint uses them and because muting a security alert
 * should never become possible by accident.
 */
export const NOTIFICATION_KINDS = [
  'report_ready',
  'new_lead',
  'campaign_changed',
  'content_scheduled',
  'schema_error',
  'audit_complete',
  'crawl_complete',
  'validation_complete',
  'security',
  'billing',
  'system',
] as const;

export type NotificationKind = (typeof NOTIFICATION_KINDS)[number];

/** The eight the Phase 6 brief lists, for the gate test to check against. */
export const PHASE_6_NOTIFICATION_KINDS: readonly NotificationKind[] = [
  'report_ready',
  'new_lead',
  'campaign_changed',
  'content_scheduled',
  'schema_error',
  'audit_complete',
  'crawl_complete',
  'validation_complete',
];

export const NOTIFICATION_LABEL: Readonly<Record<NotificationKind, string>> = {
  report_ready: 'A report is ready',
  new_lead: 'A new lead arrives',
  campaign_changed: 'A campaign changes',
  content_scheduled: 'Content is scheduled',
  schema_error: 'A structured-data error is found',
  audit_complete: 'An audit finishes',
  crawl_complete: 'A crawl finishes',
  validation_complete: 'A validation finishes',
  security: 'Security',
  billing: 'Billing',
  system: 'Service messages',
};

export const NOTIFICATION_DESCRIPTION: Readonly<Record<NotificationKind, string>> = {
  report_ready: 'Sent when a scheduled or requested report has finished generating.',
  new_lead: 'Sent when an enquiry is recorded in your pipeline.',
  campaign_changed: 'Sent when a campaign plan is approved, declined or edited.',
  content_scheduled: 'Sent when a piece of content is put on the calendar.',
  schema_error: 'Sent when a validation finds an error, or markup disappears from a page.',
  audit_complete: 'Sent when an SEO or AEO audit finishes and the score is ready.',
  crawl_complete: 'Sent when a crawl finishes, including when it stopped early.',
  validation_complete: 'Sent when a structured-data validation finishes.',
  security: 'Sign-ins, password changes, new devices and API keys. Cannot be switched off.',
  billing: 'Payments, failures and plan changes. Cannot be switched off.',
  system: 'Maintenance and service notices that affect your account.',
};

/**
 * Kinds a user may not switch off, and why.
 *
 * The reason is stored beside the rule so the settings screen can SHOW it. A
 * greyed-out toggle with no explanation reads as a bug or as contempt.
 */
export const ALWAYS_ON: Readonly<Partial<Record<NotificationKind, string>>> = {
  security:
    'Security notices cannot be switched off. If someone signs in as you or changes your password, you need to know, and an attacker must not be able to silence it.',
  billing:
    'Billing notices cannot be switched off, so a failed payment never becomes a surprise cancellation.',
};

export function isNotificationKind(value: unknown): value is NotificationKind {
  return typeof value === 'string' && (NOTIFICATION_KINDS as readonly string[]).includes(value);
}

export function isAlwaysOn(kind: NotificationKind): boolean {
  return ALWAYS_ON[kind] !== undefined;
}

/* -------------------------------------------------------------------------- */
/* Channels                                                                   */
/* -------------------------------------------------------------------------- */

export const CHANNEL_IDS = ['in_app', 'email'] as const;
export type ChannelId = (typeof CHANNEL_IDS)[number];

export interface ChannelDefinition {
  readonly id: ChannelId;
  readonly label: string;
  readonly available: boolean;
  /** Why not, when it is not. Shown, not hidden. */
  readonly unavailableReason?: string;
}

export const CHANNELS: Readonly<Record<ChannelId, ChannelDefinition>> = {
  in_app: { id: 'in_app', label: 'In SeSha', available: true },
  email: {
    id: 'email',
    label: 'Email',
    available: false,
    unavailableReason:
      'No email provider is connected, so SeSha cannot send email. Connect one in Settings and this becomes available. Until then it is shown here rather than hidden, so you know what it would do.',
  },
};

export function availableChannels(): readonly ChannelId[] {
  return CHANNEL_IDS.filter((id) => CHANNELS[id].available);
}

/* -------------------------------------------------------------------------- */
/* Preferences                                                                */
/* -------------------------------------------------------------------------- */

export interface NotificationPreference {
  readonly kind: NotificationKind;
  readonly inApp: boolean;
  readonly email: boolean;
}

/**
 * The default preference for a kind.
 *
 * Everything on, because a notification a user never sees is the same as a
 * feature that does not exist, and because the whole set is in-app only — there
 * is no inbox to flood. `content_scheduled` is the one exception: a person who
 * schedules something does not need to be told they scheduled it.
 */
export function defaultPreference(kind: NotificationKind): NotificationPreference {
  return {
    kind,
    inApp: kind !== 'content_scheduled',
    email: false,
  };
}

export function defaultPreferences(): readonly NotificationPreference[] {
  return NOTIFICATION_KINDS.map(defaultPreference);
}

/**
 * Merges stored rows over the defaults.
 *
 * A kind with no row gets the default rather than being treated as off, so adding
 * a new notification kind does not silently arrive switched off for every
 * existing user.
 */
export function resolvePreferences(
  rows: readonly { readonly kind: string; readonly inApp: boolean; readonly email: boolean }[],
): readonly NotificationPreference[] {
  return NOTIFICATION_KINDS.map((kind) => {
    const row = rows.find((candidate) => candidate.kind === kind);
    const base = defaultPreference(kind);
    if (!row) return base;
    if (isAlwaysOn(kind)) return { kind, inApp: true, email: row.email && CHANNELS.email.available };
    return { kind, inApp: row.inApp, email: row.email && CHANNELS.email.available };
  });
}

export interface PreferenceUpdate {
  readonly kind: NotificationKind;
  readonly inApp?: boolean;
  readonly email?: boolean;
}

export interface PreferenceProblem {
  readonly kind: NotificationKind;
  readonly message: string;
}

/**
 * Validates a set of preference changes.
 *
 * Returns problems rather than silently correcting them. A user who switches off
 * security notifications and gets no complaint, then keeps receiving them, has
 * been lied to twice.
 */
export function checkPreferenceUpdates(
  updates: readonly PreferenceUpdate[],
): readonly PreferenceProblem[] {
  const problems: PreferenceProblem[] = [];
  for (const update of updates) {
    if (!isNotificationKind(update.kind)) {
      problems.push({ kind: update.kind, message: 'That is not a notification SeSha sends.' });
      continue;
    }
    if (isAlwaysOn(update.kind) && update.inApp === false) {
      problems.push({ kind: update.kind, message: ALWAYS_ON[update.kind]! });
    }
    if (update.email === true && !CHANNELS.email.available) {
      problems.push({
        kind: update.kind,
        message: CHANNELS.email.unavailableReason ?? 'That channel is not available.',
      });
    }
  }
  return problems;
}

/* -------------------------------------------------------------------------- */
/* The gate                                                                   */
/* -------------------------------------------------------------------------- */

export type NotifyDecision =
  | { readonly send: true; readonly channels: readonly ChannelId[] }
  | { readonly send: false; readonly reason: string };

/**
 * The ONLY route from an event to a user.
 *
 * Nothing in SeSha writes a notification row without going through here. That
 * is what makes "users control their notifications" a property of the system
 * rather than a promise on a settings page.
 */
export function shouldNotify(
  kind: NotificationKind,
  preferences: readonly NotificationPreference[],
): NotifyDecision {
  if (isAlwaysOn(kind)) return { send: true, channels: ['in_app'] };

  const preference = preferences.find((candidate) => candidate.kind === kind) ?? defaultPreference(kind);
  const channels: ChannelId[] = [];
  if (preference.inApp) channels.push('in_app');
  if (preference.email && CHANNELS.email.available) channels.push('email');

  if (channels.length === 0) {
    return { send: false, reason: `You have switched off "${NOTIFICATION_LABEL[kind]}".` };
  }
  return { send: true, channels };
}

/* -------------------------------------------------------------------------- */
/* Composing                                                                  */
/* -------------------------------------------------------------------------- */

export interface NotificationDraft {
  readonly kind: NotificationKind;
  readonly title: string;
  readonly body: string;
  readonly actionUrl?: string;
}

/**
 * The kind as the existing `notifications` table records it.
 *
 * Migration 0006 widens the CHECK constraint to the full list, so this is the
 * identity function — it exists so that a future narrowing has one place to
 * change rather than eleven call sites, and so the mapping is testable.
 */
export function storedKind(kind: NotificationKind): NotificationKind {
  return kind;
}

/** Truncates a title to what the notification list can show without clipping. */
export function notificationTitle(text: string): string {
  const trimmed = text.trim().replace(/\s+/g, ' ');
  return trimmed.length <= 120 ? trimmed : `${trimmed.slice(0, 117)}...`;
}
