/**
 * Notification service.
 *
 * ONE DOOR
 * `send()` is the only function in SeSha that writes a notification row, and
 * it goes through `shouldNotify()` every time. Nothing can decide its own
 * message is important enough to bypass a user's settings — which is what makes
 * *"users must control notification preferences"* a property of the system
 * rather than a claim on a settings page.
 *
 * WHO GETS TOLD
 * A notification is per user, so "notify the organization" means resolving the
 * members and asking each of their preferences separately. Broadcasting to
 * everyone and filtering in the UI would write rows for people who switched the
 * kind off — the preference would appear to work while being ignored.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { assertTenant, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { NotificationRow } from '@/lib/db/types';

import {
  ALWAYS_ON,
  CHANNELS,
  NOTIFICATION_DESCRIPTION,
  NOTIFICATION_KINDS,
  NOTIFICATION_LABEL,
  checkPreferenceUpdates,
  isAlwaysOn,
  isNotificationKind,
  notificationTitle,
  resolvePreferences,
  shouldNotify,
  type NotificationDraft,
  type NotificationKind,
  type NotificationPreference,
  type PreferenceUpdate,
} from './types';

export interface NotificationServiceContext {
  readonly db: Database;
  readonly now?: () => Date;
}

function clock(context: NotificationServiceContext): Date {
  return context.now?.() ?? new Date();
}

export class NotificationInputError extends Error {
  readonly code = 'INVALID_INPUT' as const;
  readonly problems: readonly { readonly kind: string; readonly message: string }[];
  constructor(message: string, problems: readonly { readonly kind: string; readonly message: string }[] = []) {
    super(message);
    this.name = 'NotificationInputError';
    this.problems = problems;
  }
}

/* -------------------------------------------------------------------------- */
/* Preferences                                                                */
/* -------------------------------------------------------------------------- */

export interface PreferenceView {
  readonly preference: NotificationPreference;
  readonly label: string;
  readonly description: string;
  /** Set when the user may not switch this off. Shown, not merely enforced. */
  readonly lockedReason?: string;
}

export async function preferencesFor(
  context: NotificationServiceContext,
  tenant: TenantContext,
  userId?: string,
): Promise<readonly NotificationPreference[]> {
  const target = userId ?? tenant.userId;
  if (target !== tenant.userId) {
    // Someone else's notification settings are theirs. Even an owner does not
    // get to read or change them: they are a personal setting, not a tenant one.
    throw new NotificationInputError('You can only read your own notification settings.');
  }
  const rows = await context.db.notificationPreferences.listForUser(tenant.organizationId, target);
  return resolvePreferences(rows.map((row) => ({ kind: row.kind, inApp: row.inApp, email: row.email })));
}

export async function updatePreferences(
  context: NotificationServiceContext,
  tenant: TenantContext,
  updates: readonly PreferenceUpdate[],
): Promise<readonly NotificationPreference[]> {
  const problems = checkPreferenceUpdates(updates);
  if (problems.length > 0) {
    throw new NotificationInputError('Those settings cannot be saved.', problems);
  }

  const at = clock(context);
  for (const update of updates) {
    if (!isNotificationKind(update.kind)) continue;
    await context.db.notificationPreferences.set(
      tenant.organizationId,
      tenant.userId,
      update.kind,
      {
        ...(update.inApp === undefined ? {} : { inApp: update.inApp }),
        ...(update.email === undefined ? {} : { email: update.email }),
      },
      at,
    );
  }

  return preferencesFor(context, tenant);
}

/** Everything the settings screen needs, including why two rows are locked. */
export async function preferenceView(
  context: NotificationServiceContext,
  tenant: TenantContext,
): Promise<readonly PreferenceView[]> {
  const preferences = await preferencesFor(context, tenant);
  return NOTIFICATION_KINDS.map((kind) => {
    const preference = preferences.find((candidate) => candidate.kind === kind) ?? {
      kind,
      inApp: true,
      email: false,
    };
    const locked = ALWAYS_ON[kind];
    return {
      preference,
      label: NOTIFICATION_LABEL[kind],
      description: NOTIFICATION_DESCRIPTION[kind],
      ...(locked ? { lockedReason: locked } : {}),
    };
  });
}

/* -------------------------------------------------------------------------- */
/* Sending                                                                    */
/* -------------------------------------------------------------------------- */

export interface SendResult {
  readonly sent: boolean;
  readonly reason?: string;
  readonly row?: NotificationRow;
}

/**
 * The only route from an event to one user.
 *
 * Email is never attempted: `shouldNotify` cannot return it while no provider is
 * connected, and there is deliberately no branch here that would try.
 */
export async function send(
  context: NotificationServiceContext,
  organizationId: string,
  userId: string,
  draft: NotificationDraft,
  projectId?: string,
): Promise<SendResult> {
  if (!isNotificationKind(draft.kind)) {
    return { sent: false, reason: 'That is not a notification SeSha sends.' };
  }

  const rows = await context.db.notificationPreferences.listForUser(organizationId, userId);
  const preferences = resolvePreferences(
    rows.map((row) => ({ kind: row.kind, inApp: row.inApp, email: row.email })),
  );
  const decision = shouldNotify(draft.kind, preferences);
  if (!decision.send) return { sent: false, reason: decision.reason };

  const row = await context.db.notifications.create({
    organizationId,
    userId,
    projectId: projectId ?? null,
    kind: draft.kind,
    title: notificationTitle(draft.title),
    body: draft.body,
    actionUrl: draft.actionUrl ?? null,
  });

  return { sent: true, row };
}

/**
 * Sends to every member of an organization, each according to their own
 * preferences.
 *
 * Returns one result per member, including the ones who were not notified —
 * so a caller can report "3 of 5 people have this switched off" rather than
 * silently reaching fewer people than it thinks.
 */
export async function broadcast(
  context: NotificationServiceContext,
  organizationId: string,
  draft: NotificationDraft,
  projectId?: string,
): Promise<readonly { readonly userId: string; readonly result: SendResult }[]> {
  const members = await context.db.memberships.listForOrganization(organizationId);
  const results: { userId: string; result: SendResult }[] = [];
  for (const member of members) {
    results.push({
      userId: member.userId,
      result: await send(context, organizationId, member.userId, draft, projectId),
    });
  }
  return results;
}

/* -------------------------------------------------------------------------- */
/* Reading                                                                    */
/* -------------------------------------------------------------------------- */

export async function listForUser(
  context: NotificationServiceContext,
  tenant: TenantContext,
  limit = 50,
): Promise<readonly NotificationRow[]> {
  requirePermission(tenant.role, 'project:read');
  return context.db.notifications.listForUser(tenant.organizationId, tenant.userId, limit);
}

export async function unreadCount(
  context: NotificationServiceContext,
  tenant: TenantContext,
): Promise<number> {
  return context.db.notifications.countUnread(tenant.organizationId, tenant.userId);
}

export async function markRead(
  context: NotificationServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<void> {
  const rows = await context.db.notifications.listForUser(tenant.organizationId, tenant.userId, 500);
  const own = rows.find((row) => row.id === id) ?? null;
  // Scoped to the caller's own rows: a notification belonging to a colleague is
  // reported as not found rather than as forbidden, for the same reason every
  // cross-tenant read is.
  assertTenant(tenant, own, 'Notification');
  await context.db.notifications.markRead(tenant.organizationId, id, clock(context));
}

/** Whether a kind can be switched off, for the interface. */
export function isLocked(kind: NotificationKind): boolean {
  return isAlwaysOn(kind);
}

/** Whether email could be used at all. False while no provider is connected. */
export function emailAvailable(): boolean {
  return CHANNELS.email.available;
}
