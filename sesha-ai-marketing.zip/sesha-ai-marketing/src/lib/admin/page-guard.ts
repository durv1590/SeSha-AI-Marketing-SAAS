/**
 * The admin page guard — the server-component counterpart to `requireStaff`.
 *
 * WHY A SEPARATE FUNCTION AND NOT A SHARED ONE. `requireStaff` takes a `Request`
 * so it can enforce CSRF on unsafe methods; a page render has no unsafe method
 * and no body, so there is nothing to protect against there. Trying to share one
 * function would mean either passing a fake Request or making the CSRF step
 * optional — and an optional CSRF check is a CSRF check that will one day be off
 * on a route that needed it.
 *
 * WHAT BOTH DO IDENTICALLY, AND MUST: resolve staff from `platform_staff` on
 * every render, and give a non-staff visitor a 404. `notFound()` renders the
 * same not-found page as a mistyped URL, so /admin is indistinguishable from a
 * route that was never built.
 */

import { notFound } from 'next/navigation';

import { getCurrentSession } from '@/lib/auth/current-session';
import { isSudo } from '@/lib/auth/session';
import { getDatabase } from '@/lib/db';

import { checkAdminAccess, type AdminPermission, type StaffContext } from './auth';
import { staffFor } from './service';

export interface AdminPageContext {
  readonly staff: StaffContext;
}

/**
 * Requires platform staff holding `permission`, or renders not-found.
 *
 * A sudo refusal is NOT a 404 here — the visitor is already established as
 * staff, so the page can say "confirm your password" instead of pretending to
 * vanish. The caller receives the refusal by exception only for a real denial;
 * for sudo it gets the context back with `sudo: false` and decides what to show,
 * because a read screen should still render while a form on it is locked.
 */
export async function requireStaffPage(permission: AdminPermission): Promise<AdminPageContext> {
  const session = await getCurrentSession();
  if (!session) notFound();

  const staff = await staffFor(
    { db: getDatabase() },
    { id: session.user.id, email: session.user.email },
    {
      id: session.session.id,
      sudo: isSudo(session.session, Date.now()),
      ipHash: null,
    },
  );

  if (!staff) notFound();

  const access = checkAdminAccess(staff, permission);
  // `needsSudo` means the ROLE is sufficient and only the recency of the sign-in
  // is not. That is not a reason to hide the screen.
  if (!access.ok && !access.needsSudo) notFound();

  return { staff };
}
