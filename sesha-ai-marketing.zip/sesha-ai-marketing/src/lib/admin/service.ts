/**
 * The admin service.
 *
 * EVERY FUNCTION HERE DOES THREE THINGS IN THE SAME ORDER: check the permission,
 * do the work, record the action. There is no path that skips the third step,
 * and reads are recorded as well as writes — "who looked at which customer" is
 * the question an audit log exists to answer, and a log of writes only cannot
 * answer it.
 *
 * `withAudit()` is the wrapper that guarantees it. A function that recorded its
 * own action at the end would silently record nothing when it threw, which is
 * precisely when you want to know what was attempted — so the record is written
 * in a `finally` with the outcome, including `denied`.
 *
 * WHAT THIS SERVICE CANNOT REACH
 * `db.adminRead` has no method that returns customer content. Support can see
 * that an organization exists, what plan it is on, how much it has used and
 * whether its jobs are failing. It cannot read a lead's email address, an
 * article, a report body or a message. That is a deliberate ceiling: a panel
 * that showed staff every customer's content would be a privacy incident with a
 * dashboard, and "we only look when we need to" is not a control.
 */

import type { Database } from '@/lib/db/repositories';
import type {
  AdminActionRow,
  ErrorEventRow,
  FeedbackRow,
  JobRow,
  OrganizationRow,
  PlatformStaffRow,
  SubscriptionRow,
} from '@/lib/db/types';
import { LIMIT_IDS, PLANS, isPlanId, type LimitId, type PlanId } from '@/content/plans';
import { clampLimit, effectiveLimits } from '@/lib/plans/resolve';
import { overridesFor } from '@/lib/plans/service';
import { limitStatus } from '@/lib/quota';
import { periodStartOf } from '@/lib/usage/metrics';
import { usageSnapshot } from '@/lib/usage/service';
import { FLAG_DEFINITIONS, checkRule, isFlagKey, type FlagRule } from '@/lib/flags';
import { authSecretIsConfigured } from '@/lib/auth/session';
import { availability } from '@/lib/flags/service';
import { isSubscriptionStatus } from '@/lib/billing/types';
// The key variables are read in ONE module (lib/ai/provider.ts) so there is one
// place to audit. `tests/ai-security.test.ts` enforces that, and it caught this
// health check reading them directly.
import { aiIsEnabled, configuredProviders } from '@/lib/ai/provider';

import {
  AdminAuthorizationError,
  requireAdmin,
  staffRoleFrom,
  type AdminPermission,
  type StaffContext,
  type StaffRole,
} from './auth';
import { check as checkSetting, resolveSetting, SETTING_DEFINITIONS, isSettingKey } from './settings';

export interface AdminServiceContext {
  readonly db: Database;
  readonly now?: () => Date;
}

function clock(context: AdminServiceContext): Date {
  return context.now?.() ?? new Date();
}

/* -------------------------------------------------------------------------- */
/* Resolving staff                                                            */
/* -------------------------------------------------------------------------- */

/**
 * Whether this user is staff, read fresh from the database.
 *
 * Never cached and never taken from the session: revoking access must take
 * effect on the next request, not when a thirty-day session happens to expire.
 */
export async function staffFor(
  context: AdminServiceContext,
  user: { readonly id: string; readonly email: string },
  session: { readonly id: string; readonly sudo: boolean; readonly ipHash: string | null },
): Promise<StaffContext | null> {
  const row = await context.db.platformStaff.findByUser(user.id);
  const role = staffRoleFrom(row);
  if (!role) return null;
  return {
    userId: user.id,
    email: user.email,
    role,
    sudo: session.sudo,
    sessionId: session.id,
    ipHash: session.ipHash,
  };
}

/* -------------------------------------------------------------------------- */
/* The audit wrapper                                                          */
/* -------------------------------------------------------------------------- */

interface AuditSpec {
  readonly permission: AdminPermission;
  readonly action: string;
  readonly kind: 'read' | 'write';
  readonly targetType: string;
  readonly targetId?: string | null;
  readonly targetOrganizationId?: string | null;
  readonly metadata?: Readonly<Record<string, unknown>>;
}

/**
 * Checks the permission, runs the work, records the action.
 *
 * The record is written in a `finally`, with the real outcome, so a refusal and
 * a failure are both logged. A wrapper that only recorded success would hide
 * exactly the events worth auditing.
 */
async function withAudit<T>(
  context: AdminServiceContext,
  staff: StaffContext | null,
  spec: AuditSpec,
  work: (staff: StaffContext) => Promise<T>,
): Promise<T> {
  let outcome: AdminActionRow['outcome'] = 'success';
  try {
    const allowed = requireAdmin(staff, spec.permission);
    return await work(allowed);
  } catch (error) {
    outcome = error instanceof AdminAuthorizationError ? 'denied' : 'failure';
    throw error;
  } finally {
    try {
      await context.db.adminActions.record({
        staffUserId: staff?.userId ?? null,
        staffRole: staff?.role ?? 'none',
        permission: spec.permission,
        action: spec.action,
        kind: spec.kind,
        targetType: spec.targetType,
        targetId: spec.targetId ?? null,
        targetOrganizationId: spec.targetOrganizationId ?? null,
        metadata: spec.metadata ?? {},
        outcome,
        sessionId: staff?.sessionId ?? null,
        ipHash: staff?.ipHash ?? null,
      });
    } catch {
      // An audit write failure must not swallow the real result or the real
      // error. Logged by the error recorder in the route layer.
    }
  }
}

/* -------------------------------------------------------------------------- */
/* Dashboard                                                                  */
/* -------------------------------------------------------------------------- */

export interface PlatformOverview {
  readonly organizations: number;
  readonly users: number;
  readonly projects: number;
  readonly reports: number;
  readonly activeStaff: number;
  readonly planCounts: Readonly<Record<string, number>>;
  readonly statusCounts: Readonly<Record<string, number>>;
  readonly usageThisPeriod: Readonly<Record<string, number>>;
  readonly jobCounts: Readonly<Record<string, number>>;
  readonly openErrors: number;
  readonly newFeedback: number;
  readonly refusalsLast7Days: Readonly<Record<string, number>>;
}

export async function overview(
  context: AdminServiceContext,
  staff: StaffContext | null,
): Promise<PlatformOverview> {
  return withAudit(
    context,
    staff,
    { permission: 'admin:health:read', action: 'admin.overview', kind: 'read', targetType: 'platform' },
    async () => {
      const now = clock(context);
      const organizations = await context.db.adminRead.listOrganizations({ limit: 1_000 });

      const planCounts: Record<string, number> = {};
      const statusCounts: Record<string, number> = {};
      for (const entry of organizations) {
        planCounts[entry.organization.plan] = (planCounts[entry.organization.plan] ?? 0) + 1;
        const status = entry.subscription?.status ?? 'none';
        statusCounts[status] = (statusCounts[status] ?? 0) + 1;
      }

      return {
        organizations: await context.db.adminRead.countOrganizations(),
        users: await context.db.adminRead.countUsers(),
        projects: await context.db.adminRead.countProjects(),
        reports: await context.db.adminRead.countReports(),
        activeStaff: await context.db.platformStaff.countActive(),
        planCounts,
        statusCounts,
        usageThisPeriod: await context.db.adminRead.usageTotals(periodStartOf(now)),
        jobCounts: await context.db.adminRead.countJobsByStatus(),
        openErrors: (await context.db.errors.listOpen(200)).length,
        newFeedback: (await context.db.feedback.list({ status: 'new', limit: 200 })).length,
        refusalsLast7Days: await context.db.quotaRefusals.countByLimitSince(
          new Date(now.getTime() - 7 * 86_400_000),
        ),
      };
    },
  );
}

/**
 * System health.
 *
 * REPORTS ONLY WHAT IS ACTUALLY KNOWABLE. There is no uptime figure, no latency
 * percentile and no "all systems operational" badge, because this deployment
 * measures none of those and a green tick that means nothing is worse than no
 * tick. What it does report is checkable: which database adapter is live,
 * whether the required secrets are set, how many jobs are stuck, how many
 * errors are open.
 */
export interface HealthReport {
  readonly checks: readonly {
    readonly id: string;
    readonly label: string;
    readonly state: 'ok' | 'warn' | 'fail' | 'unknown';
    readonly detail: string;
  }[];
  readonly notMeasured: readonly string[];
}

export async function health(
  context: AdminServiceContext,
  staff: StaffContext | null,
): Promise<HealthReport> {
  return withAudit(
    context,
    staff,
    { permission: 'admin:health:read', action: 'admin.health', kind: 'read', targetType: 'platform' },
    async () => {
      const now = clock(context);
      const jobCounts = await context.db.adminRead.countJobsByStatus();
      const failed = jobCounts.failed ?? 0;
      const running = jobCounts.running ?? 0;
      const errorsSince = await context.db.errors.countSince(new Date(now.getTime() - 86_400_000));

      const checks: HealthReport['checks'] = [
        {
          id: 'database',
          label: 'Database adapter',
          state: process.env.DATABASE_URL ? 'ok' : 'warn',
          detail: process.env.DATABASE_URL
            ? 'PostgreSQL.'
            : 'In-memory adapter. State is lost on restart and is not shared between instances. Correct for development, never for production.',
        },
        {
          id: 'auth_secret',
          label: 'AUTH_SECRET',
          // Asked as a question, not read as a value: `authSecretIsConfigured()`
          // returns a boolean and lives in lib/auth, which is the only place
          // that touches the secret itself.
          state: authSecretIsConfigured() ? 'ok' : 'fail',
          detail: authSecretIsConfigured()
            ? 'Set, and long enough.'
            : 'Missing or shorter than 32 bytes. The application refuses to start in production without it.',
        },
        {
          id: 'email',
          label: 'Email delivery',
          state: process.env.SMTP_URL ? 'ok' : 'warn',
          detail: process.env.SMTP_URL
            ? 'Configured.'
            : 'No provider. Verification and reset links are logged, not sent — customers cannot verify an address.',
        },
        {
          id: 'ai_providers',
          label: 'AI providers',
          state: aiIsEnabled() ? 'ok' : 'warn',
          detail: aiIsEnabled()
            ? `Configured: ${configuredProviders().map((provider) => provider.name).join(', ')}.`
            : 'No provider key is set, so AI generation is unavailable. The copilot reports this rather than failing silently.',
        },
        {
          id: 'jobs',
          label: 'Background jobs',
          state: failed > 0 ? 'warn' : 'ok',
          detail: `${running} running, ${failed} failed.`,
        },
        {
          id: 'errors',
          label: 'Errors in the last 24 hours',
          state: errorsSince > 100 ? 'warn' : 'ok',
          detail: `${errorsSince} recorded occurrences across ${(await context.db.errors.listOpen(500)).length} open problems.`,
        },
      ];

      return {
        checks,
        notMeasured: [
          'Uptime — this deployment records no availability history, so any figure would be invented.',
          'Response latency — not instrumented.',
          'Queue depth over time — jobs are counted now, not sampled.',
          'Provider latency and error rates — not recorded per provider.',
        ],
      };
    },
  );
}

/* -------------------------------------------------------------------------- */
/* Accounts                                                                   */
/* -------------------------------------------------------------------------- */

export interface OrganizationSummary {
  readonly organization: OrganizationRow;
  readonly subscription: SubscriptionRow | null;
  readonly memberCount: number;
  readonly projectCount: number;
}

export async function listOrganizations(
  context: AdminServiceContext,
  staff: StaffContext | null,
  filter: { readonly plan?: string; readonly status?: string; readonly query?: string } = {},
): Promise<readonly OrganizationSummary[]> {
  return withAudit(
    context,
    staff,
    {
      permission: 'admin:businesses:read',
      action: 'admin.organizations.list',
      kind: 'read',
      targetType: 'organization',
      // The SEARCH TERM is recorded, not the results. Someone fishing for a
      // named customer leaves a trace.
      metadata: { ...(filter.query ? { query: filter.query } : {}), ...(filter.plan ? { plan: filter.plan } : {}) },
    },
    async () =>
      context.db.adminRead.listOrganizations({
        ...(filter.plan && isPlanId(filter.plan) ? { plan: filter.plan } : {}),
        ...(filter.status && isSubscriptionStatus(filter.status) ? { status: filter.status } : {}),
        ...(filter.query ? { query: filter.query } : {}),
        limit: 100,
      }),
  );
}

export interface OrganizationDetail {
  readonly organization: OrganizationRow;
  readonly subscription: SubscriptionRow | null;
  readonly plan: PlanId;
  readonly members: readonly { readonly email: string; readonly name: string | null; readonly role: string }[];
  readonly projects: readonly { readonly id: string; readonly name: string; readonly status: string }[];
  readonly businesses: readonly { readonly id: string; readonly name: string }[];
  readonly limits: readonly {
    readonly limitId: LimitId;
    readonly label: string;
    readonly value: number | null;
    readonly used: number;
    readonly source: 'plan' | 'override';
    readonly overrideReason?: string;
  }[];
  readonly billingHistory: readonly { readonly event: string; readonly applied: boolean; readonly occurredAt: string }[];
  readonly recentRefusals: readonly { readonly limitId: string; readonly reason: string; readonly refusedAt: string }[];
}

export async function organizationDetail(
  context: AdminServiceContext,
  staff: StaffContext | null,
  organizationId: string,
): Promise<OrganizationDetail | null> {
  return withAudit(
    context,
    staff,
    {
      permission: 'admin:businesses:read',
      action: 'admin.organization.read',
      kind: 'read',
      targetType: 'organization',
      targetId: organizationId,
      targetOrganizationId: organizationId,
    },
    async () => {
      const found = await context.db.adminRead.findOrganization(organizationId);
      if (!found) return null;

      const plan = (isPlanId(found.organization.plan) ? found.organization.plan : 'free') as PlanId;
      const overrides = await overridesFor(context, organizationId);
      const limits = effectiveLimits(plan, overrides);
      const statuses = await usageSnapshot(
        context,
        organizationId,
        limits,
        periodStartOf(clock(context)),
      );
      const events = await context.db.billingEvents.listForOrganization(organizationId, 20);
      const refusals = await context.db.quotaRefusals.listForOrganization(organizationId, 20);

      return {
        organization: found.organization,
        subscription: found.subscription,
        plan,
        // Email and name only. A support engineer needs to identify the person
        // who raised a ticket; nothing here reaches the customer's own content.
        members: found.members.map((member) => ({
          email: member.user.email,
          name: member.user.name,
          role: member.role,
        })),
        projects: found.projects.map((project) => ({
          id: project.id,
          name: project.name,
          status: project.status,
        })),
        businesses: found.businesses.map((business) => ({ id: business.id, name: business.name })),
        limits: statuses.map((status) => ({
          limitId: status.limit.id,
          label: status.limit.label,
          value: status.limit.value,
          used: status.used,
          source: status.limit.source,
          ...(status.limit.override ? { overrideReason: status.limit.override.reason } : {}),
        })),
        billingHistory: events.map((row) => ({
          event: row.event,
          applied: row.applied,
          occurredAt: row.occurredAt.toISOString(),
        })),
        recentRefusals: refusals.map((row) => ({
          limitId: row.limitId,
          reason: row.reason,
          refusedAt: row.refusedAt.toISOString(),
        })),
      };
    },
  );
}

/* -------------------------------------------------------------------------- */
/* Controls: plans and limits                                                 */
/* -------------------------------------------------------------------------- */

export async function setLimitOverride(
  context: AdminServiceContext,
  staff: StaffContext | null,
  organizationId: string,
  limitId: LimitId,
  value: number | null,
  reason: string,
): Promise<void> {
  await withAudit(
    context,
    staff,
    {
      permission: 'admin:limits:write',
      action: 'admin.limit.set',
      kind: 'write',
      targetType: 'plan_limit',
      targetId: limitId,
      targetOrganizationId: organizationId,
      metadata: { limitId, value, reason },
    },
    async (allowed) => {
      if (!(LIMIT_IDS as readonly string[]).includes(limitId)) {
        throw new Error(`"${limitId}" is not a limit this product has.`);
      }
      const clamped = clampLimit(value);
      if (clamped === undefined) {
        throw new Error('A limit is a whole number of zero or more, or unlimited.');
      }
      if (reason.trim().length === 0) {
        throw new Error(
          'Say why. An override nobody can explain is an override nobody dares remove.',
        );
      }
      await context.db.planLimits.set(
        organizationId,
        limitId,
        clamped,
        reason.trim(),
        allowed.userId,
        clock(context),
      );
    },
  );
}

export async function clearLimitOverride(
  context: AdminServiceContext,
  staff: StaffContext | null,
  organizationId: string,
  limitId: LimitId,
): Promise<void> {
  await withAudit(
    context,
    staff,
    {
      permission: 'admin:limits:write',
      action: 'admin.limit.clear',
      kind: 'write',
      targetType: 'plan_limit',
      targetId: limitId,
      targetOrganizationId: organizationId,
    },
    async () => {
      await context.db.planLimits.clear(organizationId, limitId);
    },
  );
}

/**
 * Changes an organization's plan from the admin panel.
 *
 * Deliberately does NOT touch the payment provider. This is the support action
 * for "we agreed to move this customer" and for correcting a mistake, and making
 * it also charge someone would be a surprise. The billing consequence is a
 * separate, deliberate step at the provider.
 */
export async function setPlan(
  context: AdminServiceContext,
  staff: StaffContext | null,
  organizationId: string,
  plan: PlanId,
  reason: string,
): Promise<void> {
  await withAudit(
    context,
    staff,
    {
      permission: 'admin:subscriptions:write',
      action: 'admin.plan.set',
      kind: 'write',
      targetType: 'subscription',
      targetId: organizationId,
      targetOrganizationId: organizationId,
      metadata: { plan, reason },
    },
    async () => {
      if (!isPlanId(plan)) throw new Error('That is not a plan SeSha offers.');
      if (reason.trim().length === 0) throw new Error('Say why this plan is being changed.');
      await context.db.subscriptions.update(organizationId, { plan });
      await context.db.billingEvents.record({
        organizationId,
        externalEventId: null,
        provider: 'admin',
        event: 'plan_changed',
        statusBefore: null,
        statusAfter: null,
        planBefore: null,
        planAfter: plan,
        applied: true,
        note: `Changed by platform staff: ${reason.trim()}`,
        payloadSummary: {},
        occurredAt: clock(context),
      });
    },
  );
}

/* -------------------------------------------------------------------------- */
/* Controls: feature flags                                                    */
/* -------------------------------------------------------------------------- */

export interface FlagAdminView {
  readonly key: string;
  readonly label: string;
  readonly description: string;
  readonly category: string;
  readonly defaultValue: boolean;
  readonly rule: FlagRule | null;
  readonly available: boolean;
  readonly unavailableReason?: string;
}

export async function listFlags(
  context: AdminServiceContext,
  staff: StaffContext | null,
): Promise<readonly FlagAdminView[]> {
  return withAudit(
    context,
    staff,
    { permission: 'admin:health:read', action: 'admin.flags.list', kind: 'read', targetType: 'feature_flag' },
    async () => {
      const rows = await context.db.featureFlags.list();
      const state = availability();
      return FLAG_DEFINITIONS.map((definition) => {
        const row = rows.find((candidate) => candidate.key === definition.key);
        const reachable = state.find((entry) => entry.key === definition.key);
        return {
          key: definition.key,
          label: definition.label,
          description: definition.description,
          category: definition.category,
          defaultValue: definition.defaultValue,
          rule: row
            ? {
                key: row.key,
                disabled: row.disabled,
                organizationIds: row.organizationIds,
                excludedOrganizationIds: row.excludedOrganizationIds,
                plans: row.plans as readonly PlanId[],
                rolloutPercent: row.rolloutPercent,
                updatedBy: row.updatedBy,
                updatedAt: row.updatedAt.toISOString(),
              }
            : null,
          available: reachable?.available ?? true,
          ...(reachable?.reason ? { unavailableReason: reachable.reason } : {}),
        };
      });
    },
  );
}

export async function setFlagRule(
  context: AdminServiceContext,
  staff: StaffContext | null,
  input: {
    readonly key: string;
    readonly disabled?: boolean;
    readonly organizationIds?: readonly string[];
    readonly excludedOrganizationIds?: readonly string[];
    readonly plans?: readonly string[];
    readonly rolloutPercent?: number;
  },
): Promise<void> {
  await withAudit(
    context,
    staff,
    {
      permission: 'admin:flags:write',
      action: 'admin.flag.set',
      kind: 'write',
      targetType: 'feature_flag',
      targetId: input.key,
      metadata: { ...input },
    },
    async (allowed) => {
      if (!isFlagKey(input.key)) {
        throw new Error(`"${input.key}" is not a flag this product declares.`);
      }
      const plans = (input.plans ?? []).filter((plan): plan is PlanId => isPlanId(plan));
      const problems = checkRule({
        key: input.key,
        plans,
        ...(input.rolloutPercent === undefined ? {} : { rolloutPercent: input.rolloutPercent }),
        organizationIds: input.organizationIds ?? [],
        excludedOrganizationIds: input.excludedOrganizationIds ?? [],
      });
      if (problems.length > 0) throw new Error(problems.join(' '));

      await context.db.featureFlags.upsert({
        key: input.key,
        disabled: input.disabled ?? false,
        organizationIds: input.organizationIds ?? [],
        excludedOrganizationIds: input.excludedOrganizationIds ?? [],
        plans,
        rolloutPercent: input.rolloutPercent ?? 0,
        updatedBy: allowed.userId,
        updatedAt: clock(context),
      });
    },
  );
}

/* -------------------------------------------------------------------------- */
/* Controls: system settings                                                  */
/* -------------------------------------------------------------------------- */

export interface SettingView {
  readonly key: string;
  readonly group: string;
  readonly label: string;
  readonly description: string;
  readonly shape: string;
  readonly value: unknown;
  readonly isDefault: boolean;
  readonly updatedAt: string | null;
}

export async function listSettings(
  context: AdminServiceContext,
  staff: StaffContext | null,
): Promise<readonly SettingView[]> {
  return withAudit(
    context,
    staff,
    { permission: 'admin:health:read', action: 'admin.settings.list', kind: 'read', targetType: 'system_setting' },
    async () => {
      const rows = await context.db.systemSettings.list();
      return SETTING_DEFINITIONS.map((definition) => {
        const row = rows.find((candidate) => candidate.key === definition.key);
        return {
          key: definition.key,
          group: definition.group,
          label: definition.label,
          description: definition.description,
          shape: definition.shape,
          value: resolveSetting(definition.key, row?.value),
          isDefault: row === undefined,
          updatedAt: row?.updatedAt.toISOString() ?? null,
        };
      });
    },
  );
}

export async function setSetting(
  context: AdminServiceContext,
  staff: StaffContext | null,
  key: string,
  value: unknown,
): Promise<void> {
  await withAudit(
    context,
    staff,
    {
      // Every configuration control maps to its own permission so the audit log
      // says which surface was touched, not just "a setting changed".
      permission: permissionForSetting(key),
      action: 'admin.setting.set',
      kind: 'write',
      targetType: 'system_setting',
      targetId: key,
      metadata: { key, value },
    },
    async (allowed) => {
      if (!isSettingKey(key)) throw new Error(`"${key}" is not a setting this product declares.`);
      const checked = checkSetting(key, value);
      if (!checked.ok) throw new Error(checked.message);
      await context.db.systemSettings.set(key, checked.value, allowed.userId, clock(context));
    },
  );
}

function permissionForSetting(key: string): AdminPermission {
  const definition = SETTING_DEFINITIONS.find((candidate) => candidate.key === key);
  switch (definition?.group) {
    case 'prompts':
      return 'admin:prompts:write';
    case 'templates':
      return 'admin:templates:write';
    case 'validator':
      return 'admin:validator:write';
    default:
      return 'admin:system:write';
  }
}

/** A setting's value for the rest of the product. No permission needed. */
export async function settingValue(
  context: AdminServiceContext,
  key: string,
): Promise<unknown> {
  if (!isSettingKey(key)) return undefined;
  try {
    const row = await context.db.systemSettings.get(key);
    return resolveSetting(key, row?.value);
  } catch {
    // The declared default, not an exception. A settings read failure must not
    // take down the screen that was only asking for a banner string.
    return resolveSetting(key, undefined);
  }
}

/* -------------------------------------------------------------------------- */
/* Operational surfaces                                                       */
/* -------------------------------------------------------------------------- */

export async function listJobs(
  context: AdminServiceContext,
  staff: StaffContext | null,
  filter: { readonly kind?: string; readonly status?: string } = {},
): Promise<readonly JobRow[]> {
  return withAudit(
    context,
    staff,
    { permission: 'admin:jobs:read', action: 'admin.jobs.list', kind: 'read', targetType: 'job', metadata: { ...filter } },
    async () => context.db.adminRead.listJobs({ ...filter, limit: 100 }),
  );
}

export async function listErrors(
  context: AdminServiceContext,
  staff: StaffContext | null,
): Promise<readonly ErrorEventRow[]> {
  return withAudit(
    context,
    staff,
    { permission: 'admin:errors:read', action: 'admin.errors.list', kind: 'read', targetType: 'error_event' },
    async () => context.db.errors.listOpen(100),
  );
}

export async function resolveError(
  context: AdminServiceContext,
  staff: StaffContext | null,
  fingerprint: string,
): Promise<void> {
  await withAudit(
    context,
    staff,
    {
      permission: 'admin:system:write',
      action: 'admin.error.resolve',
      kind: 'write',
      targetType: 'error_event',
      targetId: fingerprint,
    },
    async (allowed) => {
      await context.db.errors.resolve(fingerprint, allowed.userId, clock(context));
    },
  );
}

export async function listFeedback(
  context: AdminServiceContext,
  staff: StaffContext | null,
  status?: FeedbackRow['status'],
): Promise<readonly FeedbackRow[]> {
  return withAudit(
    context,
    staff,
    { permission: 'admin:feedback:read', action: 'admin.feedback.list', kind: 'read', targetType: 'feedback' },
    async () => context.db.feedback.list({ ...(status ? { status } : {}), limit: 100 }),
  );
}

export async function setFeedbackStatus(
  context: AdminServiceContext,
  staff: StaffContext | null,
  id: string,
  status: FeedbackRow['status'],
): Promise<void> {
  await withAudit(
    context,
    staff,
    {
      permission: 'admin:feedback:write',
      action: 'admin.feedback.status',
      kind: 'write',
      targetType: 'feedback',
      targetId: id,
      metadata: { status },
    },
    async (allowed) => {
      await context.db.feedback.setStatus(id, status, allowed.userId, clock(context));
    },
  );
}

export async function listSecurityEvents(
  context: AdminServiceContext,
  staff: StaffContext | null,
): Promise<readonly { readonly action: string; readonly outcome: string; readonly createdAt: string; readonly organizationId: string | null }[]> {
  return withAudit(
    context,
    staff,
    { permission: 'admin:security:read', action: 'admin.security.list', kind: 'read', targetType: 'audit_log' },
    async () => {
      const rows = await context.db.adminRead.listSecurityEvents(100);
      return rows.map((row) => ({
        action: row.action,
        outcome: row.outcome,
        createdAt: row.createdAt.toISOString(),
        organizationId: row.organizationId,
      }));
    },
  );
}

export async function listAdminActions(
  context: AdminServiceContext,
  staff: StaffContext | null,
  filter: { readonly kind?: 'read' | 'write'; readonly targetOrganizationId?: string } = {},
): Promise<readonly AdminActionRow[]> {
  return withAudit(
    context,
    staff,
    { permission: 'admin:audit:read', action: 'admin.audit.list', kind: 'read', targetType: 'admin_action', metadata: { ...filter } },
    async () => context.db.adminActions.list({ ...filter, limit: 200 }),
  );
}

/* -------------------------------------------------------------------------- */
/* Staff management                                                           */
/* -------------------------------------------------------------------------- */

export async function listStaff(
  context: AdminServiceContext,
  staff: StaffContext | null,
): Promise<readonly PlatformStaffRow[]> {
  return withAudit(
    context,
    staff,
    { permission: 'admin:staff:read', action: 'admin.staff.list', kind: 'read', targetType: 'platform_staff' },
    async () => context.db.platformStaff.list(true),
  );
}

export async function grantStaff(
  context: AdminServiceContext,
  staff: StaffContext | null,
  userId: string,
  role: StaffRole,
  reason: string,
): Promise<void> {
  await withAudit(
    context,
    staff,
    {
      permission: 'admin:staff:write',
      action: 'admin.staff.grant',
      kind: 'write',
      targetType: 'platform_staff',
      targetId: userId,
      metadata: { role, reason },
    },
    async (allowed) => {
      if (reason.trim().length === 0) {
        throw new Error(
          'Say why. An unexplained staff row is the one nobody removes when someone changes team.',
        );
      }
      const user = await context.db.users.findById(userId);
      if (!user) throw new Error('No such user.');
      await context.db.platformStaff.grant({
        userId,
        role,
        grantedBy: allowed.userId,
        reason: reason.trim(),
        at: clock(context),
      });
    },
  );
}

export async function revokeStaff(
  context: AdminServiceContext,
  staff: StaffContext | null,
  userId: string,
): Promise<void> {
  await withAudit(
    context,
    staff,
    {
      permission: 'admin:staff:write',
      action: 'admin.staff.revoke',
      kind: 'write',
      targetType: 'platform_staff',
      targetId: userId,
    },
    async (allowed) => {
      // The last platform owner cannot revoke themselves. An organization with
      // no owner cannot grant anyone access again, and recovering means editing
      // the database by hand at the worst possible moment.
      const active = await context.db.platformStaff.list(false);
      const owners = active.filter((row) => row.role === 'platform_owner');
      if (owners.length === 1 && owners[0]?.userId === userId) {
        throw new Error(
          'This is the last platform owner. Grant the role to someone else first — with nobody holding it, staff access cannot be restored without direct database access.',
        );
      }
      await context.db.platformStaff.revoke(userId, allowed.userId, clock(context));
    },
  );
}

/* -------------------------------------------------------------------------- */
/* Usage across the platform                                                  */
/* -------------------------------------------------------------------------- */

export async function platformUsage(
  context: AdminServiceContext,
  staff: StaffContext | null,
): Promise<{
  readonly periodStart: string;
  readonly totals: Readonly<Record<string, number>>;
  readonly ai: { readonly requests: number; readonly tokens: number };
  readonly byPlan: readonly { readonly plan: string; readonly organizations: number }[];
}> {
  return withAudit(
    context,
    staff,
    { permission: 'admin:usage:read', action: 'admin.usage.read', kind: 'read', targetType: 'platform' },
    async () => {
      const now = clock(context);
      const periodStart = periodStartOf(now);
      const organizations = await context.db.adminRead.listOrganizations({ limit: 1_000 });
      const byPlan = PLANS.map((plan) => ({
        plan,
        organizations: organizations.filter((entry) => entry.organization.plan === plan).length,
      }));
      return {
        periodStart,
        totals: await context.db.adminRead.usageTotals(periodStart),
        ai: await context.db.adminRead.aiUsageSince(new Date(now.getTime() - 30 * 86_400_000)),
        byPlan,
      };
    },
  );
}

/** Exported for the gate test: every limit status shape the panel renders. */
export function limitRowsFor(plan: PlanId, used: Readonly<Record<string, number>>) {
  const limits = effectiveLimits(plan);
  return LIMIT_IDS.map((id) => limitStatus(limits[id], used[id] ?? 0));
}
