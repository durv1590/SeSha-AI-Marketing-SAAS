/**
 * Platform-staff authorization.
 *
 * THE DECISION THAT DEFINES THIS FILE: AN ORGANIZATION ADMIN IS NOT A PLATFORM
 * ADMIN.
 *
 * Phase 2 shipped four organization roles, the highest of which is called
 * `admin`. That is a CUSTOMER — the person who runs one company's workspace and
 * invites their colleagues. Reusing it for the platform panel would mean every
 * customer who made themselves an admin of their own organization could read
 * every other customer's data. It is the single most expensive mistake available
 * in this phase, it is a one-line mistake, and the brief is explicit about it:
 * *"Separate admin authorization"* and *"never expose admin APIs to normal
 * users."*
 *
 * So platform staff are a separate table (`platform_staff`), a separate role
 * scale, a separate permission set, a separate guard and a separate URL
 * namespace. Nothing in `lib/auth/rbac.ts` grants anything here, and
 * `tests/admin-security.test.ts` asserts that an organization owner with the
 * `admin` role is refused by every admin permission.
 *
 * FOUR MORE THINGS THE BRIEF ASKS FOR, AND HOW THEY ARE MET
 *  · **Strong authentication** — every WRITE requires a live sudo window (a
 *    re-authentication within the last 15 minutes, Phase 2's `sessions.sudo_until`).
 *    A stolen session cookie is not enough to change a plan or a feature flag.
 *  · **Role restrictions** — three staff roles, and the read/write split is real:
 *    support can read the operational surfaces and change nothing.
 *  · **Audit logs** — `lib/admin/service.ts` records every action, and reads are
 *    recorded too, not just writes. Who looked at which customer is the question
 *    an audit log exists to answer.
 *  · **Session controls** — staff sessions are additionally checked against
 *    revocation on every request, and granting staff access is itself an audited,
 *    sudo-gated action that only a platform owner may perform.
 *
 * Framework-free and fully unit tested.
 */

/* -------------------------------------------------------------------------- */
/* Staff roles                                                               */
/* -------------------------------------------------------------------------- */

/**
 * Three roles, ordered by rank.
 *
 * `support` reads. `engineer` reads and changes configuration. `platform_owner`
 * additionally grants and revokes staff access — the one power that must not be
 * self-serve, because it is the power to give yourself every other power.
 */
export const STAFF_ROLES = ['support', 'engineer', 'platform_owner'] as const;

export type StaffRole = (typeof STAFF_ROLES)[number];

const STAFF_RANK: Readonly<Record<StaffRole, number>> = {
  support: 0,
  engineer: 1,
  platform_owner: 2,
};

export const STAFF_ROLE_LABEL: Readonly<Record<StaffRole, string>> = {
  support: 'Support',
  engineer: 'Engineer',
  platform_owner: 'Platform owner',
};

export const STAFF_ROLE_DESCRIPTION: Readonly<Record<StaffRole, string>> = {
  support:
    'Reads the operational surfaces — accounts, subscriptions, usage, jobs, errors — and changes nothing. Every screen they open is recorded.',
  engineer:
    'Everything Support can do, plus plan limits, feature flags, prompts and system configuration. Cannot grant staff access.',
  platform_owner:
    'Everything, including granting and revoking staff access. Should be a very short list of people.',
};

export function isStaffRole(value: unknown): value is StaffRole {
  return typeof value === 'string' && (STAFF_ROLES as readonly string[]).includes(value);
}

/* -------------------------------------------------------------------------- */
/* Permissions                                                               */
/* -------------------------------------------------------------------------- */

/**
 * The admin permission set.
 *
 * Named for the brief's own dashboard and control lists, so the mapping from
 * requirement to enforcement is checkable by reading. Reads and writes are
 * separate permissions throughout — a single `admin:subscriptions` that covered
 * both would make the support role meaningless.
 */
export const ADMIN_PERMISSIONS = [
  /* Dashboard reads */
  'admin:users:read',
  'admin:businesses:read',
  'admin:projects:read',
  'admin:subscriptions:read',
  'admin:usage:read',
  'admin:ai:read',
  'admin:errors:read',
  'admin:health:read',
  'admin:reports:read',
  'admin:feedback:read',
  'admin:jobs:read',
  'admin:security:read',
  'admin:audit:read',

  /* Controls */
  'admin:plans:write',
  'admin:limits:write',
  'admin:templates:write',
  'admin:prompts:write',
  'admin:flags:write',
  'admin:validator:write',
  'admin:system:write',
  'admin:subscriptions:write',
  'admin:feedback:write',

  /* The power to grant power */
  'admin:staff:read',
  'admin:staff:write',
] as const;

export type AdminPermission = (typeof ADMIN_PERMISSIONS)[number];

/**
 * The minimum staff role each permission requires.
 *
 * Written as "minimum role" rather than per-role lists so a new permission
 * cannot be accidentally granted to everyone or forgotten for a role.
 * `tests/admin-security.test.ts` asserts every permission has an entry.
 */
const MINIMUM_STAFF_ROLE: Readonly<Record<AdminPermission, StaffRole>> = {
  'admin:users:read': 'support',
  'admin:businesses:read': 'support',
  'admin:projects:read': 'support',
  'admin:subscriptions:read': 'support',
  'admin:usage:read': 'support',
  'admin:ai:read': 'support',
  'admin:errors:read': 'support',
  'admin:health:read': 'support',
  'admin:reports:read': 'support',
  'admin:feedback:read': 'support',
  'admin:jobs:read': 'support',
  'admin:security:read': 'support',
  'admin:audit:read': 'engineer',

  'admin:plans:write': 'engineer',
  'admin:limits:write': 'engineer',
  'admin:templates:write': 'engineer',
  'admin:prompts:write': 'engineer',
  'admin:flags:write': 'engineer',
  'admin:validator:write': 'engineer',
  'admin:system:write': 'engineer',
  'admin:subscriptions:write': 'engineer',
  'admin:feedback:write': 'support',

  'admin:staff:read': 'engineer',
  'admin:staff:write': 'platform_owner',
};

/**
 * Permissions that additionally require a live sudo window.
 *
 * Every write, plus reading the audit log — because the audit log records who
 * looked at whom, and someone covering their tracks would start by reading it.
 */
const REQUIRES_SUDO: readonly AdminPermission[] = ADMIN_PERMISSIONS.filter(
  (permission) => permission.endsWith(':write') || permission === 'admin:audit:read',
);

export function requiresSudo(permission: AdminPermission): boolean {
  return REQUIRES_SUDO.includes(permission);
}

export function isAdminPermission(value: unknown): value is AdminPermission {
  return typeof value === 'string' && (ADMIN_PERMISSIONS as readonly string[]).includes(value);
}

/** Every permission a staff role holds. For the panel and for tests. */
export function permissionsFor(role: StaffRole): readonly AdminPermission[] {
  return ADMIN_PERMISSIONS.filter(
    (permission) => STAFF_RANK[role] >= STAFF_RANK[MINIMUM_STAFF_ROLE[permission]],
  );
}

/* -------------------------------------------------------------------------- */
/* The staff context                                                          */
/* -------------------------------------------------------------------------- */

/**
 * Who is acting, in the admin panel.
 *
 * Deliberately NOT a superset of `TenantContext`, and deliberately carrying no
 * `organizationId`. A staff member acting on the platform is not acting inside a
 * tenant, and a type that carried both would invite code that uses whichever is
 * convenient — which is how a cross-tenant read ends up scoped to the staff
 * member's own organization by accident, silently returning nothing and looking
 * like it worked.
 */
export interface StaffContext {
  readonly userId: string;
  readonly email: string;
  readonly role: StaffRole;
  /** True while the re-authentication window is live. */
  readonly sudo: boolean;
  /** The session, so an action can be tied to one login. */
  readonly sessionId: string;
  /** Hashed client address, for the audit record. Never the raw address. */
  readonly ipHash: string | null;
}

export class AdminAuthorizationError extends Error {
  readonly code = 'ADMIN_FORBIDDEN' as const;
  readonly permission: AdminPermission;
  readonly needsSudo: boolean;

  constructor(permission: AdminPermission, needsSudo: boolean, message: string) {
    super(message);
    this.name = 'AdminAuthorizationError';
    this.permission = permission;
    this.needsSudo = needsSudo;
  }
}

export type AdminAccess =
  | { readonly ok: true }
  | { readonly ok: false; readonly needsSudo: boolean; readonly message: string };

/**
 * Whether this staff member may exercise this permission right now.
 *
 * Returns a decision so the caller can distinguish "you are not allowed" from
 * "confirm your password again" — those need different responses, and conflating
 * them either teaches staff to ignore a permission error or asks someone to
 * re-authenticate for something they will still be refused.
 */
export function checkAdminAccess(
  staff: StaffContext | null,
  permission: AdminPermission,
): AdminAccess {
  if (!staff) {
    return {
      ok: false,
      needsSudo: false,
      message: 'This is not available.',
    };
  }
  if (!isAdminPermission(permission)) {
    return { ok: false, needsSudo: false, message: 'This is not available.' };
  }
  if (STAFF_RANK[staff.role] < STAFF_RANK[MINIMUM_STAFF_ROLE[permission]]) {
    return {
      ok: false,
      needsSudo: false,
      message: `That needs the ${STAFF_ROLE_LABEL[MINIMUM_STAFF_ROLE[permission]]} role. You have ${STAFF_ROLE_LABEL[staff.role]}.`,
    };
  }
  if (requiresSudo(permission) && !staff.sudo) {
    return {
      ok: false,
      needsSudo: true,
      message: 'Confirm your password again to continue. Admin changes need a recent sign-in.',
    };
  }
  return { ok: true };
}

/** Throws on refusal. The form services use this; routes use the decision. */
export function requireAdmin(staff: StaffContext | null, permission: AdminPermission): StaffContext {
  const access = checkAdminAccess(staff, permission);
  if (!access.ok) {
    throw new AdminAuthorizationError(permission, access.needsSudo, access.message);
  }
  return staff as StaffContext;
}

/* -------------------------------------------------------------------------- */
/* What a refused stranger is told                                            */
/* -------------------------------------------------------------------------- */

/**
 * The response an ordinary user gets from an admin endpoint: 404.
 *
 * Not 403. A 403 confirms the endpoint exists and that there is a panel worth
 * attacking; the same reasoning as cross-tenant access returning 404 rather than
 * 403 (Phase 2). To someone who is not staff, the admin panel does not exist.
 */
export const ADMIN_NOT_FOUND_MESSAGE = 'Not found.';

/**
 * The HTTP shape of a refusal: status, body message, and whether to flag sudo.
 *
 * EXTRACTED FROM THE GUARD BECAUSE IT IS LOGIC, AND LOGIC IN A REQUEST HANDLER
 * IS LOGIC NOBODY TESTS. The guard lives behind `getCurrentSession`, which needs
 * cookies and a running Next.js, so a test cannot reach it — and a mutation
 * check proved the cost: changing the guard's refusal from 404 to 403 left the
 * whole suite green, because the tests asserted the DECISION (`checkAdminAccess`)
 * and never the response it turns into. Both halves are testable here.
 *
 * THE RULE: everything is 404 except a sudo prompt.
 *  · not staff, or no session at all → 404, the same not-found page a mistyped
 *    URL gets. To a stranger the panel does not exist.
 *  · staff, right role, stale sign-in → 403 with `needsSudo`, because that
 *    caller is already known to be staff and asking them to re-authenticate
 *    discloses nothing they do not already know.
 *  · staff, wrong role → 404, NOT 403. A support engineer probing for the staff
 *    management endpoint should not learn that it is there and that someone
 *    senior can reach it.
 */
export interface AdminRefusal {
  readonly status: 404 | 403;
  readonly message: string;
  readonly needsSudo: boolean;
}

export function adminRefusal(access: Exclude<AdminAccess, { readonly ok: true }>): AdminRefusal {
  if (access.needsSudo) {
    return { status: 403, message: access.message, needsSudo: true };
  }
  // The role-based refusal deliberately DISCARDS `access.message`. That message
  // names the role required ("That needs the Engineer role"), which is useful to
  // a staff member reading a form and is disclosure to anyone else — and this
  // branch cannot tell the two apart, so it tells neither.
  return { status: 404, message: ADMIN_NOT_FOUND_MESSAGE, needsSudo: false };
}

/**
 * Whether a user is staff at all, given their stored row.
 *
 * A revoked row is not staff. Checked on every request rather than trusted from
 * the session, so revoking access takes effect immediately rather than when the
 * session happens to expire — which could be thirty days.
 */
export function staffRoleFrom(
  row: { readonly role: string; readonly revokedAt: Date | null } | null,
): StaffRole | null {
  if (!row) return null;
  if (row.revokedAt !== null) return null;
  return isStaffRole(row.role) ? row.role : null;
}
