/**
 * The system settings registry.
 *
 * Backs the brief's four configuration controls — Templates, Prompts, Validator
 * configuration, System configuration — with one table and a FIXED registry of
 * permitted keys.
 *
 * WHY A REGISTRY AND NOT FREE-FORM KEYS
 * Same reasoning as the feature flags. A setting created by typing a new name
 * into a form is a setting nobody can find, nobody documents and nobody
 * removes — and there is no way to validate a value whose meaning is unknown.
 * Every key here declares its shape, its default and what changing it does.
 *
 * WHAT A SETTING MAY NOT DO: WIDEN A SAFETY LIMIT.
 * `crawler.max_pages_ceiling` can only LOWER the built-in cap, exactly as
 * `CRAWLER_MAX_PAGES` can only lower it (Phase 4). A configuration surface that
 * can raise a safety limit is a configuration surface that will, at 2am, by
 * someone who does not know why the limit was there. `check()` enforces the
 * direction, not just the type.
 */

/* -------------------------------------------------------------------------- */
/* The registry                                                               */
/* -------------------------------------------------------------------------- */

export const SETTING_GROUPS = ['prompts', 'templates', 'validator', 'system'] as const;

export type SettingGroup = (typeof SETTING_GROUPS)[number];

export const GROUP_LABEL: Readonly<Record<SettingGroup, string>> = {
  prompts: 'Prompts',
  templates: 'Templates',
  validator: 'Validator configuration',
  system: 'System configuration',
};

export type SettingShape = 'string' | 'number' | 'boolean' | 'string_list';

export interface SettingDefinition {
  readonly key: string;
  readonly group: SettingGroup;
  readonly label: string;
  /** What changing it actually does. Written for whoever is on call. */
  readonly description: string;
  readonly shape: SettingShape;
  readonly defaultValue: unknown;
  /** For a number: the inclusive bounds. */
  readonly min?: number;
  readonly max?: number;
  /** For a string: the largest value that may be stored. */
  readonly maxLength?: number;
  /**
   * Set when a value may only move in one direction from the default. The
   * crawler ceiling is the case: narrowing is allowed, widening is not.
   */
  readonly narrowOnly?: 'lower' | 'higher';
}

export const SETTING_DEFINITIONS: readonly SettingDefinition[] = [
  /* ------------------------------- prompts -------------------------------- */
  {
    key: 'prompts.house_style',
    group: 'prompts',
    label: 'House style note',
    description:
      'Appended to every content generation prompt. Use it for cross-customer guidance ("prefer Indian English", "never use the word synergy"). It does not override a customer’s own brand voice, which is more specific and wins.',
    shape: 'string',
    defaultValue: '',
    maxLength: 2_000,
  },
  {
    key: 'prompts.refusal_reminder',
    group: 'prompts',
    label: 'Refusal reminder',
    description:
      'Appended to every prompt, reminding the model not to invent ratings, prices, credentials or statistics. The provenance system rejects untagged output regardless — this reduces how often it has to.',
    shape: 'string',
    defaultValue:
      'Never invent a statistic, rating, price, award or credential. If you do not know something, say so.',
    maxLength: 2_000,
  },

  /* ------------------------------ templates ------------------------------- */
  {
    key: 'templates.report_footer',
    group: 'templates',
    label: 'Report footer',
    description: 'Appended to the last page of every exported report. Plain text.',
    shape: 'string',
    defaultValue: '',
    maxLength: 500,
  },
  {
    key: 'templates.notification_signature',
    group: 'templates',
    label: 'Notification signature',
    description: 'Appended to in-app notification bodies. Plain text.',
    shape: 'string',
    defaultValue: '',
    maxLength: 300,
  },

  /* ------------------------------ validator ------------------------------- */
  {
    key: 'validator.suppressed_checks',
    group: 'validator',
    label: 'Suppressed checks',
    description:
      'Validator check ids to stop reporting platform-wide, for when one of our own rules is found to be wrong. A suppressed check is reported on screen as a SeSha problem, not as a clean result — suppressing a check must never look like passing it.',
    shape: 'string_list',
    defaultValue: [],
  },
  {
    key: 'validator.warn_on_localhost',
    group: 'validator',
    label: 'Advise on localhost URLs',
    description:
      'Whether a localhost URL in markup produces an advisory. On by default: it is correct while developing and must not be what gets published.',
    shape: 'boolean',
    defaultValue: true,
  },

  /* ------------------------------- system --------------------------------- */
  {
    key: 'system.signup_enabled',
    group: 'system',
    label: 'Allow new sign-ups',
    description:
      'Off closes registration. Existing customers are unaffected and can still sign in — this is not a maintenance switch.',
    shape: 'boolean',
    defaultValue: true,
  },
  {
    key: 'system.banner',
    group: 'system',
    label: 'Service banner',
    description:
      'Shown at the top of every authenticated screen. Use it during an incident. Empty means no banner.',
    shape: 'string',
    defaultValue: '',
    maxLength: 300,
  },
  {
    key: 'crawler.max_pages_ceiling',
    group: 'system',
    label: 'Crawler page ceiling',
    description:
      'The largest number of pages any crawl may fetch, platform-wide. This can only be LOWERED from the built-in cap of 500 — a configuration surface that can raise a safety limit is one that eventually will.',
    shape: 'number',
    defaultValue: 500,
    min: 1,
    max: 500,
    narrowOnly: 'lower',
  },
  {
    key: 'system.ai_disabled_reason',
    group: 'system',
    label: 'AI unavailable notice',
    description:
      'When set, AI generation is refused platform-wide and this sentence is shown as the reason. For a provider outage. Empty means AI is available.',
    shape: 'string',
    defaultValue: '',
    maxLength: 300,
  },
];

const BY_KEY: ReadonlyMap<string, SettingDefinition> = new Map(
  SETTING_DEFINITIONS.map((definition) => [definition.key, definition]),
);

export const SETTING_KEYS: readonly string[] = SETTING_DEFINITIONS.map(
  (definition) => definition.key,
);

export function isSettingKey(value: unknown): value is string {
  return typeof value === 'string' && BY_KEY.has(value);
}

export function settingDefinition(key: string): SettingDefinition | null {
  return BY_KEY.get(key) ?? null;
}

export function settingsInGroup(group: SettingGroup): readonly SettingDefinition[] {
  return SETTING_DEFINITIONS.filter((definition) => definition.group === group);
}

/* -------------------------------------------------------------------------- */
/* Validation                                                                 */
/* -------------------------------------------------------------------------- */

export type SettingCheck =
  | { readonly ok: true; readonly value: unknown }
  | { readonly ok: false; readonly message: string };

/**
 * Validates a submitted value against its declared shape.
 *
 * Returns the NORMALISED value on success — a trimmed string, a floored number,
 * a de-duplicated list — so what is stored is what was validated rather than
 * what was typed.
 */
export function check(key: string, value: unknown): SettingCheck {
  const definition = settingDefinition(key);
  if (!definition) {
    return { ok: false, message: `"${key}" is not a setting this product declares.` };
  }

  switch (definition.shape) {
    case 'boolean':
      if (typeof value !== 'boolean') {
        return { ok: false, message: `${definition.label} is on or off.` };
      }
      return { ok: true, value };

    case 'string': {
      if (typeof value !== 'string') {
        return { ok: false, message: `${definition.label} is text.` };
      }
      const trimmed = value.trim();
      const max = definition.maxLength ?? 1_000;
      if (trimmed.length > max) {
        return { ok: false, message: `${definition.label} is at most ${max} characters.` };
      }
      return { ok: true, value: trimmed };
    }

    case 'number': {
      if (typeof value !== 'number' || !Number.isFinite(value)) {
        return { ok: false, message: `${definition.label} is a number.` };
      }
      const floored = Math.floor(value);

      // THE DIRECTION GUARD IS CHECKED FIRST, and the order is deliberate.
      // `crawler.max_pages_ceiling` has `max` equal to its default, so a `max`
      // check evaluated first would shadow this one entirely — the guard would
      // be unreachable code that looked like protection. A test caught that:
      // setting 5000 was refused with "at most 500", which is true but does not
      // say the thing that matters, which is that this is a safety limit and
      // raising it is not a thing anyone may do.
      if (definition.narrowOnly === 'lower' && typeof definition.defaultValue === 'number') {
        if (floored > definition.defaultValue) {
          return {
            ok: false,
            message: `${definition.label} can only be lowered from ${definition.defaultValue}, never raised. It is a safety limit.`,
          };
        }
      }
      if (definition.narrowOnly === 'higher' && typeof definition.defaultValue === 'number') {
        if (floored < definition.defaultValue) {
          return {
            ok: false,
            message: `${definition.label} can only be raised from ${definition.defaultValue}, never lowered.`,
          };
        }
      }

      if (definition.min !== undefined && floored < definition.min) {
        return { ok: false, message: `${definition.label} is at least ${definition.min}.` };
      }
      if (definition.max !== undefined && floored > definition.max) {
        return { ok: false, message: `${definition.label} is at most ${definition.max}.` };
      }
      return { ok: true, value: floored };
    }

    case 'string_list': {
      if (!Array.isArray(value) || value.some((entry) => typeof entry !== 'string')) {
        return { ok: false, message: `${definition.label} is a list of text values.` };
      }
      const cleaned = [...new Set((value as string[]).map((entry) => entry.trim()).filter(Boolean))];
      if (cleaned.length > 200) {
        return { ok: false, message: `${definition.label} holds at most 200 values.` };
      }
      return { ok: true, value: cleaned };
    }
  }
}

/** The stored value, or the declared default. Never undefined. */
export function resolveSetting(key: string, stored: unknown): unknown {
  const definition = settingDefinition(key);
  if (!definition) return undefined;
  if (stored === undefined || stored === null) return definition.defaultValue;
  // A stored value that no longer validates falls back to the default rather
  // than being served. A setting whose shape changed in a deploy must not break
  // every screen that reads it.
  const checked = check(key, stored);
  return checked.ok ? checked.value : definition.defaultValue;
}
