/**
 * The validation engine.
 *
 * Every check the brief names lives here, and each one decides TWO things: the
 * status, and the dimension. The dimension is the harder and more important of
 * the two, because it is what stops the tool from telling a user that a missing
 * `image` is the same kind of problem as malformed JSON.
 *
 * THE RULE EVERY CHECK FOLLOWS
 * A check may only claim what it can know from the document in front of it.
 *  · "This is not valid JSON"                     — knowable. SCHEMA_VALIDITY.
 *  · "Google's documentation asks for an image"    — knowable (it is published).
 *                                                    SEARCH_ELIGIBILITY.
 *  · "You will get a rich result"                  — NOT knowable. Never emitted.
 *  · "An AI system will cite this page"            — NOT knowable. Never emitted.
 *
 * `tests/schema-engine.test.ts` asserts the last two never appear, by scanning
 * every explanation this file can produce for forbidden phrasing.
 *
 * Framework-free and fully unit tested.
 */

import {
  asNumber,
  checkCurrency,
  checkDate,
  checkDuration,
  checkEnum,
  checkNumber,
  checkText,
  checkUrl,
  compareDates,
  isAdvisoryUrl,
  preview,
} from './datatypes';
import { parseDocument, type JsonValue, type ParsedNode } from './parse';
import {
  ARTICLE_TYPES,
  DEPRECATED_PROPERTIES,
  PROPERTY_RULES,
  SEARCH_RULES_AS_OF,
  SUPPORTED_SCHEMA_TYPES,
  isNestedType,
  rulesFor,
} from './registry';
import {
  VALIDATOR_VERSION,
  countIssues,
  overallStatus,
  sortIssues,
  type CrawlLimitation,
  type SchemaEntity,
  type SchemaSyntax,
  type ValidationIssue,
  type ValidationResult,
  type ValidationSourceKind,
} from './types';

export interface ValidateInput {
  readonly source: string;
  readonly sourceKind: ValidationSourceKind;
  readonly sourceUrl?: string;
  /**
   * The page's canonical URL, when the caller knows it from a crawl. Supplied
   * rather than guessed: the canonical check is skipped (and reported as
   * NOT_EVALUATED) when it is absent, because a canonical cannot be inferred
   * from the structured data itself.
   */
  readonly canonicalUrl?: string;
  /** Limitations of how the document was obtained. Not findings. */
  readonly limitations?: readonly CrawlLimitation[];
  readonly now?: () => Date;
}

/** Longest headline a search result will show without truncating it. */
const HEADLINE_LIMIT = 110;

export function validateSchema(input: ValidateInput): ValidationResult {
  const now = input.now ?? (() => new Date());
  const checkedAt = now().toISOString();
  const issues: ValidationIssue[] = [];
  const limitations: CrawlLimitation[] = [...(input.limitations ?? [])];

  const parsed = parseDocument(input.source);
  for (const limitation of parsed.limitations) {
    limitations.push({ code: limitation.code, detail: limitation.detail });
  }

  /* ---------------------------------------------------------------- syntax */
  for (const failure of parsed.failures) {
    issues.push({
      status: failure.code === 'no_markup_found' ? 'NOT_EVALUATED' : 'INVALID',
      dimension: 'SCHEMA_VALIDITY',
      check: `parse_${failure.code}`,
      path: failure.path ?? '$',
      explanation: failure.detail,
    });
  }

  const nodes = parsed.nodes;

  /* --------------------------------------------------------------- context */
  checkContexts(parsed.contexts, nodes, issues, limitations);

  /* ----------------------------------------------------------- every node */
  for (const node of nodes) {
    checkNode(node, nodes, issues, now());
  }

  /* ------------------------------------------------ whole-document checks */
  checkDuplicateIds(nodes, issues);
  checkDuplicateEntities(nodes, issues);
  checkOrganizationConsistency(nodes, issues);
  checkCanonical(nodes, issues, input.canonicalUrl);

  /* ----------------------------------------------- what was NOT evaluated */
  addNotEvaluated(issues, nodes, input);

  const entities = nodes.map(toEntity);
  const typesFound = uniqueTypes(nodes);
  const unsupportedTypes = typesFound.filter(
    (type) => rulesFor(type) === null && !isNestedType(type),
  );

  const sorted = sortIssues(issues);
  return {
    validatorVersion: VALIDATOR_VERSION,
    checkedAt,
    sourceKind: input.sourceKind,
    ...(input.sourceUrl ? { sourceUrl: input.sourceUrl } : {}),
    syntaxes: dedupe(parsed.syntaxes) as SchemaSyntax[],
    parsed: parsed.failures.every((failure) => failure.code === 'no_markup_found'),
    entities,
    typesFound,
    unsupportedTypes,
    issues: sorted,
    counts: countIssues(sorted),
    limitations,
    overall: overallStatus(entities, sorted),
  };
}

/* -------------------------------------------------------------------------- */
/* @context                                                                   */
/* -------------------------------------------------------------------------- */

function checkContexts(
  contexts: readonly string[],
  nodes: readonly ParsedNode[],
  issues: ValidationIssue[],
  limitations: CrawlLimitation[],
): void {
  const jsonLdTopLevel = nodes.filter((node) => node.syntax === 'json-ld' && !node.parent);
  if (jsonLdTopLevel.length === 0) return;

  if (contexts.length === 0) {
    issues.push({
      status: 'INVALID',
      dimension: 'SCHEMA_VALIDITY',
      check: 'context_missing',
      path: jsonLdTopLevel[0]!.path,
      property: '@context',
      explanation:
        'The document has no "@context", so nothing tells a consumer that these property names are schema.org terms. Without it the markup is ignored.',
      correctedExample: '"@context": "https://schema.org"',
    });
    return;
  }

  for (const context of contexts) {
    if (context === '[inline object]') {
      limitations.push({
        code: 'inline_context',
        detail:
          'The document defines its own "@context" object. Term mappings inside it were not resolved, so property names were checked as written.',
      });
      continue;
    }
    // Only the https form with no path is the canonical context. `http://` still
    // works in most consumers but is the older spelling, so it is a note.
    if (/^https:\/\/schema\.org\/?$/.test(context)) continue;
    if (/schema\.org/i.test(context)) {
      // e.g. http://schema.org with a trailing path, or a versioned context.
      issues.push({
        status: 'RECOMMENDATION',
        dimension: 'SCHEMA_VALIDITY',
        check: 'context_variant',
        path: '$',
        property: '@context',
        explanation: `The context "${preview(context, 60)}" is a schema.org variant. The canonical value is "https://schema.org".`,
        correctedExample: '"@context": "https://schema.org"',
        found: preview(context, 60),
      });
      continue;
    }
    issues.push({
      status: 'WARNING',
      dimension: 'SCHEMA_VALIDITY',
      check: 'context_not_schema_org',
      path: '$',
      property: '@context',
      explanation: `The context "${preview(context, 60)}" is not schema.org, so the property names here are not being read as schema.org terms. This validator only knows schema.org.`,
      correctedExample: '"@context": "https://schema.org"',
      found: preview(context, 60),
    });
  }
}

/* -------------------------------------------------------------------------- */
/* One node                                                                   */
/* -------------------------------------------------------------------------- */

/** A node that exists only to point at another node carries just `@id`. */
function isReferenceOnly(node: ParsedNode): boolean {
  return node.types.length === 0 && node.id !== undefined && Object.keys(node.properties).length === 0;
}

/**
 * What part a node plays in the document.
 *
 * WHY THIS MATTERS FOR THE SEARCH REQUIREMENTS
 * Published requirements for Organization are about the organization the PAGE IS
 * ABOUT — the site's own entity, or the publisher of an article. They are not
 * about every Organization that happens to be nested somewhere: an article whose
 * author is `{ "@type": "Organization", "name": "Editorial Team" }` is correct
 * markup, and telling the user their editorial team needs a logo, a URL and a
 * contact point is noise. Noise is not harmless — it is how a user learns to
 * ignore the findings that matter.
 *
 * So a nested node is held to schema.org validity (its required properties) and
 * not to the published search requirements or the SEO recommendations of the
 * role it does not play.
 */
type NodeRole = 'top_level' | 'publisher' | 'author' | 'nested';

function roleOf(node: ParsedNode): NodeRole {
  if (!node.parent) return 'top_level';
  const segment = node.path.slice(node.parent.length + 1).replace(/\[\d+\]$/, '');
  if (segment === 'publisher') return 'publisher';
  if (segment === 'author' || segment === 'creator' || segment === 'reviewedBy') return 'author';
  return 'nested';
}

/** Whether this node should be judged against published search requirements. */
function carriesSearchRequirements(node: ParsedNode): boolean {
  const role = roleOf(node);
  return role === 'top_level' || role === 'publisher';
}

function checkNode(
  node: ParsedNode,
  all: readonly ParsedNode[],
  issues: ValidationIssue[],
  now: Date,
): void {
  if (isReferenceOnly(node)) return;

  /* ------------------------------------------------------------- @type */
  if (node.types.length === 0) {
    // An empty object inside a property is a different, clearer complaint.
    const empty = Object.keys(node.properties).length === 0;
    issues.push({
      status: 'INVALID',
      dimension: 'SCHEMA_VALIDITY',
      check: 'type_missing',
      path: node.path,
      property: '@type',
      explanation: empty
        ? 'This node is empty and has no "@type". Remove it, or give it a type and properties.'
        : 'This node has no "@type", so a consumer cannot tell what it describes. Every node needs one.',
      correctedExample: '"@type": "Organization"',
    });
    return;
  }

  /* --------------------------------------------------------------- @id */
  if (node.id !== undefined) {
    const id = node.id.trim();
    if (id.length === 0) {
      issues.push({
        status: 'INVALID',
        dimension: 'SCHEMA_VALIDITY',
        check: 'id_empty',
        path: node.path,
        property: '@id',
        explanation: 'The "@id" is empty. Either remove it or give the node a stable identifier.',
      });
    } else if (!/^(https?:\/\/|#|_:)/i.test(id)) {
      issues.push({
        status: 'WARNING',
        dimension: 'SCHEMA_VALIDITY',
        check: 'id_not_absolute',
        path: node.path,
        property: '@id',
        explanation:
          'An "@id" should be a stable absolute URL, usually the page URL with a fragment, so other nodes and other pages can refer to the same thing.',
        correctedExample: '"@id": "https://example.com/#organization"',
        found: preview(id, 80),
      });
    }
  }

  /* ------------------------------------------------------ types and rules */
  const resolved = node.types.map((type) => ({ type, rules: rulesFor(type) }));
  const supported = resolved.filter((entry) => entry.rules !== null);

  if (supported.length === 0) {
    if (node.types.every((type) => isNestedType(type))) {
      // Checked by its parent (a Rating inside a Review, for example).
    } else {
      issues.push({
        status: 'UNSUPPORTED',
        dimension: 'SCHEMA_VALIDITY',
        check: 'type_unsupported',
        path: node.path,
        type: node.types.join(', '),
        explanation: `SeSha has no property rules for "${node.types.join(', ')}", so this node was not checked. That is a limit of this tool, not a problem with your markup.`,
      });
    }
  }

  for (const entry of supported) {
    const rule = entry.rules!.rule;
    const typeName = entry.rules!.as;

    /* ------------------------------------------------ required properties */
    for (const property of rule.required) {
      if (!hasValue(node, property)) {
        issues.push({
          status: 'INVALID',
          dimension: 'SCHEMA_VALIDITY',
          check: 'required_property_missing',
          path: `${node.path}.${property}`,
          property,
          type: entry.type,
          explanation: `${entry.type} requires "${property}". Without it the node does not describe anything a consumer can use.`,
          ...exampleFor(property),
        });
      }
    }

    /* --------------------------------------------- one-of property groups */
    for (const group of rule.oneOf ?? []) {
      if (group.properties.some((property) => hasValue(node, property))) continue;
      const validity = group.kind === 'validity';
      issues.push({
        status: validity ? 'INVALID' : 'WARNING',
        dimension: validity ? 'SCHEMA_VALIDITY' : 'SEARCH_ELIGIBILITY',
        check: 'one_of_missing',
        path: node.path,
        type: entry.type,
        explanation: validity
          ? `${entry.type} has none of ${quoteList(group.properties)} — ${group.why}.`
          : `${entry.type} has none of ${quoteList(group.properties)} — ${group.why}. As of ${SEARCH_RULES_AS_OF} the published requirements ask for at least one.`,
      });
    }

    /* --------------------------------------------- recommended properties */
    const judgeForSearch = carriesSearchRequirements(node);
    for (const property of rule.recommended) {
      if (hasValue(node, property)) continue;
      const isSearchRequirement = (rule.search?.properties.includes(property) ?? false) && judgeForSearch;
      if (!judgeForSearch && !isSearchRequirement) {
        // A nested node is checked for validity, not for completeness in a role
        // it does not play. See `roleOf`.
        continue;
      }
      if (isSearchRequirement) {
        issues.push({
          status: 'WARNING',
          dimension: 'SEARCH_ELIGIBILITY',
          check: 'search_property_missing',
          path: `${node.path}.${property}`,
          property,
          type: entry.type,
          explanation: `"${property}" is missing. As of ${SEARCH_RULES_AS_OF}, published search-engine documentation asks for it on ${entry.type}. Whether any particular result appears is the search engine's decision, not something this tool can check.`,
          ...exampleFor(property),
        });
      } else {
        issues.push({
          status: 'RECOMMENDATION',
          dimension: 'SEO_GUIDANCE',
          check: 'recommended_property_missing',
          path: `${node.path}.${property}`,
          property,
          type: entry.type,
          explanation: `"${property}" is not set. It is optional — the markup is valid without it — but it describes ${entry.type} more completely.`,
          ...exampleFor(property),
        });
      }
    }

    /* ---------------------------------- search requirements not yet listed */
    for (const property of judgeForSearch ? rule.search?.properties ?? [] : []) {
      if (hasValue(node, property)) continue;
      if (rule.recommended.includes(property) || rule.required.includes(property)) continue;
      issues.push({
        status: 'WARNING',
        dimension: 'SEARCH_ELIGIBILITY',
        check: 'search_property_missing',
        path: `${node.path}.${property}`,
        property,
        type: entry.type,
        explanation: `"${property}" is missing. As of ${SEARCH_RULES_AS_OF}, published search-engine documentation asks for it on ${entry.type}.`,
        ...exampleFor(property),
      });
    }

    /* ------------------------------------------------- feature-level notes */
    if (rule.search?.note && judgeForSearch) {
      issues.push({
        status: 'RECOMMENDATION',
        dimension: 'SEARCH_ELIGIBILITY',
        check: 'search_feature_note',
        path: node.path,
        type: entry.type,
        explanation: `${rule.search.note} (Reviewed ${SEARCH_RULES_AS_OF}.)`,
      });
    }

    /* ----------------------------------------------------- AEO properties */
    for (const property of judgeForSearch ? rule.aeo ?? [] : []) {
      if (hasValue(node, property)) continue;
      issues.push({
        status: 'RECOMMENDATION',
        dimension: 'AEO_CLARITY',
        check: 'aeo_property_missing',
        path: `${node.path}.${property}`,
        property,
        type: entry.type,
        explanation: `"${property}" is missing. An AI system reading this node alone would have to infer it. Stating it makes the fact quotable rather than guessable.`,
        ...exampleFor(property),
      });
    }

    /* ----------------------------------------------------- per-type checks */
    applyTypeChecks(typeName, entry.type, node, all, issues, now);
  }

  /* ----------------------------------------------------------- data types */
  for (const [property, value] of Object.entries(node.properties)) {
    checkPropertyValue(node, property, value, issues, now);
  }

  /* ------------------------------------------------------------- honesty */
  // Keyed on the PROPERTY, not the type. A rating published on an Article, a
  // Service, a LocalBusiness or anything else is the same claim about real
  // customers, and the earlier version of this check only fired for Product —
  // which is exactly the node a fabricated rating is least often attached to.
  checkRatingHonesty(node, issues, node.types[0] ?? 'this node');

  /* -------------------------------------------------------- deprecations */
  for (const property of Object.keys(node.properties)) {
    const replacement = DEPRECATED_PROPERTIES[property];
    if (replacement) {
      issues.push({
        status: 'WARNING',
        dimension: 'SCHEMA_VALIDITY',
        check: 'deprecated_property',
        path: `${node.path}.${property}`,
        property,
        type: node.types[0],
        explanation: `"${property}" has been superseded by "${replacement}". Consumers may ignore the old name.`,
        correctedExample: `"${replacement}": …`,
      });
    }
  }
}

/* -------------------------------------------------------------------------- */
/* Property values                                                            */
/* -------------------------------------------------------------------------- */

function checkPropertyValue(
  node: ParsedNode,
  property: string,
  value: JsonValue,
  issues: ValidationIssue[],
  now: Date,
): void {
  const rule = PROPERTY_RULES[property];
  if (!rule) return;
  if (isNestedReference(value)) return;

  const values = Array.isArray(value) ? value : [value];
  for (const entry of values) {
    if (entry === null || entry === undefined) continue;
    if (rule.type === 'node') {
      // Nested nodes are validated as nodes in their own right; here we only
      // check that a node-valued property is not a bare string where a node is
      // needed to carry required sub-properties.
      if (typeof entry === 'string' && requiresNode(property)) {
        issues.push({
          status: 'WARNING',
          dimension: 'SCHEMA_VALIDITY',
          check: 'node_expected',
          path: `${node.path}.${property}`,
          property,
          type: node.types[0],
          explanation: `"${property}" is written as plain text. ${quoteList(rule.expects ?? [])} carry their own properties, so a nested node says more and is what consumers expect.`,
          correctedExample: `"${property}": ${rule.example}`,
          found: preview(entry),
        });
      }
      continue;
    }

    const text = typeof entry === 'string' ? entry : undefined;

    switch (rule.type) {
      case 'url': {
        if (text === undefined) {
          if (typeof entry === 'object') continue; // e.g. image as ImageObject
          pushInvalid(issues, node, property, 'this should be a URL written as text', entry);
          continue;
        }
        const result = checkUrl(text);
        if (!result.ok) {
          pushInvalid(issues, node, property, result.reason ?? 'this is not a valid URL', entry, rule.example);
        } else if (isAdvisoryUrl(result)) {
          const unreachable = /localhost/.test(result.reason ?? '');
          issues.push({
            status: 'WARNING',
            dimension: 'SEO_GUIDANCE',
            check: unreachable ? 'url_not_public' : 'url_not_https',
            path: `${node.path}.${property}`,
            property,
            type: node.types[0],
            explanation: unreachable
              ? `"${property}": ${result.reason}.`
              : `"${property}": ${result.reason}. Serve it over https so the reference does not point at an insecure resource.`,
            found: preview(entry),
          });
        }
        break;
      }
      case 'date':
      case 'datetime': {
        if (text === undefined) {
          pushInvalid(issues, node, property, 'a date should be written as text', entry, rule.example);
          continue;
        }
        const result = checkDate(text, { time: rule.type === 'datetime' });
        if (!result.ok) {
          pushInvalid(issues, node, property, result.reason ?? 'this is not a valid date', entry, rule.example);
        } else if (result.reason) {
          issues.push({
            status: 'RECOMMENDATION',
            dimension: 'SCHEMA_VALIDITY',
            check: 'date_precision',
            path: `${node.path}.${property}`,
            property,
            type: node.types[0],
            explanation: result.reason,
            correctedExample: `"${property}": "${rule.example}"`,
            found: preview(entry),
          });
        }
        break;
      }
      case 'duration': {
        if (text === undefined) {
          pushInvalid(issues, node, property, 'a duration should be written as text', entry, rule.example);
          continue;
        }
        const result = checkDuration(text);
        if (!result.ok) {
          pushInvalid(issues, node, property, result.reason ?? 'this is not a valid duration', entry, rule.example);
        }
        break;
      }
      case 'number':
      case 'integer': {
        const result = checkNumber(entry, {
          integer: rule.type === 'integer',
          ...(rule.min !== undefined ? { min: rule.min } : {}),
          ...(rule.max !== undefined ? { max: rule.max } : {}),
        });
        if (!result.ok) {
          pushInvalid(issues, node, property, result.reason ?? 'this is not a number', entry, rule.example);
        }
        break;
      }
      case 'enum': {
        if (text === undefined) {
          pushInvalid(issues, node, property, 'this should be one of the accepted values', entry, rule.example);
          continue;
        }
        const result =
          property === 'priceCurrency' ? checkCurrency(text) : checkEnum(text, rule.values ?? []);
        if (!result.ok) {
          pushInvalid(issues, node, property, result.reason ?? 'this is not an accepted value', entry, rule.example);
        } else if (result.reason) {
          issues.push({
            status: 'RECOMMENDATION',
            dimension: 'SCHEMA_VALIDITY',
            check: 'enum_spelling',
            path: `${node.path}.${property}`,
            property,
            type: node.types[0],
            explanation: result.reason,
            correctedExample: `"${property}": "${rule.example}"`,
            found: preview(entry),
          });
        }
        break;
      }
      case 'text': {
        const result = checkText(entry);
        if (!result.ok) {
          pushInvalid(issues, node, property, result.reason ?? 'this should be text', entry);
        } else if (result.reason) {
          issues.push({
            status: 'WARNING',
            dimension: 'SCHEMA_VALIDITY',
            check: 'text_shape',
            path: `${node.path}.${property}`,
            property,
            type: node.types[0],
            explanation: result.reason,
            found: preview(entry),
          });
        }
        break;
      }
      case 'boolean': {
        if (typeof entry !== 'boolean' && entry !== 'true' && entry !== 'false') {
          pushInvalid(issues, node, property, 'this should be true or false', entry);
        }
        break;
      }
    }
  }

  /* ------------------------------------------------------------- dates pair */
  if (property === 'dateModified') {
    const published = firstString(node.properties['datePublished']);
    const modified = firstString(value);
    if (published && modified) {
      const delta = compareDates(modified, published);
      if (delta !== null && delta < 0) {
        issues.push({
          status: 'INVALID',
          dimension: 'SCHEMA_VALIDITY',
          check: 'dates_out_of_order',
          path: `${node.path}.dateModified`,
          property: 'dateModified',
          type: node.types[0],
          explanation: `"dateModified" (${modified}) is earlier than "datePublished" (${published}), which cannot be true.`,
        });
      }
    }
  }

  /* --------------------------------------------------- expiry in the past */
  if (property === 'priceValidUntil' || property === 'validThrough') {
    const text = firstString(value);
    if (text) {
      const parsed = new Date(text);
      if (!Number.isNaN(parsed.getTime()) && parsed.getTime() < now.getTime()) {
        issues.push({
          status: 'WARNING',
          dimension: 'SEARCH_ELIGIBILITY',
          check: 'validity_expired',
          path: `${node.path}.${property}`,
          property,
          type: node.types[0],
          explanation: `"${property}" is ${text}, which has passed. Consumers treat an expired offer or posting as no longer available.`,
          found: text,
        });
      }
    }
  }

  /* ----------------------------------------------------- headline length */
  if (property === 'headline' && ARTICLE_TYPES.some((type) => node.types.includes(type))) {
    const text = firstString(value);
    if (text && text.trim().length > HEADLINE_LIMIT) {
      issues.push({
        status: 'WARNING',
        dimension: 'SEO_GUIDANCE',
        check: 'headline_too_long',
        path: `${node.path}.headline`,
        property: 'headline',
        type: node.types[0],
        explanation: `Headline is ${text.trim().length} characters. Beyond about ${HEADLINE_LIMIT} it is usually truncated where it is displayed.`,
        found: preview(text, 140),
      });
    }
  }
}

function pushInvalid(
  issues: ValidationIssue[],
  node: ParsedNode,
  property: string,
  reason: string,
  found: unknown,
  example?: string,
): void {
  issues.push({
    status: 'INVALID',
    dimension: 'SCHEMA_VALIDITY',
    check: 'data_type_invalid',
    path: `${node.path}.${property}`,
    property,
    type: node.types[0],
    explanation: `"${property}": ${reason}.`,
    ...(example ? { correctedExample: `"${property}": ${jsonish(example)}` } : exampleFor(property)),
    found: preview(found),
  });
}

/** Properties where a bare string loses information a nested node would carry. */
function requiresNode(property: string): boolean {
  return ['address', 'offers', 'aggregateRating', 'reviewRating', 'location', 'hiringOrganization', 'baseSalary', 'acceptedAnswer'].includes(
    property,
  );
}

/* -------------------------------------------------------------------------- */
/* Per-type consistency                                                       */
/* -------------------------------------------------------------------------- */

function applyTypeChecks(
  typeName: string,
  actualType: string,
  node: ParsedNode,
  all: readonly ParsedNode[],
  issues: ValidationIssue[],
  now: Date,
): void {
  switch (typeName) {
    case 'BreadcrumbList':
      checkBreadcrumb(node, all, issues);
      break;
    case 'FAQPage':
      checkFaq(node, all, issues);
      break;
    case 'Product':
      checkProduct(node, all, issues);
      break;
    case 'Offer':
      checkOffer(node, issues);
      break;
    case 'Review':
      checkReview(node, all, issues);
      break;
    case 'AggregateRating':
      checkRating(node, issues, 'AggregateRating');
      break;
    case 'Organization':
    case 'LocalBusiness':
      checkOrganizationNode(node, issues);
      break;
    case 'Event':
      checkEvent(node, issues, now);
      break;
    case 'ItemList':
      checkItemList(node, all, issues);
      break;
    case 'VideoObject':
      checkVideo(node, issues);
      break;
    default:
      break;
  }
  void actualType;
}

/* ------------------------------------------------------------- breadcrumbs */

function checkBreadcrumb(
  node: ParsedNode,
  all: readonly ParsedNode[],
  issues: ValidationIssue[],
): void {
  const elements = childNodes(node, all, 'itemListElement');
  const inline = Array.isArray(node.properties['itemListElement'])
    ? (node.properties['itemListElement'] as JsonValue[])
    : node.properties['itemListElement'] !== undefined
      ? [node.properties['itemListElement'] as JsonValue]
      : [];

  const items = elements.length > 0 ? elements : [];
  if (items.length === 0 && inline.length === 0) return;

  const positions: number[] = [];
  const source = items.length > 0 ? items : [];

  source.forEach((item, index) => {
    const position = asNumber(firstScalar(item.properties['position']));
    const name = firstString(item.properties['name']);
    const itemValue = item.properties['item'];
    const isLast = index === source.length - 1;

    if (position === null) {
      issues.push({
        status: 'INVALID',
        dimension: 'SCHEMA_VALIDITY',
        check: 'breadcrumb_position_missing',
        path: `${item.path}.position`,
        property: 'position',
        type: 'ListItem',
        explanation: 'This breadcrumb item has no numeric "position", so the order of the trail is undefined.',
        correctedExample: '"position": 1',
      });
    } else {
      positions.push(position);
    }

    if (!name) {
      issues.push({
        status: 'INVALID',
        dimension: 'SCHEMA_VALIDITY',
        check: 'breadcrumb_name_missing',
        path: `${item.path}.name`,
        property: 'name',
        type: 'ListItem',
        explanation: 'This breadcrumb item is missing "name", which is the text shown for the step.',
        correctedExample: '"name": "Blog"',
      });
    }

    if (itemValue === undefined && !isLast) {
      issues.push({
        status: 'INVALID',
        dimension: 'SCHEMA_VALIDITY',
        check: 'breadcrumb_item_missing',
        path: `${item.path}.item`,
        property: 'item',
        type: 'ListItem',
        explanation:
          'This breadcrumb item has no "item" URL. Only the final item — the page itself — may omit it.',
        correctedExample: '"item": "https://example.com/blog"',
      });
    }
  });

  const sorted = [...positions].sort((a, b) => a - b);
  if (sorted.length > 0 && sorted[0] !== 1) {
    issues.push({
      status: 'INVALID',
      dimension: 'SCHEMA_VALIDITY',
      check: 'breadcrumb_position_start',
      path: node.path,
      property: 'position',
      type: 'BreadcrumbList',
      explanation: `Breadcrumb positions must start at 1; this trail starts at ${sorted[0]}.`,
    });
  }
  for (let index = 1; index < sorted.length; index += 1) {
    if (sorted[index]! !== sorted[index - 1]! + 1) {
      issues.push({
        status: 'INVALID',
        dimension: 'SCHEMA_VALIDITY',
        check: 'breadcrumb_position_sequence',
        path: node.path,
        property: 'position',
        type: 'BreadcrumbList',
        explanation: `Breadcrumb positions must increase by 1 with no gaps; this trail goes ${sorted.join(', ')}.`,
      });
      break;
    }
  }
}

/* -------------------------------------------------------------------- FAQ */

function checkFaq(node: ParsedNode, all: readonly ParsedNode[], issues: ValidationIssue[]): void {
  const questions = childNodes(node, all, 'mainEntity');
  if (questions.length === 0) return;

  for (const question of questions) {
    if (!question.types.includes('Question')) {
      issues.push({
        status: 'INVALID',
        dimension: 'SCHEMA_VALIDITY',
        check: 'faq_not_question',
        path: question.path,
        type: question.types.join(', ') || 'untyped',
        explanation: 'Every entry in a FAQPage "mainEntity" must be a Question.',
        correctedExample: '"@type": "Question"',
      });
      continue;
    }
    if (!firstString(question.properties['name'])) {
      issues.push({
        status: 'INVALID',
        dimension: 'SCHEMA_VALIDITY',
        check: 'faq_question_missing_name',
        path: `${question.path}.name`,
        property: 'name',
        type: 'Question',
        explanation: 'This Question has no "name", which is where the question text goes.',
        correctedExample: '"name": "How long does delivery take?"',
      });
    }

    const answerNodes = childNodes(question, all, 'acceptedAnswer');
    if (answerNodes.length === 0) {
      issues.push({
        status: 'INVALID',
        dimension: 'SCHEMA_VALIDITY',
        check: 'faq_missing_accepted_answer',
        path: `${question.path}.acceptedAnswer`,
        property: 'acceptedAnswer',
        type: 'Question',
        explanation: 'This Question has no "acceptedAnswer", so the answer is not in the markup at all.',
        correctedExample: '"acceptedAnswer": { "@type": "Answer", "text": "Two to four working days." }',
      });
      continue;
    }
    for (const answer of answerNodes) {
      const text = firstString(answer.properties['text']);
      if (!text) {
        issues.push({
          status: 'INVALID',
          dimension: 'SCHEMA_VALIDITY',
          check: 'faq_answer_missing_text',
          path: `${answer.path}.text`,
          property: 'text',
          type: 'Answer',
          explanation: 'This Answer is missing "text". An answer with no text answers nothing.',
          correctedExample: '"text": "Two to four working days."',
        });
      } else if (text.trim().length < 20) {
        issues.push({
          status: 'RECOMMENDATION',
          dimension: 'AEO_CLARITY',
          check: 'faq_answer_short',
          path: `${answer.path}.text`,
          property: 'text',
          type: 'Answer',
          explanation:
            'This answer is very short. An answer that stands on its own — a complete sentence with the subject named — is easier for an AI system to quote without distorting it.',
          found: preview(text),
        });
      }
    }
  }
}

/* ---------------------------------------------------------------- product */

function checkProduct(
  node: ParsedNode,
  all: readonly ParsedNode[],
  issues: ValidationIssue[],
): void {
  const offers = childNodes(node, all, 'offers');
  const currencies = new Set<string>();
  for (const offer of offers) {
    const currency = firstString(offer.properties['priceCurrency']);
    if (currency) currencies.add(currency.trim().toUpperCase());
  }
  if (currencies.size > 1) {
    issues.push({
      status: 'WARNING',
      dimension: 'SCHEMA_VALIDITY',
      check: 'product_currency_conflict',
      path: `${node.path}.offers`,
      property: 'priceCurrency',
      type: 'Product',
      explanation: `The offers on this product use more than one currency (${[...currencies].join(', ')}). Consumers generally read the first, so the price shown may not be the one you mean. Use an AggregateOffer, or one Offer per page.`,
    });
  }

  const productName = firstString(node.properties['name']);
  for (const offer of offers) {
    const offerName = firstString(offer.properties['name']);
    if (productName && offerName && normalize(productName) !== normalize(offerName)) {
      issues.push({
        status: 'RECOMMENDATION',
        dimension: 'SCHEMA_VALIDITY',
        check: 'product_offer_name_mismatch',
        path: `${offer.path}.name`,
        property: 'name',
        type: 'Offer',
        explanation: `The offer is named "${preview(offerName, 40)}" but the product is "${preview(productName, 40)}". If they are the same thing, drop the name from the offer rather than stating it twice.`,
      });
    }
  }

}

/* ------------------------------------------------------------------ offer */

function checkOffer(node: ParsedNode, issues: ValidationIssue[]): void {
  const hasPrice = hasValue(node, 'price');
  const hasSpecification = hasValue(node, 'priceSpecification');
  const hasLowHigh = hasValue(node, 'lowPrice') || hasValue(node, 'highPrice');

  if (!hasPrice && !hasSpecification && !hasLowHigh) {
    issues.push({
      status: 'INVALID',
      dimension: 'SCHEMA_VALIDITY',
      check: 'offer_no_price',
      path: node.path,
      type: 'Offer',
      explanation:
        'An Offer needs "price" (or a "priceSpecification"). An offer that states no price is not an offer.',
      correctedExample: '"price": "499.00", "priceCurrency": "INR"',
    });
  }

  if (hasPrice && !hasValue(node, 'priceCurrency')) {
    issues.push({
      status: 'INVALID',
      dimension: 'SCHEMA_VALIDITY',
      check: 'offer_no_currency',
      path: `${node.path}.priceCurrency`,
      property: 'priceCurrency',
      type: 'Offer',
      explanation:
        'This Offer has a price but no "priceCurrency", so the number is ambiguous — 499 could be rupees, dollars or anything else.',
      correctedExample: '"priceCurrency": "INR"',
    });
  }

  const price = asNumber(firstScalar(node.properties['price']));
  if (price !== null && price === 0) {
    issues.push({
      status: 'RECOMMENDATION',
      dimension: 'SCHEMA_VALIDITY',
      check: 'offer_zero_price',
      path: `${node.path}.price`,
      property: 'price',
      type: 'Offer',
      explanation:
        'The price is 0. If the item is genuinely free, that is correct; if the price is simply unknown, omit the offer rather than publishing zero.',
    });
  }
}

/* ----------------------------------------------------------------- review */

function checkReview(
  node: ParsedNode,
  all: readonly ParsedNode[],
  issues: ValidationIssue[],
): void {
  const ratings = childNodes(node, all, 'reviewRating');
  for (const rating of ratings) checkRating(rating, issues, 'Rating');

  if (!hasValue(node, 'itemReviewed') && !node.parent) {
    issues.push({
      status: 'WARNING',
      dimension: 'SCHEMA_VALIDITY',
      check: 'review_no_item',
      path: `${node.path}.itemReviewed`,
      property: 'itemReviewed',
      type: 'Review',
      explanation:
        'This Review stands on its own but does not say what was reviewed. Nest it inside the thing it reviews, or set "itemReviewed".',
      correctedExample: '"itemReviewed": { "@type": "Product", "name": "Example product" }',
    });
  }

  const authorNodes = childNodes(node, all, 'author');
  const authorText = firstString(node.properties['author']);
  if (authorNodes.length === 0 && !authorText) return;
  for (const author of authorNodes) {
    if (!firstString(author.properties['name'])) {
      issues.push({
        status: 'INVALID',
        dimension: 'SCHEMA_VALIDITY',
        check: 'review_author_unnamed',
        path: `${author.path}.name`,
        property: 'name',
        type: author.types[0] ?? 'Person',
        explanation: 'The review author has no "name". An unnamed author is not attribution.',
        correctedExample: '"name": "A. Mehta"',
      });
    }
  }
}

/* ----------------------------------------------------------------- rating */

function checkRating(node: ParsedNode, issues: ValidationIssue[], label: string): void {
  const value = asNumber(firstScalar(node.properties['ratingValue']));
  const best = asNumber(firstScalar(node.properties['bestRating']));
  const worst = asNumber(firstScalar(node.properties['worstRating']));

  if (value === null) return;

  const effectiveBest = best ?? 5;
  const effectiveWorst = worst ?? 1;

  if (value > effectiveBest) {
    issues.push({
      status: 'INVALID',
      dimension: 'SCHEMA_VALIDITY',
      check: 'rating_above_best',
      path: `${node.path}.ratingValue`,
      property: 'ratingValue',
      type: label,
      explanation: best === null
        ? `The rating is ${value}, but with no "bestRating" the scale is assumed to be 5. Set "bestRating" if the scale is different.`
        : `The rating is ${value}, which is above the stated "bestRating" of ${best}.`,
      correctedExample: '"ratingValue": "4.6", "bestRating": "5"',
      found: String(value),
    });
  }
  if (value < effectiveWorst) {
    issues.push({
      status: 'INVALID',
      dimension: 'SCHEMA_VALIDITY',
      check: 'rating_below_worst',
      path: `${node.path}.ratingValue`,
      property: 'ratingValue',
      type: label,
      explanation: `The rating is ${value}, which is below the ${worst === null ? 'assumed' : 'stated'} "worstRating" of ${effectiveWorst}.`,
      found: String(value),
    });
  }
  if (best !== null && worst !== null && best <= worst) {
    issues.push({
      status: 'INVALID',
      dimension: 'SCHEMA_VALIDITY',
      check: 'rating_scale_inverted',
      path: node.path,
      type: label,
      explanation: `"bestRating" (${best}) must be greater than "worstRating" (${worst}).`,
    });
  }

  if (label === 'AggregateRating') {
    const count = asNumber(firstScalar(node.properties['ratingCount'])) ??
      asNumber(firstScalar(node.properties['reviewCount']));
    if (count !== null && count <= 0) {
      issues.push({
        status: 'INVALID',
        dimension: 'SCHEMA_VALIDITY',
        check: 'rating_count_zero',
        path: node.path,
        property: 'ratingCount',
        type: label,
        explanation: 'An aggregate rating based on zero ratings is not an aggregate of anything.',
      });
    }
  }
}

/**
 * The honesty rule, carried forward from Phase 1 and applied to Phase 5's wider
 * type set.
 *
 * Ratings and reviews in markup are the most commonly falsified structured data
 * there is, and the consequence falls on the user, not on us. So any node
 * publishing a rating gets a written warning that the figure must reflect
 * genuine reviews — and SeSha's own generator refuses to produce one at all.
 */
function checkRatingHonesty(node: ParsedNode, issues: ValidationIssue[], label: string): void {
  const hasRating = hasValue(node, 'aggregateRating');
  const hasReview = hasValue(node, 'review') || hasValue(node, 'reviews');
  if (!hasRating && !hasReview) return;

  issues.push({
    status: 'WARNING',
    dimension: 'SEARCH_ELIGIBILITY',
    check: 'rating_must_be_genuine',
    path: node.path,
    type: label,
    explanation:
      'This markup publishes ratings or reviews. They must reflect genuine reviews collected from real customers and be visible on the page itself; inventing them breaches every search engine\'s policy and is the kind of thing that gets structured data ignored site-wide. SeSha will never generate a rating for you.',
  });
}

/* ----------------------------------------------------------- organization */

function checkOrganizationNode(node: ParsedNode, issues: ValidationIssue[]): void {
  const logo = node.properties['logo'];
  if (logo !== undefined && typeof logo === 'object' && logo !== null && !Array.isArray(logo)) {
    const contentUrl = firstString((logo as Record<string, JsonValue>)['url']) ??
      firstString((logo as Record<string, JsonValue>)['contentUrl']);
    if (!contentUrl) {
      issues.push({
        status: 'INVALID',
        dimension: 'SCHEMA_VALIDITY',
        check: 'logo_no_url',
        path: `${node.path}.logo`,
        property: 'logo',
        type: node.types[0],
        explanation:
          'The logo is an ImageObject with no "url" or "contentUrl", so there is no image to fetch.',
        correctedExample: '"logo": { "@type": "ImageObject", "url": "https://example.com/logo.png" }',
      });
    }
  }

  const telephone = firstString(node.properties['telephone']);
  if (telephone && !/^\+?[\d][\d\s\-().]{5,}$/.test(telephone.trim())) {
    issues.push({
      status: 'WARNING',
      dimension: 'SCHEMA_VALIDITY',
      check: 'telephone_shape',
      path: `${node.path}.telephone`,
      property: 'telephone',
      type: node.types[0],
      explanation:
        'The telephone number does not look like a dialable number. Include the country code, for example +91-712-000-0000.',
      found: preview(telephone),
    });
  }
}

/**
 * Two Organization nodes describing the same organization differently.
 *
 * This is the single most common cause of a knowledge panel showing the wrong
 * name: the Organization in the site-wide graph says one thing and the publisher
 * on each article says another.
 */
function checkOrganizationConsistency(
  nodes: readonly ParsedNode[],
  issues: ValidationIssue[],
): void {
  const organizations = nodes.filter(
    (node) =>
      (node.types.includes('Organization') || node.types.includes('LocalBusiness')) &&
      // An article's author may legitimately be a different organization from its
      // publisher (an editorial team, a guest contributor, an agency), so author
      // nodes are not part of the "is the site's organization described
      // consistently" question.
      roleOf(node) !== 'author',
  );
  const named = organizations
    .map((node) => ({ node, name: firstString(node.properties['name']) }))
    .filter((entry): entry is { node: ParsedNode; name: string } => Boolean(entry.name));

  const distinct = new Map<string, ParsedNode[]>();
  for (const entry of named) {
    const key = normalize(entry.name);
    const existing = distinct.get(key);
    if (existing) existing.push(entry.node);
    else distinct.set(key, [entry.node]);
  }

  if (distinct.size > 1) {
    const names = named.map((entry) => entry.name);
    issues.push({
      status: 'WARNING',
      dimension: 'SCHEMA_VALIDITY',
      check: 'organization_name_conflict',
      path: '$',
      property: 'name',
      type: 'Organization',
      explanation: `This page describes more than one organization name (${quoteList([...new Set(names)].slice(0, 4))}). If they are the same organization, use one name and one "@id" everywhere; if they are genuinely different, link them with "parentOrganization" so the relationship is stated.`,
    });
  }

  const logos = new Set(
    organizations
      .map((node) => firstString(node.properties['logo']))
      .filter((value): value is string => Boolean(value))
      .map((value) => value.trim()),
  );
  if (logos.size > 1) {
    issues.push({
      status: 'WARNING',
      dimension: 'SCHEMA_VALIDITY',
      check: 'organization_logo_conflict',
      path: '$',
      property: 'logo',
      type: 'Organization',
      explanation:
        'Different logo URLs are published for the organization on this page. Publish one logo so a consumer does not have to choose.',
    });
  }
}

/* ------------------------------------------------------------------ event */

function checkEvent(node: ParsedNode, issues: ValidationIssue[], now: Date): void {
  const start = firstString(node.properties['startDate']);
  const end = firstString(node.properties['endDate']);
  if (start && end) {
    const delta = compareDates(end, start);
    if (delta !== null && delta < 0) {
      issues.push({
        status: 'INVALID',
        dimension: 'SCHEMA_VALIDITY',
        check: 'event_dates_out_of_order',
        path: `${node.path}.endDate`,
        property: 'endDate',
        type: 'Event',
        explanation: `"endDate" (${end}) is before "startDate" (${start}).`,
      });
    }
  }
  if (start) {
    const parsed = new Date(start);
    if (!Number.isNaN(parsed.getTime()) && parsed.getTime() < now.getTime()) {
      issues.push({
        status: 'RECOMMENDATION',
        dimension: 'SEO_GUIDANCE',
        check: 'event_in_past',
        path: `${node.path}.startDate`,
        property: 'startDate',
        type: 'Event',
        explanation: `This event started on ${start}, which has passed. Past events are fine to keep published, but make sure the page says so.`,
      });
    }
  }
}

/* --------------------------------------------------------------- itemlist */

function checkItemList(
  node: ParsedNode,
  all: readonly ParsedNode[],
  issues: ValidationIssue[],
): void {
  const items = childNodes(node, all, 'itemListElement');
  const declared = asNumber(firstScalar(node.properties['numberOfItems']));
  if (declared !== null && items.length > 0 && declared !== items.length) {
    issues.push({
      status: 'WARNING',
      dimension: 'SCHEMA_VALIDITY',
      check: 'itemlist_count_mismatch',
      path: `${node.path}.numberOfItems`,
      property: 'numberOfItems',
      type: 'ItemList',
      explanation: `"numberOfItems" says ${declared} but ${items.length} items are listed.`,
      found: String(declared),
    });
  }
}

/* ------------------------------------------------------------------ video */

function checkVideo(node: ParsedNode, issues: ValidationIssue[]): void {
  if (!hasValue(node, 'contentUrl') && !hasValue(node, 'embedUrl')) {
    issues.push({
      status: 'WARNING',
      dimension: 'SEARCH_ELIGIBILITY',
      check: 'video_no_source',
      path: node.path,
      type: 'VideoObject',
      explanation:
        'This VideoObject has neither "contentUrl" nor "embedUrl", so there is no way for a consumer to reach the video itself.',
      correctedExample: '"embedUrl": "https://example.com/embed/abc"',
    });
  }
  if (!hasValue(node, 'transcript')) {
    // Already emitted as an AEO recommendation by the registry; nothing here.
  }
}

/* -------------------------------------------------------------------------- */
/* Document-level                                                             */
/* -------------------------------------------------------------------------- */

function checkDuplicateIds(nodes: readonly ParsedNode[], issues: ValidationIssue[]): void {
  const byId = new Map<string, ParsedNode[]>();
  for (const node of nodes) {
    if (!node.id) continue;
    if (isReferenceOnly(node)) continue;
    const key = node.id.trim();
    const existing = byId.get(key);
    if (existing) existing.push(node);
    else byId.set(key, [node]);
  }

  for (const [id, group] of byId) {
    if (group.length < 2) continue;
    const types = new Set(group.flatMap((node) => node.types));
    issues.push({
      status: 'INVALID',
      dimension: 'SCHEMA_VALIDITY',
      check: 'duplicate_id',
      path: group[1]!.path,
      property: '@id',
      type: [...types].join(', '),
      explanation: `Duplicate "@id": ${group.length} nodes share the identifier "${preview(id, 60)}". An "@id" names one thing, so a consumer cannot tell which of these is the real one.`,
      found: preview(id, 60),
    });

    if (types.size > 1) {
      issues.push({
        status: 'INVALID',
        dimension: 'SCHEMA_VALIDITY',
        check: 'id_type_conflict',
        path: group[1]!.path,
        property: '@id',
        explanation: `The nodes sharing "${preview(id, 40)}" have different types (${[...types].join(', ')}). One identifier cannot be two kinds of thing.`,
      });
    }
  }
}

/**
 * The same entity described twice — typically once in JSON-LD and again in
 * Microdata, because a theme emits one and a plugin emits the other.
 *
 * Reported as a WARNING rather than an error: duplicate markup is valid, and
 * which copy wins is the consumer's choice. The risk is that the two disagree,
 * so the explanation says exactly that.
 */
function checkDuplicateEntities(nodes: readonly ParsedNode[], issues: ValidationIssue[]): void {
  interface Seen {
    readonly node: ParsedNode;
    readonly name: string;
  }
  const byKey = new Map<string, Seen[]>();

  for (const node of nodes) {
    if (node.types.length === 0) continue;
    const name = firstString(node.properties['name']) ?? firstString(node.properties['headline']);
    if (!name) continue;
    const key = `${node.types.slice().sort().join('+')}::${normalize(name)}`;
    const existing = byKey.get(key);
    if (existing) existing.push({ node, name });
    else byKey.set(key, [{ node, name }]);
  }

  for (const [, group] of byKey) {
    if (group.length < 2) continue;
    const syntaxes = new Set(group.map((entry) => entry.node.syntax));
    const first = group[0]!;

    if (syntaxes.size > 1) {
      issues.push({
        status: 'WARNING',
        dimension: 'SCHEMA_VALIDITY',
        check: 'duplicate_entity_across_syntaxes',
        path: group[1]!.node.path,
        type: first.node.types.join(', '),
        explanation: `"${preview(first.name, 40)}" is described in both ${[...syntaxes].join(' and ')}. Two copies can disagree, and a consumer picks one without telling you which. Publish one.`,
      });
    } else {
      issues.push({
        status: 'WARNING',
        dimension: 'SCHEMA_VALIDITY',
        check: 'duplicate_entity',
        path: group[1]!.node.path,
        type: first.node.types.join(', '),
        explanation: `${group.length} ${first.node.types.join(', ')} nodes describe "${preview(first.name, 40)}". Give the entity one node and one "@id", and refer to it from elsewhere.`,
      });
    }

    // Conflicting values for the same entity are the real risk; name them.
    const conflicts = findConflicts(group.map((entry) => entry.node));
    for (const property of conflicts) {
      issues.push({
        status: 'WARNING',
        dimension: 'SCHEMA_VALIDITY',
        check: 'duplicate_entity_conflict',
        path: group[1]!.node.path,
        property,
        type: first.node.types.join(', '),
        explanation: `The copies of "${preview(first.name, 40)}" give different values for "${property}". At most one can be right.`,
      });
    }
  }
}

/** Properties where two nodes for the same entity state different values. */
function findConflicts(group: readonly ParsedNode[]): string[] {
  const conflicts: string[] = [];
  const interesting = ['url', 'telephone', 'logo', 'image', 'datePublished', 'price', 'priceCurrency'];
  for (const property of interesting) {
    const values = new Set(
      group
        .map((node) => firstString(node.properties[property]))
        .filter((value): value is string => Boolean(value))
        .map((value) => value.trim()),
    );
    if (values.size > 1) conflicts.push(property);
  }
  return conflicts;
}

/**
 * The canonical check.
 *
 * Only runs when the caller supplied the page's canonical URL, because it cannot
 * be inferred from the structured data. When it is absent the check is reported
 * as NOT_EVALUATED rather than passed over in silence — see `addNotEvaluated`.
 */
function checkCanonical(
  nodes: readonly ParsedNode[],
  issues: ValidationIssue[],
  canonicalUrl?: string,
): void {
  if (!canonicalUrl) return;
  const canonical = canonicalUrl.trim().replace(/\/$/, '');

  for (const node of nodes) {
    const isPage = node.types.includes('WebPage') || ARTICLE_TYPES.some((type) => node.types.includes(type));
    if (!isPage) continue;

    const url = firstString(node.properties['url']);
    if (url && url.trim().replace(/\/$/, '') !== canonical) {
      issues.push({
        status: 'WARNING',
        dimension: 'SEARCH_ELIGIBILITY',
        check: 'canonical_mismatch',
        path: `${node.path}.url`,
        property: 'url',
        type: node.types[0],
        explanation: `The "url" here is ${preview(url, 60)} but the page's canonical URL is ${preview(canonical, 60)}. When they disagree, a consumer may attribute this markup to a different page.`,
        found: preview(url, 60),
        correctedExample: `"url": "${canonical}"`,
      });
    }

    const mainEntity = firstString(node.properties['mainEntityOfPage']);
    if (mainEntity && !mainEntity.includes(canonical)) {
      issues.push({
        status: 'RECOMMENDATION',
        dimension: 'SEARCH_ELIGIBILITY',
        check: 'main_entity_mismatch',
        path: `${node.path}.mainEntityOfPage`,
        property: 'mainEntityOfPage',
        type: node.types[0],
        explanation:
          '"mainEntityOfPage" does not point at the canonical URL of this page, which is what it is for.',
        found: preview(mainEntity, 60),
      });
    }
  }
}

/**
 * What was deliberately not checked.
 *
 * NOT_EVALUATED exists so the absence of a finding never reads as a pass. Every
 * entry here is a real limit: a check that needs a network request, a rendered
 * page, or information only the search engine has.
 */
function addNotEvaluated(
  issues: ValidationIssue[],
  nodes: readonly ParsedNode[],
  input: ValidateInput,
): void {
  const hasImage = nodes.some(
    (node) => hasValue(node, 'image') || hasValue(node, 'logo') || hasValue(node, 'thumbnailUrl'),
  );
  if (hasImage) {
    issues.push({
      status: 'NOT_EVALUATED',
      dimension: 'SEARCH_ELIGIBILITY',
      check: 'image_not_fetched',
      path: '$',
      property: 'image',
      explanation:
        'Image URLs were checked as URLs but not fetched, so their size, aspect ratio, format and whether they load at all were not checked. Published requirements include minimum dimensions.',
    });
  }

  if (!input.canonicalUrl) {
    issues.push({
      status: 'NOT_EVALUATED',
      dimension: 'SEARCH_ELIGIBILITY',
      check: 'canonical_unknown',
      path: '$',
      explanation:
        'The page\'s canonical URL was not supplied, so this run could not check the markup against it. Validate a page URL rather than pasted markup and this check runs.',
    });
  }

  issues.push({
    status: 'NOT_EVALUATED',
    dimension: 'SEARCH_ELIGIBILITY',
    check: 'rich_result_not_predicted',
    path: '$',
    explanation:
      'Whether a search engine shows a rich result for this page was not evaluated, and cannot be: that decision is made by the search engine using signals this tool does not have. This validator checks the markup against published requirements only.',
  });

  issues.push({
    status: 'NOT_EVALUATED',
    dimension: 'AEO_CLARITY',
    check: 'ai_citation_not_measured',
    path: '$',
    explanation:
      'Whether an AI system reads or cites this page was not measured, and no tool can measure it. The AEO findings are about whether your facts are stated unambiguously in the markup.',
  });

  if (input.sourceKind === 'pasted') {
    issues.push({
      status: 'NOT_EVALUATED',
      dimension: 'SCHEMA_VALIDITY',
      check: 'page_context_unknown',
      path: '$',
      explanation:
        'This was pasted markup, so whether the facts in it match what the page actually shows was not checked. Structured data must describe content visible on the page.',
    });
  }
}

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function hasValue(node: ParsedNode, property: string): boolean {
  const value = node.properties[property];
  if (value === undefined || value === null) return false;
  if (typeof value === 'string') return value.trim().length > 0;
  if (Array.isArray(value)) return value.length > 0;
  if (typeof value === 'object') return Object.keys(value).length > 0;
  return true;
}

function isNestedReference(value: JsonValue): boolean {
  return (
    typeof value === 'object' &&
    value !== null &&
    !Array.isArray(value) &&
    '@nested' in (value as Record<string, JsonValue>)
  );
}

function firstString(value: JsonValue | undefined): string | undefined {
  if (typeof value === 'string') return value;
  if (Array.isArray(value)) {
    for (const entry of value) {
      if (typeof entry === 'string') return entry;
    }
    return undefined;
  }
  if (typeof value === 'object' && value !== null) {
    const record = value as Record<string, JsonValue>;
    const url = record['url'] ?? record['contentUrl'] ?? record['@id'];
    return typeof url === 'string' ? url : undefined;
  }
  return undefined;
}

function firstScalar(value: JsonValue | undefined): JsonValue | undefined {
  if (Array.isArray(value)) return value[0];
  return value;
}

/** Child nodes of `node` that came from a given property. */
function childNodes(
  node: ParsedNode,
  all: readonly ParsedNode[],
  property: string,
): ParsedNode[] {
  const prefix = `${node.path}.${property}`;
  return all.filter(
    (candidate) =>
      candidate.parent === node.path &&
      (candidate.path === prefix || candidate.path.startsWith(`${prefix}[`)),
  );
}

function toEntity(node: ParsedNode): SchemaEntity {
  return {
    path: node.path,
    types: node.types,
    ...(node.id ? { id: node.id } : {}),
    syntax: node.syntax,
    supported: node.types.some((type) => rulesFor(type) !== null),
    propertyCount: Object.keys(node.properties).length,
  };
}

function uniqueTypes(nodes: readonly ParsedNode[]): string[] {
  const seen: string[] = [];
  for (const node of nodes) {
    for (const type of node.types) {
      if (!seen.includes(type)) seen.push(type);
    }
  }
  return seen;
}

function dedupe(values: readonly string[]): string[] {
  return [...new Set(values)];
}

function normalize(value: string): string {
  return value.trim().toLowerCase().replace(/\s+/g, ' ');
}

function quoteList(values: readonly string[]): string {
  return values.map((value) => `"${value}"`).join(', ');
}

function jsonish(example: string): string {
  return example.trim().startsWith('{') ? example : `"${example}"`;
}

function exampleFor(property: string): { readonly correctedExample?: string } {
  const rule = PROPERTY_RULES[property];
  if (!rule) return {};
  return { correctedExample: `"${property}": ${jsonish(rule.example)}` };
}

/** The types this engine has rules for. Re-exported for the interface. */
export const SUPPORTED_TYPES = SUPPORTED_SCHEMA_TYPES;
