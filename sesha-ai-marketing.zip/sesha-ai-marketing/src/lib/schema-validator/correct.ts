/**
 * Corrected JSON-LD: the "here is what right looks like" half of a finding.
 *
 * THE LINE THIS FILE DOES NOT CROSS
 * A corrected document is only useful if the user can paste it. That creates an
 * obvious temptation: fill in the missing properties so the output looks
 * complete. Doing that would publish invented facts under the user's name on
 * their own website, which is the worst version of the thing this whole project
 * is built to avoid.
 *
 * So the rules are:
 *  1. A value is only ever CHANGED when the correct value is derivable — a
 *     missing "@context", an enum spelled without its schema.org prefix, a
 *     relative URL where the page URL is known.
 *  2. A MISSING property becomes a visibly fake placeholder —
 *     `"<add the headline here>"` — never a plausible value. A placeholder that
 *     looks like data is worse than no suggestion at all, because it gets
 *     published.
 *  3. Reviews, ratings, prices, availability, awards, certifications and
 *     credentials are NEVER added, not even as a placeholder. They are the
 *     properties people fake, and a placeholder shaped like
 *     `"ratingValue": "<add>"` is one careless find-and-replace away from a
 *     fabricated rating. The output says they were deliberately left out.
 *
 * Framework-free and fully unit tested.
 */

import { preview } from './datatypes';
import { extractJsonLdBlocks, type JsonValue } from './parse';
import { PROPERTY_RULES, isNeverInvent } from './registry';
import type { ValidationIssue, ValidationResult } from './types';

export interface CorrectionRefusal {
  readonly property: string;
  readonly why: string;
}

export interface Correction {
  /** True when anything could be suggested at all. */
  readonly available: boolean;
  /** The original document, pretty-printed when it parsed. */
  readonly before: string;
  /** The suggested document. Equal to `before` when nothing could be changed. */
  readonly after: string;
  /** One line per change, in the order applied. */
  readonly changes: readonly string[];
  /** Properties deliberately not filled in, and why. */
  readonly refusals: readonly CorrectionRefusal[];
  /** Placeholders the user must replace before publishing. */
  readonly placeholders: readonly string[];
  /** Why no correction could be offered, when `available` is false. */
  readonly unavailableReason?: string;
}

const PLACEHOLDER_PREFIX = '<add ';

export function placeholderFor(property: string): string {
  const rule = PROPERTY_RULES[property];
  const hint = rule ? ` — for example ${stripQuotes(rule.example)}` : '';
  return `${PLACEHOLDER_PREFIX}${property}${hint}>`;
}

export function isPlaceholder(value: unknown): boolean {
  return typeof value === 'string' && value.startsWith(PLACEHOLDER_PREFIX);
}

/**
 * Builds a corrected document from a validation result.
 *
 * Works on JSON-LD only. Microdata and RDFa corrections would mean rewriting the
 * user's HTML, and a tool that rewrites markup it parsed with regular
 * expressions will eventually corrupt a page — so for those syntaxes this
 * returns `available: false` with the reason, rather than a guess.
 */
export function buildCorrection(
  source: string,
  result: ValidationResult,
  options: { readonly pageUrl?: string } = {},
): Correction {
  const blocks = extractJsonLdBlocks(source);
  if (blocks.length === 0) {
    return unavailable(
      source,
      result.syntaxes.length > 0
        ? `A corrected document is only generated for JSON-LD. This page uses ${result.syntaxes.join(' and ')}, and rewriting your HTML automatically is not something this tool will do.`
        : 'There is no JSON-LD here to correct.',
    );
  }

  const block = blocks[0]!;
  let parsed: JsonValue;
  try {
    parsed = JSON.parse(block.text) as JsonValue;
  } catch {
    return unavailable(
      source,
      'The JSON could not be parsed, so there is nothing to build on. Fix the syntax error first and validate again.',
    );
  }

  const changes: string[] = [];
  const refusals: CorrectionRefusal[] = [];
  const placeholders: string[] = [];

  const working = structuredClone(parsed) as JsonValue;

  /* ------------------------------------------------------------- @context */
  if (isObject(working) && working['@context'] === undefined && working['@graph'] === undefined) {
    working['@context'] = 'https://schema.org';
    changes.push('Added "@context": "https://schema.org".');
  } else if (isObject(working) && typeof working['@context'] === 'string') {
    const context = working['@context'];
    if (/schema\.org/i.test(context) && !/^https:\/\/schema\.org$/.test(context)) {
      working['@context'] = 'https://schema.org';
      changes.push(`Normalised "@context" from "${preview(context, 40)}" to "https://schema.org".`);
    }
  }

  /* ----------------------------------------------------- per-issue fixes */
  for (const issue of result.issues) {
    applyIssue(working, issue, { changes, refusals, placeholders, pageUrl: options.pageUrl });
  }

  const after = JSON.stringify(working, null, 2);
  const before = JSON.stringify(parsed, null, 2);

  return {
    available: changes.length > 0 || placeholders.length > 0,
    before,
    after,
    changes,
    refusals: dedupeRefusals(refusals),
    placeholders: [...new Set(placeholders)],
    ...(changes.length === 0 && placeholders.length === 0
      ? { unavailableReason: 'Nothing could be corrected mechanically — the remaining findings need a human decision about what the right value is.' }
      : {}),
  };
}

interface Accumulator {
  readonly changes: string[];
  readonly refusals: CorrectionRefusal[];
  readonly placeholders: string[];
  readonly pageUrl?: string;
}

function applyIssue(document: JsonValue, issue: ValidationIssue, acc: Accumulator): void {
  const property = issue.property;
  if (!property || property.startsWith('@')) return;

  /* --------------------------------------------- the properties we refuse */
  if (isNeverInvent(property)) {
    acc.refusals.push({
      property,
      why:
        'SeSha never fills in reviews, ratings, prices, availability, awards, certifications or credentials. These must come from your own records, published exactly as they are.',
    });
    return;
  }

  const target = resolveNode(document, issue.path);
  if (!target) return;

  switch (issue.check) {
    case 'required_property_missing':
    case 'search_property_missing':
    case 'recommended_property_missing':
    case 'aeo_property_missing': {
      if (target[property] !== undefined) return;
      const placeholder = placeholderFor(property);
      target[property] = placeholder;
      acc.placeholders.push(property);
      acc.changes.push(`Added "${property}" as a placeholder for you to fill in.`);
      return;
    }
    case 'enum_spelling': {
      const rule = PROPERTY_RULES[property];
      if (!rule || typeof target[property] !== 'string') return;
      target[property] = stripQuotes(rule.example);
      acc.changes.push(`Rewrote "${property}" using the schema.org spelling.`);
      return;
    }
    case 'data_type_invalid': {
      const current = target[property];
      // A relative URL is the one data-type error with a derivable fix.
      if (typeof current === 'string' && acc.pageUrl && isRelative(current)) {
        try {
          target[property] = new URL(current, acc.pageUrl).toString();
          acc.changes.push(`Made "${property}" absolute using the page URL.`);
        } catch {
          /* leave it alone rather than write something wrong */
        }
      }
      return;
    }
    case 'deprecated_property': {
      const replacement = deprecatedReplacement(issue.explanation);
      if (!replacement) return;
      const current = target[property];
      if (current === undefined || target[replacement] !== undefined) return;
      target[replacement] = current;
      delete target[property];
      acc.changes.push(`Renamed "${property}" to "${replacement}".`);
      return;
    }
    default:
      return;
  }
}

/** Pulls the replacement name out of the deprecation explanation. */
function deprecatedReplacement(explanation: string): string | null {
  const match = /superseded by "([A-Za-z]+)"/.exec(explanation);
  return match?.[1] ?? null;
}

/**
 * Walks a dotted path to the node that owns a property.
 *
 * Paths come from the parser, so they are of the forms `$`, `script[0]`,
 * `$.@graph[2]`, `$.author`, `$.@graph[1].author.name`. The final segment is the
 * property itself and is dropped: the caller wants the object to write into.
 */
function resolveNode(document: JsonValue, path: string): Record<string, JsonValue> | null {
  const segments = path
    .replace(/^\$\.?/, '')
    .replace(/^script\[\d+\]\.?/, '')
    .split('.')
    .filter((segment) => segment.length > 0);

  let current: JsonValue = document;
  // The last segment is the property name in every path the engine emits for a
  // property-level finding; node-level findings end at the node itself.
  for (let index = 0; index < segments.length; index += 1) {
    const segment = segments[index]!;
    const isLast = index === segments.length - 1;
    const match = /^([^[]*)((\[\d+\])*)$/.exec(segment);
    if (!match) return null;
    const key = match[1] ?? '';
    const indexes = [...(match[2] ?? '').matchAll(/\[(\d+)\]/g)].map((entry) => Number(entry[1]));

    if (isLast && indexes.length === 0) {
      // `…​.author` — the owner is `current`, unless the segment names an
      // existing object, in which case the finding is about that object.
      if (isObject(current)) {
        const owned = current[key];
        if (owned !== undefined && isObject(owned)) return owned;
      }
      return isObject(current) ? current : null;
    }

    if (key.length > 0) {
      if (!isObject(current)) return null;
      const next = current[key];
      if (next === undefined) return null;
      current = next;
    }
    for (const position of indexes) {
      if (!Array.isArray(current)) return null;
      const next = current[position];
      if (next === undefined) return null;
      current = next;
    }
  }

  return isObject(current) ? current : null;
}

function unavailable(source: string, reason: string): Correction {
  return {
    available: false,
    before: source,
    after: source,
    changes: [],
    refusals: [],
    placeholders: [],
    unavailableReason: reason,
  };
}

function isObject(value: JsonValue): value is { [key: string]: JsonValue } {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isRelative(value: string): boolean {
  return value.startsWith('/') || value.startsWith('./') || value.startsWith('../');
}

function stripQuotes(example: string): string {
  const trimmed = example.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"')) return trimmed.slice(1, -1);
  return trimmed;
}

function dedupeRefusals(refusals: readonly CorrectionRefusal[]): CorrectionRefusal[] {
  const seen = new Map<string, CorrectionRefusal>();
  for (const refusal of refusals) {
    if (!seen.has(refusal.property)) seen.set(refusal.property, refusal);
  }
  return [...seen.values()];
}

/**
 * A one-line summary of the difference between two documents, for the history
 * view. Not a character diff: what matters is which findings changed.
 */
export function compareResults(
  previous: ValidationResult,
  current: ValidationResult,
): {
  readonly fixed: readonly ValidationIssue[];
  readonly introduced: readonly ValidationIssue[];
  readonly unchanged: number;
  readonly versionChanged: boolean;
  readonly summary: string;
} {
  const key = (issue: ValidationIssue): string => `${issue.check}::${issue.path}::${issue.property ?? ''}`;
  const before = new Map(previous.issues.map((issue) => [key(issue), issue]));
  const after = new Map(current.issues.map((issue) => [key(issue), issue]));

  const fixed = [...before.entries()].filter(([id]) => !after.has(id)).map(([, issue]) => issue);
  const introduced = [...after.entries()].filter(([id]) => !before.has(id)).map(([, issue]) => issue);
  const unchanged = [...after.keys()].filter((id) => before.has(id)).length;
  const versionChanged = previous.validatorVersion !== current.validatorVersion;

  const parts: string[] = [];
  if (fixed.length > 0) parts.push(`${fixed.length} resolved`);
  if (introduced.length > 0) parts.push(`${introduced.length} new`);
  if (parts.length === 0) parts.push('no change');

  return {
    fixed,
    introduced,
    unchanged,
    versionChanged,
    summary: versionChanged
      ? `${parts.join(', ')} — note the validator itself changed from ${previous.validatorVersion} to ${current.validatorVersion}, so some of this difference may be a rule change rather than a change to your markup.`
      : parts.join(', '),
  };
}
