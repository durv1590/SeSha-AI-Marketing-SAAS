/**
 * The Phase 1 validator's interface, now backed by the Phase 5 engine.
 *
 * WHY THIS FILE STILL EXISTS
 * The public tool at /schema-validator and the workspace screen both shipped
 * against this shape — `{ valid, parsed, typesFound, nodeCount, messages,
 * counts }` with `error | warning | info` severities. Phase 5 replaced the
 * engine underneath with one that knows three syntaxes, twenty-four types and,
 * most importantly, which DIMENSION each finding belongs to.
 *
 * Keeping this adapter rather than forking the validator is deliberate. Two
 * validators would answer the same question two ways, and the first time they
 * disagreed a user would be right to treat both as unreliable. So there is one
 * engine, and this file is a projection of it.
 *
 * WHAT IS LOST IN THE PROJECTION, AND WHY THAT IS ACCEPTABLE HERE
 * A severity cannot express a dimension. `error | warning | info` flattens
 * "this is not valid JSON" and "published search requirements ask for an image"
 * into the same axis, which is exactly the conflation Phase 5 exists to undo. So
 * the mapping below is lossy ON PURPOSE and only the public one-field tool uses
 * it; every authenticated surface uses `validateSchema` and renders the four
 * dimensions separately.
 *
 * The mapping:
 *   INVALID         -> error     (the markup is wrong)
 *   WARNING         -> warning   (something will probably not work as intended)
 *   RECOMMENDATION  -> info      (optional improvement)
 *   UNSUPPORTED     -> info      (we did not check it; not a fault)
 *   NOT_EVALUATED   -> info      (we could not check it; not a fault)
 */

import { validateSchema } from './engine';
import { SUPPORTED_SCHEMA_TYPES } from './registry';
import type { ValidationStatus } from './types';

export type Severity = 'error' | 'warning' | 'info';

export interface ValidationMessage {
  readonly severity: Severity;
  /** Dotted path to the offending node, e.g. "@graph[1].author". */
  readonly path: string;
  readonly type?: string;
  readonly message: string;
}

export interface ValidationReport {
  readonly valid: boolean;
  readonly parsed: boolean;
  readonly typesFound: readonly string[];
  readonly nodeCount: number;
  readonly messages: readonly ValidationMessage[];
  readonly counts: { readonly errors: number; readonly warnings: number; readonly infos: number };
}

/** The types the validator has rules for. */
export const SUPPORTED_TYPES: readonly string[] = SUPPORTED_SCHEMA_TYPES;

function toSeverity(status: ValidationStatus): Severity {
  switch (status) {
    case 'INVALID':
      return 'error';
    case 'WARNING':
      return 'warning';
    default:
      return 'info';
  }
}

/**
 * Validates a JSON-LD document — or an HTML page containing one.
 *
 * Kept synchronous and side-effect free: the public endpoint validates and
 * discards, which is what the privacy page promises.
 */
export function validateJsonLd(source: string): ValidationReport {
  const result = validateSchema({ source, sourceKind: 'pasted' });

  const messages: ValidationMessage[] = result.issues
    // The NOT_EVALUATED notes are valuable in the dimensioned view and noise in
    // a flat list of "messages": a one-field tool that answers "is my markup
    // valid" should not open with four paragraphs about what it did not check.
    .filter((issue) => issue.status !== 'NOT_EVALUATED')
    .map((issue) => ({
      severity: toSeverity(issue.status),
      path: issue.path,
      ...(issue.type ? { type: issue.type } : {}),
      message: issue.correctedExample
        ? `${issue.explanation} Expected form: ${issue.correctedExample}`
        : issue.explanation,
    }));

  // Parsed JSON with no node in it (`null`, `[]`, `42`) has nothing to be valid
  // ABOUT. Reporting "No errors found" for it would be a verdict on nothing.
  if (result.parsed && result.entities.length === 0) {
    messages.push({
      severity: 'error',
      path: '$',
      message:
        'No schema.org node was found. JSON-LD must contain at least one object with an "@type". Expected form: { "@context": "https://schema.org", "@type": "Organization", "name": "Example" }',
    });
  }

  const errors = messages.filter((message) => message.severity === 'error').length;
  const warnings = messages.filter((message) => message.severity === 'warning').length;
  const infos = messages.filter((message) => message.severity === 'info').length;

  return {
    valid: errors === 0 && result.parsed,
    parsed: result.parsed,
    typesFound: result.typesFound,
    nodeCount: result.entities.length,
    messages,
    counts: { errors, warnings, infos },
  };
}
