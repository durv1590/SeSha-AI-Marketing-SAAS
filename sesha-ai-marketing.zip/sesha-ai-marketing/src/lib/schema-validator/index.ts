/**
 * The structured-data validator's public surface.
 *
 * `engine.ts` is the validator. `validate.ts` is a thin adapter that presents
 * the engine in the shape the Phase 1 public tool already consumes — there is
 * one engine, not two, which is the point: two validators answering the same
 * question differently is a defect waiting to be reported by a user.
 */

export {
  VALIDATION_STATUSES,
  VALIDATION_DIMENSIONS,
  DIMENSION_LABEL,
  DIMENSION_MEANING,
  SCHEMA_SYNTAXES,
  SYNTAX_LABEL,
  SOURCE_KIND_LABEL,
  STATUS_ORDER,
  VALIDATOR_VERSION,
  countIssues,
  emptyCounts,
  isFailing,
  issuesForDimension,
  overallStatus,
  sortIssues,
  type CrawlLimitation,
  type SchemaEntity,
  type SchemaSyntax,
  type StatusCounts,
  type ValidationDimension,
  type ValidationIssue,
  type ValidationResult,
  type ValidationSourceKind,
  type ValidationStatus,
} from './types';

export {
  MAX_DOCUMENT_BYTES,
  MAX_NESTING_DEPTH,
  MAX_NODES,
  extractJsonLdBlocks,
  parseDocument,
  parseJsonLd,
  parseMicrodata,
  parseRdfa,
  type JsonValue,
  type ParsedNode,
} from './parse';

export {
  DEPRECATED_PROPERTIES,
  KNOWN_CURRENCIES,
  NEVER_INVENT_PROPERTIES,
  PROPERTY_RULES,
  SEARCH_RULES_AS_OF,
  SUPPORTED_SCHEMA_TYPES,
  TYPE_RULES,
  isNeverInvent,
  rulesFor,
} from './registry';

export { validateSchema, type ValidateInput } from './engine';

export {
  buildCorrection,
  compareResults,
  isPlaceholder,
  placeholderFor,
  type Correction,
  type CorrectionRefusal,
} from './correct';

export { SUPPORTED_TYPES, validateJsonLd, type ValidationReport, type ValidationMessage, type Severity } from './validate';
