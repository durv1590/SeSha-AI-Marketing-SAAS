/**
 * The structured-data validation contract.
 *
 * THE DISTINCTION THIS FILE EXISTS TO ENFORCE
 * The brief is explicit: schema.org validity, search-engine eligibility,
 * general SEO guidance and AI/AEO clarity are four different things, and one
 * must never be represented as another. A validator that reports them in one
 * undifferentiated list of "errors" is lying by omission — it tells a user that
 * a missing `aggregateRating` is the same kind of fact as malformed JSON.
 *
 * So `dimension` is a REQUIRED field on every issue. There is no default and no
 * way to emit an issue without choosing one. The UI groups by it, the stored
 * history keeps it, and `tests/schema-engine.test.ts` fails if any check emits
 * an issue whose dimension does not match what that check can actually know.
 *
 * What each dimension may claim:
 *
 *  · SCHEMA_VALIDITY    — checkable here, from the document alone. "This is not
 *                         valid JSON." "`datePublished` is not an ISO 8601
 *                         date." These are facts.
 *  · SEARCH_ELIGIBILITY — what a search engine's PUBLISHED requirements say.
 *                         Never whether a rich result will appear: that is
 *                         Google's decision, made later, on data we do not have.
 *  · SEO_GUIDANCE       — ordinary on-page advice that happens to be visible in
 *                         the markup. Not a schema error at all.
 *  · AEO_CLARITY        — whether the markup makes the page's facts easy for a
 *                         language model to extract. Associated with being
 *                         quotable; NOT a measurement of citation, which no
 *                         tool can measure.
 *
 * Framework-free and fully unit tested.
 */

/**
 * The six statuses from the brief.
 *
 * The two at the end are the honest ones, and the reason this is not a boolean:
 *
 *  · NOT_EVALUATED means "we did not check this", which is different from "this
 *    is fine". A validator that silently skips a check and reports no issue has
 *    told the user their markup passed a test that never ran.
 *  · UNSUPPORTED means "this is a real schema.org type that SeSha does not
 *    have rules for". Reporting an unknown type as INVALID would be a false
 *    accusation — the markup may be perfect.
 */
export const VALIDATION_STATUSES = [
  'VALID',
  'INVALID',
  'WARNING',
  'RECOMMENDATION',
  'NOT_EVALUATED',
  'UNSUPPORTED',
] as const;

export type ValidationStatus = (typeof VALIDATION_STATUSES)[number];

/** Only INVALID means the markup is wrong. */
export function isFailing(status: ValidationStatus): boolean {
  return status === 'INVALID';
}

/**
 * Ordering for display: what is wrong first, what was not looked at last.
 * Used by the UI and by `sortIssues` so two runs present identically.
 */
export const STATUS_ORDER: Readonly<Record<ValidationStatus, number>> = {
  INVALID: 0,
  WARNING: 1,
  RECOMMENDATION: 2,
  UNSUPPORTED: 3,
  NOT_EVALUATED: 4,
  VALID: 5,
};

export const VALIDATION_DIMENSIONS = [
  'SCHEMA_VALIDITY',
  'SEARCH_ELIGIBILITY',
  'SEO_GUIDANCE',
  'AEO_CLARITY',
] as const;

export type ValidationDimension = (typeof VALIDATION_DIMENSIONS)[number];

/**
 * What each dimension is allowed to claim, in the words the interface shows.
 *
 * These strings are rendered next to the grouped issues. They are here rather
 * than in a component so they are testable and so the same sentence cannot
 * drift between the public tool and the workspace.
 */
export const DIMENSION_MEANING: Readonly<Record<ValidationDimension, string>> = {
  SCHEMA_VALIDITY:
    'Whether the markup is valid schema.org. Checkable from the document itself, so these are facts rather than opinions.',
  SEARCH_ELIGIBILITY:
    "What search engines' published requirements ask for. Meeting them does not mean a rich result will appear — that is the search engine's decision, made on data this tool does not have.",
  SEO_GUIDANCE:
    'General on-page advice visible in the markup. Not a structured-data error, and ignoring it does not make the schema invalid.',
  AEO_CLARITY:
    'Whether the markup makes the page easy for an AI system to read and quote accurately. Associated with being quotable; no tool can measure whether an AI system cites a page.',
};

export const DIMENSION_LABEL: Readonly<Record<ValidationDimension, string>> = {
  SCHEMA_VALIDITY: 'Schema.org validity',
  SEARCH_ELIGIBILITY: 'Search-engine eligibility',
  SEO_GUIDANCE: 'General SEO guidance',
  AEO_CLARITY: 'AI / AEO clarity',
};

/** The markup syntaxes the parser accepts. */
export const SCHEMA_SYNTAXES = ['json-ld', 'microdata', 'rdfa'] as const;
export type SchemaSyntax = (typeof SCHEMA_SYNTAXES)[number];

export const SYNTAX_LABEL: Readonly<Record<SchemaSyntax, string>> = {
  'json-ld': 'JSON-LD',
  microdata: 'Microdata',
  rdfa: 'RDFa',
};

/**
 * One finding.
 *
 * Every field below the first four exists because the brief asks the results to
 * be actionable rather than merely correct: an error path with no corrected
 * example tells a user they are wrong without telling them what right looks
 * like.
 */
export interface ValidationIssue {
  readonly status: ValidationStatus;
  readonly dimension: ValidationDimension;
  /** Machine-readable check id, e.g. `required_property_missing`. */
  readonly check: string;
  /** Dotted path into the document, e.g. `@graph[1].author.name`. */
  readonly path: string;
  /** The property at fault, where the issue is about one. */
  readonly property?: string;
  /** The schema.org type of the node, where there is one. */
  readonly type?: string;
  /** One sentence, plain language, no jargon the user did not write. */
  readonly explanation: string;
  /** What the value should look like. A fragment, not a whole document. */
  readonly correctedExample?: string;
  /** The actual offending value, truncated. Never invented. */
  readonly found?: string;
}

/** One node found in the document. */
export interface SchemaEntity {
  readonly path: string;
  readonly types: readonly string[];
  readonly id?: string;
  readonly syntax: SchemaSyntax;
  /** True when SeSha has property rules for at least one of `types`. */
  readonly supported: boolean;
  readonly propertyCount: number;
}

export interface StatusCounts {
  readonly VALID: number;
  readonly INVALID: number;
  readonly WARNING: number;
  readonly RECOMMENDATION: number;
  readonly NOT_EVALUATED: number;
  readonly UNSUPPORTED: number;
}

/**
 * What the document was. Kept with the result because a validation of a page
 * URL and a validation of a pasted snippet are not comparable, and a history
 * that does not record which one it was invites exactly that comparison.
 */
export type ValidationSourceKind = 'pasted' | 'page_url' | 'website_url';

export const SOURCE_KIND_LABEL: Readonly<Record<ValidationSourceKind, string>> = {
  pasted: 'Pasted markup',
  page_url: 'Page URL',
  website_url: 'Website URL',
};

/**
 * The validator's own version.
 *
 * Stored on every result. Without it, a history is not comparable: a finding
 * that appears between two runs might be a change in the user's markup or a
 * change in this file's rules, and there would be no way to tell which.
 *
 * Bump the minor when a rule is added or its wording changes; bump the major
 * when a status could change for unchanged markup.
 */
export const VALIDATOR_VERSION = '5.0.0';

/**
 * A limitation of how the markup was obtained — not a finding about the markup.
 *
 * Examples: the fetch did not execute JavaScript, so schema injected by a tag
 * manager was not seen; only one page of a site was read. Reporting these as
 * warnings would blame the user for the tool's boundaries, so they are a
 * separate list and the UI renders them separately.
 */
export interface CrawlLimitation {
  readonly code: string;
  readonly detail: string;
}

export interface ValidationResult {
  readonly validatorVersion: string;
  /** When the validation ran. ISO 8601. */
  readonly checkedAt: string;
  readonly sourceKind: ValidationSourceKind;
  readonly sourceUrl?: string;
  /** Which syntaxes were actually found in the input. */
  readonly syntaxes: readonly SchemaSyntax[];
  readonly parsed: boolean;
  readonly entities: readonly SchemaEntity[];
  readonly typesFound: readonly string[];
  /** Types present in the document that SeSha has no rules for. */
  readonly unsupportedTypes: readonly string[];
  readonly issues: readonly ValidationIssue[];
  readonly counts: StatusCounts;
  readonly limitations: readonly CrawlLimitation[];
  /**
   * The headline status. INVALID if anything is INVALID, WARNING if anything is
   * a WARNING, else VALID — and NOT_EVALUATED when there was nothing to judge,
   * which is not the same as valid.
   */
  readonly overall: ValidationStatus;
}

export function emptyCounts(): StatusCounts {
  return {
    VALID: 0,
    INVALID: 0,
    WARNING: 0,
    RECOMMENDATION: 0,
    NOT_EVALUATED: 0,
    UNSUPPORTED: 0,
  };
}

export function countIssues(issues: readonly ValidationIssue[]): StatusCounts {
  const counts = { ...emptyCounts() };
  for (const issue of issues) counts[issue.status] += 1;
  return counts;
}

/**
 * The single status for a run.
 *
 * A document with no entities is NOT_EVALUATED, never VALID. "We found no
 * structured data" and "your structured data is correct" are different
 * sentences, and only one of them is true of an empty page.
 */
export function overallStatus(
  entities: readonly SchemaEntity[],
  issues: readonly ValidationIssue[],
): ValidationStatus {
  if (issues.some((issue) => issue.status === 'INVALID')) return 'INVALID';
  if (entities.length === 0) return 'NOT_EVALUATED';
  if (issues.some((issue) => issue.status === 'WARNING')) return 'WARNING';
  return 'VALID';
}

/** Stable ordering: status, then dimension, then path. */
export function sortIssues(issues: readonly ValidationIssue[]): ValidationIssue[] {
  return [...issues].sort((a, b) => {
    const byStatus = STATUS_ORDER[a.status] - STATUS_ORDER[b.status];
    if (byStatus !== 0) return byStatus;
    const byDimension =
      VALIDATION_DIMENSIONS.indexOf(a.dimension) - VALIDATION_DIMENSIONS.indexOf(b.dimension);
    if (byDimension !== 0) return byDimension;
    return a.path.localeCompare(b.path);
  });
}

export function issuesForDimension(
  issues: readonly ValidationIssue[],
  dimension: ValidationDimension,
): ValidationIssue[] {
  return issues.filter((issue) => issue.dimension === dimension);
}
