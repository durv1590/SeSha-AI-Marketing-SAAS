/**
 * Data-type checks for property values.
 *
 * Each function answers one question and returns a written reason when the
 * answer is no, because "invalid date" is not a useful thing to show a user who
 * typed `05/01/2026` — they need to be told it is ambiguous and what to write.
 *
 * Framework-free and fully unit tested.
 */

import { KNOWN_CURRENCIES } from './registry';

export interface CheckResult {
  readonly ok: boolean;
  readonly reason?: string;
}

const OK: CheckResult = { ok: true };

/* -------------------------------------------------------------------------- */
/* URLs                                                                       */
/* -------------------------------------------------------------------------- */

/**
 * A usable absolute http(s) URL.
 *
 * Relative URLs are the most common real mistake: `/logo.png` is meaningless to
 * a consumer that did not fetch the page it appeared on, and a search engine may
 * resolve it differently from an AI system reading the JSON alone.
 */
export function checkUrl(value: string): CheckResult {
  const trimmed = value.trim();
  if (trimmed.length === 0) return { ok: false, reason: 'the value is empty' };

  if (trimmed.startsWith('/') || trimmed.startsWith('./') || trimmed.startsWith('../')) {
    return {
      ok: false,
      reason: 'this is a relative URL; structured data needs the full absolute URL including https://',
    };
  }
  if (trimmed.startsWith('//')) {
    return { ok: false, reason: 'this is a protocol-relative URL; write https:// explicitly' };
  }

  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    return { ok: false, reason: 'this is not a valid URL' };
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return { ok: false, reason: `"${parsed.protocol}" is not a web address; use https://` };
  }
  if (parsed.hostname.length === 0) return { ok: false, reason: 'the URL has no host' };
  if (!parsed.hostname.includes('.') && parsed.hostname !== 'localhost') {
    return { ok: false, reason: 'the host does not look like a real domain' };
  }
  if (parsed.hostname === 'localhost' || parsed.hostname.startsWith('127.')) {
    // An advisory, not an error. `http://localhost:3000` is the correct value
    // while developing, and a validator that calls it invalid is wrong about the
    // most common development setup there is. What matters is that it must not be
    // what gets published, which is what the reason says.
    return {
      ok: true,
      reason:
        'this points at localhost, which nobody outside your machine can reach — correct while developing, but it must not be what you publish',
    };
  }
  if (parsed.protocol === 'http:') {
    return { ok: true, reason: 'this URL is http rather than https' };
  }
  return OK;
}

/** True when the URL is valid but carried an advisory reason (e.g. http). */
export function isAdvisoryUrl(result: CheckResult): boolean {
  return result.ok && result.reason !== undefined;
}

/* -------------------------------------------------------------------------- */
/* Dates                                                                      */
/* -------------------------------------------------------------------------- */

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
const ISO_DATETIME =
  /^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2}(\.\d{1,6})?)?(Z|[+-]\d{2}:?\d{2})?$/;

/**
 * ISO 8601, and real.
 *
 * `2026-02-31` matches the pattern and is not a date, so the components are
 * checked against what `Date` actually accepted — otherwise a validator reports
 * a non-existent day as valid.
 */
export function checkDate(value: string, options: { readonly time?: boolean } = {}): CheckResult {
  const trimmed = value.trim();
  if (trimmed.length === 0) return { ok: false, reason: 'the value is empty' };

  const isDate = ISO_DATE.test(trimmed);
  const isDateTime = ISO_DATETIME.test(trimmed);

  if (!isDate && !isDateTime) {
    return {
      ok: false,
      reason:
        'this is not an ISO 8601 date. Write 2026-03-14, or 2026-03-14T18:30:00+05:30 when the time matters — 14/03/2026 and 03/14/2026 are ambiguous',
    };
  }

  const parsed = new Date(trimmed);
  if (Number.isNaN(parsed.getTime())) {
    return { ok: false, reason: 'this date does not exist' };
  }
  // Guard against rollover: Date turns 2026-02-31 into 2026-03-03.
  if (isDate) {
    const [year, month, day] = trimmed.split('-').map(Number) as [number, number, number];
    if (
      parsed.getUTCFullYear() !== year ||
      parsed.getUTCMonth() + 1 !== month ||
      parsed.getUTCDate() !== day
    ) {
      return { ok: false, reason: 'this date does not exist' };
    }
  }

  if (options.time === true && !isDateTime) {
    return {
      ok: true,
      reason: 'a date with no time of day is accepted here, but a time and offset are more precise',
    };
  }
  return OK;
}

/** Compares two ISO dates. Null when either is unusable. */
export function compareDates(a: string, b: string): number | null {
  const first = new Date(a.trim());
  const second = new Date(b.trim());
  if (Number.isNaN(first.getTime()) || Number.isNaN(second.getTime())) return null;
  return first.getTime() - second.getTime();
}

/* -------------------------------------------------------------------------- */
/* Durations                                                                  */
/* -------------------------------------------------------------------------- */

const ISO_DURATION = /^P(?!$)(\d+Y)?(\d+M)?(\d+W)?(\d+D)?(T(?!$)(\d+H)?(\d+M)?(\d+(\.\d+)?S)?)?$/;

export function checkDuration(value: string): CheckResult {
  const trimmed = value.trim();
  if (trimmed.length === 0) return { ok: false, reason: 'the value is empty' };
  if (!ISO_DURATION.test(trimmed)) {
    return {
      ok: false,
      reason:
        'durations use ISO 8601: PT15M for fifteen minutes, PT1H30M for an hour and a half. "15 minutes" is not readable by a machine',
    };
  }
  return OK;
}

/* -------------------------------------------------------------------------- */
/* Numbers                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * A number, whether written as a number or as a string.
 *
 * Schema.org permits `"4.6"`, and rejecting it would be wrong. What is rejected
 * is a value that is not a number at all, and — specifically — a price with a
 * currency symbol or thousands separators in it, which is the mistake that makes
 * a price unreadable.
 */
export function checkNumber(
  value: unknown,
  options: { readonly integer?: boolean; readonly min?: number; readonly max?: number } = {},
): CheckResult {
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return { ok: false, reason: 'this is not a finite number' };
    return boundsCheck(value, options);
  }
  if (typeof value !== 'string') {
    return { ok: false, reason: 'this should be a number' };
  }
  const trimmed = value.trim();
  if (trimmed.length === 0) return { ok: false, reason: 'the value is empty' };

  if (/[^\d.\-+eE]/.test(trimmed)) {
    if (/[₹$€£¥]/.test(trimmed)) {
      return {
        ok: false,
        reason:
          'remove the currency symbol — the number goes in the value and the currency goes in priceCurrency',
      };
    }
    if (trimmed.includes(',')) {
      return { ok: false, reason: 'remove the thousands separator: write 1499.00, not 1,499.00' };
    }
    return { ok: false, reason: 'this contains characters that are not part of a number' };
  }

  const parsed = Number(trimmed);
  if (Number.isNaN(parsed)) return { ok: false, reason: 'this is not a number' };
  return boundsCheck(parsed, options);
}

function boundsCheck(
  parsed: number,
  options: { readonly integer?: boolean; readonly min?: number; readonly max?: number },
): CheckResult {
  if (options.integer === true && !Number.isInteger(parsed)) {
    return { ok: false, reason: 'this should be a whole number' };
  }
  if (options.min !== undefined && parsed < options.min) {
    return { ok: false, reason: `this should not be below ${options.min}` };
  }
  if (options.max !== undefined && parsed > options.max) {
    return { ok: false, reason: `this should not be above ${options.max}` };
  }
  return OK;
}

export function asNumber(value: unknown): number | null {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  if (typeof value !== 'string') return null;
  const parsed = Number(value.trim());
  return Number.isNaN(parsed) ? null : parsed;
}

/* -------------------------------------------------------------------------- */
/* Enumerations                                                               */
/* -------------------------------------------------------------------------- */

/**
 * A schema.org enumeration value.
 *
 * Both `InStock` and `https://schema.org/InStock` are accepted because both are
 * used in the wild, but the full URL is suggested: a bare token is ambiguous
 * outside the document's context, and the context is exactly what gets lost when
 * a node is read on its own.
 */
export function checkEnum(value: string, allowed: readonly string[]): CheckResult {
  const trimmed = value.trim();
  if (trimmed.length === 0) return { ok: false, reason: 'the value is empty' };

  const bare = trimmed.replace(/^https?:\/\/schema\.org\//i, '').replace(/^schema:/i, '');
  const match = allowed.find((candidate) => candidate.toLowerCase() === bare.toLowerCase());
  if (!match) {
    return {
      ok: false,
      reason: `"${trimmed}" is not one of the accepted values (${allowed.slice(0, 6).join(', ')}${allowed.length > 6 ? ', …' : ''})`,
    };
  }
  if (match !== bare) {
    return { ok: true, reason: `the accepted spelling is "${match}"` };
  }
  if (!/^https?:\/\/schema\.org\//i.test(trimmed)) {
    // Both forms are valid and both are used in the wild, so this is a note
    // rather than an error. The full URL is suggested because a bare token has no
    // meaning once the node is read on its own, which is exactly what happens
    // when a consumer extracts one node from a graph.
    return {
      ok: true,
      reason: `"${match}" is valid; the unambiguous form is the full "https://schema.org/${match}"`,
    };
  }
  return OK;
}

export function checkCurrency(value: string): CheckResult {
  const trimmed = value.trim().toUpperCase();
  if (trimmed.length === 0) return { ok: false, reason: 'the value is empty' };
  if (!/^[A-Z]{3}$/.test(trimmed)) {
    return {
      ok: false,
      reason: 'use the three-letter ISO 4217 code — INR, not ₹ or "Rupees"',
    };
  }
  if (!KNOWN_CURRENCIES.includes(trimmed)) {
    return { ok: true, reason: `"${trimmed}" is not a currency code this validator recognises` };
  }
  return OK;
}

/* -------------------------------------------------------------------------- */
/* Text                                                                       */
/* -------------------------------------------------------------------------- */

export function checkText(value: unknown): CheckResult {
  if (typeof value === 'number' || typeof value === 'boolean') {
    return { ok: true, reason: 'this is written as a number but read as text' };
  }
  if (typeof value !== 'string') return { ok: false, reason: 'this should be text' };
  if (value.trim().length === 0) return { ok: false, reason: 'the value is empty' };
  if (/<[a-z][^>]*>/i.test(value)) {
    return {
      ok: true,
      reason: 'this contains HTML tags, which are shown literally by most consumers',
    };
  }
  return OK;
}

/** Truncates a value for display without hiding that it was truncated. */
export function preview(value: unknown, limit = 120): string {
  const text =
    typeof value === 'string'
      ? value
      : value === null || value === undefined
        ? String(value)
        : JSON.stringify(value);
  const collapsed = text.replace(/\s+/g, ' ').trim();
  return collapsed.length > limit ? `${collapsed.slice(0, limit)}…` : collapsed;
}
