/**
 * The type registry: what each supported schema.org type expects.
 *
 * FOUR KINDS OF EXPECTATION, KEPT APART ON PURPOSE
 *
 *  · `required`   — without it the node does not describe anything. A
 *                   `LocalBusiness` with no name is not a business, it is an
 *                   empty object. Missing one is INVALID.
 *  · `recommended` — schema.org defines it and it materially helps. Missing one
 *                   is a RECOMMENDATION, never an error.
 *  · `search`     — what a search engine's PUBLISHED documentation asks for.
 *                   Missing one is a SEARCH_ELIGIBILITY warning and is stated as
 *                   "the published requirements ask for X", never as "you will
 *                   not get a rich result". We do not contact any search engine
 *                   and cannot know what it will do.
 *  · `aeo`        — properties that make the page's facts unambiguous to a
 *                   language model reading the markup. Associated with being
 *                   quotable. Not a measurement of anything.
 *
 * WHY THE SEARCH REQUIREMENTS CARRY A DATE
 * Search engines change their requirements, and this file cannot know when they
 * do. Every entry in `search` is what the published documentation said as of
 * `SEARCH_RULES_AS_OF`, and the interface shows that date. A requirement list
 * presented as timeless would be a quiet lie within a year.
 *
 * Framework-free and fully unit tested.
 */

/**
 * When the search-eligibility rules in this file were last reviewed against
 * published documentation. Shown in the interface next to every
 * SEARCH_ELIGIBILITY finding.
 */
export const SEARCH_RULES_AS_OF = '2026-05';

export type PropertyDataType =
  | 'text'
  | 'url'
  | 'date'
  | 'datetime'
  | 'duration'
  | 'number'
  | 'integer'
  | 'boolean'
  | 'node'
  | 'enum';

export interface PropertyRule {
  readonly type: PropertyDataType;
  /** For `enum`: the accepted values, with or without the schema.org prefix. */
  readonly values?: readonly string[];
  /** For `node`: the type(s) the nested node is expected to be. */
  readonly expects?: readonly string[];
  /** A correct value, used verbatim in the corrected example. */
  readonly example: string;
  /** Inclusive bounds for numbers. */
  readonly min?: number;
  readonly max?: number;
}

/**
 * ISO 4217 codes this validator recognises: the currencies a product in this
 * market actually sees. An unknown code is a WARNING, not an error — the list is
 * a spell-check for `priceCurrency`, not an assertion about world currencies.
 */
export const KNOWN_CURRENCIES: readonly string[] = [
  'INR', 'USD', 'EUR', 'GBP', 'AED', 'AUD', 'CAD', 'SGD', 'JPY', 'CNY',
  'CHF', 'SEK', 'NOK', 'DKK', 'NZD', 'ZAR', 'BRL', 'MXN', 'SAR', 'QAR',
  'KWD', 'BHD', 'OMR', 'LKR', 'NPR', 'BDT', 'PKR', 'THB', 'MYR', 'IDR',
  'PHP', 'VND', 'KRW', 'HKD', 'TWD', 'TRY', 'RUB', 'PLN', 'CZK', 'HUF',
  'ILS', 'EGP', 'NGN', 'KES', 'GHS', 'TZS', 'UGX', 'MAD', 'CLP', 'COP',
  'ARS', 'PEN', 'UYU',
];

/**
 * Property data types, shared across every type that uses the property.
 *
 * One table rather than per-type tables: `datePublished` means the same thing on
 * an Article as on a NewsArticle, and duplicating it is how the two drift.
 */
export const PROPERTY_RULES: Readonly<Record<string, PropertyRule>> = {
  /* identity and links */
  url: { type: 'url', example: 'https://example.com/page' },
  sameAs: { type: 'url', example: 'https://www.linkedin.com/company/example' },
  logo: { type: 'url', example: 'https://example.com/logo.png' },
  image: { type: 'url', example: 'https://example.com/photo.jpg' },
  thumbnailUrl: { type: 'url', example: 'https://example.com/thumb.jpg' },
  contentUrl: { type: 'url', example: 'https://example.com/image.jpg' },
  embedUrl: { type: 'url', example: 'https://example.com/embed/abc' },
  targetUrl: { type: 'url', example: 'https://example.com/target' },
  downloadUrl: { type: 'url', example: 'https://example.com/app.apk' },
  installUrl: { type: 'url', example: 'https://example.com/install' },
  applyUrl: { type: 'url', example: 'https://example.com/apply' },

  /* dates */
  datePublished: { type: 'date', example: '2026-03-14' },
  dateModified: { type: 'date', example: '2026-04-02' },
  uploadDate: { type: 'date', example: '2026-03-14' },
  startDate: { type: 'datetime', example: '2026-07-01T19:00:00+05:30' },
  endDate: { type: 'datetime', example: '2026-07-01T21:00:00+05:30' },
  datePosted: { type: 'date', example: '2026-03-14' },
  validThrough: { type: 'datetime', example: '2026-12-31T23:59:59+05:30' },
  validFrom: { type: 'datetime', example: '2026-04-01T00:00:00+05:30' },
  priceValidUntil: { type: 'date', example: '2026-12-31' },
  expires: { type: 'date', example: '2026-12-31' },
  dateCreated: { type: 'date', example: '2026-01-09' },

  /* durations */
  prepTime: { type: 'duration', example: 'PT15M' },
  cookTime: { type: 'duration', example: 'PT45M' },
  totalTime: { type: 'duration', example: 'PT1H' },
  duration: { type: 'duration', example: 'PT4M30S' },
  timeRequired: { type: 'duration', example: 'PT30M' },

  /* numbers */
  ratingValue: { type: 'number', example: '4.6', min: 0, max: 100 },
  bestRating: { type: 'number', example: '5' },
  worstRating: { type: 'number', example: '1' },
  ratingCount: { type: 'integer', example: '128', min: 0 },
  reviewCount: { type: 'integer', example: '64', min: 0 },
  price: { type: 'number', example: '499.00', min: 0 },
  position: { type: 'integer', example: '1', min: 1 },
  numberOfItems: { type: 'integer', example: '10', min: 0 },
  recipeYield: { type: 'text', example: '4 servings' },

  /* constrained vocabularies */
  priceCurrency: { type: 'enum', values: KNOWN_CURRENCIES, example: 'INR' },
  availability: {
    type: 'enum',
    values: [
      'InStock',
      'OutOfStock',
      'PreOrder',
      'PreSale',
      'BackOrder',
      'Discontinued',
      'InStoreOnly',
      'LimitedAvailability',
      'OnlineOnly',
      'SoldOut',
    ],
    example: 'https://schema.org/InStock',
  },
  itemCondition: {
    type: 'enum',
    values: ['NewCondition', 'UsedCondition', 'RefurbishedCondition', 'DamagedCondition'],
    example: 'https://schema.org/NewCondition',
  },
  eventStatus: {
    type: 'enum',
    values: [
      'EventScheduled',
      'EventCancelled',
      'EventMovedOnline',
      'EventPostponed',
      'EventRescheduled',
    ],
    example: 'https://schema.org/EventScheduled',
  },
  eventAttendanceMode: {
    type: 'enum',
    values: ['OfflineEventAttendanceMode', 'OnlineEventAttendanceMode', 'MixedEventAttendanceMode'],
    example: 'https://schema.org/OfflineEventAttendanceMode',
  },
  employmentType: {
    type: 'enum',
    values: ['FULL_TIME', 'PART_TIME', 'CONTRACTOR', 'TEMPORARY', 'INTERN', 'VOLUNTEER', 'PER_DIEM', 'OTHER'],
    example: 'FULL_TIME',
  },

  /* nested nodes */
  author: { type: 'node', expects: ['Person', 'Organization'], example: '{ "@type": "Person", "name": "A. Mehta" }' },
  publisher: {
    type: 'node',
    expects: ['Organization', 'Person'],
    example: '{ "@type": "Organization", "name": "Example", "logo": "https://example.com/logo.png" }',
  },
  address: {
    type: 'node',
    expects: ['PostalAddress'],
    example:
      '{ "@type": "PostalAddress", "streetAddress": "12 MG Road", "addressLocality": "Nagpur", "addressRegion": "MH", "postalCode": "440001", "addressCountry": "IN" }',
  },
  geo: { type: 'node', expects: ['GeoCoordinates'], example: '{ "@type": "GeoCoordinates", "latitude": 21.1458, "longitude": 79.0882 }' },
  offers: { type: 'node', expects: ['Offer', 'AggregateOffer'], example: '{ "@type": "Offer", "price": "499.00", "priceCurrency": "INR", "availability": "https://schema.org/InStock", "url": "https://example.com/product" }' },
  aggregateRating: { type: 'node', expects: ['AggregateRating'], example: '{ "@type": "AggregateRating", "ratingValue": "4.6", "reviewCount": "64" }' },
  reviewRating: { type: 'node', expects: ['Rating'], example: '{ "@type": "Rating", "ratingValue": "5", "bestRating": "5" }' },
  itemReviewed: { type: 'node', expects: ['Thing'], example: '{ "@type": "Product", "name": "Example product" }' },
  review: { type: 'node', expects: ['Review'], example: '{ "@type": "Review", "author": { "@type": "Person", "name": "A. Mehta" }, "reviewRating": { "@type": "Rating", "ratingValue": "5" } }' },
  location: { type: 'node', expects: ['Place', 'VirtualLocation', 'PostalAddress'], example: '{ "@type": "Place", "name": "Venue", "address": { "@type": "PostalAddress", "addressLocality": "Nagpur", "addressCountry": "IN" } }' },
  hiringOrganization: { type: 'node', expects: ['Organization'], example: '{ "@type": "Organization", "name": "Example", "sameAs": "https://example.com" }' },
  jobLocation: { type: 'node', expects: ['Place'], example: '{ "@type": "Place", "address": { "@type": "PostalAddress", "addressLocality": "Nagpur", "addressCountry": "IN" } }' },
  baseSalary: { type: 'node', expects: ['MonetaryAmount'], example: '{ "@type": "MonetaryAmount", "currency": "INR", "value": { "@type": "QuantitativeValue", "value": 900000, "unitText": "YEAR" } }' },
  mainEntity: { type: 'node', expects: ['Question', 'Thing'], example: '{ "@type": "Question", "name": "…", "acceptedAnswer": { "@type": "Answer", "text": "…" } }' },
  acceptedAnswer: { type: 'node', expects: ['Answer'], example: '{ "@type": "Answer", "text": "A complete answer in one or two sentences." }' },
  itemListElement: { type: 'node', expects: ['ListItem'], example: '{ "@type": "ListItem", "position": 1, "name": "Home", "item": "https://example.com/" }' },
  step: { type: 'node', expects: ['HowToStep', 'HowToSection'], example: '{ "@type": "HowToStep", "name": "Rinse", "text": "Rinse the beans under cold water." }' },
  provider: { type: 'node', expects: ['Organization', 'Person'], example: '{ "@type": "Organization", "name": "Example Academy" }' },
  breadcrumb: { type: 'node', expects: ['BreadcrumbList'], example: '{ "@type": "BreadcrumbList", "itemListElement": [] }' },
  isPartOf: { type: 'node', expects: ['WebSite', 'WebPage'], example: '{ "@id": "https://example.com/#website" }' },
  mainEntityOfPage: { type: 'node', expects: ['WebPage'], example: '{ "@id": "https://example.com/page#webpage" }' },
  contactPoint: { type: 'node', expects: ['ContactPoint'], example: '{ "@type": "ContactPoint", "contactType": "customer support", "telephone": "+91-712-000-0000" }' },

  /* nodes and values referenced by the type rules above */
  performer: { type: 'node', expects: ['Person', 'PerformingGroup', 'Organization'], example: '{ "@type": "Person", "name": "A. Mehta" }' },
  supply: { type: 'node', expects: ['HowToSupply'], example: '{ "@type": "HowToSupply", "name": "200 g coffee beans" }' },
  tool: { type: 'node', expects: ['HowToTool'], example: '{ "@type": "HowToTool", "name": "Burr grinder" }' },
  hasCourseInstance: { type: 'node', expects: ['CourseInstance'], example: '{ "@type": "CourseInstance", "courseMode": "online" }' },
  jobLocationType: { type: 'text', example: 'TELECOMMUTE' },
  applicantLocationRequirements: { type: 'node', expects: ['Country'], example: '{ "@type": "Country", "name": "India" }' },
  itemListOrder: { type: 'text', example: 'https://schema.org/ItemListOrderDescending' },
  width: { type: 'number', example: '1200', min: 1 },
  height: { type: 'number', example: '675', min: 1 },
  license: { type: 'url', example: 'https://example.com/licence' },
  lowPrice: { type: 'number', example: '399.00', min: 0 },
  highPrice: { type: 'number', example: '899.00', min: 0 },

  /* plain text */
  name: { type: 'text', example: 'Example Coffee Roasters' },
  headline: { type: 'text', example: 'How we roast our beans' },
  description: { type: 'text', example: 'One or two sentences describing the page.' },
  text: { type: 'text', example: 'The full text of the answer or step.' },
  telephone: { type: 'text', example: '+91-712-000-0000' },
  email: { type: 'text', example: 'hello@example.com' },
  priceRange: { type: 'text', example: '₹₹' },
  openingHours: { type: 'text', example: 'Mo-Sa 09:00-21:00' },
  sku: { type: 'text', example: 'EX-1001' },
  brand: { type: 'node', expects: ['Brand', 'Organization'], example: '{ "@type": "Brand", "name": "Example" }' },
  applicationCategory: { type: 'text', example: 'BusinessApplication' },
  operatingSystem: { type: 'text', example: 'Android 12+' },
  title: { type: 'text', example: 'Senior Marketing Manager' },
  jobTitle: { type: 'text', example: 'Head of Content' },
  recipeIngredient: { type: 'text', example: '200 g coffee beans' },
  recipeInstructions: { type: 'node', expects: ['HowToStep'], example: '{ "@type": "HowToStep", "text": "Grind the beans." }' },
  serviceType: { type: 'text', example: 'Digital marketing' },
  areaServed: { type: 'text', example: 'Nagpur' },
  inLanguage: { type: 'text', example: 'en-IN' },
  alternateName: { type: 'text', example: 'Example Co' },
  caption: { type: 'text', example: 'Our roastery in Nagpur' },
  transcript: { type: 'text', example: 'The spoken words of the video.' },
};

export interface SearchRequirement {
  /** Properties the published documentation asks for. */
  readonly properties: readonly string[];
  /**
   * A note about the feature itself — for example that a rich result was
   * retired. Rendered with the as-of date.
   */
  readonly note?: string;
}

export interface TypeRule {
  readonly label: string;
  /** Without these the node does not describe anything. */
  readonly required: readonly string[];
  readonly recommended: readonly string[];
  /** Published search-engine requirements, kept separate from validity. */
  readonly search?: SearchRequirement;
  /** Properties that make the node's facts unambiguous to a language model. */
  readonly aeo?: readonly string[];
  /**
   * Groups where ONE of the listed properties must be present. Used both for
   * schema-level alternatives ("an ImageObject needs contentUrl or url") and for
   * published search requirements ("a Product needs offers, review or
   * aggregateRating"). Those are different claims, so each group says which it
   * is; the default is the search-requirement reading.
   */
  readonly oneOf?: readonly {
    readonly properties: readonly string[];
    readonly why: string;
    /** `validity` when the markup is incomplete without one of them. */
    readonly kind?: 'validity' | 'search';
  }[];
}

/**
 * The twenty-four types the brief names.
 *
 * A type absent from this table is reported UNSUPPORTED, never INVALID: the
 * markup may be perfectly correct and simply outside what SeSha checks.
 */
export const TYPE_RULES: Readonly<Record<string, TypeRule>> = {
  Organization: {
    label: 'Organization',
    required: ['name'],
    recommended: ['url', 'logo', 'description', 'sameAs', 'contactPoint', 'address'],
    search: { properties: ['name', 'url', 'logo'], note: 'Used for the knowledge-panel logo feature.' },
    aeo: ['description', 'sameAs', 'address'],
  },
  LocalBusiness: {
    label: 'LocalBusiness',
    required: ['name', 'address'],
    recommended: ['telephone', 'openingHours', 'geo', 'priceRange', 'url', 'image'],
    search: { properties: ['name', 'address', 'telephone', 'openingHours'] },
    aeo: ['geo', 'priceRange', 'areaServed'],
  },
  Person: {
    label: 'Person',
    required: ['name'],
    recommended: ['url', 'image', 'jobTitle', 'sameAs', 'description'],
    aeo: ['jobTitle', 'sameAs'],
  },
  WebSite: {
    label: 'WebSite',
    required: ['name', 'url'],
    recommended: ['publisher', 'inLanguage', 'description', 'alternateName'],
    aeo: ['publisher', 'inLanguage'],
  },
  WebPage: {
    label: 'WebPage',
    required: ['name'],
    recommended: ['url', 'description', 'isPartOf', 'breadcrumb', 'inLanguage', 'dateModified'],
    aeo: ['description', 'breadcrumb', 'dateModified'],
  },
  Article: {
    label: 'Article',
    required: ['headline'],
    recommended: ['image', 'datePublished', 'dateModified', 'author', 'publisher', 'description', 'mainEntityOfPage'],
    search: { properties: ['headline', 'image', 'datePublished', 'author'] },
    aeo: ['author', 'datePublished', 'description'],
  },
  BlogPosting: {
    label: 'BlogPosting',
    required: ['headline'],
    recommended: ['image', 'datePublished', 'dateModified', 'author', 'publisher', 'description'],
    search: { properties: ['headline', 'image', 'datePublished', 'author'] },
    aeo: ['author', 'datePublished', 'description'],
  },
  NewsArticle: {
    label: 'NewsArticle',
    required: ['headline', 'datePublished'],
    recommended: ['image', 'dateModified', 'author', 'publisher', 'description'],
    search: { properties: ['headline', 'image', 'datePublished', 'author', 'publisher'] },
    aeo: ['author', 'publisher', 'datePublished'],
  },
  Product: {
    label: 'Product',
    required: ['name'],
    recommended: ['image', 'description', 'brand', 'sku', 'offers'],
    search: { properties: ['name', 'image'] },
    oneOf: [
      {
        properties: ['offers', 'review', 'aggregateRating'],
        why: 'a product snippet needs at least one of price, a review or an aggregate rating',
      },
    ],
    aeo: ['description', 'brand', 'offers'],
  },
  Offer: {
    label: 'Offer',
    required: ['price', 'priceCurrency'],
    recommended: ['availability', 'url', 'priceValidUntil', 'itemCondition'],
    search: { properties: ['price', 'priceCurrency', 'availability'] },
    aeo: ['availability', 'priceValidUntil'],
  },
  Review: {
    label: 'Review',
    required: ['author', 'reviewRating'],
    recommended: ['itemReviewed', 'datePublished', 'description'],
    search: { properties: ['author', 'reviewRating', 'itemReviewed'] },
    aeo: ['itemReviewed', 'datePublished'],
  },
  AggregateRating: {
    label: 'AggregateRating',
    required: ['ratingValue'],
    recommended: ['bestRating', 'worstRating'],
    search: { properties: ['ratingValue'] },
    oneOf: [
      {
        properties: ['ratingCount', 'reviewCount'],
        why: 'an aggregate rating must say how many ratings or reviews it is based on',
      },
    ],
    aeo: ['ratingCount', 'reviewCount'],
  },
  Event: {
    label: 'Event',
    required: ['name', 'startDate', 'location'],
    recommended: ['endDate', 'description', 'image', 'offers', 'performer', 'eventStatus', 'eventAttendanceMode'],
    search: { properties: ['name', 'startDate', 'location'] },
    aeo: ['endDate', 'eventAttendanceMode', 'offers'],
  },
  Recipe: {
    label: 'Recipe',
    required: ['name'],
    recommended: ['image', 'recipeIngredient', 'recipeInstructions', 'recipeYield', 'prepTime', 'cookTime', 'totalTime', 'author'],
    search: { properties: ['name', 'image'] },
    aeo: ['recipeIngredient', 'recipeInstructions', 'totalTime'],
  },
  FAQPage: {
    label: 'FAQPage',
    required: ['mainEntity'],
    recommended: ['name', 'url'],
    search: {
      properties: ['mainEntity'],
      note:
        'Search engines have narrowed FAQ rich results substantially; as of the date above, Google shows them only for authoritative government and health sites. The markup is still valid and still helps AI systems read the answers.',
    },
    aeo: ['mainEntity'],
  },
  HowTo: {
    label: 'HowTo',
    required: ['name', 'step'],
    recommended: ['image', 'totalTime', 'description', 'supply', 'tool'],
    search: {
      properties: ['name', 'step'],
      note:
        'Google retired the HowTo rich result; as of the date above it is no longer shown in search. The markup remains valid schema.org and still describes the steps for AI systems.',
    },
    aeo: ['step', 'totalTime'],
  },
  BreadcrumbList: {
    label: 'BreadcrumbList',
    required: ['itemListElement'],
    recommended: [],
    search: { properties: ['itemListElement'] },
    aeo: ['itemListElement'],
  },
  VideoObject: {
    label: 'VideoObject',
    required: ['name', 'description', 'thumbnailUrl', 'uploadDate'],
    recommended: ['duration', 'contentUrl', 'embedUrl', 'transcript'],
    search: { properties: ['name', 'description', 'thumbnailUrl', 'uploadDate'] },
    aeo: ['transcript', 'duration'],
  },
  ImageObject: {
    label: 'ImageObject',
    // NOT `contentUrl` as a hard requirement: schema.org permits `url` on any
    // Thing and `{ "@type": "ImageObject", "url": … }` is the commonest form in
    // the wild, accepted by consumers. Demanding `contentUrl` would report
    // correct markup as invalid, so the requirement is "one of the two".
    required: [],
    recommended: ['caption', 'width', 'height', 'license'],
    oneOf: [
      {
        properties: ['contentUrl', 'url'],
        why: 'an image node with no URL points at no image',
        kind: 'validity',
      },
    ],
    aeo: ['caption'],
  },
  Service: {
    label: 'Service',
    required: ['name'],
    recommended: ['provider', 'serviceType', 'areaServed', 'description', 'offers'],
    aeo: ['serviceType', 'areaServed', 'description'],
  },
  Course: {
    label: 'Course',
    required: ['name', 'description'],
    recommended: ['provider', 'url', 'hasCourseInstance', 'offers'],
    search: { properties: ['name', 'description', 'provider'] },
    aeo: ['provider', 'timeRequired'],
  },
  JobPosting: {
    label: 'JobPosting',
    required: ['title', 'description', 'datePosted', 'hiringOrganization'],
    recommended: ['jobLocation', 'baseSalary', 'employmentType', 'validThrough'],
    search: { properties: ['title', 'description', 'datePosted', 'hiringOrganization', 'jobLocation'] },
    oneOf: [
      {
        properties: ['jobLocation', 'jobLocationType', 'applicantLocationRequirements'],
        why: 'a job posting must say where the work happens, or that it is remote',
        kind: 'validity',
      },
    ],
    aeo: ['baseSalary', 'employmentType', 'validThrough'],
  },
  SoftwareApplication: {
    label: 'SoftwareApplication',
    required: ['name'],
    recommended: ['applicationCategory', 'operatingSystem', 'offers', 'aggregateRating', 'description'],
    search: { properties: ['name', 'applicationCategory', 'operatingSystem'] },
    aeo: ['applicationCategory', 'operatingSystem', 'description'],
  },
  ItemList: {
    label: 'ItemList',
    required: ['itemListElement'],
    recommended: ['name', 'numberOfItems', 'itemListOrder'],
    aeo: ['numberOfItems'],
  },
};

export const SUPPORTED_SCHEMA_TYPES: readonly string[] = Object.keys(TYPE_RULES);

/** Types that are valid inside a graph but are checked as part of their parent. */
export const NESTED_TYPES: readonly string[] = [
  'PostalAddress',
  'GeoCoordinates',
  'ContactPoint',
  'Rating',
  'ListItem',
  'Question',
  'Answer',
  'HowToStep',
  'HowToSection',
  'HowToSupply',
  'HowToTool',
  'Brand',
  'MonetaryAmount',
  'QuantitativeValue',
  'AggregateOffer',
  'Place',
  'VirtualLocation',
  'OpeningHoursSpecification',
  'PropertyValue',
  'SearchAction',
  'EntryPoint',
  'CourseInstance',
  'Thing',
];

/**
 * Article-like types, which share their rules. Kept as a list because several
 * checks need "is this an article of some kind" and string comparison against
 * three literals in four places is how the fourth place gets forgotten.
 */
export const ARTICLE_TYPES: readonly string[] = ['Article', 'BlogPosting', 'NewsArticle'];

/**
 * LocalBusiness subtypes seen in the wild. A `Restaurant` is a `LocalBusiness`
 * and is checked with the LocalBusiness rules rather than reported unsupported.
 */
export const LOCAL_BUSINESS_SUBTYPES: readonly string[] = [
  'Restaurant',
  'Store',
  'CafeOrCoffeeShop',
  'Bakery',
  'BarOrPub',
  'Hotel',
  'Dentist',
  'Physician',
  'MedicalClinic',
  'HealthClub',
  'BeautySalon',
  'HairSalon',
  'Spa',
  'AutoRepair',
  'RealEstateAgent',
  'InsuranceAgency',
  'FinancialService',
  'AccountingService',
  'Attorney',
  'LegalService',
  'Electrician',
  'Plumber',
  'HomeAndConstructionBusiness',
  'GeneralContractor',
  'MovingCompany',
  'Locksmith',
  'ProfessionalService',
  'TravelAgency',
  'ChildCare',
  'School',
  'EducationalOrganization',
  'SportsClub',
  'Gym',
  'ShoppingCenter',
  'GroceryStore',
  'ClothingStore',
  'ElectronicsStore',
  'FurnitureStore',
  'JewelryStore',
  'PetStore',
  'Pharmacy',
  'VeterinaryCare',
];

/**
 * Resolves the rule set for a type, following the two inheritance cases this
 * validator handles: LocalBusiness subtypes, and Organization as the parent of
 * LocalBusiness.
 *
 * Returns null for a type with no rules, which the engine reports UNSUPPORTED.
 */
export function rulesFor(type: string): { readonly as: string; readonly rule: TypeRule } | null {
  const direct = TYPE_RULES[type];
  if (direct) return { as: type, rule: direct };
  if (LOCAL_BUSINESS_SUBTYPES.includes(type)) {
    const localBusiness = TYPE_RULES['LocalBusiness'];
    // Present only for the impossible case of the table being edited wrongly.
    if (localBusiness) return { as: 'LocalBusiness', rule: localBusiness };
  }
  return null;
}

export function isNestedType(type: string): boolean {
  return NESTED_TYPES.includes(type);
}

/**
 * Properties schema.org has superseded, with their replacement.
 *
 * DELIBERATELY NOT EXHAUSTIVE, and the interface says so. Listing a property
 * here asserts that schema.org superseded it; a guess would turn correct markup
 * into a reported problem, which is worse than not checking. Each entry below is
 * one this project is confident about.
 */
export const DEPRECATED_PROPERTIES: Readonly<Record<string, string>> = {
  ingredients: 'recipeIngredient',
  performers: 'performer',
  attendees: 'attendee',
  subEvents: 'subEvent',
  members: 'member',
  serviceArea: 'areaServed',
  availableAtOrFrom: 'areaServed',
  requirements: 'supply',
  blogPosts: 'blogPost',
  reviews: 'review',
};

/**
 * Properties that must never be generated by SeSha from unverified data.
 *
 * The generator refuses them outright rather than inventing a value; see
 * `lib/schema/generate.ts`. They are listed here because the validator also
 * uses the list: it will not suggest adding one of these to fix a finding.
 */
export const NEVER_INVENT_PROPERTIES: readonly string[] = [
  'review',
  'reviews',
  'aggregateRating',
  'ratingValue',
  'ratingCount',
  'reviewCount',
  'price',
  'priceCurrency',
  'priceValidUntil',
  'offers',
  'availability',
  'award',
  'awards',
  'hasCredential',
  'hasCertification',
  'certification',
  'accreditation',
];

export function isNeverInvent(property: string): boolean {
  return NEVER_INVENT_PROPERTIES.includes(property);
}
