/**
 * Extracting structured data from what the user actually gives us.
 *
 * THREE SYNTAXES, ONE NODE SHAPE
 * JSON-LD, Microdata and RDFa express the same graph three ways. Rather than
 * three validators, each parser normalises to `ParsedNode` and there is one set
 * of rules. A Microdata `itemprop="name"` and a JSON-LD `"name"` are then the
 * same finding, with the same explanation, differing only in `syntax`.
 *
 * NO DOM LIBRARY, FOR THE SAME REASON AS THE CRAWLER
 * A full HTML parser is a large attack surface pointed at untrusted input, and
 * the input here is a document a user pasted or a page the crawler fetched.
 * `script`, `style` and comments are stripped first; extraction then uses bounded
 * expressions over the remaining text. The Microdata and RDFa readers are
 * therefore deliberately conservative: they read flat and one level of nesting,
 * and say so in a limitation rather than guessing at deep structure.
 *
 * NO EXTERNAL @context FETCH, EVER
 * A JSON-LD document may name a remote context. Fetching it would mean making a
 * request to a URL inside a document a stranger pasted — the crawler's whole
 * threat model, reintroduced through a side door. The context is checked as a
 * string and never dereferenced.
 *
 * Framework-free and fully unit tested.
 */

import type { SchemaSyntax } from './types';

export const MAX_DOCUMENT_BYTES = 200_000;
/** Depth cap. A document nested deeper than this is refused, not walked. */
export const MAX_NESTING_DEPTH = 12;
/** Node cap, so a pathological document cannot produce a million findings. */
export const MAX_NODES = 500;

export type JsonValue =
  | string
  | number
  | boolean
  | null
  | JsonValue[]
  | { [key: string]: JsonValue };

/** One normalised node, whatever syntax it came from. */
export interface ParsedNode {
  /** Dotted path back into the source document. */
  readonly path: string;
  readonly types: readonly string[];
  readonly id?: string;
  readonly syntax: SchemaSyntax;
  /** Property name to value. Values keep their JSON shape. */
  readonly properties: Readonly<Record<string, JsonValue>>;
  /** Paths of nodes nested inside this one. */
  readonly children: readonly string[];
  /** The parent node's path, absent on a top-level node. */
  readonly parent?: string;
  /** The raw object, for JSON-LD only, so a corrected version can be built. */
  readonly raw?: Readonly<Record<string, JsonValue>>;
}

export interface ParseFailure {
  readonly code:
    | 'empty'
    | 'too_large'
    | 'invalid_json'
    | 'too_deep'
    | 'not_an_object'
    | 'no_markup_found';
  readonly detail: string;
  /** Where the syntax error is, when the parser can say. */
  readonly path?: string;
}

export interface ParseOutcome {
  readonly ok: boolean;
  readonly nodes: readonly ParsedNode[];
  readonly failures: readonly ParseFailure[];
  readonly syntaxes: readonly SchemaSyntax[];
  /** `@context` values seen, for the context check. Raw, unresolved. */
  readonly contexts: readonly string[];
  /** Notes about what this reader could not see. Not findings about the markup. */
  readonly limitations: readonly { readonly code: string; readonly detail: string }[];
}

/* -------------------------------------------------------------------------- */
/* Shared helpers                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Strips everything that is not content before any extraction.
 *
 * Comments go first: a commented-out block of Microdata is not markup on the
 * page, and reporting it would be a finding about text the browser ignores.
 */
export function stripNonContent(html: string): string {
  return html
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style\s*>/gi, ' ')
    .replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript\s*>/gi, ' ');
}

/** Decodes the handful of entities that appear in attribute values. */
export function decodeEntities(value: string): string {
  return value
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&');
}

/** Last path segment of a type IRI: `https://schema.org/Product` -> `Product`. */
export function localName(value: string): string {
  const trimmed = value.trim();
  const afterHash = trimmed.includes('#') ? trimmed.slice(trimmed.lastIndexOf('#') + 1) : trimmed;
  const afterSlash = afterHash.includes('/') ? afterHash.slice(afterHash.lastIndexOf('/') + 1) : afterHash;
  // `schema:Product` and `Product` both arrive here.
  return afterSlash.includes(':') ? afterSlash.slice(afterSlash.lastIndexOf(':') + 1) : afterSlash;
}

function asStringArray(value: JsonValue | undefined): string[] {
  if (typeof value === 'string') return [value];
  if (Array.isArray(value)) return value.filter((item): item is string => typeof item === 'string');
  return [];
}

/* -------------------------------------------------------------------------- */
/* JSON-LD                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Pulls JSON-LD out of an HTML document, or accepts a bare JSON document.
 *
 * A page may carry several `<script type="application/ld+json">` blocks, and one
 * of them being broken must not discard the others — so each block is parsed
 * independently and a failure is reported against that block's own path.
 */
export function extractJsonLdBlocks(source: string): { readonly path: string; readonly text: string }[] {
  const trimmed = source.trim();
  if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
    return [{ path: '$', text: trimmed }];
  }

  const blocks: { path: string; text: string }[] = [];
  const cleaned = source.replace(/<!--[\s\S]*?-->/g, ' ');
  const pattern = /<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi;
  let index = 0;
  for (const match of cleaned.matchAll(pattern)) {
    const attributes = match[1] ?? '';
    const body = match[2] ?? '';
    if (!/type\s*=\s*["']?application\/ld\+json["']?/i.test(attributes)) continue;
    blocks.push({ path: `script[${index}]`, text: body.trim() });
    index += 1;
  }
  return blocks;
}

interface JsonLdWalkState {
  readonly nodes: ParsedNode[];
  readonly failures: ParseFailure[];
  readonly contexts: string[];
  truncated: boolean;
}

function isPlainObject(value: JsonValue): value is { [key: string]: JsonValue } {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/**
 * Walks a parsed JSON-LD value, emitting one node per object that has a `@type`
 * — and also for an object that has none, because a typeless node is itself a
 * finding and discarding it here would hide it.
 */
function walkJsonLd(
  value: JsonValue,
  path: string,
  depth: number,
  parent: string | undefined,
  state: JsonLdWalkState,
): string[] {
  if (depth > MAX_NESTING_DEPTH) {
    state.failures.push({
      code: 'too_deep',
      detail: `Nesting is deeper than ${MAX_NESTING_DEPTH} levels, which is past the point of being readable. Flatten the document and use "@id" references between nodes instead.`,
      path,
    });
    return [];
  }

  if (Array.isArray(value)) {
    const emitted: string[] = [];
    value.forEach((item, index) => {
      // An array directly inside an array is a level of nesting too. Without
      // counting it, `[[[[…]]]]` bypassed MAX_NESTING_DEPTH entirely and a
      // ~10KB paste overflowed the stack (RangeError) instead of being reported.
      const itemDepth = Array.isArray(item) ? depth + 1 : depth;
      emitted.push(...walkJsonLd(item, `${path}[${index}]`, itemDepth, parent, state));
    });
    return emitted;
  }

  if (!isPlainObject(value)) return [];

  if (state.nodes.length >= MAX_NODES) {
    state.truncated = true;
    return [];
  }

  const context = value['@context'] ?? null;
  for (const entry of asStringArray(context)) state.contexts.push(entry);
  if (isPlainObject(context)) {
    // A context object rather than a URL. Recorded so the engine can say it was
    // not resolved, rather than silently treating it as correct.
    state.contexts.push('[inline object]');
  }

  const graph = value['@graph'];
  if (graph !== undefined) {
    // A graph wrapper is not itself an entity; its members are.
    return walkJsonLd(graph, `${path}.@graph`, depth + 1, parent, state);
  }

  const types = asStringArray(value['@type']).map(localName);
  const rawId = value['@id'];
  const properties: Record<string, JsonValue> = {};
  const children: string[] = [];

  const node: ParsedNode = {
    path,
    types,
    ...(typeof rawId === 'string' ? { id: rawId } : {}),
    syntax: 'json-ld',
    properties,
    children,
    ...(parent ? { parent } : {}),
    raw: value,
  };
  state.nodes.push(node);

  for (const [key, child] of Object.entries(value)) {
    if (key === '@context' || key === '@type' || key === '@id') continue;
    properties[key] = child;
    // Nested objects and arrays of objects become nodes of their own so their
    // own required properties are checked.
    const nested = walkJsonLd(child, `${path}.${key}`, depth + 1, path, state);
    children.push(...nested);
  }

  return [path];
}

export function parseJsonLd(source: string): ParseOutcome {
  const limitations: { code: string; detail: string }[] = [];
  const state: JsonLdWalkState = { nodes: [], failures: [], contexts: [], truncated: false };

  if (source.trim().length === 0) {
    return {
      ok: false,
      nodes: [],
      failures: [{ code: 'empty', detail: 'Nothing to validate.' }],
      syntaxes: [],
      contexts: [],
      limitations: [],
    };
  }

  const bytes = Buffer.byteLength(source, 'utf8');
  if (bytes > MAX_DOCUMENT_BYTES) {
    return {
      ok: false,
      nodes: [],
      failures: [
        {
          code: 'too_large',
          detail: `The document is ${bytes.toLocaleString('en-IN')} bytes, past the ${MAX_DOCUMENT_BYTES.toLocaleString('en-IN')} byte limit.`,
        },
      ],
      syntaxes: [],
      contexts: [],
      limitations: [],
    };
  }

  const blocks = extractJsonLdBlocks(source);
  if (blocks.length === 0) {
    return {
      ok: false,
      nodes: [],
      failures: [],
      syntaxes: [],
      contexts: [],
      limitations: [],
    };
  }

  for (const block of blocks) {
    let parsed: JsonValue;
    try {
      parsed = JSON.parse(block.text) as JsonValue;
    } catch (error) {
      state.failures.push({
        code: 'invalid_json',
        detail: `The JSON-LD could not be parsed: ${error instanceof Error ? error.message : 'unknown error'}`,
        path: block.path,
      });
      continue;
    }
    if (!isPlainObject(parsed) && !Array.isArray(parsed)) {
      state.failures.push({
        code: 'not_an_object',
        detail: 'JSON-LD must be an object or an array of objects.',
        path: block.path,
      });
      continue;
    }
    walkJsonLd(parsed, block.path === '$' ? '$' : block.path, 0, undefined, state);
  }

  if (state.truncated) {
    limitations.push({
      code: 'node_limit',
      detail: `Only the first ${MAX_NODES} nodes were checked. The rest of the document was not evaluated.`,
    });
  }

  return {
    ok: state.failures.length === 0,
    nodes: state.nodes,
    failures: state.failures,
    syntaxes: state.nodes.length > 0 ? ['json-ld'] : [],
    contexts: state.contexts,
    limitations,
  };
}

/* -------------------------------------------------------------------------- */
/* Microdata                                                                  */
/* -------------------------------------------------------------------------- */

/**
 * Reads Microdata: `itemscope` + `itemtype` + `itemprop`.
 *
 * HOW THIS STAYS HONEST WITHOUT A DOM
 * Microdata's nesting is expressed by element containment, which a regex cannot
 * reliably determine. Rather than guess, this reader walks the tags in order and
 * keeps a scope stack by tag depth — correct for well-formed markup, and when it
 * meets something it cannot follow (an unclosed element, an `itemref`) it records
 * a LIMITATION saying so. The limitation is the honest output: the alternative is
 * a confident wrong answer about which property belongs to which item.
 */
export function parseMicrodata(source: string): ParseOutcome {
  const html = stripNonContent(source);
  if (!/itemscope/i.test(html)) {
    return { ok: true, nodes: [], failures: [], syntaxes: [], contexts: [], limitations: [] };
  }

  const nodes: ParsedNode[] = [];
  const limitations: { code: string; detail: string }[] = [];

  interface Scope {
    readonly node: ParsedNode;
    readonly properties: Record<string, JsonValue>;
    readonly children: string[];
    /** Tag depth at which this scope opened, so it closes at the same depth. */
    readonly depth: number;
    /** The tag name that opened it, to detect a mismatched close. */
    readonly tag: string;
  }

  const stack: Scope[] = [];
  const VOID_TAGS = new Set([
    'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link',
    'meta', 'param', 'source', 'track', 'wbr',
  ]);

  let depth = 0;
  let index = 0;
  let sawItemref = false;

  const tagPattern = /<(\/?)([a-zA-Z][a-zA-Z0-9-]*)((?:"[^"]*"|'[^']*'|[^>"'])*?)(\/?)>/g;

  for (const match of html.matchAll(tagPattern)) {
    const closing = match[1] === '/';
    const tag = (match[2] ?? '').toLowerCase();
    const attributes = match[3] ?? '';
    const selfClosing = match[4] === '/' || VOID_TAGS.has(tag);
    const tagEnd = (match.index ?? 0) + match[0].length;

    if (closing) {
      depth = Math.max(0, depth - 1);
      while (stack.length > 0) {
        const top = stack[stack.length - 1]!;
        if (top.depth < depth) break;
        stack.pop();
      }
      continue;
    }

    if (/\bitemref\b/i.test(attributes)) sawItemref = true;

    const itemscope = /\bitemscope\b/i.test(attributes);
    const itemtype = attribute(attributes, 'itemtype');
    const itemprop = attribute(attributes, 'itemprop');
    const itemid = attribute(attributes, 'itemid');

    if (itemscope) {
      const types = (itemtype ?? '')
        .split(/\s+/)
        .map((entry) => localName(entry))
        .filter((entry) => entry.length > 0);
      const properties: Record<string, JsonValue> = {};
      const children: string[] = [];
      const parent = stack.length > 0 ? stack[stack.length - 1] : undefined;
      const path = parent ? `${parent.node.path}.${itemprop ?? `item[${index}]`}` : `item[${index}]`;
      index += 1;

      const node: ParsedNode = {
        path,
        types,
        ...(itemid ? { id: itemid } : {}),
        syntax: 'microdata',
        properties,
        children,
        ...(parent ? { parent: parent.node.path } : {}),
      };
      nodes.push(node);
      if (parent && itemprop) {
        parent.children.push(path);
        parent.properties[itemprop] = { '@nested': path };
      }
      if (!selfClosing) {
        stack.push({ node, properties, children, depth, tag });
      }
    } else if (itemprop && stack.length > 0) {
      const scope = stack[stack.length - 1]!;
      const value = microdataValue(tag, attributes, html, tagEnd);
      const existing = scope.properties[itemprop];
      if (existing === undefined) scope.properties[itemprop] = value;
      else if (Array.isArray(existing)) existing.push(value);
      else scope.properties[itemprop] = [existing, value];
    }

    if (!selfClosing) depth += 1;
  }

  limitations.push({
    code: 'microdata_flat_read',
    detail:
      'Microdata was read without a browser, so nesting is followed by element order rather than by a rendered document tree. Deeply nested or unclosed markup may be read differently by a search engine.',
  });
  if (sawItemref) {
    limitations.push({
      code: 'microdata_itemref',
      detail:
        'This page uses itemref, which points at content elsewhere in the document. Those referenced properties were NOT resolved and are not included below.',
    });
  }

  return {
    ok: true,
    nodes,
    failures: [],
    syntaxes: nodes.length > 0 ? ['microdata'] : [],
    contexts: [],
    limitations,
  };
}

function attribute(attributes: string, name: string): string | undefined {
  const pattern = new RegExp(`\\b${name}\\s*=\\s*("([^"]*)"|'([^']*)'|([^\\s"'>]+))`, 'i');
  const match = pattern.exec(attributes);
  if (!match) return undefined;
  const raw = match[2] ?? match[3] ?? match[4] ?? '';
  return decodeEntities(raw).trim();
}

/**
 * A Microdata property's value.
 *
 * The element decides: `meta` uses `content`, links use `href`, media uses `src`,
 * `time` uses `datetime`, and everything else uses its text. Taking the text of a
 * `meta` element would silently read an empty string.
 */
function microdataValue(tag: string, attributes: string, html: string, tagEnd: number): string {
  if (tag === 'meta') return attribute(attributes, 'content') ?? '';
  if (tag === 'a' || tag === 'area' || tag === 'link') return attribute(attributes, 'href') ?? '';
  if (tag === 'img' || tag === 'audio' || tag === 'video' || tag === 'source' || tag === 'embed' || tag === 'iframe') {
    return attribute(attributes, 'src') ?? attribute(attributes, 'content') ?? '';
  }
  if (tag === 'time') {
    const datetime = attribute(attributes, 'datetime');
    if (datetime) return datetime;
  }
  if (tag === 'object') return attribute(attributes, 'data') ?? '';
  if (tag === 'data') return attribute(attributes, 'value') ?? '';

  // Text content up to the matching close tag, with inner tags removed.
  const closeIndex = html.toLowerCase().indexOf(`</${tag}`, tagEnd);
  const slice = closeIndex === -1 ? html.slice(tagEnd, tagEnd + 2_000) : html.slice(tagEnd, closeIndex);
  return decodeEntities(slice.replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim();
}

/* -------------------------------------------------------------------------- */
/* RDFa                                                                       */
/* -------------------------------------------------------------------------- */

/**
 * Reads RDFa Lite: `vocab`, `typeof`, `property`, `resource`.
 *
 * The same conservative approach as Microdata, and the same honesty about it:
 * RDFa's full semantics (prefix mappings, `about`, `rel`/`rev`, chaining) are
 * beyond what can be read safely without a parser, so what is not read is
 * reported as a limitation rather than assumed absent.
 */
export function parseRdfa(source: string): ParseOutcome {
  const html = stripNonContent(source);
  if (!/\btypeof\s*=/i.test(html)) {
    return { ok: true, nodes: [], failures: [], syntaxes: [], contexts: [], limitations: [] };
  }

  const nodes: ParsedNode[] = [];
  const contexts: string[] = [];
  const limitations: { code: string; detail: string }[] = [];

  interface Scope {
    readonly node: ParsedNode;
    readonly properties: Record<string, JsonValue>;
    readonly children: string[];
    readonly depth: number;
  }

  const stack: Scope[] = [];
  const VOID_TAGS = new Set([
    'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link',
    'meta', 'param', 'source', 'track', 'wbr',
  ]);

  let depth = 0;
  let index = 0;
  let sawPrefix = false;

  for (const match of html.matchAll(/<(\/?)([a-zA-Z][a-zA-Z0-9-]*)((?:"[^"]*"|'[^']*'|[^>"'])*?)(\/?)>/g)) {
    const closing = match[1] === '/';
    const tag = (match[2] ?? '').toLowerCase();
    const attributes = match[3] ?? '';
    const selfClosing = match[4] === '/' || VOID_TAGS.has(tag);
    const tagEnd = (match.index ?? 0) + match[0].length;

    if (closing) {
      depth = Math.max(0, depth - 1);
      while (stack.length > 0 && stack[stack.length - 1]!.depth >= depth) stack.pop();
      continue;
    }

    const vocab = attribute(attributes, 'vocab');
    if (vocab) contexts.push(vocab);
    if (attribute(attributes, 'prefix')) sawPrefix = true;

    const typeOf = attribute(attributes, 'typeof');
    const property = attribute(attributes, 'property');
    const resource = attribute(attributes, 'resource');

    if (typeOf) {
      const types = typeOf
        .split(/\s+/)
        .map((entry) => localName(entry))
        .filter((entry) => entry.length > 0);
      const properties: Record<string, JsonValue> = {};
      const children: string[] = [];
      const parent = stack.length > 0 ? stack[stack.length - 1] : undefined;
      const path = parent ? `${parent.node.path}.${property ?? `node[${index}]`}` : `node[${index}]`;
      index += 1;

      const node: ParsedNode = {
        path,
        types,
        ...(resource ? { id: resource } : {}),
        syntax: 'rdfa',
        properties,
        children,
        ...(parent ? { parent: parent.node.path } : {}),
      };
      nodes.push(node);
      if (parent && property) {
        parent.children.push(path);
        parent.properties[property] = { '@nested': path };
      }
      if (!selfClosing) stack.push({ node, properties, children, depth });
    } else if (property && stack.length > 0) {
      const scope = stack[stack.length - 1]!;
      const value =
        attribute(attributes, 'content') ??
        attribute(attributes, 'href') ??
        attribute(attributes, 'src') ??
        attribute(attributes, 'datetime') ??
        microdataValue(tag, attributes, html, tagEnd);
      const key = localName(property);
      const existing = scope.properties[key];
      if (existing === undefined) scope.properties[key] = value;
      else if (Array.isArray(existing)) existing.push(value);
      else scope.properties[key] = [existing, value];
    }

    if (!selfClosing) depth += 1;
  }

  limitations.push({
    code: 'rdfa_lite_only',
    detail:
      'RDFa was read as RDFa Lite (vocab, typeof, property, resource) without a browser. Prefix mappings, about, rel and rev were not resolved, so a search engine may read more than is listed below.',
  });
  if (sawPrefix) {
    limitations.push({
      code: 'rdfa_prefix',
      detail:
        'This page declares RDFa prefixes, which were not expanded. Properties using a prefix other than the document vocabulary may be missing from the list below.',
    });
  }

  return {
    ok: true,
    nodes,
    failures: [],
    syntaxes: nodes.length > 0 ? ['rdfa'] : [],
    contexts,
    limitations,
  };
}

/* -------------------------------------------------------------------------- */
/* All three                                                                  */
/* -------------------------------------------------------------------------- */

/**
 * Parses whatever was given: a JSON-LD document, or an HTML page that may carry
 * any combination of the three syntaxes.
 *
 * A page with JSON-LD *and* Microdata for the same thing is a real and common
 * mistake; both are returned so the duplicate-entity check can see them.
 */
export function parseDocument(source: string): ParseOutcome {
  const jsonLd = parseJsonLd(source);

  const trimmed = source.trim();
  const looksLikeJson = trimmed.startsWith('{') || trimmed.startsWith('[');
  if (looksLikeJson) return jsonLd;

  const microdata = parseMicrodata(source);
  const rdfa = parseRdfa(source);

  const nodes = [...jsonLd.nodes, ...microdata.nodes, ...rdfa.nodes];
  const syntaxes = [...jsonLd.syntaxes, ...microdata.syntaxes, ...rdfa.syntaxes];

  const failures = [...jsonLd.failures, ...microdata.failures, ...rdfa.failures];
  if (nodes.length === 0 && failures.length === 0) {
    failures.push({
      code: 'no_markup_found',
      detail:
        'No JSON-LD, Microdata or RDFa was found. If the markup is added by a tag manager or by JavaScript, this tool will not see it — it reads the HTML as delivered.',
    });
  }

  return {
    ok: failures.length === 0,
    nodes,
    failures,
    syntaxes,
    contexts: [...jsonLd.contexts, ...rdfa.contexts],
    limitations: [
      // Only mention a syntax's limitations when that syntax was actually found.
      ...jsonLd.limitations,
      ...(microdata.nodes.length > 0 ? microdata.limitations : []),
      ...(rdfa.nodes.length > 0 ? rdfa.limitations : []),
    ],
  };
}
