/**
 * Email and WhatsApp: content and planning.
 *
 * THE TWO INSTRUCTIONS IN THE BRIEF THAT SHAPE THIS FILE
 *   "Use official APIs only."
 *   "Do not enable unauthorized spam."
 *
 * Taking those seriously changes the design rather than adding a disclaimer:
 *
 *  1. NOTHING HERE SENDS. `sendingStatus()` is the single source of truth and it
 *     says no provider is connected, exactly as Phase 3 did for social
 *     publishing. There is no `send()` to comment out later, and no 'sent' or
 *     'scheduled' state in the type — so no screen, request body or cast can
 *     produce one.
 *  2. A PLAN WITHOUT A LAWFUL BASIS IS REFUSED, not warned about. A marketing
 *     message needs a recorded reason the recipient agreed to hear from you, and
 *     `checkMessagingPlan` returns an error when there is none. A purchased or
 *     scraped list is refused outright — there is no override, because the only
 *     purpose of an override is to send to a purchased list.
 *  3. PROMOTIONAL EMAIL WITHOUT AN UNSUBSCRIBE IS AN ERROR. Not a recommendation.
 *     It is a legal requirement in most of the markets this product serves, and a
 *     tool that treats it as optional is helping its user break the law.
 *  4. WHATSAPP IS TEMPLATE-SHAPED. The official Business API sends marketing
 *     content only as a pre-approved template to an opted-in number. So the
 *     planner produces template-shaped content with a category and numbered
 *     placeholders, because that is what can actually be submitted — a free-text
 *     "WhatsApp blast" is not a thing the official API does.
 *
 * Framework-free and fully unit tested.
 */

export const MESSAGING_CHANNELS = ['email', 'whatsapp'] as const;
export type MessagingChannel = (typeof MESSAGING_CHANNELS)[number];

export const CHANNEL_LABEL: Readonly<Record<MessagingChannel, string>> = {
  email: 'Email',
  whatsapp: 'WhatsApp',
};

/* -------------------------------------------------------------------------- */
/* Kinds                                                                      */
/* -------------------------------------------------------------------------- */

/** The six email kinds the brief names. */
export const EMAIL_KINDS = [
  'welcome',
  'promotional',
  'follow_up',
  'newsletter',
  're_engagement',
  'nurturing',
] as const;
export type EmailKind = (typeof EMAIL_KINDS)[number];

/** The five WhatsApp kinds the brief names. */
export const WHATSAPP_KINDS = ['product', 'follow_up', 'offer', 'appointment', 'retention'] as const;
export type WhatsappKind = (typeof WHATSAPP_KINDS)[number];

export type MessagingKind = EmailKind | WhatsappKind;

export const EMAIL_KIND_LABEL: Readonly<Record<EmailKind, string>> = {
  welcome: 'Welcome',
  promotional: 'Promotional',
  follow_up: 'Follow-up',
  newsletter: 'Newsletter',
  re_engagement: 'Re-engagement',
  nurturing: 'Nurturing',
};

export const WHATSAPP_KIND_LABEL: Readonly<Record<WhatsappKind, string>> = {
  product: 'Product',
  follow_up: 'Follow-up',
  offer: 'Offer',
  appointment: 'Appointment',
  retention: 'Retention',
};

/**
 * Which kinds are marketing rather than service messages.
 *
 * The distinction is not cosmetic. A transactional message — an appointment
 * reminder, a reply to an enquiry — is permitted on a different basis from a
 * promotion, and WhatsApp charges and categorises them differently. Getting this
 * wrong is how a business gets its number blocked.
 */
export const MARKETING_KINDS: readonly MessagingKind[] = [
  'promotional',
  'newsletter',
  're_engagement',
  'nurturing',
  'offer',
  'product',
  'retention',
];

export function isMarketing(kind: MessagingKind): boolean {
  return MARKETING_KINDS.includes(kind);
}

export function isEmailKind(value: unknown): value is EmailKind {
  return typeof value === 'string' && (EMAIL_KINDS as readonly string[]).includes(value);
}

export function isWhatsappKind(value: unknown): value is WhatsappKind {
  return typeof value === 'string' && (WHATSAPP_KINDS as readonly string[]).includes(value);
}

/* -------------------------------------------------------------------------- */
/* Lawful basis                                                               */
/* -------------------------------------------------------------------------- */

/**
 * Why this recipient may be messaged.
 *
 * `purchased_list` and `scraped` exist in this list ON PURPOSE. They are the two
 * answers that cause a plan to be refused, and naming them is what makes the
 * refusal possible: a field that only offers acceptable answers teaches the user
 * to pick the nearest acceptable-looking one.
 */
export const OPT_IN_BASES = [
  'explicit_opt_in',
  'existing_customer',
  'enquiry_reply',
  'contract_necessity',
  'purchased_list',
  'scraped',
  'none',
] as const;

export type OptInBasis = (typeof OPT_IN_BASES)[number];

export const OPT_IN_LABEL: Readonly<Record<OptInBasis, string>> = {
  explicit_opt_in: 'They ticked a box or sent a message asking to hear from us',
  existing_customer: 'They are an existing customer and this relates to what they bought',
  enquiry_reply: 'They contacted us and this is the reply',
  contract_necessity: 'This is needed to deliver something they have bought',
  purchased_list: 'The list was bought, rented or swapped',
  scraped: 'The addresses or numbers were collected from somewhere public',
  none: 'No recorded basis',
};

/** Bases that never justify a message. A plan carrying one is refused. */
export const FORBIDDEN_BASES: readonly OptInBasis[] = ['purchased_list', 'scraped', 'none'];

export function isForbiddenBasis(basis: OptInBasis): boolean {
  return FORBIDDEN_BASES.includes(basis);
}

export const BASIS_REFUSAL: Readonly<Record<string, string>> = {
  purchased_list:
    'SeSha will not help you message a bought list. The people on it did not ask to hear from you, it is unlawful in most markets, and it is the fastest way to get your sending domain and your WhatsApp number blocked. There is no setting that changes this.',
  scraped:
    'Addresses and numbers collected from public pages are not consent. SeSha will not plan a campaign to them.',
  none:
    'Record why these people agreed to hear from you before planning the message. If the answer is that they did not, the campaign should not exist.',
};

/* -------------------------------------------------------------------------- */
/* Email                                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Limits that are about whether a message works, not about whether it is allowed.
 * Dated, like the ad and search rules, because client behaviour changes.
 */
export const EMAIL_LIMITS_AS_OF = '2026-05';

export const EMAIL_LIMITS = {
  /** Past this, most clients truncate the subject in the list view. */
  subjectCharacters: 60,
  subjectHardLimit: 150,
  /** The preview text clients show next to the subject. */
  preheaderCharacters: 100,
  /** A single call to action converts better than three competing ones. */
  maxCallsToAction: 2,
} as const;

export interface EmailPlan {
  readonly channel: 'email';
  readonly kind: EmailKind;
  readonly subject: string;
  readonly preheader: string;
  readonly body: string;
  /** Plain-text alternative. Absent is a warning: some clients show only this. */
  readonly plainText?: string;
  readonly callsToAction: readonly { readonly label: string; readonly url: string }[];
  /** Whether the message carries a working unsubscribe link. */
  readonly hasUnsubscribe: boolean;
  /** Postal address or equivalent sender identification. */
  readonly senderIdentification: string;
  readonly optInBasis: OptInBasis;
  readonly audienceDescription: string;
}

/* -------------------------------------------------------------------------- */
/* WhatsApp                                                                   */
/* -------------------------------------------------------------------------- */

export const WHATSAPP_LIMITS_AS_OF = '2026-05';

/**
 * The official Business API's own shape.
 *
 * These are the numbers a template submission is checked against, so a planner
 * that ignores them produces content that cannot be submitted.
 */
export const WHATSAPP_LIMITS = {
  headerCharacters: 60,
  bodyCharacters: 1_024,
  footerCharacters: 60,
  buttonLabelCharacters: 25,
  maxButtons: 3,
  /** Beyond this many placeholders a template is usually rejected as spammy. */
  maxPlaceholders: 6,
} as const;

/**
 * Template categories, as the official API defines them.
 *
 * The category decides what may be sent and when. Marketing content sent under a
 * UTILITY category is a policy breach, so the planner derives the category from
 * the kind rather than letting it be chosen freely.
 */
export const WHATSAPP_CATEGORIES = ['MARKETING', 'UTILITY', 'AUTHENTICATION'] as const;
export type WhatsappCategory = (typeof WHATSAPP_CATEGORIES)[number];

export function categoryFor(kind: WhatsappKind): WhatsappCategory {
  switch (kind) {
    case 'appointment':
      // A reminder about something they booked is a utility message.
      return 'UTILITY';
    case 'follow_up':
      return 'UTILITY';
    default:
      return 'MARKETING';
  }
}

export interface WhatsappPlan {
  readonly channel: 'whatsapp';
  readonly kind: WhatsappKind;
  readonly category: WhatsappCategory;
  readonly header?: string;
  /** Placeholders are numbered, as the API requires: {{1}}, {{2}}. */
  readonly body: string;
  readonly footer?: string;
  readonly buttons: readonly { readonly label: string; readonly kind: 'quick_reply' | 'url' | 'phone'; readonly value?: string }[];
  /** What each placeholder means, in order. Required: an unexplained {{1}} is unreviewable. */
  readonly placeholders: readonly string[];
  readonly optInBasis: OptInBasis;
  readonly audienceDescription: string;
}

export type MessagingPlan = EmailPlan | WhatsappPlan;

/* -------------------------------------------------------------------------- */
/* Validation                                                                 */
/* -------------------------------------------------------------------------- */

export interface MessagingProblem {
  readonly severity: 'error' | 'warning';
  readonly field: string;
  readonly message: string;
}

export function checkMessagingPlan(plan: MessagingPlan): readonly MessagingProblem[] {
  const problems: MessagingProblem[] = [];

  /* ------------------------------------------------------ lawful basis */
  if (isForbiddenBasis(plan.optInBasis)) {
    problems.push({
      severity: 'error',
      field: 'optInBasis',
      message: BASIS_REFUSAL[plan.optInBasis] ?? 'This is not a basis for messaging anyone.',
    });
  } else if (isMarketing(plan.kind) && plan.optInBasis === 'enquiry_reply') {
    problems.push({
      severity: 'error',
      field: 'optInBasis',
      message:
        'Replying to an enquiry permits an answer, not a promotion. Either make this a reply, or record that they agreed to marketing.',
    });
  }

  if (plan.audienceDescription.trim().length < 10) {
    problems.push({
      severity: 'error',
      field: 'audienceDescription',
      message: 'Say who this is going to. "Everyone" is not an audience, and a plan nobody can review is not a plan.',
    });
  }

  if (plan.channel === 'email') return [...problems, ...checkEmail(plan)];
  return [...problems, ...checkWhatsapp(plan)];
}

function checkEmail(plan: EmailPlan): MessagingProblem[] {
  const problems: MessagingProblem[] = [];
  const subject = plan.subject.trim();

  if (subject.length === 0) {
    problems.push({ severity: 'error', field: 'subject', message: 'The email needs a subject line.' });
  } else if (subject.length > EMAIL_LIMITS.subjectHardLimit) {
    problems.push({
      severity: 'error',
      field: 'subject',
      message: `The subject is ${subject.length} characters, past the ${EMAIL_LIMITS.subjectHardLimit} that clients accept.`,
    });
  } else if (subject.length > EMAIL_LIMITS.subjectCharacters) {
    problems.push({
      severity: 'warning',
      field: 'subject',
      message: `The subject is ${subject.length} characters; most clients cut it at about ${EMAIL_LIMITS.subjectCharacters} (as of ${EMAIL_LIMITS_AS_OF}).`,
    });
  }

  if (/^(?:re|fwd):/i.test(subject)) {
    problems.push({
      severity: 'error',
      field: 'subject',
      message:
        'A subject beginning "Re:" or "Fwd:" on a message that is neither is a deception. It also trains recipients to distrust you.',
    });
  }

  if (plan.body.trim().length < 40) {
    problems.push({ severity: 'error', field: 'body', message: 'The email body is effectively empty.' });
  }

  if (plan.preheader.trim().length === 0) {
    problems.push({
      severity: 'warning',
      field: 'preheader',
      message: 'With no preheader, clients show the first line of the body instead — often a link or a greeting.',
    });
  } else if (plan.preheader.trim().length > EMAIL_LIMITS.preheaderCharacters) {
    problems.push({
      severity: 'warning',
      field: 'preheader',
      message: `The preheader is longer than the ~${EMAIL_LIMITS.preheaderCharacters} characters clients display.`,
    });
  }

  if (isMarketing(plan.kind) && !plan.hasUnsubscribe) {
    problems.push({
      severity: 'error',
      field: 'hasUnsubscribe',
      message:
        'A marketing email must carry a working unsubscribe link. This is a legal requirement in most markets, not a best practice, and SeSha will not mark this plan ready without it.',
    });
  }

  if (isMarketing(plan.kind) && plan.senderIdentification.trim().length === 0) {
    problems.push({
      severity: 'error',
      field: 'senderIdentification',
      message: 'A marketing email must identify the sender — a real business name and a postal address or equivalent.',
    });
  }

  if (plan.callsToAction.length === 0) {
    problems.push({
      severity: 'warning',
      field: 'callsToAction',
      message: 'There is no call to action, so it is not clear what the reader should do.',
    });
  } else if (plan.callsToAction.length > EMAIL_LIMITS.maxCallsToAction) {
    problems.push({
      severity: 'warning',
      field: 'callsToAction',
      message: `${plan.callsToAction.length} calls to action compete with each other. One clear action converts better.`,
    });
  }
  for (const action of plan.callsToAction) {
    if (!/^https?:\/\//i.test(action.url.trim())) {
      problems.push({
        severity: 'error',
        field: 'callsToAction',
        message: `The call to action "${action.label}" does not have a full URL.`,
      });
    }
  }

  if (!plan.plainText || plan.plainText.trim().length === 0) {
    problems.push({
      severity: 'warning',
      field: 'plainText',
      message:
        'There is no plain-text version. Some clients and most filters read it, and its absence is itself a spam signal.',
    });
  }

  for (const problem of spamPhrasing(`${subject} ${plan.body}`, 'body')) problems.push(problem);

  return problems;
}

function checkWhatsapp(plan: WhatsappPlan): MessagingProblem[] {
  const problems: MessagingProblem[] = [];
  const body = plan.body.trim();

  if (plan.category !== categoryFor(plan.kind)) {
    problems.push({
      severity: 'error',
      field: 'category',
      message: `A ${WHATSAPP_KIND_LABEL[plan.kind]} template is ${categoryFor(plan.kind)}, not ${plan.category}. Sending marketing content under a utility category is a policy breach and risks the number being blocked.`,
    });
  }

  if (plan.category === 'MARKETING' && plan.optInBasis !== 'explicit_opt_in' && plan.optInBasis !== 'existing_customer') {
    problems.push({
      severity: 'error',
      field: 'optInBasis',
      message:
        'A marketing template may only go to numbers that opted in explicitly, or to existing customers about what they bought. WhatsApp enforces this, and the penalty falls on your number.',
    });
  }

  if (body.length === 0) {
    problems.push({ severity: 'error', field: 'body', message: 'The template needs a body.' });
  } else if (body.length > WHATSAPP_LIMITS.bodyCharacters) {
    problems.push({
      severity: 'error',
      field: 'body',
      message: `The body is ${body.length} characters; the official limit is ${WHATSAPP_LIMITS.bodyCharacters} (as of ${WHATSAPP_LIMITS_AS_OF}).`,
    });
  }

  if (plan.header && plan.header.trim().length > WHATSAPP_LIMITS.headerCharacters) {
    problems.push({
      severity: 'error',
      field: 'header',
      message: `The header is longer than ${WHATSAPP_LIMITS.headerCharacters} characters.`,
    });
  }
  if (plan.footer && plan.footer.trim().length > WHATSAPP_LIMITS.footerCharacters) {
    problems.push({
      severity: 'error',
      field: 'footer',
      message: `The footer is longer than ${WHATSAPP_LIMITS.footerCharacters} characters.`,
    });
  }

  if (plan.buttons.length > WHATSAPP_LIMITS.maxButtons) {
    problems.push({
      severity: 'error',
      field: 'buttons',
      message: `At most ${WHATSAPP_LIMITS.maxButtons} buttons are accepted.`,
    });
  }
  for (const button of plan.buttons) {
    if (button.label.trim().length === 0) {
      problems.push({ severity: 'error', field: 'buttons', message: 'A button needs a label.' });
    } else if (button.label.trim().length > WHATSAPP_LIMITS.buttonLabelCharacters) {
      problems.push({
        severity: 'error',
        field: 'buttons',
        message: `The button "${button.label}" is longer than ${WHATSAPP_LIMITS.buttonLabelCharacters} characters.`,
      });
    }
    if (button.kind === 'url' && !/^https?:\/\//i.test((button.value ?? '').trim())) {
      problems.push({
        severity: 'error',
        field: 'buttons',
        message: `The URL button "${button.label}" needs a full URL.`,
      });
    }
    if (button.kind === 'phone' && (button.value ?? '').trim().length === 0) {
      problems.push({
        severity: 'error',
        field: 'buttons',
        message: `The call button "${button.label}" needs a phone number.`,
      });
    }
  }

  /* -------------------------------------------------- placeholder rules */
  const used = [...body.matchAll(/\{\{(\d+)\}\}/g)].map((match) => Number(match[1]));
  const unique = [...new Set(used)].sort((a, b) => a - b);

  if (unique.length > WHATSAPP_LIMITS.maxPlaceholders) {
    problems.push({
      severity: 'error',
      field: 'body',
      message: `${unique.length} placeholders is more than the ${WHATSAPP_LIMITS.maxPlaceholders} a template is usually approved with.`,
    });
  }
  unique.forEach((number, index) => {
    if (number !== index + 1) {
      problems.push({
        severity: 'error',
        field: 'body',
        message: `Placeholders must be numbered from {{1}} with no gaps; this template uses ${unique.map((value) => `{{${value}}}`).join(', ')}.`,
      });
    }
  });
  if (unique.length !== plan.placeholders.length) {
    problems.push({
      severity: 'error',
      field: 'placeholders',
      message: `The body uses ${unique.length} placeholder(s) but ${plan.placeholders.length} are described. Every placeholder needs to say what goes in it, or nobody can review the message.`,
    });
  }
  if (/^\s*\{\{1\}\}/.test(body)) {
    problems.push({
      severity: 'error',
      field: 'body',
      message: 'A template may not begin with a placeholder — submissions are rejected for it.',
    });
  }

  for (const problem of spamPhrasing(body, 'body')) problems.push(problem);

  return problems;
}

/**
 * Phrasing that gets messages filtered, and — more importantly — phrasing that
 * makes a promise the business cannot keep.
 *
 * These are warnings rather than errors except where the phrasing is a false
 * claim, which is an error for the same reason everywhere else in this codebase.
 */
function spamPhrasing(text: string, field: string): MessagingProblem[] {
  const problems: MessagingProblem[] = [];
  const checks: readonly { readonly pattern: RegExp; readonly severity: 'error' | 'warning'; readonly message: string }[] = [
    {
      pattern: /\b(?:guaranteed|guarantee)\s+(?:results|income|returns|profit|growth|ranking)\b/i,
      severity: 'error',
      message: 'This guarantees an outcome you cannot guarantee. Remove it.',
    },
    {
      pattern: /\b(?:risk[- ]free|no risk|100%\s*(?:safe|guaranteed))\b/i,
      severity: 'error',
      message: 'A risk-free claim is one you would have to honour. Say what you actually offer instead.',
    },
    {
      pattern: /\b(?:act now|limited time only|hurry|last chance|don't miss out)\b/i,
      severity: 'warning',
      message: 'Manufactured urgency reads as spam to both filters and people.',
    },
    {
      pattern: /!{2,}/,
      severity: 'warning',
      message: 'Repeated exclamation marks are a well-known spam signal.',
    },
    {
      pattern: /\b[A-Z]{6,}\b/,
      severity: 'warning',
      message: 'Words in full capitals trigger filters and read as shouting.',
    },
    {
      pattern: /\b(?:free free|click here now|winner|congratulations you)\b/i,
      severity: 'warning',
      message: 'This phrasing is strongly associated with spam.',
    },
  ];

  for (const check of checks) {
    if (check.pattern.test(text)) {
      problems.push({ severity: check.severity, field, message: check.message });
    }
  }
  return problems;
}

export function hasMessagingErrors(problems: readonly MessagingProblem[]): boolean {
  return problems.some((problem) => problem.severity === 'error');
}

/**
 * Whether SeSha can send anything. It cannot.
 *
 * The same single-source-of-truth shape as `publishingStatus()` in Phase 3 and
 * `adsDataStatus()` in Phase 5: one function every screen reads, so no screen can
 * imply otherwise and there is one place to change when a provider is genuinely
 * connected through its official API.
 */
export function sendingStatus(channel: MessagingChannel): {
  readonly connected: false;
  readonly canSend: false;
  readonly message: string;
  readonly whatWouldBeNeeded: string;
} {
  return {
    connected: false,
    canSend: false,
    message:
      channel === 'email'
        ? 'No email provider is connected, so SeSha cannot send this. It writes and plans the message; you send it from your own provider.'
        : 'No WhatsApp Business account is connected, so SeSha cannot send this. It writes the template; you submit it for approval and send from your own account.',
    whatWouldBeNeeded:
      channel === 'email'
        ? 'An official API connection to your email provider, with your own verified sending domain.'
        : 'An official WhatsApp Business API connection through Meta or a Business Solution Provider, with your own verified number and approved templates. SeSha will not send WhatsApp messages by any other route — unofficial automation gets numbers banned.',
  };
}
