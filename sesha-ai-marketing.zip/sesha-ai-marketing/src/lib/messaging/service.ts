/**
 * Messaging plan service (email and WhatsApp).
 *
 * THE REFUSAL IS THE FEATURE
 * `checkMessagingPlan` returns an error for a plan with no lawful basis, for a
 * bought list, for a marketing email with no unsubscribe. This service does not
 * merely pass those along — it REFUSES TO STORE the plan at all when the basis is
 * forbidden, and the database CHECK refuses the row independently. Three
 * independent refusals, for the same reason the provenance system has three: a
 * single check is a single thing to get wrong.
 *
 * NOTHING HERE SENDS. There is no `send`, no scheduler, no recipient list. See
 * `sendingStatus()`.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { assertTenant, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { MessagingPlanRow } from '@/lib/db/types';

import {
  BASIS_REFUSAL,
  categoryFor,
  checkMessagingPlan,
  hasMessagingErrors,
  isEmailKind,
  isForbiddenBasis,
  isWhatsappKind,
  sendingStatus,
  type MessagingChannel,
  type MessagingPlan,
  type MessagingProblem,
  type OptInBasis,
} from './types';

export interface MessagingServiceContext {
  readonly db: Database;
  readonly now?: () => Date;
}

function clock(context: MessagingServiceContext): Date {
  return context.now?.() ?? new Date();
}

export class MessagingInputError extends Error {
  readonly code = 'INVALID_INPUT' as const;
  readonly problems: readonly MessagingProblem[];
  constructor(message: string, problems: readonly MessagingProblem[] = []) {
    super(message);
    this.name = 'MessagingInputError';
    this.problems = problems;
  }
}

/** Refusing to plan a message at all, as distinct from a plan with mistakes in it. */
export class UnlawfulAudienceError extends Error {
  readonly code = 'UNLAWFUL_AUDIENCE' as const;
  constructor(basis: OptInBasis) {
    super(BASIS_REFUSAL[basis] ?? 'There is no lawful basis for messaging this audience.');
    this.name = 'UnlawfulAudienceError';
  }
}

export interface SaveMessagingPlanInput {
  readonly projectId: string;
  readonly title: string;
  readonly plan: MessagingPlan;
  readonly reviewState?: MessagingPlanRow['reviewState'];
}

export interface SavedMessagingPlan {
  readonly row: MessagingPlanRow;
  readonly problems: readonly MessagingProblem[];
  readonly sending: ReturnType<typeof sendingStatus>;
}

export async function saveMessagingPlan(
  context: MessagingServiceContext,
  tenant: TenantContext,
  input: SaveMessagingPlanInput,
): Promise<SavedMessagingPlan> {
  requirePermission(tenant.role, 'content:create');

  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, input.projectId),
    'Project',
  );

  const plan = input.plan;

  // FIRST REFUSAL: the basis. Before validation, before storage, before anything
  // — because a campaign to a bought list should not reach the stage of having
  // its subject line critiqued.
  if (isForbiddenBasis(plan.optInBasis)) {
    throw new UnlawfulAudienceError(plan.optInBasis);
  }

  if (plan.channel === 'email' && !isEmailKind(plan.kind)) {
    throw new MessagingInputError('That is not an email kind SeSha plans for.');
  }
  if (plan.channel === 'whatsapp' && !isWhatsappKind(plan.kind)) {
    throw new MessagingInputError('That is not a WhatsApp template kind SeSha plans for.');
  }

  const problems = checkMessagingPlan(plan);
  const requested = input.reviewState ?? 'draft';

  // SECOND REFUSAL: approval requires no errors. A marketing email with no
  // unsubscribe is an error, so it cannot be approved.
  if (requested === 'approved' && hasMessagingErrors(problems)) {
    throw new MessagingInputError(
      'This cannot be marked ready while it has errors.',
      problems,
    );
  }

  const row = await context.db.messagingPlans.create({
    organizationId: tenant.organizationId,
    projectId: project.id,
    createdBy: tenant.userId,
    channel: plan.channel,
    kind: plan.kind,
    // The category is derived, never taken from the request: a marketing message
    // submitted under a utility category is a policy breach, and letting the
    // caller choose is how that happens.
    category: plan.channel === 'whatsapp' ? categoryFor(plan.kind) : null,
    title: input.title.trim(),
    plan: plan as unknown as Readonly<Record<string, unknown>>,
    problems: problems as unknown as readonly Readonly<Record<string, unknown>>[],
    optInBasis: plan.optInBasis as MessagingPlanRow['optInBasis'],
    audienceNote: plan.audienceDescription.trim(),
    reviewState: requested,
  });

  return { row, problems, sending: sendingStatus(plan.channel) };
}

export async function listMessagingPlans(
  context: MessagingServiceContext,
  tenant: TenantContext,
  projectId: string,
  channel?: MessagingChannel,
): Promise<readonly MessagingPlanRow[]> {
  requirePermission(tenant.role, 'content:read');
  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, projectId),
    'Project',
  );
  return context.db.messagingPlans.listForProject(tenant.organizationId, project.id, channel);
}

export async function getMessagingPlan(
  context: MessagingServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<{
  readonly row: MessagingPlanRow;
  readonly problems: readonly MessagingProblem[];
  readonly sending: ReturnType<typeof sendingStatus>;
}> {
  requirePermission(tenant.role, 'content:read');
  const row = assertTenant(
    tenant,
    await context.db.messagingPlans.findById(tenant.organizationId, id),
    'Message plan',
  );
  const problems = checkMessagingPlan(row.plan as unknown as MessagingPlan);
  return { row, problems, sending: sendingStatus(row.channel) };
}

/** Re-validates before approving, rather than trusting the stored problems. */
export async function setMessagingReviewState(
  context: MessagingServiceContext,
  tenant: TenantContext,
  id: string,
  reviewState: MessagingPlanRow['reviewState'],
): Promise<SavedMessagingPlan> {
  requirePermission(tenant.role, 'content:create');

  const existing = assertTenant(
    tenant,
    await context.db.messagingPlans.findById(tenant.organizationId, id),
    'Message plan',
  );

  const plan = existing.plan as unknown as MessagingPlan;
  const problems = checkMessagingPlan(plan);
  if (reviewState === 'approved' && hasMessagingErrors(problems)) {
    throw new MessagingInputError('This still has errors, so it cannot be marked ready.', problems);
  }

  const row = await context.db.messagingPlans.update(tenant.organizationId, existing.id, {
    reviewState,
    problems: problems as unknown as readonly Readonly<Record<string, unknown>>[],
  });
  if (!row) throw new MessagingInputError('That plan could not be updated.');
  return { row, problems, sending: sendingStatus(row.channel) };
}

export async function deleteMessagingPlan(
  context: MessagingServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<void> {
  requirePermission(tenant.role, 'content:create');
  const existing = assertTenant(
    tenant,
    await context.db.messagingPlans.findById(tenant.organizationId, id),
    'Message plan',
  );
  await context.db.messagingPlans.softDelete(tenant.organizationId, existing.id, clock(context));
}
