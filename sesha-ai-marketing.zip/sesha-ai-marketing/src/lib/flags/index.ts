/**
 * Feature flags.
 *
 * THE DEFAULT IS OFF, AND THE DEFAULT IS THE SAFE ANSWER
 * `evaluate()` returns the flag's declared default when nothing matches, and
 * every declared default here is `false` except the module flags that are
 * already shipped. A flag system whose failure mode is "on" turns a missing row
 * into a launch — and the missing row always happens on the day the database is
 * slow, to the customer you least want it to happen to.
 *
 * EVERY DECISION CARRIES ITS REASON
 * `FlagDecision` has a `because`, and the admin panel shows it. "Why can this
 * customer see the beta and that one cannot" is the question a flag system
 * exists to answer, and the usual implementation — a boolean and a shrug —
 * cannot answer it.
 *
 * THE KILL SWITCH IS NOT A FLAG SET TO FALSE
 * `disabled` on a definition beats every rule, every targeting list and every
 * override. When an AI provider is melting down at 2am, the person on call needs
 * one thing to turn off that nothing else can re-enable. A flag that a
 * per-organization override could switch back on is not a kill switch.
 *
 * Framework-free and fully unit tested.
 */

import { PLANS, type PlanId } from '@/content/plans';

/* -------------------------------------------------------------------------- */
/* What a flag is                                                             */
/* -------------------------------------------------------------------------- */

/** The five categories the brief names. */
export const FLAG_CATEGORIES = [
  'ai_provider',
  'module',
  'beta',
  'plan',
  'experimental',
] as const;

export type FlagCategory = (typeof FLAG_CATEGORIES)[number];

export const CATEGORY_LABEL: Readonly<Record<FlagCategory, string>> = {
  ai_provider: 'AI providers',
  module: 'Modules',
  beta: 'Beta features',
  plan: 'Plan features',
  experimental: 'Experimental',
};

export interface FlagDefinition {
  readonly key: string;
  readonly label: string;
  /** What turning it on actually does. Written for whoever is on call. */
  readonly description: string;
  readonly category: FlagCategory;
  /** The answer when no rule matches. */
  readonly defaultValue: boolean;
  /**
   * True when the flag is only meaningful once something external exists — an
   * API key, a connected provider. The admin panel renders it as unavailable
   * with the reason rather than as a switch that does nothing.
   */
  readonly requires?: string;
}

/**
 * The flags the product declares.
 *
 * Deliberately a fixed registry rather than free-form strings. A flag created by
 * typing a new key into a form is a flag nobody can find, nobody documents, and
 * nobody removes — and `evaluate()` on an unknown key has to guess, which
 * defeats the point of a safe default.
 */
export const FLAG_DEFINITIONS: readonly FlagDefinition[] = [
  /* ------------------------------- providers ------------------------------ */
  {
    key: 'provider.openai',
    label: 'OpenAI',
    description:
      'Allows the orchestrator to select OpenAI. Turning this off routes every request to the remaining providers; turning all of them off stops AI generation entirely, which the copilot reports as unavailable rather than failing silently.',
    category: 'ai_provider',
    defaultValue: true,
    requires: 'OPENAI_API_KEY',
  },
  {
    key: 'provider.anthropic',
    label: 'Anthropic',
    description: 'Allows the orchestrator to select Anthropic.',
    category: 'ai_provider',
    defaultValue: true,
    requires: 'ANTHROPIC_API_KEY',
  },
  {
    key: 'provider.gemini',
    label: 'Google Gemini',
    description: 'Allows the orchestrator to select Gemini.',
    category: 'ai_provider',
    defaultValue: true,
    requires: 'GEMINI_API_KEY',
  },

  /* -------------------------------- modules ------------------------------- */
  {
    key: 'module.crawler',
    label: 'Website crawler',
    description:
      'The crawler and everything downstream of it — SEO and AEO audits, keywords, page-level schema checks. Off means no new crawl starts; stored results still open.',
    category: 'module',
    defaultValue: true,
  },
  {
    key: 'module.competitors',
    label: 'Competitor intelligence',
    description: 'Reading a named competitor’s public pages. Off means no new analysis starts.',
    category: 'module',
    defaultValue: true,
  },
  {
    key: 'module.automations',
    label: 'Automations',
    description:
      'Evaluating automation rules. Off means no rule fires; rules keep their configuration and their history.',
    category: 'module',
    defaultValue: true,
  },
  {
    key: 'module.reports',
    label: 'Reports',
    description: 'Generating and exporting reports. Stored reports still open and still export.',
    category: 'module',
    defaultValue: true,
  },

  /* --------------------------------- beta --------------------------------- */
  {
    key: 'beta.report_sharing',
    label: 'Share reports by link',
    description:
      'Revocable public links to a generated report. This is the only feature that serves tenant data to someone who is not signed in, which is why it is behind a flag.',
    category: 'beta',
    defaultValue: false,
  },
  {
    key: 'beta.calendar_suggestions',
    label: 'Calendar suggestions',
    description:
      'Suggesting activities for empty calendar dates, drawn from the customer’s own findings and stated channels.',
    category: 'beta',
    defaultValue: true,
  },

  /* --------------------------------- plan --------------------------------- */
  {
    key: 'plan.self_serve_checkout',
    label: 'Self-serve checkout',
    description:
      'Lets a customer buy or change a plan themselves. Requires a connected payment provider; without one the button is not shown at all.',
    category: 'plan',
    defaultValue: false,
    requires: 'a connected payment provider',
  },
  {
    key: 'plan.free_signup',
    label: 'Free plan on sign-up',
    description: 'New organizations start on Free rather than on a trial of a paid plan.',
    category: 'plan',
    defaultValue: true,
  },

  /* ----------------------------- experimental ----------------------------- */
  {
    key: 'experimental.ai_report_commentary',
    label: 'AI commentary on reports',
    description:
      'Prose written over the rule-based report sections. Off by default: the sections are built from records and say when a cause is not visible, and generated narrative can undo that.',
    category: 'experimental',
    defaultValue: false,
  },
  {
    key: 'experimental.schema_auto_publish',
    label: 'Publish generated JSON-LD automatically',
    description:
      'Not implemented, and declared here so its absence is visible: SeSha has no write access to any customer website and generating markup is not publishing it.',
    category: 'experimental',
    defaultValue: false,
    requires: 'write access to the customer website, which SeSha does not have',
  },
];

const BY_KEY: ReadonlyMap<string, FlagDefinition> = new Map(
  FLAG_DEFINITIONS.map((definition) => [definition.key, definition]),
);

export const FLAG_KEYS: readonly string[] = FLAG_DEFINITIONS.map((definition) => definition.key);

export function isFlagKey(value: unknown): value is string {
  return typeof value === 'string' && BY_KEY.has(value);
}

export function flagDefinition(key: string): FlagDefinition | null {
  return BY_KEY.get(key) ?? null;
}

/* -------------------------------------------------------------------------- */
/* Rules                                                                      */
/* -------------------------------------------------------------------------- */

/**
 * A stored rule for one flag.
 *
 * Precedence, highest first:
 *   1. `disabled`            — the kill switch. Nothing overrides it.
 *   2. `organizationIds`     — a named organization. Beats the plan and the roll-out.
 *   3. `plans`               — every organization on those plans.
 *   4. `rolloutPercent`      — a stable slice, by hash of the organization id.
 *   5. the definition default.
 *
 * Ordering matters and is asserted by tests: a roll-out that could override a
 * named exclusion would make "turn it off for this customer" unreliable, which
 * is the one thing support needs it for.
 */
export interface FlagRule {
  readonly key: string;
  /** The kill switch. Beats everything below. */
  readonly disabled: boolean;
  /** Explicitly on for these organizations. */
  readonly organizationIds: readonly string[];
  /** Explicitly OFF for these, whatever else says. Checked before the ons. */
  readonly excludedOrganizationIds: readonly string[];
  readonly plans: readonly PlanId[];
  /** 0–100. A stable slice, not a coin flip — see `inRollout`. */
  readonly rolloutPercent: number;
  readonly updatedBy: string | null;
  readonly updatedAt: string;
}

export function emptyRule(key: string): FlagRule {
  return {
    key,
    disabled: false,
    organizationIds: [],
    excludedOrganizationIds: [],
    plans: [],
    rolloutPercent: 0,
    updatedBy: null,
    updatedAt: new Date(0).toISOString(),
  };
}

/* -------------------------------------------------------------------------- */
/* Evaluation                                                                 */
/* -------------------------------------------------------------------------- */

export interface FlagTarget {
  readonly organizationId: string;
  readonly plan: PlanId;
}

export interface FlagDecision {
  readonly key: string;
  readonly enabled: boolean;
  /** Which rule decided, so the admin panel can explain itself. */
  readonly because:
    | 'kill_switch'
    | 'organization_excluded'
    | 'organization_included'
    | 'plan'
    | 'rollout'
    | 'default'
    | 'unknown_flag';
  readonly explanation: string;
}

/**
 * A stable slice of organizations.
 *
 * Hashed, not random: the same organization must get the same answer on every
 * request. A `Math.random()` roll-out flickers a feature on and off between page
 * loads, which users report as the product being broken — and they are right.
 *
 * FNV-1a, written out because it is four lines and a dependency for this would
 * be absurd. It is not a security hash and is not used as one.
 */
export function inRollout(organizationId: string, percent: number, key: string): boolean {
  if (percent <= 0) return false;
  if (percent >= 100) return true;
  // The key is mixed in so two flags at 10% do not select the SAME 10% of
  // customers — otherwise one unlucky cohort receives every experiment.
  const input = `${key}:${organizationId}`;
  let hash = 0x811c9dc5;
  for (let index = 0; index < input.length; index += 1) {
    hash ^= input.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash % 100 < percent;
}

export function evaluate(
  key: string,
  target: FlagTarget,
  rule: FlagRule | null,
): FlagDecision {
  const definition = flagDefinition(key);
  if (!definition) {
    return {
      key,
      enabled: false,
      because: 'unknown_flag',
      explanation: `"${key}" is not a flag this product declares, so it is off. Flags are a fixed registry; a typo cannot switch something on.`,
    };
  }

  if (rule?.disabled) {
    return {
      key,
      enabled: false,
      because: 'kill_switch',
      explanation: `${definition.label} is switched off for everyone. Nothing overrides this — not a plan, not a named organization, not a roll-out.`,
    };
  }

  if (rule && rule.excludedOrganizationIds.includes(target.organizationId)) {
    return {
      key,
      enabled: false,
      because: 'organization_excluded',
      explanation: `${definition.label} is switched off for this organization specifically.`,
    };
  }

  if (rule && rule.organizationIds.includes(target.organizationId)) {
    return {
      key,
      enabled: true,
      because: 'organization_included',
      explanation: `${definition.label} is switched on for this organization specifically.`,
    };
  }

  if (rule && rule.plans.includes(target.plan)) {
    return {
      key,
      enabled: true,
      because: 'plan',
      explanation: `${definition.label} is on for every organization on the ${target.plan} plan.`,
    };
  }

  if (rule && inRollout(target.organizationId, rule.rolloutPercent, key)) {
    return {
      key,
      enabled: true,
      because: 'rollout',
      explanation: `${definition.label} is in a ${rule.rolloutPercent}% roll-out, and this organization is inside it. The selection is stable — it will not change between page loads.`,
    };
  }

  return {
    key,
    enabled: definition.defaultValue,
    because: 'default',
    explanation: definition.defaultValue
      ? `${definition.label} is on by default.`
      : `${definition.label} is off by default, and no rule turns it on for this organization.`,
  };
}

/** Every flag, decided for one target. What the admin panel renders. */
export function evaluateAll(
  target: FlagTarget,
  rules: readonly FlagRule[],
): readonly FlagDecision[] {
  return FLAG_DEFINITIONS.map((definition) =>
    evaluate(definition.key, target, rules.find((rule) => rule.key === definition.key) ?? null),
  );
}

/** Validates a rule an admin submitted. Returns problems; empty means fine. */
export function checkRule(rule: Partial<FlagRule> & { readonly key: string }): readonly string[] {
  const problems: string[] = [];
  if (!isFlagKey(rule.key)) {
    problems.push(`"${rule.key}" is not a flag this product declares.`);
    return problems;
  }
  const percent = rule.rolloutPercent;
  if (percent !== undefined && (!Number.isInteger(percent) || percent < 0 || percent > 100)) {
    problems.push('A roll-out percentage is a whole number between 0 and 100.');
  }
  for (const plan of rule.plans ?? []) {
    if (!(PLANS as readonly string[]).includes(plan)) {
      problems.push(`"${plan}" is not a plan.`);
    }
  }
  const overlap = (rule.organizationIds ?? []).filter((id) =>
    (rule.excludedOrganizationIds ?? []).includes(id),
  );
  if (overlap.length > 0) {
    problems.push(
      `An organization cannot be both included and excluded (${overlap.join(', ')}). Exclusion would win, so the inclusion is misleading — remove one.`,
    );
  }
  return problems;
}
