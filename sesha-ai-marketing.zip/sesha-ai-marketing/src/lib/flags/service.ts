/**
 * Feature flags, resolved against the database.
 *
 * THE FAILURE MODE IS OFF.
 * If the rules cannot be read, `isEnabled()` falls back to the flag's declared
 * default rather than throwing or guessing. Every experimental and beta default
 * is `false`, so a database problem cannot launch a feature — which is the whole
 * reason the default lives in code rather than in the row.
 *
 * A FLAG THAT NEEDS SOMETHING EXTERNAL REPORTS THAT SEPARATELY.
 * `provider.openai` being on does not mean OpenAI works; it means we are willing
 * to try it. `available()` reports whether the thing it depends on actually
 * exists, so the admin panel can render "on, but there is no API key" instead of
 * a switch that appears to work and does nothing.
 */

import type { Database } from '@/lib/db/repositories';
import type { PlanId } from '@/content/plans';
import { configuredProviders, type ProviderName } from '@/lib/ai/provider';

import {
  FLAG_DEFINITIONS,
  evaluate,
  evaluateAll,
  flagDefinition,
  isFlagKey,
  type FlagDecision,
  type FlagRule,
  type FlagTarget,
} from './index';

export interface FlagServiceContext {
  readonly db: Database;
  readonly now?: () => Date;
}

function toRule(row: {
  readonly key: string;
  readonly disabled: boolean;
  readonly organizationIds: readonly string[];
  readonly excludedOrganizationIds: readonly string[];
  readonly plans: readonly string[];
  readonly rolloutPercent: number;
  readonly updatedBy: string | null;
  readonly updatedAt: Date;
}): FlagRule {
  return {
    key: row.key,
    disabled: row.disabled,
    organizationIds: row.organizationIds,
    excludedOrganizationIds: row.excludedOrganizationIds,
    plans: row.plans as readonly PlanId[],
    rolloutPercent: row.rolloutPercent,
    updatedBy: row.updatedBy,
    updatedAt: row.updatedAt.toISOString(),
  };
}

/** One flag, for one organization. */
export async function isEnabled(
  context: FlagServiceContext,
  key: string,
  target: FlagTarget,
): Promise<boolean> {
  return (await decide(context, key, target)).enabled;
}

/** One flag with the reason, for a screen that has to explain itself. */
export async function decide(
  context: FlagServiceContext,
  key: string,
  target: FlagTarget,
): Promise<FlagDecision> {
  if (!isFlagKey(key)) return evaluate(key, target, null);
  try {
    const row = await context.db.featureFlags.find(key);
    return evaluate(key, target, row ? toRule(row) : null);
  } catch {
    // The safe answer, not an exception. See the header.
    return evaluate(key, target, null);
  }
}

/** Every flag for one organization. What the settings and admin screens render. */
export async function decideAll(
  context: FlagServiceContext,
  target: FlagTarget,
): Promise<readonly FlagDecision[]> {
  try {
    const rows = await context.db.featureFlags.list();
    return evaluateAll(target, rows.map(toRule));
  } catch {
    return evaluateAll(target, []);
  }
}

/* -------------------------------------------------------------------------- */
/* Availability                                                               */
/* -------------------------------------------------------------------------- */

export interface FlagAvailability {
  readonly key: string;
  /** False when the thing the flag depends on does not exist. */
  readonly available: boolean;
  readonly reason?: string;
}

/**
 * Whether the dependency a flag needs actually exists.
 *
 * Deliberately explicit per flag rather than a generic env-var lookup: the
 * payment-provider and website-write-access cases are not environment
 * variables, and a generic check would report them as available because no
 * variable was missing.
 */
export function available(key: string): FlagAvailability {
  const definition = flagDefinition(key);
  if (!definition) return { key, available: false, reason: 'Not a flag this product declares.' };
  if (definition.requires === undefined) return { key, available: true };

  switch (key) {
    case 'provider.openai':
      return providerConfigured(key, 'openai', 'OPENAI_API_KEY');
    case 'provider.anthropic':
      return providerConfigured(key, 'anthropic', 'ANTHROPIC_API_KEY');
    case 'provider.gemini':
      return providerConfigured(key, 'gemini', 'GEMINI_API_KEY');
    case 'plan.self_serve_checkout':
      return {
        key,
        available: false,
        reason:
          'No payment provider is connected, so checkout cannot run whatever this flag says. Connect one first.',
      };
    case 'experimental.schema_auto_publish':
      return {
        key,
        available: false,
        reason:
          'SeSha has no write access to any customer website, and generating markup is not publishing it. This flag cannot be made to work by switching it on.',
      };
    default:
      return { key, available: true };
  }
}

/**
 * Whether a provider is usable.
 *
 * Asks `lib/ai/provider.ts` rather than reading the key variable here. The key
 * variables are read in exactly one module so there is one place to audit, and
 * `tests/ai-security.test.ts` fails if a second module reads them — which it did
 * when this function was first written with a `process.env` lookup.
 */
function providerConfigured(
  key: string,
  name: ProviderName,
  variable: string,
): FlagAvailability {
  const configured = configuredProviders().some((provider) => provider.name === name);
  return configured
    ? { key, available: true }
    : {
        key,
        available: false,
        reason: `${variable} is not set, so this provider cannot be used even with the flag on.`,
      };
}

/** Every flag with its availability, for the admin panel. */
export function availability(): readonly FlagAvailability[] {
  return FLAG_DEFINITIONS.map((definition) => available(definition.key));
}
