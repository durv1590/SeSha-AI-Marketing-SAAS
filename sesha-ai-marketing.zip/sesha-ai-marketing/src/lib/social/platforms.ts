/**
 * Social platform specifications.
 *
 * Seven platforms with their real constraints, plus the planning model.
 *
 * THE PUBLISHING RULE, which shapes everything in this file:
 * NOTHING HERE PUBLISHES. No platform API is connected, so a post cannot leave
 * this product. The status values stop at `ready` — there is deliberately no
 * `published` and no `scheduled` state, and `canPublish` is false for every
 * platform with the reason recorded. The brief says not to pretend to publish
 * unless an official API is actually connected; the way to keep that promise is
 * to make the unpublishable state unrepresentable rather than to remember not
 * to use it.
 *
 * Framework-free and fully unit tested.
 */

export const PLATFORMS = [
  'instagram',
  'facebook',
  'linkedin',
  'youtube',
  'x',
  'pinterest',
  'whatsapp',
] as const;

export type Platform = (typeof PLATFORMS)[number];

export interface PlatformFormat {
  readonly id: string;
  readonly label: string;
  /** Caption or body limit, where the platform enforces one. */
  readonly maxCharacters: number;
  readonly notes: string;
}

export interface PlatformSpec {
  readonly id: Platform;
  readonly label: string;
  readonly formats: readonly PlatformFormat[];
  readonly hashtags: {
    readonly supported: boolean;
    /** What actually works, not what the platform permits. */
    readonly recommended: number;
    readonly max: number;
  };
  /**
   * False for every platform. `publishBlockedReason` says why, and the
   * interface shows it rather than a disabled button with no explanation.
   */
  readonly canPublish: false;
  readonly publishBlockedReason: string;
  /** What connecting the official API would require. */
  readonly apiRequirement: string;
  readonly audienceNote: string;
}

export const PLATFORM_SPECS: Record<Platform, PlatformSpec> = {
  instagram: {
    id: 'instagram',
    label: 'Instagram',
    formats: [
      { id: 'feed', label: 'Feed post', maxCharacters: 2200, notes: 'Only the first ~125 characters show before "more".' },
      { id: 'carousel', label: 'Carousel', maxCharacters: 2200, notes: 'Up to 10 slides. Plan a hook slide and a payoff slide.' },
      { id: 'reel', label: 'Reel', maxCharacters: 2200, notes: 'Vertical video. The first 3 seconds decide whether it is watched.' },
      { id: 'story', label: 'Story', maxCharacters: 250, notes: '24 hours. Keep on-screen text short.' },
    ],
    hashtags: { supported: true, recommended: 8, max: 30 },
    canPublish: false,
    publishBlockedReason: 'No Instagram Graph API connection is configured.',
    apiRequirement: 'Instagram Graph API via a Facebook Business account, with a reviewed app and a Professional account.',
    audienceNote: 'Visual first. The caption supports the image; it does not replace it.',
  },

  facebook: {
    id: 'facebook',
    label: 'Facebook',
    formats: [
      { id: 'post', label: 'Page post', maxCharacters: 63206, notes: 'Long posts are truncated in the feed. Front-load the point.' },
      { id: 'reel', label: 'Reel', maxCharacters: 2200, notes: 'Vertical short video.' },
      { id: 'story', label: 'Story', maxCharacters: 250, notes: 'Disappears after 24 hours. One idea per card, large on-screen text.' },
    ],
    hashtags: { supported: true, recommended: 2, max: 10 },
    canPublish: false,
    publishBlockedReason: 'No Facebook Pages API connection is configured.',
    apiRequirement: 'Facebook Pages API with a reviewed app and a Page access token.',
    audienceNote: 'Broad age range. Plain language outperforms industry vocabulary.',
  },

  linkedin: {
    id: 'linkedin',
    label: 'LinkedIn',
    formats: [
      { id: 'post', label: 'Post', maxCharacters: 3000, notes: 'Only ~140 characters show before "see more".' },
      { id: 'article', label: 'Article', maxCharacters: 110000, notes: 'Long-form, hosted on LinkedIn.' },
      { id: 'document', label: 'Document post', maxCharacters: 3000, notes: 'A PDF carousel. Plan it as slides.' },
    ],
    hashtags: { supported: true, recommended: 3, max: 10 },
    canPublish: false,
    publishBlockedReason: 'No LinkedIn Marketing API connection is configured.',
    apiRequirement: 'LinkedIn Marketing Developer Platform access with w_organization_social permission.',
    audienceNote: 'Professional context. Specifics and lessons land; motivational filler does not.',
  },

  youtube: {
    id: 'youtube',
    label: 'YouTube',
    formats: [
      { id: 'video', label: 'Video', maxCharacters: 5000, notes: 'Description field. The first 2 lines show above the fold.' },
      { id: 'short', label: 'Short', maxCharacters: 5000, notes: 'Vertical, under 60 seconds.' },
      { id: 'community', label: 'Community post', maxCharacters: 1500, notes: 'Text or poll to subscribers.' },
    ],
    hashtags: { supported: true, recommended: 3, max: 15 },
    canPublish: false,
    publishBlockedReason: 'No YouTube Data API connection is configured.',
    apiRequirement: 'YouTube Data API v3 with OAuth and, for upload quota beyond the default, an audited project.',
    audienceNote: 'Search-driven as much as feed-driven. Titles and descriptions matter for discovery.',
  },

  x: {
    id: 'x',
    label: 'X',
    formats: [
      { id: 'post', label: 'Post', maxCharacters: 280, notes: 'Hard limit for standard accounts.' },
      { id: 'thread', label: 'Thread', maxCharacters: 280, notes: 'Per post. Each one must stand alone.' },
    ],
    hashtags: { supported: true, recommended: 1, max: 3 },
    canPublish: false,
    publishBlockedReason: 'No X API connection is configured.',
    apiRequirement: 'X API v2 with a paid tier that permits posting.',
    audienceNote: 'Fast and compressed. One idea per post; no wind-up.',
  },

  pinterest: {
    id: 'pinterest',
    label: 'Pinterest',
    formats: [
      { id: 'pin', label: 'Pin', maxCharacters: 500, notes: 'Description. Vertical 2:3 images perform best.' },
      { id: 'idea-pin', label: 'Idea Pin', maxCharacters: 500, notes: 'Multi-page format.' },
    ],
    hashtags: { supported: true, recommended: 4, max: 20 },
    canPublish: false,
    publishBlockedReason: 'No Pinterest API connection is configured.',
    apiRequirement: 'Pinterest API for Business with a reviewed app.',
    audienceNote: 'A planning surface more than a social feed. People arrive with intent, often well ahead of buying.',
  },

  whatsapp: {
    id: 'whatsapp',
    label: 'WhatsApp Business',
    formats: [
      { id: 'broadcast', label: 'Broadcast message', maxCharacters: 1024, notes: 'Template messages need prior approval from Meta.' },
      { id: 'status', label: 'Status', maxCharacters: 700, notes: 'Disappears after 24 hours. Only contacts who have your number will see it.' },
    ],
    hashtags: { supported: false, recommended: 0, max: 0 },
    canPublish: false,
    publishBlockedReason: 'No WhatsApp Business Platform connection is configured.',
    apiRequirement: 'WhatsApp Business Platform (Cloud API) with a verified business and approved message templates.',
    audienceNote: 'A personal channel. Messaging without explicit opt-in damages trust and breaches platform policy.',
  },
};

export function isPlatform(value: unknown): value is Platform {
  return typeof value === 'string' && (PLATFORMS as readonly string[]).includes(value);
}

export function getPlatform(id: Platform): PlatformSpec {
  return PLATFORM_SPECS[id];
}

export function allPlatforms(): PlatformSpec[] {
  return PLATFORMS.map((id) => PLATFORM_SPECS[id]);
}

/**
 * Whether anything can currently be published anywhere.
 *
 * A function rather than a constant so that connecting a real API later is a
 * change in one place — and so a test can assert the answer is false today.
 */
export function anyPlatformConnected(): boolean {
  return allPlatforms().some((platform) => platform.canPublish);
}

/* -------------------------------------------------------------------------- */
/* Planning model                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Post lifecycle.
 *
 * There is no 'published' and no 'scheduled'. `ready` means a person can copy
 * it out and post it themselves. When a platform API is genuinely connected,
 * add the state then — not before.
 */
export const POST_STATUSES = ['idea', 'draft', 'ready', 'archived'] as const;
export type PostStatus = (typeof POST_STATUSES)[number];

export interface SocialPostDraft {
  readonly platform: Platform;
  readonly format: string;
  readonly caption: string;
  readonly hashtags: readonly string[];
  readonly idea: string | null;
  readonly status: PostStatus;
  readonly plannedFor: string | null;
}

export interface SocialIssue {
  readonly severity: 'error' | 'warning';
  readonly message: string;
}

/** Validates a draft against the platform's real limits. */
export function checkPost(draft: SocialPostDraft): SocialIssue[] {
  const issues: SocialIssue[] = [];
  const spec = PLATFORM_SPECS[draft.platform];
  const format = spec.formats.find((f) => f.id === draft.format);

  // Checked at RUNTIME as well as in the type. The type stops a mistake in this
  // codebase; this stops a value that arrived from a request body, a migration,
  // or a cast. "Cannot be published" has to hold even when the type system is
  // not in the room.
  if (!(POST_STATUSES as readonly string[]).includes(draft.status)) {
    issues.push({
      severity: 'error',
      message: `"${String(draft.status)}" is not a valid status. Publishing is not available: no platform API is connected.`,
    });
  }

  if (!format) {
    return [
      ...issues,
      { severity: 'error', message: `${spec.label} has no format called "${draft.format}".` },
    ];
  }

  const caption = draft.caption.trim();
  if (caption.length === 0) {
    issues.push({ severity: 'error', message: 'The caption is empty.' });
  }

  // Hashtags count toward the caption limit on every platform that has one.
  const hashtagLength = draft.hashtags.length > 0 ? draft.hashtags.join(' ').length + 1 : 0;
  const total = caption.length + hashtagLength;

  if (total > format.maxCharacters) {
    issues.push({
      severity: 'error',
      message: `${total} characters exceeds the ${format.maxCharacters}-character limit for a ${spec.label} ${format.label.toLowerCase()}.`,
    });
  }

  if (draft.hashtags.length > 0 && !spec.hashtags.supported) {
    issues.push({
      severity: 'error',
      message: `${spec.label} does not use hashtags.`,
    });
  } else if (draft.hashtags.length > spec.hashtags.max) {
    issues.push({
      severity: 'error',
      message: `${draft.hashtags.length} hashtags exceeds the ${spec.hashtags.max} allowed on ${spec.label}.`,
    });
  } else if (draft.hashtags.length > spec.hashtags.recommended * 2) {
    issues.push({
      severity: 'warning',
      message: `${draft.hashtags.length} hashtags is a lot for ${spec.label}; around ${spec.hashtags.recommended} works better.`,
    });
  }

  for (const tag of draft.hashtags) {
    // \p{M} matters: Devanagari vowel signs (कॉफी) are combining marks, not
    // letters. Without it a valid Hindi hashtag is rejected as malformed.
    if (!/^#?[\p{L}\p{N}_][\p{L}\p{N}\p{M}_]*$/u.test(tag)) {
      issues.push({ severity: 'error', message: `"${tag}" is not a valid hashtag.` });
      break;
    }
  }

  if (draft.plannedFor && !/^\d{4}-\d{2}-\d{2}$/.test(draft.plannedFor)) {
    issues.push({ severity: 'error', message: 'The planned date must be YYYY-MM-DD.' });
  }

  return issues;
}

export function normalizeHashtag(tag: string): string {
  // Combining marks are kept (see checkPost) or "#कॉफी" would become "#कफ".
  const cleaned = tag
    .trim()
    .replace(/^#+/, '')
    .replace(/[^\p{L}\p{N}\p{M}_]/gu, '')
    .replace(/^\p{M}+/u, '');
  return cleaned.length > 0 ? `#${cleaned}` : '';
}

export function normalizeHashtags(tags: readonly string[], max: number): string[] {
  const seen = new Set<string>();
  for (const tag of tags) {
    const normalized = normalizeHashtag(tag);
    if (normalized.length > 1) seen.add(normalized.toLowerCase());
    if (seen.size >= max) break;
  }
  return [...seen];
}

/** The instruction handed to the social agent. */
export function buildSocialBrief(
  platform: Platform,
  format: string,
  topic: string,
  count: number,
): string {
  const spec = PLATFORM_SPECS[platform];
  const formatSpec = spec.formats.find((f) => f.id === format) ?? spec.formats[0]!;

  return [
    `PLATFORM: ${spec.label}`,
    `FORMAT: ${formatSpec.label}`,
    `PLATFORM NOTES: ${formatSpec.notes}`,
    `AUDIENCE NOTE: ${spec.audienceNote}`,
    `HARD LIMIT: ${formatSpec.maxCharacters} characters including hashtags.`,
    spec.hashtags.supported
      ? `HASHTAGS: about ${spec.hashtags.recommended}, never more than ${spec.hashtags.max}.`
      : 'HASHTAGS: this platform does not use them. Do not include any.',
    `TOPIC: ${topic}`,
    `PRODUCE: ${count} distinct option(s). Distinct means a different angle, not a reworded version of the same one.`,
    'You cannot publish these. Do not write as though you can, and do not refer to scheduling.',
  ].join('\n');
}

/** Calendar entry, used by the planning view. */
export interface CalendarEntry {
  readonly date: string;
  readonly platform: Platform;
  readonly format: string;
  readonly caption: string;
  readonly status: PostStatus;
}

/** Groups planned posts by date for the calendar. */
export function groupByDate(entries: readonly CalendarEntry[]): Map<string, CalendarEntry[]> {
  const grouped = new Map<string, CalendarEntry[]>();
  for (const entry of entries) {
    const existing = grouped.get(entry.date);
    if (existing) existing.push(entry);
    else grouped.set(entry.date, [entry]);
  }
  return grouped;
}
