/**
 * Social marketing service.
 *
 * The load-bearing rule here is a negative one: NOTHING in this file publishes,
 * schedules a publish, or reports a post as live. No platform API is connected,
 * so a post can only reach `ready` — meaning "a person could copy this and post
 * it". `plannedFor` is a date on a calendar, not a scheduled job.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { assertTenant, type TenantContext } from '@/lib/tenant';
import { generatedByFrom, runAgent, type AiServiceContext } from '@/lib/ai/service';
import { blocksToText } from '@/lib/ai/provenance';
import type { RunResult } from '@/lib/ai/orchestrator';
import type { SocialPostRow, SocialPostStatus } from '@/lib/db/types';
import {
  POST_STATUSES,
  PLATFORM_SPECS,
  buildSocialBrief,
  checkPost,
  getPlatform,
  isPlatform,
  normalizeHashtags,
  type CalendarEntry,
  type Platform,
  type SocialIssue,
  type SocialPostDraft,
} from './platforms';

export interface SocialServiceContext extends AiServiceContext {}

/**
 * Publishing is unavailable and this is the single place that says so.
 *
 * It is a function rather than a constant so that connecting a real API later
 * changes one implementation, not scattered copy — and so the test suite can
 * assert the whole application agrees on the answer.
 */
export function publishingStatus(platform: Platform): {
  readonly canPublish: false;
  readonly reason: string;
  readonly requirement: string;
} {
  const spec = getPlatform(platform);
  return {
    canPublish: false,
    reason: spec.publishBlockedReason,
    requirement: spec.apiRequirement,
  };
}

/* -------------------------------------------------------------------------- */
/* Validation                                                                 */
/* -------------------------------------------------------------------------- */

export interface PostValidation {
  readonly ok: boolean;
  readonly draft?: SocialPostDraft;
  readonly errors: Record<string, string>;
  readonly issues: readonly SocialIssue[];
}

const MAX_CAPTION = 12_000;
const MAX_IDEA = 500;

function isStatus(value: unknown): value is SocialPostStatus {
  return typeof value === 'string' && (POST_STATUSES as readonly string[]).includes(value);
}

export function validatePost(input: Record<string, unknown>): PostValidation {
  const errors: Record<string, string> = {};

  const platform = isPlatform(input.platform) ? input.platform : null;
  if (!platform) errors.platform = 'Choose a platform.';

  const format = typeof input.format === 'string' ? input.format : '';
  if (platform && !PLATFORM_SPECS[platform].formats.some((f) => f.id === format)) {
    errors.format = 'Choose a format this platform supports.';
  }

  const caption = typeof input.caption === 'string' ? input.caption.slice(0, MAX_CAPTION) : '';

  const status = input.status === undefined ? 'draft' : isStatus(input.status) ? input.status : null;
  if (!status) {
    // The likeliest bad value is "published" or "scheduled", so say why.
    errors.status = 'A post can be an idea, a draft, ready, or archived. Publishing is not available.';
  }

  let plannedFor: string | null = null;
  if (typeof input.plannedFor === 'string' && input.plannedFor.length > 0) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(input.plannedFor) || Number.isNaN(Date.parse(input.plannedFor))) {
      errors.plannedFor = 'Use a real date in YYYY-MM-DD form.';
    } else {
      plannedFor = input.plannedFor;
    }
  }

  const rawTags = Array.isArray(input.hashtags) ? input.hashtags.filter((t): t is string => typeof t === 'string') : [];

  if (!platform || !status || Object.keys(errors).length > 0) {
    return { ok: false, errors, issues: [] };
  }

  const draft: SocialPostDraft = {
    platform,
    format,
    caption,
    hashtags: normalizeHashtags(rawTags, PLATFORM_SPECS[platform].hashtags.max || rawTags.length),
    idea: typeof input.idea === 'string' ? input.idea.trim().slice(0, MAX_IDEA) || null : null,
    status,
    plannedFor,
  };

  const issues = checkPost(draft);
  const blocking = issues.filter((issue) => issue.severity === 'error');
  if (blocking.length > 0) {
    return { ok: false, errors: { caption: blocking[0]!.message }, issues };
  }

  return { ok: true, draft, errors: {}, issues };
}

/* -------------------------------------------------------------------------- */
/* Generation                                                                 */
/* -------------------------------------------------------------------------- */

export interface GeneratePostInput {
  readonly projectId: string;
  readonly platform: Platform;
  readonly format: string;
  readonly idea: string;
  readonly save?: boolean;
}

export interface GeneratePostResult {
  readonly ok: boolean;
  readonly result: RunResult;
  readonly post: SocialPostRow | null;
  readonly issues: readonly SocialIssue[];
}

/**
 * Splits a generated caption from its trailing hashtags.
 *
 * Models put hashtags on the last line. Storing them separately is what lets
 * the character check count them against the platform limit honestly.
 */
export function splitCaption(text: string): { caption: string; hashtags: string[] } {
  const lines = text.trimEnd().split('\n');
  const last = lines[lines.length - 1]?.trim() ?? '';
  const looksLikeTagLine = last.length > 0 && last.split(/\s+/).every((word) => word.startsWith('#'));

  if (!looksLikeTagLine || lines.length === 1) {
    return { caption: text.trim(), hashtags: [] };
  }
  return {
    caption: lines.slice(0, -1).join('\n').trim(),
    hashtags: last.split(/\s+/),
  };
}

export async function generatePost(
  context: SocialServiceContext,
  tenant: TenantContext,
  input: GeneratePostInput,
): Promise<GeneratePostResult> {
  requirePermission(tenant.role, 'content:create');

  const result = await runAgent(context, tenant, {
    agent: 'social',
    // One option per call: the caller decides how many to ask for, and each is
    // stored as its own post rather than parsed back out of a single blob.
    prompt: buildSocialBrief(input.platform, input.format, input.idea, 1),
    projectId: input.projectId,
  });

  if (!result.ok) return { ok: false, result, post: null, issues: [] };

  const text = blocksToText(result.response.blocks);
  const split = splitCaption(text);
  const spec = PLATFORM_SPECS[input.platform];

  const draft: SocialPostDraft = {
    platform: input.platform,
    format: input.format,
    caption: split.caption,
    hashtags: normalizeHashtags(split.hashtags, spec.hashtags.max),
    idea: input.idea.trim().slice(0, MAX_IDEA) || null,
    status: 'draft',
    plannedFor: null,
  };

  const issues = checkPost(draft);
  if (input.save === false) return { ok: true, result, post: null, issues };

  const post = await context.db.socialPosts.create({
    organizationId: tenant.organizationId,
    projectId: input.projectId,
    createdBy: tenant.userId,
    platform: draft.platform,
    format: draft.format,
    caption: draft.caption,
    hashtags: draft.hashtags,
    idea: draft.idea,
    status: draft.status,
    plannedFor: draft.plannedFor,
    blocks: result.response.blocks,
    generatedBy: generatedByFrom(result.record),
  });

  return { ok: true, result, post, issues };
}

/* -------------------------------------------------------------------------- */
/* CRUD and calendar                                                          */
/* -------------------------------------------------------------------------- */

async function requireProject(
  context: SocialServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<void> {
  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  assertTenant(tenant, project, 'Project');
}

export async function createPost(
  context: SocialServiceContext,
  tenant: TenantContext,
  projectId: string,
  draft: SocialPostDraft,
): Promise<SocialPostRow> {
  requirePermission(tenant.role, 'content:create');
  await requireProject(context, tenant, projectId);

  return context.db.socialPosts.create({
    organizationId: tenant.organizationId,
    projectId,
    createdBy: tenant.userId,
    platform: draft.platform,
    format: draft.format,
    caption: draft.caption,
    hashtags: draft.hashtags,
    idea: draft.idea,
    status: draft.status,
    plannedFor: draft.plannedFor,
    blocks: [],
    generatedBy: { human: true },
  });
}

export async function listPosts(
  context: SocialServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<SocialPostRow[]> {
  requirePermission(tenant.role, 'content:read');
  await requireProject(context, tenant, projectId);
  return context.db.socialPosts.listForProject(tenant.organizationId, projectId);
}

export async function getPost(
  context: SocialServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<SocialPostRow> {
  requirePermission(tenant.role, 'content:read');
  const post = await context.db.socialPosts.findById(tenant.organizationId, id);
  return assertTenant(tenant, post, 'Post');
}

export async function updatePost(
  context: SocialServiceContext,
  tenant: TenantContext,
  id: string,
  patch: Partial<SocialPostDraft>,
): Promise<SocialPostRow> {
  requirePermission(tenant.role, 'content:create');

  const existing = assertTenant(
    tenant,
    await context.db.socialPosts.findById(tenant.organizationId, id),
    'Post',
  );

  const merged: SocialPostDraft = {
    platform: (patch.platform ?? existing.platform) as Platform,
    format: patch.format ?? existing.format,
    caption: patch.caption ?? existing.caption,
    hashtags: patch.hashtags ?? existing.hashtags,
    idea: patch.idea === undefined ? existing.idea : patch.idea,
    status: patch.status ?? existing.status,
    plannedFor: patch.plannedFor === undefined ? existing.plannedFor : patch.plannedFor,
  };

  const blocking = checkPost(merged).filter((issue) => issue.severity === 'error');
  if (blocking.length > 0) throw new SocialValidationError(blocking[0]!.message);

  const next: { -readonly [K in keyof SocialPostRow]?: SocialPostRow[K] } = { ...merged };
  if (patch.caption !== undefined && patch.caption !== existing.caption) {
    next.blocks = [];
    next.generatedBy = { ...existing.generatedBy, humanEdited: true };
  }

  const updated = await context.db.socialPosts.update(tenant.organizationId, id, next);
  return assertTenant(tenant, updated, 'Post');
}

export class SocialValidationError extends Error {
  readonly code = 'INVALID_POST' as const;
  constructor(message: string) {
    super(message);
    this.name = 'SocialValidationError';
  }
}

export async function deletePost(
  context: SocialServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<void> {
  requirePermission(tenant.role, 'content:create');
  assertTenant(tenant, await context.db.socialPosts.findById(tenant.organizationId, id), 'Post');
  await context.db.socialPosts.softDelete(tenant.organizationId, id, new Date(context.now?.() ?? Date.now()));
}

/**
 * The planning calendar.
 *
 * Archived posts are excluded, and a post with no planned date never appears —
 * an undated post is not "today's post", and showing it as one would be the
 * first step toward implying a schedule that does not exist.
 */
export async function calendar(
  context: SocialServiceContext,
  tenant: TenantContext,
  projectId: string,
  from: string,
  to: string,
): Promise<CalendarEntry[]> {
  requirePermission(tenant.role, 'content:read');
  await requireProject(context, tenant, projectId);

  const posts = await context.db.socialPosts.listForCalendar(tenant.organizationId, projectId, from, to);

  return posts
    .filter((post): post is SocialPostRow & { plannedFor: string } =>
      typeof post.plannedFor === 'string' && post.status !== 'archived')
    .map((post) => ({
      date: post.plannedFor,
      platform: post.platform as Platform,
      format: post.format,
      caption: post.caption,
      status: post.status,
    }));
}
