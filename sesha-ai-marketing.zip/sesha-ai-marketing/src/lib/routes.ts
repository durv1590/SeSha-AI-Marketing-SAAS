/**
 * Route registry — the single source of truth for the public URL surface.
 *
 * Everything derives from this: navigation, sitemap, breadcrumbs, internal-link
 * validation and the link-integrity test. A route that is not registered here
 * is not a route.
 */

export type ChangeFrequency =
  | 'always'
  | 'hourly'
  | 'daily'
  | 'weekly'
  | 'monthly'
  | 'yearly'
  | 'never';

export interface RouteDefinition {
  /** Absolute path, always starting with "/" and never ending with one. */
  readonly path: string;
  /** Human label used by navigation and breadcrumbs. */
  readonly label: string;
  /** Parent path for breadcrumb resolution. `null` for top level. */
  readonly parent: string | null;
  readonly sitemap: {
    readonly include: boolean;
    readonly priority: number;
    readonly changeFrequency: ChangeFrequency;
  };
  /** Marks pages written in answer-first (AEO) structure. */
  readonly aeo?: boolean;
}

export const SOLUTION_SLUGS = [
  'small-business',
  'startups',
  'agencies',
  'ecommerce',
  'local-business',
  'real-estate',
  'education',
  'healthcare',
  'restaurants',
] as const;

export type SolutionSlug = (typeof SOLUTION_SLUGS)[number];

const solutionLabels: Record<SolutionSlug, string> = {
  'small-business': 'Small Business',
  startups: 'Startups',
  agencies: 'Agencies',
  ecommerce: 'E-commerce',
  'local-business': 'Local Business',
  'real-estate': 'Real Estate',
  education: 'Education',
  healthcare: 'Healthcare',
  restaurants: 'Restaurants',
};

function solutionRoutes(): RouteDefinition[] {
  return SOLUTION_SLUGS.map((slug) => ({
    path: `/solutions/${slug}`,
    label: solutionLabels[slug],
    parent: '/solutions',
    sitemap: { include: true, priority: 0.7, changeFrequency: 'monthly' as const },
    aeo: true,
  }));
}

export const routes: readonly RouteDefinition[] = [
  {
    path: '/',
    label: 'Home',
    parent: null,
    sitemap: { include: true, priority: 1.0, changeFrequency: 'weekly' },
  },
  {
    path: '/features',
    label: 'Features',
    parent: null,
    sitemap: { include: true, priority: 0.9, changeFrequency: 'monthly' },
  },
  {
    path: '/solutions',
    label: 'Solutions',
    parent: null,
    sitemap: { include: true, priority: 0.9, changeFrequency: 'monthly' },
  },
  ...solutionRoutes(),
  {
    path: '/seo',
    label: 'SEO',
    parent: null,
    sitemap: { include: true, priority: 0.8, changeFrequency: 'monthly' },
    aeo: true,
  },
  {
    path: '/aeo',
    label: 'AEO',
    parent: null,
    sitemap: { include: true, priority: 0.8, changeFrequency: 'monthly' },
    aeo: true,
  },
  {
    path: '/schema-validator',
    label: 'Schema Validator',
    parent: null,
    sitemap: { include: true, priority: 0.8, changeFrequency: 'monthly' },
    aeo: true,
  },
  {
    path: '/pricing',
    label: 'Pricing',
    parent: null,
    sitemap: { include: true, priority: 0.9, changeFrequency: 'monthly' },
  },
  {
    path: '/resources',
    label: 'Resources',
    parent: null,
    sitemap: { include: true, priority: 0.6, changeFrequency: 'weekly' },
  },
  {
    path: '/blog',
    label: 'Blog',
    parent: '/resources',
    sitemap: { include: true, priority: 0.7, changeFrequency: 'weekly' },
  },
  {
    path: '/about',
    label: 'About',
    parent: null,
    sitemap: { include: true, priority: 0.6, changeFrequency: 'yearly' },
  },
  {
    path: '/contact',
    label: 'Contact',
    parent: null,
    sitemap: { include: true, priority: 0.6, changeFrequency: 'yearly' },
  },
  {
    path: '/faq',
    label: 'FAQ',
    parent: null,
    sitemap: { include: true, priority: 0.6, changeFrequency: 'monthly' },
    aeo: true,
  },
  {
    path: '/security',
    label: 'Security',
    parent: null,
    sitemap: { include: true, priority: 0.5, changeFrequency: 'yearly' },
    aeo: true,
  },
  {
    path: '/privacy',
    label: 'Privacy Policy',
    parent: null,
    sitemap: { include: true, priority: 0.3, changeFrequency: 'yearly' },
  },
  {
    path: '/terms',
    label: 'Terms of Service',
    parent: null,
    sitemap: { include: true, priority: 0.3, changeFrequency: 'yearly' },
  },
] as const;

const routeByPath = new Map<string, RouteDefinition>(routes.map((r) => [r.path, r]));

export function getRoute(path: string): RouteDefinition | undefined {
  return routeByPath.get(normalizePath(path));
}

export function isRegisteredRoute(path: string): boolean {
  return routeByPath.has(normalizePath(path));
}

/** Strips query/hash, collapses slashes and removes a trailing slash (except root). */
export function normalizePath(input: string): string {
  const withoutFragment = input.split('#')[0] ?? '';
  const withoutQuery = withoutFragment.split('?')[0] ?? '';
  if (withoutQuery === '' || withoutQuery === '/') return '/';
  const collapsed = withoutQuery.replace(/\/{2,}/g, '/');
  return collapsed.endsWith('/') ? collapsed.slice(0, -1) : collapsed;
}

export interface Crumb {
  readonly path: string;
  readonly label: string;
}

/**
 * Resolves the breadcrumb trail for a path, root-first, including the page
 * itself. Unregistered paths return a best-effort trail from their segments.
 */
export function getBreadcrumbs(path: string): Crumb[] {
  const normalized = normalizePath(path);
  if (normalized === '/') return [{ path: '/', label: 'Home' }];

  const trail: Crumb[] = [];
  let cursor: string | null = normalized;
  const guard = new Set<string>();

  while (cursor && cursor !== '/' && !guard.has(cursor)) {
    guard.add(cursor);
    const route: RouteDefinition | undefined = routeByPath.get(cursor);
    trail.unshift({ path: cursor, label: route?.label ?? labelFromSegment(cursor) });
    cursor = route ? route.parent : parentFromPath(cursor);
  }

  trail.unshift({ path: '/', label: 'Home' });
  return trail;
}

function parentFromPath(path: string): string | null {
  const segments = path.split('/').filter(Boolean);
  if (segments.length <= 1) return null;
  return `/${segments.slice(0, -1).join('/')}`;
}

function labelFromSegment(path: string): string {
  const segment = path.split('/').filter(Boolean).pop() ?? '';
  return segment
    .split('-')
    .map((word) => (word.length > 0 ? word[0]!.toUpperCase() + word.slice(1) : word))
    .join(' ');
}

/** Routes eligible for the XML sitemap, in declaration order. */
export function sitemapRoutes(): RouteDefinition[] {
  return routes.filter((r) => r.sitemap.include);
}
