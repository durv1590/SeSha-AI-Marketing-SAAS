/**
 * Resolving what an organization is actually allowed to do.
 *
 * Pure functions. No database, no clock of their own — so the interesting
 * decisions (does an override apply, is this limit reached, what does the user
 * see) are all testable without a fixture.
 *
 * THE ORDER OF PRECEDENCE, AND WHY OVERRIDES CANNOT BE SILENT
 * An effective limit is the plan default, optionally replaced by an override an
 * admin set for one organization. Every resolved limit carries `source` —
 * `'plan'` or `'override'` — and an override carries the reason the admin typed.
 * That is not decoration: a customer on Business who has been given 40 projects
 * is entitled to know why their screen disagrees with the pricing page, and a
 * support engineer looking at a strange quota needs to see who granted it.
 *
 * WHAT AN OVERRIDE MAY NOT DO
 * `null` means unlimited, and an override may grant it. It may not be used to
 * set a NEGATIVE limit, and `clampLimit` refuses one — a negative ceiling would
 * make every check fail with no message that makes sense.
 */

import {
  LIMITS,
  LIMIT_IDS,
  PLAN_DEFINITIONS,
  type LimitId,
  type LimitValue,
  type PlanDefinition,
  type PlanId,
} from '@/content/plans';

/* -------------------------------------------------------------------------- */
/* Overrides                                                                  */
/* -------------------------------------------------------------------------- */

export interface LimitOverride {
  readonly limitId: LimitId;
  readonly value: LimitValue;
  /** Why an admin granted it. Required, because "why is this 40?" gets asked. */
  readonly reason: string;
  readonly setBy: string | null;
  readonly setAt: string;
}

export interface ResolvedLimit {
  readonly id: LimitId;
  readonly label: string;
  readonly description: string;
  readonly kind: 'per_period' | 'absolute';
  readonly unit: string;
  readonly value: LimitValue;
  readonly source: 'plan' | 'override';
  /** Present only when `source` is `'override'`. */
  readonly override?: LimitOverride;
}

export type EffectiveLimits = Readonly<Record<LimitId, ResolvedLimit>>;

/**
 * Refuses a nonsensical limit rather than storing it.
 *
 * Returns `null` for unlimited and a non-negative integer otherwise. A
 * fractional or negative value is a mistake somewhere upstream, and letting it
 * through produces a quota screen nobody can explain.
 */
export function clampLimit(value: unknown): LimitValue | undefined {
  if (value === null) return null;
  if (typeof value !== 'number' || !Number.isFinite(value)) return undefined;
  if (value < 0) return undefined;
  return Math.floor(value);
}

/**
 * The effective limits for an organization.
 *
 * Total over `LIMIT_IDS`, so adding a limit to the registry without deciding its
 * default is impossible — the plan definition would not type-check.
 */
export function effectiveLimits(
  plan: PlanId,
  overrides: readonly LimitOverride[] = [],
): EffectiveLimits {
  const definition = PLAN_DEFINITIONS[plan];
  const entries = LIMIT_IDS.map((id): [LimitId, ResolvedLimit] => {
    const meta = LIMITS[id];
    const override = overrides.find((candidate) => candidate.limitId === id);
    const base: Omit<ResolvedLimit, 'value' | 'source' | 'override'> = {
      id,
      label: meta.label,
      description: meta.description,
      kind: meta.kind,
      unit: meta.unit,
    };
    if (override) {
      return [id, { ...base, value: override.value, source: 'override', override }];
    }
    return [id, { ...base, value: definition.limits[id], source: 'plan' }];
  });
  return Object.fromEntries(entries) as EffectiveLimits;
}

/** One limit, resolved. */
export function effectiveLimit(
  plan: PlanId,
  limitId: LimitId,
  overrides: readonly LimitOverride[] = [],
): ResolvedLimit {
  return effectiveLimits(plan, overrides)[limitId];
}

/* -------------------------------------------------------------------------- */
/* Entitlement                                                                */
/* -------------------------------------------------------------------------- */

/**
 * What the product will let this organization do right now.
 *
 * `plan` is what they pay for; `entitled` is what they can use TODAY, and the
 * two differ while a subscription is unpaid or cancelled. Keeping them separate
 * is what stops a past-due account from either being cut off instantly (hostile,
 * and usually a billing glitch) or keeping agency limits indefinitely.
 */
export interface Entitlement {
  readonly plan: PlanId;
  readonly definition: PlanDefinition;
  readonly limits: EffectiveLimits;
  /** False when the subscription state means nothing new may be created. */
  readonly writable: boolean;
  /** Why writing is blocked, in words, when it is. */
  readonly blockedReason?: string;
}

export function describeLimit(limit: ResolvedLimit): string {
  if (limit.value === null) return `${limit.label}: unlimited`;
  if (limit.value === 0) return `${limit.label}: not included on this plan`;
  const period = limit.kind === 'per_period' ? ' this month' : '';
  return `${limit.label}: ${limit.value.toLocaleString('en-IN')} ${limit.unit}${period}`;
}
