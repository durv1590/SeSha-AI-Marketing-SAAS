/**
 * Resolving an organization's entitlement: plan, limits and whether it may write.
 *
 * ONE FUNCTION EVERY ENFORCEMENT PATH CALLS.
 * `entitlementFor()` joins three things that were previously read separately and
 * inconsistently: the subscription's plan, the subscription's STATE, and any
 * admin override. Before Phase 7 the AI path read the plan and ignored the
 * state, which meant a cancelled account kept generating until someone noticed.
 *
 * THE PLAN IS RESOLVED DEFENSIVELY.
 * `resolvePlanId` accepts the pre-Phase-7 spellings on read. Migration 0007
 * narrows the CHECK so they cannot be written, but during a rolling deploy an
 * older instance can still write one, and a screen that throws on an unexpected
 * plan string is a screen that breaks for the customer in the middle of a
 * migration. An unrecognisable plan falls back to `free` — the safe direction,
 * because it under-grants rather than over-grants, and it is recorded as an
 * error so somebody finds out.
 */

import type { Database } from '@/lib/db/repositories';
import type { SubscriptionRow } from '@/lib/db/types';
import { PLAN_DEFINITIONS, resolvePlanId, type LimitId, type PlanId } from '@/content/plans';
import { accessFor, type SubscriptionStatus } from '@/lib/billing/types';

import { clampLimit, effectiveLimits, type Entitlement, type LimitOverride } from './resolve';

export interface PlanServiceContext {
  readonly db: Database;
  readonly now?: () => Date;
}

function clock(context: PlanServiceContext): Date {
  return context.now?.() ?? new Date();
}

/** The plan defaulted to when a subscription is missing or unreadable. */
export const FALLBACK_PLAN: PlanId = 'free';

export async function overridesFor(
  context: PlanServiceContext,
  organizationId: string,
): Promise<readonly LimitOverride[]> {
  const rows = await context.db.planLimits.listForOrganization(organizationId);
  return rows
    .map((row): LimitOverride | null => {
      const value = clampLimit(row.value);
      // A stored value that is not a sane limit is IGNORED rather than applied.
      // A negative ceiling would refuse every request with a message nobody can
      // act on, and the plan default is the better answer.
      if (value === undefined) return null;
      return {
        limitId: row.limitId as LimitId,
        value,
        reason: row.reason,
        setBy: row.setBy,
        setAt: row.setAt.toISOString(),
      };
    })
    .filter((override): override is LimitOverride => override !== null);
}

/**
 * What this organization is entitled to right now.
 *
 * `writable` folds in the subscription state, so a caller that checks a limit
 * cannot forget to also check whether the account is paid up.
 */
export async function entitlementFor(
  context: PlanServiceContext,
  organizationId: string,
): Promise<Entitlement> {
  const subscription = await context.db.subscriptions.findForOrganization(organizationId);
  const plan = planOf(subscription);
  const overrides = await overridesFor(context, organizationId);
  const limits = effectiveLimits(plan, overrides);

  // No subscription row at all: treat as free and writable. A missing row is our
  // bookkeeping problem, and locking a customer out over it would be wrong.
  if (!subscription) {
    return { plan, definition: PLAN_DEFINITIONS[plan], limits, writable: true };
  }

  const access = accessFor(subscription.status as SubscriptionStatus, {
    pastDueSince: subscription.pastDueSince,
    now: clock(context),
  });

  return {
    plan,
    definition: PLAN_DEFINITIONS[plan],
    limits,
    writable: access.writable,
    ...(access.reason ? { blockedReason: access.reason } : {}),
  };
}

/** The plan on a subscription row, resolved defensively. See the header. */
export function planOf(subscription: SubscriptionRow | null): PlanId {
  if (!subscription) return FALLBACK_PLAN;
  return resolvePlanId(subscription.plan) ?? FALLBACK_PLAN;
}

/**
 * Whether a stored plan string was recognisable.
 *
 * Exported so the caller that has a database and an error recorder can report
 * the unrecognised value. `planOf` cannot do it itself without taking a
 * dependency that would make it impure and untestable.
 */
export function planWasUnrecognised(subscription: SubscriptionRow | null): boolean {
  return subscription !== null && resolvePlanId(subscription.plan) === null;
}
