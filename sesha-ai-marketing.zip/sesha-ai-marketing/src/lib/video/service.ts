/**
 * Video script service.
 *
 * Scripts are validated on every write and the problems are stored with them, the
 * same pattern as ad and messaging plans. A script with errors — scenes that
 * overrun the platform's limit, spoken lines with no on-screen text on a platform
 * that plays muted — can be saved as a draft but not marked ready.
 *
 * No image is ever produced. See `imageGenerationStatus()`.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { assertTenant, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { VideoScriptRow } from '@/lib/db/types';

import {
  checkVideoScript,
  hasScriptErrors,
  imageGenerationStatus,
  isVideoPlatform,
  totalSeconds,
  type ScriptProblem,
  type VideoScript,
} from './types';

export interface VideoServiceContext {
  readonly db: Database;
  readonly now?: () => Date;
}

function clock(context: VideoServiceContext): Date {
  return context.now?.() ?? new Date();
}

export class VideoInputError extends Error {
  readonly code = 'INVALID_INPUT' as const;
  readonly problems: readonly ScriptProblem[];
  constructor(message: string, problems: readonly ScriptProblem[] = []) {
    super(message);
    this.name = 'VideoInputError';
    this.problems = problems;
  }
}

export interface SaveScriptInput {
  readonly projectId: string;
  readonly script: VideoScript;
  readonly reviewState?: VideoScriptRow['reviewState'];
}

export interface SavedScript {
  readonly row: VideoScriptRow;
  readonly problems: readonly ScriptProblem[];
  readonly images: ReturnType<typeof imageGenerationStatus>;
}

export async function saveVideoScript(
  context: VideoServiceContext,
  tenant: TenantContext,
  input: SaveScriptInput,
): Promise<SavedScript> {
  requirePermission(tenant.role, 'content:create');

  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, input.projectId),
    'Project',
  );

  if (!isVideoPlatform(input.script.platform)) {
    throw new VideoInputError('That is not a platform SeSha writes scripts for.');
  }

  const problems = checkVideoScript(input.script);
  const requested = input.reviewState ?? 'draft';
  if (requested === 'approved' && hasScriptErrors(problems)) {
    throw new VideoInputError('This script cannot be marked ready while it has errors.', problems);
  }

  const row = await context.db.videoScripts.create({
    organizationId: tenant.organizationId,
    projectId: project.id,
    createdBy: tenant.userId,
    platform: input.script.platform,
    topic: input.script.topic.trim(),
    totalSeconds: totalSeconds(input.script.scenes),
    script: input.script as unknown as Readonly<Record<string, unknown>>,
    problems: problems as unknown as readonly Readonly<Record<string, unknown>>[],
    reviewState: requested,
  });

  return { row, problems, images: imageGenerationStatus() };
}

export async function listVideoScripts(
  context: VideoServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<readonly VideoScriptRow[]> {
  requirePermission(tenant.role, 'content:read');
  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, projectId),
    'Project',
  );
  return context.db.videoScripts.listForProject(tenant.organizationId, project.id);
}

export async function getVideoScript(
  context: VideoServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<SavedScript> {
  requirePermission(tenant.role, 'content:read');
  const row = assertTenant(
    tenant,
    await context.db.videoScripts.findById(tenant.organizationId, id),
    'Video script',
  );
  return {
    row,
    problems: checkVideoScript(row.script as unknown as VideoScript),
    images: imageGenerationStatus(),
  };
}

export async function setVideoReviewState(
  context: VideoServiceContext,
  tenant: TenantContext,
  id: string,
  reviewState: VideoScriptRow['reviewState'],
): Promise<SavedScript> {
  requirePermission(tenant.role, 'content:create');

  const existing = assertTenant(
    tenant,
    await context.db.videoScripts.findById(tenant.organizationId, id),
    'Video script',
  );
  const problems = checkVideoScript(existing.script as unknown as VideoScript);
  if (reviewState === 'approved' && hasScriptErrors(problems)) {
    throw new VideoInputError('This script still has errors, so it cannot be marked ready.', problems);
  }

  const row = await context.db.videoScripts.update(tenant.organizationId, existing.id, {
    reviewState,
    problems: problems as unknown as readonly Readonly<Record<string, unknown>>[],
  });
  if (!row) throw new VideoInputError('That script could not be updated.');
  return { row, problems, images: imageGenerationStatus() };
}

export async function deleteVideoScript(
  context: VideoServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<void> {
  requirePermission(tenant.role, 'content:create');
  const existing = assertTenant(
    tenant,
    await context.db.videoScripts.findById(tenant.organizationId, id),
    'Video script',
  );
  await context.db.videoScripts.softDelete(tenant.organizationId, existing.id, clock(context));
}
