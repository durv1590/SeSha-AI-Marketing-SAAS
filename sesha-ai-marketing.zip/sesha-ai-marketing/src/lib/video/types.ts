/**
 * Video scripts and creative concepts.
 *
 * THE IMAGE RULE, WHICH IS THE WHOLE REASON THIS FILE IS CAREFUL
 * The brief says image generation should only be activated when a legitimate
 * image-generation API is connected. None is, so:
 *
 *  · `ThumbnailConcept` is a DESCRIPTION — a written brief a designer or the user
 *    can execute. It has no image field at all, so there is nothing to populate
 *    with a placeholder that later looks like a real asset.
 *  · `imageGenerationStatus()` is the single place that says no generator is
 *    connected, and every screen reads it.
 *  · There is no `imageUrl`, no base64 field and no "preview" anywhere in this
 *    module. A type that cannot hold a fake image cannot ship one.
 *
 * A generated thumbnail that looks real but was assembled from nothing would be
 * handed to a user as an asset. A written concept cannot be mistaken for one.
 *
 * THE SCENE DURATIONS ARE CHECKED, NOT SUGGESTED
 * A sixty-second Reel script whose scenes add up to ninety seconds is not a
 * script, it is a wish. `checkVideoScript` adds them up.
 *
 * Framework-free and fully unit tested.
 */

export const VIDEO_PLATFORMS = [
  'youtube_long',
  'youtube_shorts',
  'instagram_reels',
  'linkedin_video',
] as const;

export type VideoPlatform = (typeof VIDEO_PLATFORMS)[number];

export const VIDEO_SPECS_AS_OF = '2026-05';

export interface VideoPlatformSpec {
  readonly id: VideoPlatform;
  readonly label: string;
  readonly aspectRatio: string;
  /** Hard ceiling in seconds, where the platform has one for this format. */
  readonly maxSeconds: number;
  /** Where attention actually is. Used to check the hook length. */
  readonly hookSeconds: number;
  readonly titleCharacters: number;
  readonly descriptionCharacters: number;
  readonly maxTags: number;
  /** Whether captions are effectively required, because sound is off by default. */
  readonly soundOffByDefault: boolean;
  readonly note: string;
}

export const VIDEO_PLATFORM_SPECS: Readonly<Record<VideoPlatform, VideoPlatformSpec>> = {
  youtube_long: {
    id: 'youtube_long',
    label: 'YouTube (long form)',
    aspectRatio: '16:9',
    maxSeconds: 20 * 60,
    hookSeconds: 15,
    titleCharacters: 100,
    descriptionCharacters: 5_000,
    maxTags: 15,
    soundOffByDefault: false,
    note: 'The first fifteen seconds decide whether the rest is watched. Only the first ~120 characters of the description show before "more".',
  },
  youtube_shorts: {
    id: 'youtube_shorts',
    label: 'YouTube Shorts',
    aspectRatio: '9:16',
    maxSeconds: 60,
    hookSeconds: 3,
    titleCharacters: 100,
    descriptionCharacters: 1_000,
    maxTags: 10,
    soundOffByDefault: false,
    note: 'Vertical, under a minute, and the loop matters: an ending that leads back into the opening is watched twice.',
  },
  instagram_reels: {
    id: 'instagram_reels',
    label: 'Instagram Reels',
    aspectRatio: '9:16',
    maxSeconds: 90,
    hookSeconds: 3,
    titleCharacters: 125,
    descriptionCharacters: 2_200,
    maxTags: 10,
    soundOffByDefault: false,
    note: 'Keep text clear of the top and bottom 14% where the interface sits. The caption is read after the video, not before.',
  },
  linkedin_video: {
    id: 'linkedin_video',
    label: 'LinkedIn video',
    aspectRatio: '1:1 or 9:16',
    maxSeconds: 10 * 60,
    hookSeconds: 6,
    titleCharacters: 70,
    descriptionCharacters: 1_300,
    maxTags: 5,
    soundOffByDefault: true,
    note: 'Plays muted in the feed, so the opening must work with no sound. Burned-in captions are not optional here.',
  },
};

export function videoSpec(platform: VideoPlatform): VideoPlatformSpec {
  return VIDEO_PLATFORM_SPECS[platform];
}

export function isVideoPlatform(value: unknown): value is VideoPlatform {
  return typeof value === 'string' && (VIDEO_PLATFORMS as readonly string[]).includes(value);
}

/* -------------------------------------------------------------------------- */
/* The script                                                                 */
/* -------------------------------------------------------------------------- */

export interface Scene {
  readonly index: number;
  readonly seconds: number;
  /** What the camera sees. A shot, not a mood. */
  readonly shot: string;
  /** What is said. Empty for a silent scene, which is legitimate. */
  readonly voiceover: string;
  /** Words burned into the frame. */
  readonly onScreenText?: string;
  /** Sound other than the voice. */
  readonly audioNote?: string;
}

export interface ThumbnailConcept {
  readonly title: string;
  /** The written brief. There is deliberately no image field — see the header. */
  readonly description: string;
  /** At most four words; more does not read at thumbnail size. */
  readonly overlayText: string;
  readonly whyItWorks: string;
}

export interface VideoScript {
  readonly platform: VideoPlatform;
  readonly topic: string;
  /** The first line. What makes someone not scroll past. */
  readonly hook: string;
  readonly scenes: readonly Scene[];
  readonly callToAction: string;
  /** Title options, so a person chooses rather than accepts. */
  readonly titles: readonly string[];
  readonly description: string;
  readonly tags: readonly string[];
  readonly thumbnailConcepts: readonly ThumbnailConcept[];
  /** Always false. No image-generation API is connected. */
  readonly thumbnailImagesGenerated: false;
}

export interface ScriptProblem {
  readonly severity: 'error' | 'warning';
  readonly field: string;
  readonly message: string;
}

export function totalSeconds(scenes: readonly Scene[]): number {
  return scenes.reduce((total, scene) => total + Math.max(0, scene.seconds), 0);
}

export function checkVideoScript(script: VideoScript): readonly ScriptProblem[] {
  const spec = videoSpec(script.platform);
  const problems: ScriptProblem[] = [];

  if (script.topic.trim().length === 0) {
    problems.push({ severity: 'error', field: 'topic', message: 'The script needs a topic.' });
  }

  if (script.hook.trim().length === 0) {
    problems.push({ severity: 'error', field: 'hook', message: 'The script needs a hook — the first line that stops the scroll.' });
  } else if (script.hook.trim().split(/\s+/).length > 25) {
    problems.push({
      severity: 'warning',
      field: 'hook',
      message: `The hook is long for ${spec.hookSeconds} seconds of attention. Cut it to one sentence.`,
    });
  }

  if (script.scenes.length === 0) {
    problems.push({ severity: 'error', field: 'scenes', message: 'A script with no scenes is not a script.' });
  }

  const duration = totalSeconds(script.scenes);
  if (duration > spec.maxSeconds) {
    problems.push({
      severity: 'error',
      field: 'scenes',
      message: `The scenes add up to ${duration} seconds; ${spec.label} allows ${spec.maxSeconds} (as of ${VIDEO_SPECS_AS_OF}).`,
    });
  }

  script.scenes.forEach((scene, position) => {
    if (scene.index !== position + 1) {
      problems.push({
        severity: 'error',
        field: 'scenes',
        message: `Scene numbering jumps at position ${position + 1}. Scenes are numbered from 1 in order.`,
      });
    }
    if (scene.seconds <= 0) {
      problems.push({
        severity: 'error',
        field: 'scenes',
        message: `Scene ${scene.index} has no duration.`,
      });
    }
    if (scene.shot.trim().length === 0) {
      problems.push({
        severity: 'error',
        field: 'scenes',
        message: `Scene ${scene.index} does not say what is on screen. "Shot list" means a shot per scene.`,
      });
    }
    if (scene.seconds > 30 && script.platform !== 'youtube_long') {
      problems.push({
        severity: 'warning',
        field: 'scenes',
        message: `Scene ${scene.index} runs ${scene.seconds} seconds, which is a long time to hold one shot on a short-form platform.`,
      });
    }
  });

  const firstScene = script.scenes[0];
  if (firstScene && firstScene.seconds > spec.hookSeconds * 2) {
    problems.push({
      severity: 'warning',
      field: 'scenes',
      message: `The opening shot is ${firstScene.seconds} seconds. On ${spec.label} the decision to keep watching is made in about ${spec.hookSeconds}.`,
    });
  }

  if (spec.soundOffByDefault) {
    const silentScenes = script.scenes.filter(
      (scene) => scene.voiceover.trim().length > 0 && (scene.onScreenText ?? '').trim().length === 0,
    );
    if (silentScenes.length > 0) {
      problems.push({
        severity: 'error',
        field: 'scenes',
        message: `${spec.label} plays muted, so every spoken line needs on-screen text. ${silentScenes.length} scene(s) have speech with nothing written.`,
      });
    }
  }

  if (script.callToAction.trim().length === 0) {
    problems.push({
      severity: 'warning',
      field: 'callToAction',
      message: 'There is no call to action, so the viewer is not asked to do anything.',
    });
  }

  if (script.titles.length === 0) {
    problems.push({ severity: 'error', field: 'titles', message: 'Offer at least one title.' });
  }
  script.titles.forEach((title, index) => {
    if (title.trim().length > spec.titleCharacters) {
      problems.push({
        severity: 'error',
        field: 'titles',
        message: `Title ${index + 1} is ${title.trim().length} characters; ${spec.label} allows ${spec.titleCharacters}.`,
      });
    }
  });

  if (script.description.trim().length > spec.descriptionCharacters) {
    problems.push({
      severity: 'error',
      field: 'description',
      message: `The description is ${script.description.trim().length} characters; the limit is ${spec.descriptionCharacters}.`,
    });
  }

  if (script.tags.length > spec.maxTags) {
    problems.push({
      severity: 'warning',
      field: 'tags',
      message: `${script.tags.length} tags is more than the ${spec.maxTags} that is useful here.`,
    });
  }
  const lowered = script.tags.map((tag) => tag.trim().toLowerCase());
  if (new Set(lowered).size !== lowered.length) {
    problems.push({ severity: 'warning', field: 'tags', message: 'Some tags are duplicated.' });
  }

  for (const concept of script.thumbnailConcepts) {
    if (concept.description.trim().length < 20) {
      problems.push({
        severity: 'error',
        field: 'thumbnailConcepts',
        message: `The thumbnail concept "${concept.title}" is too thin to brief anyone from.`,
      });
    }
    const words = concept.overlayText.trim().split(/\s+/).filter((word) => word.length > 0);
    if (words.length > 4) {
      problems.push({
        severity: 'warning',
        field: 'thumbnailConcepts',
        message: `"${concept.overlayText}" is ${words.length} words. More than four does not read at thumbnail size.`,
      });
    }
  }

  // The type says false; a request body can still say otherwise.
  if ((script as { thumbnailImagesGenerated?: unknown }).thumbnailImagesGenerated === true) {
    problems.push({
      severity: 'error',
      field: 'thumbnailImagesGenerated',
      message:
        'A script cannot be marked as having generated thumbnails: no image-generation API is connected, so no image exists. The concepts are written briefs.',
    });
  }

  return problems;
}

export function hasScriptErrors(problems: readonly ScriptProblem[]): boolean {
  return problems.some((problem) => problem.severity === 'error');
}

/**
 * Whether SeSha can generate an image. It cannot.
 *
 * Same shape as the other capability gates in this codebase so a screen written
 * against it does not change when one is connected.
 */
export function imageGenerationStatus(): {
  readonly connected: false;
  readonly canGenerate: false;
  readonly message: string;
  readonly whatYouGetInstead: string;
} {
  return {
    connected: false,
    canGenerate: false,
    message:
      'No image-generation API is connected, so SeSha does not produce images. Nothing on this screen is a generated picture.',
    whatYouGetInstead:
      'A written thumbnail brief: what is in frame, the overlay words, and why that combination earns a click. Hand it to a designer, or shoot it — it is specific enough to execute from.',
  };
}

/**
 * The hook patterns that actually work, as guidance for the generator.
 *
 * Kept as data so the prompt and the interface agree, and so a test can assert
 * that the generator was given them. Not a guarantee that any hook performs:
 * nothing in this module claims a view count.
 */
export const HOOK_PATTERNS: readonly { readonly name: string; readonly shape: string; readonly example: string }[] = [
  {
    name: 'The contradiction',
    shape: 'State the thing your audience believes, then say it is costing them something.',
    example: 'Posting every day is why nobody sees your shop.',
  },
  {
    name: 'The specific number',
    shape: 'Open with one concrete figure from your own experience, not a statistic you found.',
    example: 'We threw away 4 kg of beans last month. Here is what we changed.',
  },
  {
    name: 'The question they are already asking',
    shape: 'Say the question out loud in the words they would use.',
    example: 'Why does your coffee taste sour at home and fine in the shop?',
  },
  {
    name: 'The demonstration',
    shape: 'Start mid-action, with no introduction.',
    example: '[Grinder running] This setting is wrong. Watch.',
  },
  {
    name: 'The stake',
    shape: 'Name what the viewer loses by getting it wrong.',
    example: 'Get this one setting wrong and you waste every bag you buy.',
  },
];
