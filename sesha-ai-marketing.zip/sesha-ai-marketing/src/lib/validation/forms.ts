/**
 * Form validation.
 *
 * Hand-written rather than schema-library based: Phase 1 has exactly two form
 * payloads, the rules are explicit and auditable, and it keeps the production
 * dependency surface at zero beyond React and Next. If Phase 2 adds many more
 * payloads, replace this module with a schema library behind the same
 * `ValidationResult` contract — nothing outside this file needs to change.
 *
 * Framework-free and fully unit tested.
 */

import { hasHeaderInjection, isProbablyEmail, sanitizeMultiline, sanitizeText } from '@/lib/security/sanitize';

export type FieldErrors<T> = Partial<Record<keyof T, string>>;

export type ValidationResult<T> =
  | { readonly ok: true; readonly data: T }
  | { readonly ok: false; readonly errors: FieldErrors<T> };

/* -------------------------------------------------------------------------- */
/* Contact                                                                    */
/* -------------------------------------------------------------------------- */

export const CONTACT_TOPICS = [
  'product',
  'pricing',
  'partnership',
  'support',
  'security',
  'other',
] as const;

export type ContactTopic = (typeof CONTACT_TOPICS)[number];

export interface ContactSubmission {
  readonly name: string;
  readonly email: string;
  readonly company: string;
  readonly topic: ContactTopic;
  readonly message: string;
  readonly consent: true;
}

export interface ContactRawInput {
  readonly name?: unknown;
  readonly email?: unknown;
  readonly company?: unknown;
  readonly topic?: unknown;
  readonly message?: unknown;
  readonly consent?: unknown;
  /** Honeypot: must be empty. Real users never see this field. */
  readonly website?: unknown;
  /** Client render timestamp (ms) used for a submit-speed check. */
  readonly renderedAt?: unknown;
}

/** Submissions faster than this are almost certainly automated. */
export const MIN_FILL_MS = 2_000;

export function isContactTopic(value: unknown): value is ContactTopic {
  return typeof value === 'string' && (CONTACT_TOPICS as readonly string[]).includes(value);
}

export function validateContact(input: ContactRawInput): ValidationResult<ContactSubmission> {
  const errors: FieldErrors<ContactSubmission> = {};

  const name = sanitizeText(input.name, 120);
  const email = sanitizeText(input.email, 254).toLowerCase();
  const company = sanitizeText(input.company, 160);
  const message = sanitizeMultiline(input.message, 5_000);

  // Header-injection is checked against the RAW value: sanitizeText collapses
  // CR/LF into spaces, so checking the sanitized string would never see it.
  const rawName = typeof input.name === 'string' ? input.name : '';
  const rawEmail = typeof input.email === 'string' ? input.email : '';

  if (hasHeaderInjection(rawName)) {
    errors.name = 'Name contains invalid characters.';
  } else if (name.length < 2) {
    errors.name = 'Enter your name (at least 2 characters).';
  }

  if (email.length === 0) {
    errors.email = 'Enter your email address.';
  } else if (!isProbablyEmail(email) || hasHeaderInjection(rawEmail)) {
    errors.email = 'Enter a valid email address.';
  }

  if (!isContactTopic(input.topic)) {
    errors.topic = 'Choose what your message is about.';
  }

  if (message.length < 20) {
    errors.message = 'Tell us a little more (at least 20 characters).';
  } else if (message.length > 5_000) {
    errors.message = 'Message is too long (5,000 characters maximum).';
  }

  if (input.consent !== true && input.consent !== 'on' && input.consent !== 'true') {
    errors.consent = 'Please confirm you agree to the privacy policy.';
  }

  if (Object.keys(errors).length > 0) {
    return { ok: false, errors };
  }

  return {
    ok: true,
    data: {
      name,
      email,
      company,
      topic: input.topic as ContactTopic,
      message,
      consent: true,
    },
  };
}

/**
 * Silent bot checks, kept separate from field validation so a bot receives a
 * generic success response rather than a hint about which check it failed.
 */
export function looksAutomated(input: ContactRawInput, now: number = Date.now()): boolean {
  const honeypot = sanitizeText(input.website, 200);
  if (honeypot.length > 0) return true;

  const renderedAt = Number(input.renderedAt);
  if (Number.isFinite(renderedAt) && renderedAt > 0) {
    const elapsed = now - renderedAt;
    if (elapsed >= 0 && elapsed < MIN_FILL_MS) return true;
  }
  return false;
}

/* -------------------------------------------------------------------------- */
/* Newsletter                                                                 */
/* -------------------------------------------------------------------------- */

export interface NewsletterSubmission {
  readonly email: string;
}

export interface NewsletterRawInput {
  readonly email?: unknown;
  readonly website?: unknown;
}

export function validateNewsletter(
  input: NewsletterRawInput,
): ValidationResult<NewsletterSubmission> {
  const email = sanitizeText(input.email, 254).toLowerCase();
  if (email.length === 0) {
    return { ok: false, errors: { email: 'Enter your email address.' } };
  }
  if (!isProbablyEmail(email) || hasHeaderInjection(email)) {
    return { ok: false, errors: { email: 'Enter a valid email address.' } };
  }
  return { ok: true, data: { email } };
}
