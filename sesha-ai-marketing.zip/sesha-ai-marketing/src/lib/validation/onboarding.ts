/**
 * Onboarding and workspace validation.
 *
 * Hand-written, consistent with Phase 1's `forms.ts`, and framework-free so it
 * is fully unit tested. Every field the Phase 2 brief lists is validated here,
 * server-side. The client mirrors these rules for convenience; the client is
 * never the thing that decides.
 */

import { sanitizeMultiline, sanitizeText } from '@/lib/security/sanitize';
import type { FieldErrors, ValidationResult } from './forms';

/* -------------------------------------------------------------------------- */
/* Vocabularies                                                               */
/* -------------------------------------------------------------------------- */

export const INDUSTRIES = [
  'small-business',
  'startup',
  'agency',
  'ecommerce',
  'local-services',
  'real-estate',
  'education',
  'healthcare',
  'hospitality',
  'professional-services',
  'manufacturing',
  'nonprofit',
  'other',
] as const;
export type Industry = (typeof INDUSTRIES)[number];

export const PRICE_RANGES = ['budget', 'mid_market', 'premium', 'luxury', 'varies'] as const;
export type PriceRange = (typeof PRICE_RANGES)[number];

export const MARKETING_GOALS = [
  'brand-awareness',
  'lead-generation',
  'online-sales',
  'foot-traffic',
  'customer-retention',
  'thought-leadership',
  'recruitment',
] as const;
export type MarketingGoal = (typeof MARKETING_GOALS)[number];

export const MARKETING_CHANNELS = [
  'organic-search',
  'paid-search',
  'social-organic',
  'social-paid',
  'email',
  'content',
  'events',
  'partnerships',
  'print',
  'outdoor',
] as const;
export type MarketingChannel = (typeof MARKETING_CHANNELS)[number];

export const BRAND_TONES = [
  'professional',
  'friendly',
  'authoritative',
  'playful',
  'technical',
  'empathetic',
  'direct',
] as const;
export type BrandTone = (typeof BRAND_TONES)[number];

function isMember<T extends readonly string[]>(list: T, value: unknown): value is T[number] {
  return typeof value === 'string' && (list as readonly string[]).includes(value);
}

function uniqueMembers<T extends readonly string[]>(list: T, value: unknown, max: number): T[number][] {
  if (!Array.isArray(value)) return [];
  const seen = new Set<string>();
  for (const item of value) {
    if (isMember(list, item) && !seen.has(item)) seen.add(item);
    if (seen.size >= max) break;
  }
  return [...seen] as T[number][];
}

/* -------------------------------------------------------------------------- */
/* URL handling                                                               */
/* -------------------------------------------------------------------------- */

export type UrlResult =
  | { readonly ok: true; readonly url: string; readonly hostname: string }
  | { readonly ok: false; readonly reason: string };

/**
 * Normalises a user-entered website address.
 *
 * Strict on purpose, because this value later feeds a crawler: only http/https,
 * no credentials in the URL, no non-standard ports, and no private or loopback
 * hosts — a crawler that will fetch `http://localhost:8080` or `http://169.254.
 * 169.254` on request is a server-side request forgery vector.
 */
export function normalizeWebsiteUrl(input: unknown): UrlResult {
  const raw = sanitizeText(input, 2048);
  if (raw.length === 0) return { ok: false, reason: 'Enter a website address.' };

  const candidate = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;

  let url: URL;
  try {
    url = new URL(candidate);
  } catch {
    return { ok: false, reason: 'That does not look like a valid web address.' };
  }

  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    return { ok: false, reason: 'Only http and https addresses are supported.' };
  }
  if (url.username || url.password) {
    return { ok: false, reason: 'Remove the username and password from the address.' };
  }
  if (url.port && url.port !== '80' && url.port !== '443') {
    return { ok: false, reason: 'Only standard web ports are supported.' };
  }

  const host = url.hostname.toLowerCase();
  if (isPrivateHost(host)) {
    return { ok: false, reason: 'Enter a public website address.' };
  }
  if (!host.includes('.') || host.startsWith('.') || host.endsWith('.')) {
    return { ok: false, reason: 'Enter a full domain, for example example.com.' };
  }

  url.hash = '';
  return { ok: true, url: url.toString(), hostname: host };
}

/** Blocks loopback, link-local, private ranges and internal TLDs. */
export function isPrivateHost(host: string): boolean {
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local')) return true;
  if (host === '[::1]' || host === '::1' || host.startsWith('[fd') || host.startsWith('[fe80')) return true;
  if (host.endsWith('.internal') || host.endsWith('.lan') || host.endsWith('.home.arpa')) return true;

  const ipv4 = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (ipv4) {
    const octets = ipv4.slice(1).map(Number);
    const [a, b] = octets as [number, number, number, number];
    if (octets.some((n) => n > 255)) return true;
    if (a === 10 || a === 127 || a === 0) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 169 && b === 254) return true; // cloud metadata
    if (a === 100 && b >= 64 && b <= 127) return true; // carrier-grade NAT
    return false;
  }
  return false;
}

/* -------------------------------------------------------------------------- */
/* Business details                                                           */
/* -------------------------------------------------------------------------- */

export interface BusinessDetails {
  readonly name: string;
  readonly industry: Industry;
  readonly country: string;
  readonly city: string;
  readonly websiteUrl: string | null;
}

export function validateBusiness(input: Record<string, unknown>): ValidationResult<BusinessDetails> {
  const errors: FieldErrors<BusinessDetails> = {};

  const name = sanitizeText(input.name, 160);
  const country = sanitizeText(input.country, 80);
  const city = sanitizeText(input.city, 120);
  const rawWebsite = sanitizeText(input.websiteUrl, 2048);

  if (name.length < 2) errors.name = 'Enter your business name.';
  if (!isMember(INDUSTRIES, input.industry)) errors.industry = 'Choose an industry.';
  if (country.length < 2) errors.country = 'Choose a country.';
  if (city.length < 1) errors.city = 'Enter a city.';

  let websiteUrl: string | null = null;
  if (rawWebsite.length > 0) {
    const result = normalizeWebsiteUrl(rawWebsite);
    if (!result.ok) errors.websiteUrl = result.reason;
    else websiteUrl = result.url;
  }

  if (Object.keys(errors).length > 0) return { ok: false, errors };

  return {
    ok: true,
    data: { name, industry: input.industry as Industry, country, city, websiteUrl },
  };
}

/* -------------------------------------------------------------------------- */
/* Marketing profile                                                          */
/* -------------------------------------------------------------------------- */

export interface Competitor {
  readonly name: string;
  readonly url?: string;
}

export interface MarketingProfileInput {
  readonly targetAudience: string;
  readonly productsServices: string;
  readonly priceRange: PriceRange;
  readonly marketingGoals: readonly MarketingGoal[];
  readonly marketingChannels: readonly MarketingChannel[];
  readonly brandVoice: { readonly tones: readonly BrandTone[]; readonly notes: string };
  readonly competitors: readonly Competitor[];
}

export const MAX_COMPETITORS = 10;

export function validateMarketingProfile(
  input: Record<string, unknown>,
): ValidationResult<MarketingProfileInput> {
  const errors: FieldErrors<MarketingProfileInput> = {};

  const targetAudience = sanitizeMultiline(input.targetAudience, 2000);
  const productsServices = sanitizeMultiline(input.productsServices, 2000);
  const brandVoiceNotes = sanitizeMultiline(
    (input.brandVoice as Record<string, unknown> | undefined)?.notes,
    1000,
  );

  if (targetAudience.length < 10) {
    errors.targetAudience = 'Describe who you are trying to reach (at least 10 characters).';
  }
  if (productsServices.length < 10) {
    errors.productsServices = 'Describe what you sell (at least 10 characters).';
  }
  if (!isMember(PRICE_RANGES, input.priceRange)) {
    errors.priceRange = 'Choose a price range.';
  }

  const marketingGoals = uniqueMembers(MARKETING_GOALS, input.marketingGoals, MARKETING_GOALS.length);
  if (marketingGoals.length === 0) errors.marketingGoals = 'Choose at least one goal.';

  const marketingChannels = uniqueMembers(
    MARKETING_CHANNELS,
    input.marketingChannels,
    MARKETING_CHANNELS.length,
  );
  if (marketingChannels.length === 0) errors.marketingChannels = 'Choose at least one channel.';

  const tones = uniqueMembers(
    BRAND_TONES,
    (input.brandVoice as Record<string, unknown> | undefined)?.tones,
    3,
  );
  if (tones.length === 0) errors.brandVoice = 'Choose at least one tone of voice.';

  const competitors = parseCompetitors(input.competitors);
  if (competitors.invalid) errors.competitors = 'Check the competitor web addresses.';

  if (Object.keys(errors).length > 0) return { ok: false, errors };

  return {
    ok: true,
    data: {
      targetAudience,
      productsServices,
      priceRange: input.priceRange as PriceRange,
      marketingGoals,
      marketingChannels,
      brandVoice: { tones, notes: brandVoiceNotes },
      competitors: competitors.list,
    },
  };
}

function parseCompetitors(value: unknown): { list: Competitor[]; invalid: boolean } {
  if (!Array.isArray(value)) return { list: [], invalid: false };
  const list: Competitor[] = [];
  let invalid = false;

  for (const entry of value.slice(0, MAX_COMPETITORS)) {
    if (typeof entry !== 'object' || entry === null) continue;
    const record = entry as Record<string, unknown>;
    const name = sanitizeText(record.name, 120);
    if (name.length === 0) continue;

    const rawUrl = sanitizeText(record.url, 2048);
    if (rawUrl.length === 0) {
      list.push({ name });
      continue;
    }
    const url = normalizeWebsiteUrl(rawUrl);
    if (!url.ok) {
      invalid = true;
      continue;
    }
    list.push({ name, url: url.url });
  }
  return { list, invalid };
}

/* -------------------------------------------------------------------------- */
/* Projects                                                                   */
/* -------------------------------------------------------------------------- */

export interface ProjectInput {
  readonly name: string;
  readonly description: string;
}

export function validateProject(input: Record<string, unknown>): ValidationResult<ProjectInput> {
  const errors: FieldErrors<ProjectInput> = {};
  const name = sanitizeText(input.name, 120);
  const description = sanitizeMultiline(input.description, 1000);

  if (name.length < 2) errors.name = 'Enter a project name (at least 2 characters).';
  if (name.length > 120) errors.name = 'Project names are limited to 120 characters.';

  if (Object.keys(errors).length > 0) return { ok: false, errors };
  return { ok: true, data: { name, description } };
}

export function slugifyProject(name: string): string {
  const slug = name
    .normalize('NFKD')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
  return slug.length > 0 ? slug : 'project';
}

/* -------------------------------------------------------------------------- */
/* Website crawl consent                                                      */
/* -------------------------------------------------------------------------- */

/**
 * The version of the consent wording the user agreed to.
 *
 * Stored with every grant, so a later change to what crawling means cannot
 * retroactively widen a consent someone already gave. BUMP THIS whenever the
 * disclosure text or the default scope changes.
 */
export const CRAWL_CONSENT_VERSION = '2026-09-11.v1';

export interface CrawlConsentInput {
  readonly websiteUrl: string;
  readonly maxPages: number;
  readonly respectRobots: boolean;
  readonly retentionDays: number;
  readonly consentVersion: string;
}

export const CRAWL_LIMITS = {
  maxPagesDefault: 100,
  maxPagesCeiling: 5000,
  retentionDaysDefault: 90,
  retentionDaysCeiling: 365,
} as const;

export function validateCrawlConsent(
  input: Record<string, unknown>,
): ValidationResult<CrawlConsentInput> {
  const errors: FieldErrors<CrawlConsentInput> = {};

  const website = normalizeWebsiteUrl(input.websiteUrl);
  if (!website.ok) errors.websiteUrl = website.reason;

  // Consent must be explicit. An absent or falsy value is a refusal.
  if (input.consent !== true) {
    errors.consentVersion = 'You must agree before we access your website.';
  }
  if (input.consentVersion !== CRAWL_CONSENT_VERSION) {
    errors.consentVersion = 'The consent terms have changed. Please review them again.';
  }

  const maxPages = Number(input.maxPages ?? CRAWL_LIMITS.maxPagesDefault);
  if (!Number.isInteger(maxPages) || maxPages < 1 || maxPages > CRAWL_LIMITS.maxPagesCeiling) {
    errors.maxPages = `Choose between 1 and ${CRAWL_LIMITS.maxPagesCeiling} pages.`;
  }

  const retentionDays = Number(input.retentionDays ?? CRAWL_LIMITS.retentionDaysDefault);
  if (
    !Number.isInteger(retentionDays) ||
    retentionDays < 1 ||
    retentionDays > CRAWL_LIMITS.retentionDaysCeiling
  ) {
    errors.retentionDays = `Choose between 1 and ${CRAWL_LIMITS.retentionDaysCeiling} days.`;
  }

  if (Object.keys(errors).length > 0) return { ok: false, errors };

  return {
    ok: true,
    data: {
      websiteUrl: website.ok ? website.url : '',
      maxPages,
      // robots.txt may be ignored only by explicit opt-out; the default is to
      // respect it, and the UI does not currently offer the opt-out at all.
      respectRobots: input.respectRobots !== false,
      retentionDays,
      consentVersion: CRAWL_CONSENT_VERSION,
    },
  };
}
