/**
 * The quota gate: the one place a limit is enforced.
 *
 * WHY THERE IS EXACTLY ONE
 * Before Phase 7 the only enforced limits were the AI ones, checked inside
 * `lib/ai/cost.ts`. Crawls, audits, validations, projects, seats, reports and
 * automations had configured limits nowhere and enforced limits nowhere — a plan
 * page that promised "3 projects" while the product would happily create thirty.
 * Adding eleven separate checks in eleven services would have reproduced that
 * failure eleven times over, because the one that gets forgotten is invisible.
 *
 * So: `checkLimit()` is the only function that decides, it is total over
 * `LimitId`, and `tests/quota.test.ts` walks every limit and asserts each is
 * enforced. A limit with no enforcement is a failing test, not a surprise.
 *
 * IT RETURNS A DECISION, IT DOES NOT THROW
 * The caller records the refusal and tells the user which limit they hit, what
 * the limit is, what they have used and when it resets. "Quota exceeded" with no
 * numbers is the message that generates a support ticket.
 *
 * REFUSALS ARE COUNTED TOO — see `lib/usage/service.ts`. A quota that silently
 * blocks a customer thirty times a day is a sales signal, and it is invisible
 * unless the refusal is recorded.
 */

import {
  LIMIT_IDS,
  type LimitId,
  type LimitValue,
  type PlanId,
} from '@/content/plans';
import type { EffectiveLimits, ResolvedLimit } from '@/lib/plans/resolve';
import { MEASURES, daysUntilReset, periodResetAt } from '@/lib/usage/metrics';

/* -------------------------------------------------------------------------- */
/* The decision                                                               */
/* -------------------------------------------------------------------------- */

export type QuotaRefusal =
  /** The plan's allowance for the period is spent. */
  | 'period_exhausted'
  /** A ceiling on how many may exist at once is reached. */
  | 'at_capacity'
  /** The limit is 0 on this plan: the feature is not included at all. */
  | 'not_included'
  /** The subscription state forbids new work regardless of the limit. */
  | 'subscription_blocked';

export interface QuotaAllowed {
  readonly allowed: true;
  readonly limitId: LimitId;
  /** `null` when the limit is unlimited. */
  readonly remaining: number | null;
  readonly used: number;
  readonly limit: LimitValue;
}

export interface QuotaDenied {
  readonly allowed: false;
  readonly limitId: LimitId;
  readonly reason: QuotaRefusal;
  /** Shown to the user. Always names the limit, the usage and the way out. */
  readonly message: string;
  readonly used: number;
  readonly limit: LimitValue;
  /** For a per-period limit: when the allowance comes back. */
  readonly resetsAt?: string;
}

export type QuotaDecision = QuotaAllowed | QuotaDenied;

export function isDenied(decision: QuotaDecision): decision is QuotaDenied {
  return !decision.allowed;
}

/* -------------------------------------------------------------------------- */
/* The check                                                                  */
/* -------------------------------------------------------------------------- */

export interface QuotaContext {
  readonly plan: PlanId;
  readonly limits: EffectiveLimits;
  /**
   * How much is already used: the period total for a per-period limit, the live
   * row count for an absolute one. The caller measures; this function decides.
   */
  readonly used: number;
  /** The billing period, for the reset message. Ignored for absolute limits. */
  readonly periodStart: string;
  readonly now: Date;
  /**
   * Set when the subscription itself blocks new work — unpaid past the grace
   * window, or cancelled. Checked FIRST, because no limit matters if the account
   * is not entitled to write at all.
   */
  readonly blockedReason?: string;
}

/**
 * Whether one more unit of `limitId` may be consumed.
 *
 * `amount` is for limits consumed in bulk — tokens, where a single request costs
 * thousands. Budgeting the worst case BEFORE the call is the only way to avoid
 * paying for a request that will push the account over.
 */
export function checkLimit(limitId: LimitId, context: QuotaContext, amount = 1): QuotaDecision {
  const limit = context.limits[limitId];

  if (context.blockedReason) {
    return {
      allowed: false,
      limitId,
      reason: 'subscription_blocked',
      message: context.blockedReason,
      used: context.used,
      limit: limit.value,
    };
  }

  if (limit.value === null) {
    return { allowed: true, limitId, remaining: null, used: context.used, limit: null };
  }

  if (limit.value === 0) {
    return {
      allowed: false,
      limitId,
      reason: 'not_included',
      message: `${limit.label} is not included on the ${context.plan} plan. Upgrading adds it.`,
      used: context.used,
      limit: 0,
    };
  }

  if (context.used + amount > limit.value) {
    return buildDenial(limit, context, amount);
  }

  return {
    allowed: true,
    limitId,
    remaining: limit.value - context.used - amount,
    used: context.used,
    limit: limit.value,
  };
}

function buildDenial(limit: ResolvedLimit, context: QuotaContext, amount: number): QuotaDenied {
  const value = limit.value as number;
  const formatted = value.toLocaleString('en-IN');
  const used = context.used.toLocaleString('en-IN');
  // "1 automations" reads as unfinished software. The units are declared plural
  // because that is the common case; one is the exception.
  const unit = value === 1 ? singular(limit.unit) : limit.unit;

  if (limit.kind === 'absolute') {
    return {
      allowed: false,
      limitId: limit.id,
      reason: 'at_capacity',
      message: `The ${context.plan} plan allows ${formatted} ${unit}, and you have ${used}. Remove one, or upgrade for more.`,
      used: context.used,
      limit: value,
    };
  }

  const days = daysUntilReset(context.periodStart, context.now);
  const when =
    days === 0
      ? 'Your allowance resets today.'
      : days === 1
        ? 'Your allowance resets tomorrow.'
        : `Your allowance resets in ${days} days.`;

  // A single request larger than the whole monthly allowance is a different
  // problem from a spent allowance, and telling someone to "wait for the reset"
  // when waiting cannot help is worse than saying nothing.
  const unreachable = amount > value;
  const message = unreachable
    ? `That request needs ${amount.toLocaleString('en-IN')} ${limit.unit}, which is more than the ${formatted} ${unit} the ${context.plan} plan allows in a whole month. Narrow the scope, or upgrade.`
    : `You have used ${used} of ${formatted} ${unit} this month. ${when} Upgrading raises the limit immediately.`;

  return {
    allowed: false,
    limitId: limit.id,
    reason: 'period_exhausted',
    message,
    used: context.used,
    limit: value,
    resetsAt: periodResetAt(context.periodStart),
  };
}

/* -------------------------------------------------------------------------- */
/* Reporting                                                                  */
/* -------------------------------------------------------------------------- */

export interface LimitStatus {
  readonly limit: ResolvedLimit;
  readonly used: number;
  readonly remaining: number | null;
  /** 0–100, or `null` when unlimited. Clamped: usage can exceed an override. */
  readonly percentUsed: number | null;
  readonly exhausted: boolean;
  /** True from 80% — the point at which telling someone is still useful. */
  readonly nearLimit: boolean;
}

export const NEAR_LIMIT_THRESHOLD = 0.8;

export function limitStatus(limit: ResolvedLimit, used: number): LimitStatus {
  if (limit.value === null) {
    return { limit, used, remaining: null, percentUsed: null, exhausted: false, nearLimit: false };
  }
  if (limit.value === 0) {
    return { limit, used, remaining: 0, percentUsed: 100, exhausted: true, nearLimit: true };
  }
  const remaining = Math.max(limit.value - used, 0);
  const ratio = used / limit.value;
  return {
    limit,
    used,
    remaining,
    // Clamped at 100: a limit lowered by an admin below current usage would
    // otherwise render a 340% bar, which reads as a bug rather than as a cap.
    percentUsed: Math.min(Math.round(ratio * 100), 100),
    exhausted: used >= limit.value,
    nearLimit: ratio >= NEAR_LIMIT_THRESHOLD,
  };
}

/** Every limit that is exhausted or close to it, worst first. */
export function pressurePoints(
  statuses: readonly LimitStatus[],
): readonly LimitStatus[] {
  return statuses
    .filter((status) => status.nearLimit)
    .sort((a, b) => (b.percentUsed ?? 0) - (a.percentUsed ?? 0));
}

/**
 * The singular of a declared unit.
 *
 * Deliberately tiny and deliberately not a library: the units are a closed set
 * declared in `content/plans.ts`, and a general-purpose inflector would be a
 * dependency added to handle words we control.
 */
function singular(unit: string): string {
  if (unit === 'members') return 'member';
  return unit.endsWith('s') ? unit.slice(0, -1) : unit;
}

/**
 * Asserts every limit in the registry has a measure.
 *
 * Exported so the gate test can call it rather than re-deriving the list, and so
 * the failure names the limit that was forgotten.
 */
export function unmeasuredLimits(): readonly LimitId[] {
  return LIMIT_IDS.filter((id) => MEASURES[id] === undefined);
}
