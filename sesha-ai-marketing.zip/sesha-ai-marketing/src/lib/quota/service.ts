/**
 * The enforcement path: measure, decide, record.
 *
 * `enforce()` is what every service calls before doing something a plan limits.
 * It is one function so that adding a limit means adding a call, not designing a
 * check — and so the refusal is recorded in one place rather than eleven.
 *
 * WHY REFUSALS ARE RECORDED
 * A customer blocked thirty times a day is a sales signal and a support problem,
 * and it is completely invisible unless the refusal is written down. Before
 * Phase 7 the AI path refused requests and recorded nothing, so nobody could
 * answer "how often do we block people, and on what".
 *
 * The refusal row is best-effort for the same reason usage recording is: if the
 * table is unavailable, the right outcome is that the customer still gets the
 * correct answer to their request, not that the product falls over.
 */

import type { Database } from '@/lib/db/repositories';
import type { LimitId } from '@/content/plans';
import { entitlementFor, type PlanServiceContext } from '@/lib/plans/service';
import { periodStartOf } from '@/lib/usage/metrics';
import { usedFor } from '@/lib/usage/service';

import { checkLimit, isDenied, type QuotaDecision, type QuotaDenied } from './index';

export interface QuotaServiceContext extends PlanServiceContext {
  readonly db: Database;
}

function clock(context: QuotaServiceContext): Date {
  return context.now?.() ?? new Date();
}

/**
 * Thrown when a caller wants an exception rather than a decision.
 *
 * Carries the whole decision so the route can return 402 with the limit, the
 * usage and the reset date rather than a bare "quota exceeded".
 */
export class QuotaExceededError extends Error {
  readonly code = 'QUOTA_EXCEEDED' as const;
  readonly decision: QuotaDenied;

  constructor(decision: QuotaDenied) {
    super(decision.message);
    this.name = 'QuotaExceededError';
    this.decision = decision;
  }
}

export interface EnforceOptions {
  readonly projectId?: string | null;
  readonly userId?: string | null;
  /** For a bulk limit such as tokens. Budgeted BEFORE the work is done. */
  readonly amount?: number;
  /** Skip recording. Used by a dry-run preflight that a screen calls on load. */
  readonly record?: boolean;
}

/**
 * Checks one limit for one organization, recording a refusal.
 *
 * Returns the decision. `enforceOrThrow` is the variant for call sites that
 * would otherwise write `if (!decision.allowed) throw` everywhere.
 */
export async function enforce(
  context: QuotaServiceContext,
  organizationId: string,
  limitId: LimitId,
  options: EnforceOptions = {},
): Promise<QuotaDecision> {
  const now = clock(context);
  const periodStart = periodStartOf(now);
  const entitlement = await entitlementFor(context, organizationId);
  const used = await usedFor(context, organizationId, limitId, periodStart);

  const decision = checkLimit(
    limitId,
    {
      plan: entitlement.plan,
      limits: entitlement.limits,
      used,
      periodStart,
      now,
      ...(entitlement.writable ? {} : { blockedReason: entitlement.blockedReason ?? 'This subscription cannot create new work.' }),
    },
    options.amount ?? 1,
  );

  if (isDenied(decision) && options.record !== false) {
    try {
      await context.db.quotaRefusals.record({
        organizationId,
        projectId: options.projectId ?? null,
        userId: options.userId ?? null,
        limitId,
        reason: decision.reason,
        plan: entitlement.plan,
        usedAtRefusal: decision.used,
        limitAtRefusal: typeof decision.limit === 'number' ? decision.limit : null,
        periodStart,
        refusedAt: now,
      });
    } catch {
      // Best-effort. See the header.
    }
  }

  return decision;
}

export async function enforceOrThrow(
  context: QuotaServiceContext,
  organizationId: string,
  limitId: LimitId,
  options: EnforceOptions = {},
): Promise<void> {
  const decision = await enforce(context, organizationId, limitId, options);
  if (isDenied(decision)) throw new QuotaExceededError(decision);
}

/**
 * Whether the account may write at all, independent of any limit.
 *
 * For the screens that need to disable a form before the user fills it in —
 * refusing after someone has typed for five minutes is worse than telling them
 * first.
 */
export async function writeAccess(
  context: QuotaServiceContext,
  organizationId: string,
): Promise<{ readonly writable: boolean; readonly reason?: string }> {
  const entitlement = await entitlementFor(context, organizationId);
  return entitlement.writable
    ? { writable: true }
    : { writable: false, ...(entitlement.blockedReason ? { reason: entitlement.blockedReason } : {}) };
}
