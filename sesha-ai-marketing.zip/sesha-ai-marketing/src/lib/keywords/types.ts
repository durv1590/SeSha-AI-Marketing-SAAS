/**
 * The keyword system.
 *
 * THE CONSTRAINT THAT SHAPES THIS FILE
 * "Never fabricate search volume. If unavailable: 'Data unavailable' or
 * 'AI estimate'."
 *
 * SeSha has no keyword data source connected. So search volume is not an
 * optional number that happens to be missing — it is a value this product
 * cannot know, and the type system says so: `volume` is a discriminated union
 * with no variant that carries a bare number. There is no way to write
 * `volume: 1200` and have it compile.
 *
 * The same treatment is given to competition, which is equally unknowable
 * without a data source.
 *
 * WHAT IS KNOWABLE
 * Relevance is computable: does the site's own content address this query.
 * Intent is classifiable from the query's wording. Priority follows from
 * relevance and intent. Content format follows from intent. Entities come from
 * the crawl. Those are reported as measurements; volume and competition are not.
 */

/* -------------------------------------------------------------------------- */
/* Classification                                                             */
/* -------------------------------------------------------------------------- */

/** The keyword kinds the brief lists. */
export const KEYWORD_KINDS = [
  'primary',
  'secondary',
  'long-tail',
  'local',
  'commercial',
  'informational',
  'transactional',
  'conversational',
  'question',
] as const;
export type KeywordKind = (typeof KEYWORD_KINDS)[number];

export const KEYWORD_KIND_LABELS: Record<KeywordKind, string> = {
  primary: 'Primary',
  secondary: 'Secondary',
  'long-tail': 'Long-tail',
  local: 'Local',
  commercial: 'Commercial',
  informational: 'Informational',
  transactional: 'Transactional',
  conversational: 'Conversational',
  question: 'Question',
};

export const SEARCH_INTENTS = ['informational', 'commercial', 'transactional', 'navigational'] as const;
export type KeywordIntent = (typeof SEARCH_INTENTS)[number];

/* -------------------------------------------------------------------------- */
/* Unknowable values                                                          */
/* -------------------------------------------------------------------------- */

/**
 * Search volume.
 *
 * Three states and no fourth. `unavailable` is the honest default with no data
 * source; `estimate` requires a stated basis and is labelled as an estimate
 * everywhere it is shown; `measured` exists so a future integration has
 * somewhere to put a real figure, and it requires naming the source.
 */
export type SearchVolume =
  | { readonly kind: 'unavailable'; readonly label: 'Data unavailable'; readonly why: string }
  | {
      readonly kind: 'estimate';
      readonly label: 'AI estimate';
      readonly magnitude: VolumeMagnitude;
      readonly basis: string;
    }
  | {
      readonly kind: 'measured';
      readonly label: 'Measured';
      readonly monthly: number;
      readonly source: string;
      readonly asOf: string;
    };

/**
 * An estimate is expressed as a BAND, never a number.
 *
 * "Around 1,200 searches a month" reads as a measurement. "Low" does not, and it
 * carries about as much real information.
 */
export const VOLUME_MAGNITUDES = ['very-low', 'low', 'moderate', 'high', 'unknown'] as const;
export type VolumeMagnitude = (typeof VOLUME_MAGNITUDES)[number];

export const MAGNITUDE_LABELS: Record<VolumeMagnitude, string> = {
  'very-low': 'Very low — a handful of searches',
  low: 'Low',
  moderate: 'Moderate',
  high: 'High',
  unknown: 'Cannot be judged',
};

export const NO_VOLUME_DATA: SearchVolume = {
  kind: 'unavailable',
  label: 'Data unavailable',
  why: 'No keyword data source is connected to this workspace, so SeSha does not know how often this is searched for.',
};

/** Competition, on exactly the same footing as volume. */
export type Competition =
  | { readonly kind: 'unavailable'; readonly label: 'Data unavailable'; readonly why: string }
  | {
      readonly kind: 'estimate';
      readonly label: 'AI estimate';
      readonly level: CompetitionLevel;
      readonly basis: string;
    }
  | {
      readonly kind: 'measured';
      readonly label: 'Measured';
      readonly score: number;
      readonly source: string;
      readonly asOf: string;
    };

export const COMPETITION_LEVELS = ['low', 'moderate', 'high', 'unknown'] as const;
export type CompetitionLevel = (typeof COMPETITION_LEVELS)[number];

export const NO_COMPETITION_DATA: Competition = {
  kind: 'unavailable',
  label: 'Data unavailable',
  why: 'Assessing competition needs search result data, which is not connected to this workspace.',
};

/**
 * The one string any interface should print for a volume or competition value.
 * Centralised so no surface can accidentally render a bare number.
 */
export function volumeLabel(volume: SearchVolume): string {
  switch (volume.kind) {
    case 'measured':
      return `${volume.monthly.toLocaleString()} / month (${volume.source}, ${volume.asOf})`;
    case 'estimate':
      return `${MAGNITUDE_LABELS[volume.magnitude]} — AI estimate`;
    default:
      return volume.label;
  }
}

export function competitionLabel(competition: Competition): string {
  switch (competition.kind) {
    case 'measured':
      return `${competition.score}/100 (${competition.source}, ${competition.asOf})`;
    case 'estimate':
      return `${competition.level} — AI estimate`;
    default:
      return competition.label;
  }
}

/* -------------------------------------------------------------------------- */
/* Relevance — the part that IS measurable                                    */
/* -------------------------------------------------------------------------- */

/**
 * How well the site's own content already addresses a query.
 *
 * This is computed from the crawl, so it is a measurement rather than an
 * estimate, and it is the value the priority ordering leans on most.
 */
export interface Relevance {
  /** 0–100. */
  readonly score: number;
  /** Pages that appear to address the query. */
  readonly coveringUrls: readonly string[];
  readonly basis: string;
}

export const PRIORITIES = ['high', 'medium', 'low'] as const;
export type Priority = (typeof PRIORITIES)[number];

export const CONTENT_FORMAT_SUGGESTIONS = [
  'answer-section',
  'faq-entry',
  'how-to',
  'comparison',
  'landing-page',
  'blog-post',
  'product-page',
  'service-page',
  'location-page',
] as const;
export type ContentFormatSuggestion = (typeof CONTENT_FORMAT_SUGGESTIONS)[number];

export interface Keyword {
  readonly query: string;
  readonly kinds: readonly KeywordKind[];
  readonly intent: KeywordIntent;
  readonly relevance: Relevance;
  readonly volume: SearchVolume;
  readonly competition: Competition;
  readonly priority: Priority;
  readonly contentFormat: ContentFormatSuggestion;
  /** Entities from the crawl that relate to this query. */
  readonly entities: readonly string[];
  /** Where the query itself came from. */
  readonly source: KeywordSource;
}

export const KEYWORD_SOURCES = ['page_heading', 'page_title', 'faq', 'user_provided', 'ai_suggested'] as const;
export type KeywordSource = (typeof KEYWORD_SOURCES)[number];

export const KEYWORD_SOURCE_LABELS: Record<KeywordSource, string> = {
  page_heading: 'From a heading on your site',
  page_title: 'From a page title on your site',
  faq: 'From your FAQ content',
  user_provided: 'You entered this',
  ai_suggested: 'Suggested by AI',
};

/* -------------------------------------------------------------------------- */
/* Classification logic                                                       */
/* -------------------------------------------------------------------------- */

const TRANSACTIONAL_SIGNALS = /\b(buy|order|purchase|price|pricing|cost|cheap|quote|hire|book|booking|subscribe|download|sign ?up|free trial|discount|deal|coupon|near me|delivery)\b/i;
const COMMERCIAL_SIGNALS = /\b(best|top|review|reviews|compare|comparison|vs|versus|alternative|alternatives|cheapest|which)\b/i;
const INFORMATIONAL_SIGNALS = /\b(what|why|how|when|who|guide|tutorial|learn|meaning|definition|example|examples|tips|ideas)\b/i;
const LOCAL_SIGNALS = /\b(near me|nearby|in [a-z]+|local|around me|close to me|open now|directions)\b/i;
const BRAND_ISH = /\b(login|log in|sign in|contact|careers|about us|support)\b/i;

/** Classifies a query's intent from its wording. */
export function classifyIntent(query: string): KeywordIntent {
  const text = query.trim();
  if (BRAND_ISH.test(text)) return 'navigational';
  if (TRANSACTIONAL_SIGNALS.test(text)) return 'transactional';
  if (COMMERCIAL_SIGNALS.test(text)) return 'commercial';
  if (INFORMATIONAL_SIGNALS.test(text)) return 'informational';
  // Default to informational: it is the least assuming, and treating an
  // unclassifiable query as transactional would overstate its value.
  return 'informational';
}

/** Every kind that applies. A query is usually several at once. */
export function classifyKinds(query: string, isPrimary: boolean): KeywordKind[] {
  const text = query.trim();
  const words = text.split(/\s+/).filter(Boolean).length;
  const kinds = new Set<KeywordKind>();

  kinds.add(isPrimary ? 'primary' : 'secondary');
  if (words >= 4) kinds.add('long-tail');
  if (LOCAL_SIGNALS.test(text)) kinds.add('local');
  if (TRANSACTIONAL_SIGNALS.test(text)) kinds.add('transactional');
  if (COMMERCIAL_SIGNALS.test(text)) kinds.add('commercial');
  if (INFORMATIONAL_SIGNALS.test(text)) kinds.add('informational');
  if (text.endsWith('?') || /^(what|who|when|where|why|how|which|can|do|does|is|are|should)\b/i.test(text)) {
    kinds.add('question');
  }
  // Conversational means phrased the way a person speaks: long, and either a
  // question or containing a first-person pronoun.
  if (words >= 5 && (kinds.has('question') || /\b(i|my|me|we|our)\b/i.test(text))) {
    kinds.add('conversational');
  }

  return [...kinds];
}

/** The format most likely to serve a query of this intent and shape. */
export function suggestFormat(query: string, intent: KeywordIntent): ContentFormatSuggestion {
  const text = query.trim();
  if (/\b(vs|versus|compare|comparison|alternative)\b/i.test(text)) return 'comparison';
  if (/^how to\b/i.test(text) || /\bstep by step\b/i.test(text)) return 'how-to';
  if (text.endsWith('?') || /^(what|why|who|when|which|can|does|is|are)\b/i.test(text)) {
    return text.split(/\s+/).length <= 8 ? 'faq-entry' : 'answer-section';
  }
  if (LOCAL_SIGNALS.test(text)) return 'location-page';
  switch (intent) {
    case 'transactional':
      return 'product-page';
    case 'commercial':
      return 'landing-page';
    case 'navigational':
      return 'service-page';
    default:
      return 'blog-post';
  }
}

/**
 * Priority.
 *
 * Computed from relevance and intent ONLY — the two things that are actually
 * known. A real priority would weigh volume and competition too; since those are
 * unavailable, the ordering says what it is based on rather than pretending to
 * the full calculation.
 */
export function computePriority(relevance: Relevance, intent: KeywordIntent): Priority {
  const intentWeight = intent === 'transactional' ? 20 : intent === 'commercial' ? 12 : 0;
  const total = relevance.score + intentWeight;
  if (total >= 65) return 'high';
  if (total >= 35) return 'medium';
  return 'low';
}

export const PRIORITY_BASIS =
  'Priority is based on how well your existing pages already address the query and on the query’s intent. ' +
  'It does not include search volume or competition, because no data source for those is connected.';
