/**
 * Builds the keyword list from a crawl.
 *
 * Every query here came from the site's own content — a heading, a title, an FAQ
 * question — or from the user. Nothing is invented, and `source` records which,
 * so a user can see that a query in the list is one their own page already uses
 * rather than something the tool made up.
 *
 * Relevance is measured against the crawled text, which is what makes it a
 * measurement rather than an estimate. Volume and competition stay unavailable:
 * see the header of `types.ts`.
 */

import { countWords, isQuestion, type CrawlReport, type PageData } from '@/lib/crawler';
import {
  NO_COMPETITION_DATA,
  NO_VOLUME_DATA,
  classifyIntent,
  classifyKinds,
  computePriority,
  suggestFormat,
  type Keyword,
  type KeywordSource,
  type Relevance,
} from './types';

/** Words that carry no topical meaning and would dominate any overlap count. */
const STOP_WORDS = new Set([
  'a', 'an', 'the', 'and', 'or', 'but', 'if', 'then', 'than', 'as', 'at', 'by', 'for', 'from',
  'in', 'into', 'of', 'on', 'to', 'with', 'without', 'about', 'is', 'are', 'was', 'were', 'be',
  'been', 'being', 'do', 'does', 'did', 'have', 'has', 'had', 'it', 'its', 'this', 'that',
  'these', 'those', 'you', 'your', 'we', 'our', 'us', 'i', 'my', 'me', 'can', 'will', 'would',
  'should', 'could', 'may', 'might', 'must', 'not', 'no', 'yes', 'all', 'any', 'more', 'most',
  'other', 'some', 'such', 'only', 'own', 'same', 'so', 'too', 'very', 'just', 'how', 'what',
  'when', 'where', 'why', 'who', 'which',
]);

function significantWords(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s-]/gu, ' ')
    .split(/\s+/)
    .filter((word) => word.length > 2 && !STOP_WORDS.has(word));
}

export const MAX_KEYWORDS = 100;

/**
 * Measures how well the crawled pages already address a query.
 *
 * The score is the best single-page coverage, not an average: a query answered
 * thoroughly on one page is covered, even if forty other pages never mention it.
 */
export function measureRelevance(query: string, pages: readonly PageData[]): Relevance {
  const terms = significantWords(query);
  if (terms.length === 0 || pages.length === 0) {
    return {
      score: 0,
      coveringUrls: [],
      basis: 'Could not be measured: the query has no distinctive words, or no page was crawled.',
    };
  }

  const scored: { url: string; score: number }[] = [];

  for (const page of pages) {
    const haystacks = {
      title: (page.title ?? '').toLowerCase(),
      headings: [...page.h1, ...page.h2, ...page.h3].join(' ').toLowerCase(),
      body: page.text.toLowerCase(),
    };

    let matched = 0;
    let weighted = 0;
    for (const term of terms) {
      const inTitle = haystacks.title.includes(term);
      const inHeading = haystacks.headings.includes(term);
      const inBody = haystacks.body.includes(term);
      if (!inTitle && !inHeading && !inBody) continue;
      matched += 1;
      // A term in the title or a heading is a much stronger signal that the
      // page is ABOUT the subject than the same term buried in the body.
      weighted += inTitle ? 1 : inHeading ? 0.8 : 0.35;
    }

    if (matched === 0) continue;

    // Coverage of the query's terms, scaled by where they were found.
    const coverage = matched / terms.length;
    const score = Math.round(coverage * (weighted / matched) * 100);
    if (score > 0) scored.push({ url: page.url, score });
  }

  scored.sort((a, b) => b.score - a.score);
  const best = scored[0]?.score ?? 0;

  return {
    score: Math.min(100, best),
    coveringUrls: scored.slice(0, 5).map((item) => item.url),
    basis:
      scored.length === 0
        ? 'No crawled page mentions the distinctive words in this query.'
        : `Measured against the crawled text. ${scored.length} page${scored.length === 1 ? '' : 's'} mention these terms; the score reflects the page that covers them best, weighting the title and headings above the body.`,
  };
}

function buildKeyword(
  query: string,
  source: KeywordSource,
  pages: readonly PageData[],
  isPrimary: boolean,
  entities: readonly string[],
): Keyword {
  const relevance = measureRelevance(query, pages);
  const intent = classifyIntent(query);

  return {
    query,
    kinds: classifyKinds(query, isPrimary),
    intent,
    relevance,
    // Not a missing value to be filled in later — a value this product cannot
    // know. See lib/keywords/types.ts.
    volume: NO_VOLUME_DATA,
    competition: NO_COMPETITION_DATA,
    priority: computePriority(relevance, intent),
    contentFormat: suggestFormat(query, intent),
    entities: entities.slice(0, 5),
    source,
  };
}

export interface KeywordSet {
  readonly keywords: readonly Keyword[];
  /** Stated wherever the list is shown. */
  readonly dataNote: string;
  readonly extractedAt: Date;
}

export const KEYWORD_DATA_NOTE =
  'Every query below came from your own pages or from what you entered — none was invented. ' +
  'Search volume and competition show "Data unavailable" because no keyword data source is connected ' +
  'to this workspace. SeSha will not show a volume figure it cannot source.';

/**
 * Extracts the keyword set from a crawl.
 *
 * Questions come first and are treated as primary: they are the clearest
 * statement a site makes about what it intends to answer.
 */
export function extractKeywords(
  report: CrawlReport,
  userProvided: readonly string[] = [],
): KeywordSet {
  const pages = report.pages.filter((page) => !page.robots.noindex);
  const entities = [...new Set(pages.flatMap((page) => page.entities.organizationNames))];

  const seen = new Set<string>();
  const keywords: Keyword[] = [];

  const add = (query: string, source: KeywordSource, isPrimary: boolean) => {
    const cleaned = query.trim().replace(/\s+/g, ' ');
    if (cleaned.length < 3 || cleaned.length > 160) return;
    const key = cleaned.toLowerCase();
    if (seen.has(key)) return;
    if (keywords.length >= MAX_KEYWORDS) return;
    seen.add(key);
    keywords.push(buildKeyword(cleaned, source, pages, isPrimary, entities));
  };

  // The user's own list is authoritative and goes first.
  for (const query of userProvided) add(query, 'user_provided', true);

  // FAQ markup: the site has explicitly declared these as questions it answers.
  // Only structured data counts as 'faq' — a question-phrased heading is an
  // inference from wording and is sourced as the heading it actually is.
  for (const page of pages) {
    for (const faq of page.faqs) {
      if (faq.source === 'structured_data') add(faq.question, 'faq', true);
    }
  }

  // Question-phrased headings.
  for (const page of pages) {
    for (const heading of [...page.h1, ...page.h2, ...page.h3]) {
      if (isQuestion(heading)) add(heading, 'page_heading', true);
    }
  }

  // Titles and remaining headings, as secondary.
  for (const page of pages) {
    if (page.title) add(stripBrandSuffix(page.title), 'page_title', false);
  }
  for (const page of pages) {
    for (const heading of [...page.h1, ...page.h2]) {
      if (countWords(heading) >= 2) add(heading, 'page_heading', false);
    }
  }

  return {
    keywords: sortKeywords(keywords),
    dataNote: KEYWORD_DATA_NOTE,
    extractedAt: new Date(),
  };
}

/**
 * Removes the " | Brand Name" tail most titles carry.
 *
 * Kept conservative: only a separator with a short tail is stripped, so a title
 * that genuinely contains a dash is left alone.
 */
function stripBrandSuffix(title: string): string {
  const match = /^(.{8,}?)\s+[|–—-]\s+(.{2,40})$/.exec(title.trim());
  return match?.[1] ?? title;
}

const PRIORITY_ORDER = { high: 0, medium: 1, low: 2 } as const;

export function sortKeywords(keywords: readonly Keyword[]): Keyword[] {
  return [...keywords].sort((a, b) => {
    const byPriority = PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority];
    if (byPriority !== 0) return byPriority;
    return b.relevance.score - a.relevance.score;
  });
}

/**
 * Queries the site appears to care about but does not cover well — the gap
 * between what a heading promises and what the page delivers.
 */
export function coverageGaps(set: KeywordSet, threshold = 40): Keyword[] {
  return set.keywords.filter((keyword) => keyword.relevance.score < threshold);
}
