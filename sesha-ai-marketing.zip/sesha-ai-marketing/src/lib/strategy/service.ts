/**
 * Marketing strategy service.
 *
 * A strategy is generated section by section rather than in one call. That is
 * deliberate: the 17 sections have different input requirements, and a single
 * call would either refuse everything because one input is missing, or produce
 * a document whose weakest section is indistinguishable from its strongest.
 *
 * Sections whose required inputs are missing are NOT generated. They appear in
 * the saved strategy with their availability and what is missing, so the gap is
 * visible rather than filled with plausible text.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { assertTenant, type TenantContext } from '@/lib/tenant';
import { generatedByFrom, reviewStatusFor, type AiServiceContext } from '@/lib/ai/service';
import { loadWorkspaceContext } from '@/lib/ai/context';
import { AIOrchestrator } from '@/lib/ai/orchestrator';
import { blocksToText, type ClaimWarning, type ProvenanceBlock } from '@/lib/ai/provenance';
import { defaultProvider } from '@/lib/ai/provider';
import type { GenerationRecord } from '@/lib/ai/cost';
import type { ReviewStatus, StrategyRow } from '@/lib/db/types';
import {
  buildSectionBrief,
  planSections,
  type PlannedSection,
  type SectionAvailability,
  type StrategySectionId,
} from './sections';

export interface StrategyServiceContext extends AiServiceContext {}

/** One section as it is stored and displayed. */
export interface StoredSection {
  readonly id: StrategySectionId;
  readonly label: string;
  readonly availability: SectionAvailability;
  readonly missing: readonly string[];
  readonly note: string | null;
  /** Null when the section was not generated. */
  readonly blocks: readonly ProvenanceBlock[] | null;
  readonly text: string | null;
  readonly warnings: readonly ClaimWarning[];
  readonly error: string | null;
}

export interface GenerateStrategyInput {
  readonly projectId: string;
  readonly title?: string;
  /** Restricts generation to these sections. Omitted means all generatable. */
  readonly sections?: readonly StrategySectionId[];
}

export interface GenerateStrategyResult {
  readonly ok: boolean;
  readonly strategy: StrategyRow | null;
  readonly sections: readonly StoredSection[];
  readonly message?: string;
}

/**
 * Failures that mean the rest of the document cannot be generated either.
 * Anything else (a bad response for one section, say) is retried per section.
 */
const HARD_STOP_CODES = new Set(['rate_limited', 'not_configured', 'unauthorized', 'agent_not_implemented']);

function unavailableSection(planned: PlannedSection): StoredSection {
  return {
    id: planned.spec.id,
    label: planned.spec.label,
    availability: planned.availability,
    missing: planned.missing,
    note: planned.note,
    blocks: null,
    text: null,
    warnings: [],
    error: null,
  };
}

/**
 * Generates a strategy.
 *
 * Sections run SEQUENTIALLY, not in parallel: the orchestrator's quota check
 * is per call, and firing 17 at once would let a run start that the quota
 * cannot finish, spending budget on a document that is then incomplete.
 */
export async function generateStrategy(
  context: StrategyServiceContext,
  tenant: TenantContext,
  input: GenerateStrategyInput,
): Promise<GenerateStrategyResult> {
  requirePermission(tenant.role, 'content:create');

  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, input.projectId),
    'Project',
  );

  const workspace = await loadWorkspaceContext(context.db, tenant, input.projectId);
  const planned = planSections(workspace);

  const requested = input.sections ? new Set<string>(input.sections) : null;
  const orchestrator =
    context.orchestrator ??
    (() => {
      const provider = context.provider ?? defaultProvider();
      if (!provider) return null;
      return new AIOrchestrator({
        db: context.db,
        provider,
        ...(context.now ? { now: context.now } : {}),
        ...context.deps,
      });
    })();

  if (!orchestrator) {
    return {
      ok: false,
      strategy: null,
      sections: planned.map(unavailableSection),
      message: 'AI features are not configured on this deployment.',
    };
  }

  const stored: StoredSection[] = [];
  const allWarnings: ClaimWarning[] = [];
  let lastRecord: GenerationRecord | null = null;
  let stopped: string | null = null;

  for (const section of planned) {
    if (section.availability === 'unavailable') {
      stored.push(unavailableSection(section));
      continue;
    }
    if (requested && !requested.has(section.spec.id)) {
      stored.push(unavailableSection(section));
      continue;
    }
    if (stopped) {
      // Quota or rate limit ran out mid-document. Remaining sections are
      // recorded as not generated rather than silently omitted.
      stored.push({ ...unavailableSection(section), error: stopped });
      continue;
    }

    const result = await orchestrator.run(tenant, {
      agent: 'strategy',
      prompt: buildSectionBrief(section),
      context: workspace,
      projectId: input.projectId,
    });

    if (!result.ok) {
      // A hard stop applies to the rest of the run; a soft one is per-section.
      // The orchestrator emits quota denials as `quota_<reason>`.
      if (HARD_STOP_CODES.has(result.code) || result.code.startsWith('quota_')) {
        stopped = result.message;
      }
      stored.push({ ...unavailableSection(section), error: result.message });
      continue;
    }

    lastRecord = result.record;
    allWarnings.push(...result.response.warnings);

    stored.push({
      id: section.spec.id,
      label: section.spec.label,
      availability: section.availability,
      missing: section.missing,
      note: section.note,
      blocks: result.response.blocks,
      text: blocksToText(result.response.blocks),
      warnings: result.response.warnings,
      error: null,
    });
  }

  const generated = stored.filter((section) => section.blocks !== null);
  if (generated.length === 0) {
    return {
      ok: false,
      strategy: null,
      sections: stored,
      message: stopped ?? 'No section could be generated from the information available.',
    };
  }

  const strategy = await context.db.strategies.create({
    organizationId: tenant.organizationId,
    projectId: input.projectId,
    createdBy: tenant.userId,
    title: (input.title?.trim() || `Marketing strategy — ${project.name}`).slice(0, 200),
    sections: Object.fromEntries(stored.map((section) => [section.id, section])),
    blocks: generated.flatMap((section) => section.blocks ?? []),
    claimWarnings: allWarnings,
    generatedBy: lastRecord ? generatedByFrom(lastRecord) : {},
    status: reviewStatusFor(allWarnings),
  });

  return { ok: true, strategy, sections: stored };
}

/* -------------------------------------------------------------------------- */
/* Reading and review                                                         */
/* -------------------------------------------------------------------------- */

export async function listStrategies(
  context: StrategyServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<StrategyRow[]> {
  requirePermission(tenant.role, 'content:read');
  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  assertTenant(tenant, project, 'Project');
  return context.db.strategies.listForProject(tenant.organizationId, projectId);
}

export async function getStrategy(
  context: StrategyServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<StrategyRow> {
  requirePermission(tenant.role, 'content:read');
  const strategy = await context.db.strategies.findById(tenant.organizationId, id);
  return assertTenant(tenant, strategy, 'Strategy');
}

/**
 * Changes a strategy's review status.
 *
 * Approving needs `content:publish`, and a strategy carrying a claim-linter
 * ERROR cannot be approved at all until the offending section is regenerated
 * or edited — approving a document with a fabricated statistic in it is the
 * exact outcome the provenance system exists to prevent.
 */
export async function setStrategyStatus(
  context: StrategyServiceContext,
  tenant: TenantContext,
  id: string,
  status: ReviewStatus,
): Promise<StrategyRow> {
  requirePermission(tenant.role, 'content:create');

  const existing = assertTenant(
    tenant,
    await context.db.strategies.findById(tenant.organizationId, id),
    'Strategy',
  );

  if (status === 'approved') {
    requirePermission(tenant.role, 'content:publish');
    const hasError = (existing.claimWarnings as readonly ClaimWarning[]).some(
      (warning) => warning?.severity === 'error',
    );
    if (hasError) {
      throw new StrategyReviewError(
        'This strategy contains an unsourced factual claim. Regenerate or edit that section before approving.',
      );
    }
  }

  const updated = await context.db.strategies.update(tenant.organizationId, id, { status });
  return assertTenant(tenant, updated, 'Strategy');
}

export class StrategyReviewError extends Error {
  readonly code = 'REVIEW_BLOCKED' as const;
  constructor(message: string) {
    super(message);
    this.name = 'StrategyReviewError';
  }
}

export async function deleteStrategy(
  context: StrategyServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<void> {
  requirePermission(tenant.role, 'content:create');
  assertTenant(tenant, await context.db.strategies.findById(tenant.organizationId, id), 'Strategy');
  await context.db.strategies.softDelete(tenant.organizationId, id, new Date(context.now?.() ?? Date.now()));
}

/** What the strategy page shows before anything is generated. */
export async function strategyPlan(
  context: StrategyServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<PlannedSection[]> {
  requirePermission(tenant.role, 'content:read');
  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  assertTenant(tenant, project, 'Project');
  const workspace = await loadWorkspaceContext(context.db, tenant, projectId);
  return planSections(workspace);
}
