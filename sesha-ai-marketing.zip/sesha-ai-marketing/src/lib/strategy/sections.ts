/**
 * Marketing strategy structure.
 *
 * The seventeen sections from the Phase 3 brief, each declared with what it
 * needs and whether the workspace can currently supply it.
 *
 * THE `requires` FIELD IS THE POINT. A section that needs data we do not have
 * is not quietly generated from imagination — `planSections` marks it
 * unavailable and says what would unlock it. That is how "SEO strategy
 * placeholder" and "AEO strategy placeholder" are handled honestly: they are
 * real sections that report what they are waiting for, not empty headings.
 *
 * Framework-free and fully unit tested.
 */

import type { WorkspaceContext } from '@/lib/ai/context';

export const STRATEGY_SECTIONS = [
  'market-analysis',
  'audience',
  'personas',
  'positioning',
  'usp',
  'swot',
  'funnel',
  'channel-strategy',
  'content-strategy',
  'social-strategy',
  'paid-advertising',
  'seo-strategy',
  'aeo-strategy',
  'lead-generation',
  'retargeting',
  'kpis',
  'plan-30-60-90',
] as const;

export type StrategySectionId = (typeof STRATEGY_SECTIONS)[number];

/** Inputs a section depends on. Drives availability, not just documentation. */
export type StrategyInput =
  | 'business'
  | 'audience'
  | 'offering'
  | 'goals'
  | 'channels'
  | 'brand-voice'
  | 'competitors'
  | 'website-content'
  | 'analytics'
  | 'ad-account';

export interface StrategySectionSpec {
  readonly id: StrategySectionId;
  readonly label: string;
  readonly summary: string;
  readonly requires: readonly StrategyInput[];
  /** What the section must produce. Given to the strategy agent verbatim. */
  readonly instruction: string;
  /** Sections whose value depends on data no phase has connected yet. */
  readonly placeholderUntil?: string;
}

export const SECTION_SPECS: Record<StrategySectionId, StrategySectionSpec> = {
  'market-analysis': {
    id: 'market-analysis', label: 'Market analysis',
    summary: 'The market this business operates in, as far as the workspace describes it.',
    requires: ['business', 'offering'],
    instruction:
      'Describe the market from what the context says: the category, who buys, and the dynamics that follow from the stated positioning. Do NOT state market size, growth rate or share — you have no data for any of them. Mark the absence explicitly and say what source would supply it.',
  },
  audience: {
    id: 'audience', label: 'Audience',
    summary: 'Who the business is for, segmented.',
    requires: ['audience'],
    instruction:
      'Restate the target audience as the user described it (mark "user_provided"), then segment it into two or three groups that would need different messaging. Segments are inference — mark them so.',
  },
  personas: {
    id: 'personas', label: 'Personas',
    summary: 'Two or three working personas built from the stated audience.',
    requires: ['audience', 'offering'],
    instruction:
      'Build two or three personas from the stated audience. For each: the situation that brings them here, what they are trying to achieve, what would stop them buying, and what would convince them. NO invented demographics, incomes, job titles or budgets. Every persona is "ai_inference".',
  },
  positioning: {
    id: 'positioning', label: 'Positioning',
    summary: 'The place this business should occupy in the buyer’s mind.',
    requires: ['business', 'offering', 'audience'],
    instruction:
      'Write a positioning statement: for [audience] who [need], [business] is the [category] that [distinction]. Then explain what it rules out — a positioning that excludes nothing is not one.',
  },
  usp: {
    id: 'usp', label: 'Unique selling proposition',
    summary: 'The one thing worth leading with.',
    requires: ['offering', 'audience'],
    instruction:
      'Identify the strongest genuine differentiator from the context and express it in one sentence a customer would repeat. If the context contains nothing genuinely distinctive, SAY SO and describe what would need to be true — do not manufacture a differentiator.',
  },
  swot: {
    id: 'swot', label: 'SWOT',
    summary: 'Strengths, weaknesses, opportunities and threats.',
    requires: ['business', 'offering', 'audience'],
    instruction:
      'Strengths and weaknesses come only from the context — mark them "user_provided" where they restate it, "ai_inference" where you concluded them. Opportunities and threats are inference and must be specific to this business. Four to six points each; a generic point is worse than a missing one.',
  },
  funnel: {
    id: 'funnel', label: 'Funnel',
    summary: 'How a stranger becomes a customer here.',
    requires: ['audience', 'offering', 'channels'],
    instruction:
      'Map awareness, consideration, decision and retention for THIS business: what happens at each stage, on which of their stated channels, and what moves someone to the next stage. Do not give conversion rates — you have no baseline.',
  },
  'channel-strategy': {
    id: 'channel-strategy', label: 'Channel strategy',
    summary: 'Where to focus, and what to stop doing.',
    requires: ['channels', 'audience', 'goals'],
    instruction:
      'Work from the channels they said they use. Say which to prioritise and why, given the audience and goals, and say plainly if one of their channels looks like a poor fit. Recommend at most one new channel, with the reason.',
  },
  'content-strategy': {
    id: 'content-strategy', label: 'Content strategy',
    summary: 'What to publish, and why it earns its place.',
    requires: ['audience', 'offering', 'goals'],
    instruction:
      'Three or four content themes tied to funnel stages, with formats and a realistic cadence for a team this size. Each theme must connect to a stated goal.',
  },
  'social-strategy': {
    id: 'social-strategy', label: 'Social strategy',
    summary: 'How social supports the goals.',
    requires: ['audience', 'channels', 'brand-voice'],
    instruction:
      'Per platform they actually use: what it is for, what to post, and roughly how often. Do not recommend every platform — say which to ignore.',
  },
  'paid-advertising': {
    id: 'paid-advertising', label: 'Paid advertising strategy',
    summary: 'Where paid spend would work, and where it would not.',
    requires: ['audience', 'offering', 'goals'],
    instruction:
      'Recommend an approach: objective, platforms, targeting logic, and the message angle to test first. Do NOT state budgets, CPCs, CPMs or expected returns — you have no account data. Say what would be needed to set a budget sensibly.',
  },
  'seo-strategy': {
    id: 'seo-strategy', label: 'SEO strategy',
    summary: 'Search visibility. Needs site data to go beyond principles.',
    requires: ['offering', 'audience', 'website-content'],
    placeholderUntil: 'a website crawl has run',
    instruction:
      'Without crawled site data you cannot audit anything. Give the topic areas this business should own based on its offering and audience, and the structural principles that apply. State clearly that a site audit is required before this becomes specific, and what the crawl would let you add.',
  },
  'aeo-strategy': {
    id: 'aeo-strategy', label: 'AEO strategy',
    summary: 'Answer-engine visibility. Needs site data to go beyond principles.',
    requires: ['offering', 'audience', 'website-content'],
    placeholderUntil: 'a website crawl has run',
    instruction:
      'Identify the questions this business should be the quoted answer to, derived from its offering and audience. Explain the answer-first structure those pages need. State that scoring existing pages requires a crawl, and what that would add.',
  },
  'lead-generation': {
    id: 'lead-generation', label: 'Lead generation',
    summary: 'How enquiries are captured and qualified.',
    requires: ['audience', 'offering', 'goals'],
    instruction:
      'Describe the offer that would earn a contact detail, where capture should sit, what to ask for (as little as possible), and how to qualify. Tie it to the stated goals.',
  },
  retargeting: {
    id: 'retargeting', label: 'Retargeting',
    summary: 'Reaching people who already engaged.',
    requires: ['audience', 'channels'],
    instruction:
      'Define the audiences worth retargeting, the message each should see, and the exclusions that stop someone being followed around after they have already bought. Mention the consent and privacy requirements.',
  },
  kpis: {
    id: 'kpis', label: 'KPIs',
    summary: 'What to measure, and how.',
    requires: ['goals'],
    instruction:
      'For each stated goal give one or two KPIs: the metric, where it is measured, and how often to review. DO NOT SET TARGET NUMBERS — there is no baseline, so a target would be invented. Say that the first period establishes the baseline.',
  },
  'plan-30-60-90': {
    id: 'plan-30-60-90', label: '30 / 60 / 90-day plan',
    summary: 'A sequenced plan of actions.',
    requires: ['goals', 'channels', 'offering'],
    instruction:
      'Three horizons. Days 1–30: foundations and quick wins. Days 31–60: build and publish. Days 61–90: measure and adjust. Every item must be an action this team can take with the channels and resources implied by the context. No item may depend on data or tooling they do not have.',
  },
};

/* -------------------------------------------------------------------------- */
/* Availability                                                               */
/* -------------------------------------------------------------------------- */

/** Inputs the workspace can currently supply. */
export function availableInputs(context: WorkspaceContext): Set<StrategyInput> {
  const available = new Set<StrategyInput>();

  if (context.business) available.add('business');
  if (context.profile?.targetAudience) available.add('audience');
  if (context.profile?.productsServices) available.add('offering');
  if ((context.profile?.marketingGoals.length ?? 0) > 0) available.add('goals');
  if ((context.profile?.marketingChannels.length ?? 0) > 0) available.add('channels');
  if (((context.profile?.brandVoice as { tones?: string[] })?.tones?.length ?? 0) > 0) {
    available.add('brand-voice');
  }
  if ((context.profile?.competitors.length ?? 0) > 0) available.add('competitors');

  // Not connected in any phase yet. Listed for completeness so the reason a
  // section is limited is explicit rather than implied.
  // 'website-content' — needs a crawl
  // 'analytics'       — needs a connected analytics source
  // 'ad-account'      — needs a connected ad account

  return available;
}

export type SectionAvailability = 'full' | 'partial' | 'unavailable';

export interface PlannedSection {
  readonly spec: StrategySectionSpec;
  readonly availability: SectionAvailability;
  readonly missing: readonly StrategyInput[];
  /** Shown in the interface when availability is not 'full'. */
  readonly note: string | null;
}

const INPUT_LABELS: Record<StrategyInput, string> = {
  business: 'business details',
  audience: 'target audience',
  offering: 'products and services',
  goals: 'marketing goals',
  channels: 'marketing channels',
  'brand-voice': 'brand voice',
  competitors: 'competitors',
  'website-content': 'website content (requires a crawl)',
  analytics: 'analytics data (requires a connected source)',
  'ad-account': 'ad account data (requires a connected account)',
};

/**
 * Decides what can honestly be generated.
 *
 * A section missing a REQUIRED workspace input is 'unavailable' and is not
 * generated at all. A section missing only an unconnected data source is
 * 'partial': it can still be written from principles, and says what is missing.
 */
export function planSections(context: WorkspaceContext): PlannedSection[] {
  const available = availableInputs(context);

  return STRATEGY_SECTIONS.map((id) => {
    const spec = SECTION_SPECS[id];
    const missing = spec.requires.filter((input) => !available.has(input));

    if (missing.length === 0) {
      return { spec, availability: 'full' as const, missing: [], note: null };
    }

    const externalOnly = missing.every((input) =>
      ['website-content', 'analytics', 'ad-account'].includes(input),
    );

    if (externalOnly) {
      return {
        spec,
        availability: 'partial' as const,
        missing,
        note: spec.placeholderUntil
          ? `Principles only until ${spec.placeholderUntil}.`
          : `Limited: ${missing.map((m) => INPUT_LABELS[m]).join(', ')} not connected.`,
      };
    }

    return {
      spec,
      availability: 'unavailable' as const,
      missing,
      note: `Needs ${missing.map((m) => INPUT_LABELS[m]).join(', ')} in your marketing profile.`,
    };
  });
}

export function generatableSections(context: WorkspaceContext): PlannedSection[] {
  return planSections(context).filter((section) => section.availability !== 'unavailable');
}

/** The instruction for one section, given to the strategy agent. */
export function buildSectionBrief(planned: PlannedSection): string {
  const lines = [`SECTION: ${planned.spec.label}`, planned.spec.instruction];

  if (planned.availability === 'partial' && planned.missing.length > 0) {
    lines.push(
      `MISSING INPUTS: ${planned.missing.map((m) => INPUT_LABELS[m]).join(', ')}.`,
      'Write what you honestly can without them, and include an "unavailable" block stating what is missing and what it would add. Do not fill the gap with plausible detail.',
    );
  }
  return lines.join('\n');
}

export function sectionLabel(id: StrategySectionId): string {
  return SECTION_SPECS[id].label;
}
