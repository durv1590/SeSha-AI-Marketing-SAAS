/**
 * Workspace service — businesses, projects, marketing profiles, crawl consent.
 *
 * Every function takes a `TenantContext` and goes through the tenant guard, so
 * a cross-organization read or write is impossible by construction rather than
 * by remembering to add a WHERE clause. Framework-free and fully unit tested.
 *
 * PLAN LIMITS are enforced here, at the service layer, not in the UI. Hiding
 * the "new project" button is a courtesy; refusing the create is the control.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { effectiveLimit, type LimitOverride } from '@/lib/plans/resolve';
import type { LimitId } from '@/content/plans';
import { NotFoundError, assertTenant, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { BusinessRow, CrawlConsentRow, MarketingProfileRow, Plan, ProjectRow } from '@/lib/db/types';
import {
  CRAWL_CONSENT_VERSION,
  slugifyProject,
  type BusinessDetails,
  type CrawlConsentInput,
  type MarketingProfileInput,
} from '@/lib/validation/onboarding';

export interface WorkspaceContext {
  readonly db: Database;
  readonly now?: () => number;
}

function clock(context: WorkspaceContext): number {
  return context.now?.() ?? Date.now();
}

/**
 * Projects included per plan.
 *
 * PHASE 7 MOVED THE NUMBERS OUT OF HERE. This used to be a hard-coded
 * `Record<Plan, number>` in business logic — exactly what the Phase 7 brief
 * forbids — and it was also the only plan limit outside the AI quotas that was
 * enforced at all. It now reads the plan registry, so an admin raising a
 * customer's project limit takes effect without a deployment.
 *
 * Kept as a function with the old name so the Phase 2 call sites and tests that
 * reference it still mean something, rather than being deleted and silently
 * losing their coverage.
 */
export function projectLimitFor(plan: Plan, overrides: readonly LimitOverride[] = []): number | null {
  return effectiveLimit(plan, 'projects', overrides).value;
}

export class PlanLimitError extends Error {
  readonly code = 'PLAN_LIMIT' as const;
  readonly limit: number;

  constructor(limit: number, resource: string) {
    super(`Your plan includes ${limit} ${resource}. Upgrade to add more.`);
    this.name = 'PlanLimitError';
    this.limit = limit;
  }
}

/* -------------------------------------------------------------------------- */
/* Businesses                                                                 */
/* -------------------------------------------------------------------------- */

export async function createBusiness(
  context: WorkspaceContext,
  tenant: TenantContext,
  details: BusinessDetails,
): Promise<BusinessRow> {
  requirePermission(tenant.role, 'business:update');
  return context.db.businesses.create({
    organizationId: tenant.organizationId,
    name: details.name,
    industry: details.industry,
    country: details.country,
    city: details.city,
    websiteUrl: details.websiteUrl,
    createdBy: tenant.userId,
  });
}

export async function updateBusiness(
  context: WorkspaceContext,
  tenant: TenantContext,
  businessId: string,
  details: Partial<BusinessDetails>,
): Promise<BusinessRow> {
  requirePermission(tenant.role, 'business:update');
  const existing = await context.db.businesses.findById(tenant.organizationId, businessId);
  assertTenant(tenant, existing, 'Business');

  const updated = await context.db.businesses.update(tenant.organizationId, businessId, details);
  if (!updated) throw new NotFoundError('Business');
  return updated;
}

export async function getBusiness(
  context: WorkspaceContext,
  tenant: TenantContext,
  businessId: string,
): Promise<BusinessRow> {
  requirePermission(tenant.role, 'business:read');
  return assertTenant(
    tenant,
    await context.db.businesses.findById(tenant.organizationId, businessId),
    'Business',
  );
}

/* -------------------------------------------------------------------------- */
/* Projects                                                                   */
/* -------------------------------------------------------------------------- */

export interface CreateProjectInput {
  readonly name: string;
  readonly description?: string;
  readonly businessId?: string | null;
}

export async function createProject(
  context: WorkspaceContext,
  tenant: TenantContext,
  input: CreateProjectInput,
): Promise<ProjectRow> {
  requirePermission(tenant.role, 'project:create');

  const subscription = await context.db.subscriptions.findForOrganization(tenant.organizationId);
  const plan: Plan = subscription?.plan ?? 'free';
  const overrides = await context.db.planLimits.listForOrganization(tenant.organizationId);
  const limit = projectLimitFor(
    plan,
    overrides.map((row) => ({
      limitId: row.limitId as LimitId,
      value: row.value,
      reason: row.reason,
      setBy: row.setBy,
      setAt: row.setAt.toISOString(),
    })),
  );
  // `null` is unlimited, which the Agency plan grants.
  if (limit !== null) {
    const existing = await context.db.projects.countForOrganization(tenant.organizationId);
    if (existing >= limit) throw new PlanLimitError(limit, existing === 1 ? 'project' : 'projects');
  }

  // If a business was named, it must belong to this organization.
  if (input.businessId) {
    assertTenant(
      tenant,
      await context.db.businesses.findById(tenant.organizationId, input.businessId),
      'Business',
    );
  }

  return context.db.projects.create({
    organizationId: tenant.organizationId,
    businessId: input.businessId ?? null,
    name: input.name,
    slug: await uniqueSlug(context, tenant.organizationId, slugifyProject(input.name)),
    description: input.description ?? null,
    status: 'active',
    createdBy: tenant.userId,
  });
}

async function uniqueSlug(
  context: WorkspaceContext,
  organizationId: string,
  base: string,
): Promise<string> {
  let candidate = base;
  for (let suffix = 2; suffix < 100; suffix += 1) {
    const clash = await context.db.projects.findBySlug(organizationId, candidate);
    if (!clash) return candidate;
    candidate = `${base}-${suffix}`;
  }
  return `${base}-${Date.now().toString(36)}`;
}

export async function listProjects(
  context: WorkspaceContext,
  tenant: TenantContext,
): Promise<ProjectRow[]> {
  requirePermission(tenant.role, 'project:read');
  return context.db.projects.listForOrganization(tenant.organizationId);
}

export async function getProject(
  context: WorkspaceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<ProjectRow> {
  requirePermission(tenant.role, 'project:read');
  return assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, projectId),
    'Project',
  );
}

export async function updateProject(
  context: WorkspaceContext,
  tenant: TenantContext,
  projectId: string,
  patch: { name?: string; description?: string; status?: ProjectRow['status'] },
): Promise<ProjectRow> {
  requirePermission(tenant.role, 'project:update');
  assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, projectId),
    'Project',
  );
  const updated = await context.db.projects.update(tenant.organizationId, projectId, patch);
  if (!updated) throw new NotFoundError('Project');
  return updated;
}

export async function deleteProject(
  context: WorkspaceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<void> {
  requirePermission(tenant.role, 'project:delete');
  assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, projectId),
    'Project',
  );
  await context.db.projects.softDelete(tenant.organizationId, projectId, new Date(clock(context)));
  await context.db.audit.record({
    organizationId: tenant.organizationId,
    actorId: tenant.userId,
    action: 'project.delete',
    entityType: 'project',
    entityId: projectId,
    outcome: 'success',
    metadata: { soft: true },
    ipHash: null,
    userAgent: null,
  });
}

/* -------------------------------------------------------------------------- */
/* Marketing profile                                                          */
/* -------------------------------------------------------------------------- */

export async function saveMarketingProfile(
  context: WorkspaceContext,
  tenant: TenantContext,
  projectId: string,
  input: MarketingProfileInput,
): Promise<MarketingProfileRow> {
  requirePermission(tenant.role, 'business:update');
  assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, projectId),
    'Project',
  );

  return context.db.marketingProfiles.upsert({
    organizationId: tenant.organizationId,
    projectId,
    targetAudience: input.targetAudience,
    productsServices: input.productsServices,
    priceRange: input.priceRange,
    marketingGoals: input.marketingGoals,
    marketingChannels: input.marketingChannels,
    brandVoice: input.brandVoice,
    competitors: input.competitors,
  });
}

export async function getMarketingProfile(
  context: WorkspaceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<MarketingProfileRow | null> {
  requirePermission(tenant.role, 'business:read');
  assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, projectId),
    'Project',
  );
  return context.db.marketingProfiles.findByProject(tenant.organizationId, projectId);
}

/* -------------------------------------------------------------------------- */
/* Website crawl consent                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Records explicit consent to access a website.
 *
 * Nothing in the platform may fetch a customer's site without a live row here.
 * The crawler itself is a later phase; this establishes the permission gate and
 * the audit trail first, deliberately in that order.
 */
export async function grantCrawlConsent(
  context: WorkspaceContext,
  tenant: TenantContext,
  projectId: string,
  input: CrawlConsentInput,
): Promise<CrawlConsentRow> {
  requirePermission(tenant.role, 'crawl:request');
  assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, projectId),
    'Project',
  );

  // Re-granting supersedes the previous consent rather than stacking.
  const existing = await context.db.crawlConsents.findActiveForProject(
    tenant.organizationId,
    projectId,
  );
  if (existing) {
    await context.db.crawlConsents.revoke(tenant.organizationId, existing.id, new Date(clock(context)));
  }

  const consent = await context.db.crawlConsents.grant({
    organizationId: tenant.organizationId,
    projectId,
    websiteUrl: input.websiteUrl,
    grantedBy: tenant.userId,
    consentVersion: input.consentVersion,
    maxPages: input.maxPages,
    respectRobots: input.respectRobots,
    retentionDays: input.retentionDays,
  });

  await context.db.audit.record({
    organizationId: tenant.organizationId,
    actorId: tenant.userId,
    action: 'crawl.consent.granted',
    entityType: 'website_crawl_consent',
    entityId: consent.id,
    outcome: 'success',
    metadata: {
      websiteUrl: input.websiteUrl,
      consentVersion: input.consentVersion,
      maxPages: input.maxPages,
      retentionDays: input.retentionDays,
    },
    ipHash: null,
    userAgent: null,
  });

  return consent;
}

export async function revokeCrawlConsent(
  context: WorkspaceContext,
  tenant: TenantContext,
  consentId: string,
  options: { deleteData: boolean } = { deleteData: true },
): Promise<void> {
  requirePermission(tenant.role, 'crawl:delete');
  const now = new Date(clock(context));

  // Looked up by its own id, scoped to the organization. The previous version
  // read `tenant.projectId`, which is optional on TenantContext and is not set
  // on a settings request — so the lookup always came back empty and revocation
  // always threw NotFound. Consent could not actually be withdrawn.
  const consent = await context.db.crawlConsents.findById(tenant.organizationId, consentId);
  // A consent from another organization is simply not found.
  if (!consent) throw new NotFoundError('Consent record');

  await context.db.crawlConsents.revoke(tenant.organizationId, consentId, now);
  let pagesDeleted = 0;
  if (options.deleteData) {
    // DELETE FIRST, THEN SAY SO. Until Phase 8 this only set `data_deleted_at`
    // and left every crawled page in place — the record claimed a deletion that
    // never happened. The pages go, then the marker is written.
    const crawls = await context.db.crawls.listForConsent(tenant.organizationId, consentId);
    for (const crawl of crawls) pagesDeleted += await context.db.crawls.deletePages(crawl.id);
    await context.db.crawlConsents.markDataDeleted(tenant.organizationId, consentId, now);
  }

  await context.db.audit.record({
    organizationId: tenant.organizationId,
    actorId: tenant.userId,
    action: 'crawl.consent.revoked',
    entityType: 'website_crawl_consent',
    entityId: consentId,
    outcome: 'success',
    metadata: { dataDeleted: options.deleteData, pagesDeleted },
    ipHash: null,
    userAgent: null,
  });
}

export async function getActiveCrawlConsent(
  context: WorkspaceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<CrawlConsentRow | null> {
  requirePermission(tenant.role, 'business:read');
  return context.db.crawlConsents.findActiveForProject(tenant.organizationId, projectId);
}

/* -------------------------------------------------------------------------- */
/* Onboarding                                                                 */
/* -------------------------------------------------------------------------- */

export interface OnboardingInput {
  readonly business: BusinessDetails;
  readonly profile: MarketingProfileInput;
  readonly projectName?: string;
  /** Present only when the user explicitly consented on the crawl step. */
  readonly crawlConsent?: CrawlConsentInput | null;
}

export interface OnboardingResult {
  readonly business: BusinessRow;
  readonly project: ProjectRow;
  readonly profile: MarketingProfileRow;
  readonly crawlConsent: CrawlConsentRow | null;
}

/**
 * Completes onboarding: business, first project, AI Marketing Profile, and —
 * only if explicitly agreed — a website crawl consent record.
 *
 * NOTE: the in-memory adapter has no transactions, so a failure part-way leaves
 * partial state. The PostgreSQL adapter must wrap this in one transaction; the
 * limitation is called out in src/lib/db/index.ts.
 */
export async function completeOnboarding(
  context: WorkspaceContext,
  tenant: TenantContext,
  input: OnboardingInput,
): Promise<OnboardingResult> {
  const business = await createBusiness(context, tenant, input.business);

  const project = await createProject(context, tenant, {
    name: input.projectName?.trim() || input.business.name,
    businessId: business.id,
  });

  const profile = await saveMarketingProfile(context, tenant, project.id, input.profile);

  let crawlConsent: CrawlConsentRow | null = null;
  if (input.crawlConsent && input.crawlConsent.consentVersion === CRAWL_CONSENT_VERSION) {
    crawlConsent = await grantCrawlConsent(context, tenant, project.id, input.crawlConsent);
  }

  await context.db.users.update(tenant.userId, {
    onboardingCompletedAt: new Date(clock(context)),
  });

  await context.db.audit.record({
    organizationId: tenant.organizationId,
    actorId: tenant.userId,
    action: 'onboarding.completed',
    entityType: 'project',
    entityId: project.id,
    outcome: 'success',
    metadata: { crawlConsentGranted: crawlConsent !== null },
    ipHash: null,
    userAgent: null,
  });

  return { business, project, profile, crawlConsent };
}
