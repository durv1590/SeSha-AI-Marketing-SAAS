/** Input hardening helpers shared by every API route. */

// Control characters, excluding tab (09), line feed (0A) and carriage return (0D).
const CONTROL_CHARS = new RegExp(
  '[' +
    String.fromCharCode(0) +
    '-' +
    String.fromCharCode(8) +
    String.fromCharCode(11) +
    String.fromCharCode(12) +
    String.fromCharCode(14) +
    '-' +
    String.fromCharCode(31) +
    String.fromCharCode(127) +
    ']',
  'g',
);

/** Collapses whitespace, strips control characters and enforces a max length. */
export function sanitizeText(value: unknown, maxLength = 2_000): string {
  if (typeof value !== 'string') return '';
  return value
    .replace(CONTROL_CHARS, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLength);
}

/** Preserves paragraph breaks (for message bodies) while stripping control chars. */
export function sanitizeMultiline(value: unknown, maxLength = 5_000): string {
  if (typeof value !== 'string') return '';
  return value
    .replace(CONTROL_CHARS, '')
    .split(/\r?\n/)
    .map((line) => line.replace(/[ \t]+/g, ' ').trim())
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
    .slice(0, maxLength);
}

/**
 * Blocks header-injection attempts in any value that could reach an email
 * header (name, subject, reply-to).
 */
export function hasHeaderInjection(value: string): boolean {
  return /[\r\n]|%0a|%0d/i.test(value);
}

export function isProbablyEmail(value: string): boolean {
  if (value.length > 254) return false;
  // Deliberately conservative: exactly one @, no whitespace, a dotted domain.
  return /^[^\s@]{1,64}@[^\s@.]+(\.[^\s@.]+)+$/.test(value);
}
