/**
 * Fixed-window rate limiter.
 *
 * Phase 1 uses an in-process Map, which is correct for a single instance and
 * for local development. It is deliberately written behind a narrow interface
 * so Phase 2 can swap in a Redis-backed store without touching call sites.
 *
 * Framework-free and deterministic: `now` is injectable so it can be tested.
 */

export interface RateLimitResult {
  readonly allowed: boolean;
  readonly limit: number;
  readonly remaining: number;
  /** Epoch milliseconds at which the current window resets. */
  readonly resetAt: number;
  /** Seconds the caller should wait before retrying. 0 when allowed. */
  readonly retryAfterSeconds: number;
}

export interface RateLimitOptions {
  readonly limit: number;
  readonly windowMs: number;
}

interface Bucket {
  count: number;
  resetAt: number;
}

export interface RateLimitStore {
  consume(key: string, options: RateLimitOptions, now?: number): RateLimitResult;
}

export class MemoryRateLimitStore implements RateLimitStore {
  private readonly buckets = new Map<string, Bucket>();

  consume(key: string, options: RateLimitOptions, now: number = Date.now()): RateLimitResult {
    const existing = this.buckets.get(key);

    if (!existing || existing.resetAt <= now) {
      const bucket: Bucket = { count: 1, resetAt: now + options.windowMs };
      this.buckets.set(key, bucket);
      this.evictExpired(now);
      return {
        allowed: true,
        limit: options.limit,
        remaining: options.limit - 1,
        resetAt: bucket.resetAt,
        retryAfterSeconds: 0,
      };
    }

    existing.count += 1;
    const allowed = existing.count <= options.limit;
    return {
      allowed,
      limit: options.limit,
      remaining: Math.max(0, options.limit - existing.count),
      resetAt: existing.resetAt,
      retryAfterSeconds: allowed ? 0 : Math.ceil((existing.resetAt - now) / 1000),
    };
  }

  /** Prevents unbounded growth in a long-lived process. */
  private evictExpired(now: number): void {
    if (this.buckets.size < 5_000) return;
    for (const [key, bucket] of this.buckets) {
      if (bucket.resetAt <= now) this.buckets.delete(key);
    }
  }

  reset(): void {
    this.buckets.clear();
  }
}

export const rateLimitStore: RateLimitStore = new MemoryRateLimitStore();

export const RATE_LIMITS = {
  // Public site (Phase 1)
  contact: { limit: 5, windowMs: 60 * 60 * 1000 },
  newsletter: { limit: 5, windowMs: 60 * 60 * 1000 },
  schemaValidator: { limit: 60, windowMs: 60 * 1000 },

  // Authentication (Phase 2). These are per client address and sit IN FRONT of
  // the per-account lockout in ./lockout.ts — the two defend different things:
  // this caps request volume, the lockout caps guesses against one account.
  signup: { limit: 10, windowMs: 60 * 60 * 1000 },
  signin: { limit: 30, windowMs: 15 * 60 * 1000 },
  passwordReset: { limit: 5, windowMs: 60 * 60 * 1000 },
  verifyEmail: { limit: 10, windowMs: 60 * 60 * 1000 },
  oauth: { limit: 20, windowMs: 15 * 60 * 1000 },

  // Authenticated application
  mutation: { limit: 120, windowMs: 60 * 1000 },
  read: { limit: 300, windowMs: 60 * 1000 },

  // AI generation (Phase 3). Tighter than `mutation` because each request can
  // cost real money at a provider. This is the per-ADDRESS cap; the
  // per-organization quota and request rate are enforced separately in
  // lib/ai/cost.ts, and neither substitutes for the other.
  ai: { limit: 30, windowMs: 60 * 1000 },
  // A multi-section strategy is one request that fans out into many calls.
  aiBatch: { limit: 5, windowMs: 10 * 60 * 1000 },

  // The admin platform (Phase 7). Tighter than the tenant application, because
  // the population is a handful of staff rather than every customer, and because
  // an unauthenticated caller probing the admin namespace should run out of
  // requests long before they learn anything. Writes are tighter still: a script
  // changing plan limits in a loop is either a bug or an attack.
  admin: { limit: 120, windowMs: 60 * 1000 },
  adminMutation: { limit: 30, windowMs: 60 * 1000 },
} as const satisfies Record<string, RateLimitOptions>;

/**
 * How many proxies sit in front of this application.
 *
 * `X-Forwarded-For` is a CLIENT-CONTROLLED HEADER. Anyone can send
 * `X-Forwarded-For: 1.2.3.4` and be counted as 1.2.3.4 — so taking the leftmost
 * entry, as this function used to, means every attacker gets an unlimited supply
 * of fresh rate-limit buckets by varying one header, and can also poison someone
 * else's bucket by claiming their address.
 *
 * The only entries that can be trusted are the ones appended by infrastructure
 * you control, and those are at the RIGHT-HAND end: each proxy appends the
 * address it saw. With one trusted proxy the real client is the last entry; with
 * two, the second-to-last, and so on.
 *
 * Default is 1, the common single-load-balancer deployment. Set
 * `TRUSTED_PROXY_COUNT` to match the real topology — getting it too HIGH is the
 * dangerous direction, because it starts trusting hops the attacker controls.
 */
function trustedProxyCount(): number {
  const raw = process.env.TRUSTED_PROXY_COUNT;
  if (raw === undefined) return 1;
  const parsed = Number(raw);
  if (!Number.isInteger(parsed) || parsed < 0 || parsed > 8) return 1;
  return parsed;
}

/**
 * Derives a rate-limit key from proxy headers.
 *
 * Falls back to a single shared bucket when no client address is available,
 * which fails CLOSED: everyone without a resolvable address shares one
 * allowance, rather than each getting their own.
 */
export function clientKey(headers: { get(name: string): string | null }): string {
  const hops = trustedProxyCount();
  const forwarded = headers.get('x-forwarded-for');

  if (forwarded && hops > 0) {
    const entries = forwarded
      .split(',')
      .map((entry) => entry.trim())
      .filter((entry) => entry.length > 0);
    // Count back from the right by the number of proxies we actually run.
    const index = entries.length - hops;
    const trusted = index >= 0 ? entries[index] : undefined;
    // Below zero means the header carries FEWER hops than we expect, which
    // means it did not come through the expected path. Do not guess.
    if (trusted) return trusted;
  }

  // `x-real-ip` is set by the proxy and is not appendable by the client, so it
  // is preferred over a forwarded chain we cannot account for.
  const real = headers.get('x-real-ip')?.trim();
  if (real) return real;

  return 'unknown-client';
}
