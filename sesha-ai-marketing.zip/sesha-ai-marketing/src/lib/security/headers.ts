/**
 * HTTP security headers applied to every response via next.config.ts.
 *
 * Notes on the CSP:
 *  - Next.js inlines a small hydration bootstrap, and the theme script must run
 *    before paint to avoid a flash of the wrong colour scheme. In production
 *    both are covered by 'unsafe-inline' for script-src; a nonce-based policy
 *    requires per-request middleware and is scheduled for Phase 2 alongside auth.
 *  - No third-party origins are allow-listed because Phase 1 loads no
 *    third-party scripts, fonts or images.
 */

export interface HeaderEntry {
  readonly key: string;
  readonly value: string;
}

const isProduction = process.env.NODE_ENV === 'production';

export const contentSecurityPolicy: string = [
  "default-src 'self'",
  // 'unsafe-eval' is required by the dev-mode React refresh runtime only.
  `script-src 'self' 'unsafe-inline'${isProduction ? '' : " 'unsafe-eval'"}`,
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "font-src 'self' data:",
  "connect-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
  "frame-src 'none'",
  'upgrade-insecure-requests',
].join('; ');

export function securityHeaders(): HeaderEntry[] {
  const headers: HeaderEntry[] = [
    { key: 'Content-Security-Policy', value: contentSecurityPolicy },
    { key: 'X-Content-Type-Options', value: 'nosniff' },
    { key: 'X-Frame-Options', value: 'DENY' },
    { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
    {
      key: 'Permissions-Policy',
      value: 'camera=(), microphone=(), geolocation=(), interest-cohort=(), payment=()',
    },
    { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
    { key: 'Cross-Origin-Resource-Policy', value: 'same-origin' },
    { key: 'X-DNS-Prefetch-Control', value: 'on' },
  ];

  if (isProduction) {
    headers.push({
      key: 'Strict-Transport-Security',
      value: 'max-age=63072000; includeSubDomains; preload',
    });
  }

  return headers;
}
