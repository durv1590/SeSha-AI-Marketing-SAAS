/**
 * Structured logging, with redaction that is not optional.
 *
 * WHAT A LOG LINE IS FOR: reconstructing what happened when something went
 * wrong, at three in the morning, by someone who did not write the code. That
 * means one JSON object per line, a stable set of fields, and a correlation id
 * that ties a request to every line it produced.
 *
 * WHAT A LOG LINE IS NOT FOR: storing the customer's data somewhere nobody is
 * thinking about. The brief is explicit — do not log passwords, API keys,
 * sensitive tokens, or private user content unnecessarily — and the honest way
 * to keep that promise is to make it structural rather than a rule people
 * remember. So:
 *
 *  · `redact()` runs over EVERY value on its way out. A caller cannot opt out,
 *    because there is no parameter that turns it off.
 *  · Keys whose NAME suggests a secret are replaced wholesale, without ever
 *    inspecting the value. `password`, `token`, `secret`, `apiKey`,
 *    `authorization`, `cookie`, and anything ending in `Key` or `Secret`.
 *  · Values that LOOK like a secret are replaced even under an innocent key,
 *    because the dangerous case is `{ detail: 'Bearer sk-live-...' }`.
 *  · Strings are truncated. A log line is not a place to put an article.
 *
 * The redaction is deliberately more eager than strictly necessary. A redacted
 * field that turns out to have been harmless costs one debugging session; a
 * leaked credential costs considerably more, and is not recoverable by reading
 * the logs again.
 *
 * TRANSPORT: `console` and nothing else. Shipping logs somewhere is a deployment
 * concern — a sidecar reads stdout — and adding an HTTP log shipper here would
 * add a dependency, a failure mode, and a second place for data to go.
 */

export const LOG_LEVELS = ['debug', 'info', 'warn', 'error'] as const;
export type LogLevel = (typeof LOG_LEVELS)[number];

const LEVEL_RANK: Readonly<Record<LogLevel, number>> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
};

/** Fields every line carries, so a log search has something to group by. */
export interface LogContext {
  /** Ties every line from one request together. */
  readonly requestId?: string;
  /** Which organization, for support. Never the organization's NAME. */
  readonly organizationId?: string;
  /** Which user, by id. Never an email address. */
  readonly userId?: string;
  readonly route?: string;
  readonly method?: string;
}

export interface LogLine extends LogContext {
  readonly level: LogLevel;
  readonly at: string;
  readonly message: string;
  readonly [field: string]: unknown;
}

/* -------------------------------------------------------------------------- */
/* Redaction                                                                  */
/* -------------------------------------------------------------------------- */

export const REDACTED = '[redacted]';

/**
 * Key names that are replaced without the value being looked at.
 *
 * Matched case-insensitively against the whole key, plus the suffix rules
 * below. Deliberately blunt: a false positive here is a field that reads
 * `[redacted]` in a log, which is a minor inconvenience with a loud explanation.
 */
const SECRET_KEYS = new Set(
  [
    'password',
    'newpassword',
    'currentpassword',
    'passwordhash',
    'token',
    'accesstoken',
    'refreshtoken',
    'idtoken',
    'sessiontoken',
    'csrftoken',
    'secret',
    'clientsecret',
    'apikey',
    'authorization',
    'cookie',
    'setcookie',
    'signature',
    'privatekey',
    'credentials',
    'otp',
    'pin',
    'cvv',
    'cardnumber',
  ].map((key) => key.toLowerCase()),
);

function isSecretKey(key: string): boolean {
  const lower = key.toLowerCase().replace(/[-_]/g, '');
  if (SECRET_KEYS.has(lower)) return true;
  // Suffix rules catch the ones nobody thought to list: `openaiApiKey`,
  // `webhookSecret`, `resetToken`, `authHeader`.
  return (
    lower.endsWith('key') ||
    lower.endsWith('secret') ||
    lower.endsWith('token') ||
    lower.endsWith('password')
  );
}

/**
 * Shapes that are secrets regardless of the key they arrive under.
 *
 * The case this exists for is `{ detail: 'Authorization: Bearer sk-live-…' }`,
 * where the key is innocent and the value is not.
 */
// GLOBAL flags: without `g`, `replace` redacts only the FIRST match, and a
// line carrying two tokens leaks the second. Found by the Phase 8 gate.
const SECRET_SHAPES: readonly RegExp[] = [
  /\bBearer\s+[A-Za-z0-9._~+/-]{12,}/gi,
  /\bBasic\s+[A-Za-z0-9+/=]{12,}/gi,
  // Provider key prefixes: OpenAI, Anthropic, Google, Stripe, generic.
  /\bsk-[A-Za-z0-9_-]{16,}/g,
  /\bsk_(?:live|test)_[A-Za-z0-9]{12,}/g,
  /\bAIza[A-Za-z0-9_-]{20,}/g,
  /\bghp_[A-Za-z0-9]{20,}/g,
  // A JWT: three base64url segments separated by dots.
  /\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}/g,
];

/** The longest a single string field may be before it is cut. */
export const MAX_FIELD_LENGTH = 512;

/** How deep to walk before giving up. A cyclic object must not hang a log call. */
const MAX_DEPTH = 6;

export function redactString(value: string): string {
  let out = value;
  for (const shape of SECRET_SHAPES) out = out.replace(shape, REDACTED);
  if (out.length > MAX_FIELD_LENGTH) {
    return `${out.slice(0, MAX_FIELD_LENGTH)}… [${out.length} chars]`;
  }
  return out;
}

/**
 * Makes a value safe to write down.
 *
 * Applied to every field of every line, with no way to bypass it.
 */
export function redact(value: unknown, depth = 0, seen = new WeakSet<object>()): unknown {
  if (value === null || value === undefined) return value;
  if (typeof value === 'string') return redactString(value);
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  if (typeof value === 'bigint') return `${value.toString()}n`;
  if (typeof value === 'function') return '[function]';
  if (typeof value === 'symbol') return '[symbol]';
  if (value instanceof Date) return value.toISOString();

  if (value instanceof Error) {
    return {
      name: value.name,
      message: redactString(value.message),
      // The stack is kept — it names our own files, not the customer's data —
      // but redacted too, because an error message often ends up inside it.
      stack: typeof value.stack === 'string' ? redactString(value.stack) : undefined,
    };
  }

  if (depth >= MAX_DEPTH) return '[too deep]';

  if (typeof value === 'object') {
    if (seen.has(value)) return '[circular]';
    seen.add(value);

    if (Array.isArray(value)) {
      // Arrays are capped: a log line is not a data export.
      const capped = value.slice(0, 20).map((entry) => redact(entry, depth + 1, seen));
      return value.length > 20 ? [...capped, `… ${value.length - 20} more`] : capped;
    }

    const out: Record<string, unknown> = {};
    for (const [key, entry] of Object.entries(value as Record<string, unknown>)) {
      out[key] = isSecretKey(key) ? REDACTED : redact(entry, depth + 1, seen);
    }
    return out;
  }

  return '[unserialisable]';
}

/* -------------------------------------------------------------------------- */
/* The logger                                                                 */
/* -------------------------------------------------------------------------- */

export interface LogSink {
  write(line: LogLine): void;
}

/** Writes one JSON object per line to stdout/stderr. */
export const consoleSink: LogSink = {
  write(line) {
    const serialised = JSON.stringify(line);
    if (line.level === 'error') console.error(serialised);
    else if (line.level === 'warn') console.warn(serialised);
    else console.log(serialised);
  },
};

/** Collects lines in memory. For tests, and for the admin panel's recent view. */
export class MemorySink implements LogSink {
  readonly lines: LogLine[] = [];
  constructor(private readonly cap = 500) {}
  write(line: LogLine): void {
    this.lines.push(line);
    if (this.lines.length > this.cap) this.lines.shift();
  }
}

function configuredLevel(): LogLevel {
  const raw = process.env.LOG_LEVEL?.toLowerCase();
  if (raw && (LOG_LEVELS as readonly string[]).includes(raw)) return raw as LogLevel;
  return process.env.NODE_ENV === 'production' ? 'info' : 'debug';
}

export interface Logger {
  debug(message: string, fields?: Record<string, unknown>): void;
  info(message: string, fields?: Record<string, unknown>): void;
  warn(message: string, fields?: Record<string, unknown>): void;
  error(message: string, fields?: Record<string, unknown>): void;
  /** A logger carrying extra context on every line it writes. */
  child(context: LogContext): Logger;
}

export function createLogger(
  context: LogContext = {},
  options: { readonly sink?: LogSink; readonly level?: LogLevel; readonly now?: () => Date } = {},
): Logger {
  const sink = options.sink ?? consoleSink;
  const minimum = LEVEL_RANK[options.level ?? configuredLevel()];
  const now = options.now ?? (() => new Date());

  function emit(level: LogLevel, message: string, fields?: Record<string, unknown>): void {
    if (LEVEL_RANK[level] < minimum) return;

    const redacted = (redact(fields ?? {}) ?? {}) as Record<string, unknown>;
    // The reserved fields are written LAST so a caller cannot overwrite `level`
    // or `at` with a field of the same name and make a line lie about itself.
    sink.write({
      ...redacted,
      ...context,
      level,
      at: now().toISOString(),
      message: redactString(message),
    });
  }

  return {
    debug: (message, fields) => emit('debug', message, fields),
    info: (message, fields) => emit('info', message, fields),
    warn: (message, fields) => emit('warn', message, fields),
    error: (message, fields) => emit('error', message, fields),
    child: (extra) => createLogger({ ...context, ...extra }, options),
  };
}

/** The application logger. */
export const log = createLogger();

/**
 * A correlation id for one request.
 *
 * Taken from an inbound `x-request-id` when one is present — so a trace that
 * started at the load balancer stays one trace — and generated otherwise. The
 * inbound value is CONSTRAINED, not trusted: it is client-controlled, and an
 * unbounded one would let a caller write arbitrary text into every log line of
 * their request.
 */
export function requestId(headers: { get(name: string): string | null }): string {
  const inbound = headers.get('x-request-id');
  if (inbound) {
    const cleaned = inbound.trim().replace(/[^A-Za-z0-9._-]/g, '');
    if (cleaned.length >= 8 && cleaned.length <= 64) return cleaned;
  }
  return crypto.randomUUID();
}
