/**
 * In-process metrics: counters, and latency as a histogram.
 *
 * WHAT THIS IS HONEST ABOUT
 * These are **process-local and reset on restart**. There is no metrics backend
 * here, no Prometheus scrape endpoint, no time series. What exists is enough to
 * answer "what is this instance doing right now" from the admin panel, and it
 * says so wherever it is displayed. The alternative — inventing a stored time
 * series — is the same mistake as inventing an analytics figure, and Phase 6
 * settled how this codebase treats that.
 *
 * LATENCY IS A HISTOGRAM, NOT A MEAN. A mean response time is the least useful
 * number in operations: one 30-second request hidden among a thousand fast ones
 * moves it by 30ms and nobody notices. Buckets let p95 and p99 be read off
 * directly, and the bucket boundaries are the ones worth distinguishing for a
 * web request rather than a smooth curve.
 *
 * NO LABELS WITH UNBOUNDED VALUES. A counter keyed by, say, a URL path with an
 * id in it grows without limit and eventually becomes the memory leak that takes
 * the process down. Every key here is drawn from a closed set, and `record()`
 * refuses anything else rather than silently accepting it.
 */

export const METRIC_KINDS = ['counter', 'histogram'] as const;
export type MetricKind = (typeof METRIC_KINDS)[number];

/**
 * Bucket upper bounds in milliseconds.
 *
 * Chosen for what they distinguish, not for even spacing: under 50ms is
 * "instant", 500ms is where a page stops feeling immediate, 3s is where people
 * start reloading, and anything past 10s is a failure wearing a success badge.
 */
export const LATENCY_BUCKETS_MS = [10, 50, 100, 250, 500, 1_000, 3_000, 10_000] as const;

export interface HistogramSnapshot {
  readonly count: number;
  readonly sumMs: number;
  /** Cumulative counts, one per bucket, plus a final overflow count. */
  readonly buckets: readonly { readonly leMs: number | null; readonly count: number }[];
  readonly maxMs: number;
}

export interface MetricsSnapshot {
  readonly since: string;
  readonly counters: Readonly<Record<string, number>>;
  readonly histograms: Readonly<Record<string, HistogramSnapshot>>;
}

/**
 * The closed set of metric names.
 *
 * A name not on this list is refused. That is the whole defence against
 * unbounded cardinality, and it also means the admin panel can render every
 * metric it knows about as zero rather than showing a sparse object — the same
 * reasoning as `WRITABLE_METRICS` in the usage layer.
 */
export const COUNTERS = [
  'api.request',
  'api.error',
  'api.rate_limited',
  'api.unauthorized',
  'api.not_found',
  'auth.sign_in',
  'auth.sign_in_failed',
  'auth.sign_out',
  'ai.request',
  'ai.refusal',
  'ai.provider_error',
  'job.started',
  'job.succeeded',
  'job.failed',
  'job.retried',
  'job.abandoned',
  'crawl.page_fetched',
  'crawl.page_refused',
  'quota.refused',
  'security.event',
  'breaker.opened',
  'breaker.rejected',
] as const;

export const HISTOGRAMS = ['api.latency', 'ai.latency', 'job.duration', 'crawl.fetch'] as const;

export type CounterName = (typeof COUNTERS)[number];
export type HistogramName = (typeof HISTOGRAMS)[number];

export function isCounter(value: unknown): value is CounterName {
  return typeof value === 'string' && (COUNTERS as readonly string[]).includes(value);
}

export function isHistogram(value: unknown): value is HistogramName {
  return typeof value === 'string' && (HISTOGRAMS as readonly string[]).includes(value);
}

export class Metrics {
  private readonly counters = new Map<string, number>();
  private readonly histograms = new Map<string, { count: number; sumMs: number; maxMs: number; buckets: number[] }>();
  private startedAt: Date;

  constructor(private readonly now: () => Date = () => new Date()) {
    this.startedAt = this.now();
  }

  /** Adds to a counter. An unknown name is ignored, not invented. */
  count(name: CounterName, by = 1): void {
    if (!isCounter(name)) return;
    if (!Number.isFinite(by) || by < 0) return;
    this.counters.set(name, (this.counters.get(name) ?? 0) + by);
  }

  /** Records one observation in milliseconds. */
  observe(name: HistogramName, ms: number): void {
    if (!isHistogram(name)) return;
    if (!Number.isFinite(ms) || ms < 0) return;

    let entry = this.histograms.get(name);
    if (!entry) {
      entry = { count: 0, sumMs: 0, maxMs: 0, buckets: LATENCY_BUCKETS_MS.map(() => 0) };
      this.histograms.set(name, entry);
    }
    entry.count += 1;
    entry.sumMs += ms;
    if (ms > entry.maxMs) entry.maxMs = ms;
    for (let index = 0; index < LATENCY_BUCKETS_MS.length; index += 1) {
      const bound = LATENCY_BUCKETS_MS[index];
      if (bound !== undefined && ms <= bound) {
        const current = entry.buckets[index];
        if (current !== undefined) entry.buckets[index] = current + 1;
      }
    }
  }

  /** Times a function and records the result, whether it throws or not. */
  async time<T>(name: HistogramName, fn: () => Promise<T>): Promise<T> {
    const started = this.now().getTime();
    try {
      return await fn();
    } finally {
      // In a `finally`, so a failed operation still contributes its latency.
      // Excluding failures is how a dashboard ends up reporting that everything
      // is fast while every slow request times out.
      this.observe(name, this.now().getTime() - started);
    }
  }

  snapshot(): MetricsSnapshot {
    const counters: Record<string, number> = {};
    // Every declared counter, including the zeroes — see the header.
    for (const name of COUNTERS) counters[name] = this.counters.get(name) ?? 0;

    const histograms: Record<string, HistogramSnapshot> = {};
    for (const name of HISTOGRAMS) {
      const entry = this.histograms.get(name);
      histograms[name] = {
        count: entry?.count ?? 0,
        sumMs: entry?.sumMs ?? 0,
        maxMs: entry?.maxMs ?? 0,
        buckets: [
          ...LATENCY_BUCKETS_MS.map((bound, index) => ({
            leMs: bound as number | null,
            count: entry?.buckets[index] ?? 0,
          })),
          { leMs: null, count: entry?.count ?? 0 },
        ],
      };
    }

    return { since: this.startedAt.toISOString(), counters, histograms };
  }

  reset(): void {
    this.counters.clear();
    this.histograms.clear();
    this.startedAt = this.now();
  }
}

/**
 * A percentile read off the buckets.
 *
 * Returns the bucket BOUND, not an interpolated value, and the caller is meant
 * to read it as "at or under this". Interpolating between bucket edges invents
 * precision the data does not have — the same objection as a fabricated metric,
 * in miniature.
 *
 * `null` means the percentile falls in the overflow bucket: more than the
 * largest bound, and the histogram genuinely cannot say how much more.
 */
export function percentile(snapshot: HistogramSnapshot, fraction: number): number | null {
  if (snapshot.count === 0) return 0;
  const target = Math.ceil(snapshot.count * fraction);
  for (const bucket of snapshot.buckets) {
    if (bucket.leMs !== null && bucket.count >= target) return bucket.leMs;
  }
  return null;
}

/** The application's metrics. Process-local; see the header. */
export const metrics = new Metrics();
