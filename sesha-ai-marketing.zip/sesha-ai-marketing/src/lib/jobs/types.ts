/**
 * Background jobs.
 *
 * Crawls and audits take minutes, so they cannot run inside a request. This is
 * the state machine the brief specifies, plus the three things that make a
 * long-running job usable: progress, cancellation and retry.
 *
 * WHY A STATE MACHINE RATHER THAN A BOOLEAN
 * "Running" and "failed" are not the interesting distinction. The one that
 * matters is between a job that failed for a reason worth retrying (the site
 * timed out) and one that will fail again (the URL is blocked) — so a failure
 * carries a code, and `isRetryable` is computed from it rather than guessed at by
 * the interface.
 *
 * TRANSITIONS ARE VALIDATED. A job cannot go from COMPLETED back to RUNNING, and
 * a CANCELLED job cannot quietly finish. `canTransition` is the single authority,
 * and the service layer asks it rather than re-deriving the rules.
 */

export const JOB_STATUSES = ['queued', 'running', 'completed', 'failed', 'cancelled'] as const;
export type JobStatus = (typeof JOB_STATUSES)[number];

export const JOB_KINDS = ['crawl', 'seo_audit', 'aeo_audit'] as const;
export type JobKind = (typeof JOB_KINDS)[number];

export function isJobStatus(value: unknown): value is JobStatus {
  return typeof value === 'string' && (JOB_STATUSES as readonly string[]).includes(value);
}

export function isJobKind(value: unknown): value is JobKind {
  return typeof value === 'string' && (JOB_KINDS as readonly string[]).includes(value);
}

/** A job in one of these states will never change again without a retry. */
export const TERMINAL_STATUSES: readonly JobStatus[] = ['completed', 'failed', 'cancelled'];

export function isTerminal(status: JobStatus): boolean {
  return TERMINAL_STATUSES.includes(status);
}

/**
 * The permitted transitions.
 *
 * `queued → cancelled` matters: a user who changes their mind before a worker
 * picks the job up must not have to wait for it to start.
 */
const TRANSITIONS: Record<JobStatus, readonly JobStatus[]> = {
  queued: ['running', 'cancelled', 'failed'],
  running: ['completed', 'failed', 'cancelled'],
  completed: [],
  failed: [],
  cancelled: [],
};

export function canTransition(from: JobStatus, to: JobStatus): boolean {
  return (TRANSITIONS[from] ?? []).includes(to);
}

export class JobTransitionError extends Error {
  readonly code = 'INVALID_TRANSITION' as const;
  constructor(from: JobStatus, to: JobStatus) {
    super(`A ${from} job cannot become ${to}.`);
    this.name = 'JobTransitionError';
  }
}

/* -------------------------------------------------------------------------- */
/* Progress                                                                   */
/* -------------------------------------------------------------------------- */

export interface JobProgress {
  /** 0–100, or null when the total is not yet known. */
  readonly percent: number | null;
  readonly done: number;
  readonly total: number | null;
  /** One short line for the interface. Never a stack trace. */
  readonly message: string;
}

export function progressOf(done: number, total: number | null, message: string): JobProgress {
  const percent = total !== null && total > 0
    ? Math.min(100, Math.round((done / total) * 100))
    : null;
  return { percent, done, total, message };
}

/* -------------------------------------------------------------------------- */
/* Failure classification                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Failures worth retrying: something outside our control went wrong and may not
 * go wrong again.
 */
const RETRYABLE_CODES: readonly string[] = [
  'timeout',
  'network_error',
  'dns_error',
  'robots_unavailable',
  'http_error',
  'worker_error',
  'rate_limited',
];

/**
 * Failures that will recur identically. Offering a retry here is worse than not
 * offering one: it invites the user to waste a minute discovering the same thing.
 */
const PERMANENT_CODES: readonly string[] = [
  'blocked',
  'invalid_url',
  'not_found',
  'no_consent',
  'consent_revoked',
  'quota_exceeded',
  'cancelled',
  'unsupported_type',
  'nothing_crawled',
];

export function isRetryable(code: string | null): boolean {
  if (!code) return false;
  if (PERMANENT_CODES.includes(code)) return false;
  return RETRYABLE_CODES.includes(code);
}

/** Plain-language explanation of a failure code, for the interface. */
export function explainFailure(code: string | null, detail?: string | null): string {
  const explanations: Record<string, string> = {
    timeout: 'The site took too long to respond.',
    network_error: 'The site could not be reached.',
    dns_error: 'That domain could not be looked up.',
    not_found: 'That domain does not exist.',
    blocked: 'That address cannot be crawled.',
    invalid_url: 'That is not a valid website address.',
    robots_unavailable: 'The site’s robots.txt could not be read, so the crawl did not start.',
    no_consent: 'Crawling has not been authorised for this project.',
    consent_revoked: 'Crawl permission was withdrawn before this job ran.',
    quota_exceeded: 'This organisation has used its crawl allowance for the period.',
    nothing_crawled: 'No page could be read, so there was nothing to audit.',
    cancelled: 'The job was cancelled.',
    worker_error: 'Something went wrong while running the job.',
    rate_limited: 'Too many jobs at once. Try again shortly.',
  };
  const base = (code && explanations[code]) ?? 'The job did not finish.';
  return detail ? `${base} ${detail}` : base;
}

/* -------------------------------------------------------------------------- */
/* Retry policy                                                               */
/* -------------------------------------------------------------------------- */

export const MAX_ATTEMPTS = 3;

export function canRetry(attempts: number, code: string | null): boolean {
  return attempts < MAX_ATTEMPTS && isRetryable(code);
}

/**
 * How long before a retry may run.
 *
 * Exponential with a long floor: the failures that are worth retrying are
 * usually a site being slow or briefly down, and retrying in two seconds just
 * reproduces the failure while adding load to a site that is already struggling.
 */
export function retryDelayMs(attempts: number): number {
  return Math.min(60_000 * 2 ** Math.max(0, attempts - 1), 15 * 60_000);
}

/** A job that has been RUNNING longer than this is presumed dead. */
export const STALE_RUNNING_MS = 30 * 60_000;

export function isStale(startedAt: Date | null, now: Date): boolean {
  if (!startedAt) return false;
  return now.getTime() - startedAt.getTime() > STALE_RUNNING_MS;
}
