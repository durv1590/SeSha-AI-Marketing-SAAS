/**
 * Scheduled maintenance: the housekeeping that must run whether or not anyone
 * is using the product.
 *
 * WHY THIS FILE EXISTS. Until Phase 8, `reapStaleJobs` and
 * `deleteExpiredCrawlData` were written, tested — and called by nothing. A
 * retention promise nobody enforces is a false statement in the privacy policy,
 * and a reaper nobody runs leaves dead jobs RUNNING forever. This is the one
 * entry point a scheduler (Vercel Cron, a Kubernetes CronJob, systemd timer)
 * calls, via `POST /api/internal/maintenance`.
 *
 * EACH TASK IS ISOLATED. One failing does not stop the others: a database error
 * while reaping jobs must not also skip the retention deletion.
 */

import { deleteExpiredCrawlData, reapStaleJobs, type CrawlServiceContext } from '@/lib/crawl/service';
import { tokensMatch } from '@/lib/auth/tokens';
import { log } from '@/lib/observability/log';

export interface MaintenanceReport {
  readonly ranAt: string;
  readonly jobs: { readonly requeued: number; readonly abandoned: number } | { readonly error: string };
  readonly retention: { readonly pagesDeleted: number } | { readonly error: string };
}

/** The minimum length for CRON_SECRET. Shorter is refused, not accepted weakly. */
export const MIN_CRON_SECRET_LENGTH = 32;

/**
 * True only for `Authorization: Bearer <CRON_SECRET>`, compared in constant
 * time. With no secret configured (or a short one) NOTHING is authorised —
 * there is no development fallback for an endpoint that deletes data.
 */
export function isMaintenanceAuthorized(header: string | null, secret: string | undefined): boolean {
  if (!secret || secret.length < MIN_CRON_SECRET_LENGTH) return false;
  if (!header || !header.startsWith('Bearer ')) return false;
  return tokensMatch(header.slice('Bearer '.length), secret);
}

function messageOf(error: unknown): string {
  // The class name only. An error message can carry a query or a row.
  return error instanceof Error ? error.name : 'UnknownError';
}

export async function runMaintenance(context: CrawlServiceContext): Promise<MaintenanceReport> {
  const ranAt = new Date(context.now?.() ?? Date.now()).toISOString();

  let jobs: MaintenanceReport['jobs'];
  try {
    jobs = await reapStaleJobs(context);
  } catch (error) {
    jobs = { error: messageOf(error) };
    log.error('maintenance: job recovery failed', { error: messageOf(error) });
  }

  let retention: MaintenanceReport['retention'];
  try {
    retention = { pagesDeleted: await deleteExpiredCrawlData(context) };
  } catch (error) {
    retention = { error: messageOf(error) };
    log.error('maintenance: retention deletion failed', { error: messageOf(error) });
  }

  log.info('maintenance ran', { jobs, retention });
  return { ranAt, jobs, retention };
}
