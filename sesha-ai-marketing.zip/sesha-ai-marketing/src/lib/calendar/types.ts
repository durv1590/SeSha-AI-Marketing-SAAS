/**
 * The marketing calendar.
 *
 * WHAT A CALENDAR ENTRY IS, AND IS NOT
 * An entry here is a PLAN — something a person intends to do on a date. It is not
 * a scheduled job, and nothing on this calendar fires. SeSha cannot publish a
 * social post, send an email or start an ad campaign (Phases 3 and 5), so a
 * calendar that implied a date would make something happen would be the same lie
 * in a new place.
 *
 * `status` says exactly where an entry stands: planned, done, or skipped. There
 * is deliberately no `scheduled` or `published` state.
 *
 * THE AI RECOMMENDATIONS ARE A SEPARATE TYPE
 * The brief asks for suggestions on empty dates. A suggestion rendered as an entry
 * would become, within a week, something a user believes they planned. So
 * `Suggestion` is its own type with its own reason, it is never stored as an
 * entry, and accepting one is an explicit act that creates a real entry with the
 * suggestion recorded as its origin.
 *
 * Framework-free and fully unit tested.
 */

/** The ten event kinds the brief names. */
export const EVENT_KINDS = [
  'social',
  'blog',
  'email',
  'ads',
  'offer',
  'event',
  'website_update',
  'seo_task',
  'aeo_task',
  'schema_task',
] as const;

export type EventKind = (typeof EVENT_KINDS)[number];

export const EVENT_LABEL: Readonly<Record<EventKind, string>> = {
  social: 'Social post',
  blog: 'Blog or article',
  email: 'Email',
  ads: 'Advertising',
  offer: 'Offer or promotion',
  event: 'Event',
  website_update: 'Website update',
  seo_task: 'SEO task',
  aeo_task: 'AEO task',
  schema_task: 'Schema task',
};

/**
 * Which kinds SeSha can derive from work already in the product, rather than
 * only from something a person typed. A derived entry links back to the record it
 * came from, so the calendar and the workspace cannot disagree.
 */
export const DERIVABLE_KINDS: readonly EventKind[] = [
  'social',
  'blog',
  'email',
  'ads',
  'seo_task',
  'aeo_task',
  'schema_task',
];

export type EventStatus = 'planned' | 'done' | 'skipped';

export const STATUS_LABEL: Readonly<Record<EventStatus, string>> = {
  planned: 'Planned',
  done: 'Done',
  skipped: 'Skipped',
};

/**
 * Where an entry came from.
 *
 * `derived` entries mirror a record elsewhere in SeSha — a drafted social post,
 * an audit finding that became a task. `accepted_suggestion` records that a person
 * accepted an AI recommendation, which is different from having thought of it
 * themselves and is worth keeping straight.
 */
export type EventOrigin = 'manual' | 'derived' | 'accepted_suggestion';

export const ORIGIN_LABEL: Readonly<Record<EventOrigin, string>> = {
  manual: 'Added by you',
  derived: 'From your workspace',
  accepted_suggestion: 'Suggested by SeSha, accepted by you',
};

export interface CalendarEvent {
  readonly id: string;
  readonly kind: EventKind;
  readonly title: string;
  readonly notes: string;
  /** The date it is planned for, as YYYY-MM-DD. Calendars are date-based. */
  readonly date: string;
  readonly status: EventStatus;
  readonly origin: EventOrigin;
  /** For a derived entry: what it mirrors. */
  readonly sourceKind?: 'content' | 'social_post' | 'ad_plan' | 'messaging_plan' | 'audit_finding' | 'schema_validation';
  readonly sourceId?: string;
  /** Groups entries into a campaign for the campaign view. */
  readonly campaign?: string;
}

/* -------------------------------------------------------------------------- */
/* Views                                                                      */
/* -------------------------------------------------------------------------- */

export const CALENDAR_VIEWS = ['daily', 'weekly', 'monthly', 'campaign'] as const;
export type CalendarView = (typeof CALENDAR_VIEWS)[number];

export const VIEW_LABEL: Readonly<Record<CalendarView, string>> = {
  daily: 'Day',
  weekly: 'Week',
  monthly: 'Month',
  campaign: 'Campaign',
};

export function isCalendarView(value: unknown): value is CalendarView {
  return typeof value === 'string' && (CALENDAR_VIEWS as readonly string[]).includes(value);
}

export function isEventKind(value: unknown): value is EventKind {
  return typeof value === 'string' && (EVENT_KINDS as readonly string[]).includes(value);
}

export interface DateRange {
  readonly from: string;
  readonly to: string;
}

/** A date as YYYY-MM-DD in UTC. Calendars are date-based, not instant-based. */
export function toDateKey(date: Date): string {
  return date.toISOString().slice(0, 10);
}

export function parseDateKey(key: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(key)) return null;
  const parsed = new Date(`${key}T00:00:00.000Z`);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

export function addDays(key: string, days: number): string {
  const parsed = parseDateKey(key);
  if (!parsed) return key;
  return toDateKey(new Date(parsed.getTime() + days * 86_400_000));
}

/**
 * The range a view covers.
 *
 * The week starts on Monday, which is how work weeks are planned in this market
 * and most others; a Sunday-first calendar puts the weekend in the middle of the
 * working week.
 */
export function rangeFor(view: CalendarView, anchor: string): DateRange {
  const date = parseDateKey(anchor) ?? new Date();
  switch (view) {
    case 'daily':
      return { from: toDateKey(date), to: toDateKey(date) };
    case 'weekly': {
      const day = date.getUTCDay();
      const offsetToMonday = day === 0 ? -6 : 1 - day;
      const monday = new Date(date.getTime() + offsetToMonday * 86_400_000);
      return { from: toDateKey(monday), to: toDateKey(new Date(monday.getTime() + 6 * 86_400_000)) };
    }
    case 'monthly': {
      const first = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), 1));
      const last = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth() + 1, 0));
      return { from: toDateKey(first), to: toDateKey(last) };
    }
    case 'campaign':
      // A campaign view is not bounded by the calendar grid: it shows a campaign
      // wherever its entries fall. The range is wide and the grouping does the work.
      return { from: toDateKey(new Date(date.getTime() - 90 * 86_400_000)), to: toDateKey(new Date(date.getTime() + 90 * 86_400_000)) };
  }
}

export function datesInRange(range: DateRange): string[] {
  const from = parseDateKey(range.from);
  const to = parseDateKey(range.to);
  if (!from || !to || to.getTime() < from.getTime()) return [];
  const dates: string[] = [];
  for (let time = from.getTime(); time <= to.getTime(); time += 86_400_000) {
    dates.push(toDateKey(new Date(time)));
  }
  return dates;
}

export function inRange(date: string, range: DateRange): boolean {
  return date >= range.from && date <= range.to;
}

/** Entries grouped by date, including the empty days. */
export function groupByDate(
  events: readonly CalendarEvent[],
  range: DateRange,
): readonly { readonly date: string; readonly events: readonly CalendarEvent[] }[] {
  return datesInRange(range).map((date) => ({
    date,
    events: events.filter((event) => event.date === date),
  }));
}

/** Entries grouped by campaign. Entries with no campaign are grouped separately. */
export function groupByCampaign(
  events: readonly CalendarEvent[],
): readonly { readonly campaign: string | null; readonly events: readonly CalendarEvent[] }[] {
  const groups = new Map<string | null, CalendarEvent[]>();
  for (const event of events) {
    const key = event.campaign?.trim() || null;
    const existing = groups.get(key);
    if (existing) existing.push(event);
    else groups.set(key, [event]);
  }
  return [...groups.entries()]
    .map(([campaign, grouped]) => ({
      campaign,
      events: [...grouped].sort((a, b) => a.date.localeCompare(b.date)),
    }))
    // Named campaigns first, then the loose entries.
    .sort((a, b) => {
      if (a.campaign === null) return 1;
      if (b.campaign === null) return -1;
      return a.campaign.localeCompare(b.campaign);
    });
}

/* -------------------------------------------------------------------------- */
/* Suggestions                                                                */
/* -------------------------------------------------------------------------- */

/**
 * A recommendation for an empty date.
 *
 * A separate type from `CalendarEvent` on purpose. A suggestion rendered as an
 * entry becomes, in a week, something the user believes they planned — and then a
 * report counts it as work done. Accepting one is an explicit act.
 */
export interface Suggestion {
  readonly date: string;
  readonly kind: EventKind;
  readonly title: string;
  /** Why this, on this date. Never "because the date is empty". */
  readonly why: string;
  /** What it was derived from, so the reasoning is checkable. */
  readonly basedOn: readonly string[];
}

export interface SuggestionInput {
  readonly range: DateRange;
  readonly events: readonly CalendarEvent[];
  /** Channels the customer said they use, from the marketing profile. */
  readonly channels: readonly string[];
  /** Open technical tasks that have no date yet. */
  readonly openTasks: readonly { readonly kind: EventKind; readonly title: string; readonly why: string }[];
  /** How many days in a row may be left empty before it is worth suggesting. */
  readonly gapDays?: number;
}

/**
 * Suggests activities for empty dates.
 *
 * TWO RULES THAT KEEP THIS HONEST
 *
 * 1. A suggestion must have a REASON specific to this customer — an open SEO
 *    finding, a channel they said they use, a gap longer than their own rhythm.
 *    "Post something on Tuesday" is filler, and filler trains people to ignore the
 *    calendar.
 * 2. Real work comes first. An open schema error that needs fixing is a better
 *    suggestion than an invented blog post, so the open tasks are placed before
 *    anything is generated from a channel preference.
 */
export function suggestForEmptyDates(input: SuggestionInput): readonly Suggestion[] {
  const gapDays = input.gapDays ?? 2;
  const dates = datesInRange(input.range);
  const busy = new Set(input.events.map((event) => event.date));

  // A date is a candidate only if it, and the `gapDays` before it, are empty.
  const candidates = dates.filter((date) => {
    if (busy.has(date)) return false;
    for (let back = 1; back <= gapDays; back += 1) {
      if (busy.has(addDays(date, -back))) return false;
    }
    return true;
  });

  if (candidates.length === 0) return [];

  const suggestions: Suggestion[] = [];
  const tasks = [...input.openTasks];

  for (const date of candidates) {
    // Real outstanding work first.
    const task = tasks.shift();
    if (task) {
      suggestions.push({
        date,
        kind: task.kind,
        title: task.title,
        why: task.why,
        basedOn: ['An open finding in your own audits or validations.'],
      });
      continue;
    }

    // Then, only where the customer said they use the channel.
    const channel = channelSuggestion(input.channels, suggestions.length);
    if (!channel) break;
    suggestions.push({
      date,
      kind: channel.kind,
      title: channel.title,
      why: channel.why,
      basedOn: [`You listed ${channel.channelLabel} as a channel you use during onboarding.`],
    });
  }

  return suggestions;
}

/**
 * A suggestion derived from a channel the customer actually said they use.
 *
 * Returns null when they listed none — in which case nothing is suggested at all,
 * which is the honest outcome. A tool that suggests Instagram to a business that
 * never mentioned Instagram is guessing.
 */
function channelSuggestion(
  channels: readonly string[],
  index: number,
): { readonly kind: EventKind; readonly title: string; readonly why: string; readonly channelLabel: string } | null {
  const mapped = channels
    .map((channel) => CHANNEL_SUGGESTIONS[normaliseChannel(channel)])
    .filter((entry): entry is ChannelSuggestion => entry !== undefined);
  if (mapped.length === 0) return null;
  const chosen = mapped[index % mapped.length]!;
  return {
    kind: chosen.kind,
    title: chosen.title,
    why: chosen.why,
    channelLabel: chosen.label,
  };
}

interface ChannelSuggestion {
  readonly label: string;
  readonly kind: EventKind;
  readonly title: string;
  readonly why: string;
}

function normaliseChannel(channel: string): string {
  return channel.trim().toLowerCase().replace(/[\s_]+/g, '-');
}

const CHANNEL_SUGGESTIONS: Readonly<Record<string, ChannelSuggestion>> = {
  'organic-search': {
    label: 'organic search',
    kind: 'blog',
    title: 'Write one page answering a question customers ask',
    why: 'You rely on organic search, and a page that answers a real question is what gets found and quoted.',
  },
  'social-organic': {
    label: 'organic social',
    kind: 'social',
    title: 'Draft a post about something that happened this week',
    why: 'You listed organic social as a channel, and a gap of several days is where a feed goes quiet.',
  },
  email: {
    label: 'email',
    kind: 'email',
    title: 'Draft a short update for people who opted in',
    why: 'You listed email as a channel, and there is nothing planned for this stretch.',
  },
  'paid-ads': {
    label: 'paid advertising',
    kind: 'ads',
    title: 'Review the plan for your running campaign',
    why: 'You listed paid advertising as a channel. Reviewing beats launching more.',
  },
  whatsapp: {
    label: 'WhatsApp',
    kind: 'email',
    title: 'Draft a WhatsApp template for customers who opted in',
    why: 'You listed WhatsApp as a channel, and templates need approval before they are useful.',
  },
  'foot-traffic': {
    label: 'walk-in trade',
    kind: 'offer',
    title: 'Plan one offer for the quietest day of the week',
    why: 'You said walk-in trade matters, and a quiet weekday is where an offer earns its keep.',
  },
};

/** The channels a suggestion can be built from. Useful to the interface. */
export const SUGGESTIBLE_CHANNELS: readonly string[] = Object.keys(CHANNEL_SUGGESTIONS);
