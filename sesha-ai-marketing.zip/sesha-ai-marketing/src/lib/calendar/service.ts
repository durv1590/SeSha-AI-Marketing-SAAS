/**
 * Marketing calendar service.
 *
 * WHAT A DERIVED ENTRY IS, AND WHY IT IS NOT A COPY
 * Content, ad plans and messaging plans already exist in SeSha. Showing them
 * on the calendar means mirroring them as entries with `origin: 'derived'` and a
 * pointer back to the record. The alternative — copying the title into a new
 * manual entry — produces two things that drift apart, and the calendar becomes
 * the one nobody trusts.
 *
 * `deriveEntries` is idempotent for that reason: it will not create a second
 * entry for a source record it has already mirrored.
 *
 * SUGGESTIONS ARE NEVER STORED
 * `suggestFor` returns them; nothing writes them. A suggestion is stored only
 * when a person accepts it, and then it is marked `accepted_suggestion` so the
 * record of whose idea it was survives.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { assertTenant, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { CalendarEventRow } from '@/lib/db/types';

import {
  isEventKind,
  rangeFor,
  suggestForEmptyDates,
  toDateKey,
  type CalendarEvent,
  type CalendarView,
  type EventKind,
  type EventStatus,
  type Suggestion,
} from './types';

export interface CalendarServiceContext {
  readonly db: Database;
  readonly now?: () => Date;
}

function clock(context: CalendarServiceContext): Date {
  return context.now?.() ?? new Date();
}

export class CalendarInputError extends Error {
  readonly code = 'INVALID_INPUT' as const;
  constructor(message: string) {
    super(message);
    this.name = 'CalendarInputError';
  }
}

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

/** Converts a stored row into the domain shape the view functions use. */
export function toEvent(row: CalendarEventRow): CalendarEvent {
  return {
    id: row.id,
    kind: isEventKind(row.kind) ? row.kind : 'event',
    title: row.title,
    notes: row.notes,
    date: row.eventDate,
    status: row.status,
    origin: row.origin,
    ...(row.sourceKind ? { sourceKind: row.sourceKind as NonNullable<CalendarEvent['sourceKind']> } : {}),
    ...(row.sourceId ? { sourceId: row.sourceId } : {}),
    ...(row.campaign ? { campaign: row.campaign } : {}),
  };
}

export interface CreateEventInput {
  readonly kind: EventKind;
  readonly title: string;
  readonly notes?: string;
  readonly date: string;
  readonly campaign?: string;
  readonly status?: EventStatus;
  /** Set when the user accepted a suggestion rather than writing this themselves. */
  readonly fromSuggestion?: boolean;
}

export async function createEvent(
  context: CalendarServiceContext,
  tenant: TenantContext,
  projectId: string,
  input: CreateEventInput,
): Promise<CalendarEventRow> {
  requirePermission(tenant.role, 'campaign:manage');
  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  assertTenant(tenant, project, 'Project');

  const title = input.title.trim();
  if (title.length === 0) throw new CalendarInputError('An entry needs a title.');
  if (title.length > 200) throw new CalendarInputError('A title is at most 200 characters.');
  if (!DATE_PATTERN.test(input.date)) {
    throw new CalendarInputError('A date must be written as YYYY-MM-DD.');
  }
  if (!isEventKind(input.kind)) throw new CalendarInputError('That is not a kind of entry SeSha has.');

  return context.db.calendar.create({
    organizationId: tenant.organizationId,
    projectId,
    kind: input.kind,
    title,
    notes: input.notes?.trim() ?? '',
    eventDate: input.date,
    status: input.status ?? 'planned',
    origin: input.fromSuggestion ? 'accepted_suggestion' : 'manual',
    sourceKind: null,
    sourceId: null,
    campaign: input.campaign?.trim() || null,
    createdBy: tenant.userId,
  });
}

export async function updateEvent(
  context: CalendarServiceContext,
  tenant: TenantContext,
  id: string,
  patch: { readonly title?: string; readonly notes?: string; readonly date?: string; readonly status?: EventStatus; readonly campaign?: string | null },
): Promise<CalendarEventRow> {
  requirePermission(tenant.role, 'campaign:manage');
  const existing = await context.db.calendar.findById(tenant.organizationId, id);
  assertTenant(tenant, existing, 'Calendar entry');

  if (patch.date !== undefined && !DATE_PATTERN.test(patch.date)) {
    throw new CalendarInputError('A date must be written as YYYY-MM-DD.');
  }
  if (patch.title !== undefined && patch.title.trim().length === 0) {
    throw new CalendarInputError('An entry needs a title.');
  }

  const updated = await context.db.calendar.update(tenant.organizationId, id, {
    ...(patch.title === undefined ? {} : { title: patch.title.trim() }),
    ...(patch.notes === undefined ? {} : { notes: patch.notes.trim() }),
    ...(patch.date === undefined ? {} : { eventDate: patch.date }),
    ...(patch.status === undefined ? {} : { status: patch.status }),
    ...(patch.campaign === undefined ? {} : { campaign: patch.campaign?.trim() || null }),
  });
  return assertTenant(tenant, updated, 'Calendar entry');
}

export async function removeEvent(
  context: CalendarServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<void> {
  requirePermission(tenant.role, 'campaign:manage');
  const existing = await context.db.calendar.findById(tenant.organizationId, id);
  assertTenant(tenant, existing, 'Calendar entry');
  await context.db.calendar.remove(tenant.organizationId, id);
}

/* -------------------------------------------------------------------------- */
/* Views                                                                      */
/* -------------------------------------------------------------------------- */

export interface CalendarViewResult {
  readonly view: CalendarView;
  readonly anchor: string;
  readonly range: { readonly from: string; readonly to: string };
  readonly events: readonly CalendarEvent[];
  readonly suggestions: readonly Suggestion[];
}

export async function calendarView(
  context: CalendarServiceContext,
  tenant: TenantContext,
  projectId: string,
  view: CalendarView,
  anchor?: string,
): Promise<CalendarViewResult> {
  requirePermission(tenant.role, 'campaign:read');
  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  assertTenant(tenant, project, 'Project');

  const at = anchor && DATE_PATTERN.test(anchor) ? anchor : toDateKey(clock(context));

  if (view === 'campaign') {
    // The campaign view is not a date window: it groups every entry that carries
    // a campaign, however far apart the dates are. Clipping it to a month would
    // hide the start of anything that ran across a boundary.
    const rows = await context.db.calendar.listInRange(tenant.organizationId, projectId, '0000-01-01', '9999-12-31');
    const events = rows.filter((row) => row.campaign !== null).map(toEvent);
    return { view, anchor: at, range: { from: '0000-01-01', to: '9999-12-31' }, events, suggestions: [] };
  }

  const range = rangeFor(view, at);
  const rows = await context.db.calendar.listInRange(tenant.organizationId, projectId, range.from, range.to);
  const events = rows.map(toEvent);
  const suggestions = await suggestFor(context, tenant, projectId, view, at, events);

  return { view, anchor: at, range: { from: range.from, to: range.to }, events, suggestions };
}

/**
 * Suggestions for empty dates.
 *
 * Built from the customer's OWN records: the channels they listed at onboarding
 * and the open findings from their own audits and validations. When they listed
 * no channels and have no open findings, nothing is suggested — which is the
 * honest outcome, and better than filler that trains people to ignore the page.
 */
export async function suggestFor(
  context: CalendarServiceContext,
  tenant: TenantContext,
  projectId: string,
  view: CalendarView,
  anchor: string,
  events: readonly CalendarEvent[],
): Promise<readonly Suggestion[]> {
  if (view === 'campaign') return [];

  const profile = await context.db.marketingProfiles.findByProject(tenant.organizationId, projectId);
  const channels = profile?.marketingChannels ?? [];

  const openTasks = await openTechnicalTasks(context, tenant, projectId);

  return suggestForEmptyDates({
    range: rangeFor(view, anchor),
    events,
    channels: [...channels],
    openTasks,
  });
}

/**
 * Real outstanding work, derived from the last audit and the last validation.
 *
 * These go in front of anything generated from a channel preference: an SEO
 * finding that is actually open is a better use of a Tuesday than an invented
 * blog post, and it is checkable.
 */
async function openTechnicalTasks(
  context: CalendarServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<readonly { readonly kind: EventKind; readonly title: string; readonly why: string }[]> {
  const tasks: { kind: EventKind; title: string; why: string }[] = [];

  const seo = await context.db.audits.findLatest(tenant.organizationId, projectId, 'seo');
  if (seo && seo.findings.length > 0) {
    tasks.push({
      kind: 'seo_task',
      title: `Work through the SEO findings from your last audit (${seo.findings.length})`,
      why: `Your last SEO audit scored ${seo.score} and left ${seo.findings.length} findings. These are pages you already have.`,
    });
  }

  const aeo = await context.db.audits.findLatest(tenant.organizationId, projectId, 'aeo');
  if (aeo && aeo.findings.length > 0) {
    tasks.push({
      kind: 'aeo_task',
      title: 'Make one page easier for an answer engine to quote',
      why: `Your last AEO audit left ${aeo.findings.length} findings. Answering one question directly on a page is the smallest useful fix.`,
    });
  }

  const [validation] = await context.db.schemaValidations.listForProject(tenant.organizationId, projectId, 1);
  const invalid = validation?.counts.INVALID ?? 0;
  if (invalid > 0) {
    tasks.push({
      kind: 'schema_task',
      title: `Fix ${invalid} structured-data error${invalid === 1 ? '' : 's'}`,
      why: 'Your most recent validation found markup that search engines will reject. This is a fix with a definite end.',
    });
  }

  return tasks;
}

/* -------------------------------------------------------------------------- */
/* Derived entries                                                            */
/* -------------------------------------------------------------------------- */

/**
 * Mirrors real records onto the calendar.
 *
 * Idempotent: a source record already mirrored is skipped, so running this on
 * every page load does not fill the calendar with duplicates. Returns how many
 * were created, which is what the caller reports.
 */
export async function deriveEntries(
  context: CalendarServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<number> {
  requirePermission(tenant.role, 'campaign:manage');
  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  assertTenant(tenant, project, 'Project');

  let created = 0;

  const socialPosts = await context.db.socialPosts.listForProject(tenant.organizationId, projectId);
  for (const post of socialPosts) {
    // A post with no planned date has no place on a calendar; SeSha cannot
    // schedule one, so there is nothing to infer from its absence.
    if (!post.plannedFor) continue;
    const existing = await context.db.calendar.findBySource(tenant.organizationId, 'social_post', post.id);
    if (existing) continue;
    await context.db.calendar.create({
      organizationId: tenant.organizationId,
      projectId,
      kind: 'social',
      title: post.platform ? `${post.platform}: ${firstLine(post.caption)}` : firstLine(post.caption),
      notes: 'Mirrored from Social Studio. Nothing is published automatically.',
      // `plannedFor` is already a YYYY-MM-DD date, not an instant: Social Studio
      // plans a day, it does not schedule a moment.
      eventDate: post.plannedFor,
      status: 'planned',
      origin: 'derived',
      sourceKind: 'social_post',
      sourceId: post.id,
      campaign: null,
      createdBy: null,
    });
    created += 1;
  }

  return created;
}

function firstLine(text: string): string {
  const line = text.split('\n')[0]?.trim() ?? '';
  return line.length <= 120 ? line || 'Post' : `${line.slice(0, 117)}...`;
}
