/**
 * Workspace context assembly.
 *
 * This is what turns a generic model into one that knows the user's business.
 * It gathers the selected business, project, marketing profile and brand kit
 * and renders them into a prompt section.
 *
 * TWO PROPERTIES THAT MATTER MORE THAN THE PROMPT WORDING:
 *
 * 1. EVERY VALUE IS TENANT-SCOPED. The context is built from repositories that
 *    take an organization id, so a prompt cannot be assembled from another
 *    customer's data. `tests/ai-context.test.ts` asserts it across two real
 *    organizations.
 *
 * 2. WHAT IS ABSENT IS STATED AS ABSENT. Missing fields are listed explicitly
 *    under "NOT AVAILABLE", so the model is told what it does not know instead
 *    of being left to fill the gap. This is the input side of the provenance
 *    contract: `user_provided` is only legitimate for values that appear here.
 *
 * Framework-free and fully unit tested.
 */

import { estimateTokens } from './provider';
import type { TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { BrandKitRow, BusinessRow, MarketingProfileRow, ProjectRow } from '@/lib/db/types';

export interface WorkspaceContext {
  readonly organizationId: string;
  readonly project: ProjectRow | null;
  readonly business: BusinessRow | null;
  readonly profile: MarketingProfileRow | null;
  readonly brandKit: BrandKitRow | null;
  /** Field paths the model must treat as unknown. */
  readonly missing: readonly string[];
}

/**
 * Loads context for a project.
 *
 * Every lookup passes `organizationId`, so there is no code path that could
 * read another tenant's row even if a caller supplied a foreign project id —
 * it simply returns null, and the context says the project is unavailable.
 */
export async function loadWorkspaceContext(
  db: Database,
  tenant: TenantContext,
  projectId: string | null,
): Promise<WorkspaceContext> {
  const project = projectId
    ? await db.projects.findById(tenant.organizationId, projectId)
    : null;

  const business = project?.businessId
    ? await db.businesses.findById(tenant.organizationId, project.businessId)
    : null;

  const profile = project
    ? await db.marketingProfiles.findByProject(tenant.organizationId, project.id)
    : null;

  const brandKit = project
    ? await db.brandKits.findByProject(tenant.organizationId, project.id)
    : null;

  return {
    organizationId: tenant.organizationId,
    project,
    business,
    profile,
    brandKit,
    missing: findMissing({ project, business, profile, brandKit }),
  };
}

function findMissing(context: {
  project: ProjectRow | null;
  business: BusinessRow | null;
  profile: MarketingProfileRow | null;
  brandKit: BrandKitRow | null;
}): string[] {
  const missing: string[] = [];

  if (!context.project) missing.push('project');
  if (!context.business) missing.push('business details');
  else {
    if (!context.business.industry) missing.push('industry');
    if (!context.business.country) missing.push('country');
    if (!context.business.websiteUrl) missing.push('website');
  }

  if (!context.profile) {
    missing.push('marketing profile (audience, offering, goals, channels, voice)');
  } else {
    if (!context.profile.targetAudience) missing.push('target audience');
    if (!context.profile.productsServices) missing.push('products and services');
    if (!context.profile.priceRange) missing.push('price range');
    if (context.profile.marketingGoals.length === 0) missing.push('marketing goals');
    if (context.profile.marketingChannels.length === 0) missing.push('marketing channels');
    if (context.profile.competitors.length === 0) missing.push('competitors');
  }

  // Things no deployment has yet. Saying so keeps the model from assuming it
  // has performance data to reason about.
  missing.push('website content (no crawl has run)');
  missing.push('analytics data (no analytics source is connected)');
  missing.push('advertising performance data (no ad account is connected)');
  missing.push('historical content performance');

  return missing;
}

/* -------------------------------------------------------------------------- */
/* Rendering                                                                  */
/* -------------------------------------------------------------------------- */

export interface RenderOptions {
  /** Drop the lowest-value sections if the context exceeds this. */
  readonly maxTokens?: number;
}

/**
 * Renders context into the prompt.
 *
 * Format is deliberately plain and labelled rather than JSON: a model follows
 * "AUDIENCE: ..." more reliably than a nested object, and a human reading the
 * audit log can see exactly what was sent.
 */
export function renderContext(context: WorkspaceContext, options: RenderOptions = {}): string {
  const sections: { readonly priority: number; readonly text: string }[] = [];

  if (context.business) {
    const b = context.business;
    sections.push({
      priority: 1,
      text: [
        'BUSINESS',
        `Name: ${b.name}`,
        b.industry ? `Industry: ${humanize(b.industry)}` : null,
        b.city || b.country ? `Location: ${[b.city, b.country].filter(Boolean).join(', ')}` : null,
        b.websiteUrl ? `Website: ${b.websiteUrl}` : null,
      ]
        .filter(Boolean)
        .join('\n'),
    });
  }

  if (context.project) {
    sections.push({
      priority: 1,
      text: [
        'PROJECT',
        `Name: ${context.project.name}`,
        context.project.description ? `Description: ${context.project.description}` : null,
      ]
        .filter(Boolean)
        .join('\n'),
    });
  }

  if (context.profile) {
    const p = context.profile;
    sections.push({
      priority: 1,
      text: [
        'MARKETING PROFILE',
        p.targetAudience ? `Target audience: ${p.targetAudience}` : null,
        p.productsServices ? `Products and services: ${p.productsServices}` : null,
        p.priceRange ? `Price positioning: ${humanize(p.priceRange)}` : null,
        p.marketingGoals.length > 0
          ? `Goals: ${p.marketingGoals.map(humanize).join(', ')}`
          : null,
        p.marketingChannels.length > 0
          ? `Channels in use: ${p.marketingChannels.map(humanize).join(', ')}`
          : null,
      ]
        .filter(Boolean)
        .join('\n'),
    });

    const voice = p.brandVoice as { tones?: string[]; notes?: string };
    if ((voice.tones?.length ?? 0) > 0 || voice.notes) {
      sections.push({
        priority: 1,
        text: [
          'BRAND VOICE',
          voice.tones?.length ? `Tone: ${voice.tones.map(humanize).join(', ')}` : null,
          voice.notes ? `Notes: ${voice.notes}` : null,
        ]
          .filter(Boolean)
          .join('\n'),
      });
    }

    if (p.competitors.length > 0) {
      sections.push({
        priority: 3,
        text: [
          'COMPETITORS NAMED BY THE USER',
          ...p.competitors.map((c) => `- ${c.name}${c.url ? ` (${c.url})` : ''}`),
          'You know nothing about these companies beyond their names. Do not describe',
          'their products, pricing, size or performance.',
        ].join('\n'),
      });
    }
  }

  if (context.brandKit) {
    const kit = context.brandKit;
    const terminology = kit.terminology as Record<string, unknown>;
    if (kit.voice || kit.toneRules || Object.keys(terminology).length > 0) {
      sections.push({
        priority: 2,
        text: [
          'BRAND KIT',
          kit.voice ? `Voice: ${kit.voice}` : null,
          kit.toneRules ? `Tone rules: ${kit.toneRules}` : null,
          Object.keys(terminology).length > 0
            ? `Terminology: ${JSON.stringify(terminology)}`
            : null,
        ]
          .filter(Boolean)
          .join('\n'),
      });
    }
  }

  // Always last, always included: the gaps.
  sections.push({
    priority: 0,
    text: [
      'NOT AVAILABLE — you do not have this information:',
      ...context.missing.map((item) => `- ${item}`),
      '',
      'Do not invent any of the above. If a task needs one of them, return an',
      '"unavailable" block saying what is needed.',
    ].join('\n'),
  });

  const ordered = [...sections].sort((a, b) => a.priority - b.priority);
  let rendered = ordered.map((section) => section.text).join('\n\n');

  // Trim low-priority sections if the context is over budget. The gaps list
  // (priority 0) and the core profile (priority 1) are never dropped.
  const budget = options.maxTokens;
  if (budget && estimateTokens(rendered) > budget) {
    const essential = ordered.filter((section) => section.priority <= 1);
    rendered = essential.map((section) => section.text).join('\n\n');
  }

  return rendered;
}

function humanize(value: string): string {
  return value.replace(/[-_]/g, ' ');
}

/** True when there is enough context for grounded output. */
export function isUsable(context: WorkspaceContext): boolean {
  return Boolean(context.project && context.profile?.targetAudience);
}

/**
 * What the interface shows above the composer, so the user can see what the
 * copilot knows before they ask it anything.
 */
export interface ContextSummary {
  readonly projectName: string | null;
  readonly businessName: string | null;
  readonly completeness: number;
  readonly present: readonly string[];
  readonly missing: readonly string[];
}

export function summarizeContext(context: WorkspaceContext): ContextSummary {
  const present: string[] = [];
  if (context.business) present.push('Business details');
  if (context.project) present.push('Project');
  if (context.profile?.targetAudience) present.push('Target audience');
  if (context.profile?.productsServices) present.push('Products and services');
  if ((context.profile?.marketingGoals.length ?? 0) > 0) present.push('Marketing goals');
  if ((context.profile?.marketingChannels.length ?? 0) > 0) present.push('Channels');
  if (((context.profile?.brandVoice as { tones?: string[] })?.tones?.length ?? 0) > 0) {
    present.push('Brand voice');
  }
  if ((context.profile?.competitors.length ?? 0) > 0) present.push('Competitors');

  return {
    projectName: context.project?.name ?? null,
    businessName: context.business?.name ?? null,
    completeness: context.profile?.completeness ?? 0,
    present,
    missing: context.missing,
  };
}

/** Source references recorded on every generated message, for provenance. */
export function contextSources(
  context: WorkspaceContext,
): { type: string; id: string }[] {
  const sources: { type: string; id: string }[] = [];
  if (context.project) sources.push({ type: 'project', id: context.project.id });
  if (context.business) sources.push({ type: 'business', id: context.business.id });
  if (context.profile) sources.push({ type: 'marketing_profile', id: context.profile.id });
  if (context.brandKit) sources.push({ type: 'brand_kit', id: context.brandKit.id });
  return sources;
}
