/**
 * AI provider abstraction.
 *
 * One interface, three adapters: OpenAI, Anthropic and Gemini. Everything above
 * this file is provider-agnostic, so switching provider is configuration rather
 * than a rewrite, and a provider outage is a failover rather than an incident.
 *
 * API KEYS NEVER REACH THE BROWSER. They are read from `process.env` inside
 * these adapters, which only ever run on the server:
 *   · the adapters are imported by the orchestrator, which is imported by API
 *     route handlers — never by a client component;
 *   · `tests/ai-security.test.ts` asserts no client component reaches this
 *     module, and `scripts/verify-static.mjs` fails the build if one does;
 *   · nothing here is prefixed NEXT_PUBLIC_, so Next.js would not inline it
 *     into client bundles even by accident.
 *
 * `fetch` is injected on every call so the adapters are fully testable without
 * network access or credentials.
 */

export const PROVIDERS = ['openai', 'anthropic', 'gemini'] as const;
export type ProviderName = (typeof PROVIDERS)[number];

export function isProviderName(value: unknown): value is ProviderName {
  return typeof value === 'string' && (PROVIDERS as readonly string[]).includes(value);
}

/* -------------------------------------------------------------------------- */
/* Request and response                                                       */
/* -------------------------------------------------------------------------- */

export type MessageRole = 'system' | 'user' | 'assistant';

export interface AiMessage {
  readonly role: MessageRole;
  readonly content: string;
}

export interface CompletionRequest {
  readonly system: string;
  readonly messages: readonly AiMessage[];
  readonly maxOutputTokens: number;
  /** 0 = deterministic, 1 = loose. Mapped per provider. */
  readonly temperature: number;
  /** Hard ceiling for the whole call, enforced by the caller's AbortSignal. */
  readonly timeoutMs: number;
  /** Ask the provider for JSON when it supports a JSON mode. */
  readonly json?: boolean;
}

export interface TokenUsage {
  readonly inputTokens: number;
  readonly outputTokens: number;
}

export interface CompletionResult {
  readonly text: string;
  readonly usage: TokenUsage;
  readonly model: string;
  readonly provider: ProviderName;
  /** True when the provider stopped because it hit the output limit. */
  readonly truncated: boolean;
}

export type AiErrorCode =
  | 'not_configured'
  | 'unauthorized'
  | 'rate_limited'
  | 'context_too_long'
  | 'content_filtered'
  | 'timeout'
  | 'unavailable'
  | 'bad_response'
  | 'unknown';

export class AiError extends Error {
  readonly code: AiErrorCode;
  readonly provider: ProviderName | null;
  /** Whether trying again, possibly on another provider, could work. */
  readonly retryable: boolean;
  readonly retryAfterSeconds?: number;

  constructor(
    code: AiErrorCode,
    message: string,
    options: { provider?: ProviderName; retryable?: boolean; retryAfterSeconds?: number } = {},
  ) {
    super(message);
    this.name = 'AiError';
    this.code = code;
    this.provider = options.provider ?? null;
    this.retryable = options.retryable ?? RETRYABLE_CODES.includes(code);
    if (options.retryAfterSeconds !== undefined) this.retryAfterSeconds = options.retryAfterSeconds;
  }
}

const RETRYABLE_CODES: readonly AiErrorCode[] = ['rate_limited', 'timeout', 'unavailable'];

/**
 * The message shown to the user.
 *
 * Deliberately never includes the provider's raw error, which can contain the
 * model name, organisation id, quota details and occasionally a fragment of the
 * request. Those go to the server log; the user gets something actionable.
 */
export function userFacingMessage(error: AiError): string {
  switch (error.code) {
    case 'not_configured':
      return 'AI features are not configured on this deployment.';
    case 'unauthorized':
      return 'The AI provider rejected our credentials. An administrator needs to check them.';
    case 'rate_limited':
      return 'The AI provider is rate limiting us. Please try again shortly.';
    case 'context_too_long':
      return 'There was too much context for one request. Try narrowing the scope.';
    case 'content_filtered':
      return 'The provider declined to answer that. Try rephrasing.';
    case 'timeout':
      return 'That took too long and was stopped. Try a shorter request.';
    case 'unavailable':
      return 'The AI provider is unavailable right now. Please try again shortly.';
    case 'bad_response':
      return 'The AI returned something we could not use. Try regenerating.';
    default:
      return 'Something went wrong talking to the AI provider.';
  }
}

/* -------------------------------------------------------------------------- */
/* The interface                                                              */
/* -------------------------------------------------------------------------- */

export interface ModelSpec {
  readonly id: string;
  readonly label: string;
  /** Rough capability tier, used by model selection. */
  readonly tier: 'fast' | 'balanced' | 'deep';
  readonly contextTokens: number;
  readonly maxOutputTokens: number;
}

export interface AIProvider {
  readonly name: ProviderName;
  readonly models: readonly ModelSpec[];
  isConfigured(): boolean;
  complete(
    request: CompletionRequest,
    model: string,
    fetchImpl?: typeof fetch,
  ): Promise<CompletionResult>;
}

/**
 * Token estimate used for budgeting BEFORE a call.
 *
 * Deliberately approximate — ~4 characters per token for English, and a
 * multiplier for Devanagari, where a character is usually more than one token.
 * Real usage comes back from the provider and replaces this; the estimate only
 * has to be good enough to refuse an obviously oversized request up front.
 */
export function estimateTokens(text: string): number {
  if (text.length === 0) return 0;
  const devanagari = (text.match(/[ऀ-ॿ]/g) ?? []).length;
  const rest = text.length - devanagari;
  return Math.ceil(rest / 4 + devanagari / 1.5);
}

export function estimateRequestTokens(request: CompletionRequest): number {
  const messageText = request.messages.map((m) => m.content).join('\n');
  return estimateTokens(request.system) + estimateTokens(messageText);
}

/* -------------------------------------------------------------------------- */
/* Shared HTTP handling                                                       */
/* -------------------------------------------------------------------------- */

interface CallOptions {
  readonly url: string;
  readonly headers: Record<string, string>;
  readonly body: unknown;
  readonly timeoutMs: number;
  readonly provider: ProviderName;
  readonly fetchImpl: typeof fetch;
}

async function callJson(options: CallOptions): Promise<unknown> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeoutMs);

  let response: Response;
  try {
    response = await options.fetchImpl(options.url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...options.headers },
      body: JSON.stringify(options.body),
      signal: controller.signal,
    });
  } catch (error) {
    clearTimeout(timer);
    if (error instanceof Error && error.name === 'AbortError') {
      throw new AiError('timeout', 'The provider did not respond in time.', {
        provider: options.provider,
      });
    }
    throw new AiError('unavailable', 'Could not reach the provider.', {
      provider: options.provider,
    });
  } finally {
    clearTimeout(timer);
  }

  if (!response.ok) throw mapHttpError(response, options.provider);

  try {
    return (await response.json()) as unknown;
  } catch {
    throw new AiError('bad_response', 'The provider returned invalid JSON.', {
      provider: options.provider,
    });
  }
}

function mapHttpError(response: Response, provider: ProviderName): AiError {
  const retryAfter = Number(response.headers.get('retry-after'));
  const retryAfterSeconds = Number.isFinite(retryAfter) && retryAfter > 0 ? retryAfter : undefined;

  if (response.status === 401 || response.status === 403) {
    return new AiError('unauthorized', `Provider returned ${response.status}.`, { provider });
  }
  if (response.status === 429) {
    return new AiError('rate_limited', 'Provider rate limit reached.', {
      provider,
      ...(retryAfterSeconds !== undefined ? { retryAfterSeconds } : {}),
    });
  }
  if (response.status === 413 || response.status === 422) {
    return new AiError('context_too_long', 'Request was too large for the model.', { provider });
  }
  if (response.status >= 500) {
    return new AiError('unavailable', `Provider returned ${response.status}.`, { provider });
  }
  return new AiError('unknown', `Provider returned ${response.status}.`, { provider });
}

function requireText(text: unknown, provider: ProviderName): string {
  if (typeof text !== 'string' || text.trim().length === 0) {
    throw new AiError('bad_response', 'The provider returned no content.', { provider });
  }
  return text;
}

/* -------------------------------------------------------------------------- */
/* OpenAI                                                                     */
/* -------------------------------------------------------------------------- */

export class OpenAiProvider implements AIProvider {
  readonly name = 'openai' as const;

  readonly models: readonly ModelSpec[] = [
    { id: 'gpt-4o-mini', label: 'GPT-4o mini', tier: 'fast', contextTokens: 128_000, maxOutputTokens: 16_384 },
    { id: 'gpt-4o', label: 'GPT-4o', tier: 'balanced', contextTokens: 128_000, maxOutputTokens: 16_384 },
    { id: 'gpt-4.1', label: 'GPT-4.1', tier: 'deep', contextTokens: 200_000, maxOutputTokens: 32_768 },
  ];

  private key(): string | undefined {
    return process.env.OPENAI_API_KEY;
  }

  isConfigured(): boolean {
    return Boolean(this.key());
  }

  async complete(
    request: CompletionRequest,
    model: string,
    fetchImpl: typeof fetch = fetch,
  ): Promise<CompletionResult> {
    const key = this.key();
    if (!key) throw new AiError('not_configured', 'OPENAI_API_KEY is not set.', { provider: this.name });

    const payload = await callJson({
      url: process.env.OPENAI_BASE_URL ?? 'https://api.openai.com/v1/chat/completions',
      headers: { Authorization: `Bearer ${key}` },
      body: {
        model,
        messages: [
          { role: 'system', content: request.system },
          ...request.messages.map((m) => ({ role: m.role, content: m.content })),
        ],
        max_tokens: request.maxOutputTokens,
        temperature: request.temperature,
        ...(request.json ? { response_format: { type: 'json_object' } } : {}),
      },
      timeoutMs: request.timeoutMs,
      provider: this.name,
      fetchImpl,
    });

    const body = payload as {
      choices?: { message?: { content?: string }; finish_reason?: string }[];
      usage?: { prompt_tokens?: number; completion_tokens?: number };
    };
    const choice = body.choices?.[0];

    if (choice?.finish_reason === 'content_filter') {
      throw new AiError('content_filtered', 'The provider filtered the response.', {
        provider: this.name,
      });
    }

    return {
      text: requireText(choice?.message?.content, this.name),
      usage: {
        inputTokens: body.usage?.prompt_tokens ?? 0,
        outputTokens: body.usage?.completion_tokens ?? 0,
      },
      model,
      provider: this.name,
      truncated: choice?.finish_reason === 'length',
    };
  }
}

/* -------------------------------------------------------------------------- */
/* Anthropic                                                                  */
/* -------------------------------------------------------------------------- */

export class AnthropicProvider implements AIProvider {
  readonly name = 'anthropic' as const;

  readonly models: readonly ModelSpec[] = [
    { id: 'claude-haiku-4-5', label: 'Claude Haiku 4.5', tier: 'fast', contextTokens: 200_000, maxOutputTokens: 8_192 },
    { id: 'claude-sonnet-4-5', label: 'Claude Sonnet 4.5', tier: 'balanced', contextTokens: 200_000, maxOutputTokens: 16_384 },
    { id: 'claude-opus-4-1', label: 'Claude Opus 4.1', tier: 'deep', contextTokens: 200_000, maxOutputTokens: 32_768 },
  ];

  private key(): string | undefined {
    return process.env.ANTHROPIC_API_KEY;
  }

  isConfigured(): boolean {
    return Boolean(this.key());
  }

  async complete(
    request: CompletionRequest,
    model: string,
    fetchImpl: typeof fetch = fetch,
  ): Promise<CompletionResult> {
    const key = this.key();
    if (!key) {
      throw new AiError('not_configured', 'ANTHROPIC_API_KEY is not set.', { provider: this.name });
    }

    // Anthropic takes the system prompt as a top-level field, not a message.
    const payload = await callJson({
      url: process.env.ANTHROPIC_BASE_URL ?? 'https://api.anthropic.com/v1/messages',
      headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01' },
      body: {
        model,
        system: request.system,
        messages: request.messages
          .filter((m) => m.role !== 'system')
          .map((m) => ({ role: m.role, content: m.content })),
        max_tokens: request.maxOutputTokens,
        temperature: request.temperature,
      },
      timeoutMs: request.timeoutMs,
      provider: this.name,
      fetchImpl,
    });

    const body = payload as {
      content?: { type?: string; text?: string }[];
      stop_reason?: string;
      usage?: { input_tokens?: number; output_tokens?: number };
    };

    const text = (body.content ?? [])
      .filter((part) => part.type === 'text')
      .map((part) => part.text ?? '')
      .join('');

    return {
      text: requireText(text, this.name),
      usage: {
        inputTokens: body.usage?.input_tokens ?? 0,
        outputTokens: body.usage?.output_tokens ?? 0,
      },
      model,
      provider: this.name,
      truncated: body.stop_reason === 'max_tokens',
    };
  }
}

/* -------------------------------------------------------------------------- */
/* Gemini                                                                     */
/* -------------------------------------------------------------------------- */

export class GeminiProvider implements AIProvider {
  readonly name = 'gemini' as const;

  readonly models: readonly ModelSpec[] = [
    { id: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash', tier: 'fast', contextTokens: 1_000_000, maxOutputTokens: 8_192 },
    { id: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro', tier: 'deep', contextTokens: 1_000_000, maxOutputTokens: 32_768 },
  ];

  private key(): string | undefined {
    return process.env.GEMINI_API_KEY;
  }

  isConfigured(): boolean {
    return Boolean(this.key());
  }

  async complete(
    request: CompletionRequest,
    model: string,
    fetchImpl: typeof fetch = fetch,
  ): Promise<CompletionResult> {
    const key = this.key();
    if (!key) throw new AiError('not_configured', 'GEMINI_API_KEY is not set.', { provider: this.name });

    const base = process.env.GEMINI_BASE_URL ?? 'https://generativelanguage.googleapis.com/v1beta';

    const payload = await callJson({
      // The key goes in a header, not the query string: a URL ends up in access
      // logs, proxy logs and error reports.
      url: `${base}/models/${encodeURIComponent(model)}:generateContent`,
      headers: { 'x-goog-api-key': key },
      body: {
        systemInstruction: { parts: [{ text: request.system }] },
        contents: request.messages
          .filter((m) => m.role !== 'system')
          .map((m) => ({
            role: m.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: m.content }],
          })),
        generationConfig: {
          maxOutputTokens: request.maxOutputTokens,
          temperature: request.temperature,
          ...(request.json ? { responseMimeType: 'application/json' } : {}),
        },
      },
      timeoutMs: request.timeoutMs,
      provider: this.name,
      fetchImpl,
    });

    const body = payload as {
      candidates?: { content?: { parts?: { text?: string }[] }; finishReason?: string }[];
      usageMetadata?: { promptTokenCount?: number; candidatesTokenCount?: number };
      promptFeedback?: { blockReason?: string };
    };

    if (body.promptFeedback?.blockReason) {
      throw new AiError('content_filtered', 'The provider blocked the prompt.', {
        provider: this.name,
      });
    }

    const candidate = body.candidates?.[0];
    if (candidate?.finishReason === 'SAFETY') {
      throw new AiError('content_filtered', 'The provider filtered the response.', {
        provider: this.name,
      });
    }

    const text = (candidate?.content?.parts ?? []).map((part) => part.text ?? '').join('');

    return {
      text: requireText(text, this.name),
      usage: {
        inputTokens: body.usageMetadata?.promptTokenCount ?? 0,
        outputTokens: body.usageMetadata?.candidatesTokenCount ?? 0,
      },
      model,
      provider: this.name,
      truncated: candidate?.finishReason === 'MAX_TOKENS',
    };
  }
}

/* -------------------------------------------------------------------------- */
/* Registry                                                                   */
/* -------------------------------------------------------------------------- */

export function allProviders(): AIProvider[] {
  return [new OpenAiProvider(), new AnthropicProvider(), new GeminiProvider()];
}

export function configuredProviders(): AIProvider[] {
  return allProviders().filter((provider) => provider.isConfigured());
}

export const aiIsEnabled = (): boolean => configuredProviders().length > 0;

/**
 * The provider used unless a call asks for another.
 * `AI_PROVIDER` pins one explicitly; otherwise the first configured provider in
 * registry order is used, so a deployment with one key needs no extra config.
 */
export function defaultProvider(): AIProvider | null {
  const pinned = process.env.AI_PROVIDER;
  if (isProviderName(pinned)) {
    const provider = allProviders().find((p) => p.name === pinned);
    if (provider?.isConfigured()) return provider;
    return null;
  }
  return configuredProviders()[0] ?? null;
}

export function providerByName(name: ProviderName): AIProvider | null {
  return allProviders().find((provider) => provider.name === name) ?? null;
}

/** What the interface may know about AI configuration. No keys, ever. */
export interface PublicAiStatus {
  readonly enabled: boolean;
  readonly providers: readonly { readonly name: ProviderName; readonly configured: boolean }[];
  readonly defaultProvider: ProviderName | null;
  readonly models: readonly { readonly id: string; readonly label: string; readonly tier: string }[];
}

export function publicStatus(): PublicAiStatus {
  const active = defaultProvider();
  return {
    enabled: aiIsEnabled(),
    providers: allProviders().map((provider) => ({
      name: provider.name,
      configured: provider.isConfigured(),
    })),
    defaultProvider: active?.name ?? null,
    models: (active?.models ?? []).map((model) => ({
      id: model.id,
      label: model.label,
      tier: model.tier,
    })),
  };
}
