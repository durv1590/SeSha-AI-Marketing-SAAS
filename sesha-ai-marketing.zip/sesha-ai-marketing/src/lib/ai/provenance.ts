/**
 * Provenance — where every statement in an AI response came from.
 *
 * THE PROBLEM THIS SOLVES
 * A language model will produce a plausible customer count, a plausible market
 * size and a plausible conversion rate if you let it, and they will be
 * indistinguishable in tone from figures the user actually supplied. Published
 * on a marketing site, an invented statistic is a fabricated business claim.
 *
 * THE RULE: every claim carries a kind, and the kinds are not interchangeable.
 * A model may say "your average order value is ₹2,400" ONLY when that number
 * came from the workspace. If it is guessing, it must say so, in a form the
 * interface renders differently.
 *
 * TWO INDEPENDENT DEFENCES, because prompting alone is not a control:
 *   1. Structure — the model returns tagged blocks, and `parseProvenance`
 *      rejects a response whose tags are missing or invalid.
 *   2. A LINTER — `lintClaims` scans the text for statistic-shaped assertions
 *      that are not tagged as sourced, and flags them regardless of what the
 *      model claimed. It catches the case where the model tags a guess as fact.
 *
 * Framework-free and fully unit tested.
 */

/** The seven kinds required by the Phase 3 specification. */
export const PROVENANCE_KINDS = [
  /** Typed in by the user: onboarding answers, brand kit, project details. */
  'user_provided',
  /** From a connected system: an analytics account, a CRM, an ad platform. */
  'connected',
  /** Retrieved from a source we can cite: a crawled page, an uploaded document. */
  'retrieved',
  /** A number the model produced with no source. Always approximate. */
  'ai_estimate',
  /** A conclusion the model drew from other material in the response. */
  'ai_inference',
  /** An action the model suggests. An opinion, not a fact. */
  'recommendation',
  /** Something we were asked for and genuinely do not have. */
  'unavailable',
] as const;

export type ProvenanceKind = (typeof PROVENANCE_KINDS)[number];

/** Kinds backed by something real. Only these may state a fact. */
export const SOURCED_KINDS: readonly ProvenanceKind[] = ['user_provided', 'connected', 'retrieved'];

/** Kinds the model made up. Must never be presented as fact. */
export const UNSOURCED_KINDS: readonly ProvenanceKind[] = [
  'ai_estimate',
  'ai_inference',
  'recommendation',
];

export function isProvenanceKind(value: unknown): value is ProvenanceKind {
  return typeof value === 'string' && (PROVENANCE_KINDS as readonly string[]).includes(value);
}

export function isSourced(kind: ProvenanceKind): boolean {
  return SOURCED_KINDS.includes(kind);
}

/** How each kind is labelled and treated in the interface. */
export interface ProvenanceDisplay {
  readonly label: string;
  readonly description: string;
  /** Drives the badge colour. */
  readonly tone: 'neutral' | 'success' | 'info' | 'warning' | 'brand';
  /** Whether the interface may present this as a statement of fact. */
  readonly presentAsFact: boolean;
}

export const PROVENANCE_DISPLAY: Record<ProvenanceKind, ProvenanceDisplay> = {
  user_provided: {
    label: 'From you',
    description: 'Taken from what you entered in this workspace.',
    tone: 'success',
    presentAsFact: true,
  },
  connected: {
    label: 'From connected data',
    description: 'Read from a system you connected.',
    tone: 'success',
    presentAsFact: true,
  },
  retrieved: {
    label: 'From a source',
    description: 'Retrieved from a document or page, and cited.',
    tone: 'info',
    presentAsFact: true,
  },
  ai_estimate: {
    label: 'AI estimate',
    description: 'A figure the AI produced with no source. Treat as a guess and verify it.',
    tone: 'warning',
    presentAsFact: false,
  },
  ai_inference: {
    label: 'AI inference',
    description: 'A conclusion the AI drew from the material above, not a measured fact.',
    tone: 'warning',
    presentAsFact: false,
  },
  recommendation: {
    label: 'Recommendation',
    description: 'A suggested action. An opinion, not a fact.',
    tone: 'brand',
    presentAsFact: false,
  },
  unavailable: {
    label: 'Not available',
    description: 'We do not have this. Connect a source or enter it to fill the gap.',
    tone: 'neutral',
    presentAsFact: false,
  },
};

/* -------------------------------------------------------------------------- */
/* Blocks                                                                     */
/* -------------------------------------------------------------------------- */

export interface ProvenanceBlock {
  readonly kind: ProvenanceKind;
  readonly text: string;
  /**
   * Required for `retrieved` and `connected`: what it came from.
   * `parseProvenance` rejects those kinds without it.
   */
  readonly source?: { readonly type: string; readonly id: string; readonly label?: string };
}

export interface ProvenancedResponse {
  readonly blocks: readonly ProvenanceBlock[];
  readonly warnings: readonly ClaimWarning[];
  /** True when nothing unsourced is presented as a fact. */
  readonly safe: boolean;
}

export type ParseResult =
  | { readonly ok: true; readonly response: ProvenancedResponse }
  | { readonly ok: false; readonly reason: string };

const MAX_BLOCKS = 200;
const MAX_BLOCK_LENGTH = 20_000;

/**
 * Parses a model response into provenance blocks.
 *
 * Strict by design: a malformed or untagged response is REJECTED rather than
 * shown untagged. If the model cannot follow the protocol, the right outcome is
 * an error the user sees, not an unlabelled wall of plausible text.
 */
export function parseProvenance(raw: unknown): ParseResult {
  let payload: unknown = raw;

  if (typeof raw === 'string') {
    const text = stripCodeFence(raw.trim());
    if (text.length === 0) return { ok: false, reason: 'Empty response.' };
    try {
      payload = JSON.parse(text) as unknown;
    } catch {
      return { ok: false, reason: 'Response was not valid JSON.' };
    }
  }

  if (typeof payload !== 'object' || payload === null) {
    return { ok: false, reason: 'Response was not an object.' };
  }

  const blocksRaw = (payload as { blocks?: unknown }).blocks;
  if (!Array.isArray(blocksRaw)) {
    return { ok: false, reason: 'Response has no "blocks" array.' };
  }
  if (blocksRaw.length === 0) return { ok: false, reason: 'Response contained no blocks.' };
  if (blocksRaw.length > MAX_BLOCKS) {
    return { ok: false, reason: `Response exceeded ${MAX_BLOCKS} blocks.` };
  }

  const blocks: ProvenanceBlock[] = [];

  for (const [index, entry] of blocksRaw.entries()) {
    if (typeof entry !== 'object' || entry === null) {
      return { ok: false, reason: `Block ${index} was not an object.` };
    }
    const record = entry as Record<string, unknown>;

    if (!isProvenanceKind(record.kind)) {
      return { ok: false, reason: `Block ${index} has an unknown provenance kind.` };
    }
    if (typeof record.text !== 'string' || record.text.trim().length === 0) {
      return { ok: false, reason: `Block ${index} has no text.` };
    }
    if (record.text.length > MAX_BLOCK_LENGTH) {
      return { ok: false, reason: `Block ${index} exceeded the length limit.` };
    }

    // A claim that says it came from somewhere has to say where.
    let source: ProvenanceBlock['source'];
    if (record.source && typeof record.source === 'object') {
      const s = record.source as Record<string, unknown>;
      if (typeof s.type === 'string' && typeof s.id === 'string') {
        source = {
          type: s.type,
          id: s.id,
          ...(typeof s.label === 'string' ? { label: s.label } : {}),
        };
      }
    }
    if ((record.kind === 'retrieved' || record.kind === 'connected') && !source) {
      return {
        ok: false,
        reason: `Block ${index} is marked "${record.kind}" but names no source.`,
      };
    }

    blocks.push({ kind: record.kind, text: record.text.trim(), ...(source ? { source } : {}) });
  }

  const warnings = lintClaims(blocks);
  return {
    ok: true,
    response: {
      blocks,
      warnings,
      safe: warnings.every((warning) => warning.severity !== 'error'),
    },
  };
}

function stripCodeFence(text: string): string {
  const fenced = text.match(/^```(?:json)?\s*\n([\s\S]*?)\n```$/);
  return fenced?.[1] ?? text;
}

/* -------------------------------------------------------------------------- */
/* The claim linter                                                           */
/* -------------------------------------------------------------------------- */

export interface ClaimWarning {
  readonly severity: 'error' | 'warning';
  readonly blockIndex: number;
  readonly kind: ProvenanceKind;
  readonly excerpt: string;
  readonly message: string;
}

/**
 * Patterns that look like a measured fact.
 *
 * These are exactly the shapes that get copied into a customer's marketing
 * material and then have to be defended. In a SOURCED block they are fine — the
 * user gave us the number. In an unsourced block they are a fabrication.
 */
const FACTUAL_PATTERNS: readonly { readonly label: string; readonly pattern: RegExp }[] = [
  { label: 'a percentage', pattern: /\b\d{1,3}(\.\d+)?\s?%/ },
  { label: 'a currency amount', pattern: /(?:[$€£¥]|\bRs\.?|\bINR\b|\bUSD\b)\s?\d/i },
  { label: 'a large round count', pattern: /\b\d{1,3}(,\d{3})+\b|\b\d+(\.\d+)?\s?(k|m|bn|million|billion|lakh|crore)\b/i },
  // No \b before the alternation: a word boundary cannot precede "#", so
  // "the #1 roaster" would never match.
  { label: 'a ranking claim', pattern: /(#\d+|\bnumber one\b|\bmarket leader\b|\bthe largest\b|\bthe fastest[- ]growing\b|\bbest[- ]in[- ]class\b)/i },
  { label: 'a multiplier', pattern: /\b\d+(\.\d+)?x\s+(more|faster|better|higher|growth)\b/i },
  { label: 'a dated market statistic', pattern: /\bin 20\d\d,?\s+(the\s+)?(market|industry|sector)\b/i },
  { label: 'a survey or study reference', pattern: /\b(a|the)\s+(study|survey|report)\s+(found|shows|showed|says)\b/i },
];

/** Hedges that make an unsourced figure honest rather than a claim. */
const HEDGE_PATTERN =
  /\b(roughly|approximately|around|about|typically|often|commonly|estimated|an estimate|we estimate|likely|may|might|could|in the region of|order of magnitude|as a rule of thumb|assum\w+|if\b)/i;

/**
 * Flags statistic-shaped assertions in unsourced blocks.
 *
 * This is the second, independent defence. The model is instructed not to do
 * this; the linter assumes it will anyway. A hedged estimate is a warning (the
 * interface still labels it); an unhedged one is an ERROR and makes the whole
 * response unsafe to present.
 */
export function lintClaims(blocks: readonly ProvenanceBlock[]): ClaimWarning[] {
  const warnings: ClaimWarning[] = [];

  blocks.forEach((block, index) => {
    if (isSourced(block.kind)) return;
    if (block.kind === 'unavailable') return;

    for (const rule of FACTUAL_PATTERNS) {
      const match = block.text.match(rule.pattern);
      if (!match) continue;

      const hedged = HEDGE_PATTERN.test(sentenceAround(block.text, match.index ?? 0));
      warnings.push({
        severity: hedged ? 'warning' : 'error',
        blockIndex: index,
        kind: block.kind,
        excerpt: excerptAround(block.text, match.index ?? 0),
        message: hedged
          ? `Contains ${rule.label} with no source. Labelled as ${PROVENANCE_DISPLAY[block.kind].label.toLowerCase()}; verify before publishing.`
          : `States ${rule.label} as fact with no source. Rewrite it as an explicit estimate or remove it.`,
      });
    }
  });

  return warnings;
}

function sentenceAround(text: string, index: number): string {
  const start = Math.max(0, text.lastIndexOf('.', index) + 1);
  const endMark = text.indexOf('.', index);
  const end = endMark === -1 ? text.length : endMark + 1;
  return text.slice(start, end);
}

function excerptAround(text: string, index: number, radius = 60): string {
  const start = Math.max(0, index - radius);
  const end = Math.min(text.length, index + radius);
  return `${start > 0 ? '…' : ''}${text.slice(start, end).trim()}${end < text.length ? '…' : ''}`;
}

/* -------------------------------------------------------------------------- */
/* Prompt contract                                                            */
/* -------------------------------------------------------------------------- */

/**
 * The provenance contract given to every model, verbatim.
 *
 * Kept here, next to the parser and the linter, so the instruction and its
 * enforcement cannot drift apart.
 */
export const PROVENANCE_INSTRUCTION = `You must return ONLY a JSON object of the form:
{"blocks":[{"kind":"<kind>","text":"<text>","source":{"type":"<type>","id":"<id>"}}]}

Every block must declare where its content came from, using exactly one kind:

- "user_provided"  — taken from the workspace context given to you below. Use this
                     ONLY for values that literally appear in that context.
- "connected"      — read from a connected system. Requires a "source".
- "retrieved"      — taken from a supplied document or page. Requires a "source".
- "ai_estimate"    — a number or figure you produced yourself. You have no data
                     for it. Say so in the text: write "roughly", "approximately",
                     or "we estimate".
- "ai_inference"   — a conclusion you drew from the material above.
- "recommendation" — an action you suggest. An opinion, not a fact.
- "unavailable"    — something that was asked for and is genuinely not available.
                     Say what would be needed to fill the gap.

Hard rules:
1. NEVER state a statistic, market size, percentage, currency amount, customer
   count or ranking as fact unless it appears in the workspace context. If you do
   not have the number, use "unavailable" or an explicitly hedged "ai_estimate".
2. NEVER invent a study, survey, report, award, review or testimonial.
3. If the context does not contain something you need, say so with "unavailable"
   rather than filling the gap.
4. Do not wrap the JSON in prose or a code fence.`;

/** Renders blocks back to plain text, for copy and export. */
export function blocksToText(blocks: readonly ProvenanceBlock[], options: { annotate?: boolean } = {}): string {
  return blocks
    .map((block) => {
      if (!options.annotate) return block.text;
      const label = PROVENANCE_DISPLAY[block.kind].label;
      return isSourced(block.kind) ? block.text : `${block.text}\n[${label}]`;
    })
    .join('\n\n');
}

/** Counts by kind, for the provenance summary shown above a response. */
export function summarize(blocks: readonly ProvenanceBlock[]): Record<ProvenanceKind, number> {
  const counts = Object.fromEntries(PROVENANCE_KINDS.map((kind) => [kind, 0])) as Record<
    ProvenanceKind,
    number
  >;
  for (const block of blocks) counts[block.kind] += 1;
  return counts;
}
