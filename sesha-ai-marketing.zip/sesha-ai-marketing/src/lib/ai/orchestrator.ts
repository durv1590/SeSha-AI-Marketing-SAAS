/**
 * AI Orchestrator.
 *
 * The single entry point for every generation in the product. It owns the order
 * of operations, and that order is the whole point:
 *
 *   1. agent exists and is implemented
 *   2. request rate       — per organization, cheapest rejection first
 *   3. monthly quota      — generations and tokens, per plan
 *   4. request size       — refuse an oversized prompt before paying for it
 *   5. cache              — an identical deterministic request is free
 *   6. provider call      — with a timeout and bounded retries
 *   7. parse provenance   — a response that will not parse is REJECTED
 *   8. record usage       — always, including on failure
 *
 * Nothing in the product calls a provider directly, so there is no path that
 * skips a step. Framework-free apart from the repository interfaces, and fully
 * unit tested against a fake provider.
 */

import { CircuitBreaker, CircuitOpenError } from '@/lib/reliability';
import { buildSystemPrompt, getAgent, isAgentId, type AgentId } from './agents';
import {
  AiCache,
  AiRateLimiter,
  DEFAULT_RETRY,
  DEFAULT_TIMEOUT_MS,
  aiCache,
  aiRateLimiter,
  checkQuota,
  currentPeriod,
  selectModel,
  withRetry,
  type GenerationRecord,
  type RetryPolicy,
} from './cost';
import { renderContext, contextSources, type WorkspaceContext } from './context';
import { parseProvenance, type ProvenancedResponse } from './provenance';
import {
  AiError,
  estimateRequestTokens,
  userFacingMessage,
  type AIProvider,
  type AiMessage,
  type CompletionRequest,
  type CompletionResult,
} from './provider';
import type { Database } from '@/lib/db/repositories';
import type { Plan } from '@/lib/db/types';
import type { LimitId } from '@/content/plans';
import type { TenantContext } from '@/lib/tenant';

export interface OrchestratorDeps {
  readonly db: Database;
  readonly provider: AIProvider;
  readonly cache?: AiCache;
  readonly limiter?: AiRateLimiter;
  readonly retry?: RetryPolicy;
  readonly fetchImpl?: typeof fetch;
  readonly now?: () => number;
  readonly sleep?: (ms: number) => Promise<void>;
  /** Defaults to one breaker per provider instance, shared across requests. */
  readonly breaker?: CircuitBreaker;
}

/**
 * Phase 9: a circuit breaker per provider instance.
 *
 * Without it, a provider outage made EVERY request wait out its timeout and
 * retries before failing — minutes per request, for every customer at once.
 * After five consecutive outage-class failures the breaker opens and requests
 * fail immediately with an honest "unavailable" for 30 seconds, then one probe
 * is let through. Only outage-class errors count: a filtered prompt, a context
 * that is too long or a quota refusal says nothing about the provider's health.
 */
const OUTAGE_CODES = new Set(['timeout', 'unavailable', 'unknown']);
const breakers = new WeakMap<object, CircuitBreaker>();
function breakerFor(provider: object): CircuitBreaker {
  let breaker = breakers.get(provider);
  if (!breaker) {
    breaker = new CircuitBreaker('ai-provider', {
      failureThreshold: 5,
      resetAfterMs: 30_000,
      isFailure: (error) => !(error instanceof AiError) || OUTAGE_CODES.has(error.code),
    });
    breakers.set(provider, breaker);
  }
  return breaker;
}

export interface RunInput {
  readonly agent: AgentId;
  /** The user's instruction for this turn. */
  readonly prompt: string;
  /** Prior turns, for the conversational copilot. Trimmed to a budget. */
  readonly history?: readonly AiMessage[];
  readonly context: WorkspaceContext;
  readonly projectId?: string | null;
  /** Explicit model choice. Falls back to the agent's task weight. */
  readonly model?: string;
  /** Forces a cache miss. Set by "Regenerate". */
  readonly bypassCache?: boolean;
  /** Overrides the agent default, for transforms like "shorten". */
  readonly maxOutputTokens?: number;
  readonly temperature?: number;
}

export interface RunSuccess {
  readonly ok: true;
  readonly response: ProvenancedResponse;
  readonly record: GenerationRecord;
  readonly cached: boolean;
  readonly truncated: boolean;
}

export interface RunFailure {
  readonly ok: false;
  readonly code: string;
  /** Safe to show the user. Never contains provider detail. */
  readonly message: string;
  readonly retryAfterSeconds?: number;
}

export type RunResult = RunSuccess | RunFailure;

/** Conversation history is trimmed to this, so a long chat cannot grow unbounded. */
export const HISTORY_TOKEN_BUDGET = 4_000;
export const MAX_PROMPT_LENGTH = 20_000;

export class AIOrchestrator {
  private readonly deps: OrchestratorDeps;

  constructor(deps: OrchestratorDeps) {
    this.deps = deps;
  }

  private now(): number {
    return this.deps.now?.() ?? Date.now();
  }

  async run(tenant: TenantContext, input: RunInput): Promise<RunResult> {
    const started = this.now();
    const cache = this.deps.cache ?? aiCache;
    const limiter = this.deps.limiter ?? aiRateLimiter;

    /* --- 1. agent ------------------------------------------------------- */

    if (!isAgentId(input.agent)) {
      return { ok: false, code: 'unknown_agent', message: 'That assistant does not exist.' };
    }
    const agent = getAgent(input.agent);
    if (agent.status !== 'available') {
      return {
        ok: false,
        code: 'agent_not_implemented',
        message: `${agent.label} is not built yet${agent.phase ? ` — it arrives in ${agent.phase}` : ''}.`,
      };
    }

    const prompt = input.prompt.trim();
    if (prompt.length === 0) {
      return { ok: false, code: 'empty_prompt', message: 'Enter a prompt first.' };
    }
    if (prompt.length > MAX_PROMPT_LENGTH) {
      return {
        ok: false,
        code: 'prompt_too_long',
        message: `Prompts are limited to ${MAX_PROMPT_LENGTH.toLocaleString('en-US')} characters.`,
      };
    }

    /* --- plan ----------------------------------------------------------- */

    const subscription = await this.deps.db.subscriptions.findForOrganization(
      tenant.organizationId,
    );
    const plan: Plan = subscription?.plan ?? 'free';
    // An admin's limit override is honoured on the AI path too. Before Phase 7
    // this was the ONLY place limits were enforced, so leaving it reading its
    // own private table would have made the admin control a lie exactly where
    // it matters most.
    const overrideRows = await this.deps.db.planLimits.listForOrganization(tenant.organizationId);
    const overrides = overrideRows.map((row) => ({
      limitId: row.limitId as LimitId,
      value: row.value,
      reason: row.reason,
      setBy: row.setBy,
      setAt: row.setAt.toISOString(),
    }));

    /* --- 2. request rate ------------------------------------------------ */

    const { quotaFor } = await import('./cost');
    const quota = quotaFor(plan, overrides);
    const rate = limiter.check(tenant.organizationId, quota.requestsPerMinute, started);
    if (!rate.allowed) {
      return {
        ok: false,
        code: 'rate_limited',
        message: 'Too many requests at once. Please wait a moment.',
        retryAfterSeconds: rate.retryAfterSeconds,
      };
    }

    /* --- build the request ---------------------------------------------- */

    const system = buildSystemPrompt(
      agent,
      renderContext(input.context, { maxTokens: quota.maxInputTokens / 2 }),
    );
    const history = trimHistory(input.history ?? [], HISTORY_TOKEN_BUDGET);

    const model = selectModel(this.deps.provider.models, agent.weight, input.model);
    const maxOutputTokens = Math.min(
      input.maxOutputTokens ?? agent.maxOutputTokens,
      model.maxOutputTokens,
      quota.maxOutputTokens,
    );

    const request: CompletionRequest = {
      system,
      messages: [...history, { role: 'user', content: prompt }],
      maxOutputTokens,
      temperature: input.temperature ?? agent.temperature,
      timeoutMs: DEFAULT_TIMEOUT_MS,
      json: true,
    };

    /* --- 3 + 4. quota and size ------------------------------------------ */

    const period = currentPeriod(started);
    const usedGenerations = await this.deps.db.usage.totalFor(
      tenant.organizationId,
      'ai_generation',
      period,
    );
    const usedTokens = await this.deps.db.usage.totalFor(
      tenant.organizationId,
      'ai_tokens',
      period,
    );

    const inputTokens = estimateRequestTokens(request);
    const decision = checkQuota(
      plan,
      { generations: usedGenerations, tokens: usedTokens },
      { inputTokens, maxOutputTokens },
    );

    if (!decision.allowed) {
      await this.audit(tenant, agent.id, 'denied', { reason: decision.reason });
      return { ok: false, code: `quota_${decision.reason}`, message: decision.message };
    }

    /* --- 5. cache -------------------------------------------------------- */

    const cacheKey = AiCache.key(tenant.organizationId, model.id, request);
    if (!input.bypassCache && cache.cacheable(request)) {
      const hit = cache.get(cacheKey, started);
      if (hit) {
        const parsed = parseProvenance(hit.text);
        if (parsed.ok) {
          return {
            ok: true,
            response: parsed.response,
            cached: true,
            truncated: hit.truncated,
            // A cache hit costs nothing, so it is recorded with zero tokens
            // and is NOT counted against the generation quota.
            record: {
              organizationId: tenant.organizationId,
              projectId: input.projectId ?? null,
              provider: hit.provider,
              model: hit.model,
              inputTokens: 0,
              outputTokens: 0,
              cached: true,
              attempts: 0,
              durationMs: this.now() - started,
              agent: agent.id,
            },
          };
        }
        // A cached response that no longer parses is not worth keeping.
      }
    }

    /* --- 6. call --------------------------------------------------------- */

    let completion: CompletionResult;
    let attempts = 1;

    try {
      const breaker = this.deps.breaker ?? breakerFor(this.deps.provider);
      const outcome = await breaker.run(() =>
        withRetry(
          () => this.deps.provider.complete(request, model.id, this.deps.fetchImpl),
          this.deps.retry ?? DEFAULT_RETRY,
          this.deps.sleep,
        ),
      );
      completion = outcome.result;
      attempts = outcome.attempts;
    } catch (error) {
      const aiError =
        error instanceof AiError
          ? error
          : error instanceof CircuitOpenError
            ? new AiError('unavailable', 'The AI provider is temporarily unavailable.', {
                retryAfterSeconds: Math.max(1, Math.ceil(error.retryAfterMs / 1000)),
              })
            : new AiError('unknown', 'Generation failed.');

      // Failures are recorded too: a provider outage should be visible in the
      // audit log, and a failed call still consumed time and possibly tokens.
      await this.audit(tenant, agent.id, 'failure', {
        code: aiError.code,
        provider: aiError.provider,
        attempts,
      });

      return {
        ok: false,
        code: aiError.code,
        message: userFacingMessage(aiError),
        ...(aiError.retryAfterSeconds !== undefined
          ? { retryAfterSeconds: aiError.retryAfterSeconds }
          : {}),
      };
    }

    /* --- 7. provenance --------------------------------------------------- */

    const parsed = parseProvenance(completion.text);
    if (!parsed.ok) {
      await this.recordUsage(tenant, input.projectId ?? null, completion, agent.id, period);
      await this.audit(tenant, agent.id, 'failure', { reason: 'unparseable', detail: parsed.reason });
      return {
        ok: false,
        code: 'bad_response',
        // Truthful: we were charged, and we are not showing untagged output.
        message:
          'The AI returned a response we could not verify the sourcing of, so it was discarded. Try regenerating.',
      };
    }

    /* --- 8. record ------------------------------------------------------- */

    if (cache.cacheable(request)) cache.set(cacheKey, completion, started);

    const record: GenerationRecord = {
      organizationId: tenant.organizationId,
      projectId: input.projectId ?? null,
      provider: completion.provider,
      model: completion.model,
      inputTokens: completion.usage.inputTokens,
      outputTokens: completion.usage.outputTokens,
      cached: false,
      attempts,
      durationMs: this.now() - started,
      agent: agent.id,
    };

    await this.recordUsage(tenant, input.projectId ?? null, completion, agent.id, period);
    await this.audit(tenant, agent.id, 'success', {
      provider: completion.provider,
      model: completion.model,
      tokens: completion.usage.inputTokens + completion.usage.outputTokens,
      warnings: parsed.response.warnings.length,
      safe: parsed.response.safe,
    });

    return {
      ok: true,
      response: parsed.response,
      record,
      cached: false,
      truncated: completion.truncated,
    };
  }

  private async recordUsage(
    tenant: TenantContext,
    projectId: string | null,
    completion: CompletionResult,
    agent: string,
    period: string,
  ): Promise<void> {
    await this.deps.db.usage.record({
      organizationId: tenant.organizationId,
      projectId,
      metric: 'ai_generation',
      quantity: 1,
      periodStart: period,
    });
    const tokens = completion.usage.inputTokens + completion.usage.outputTokens;
    if (tokens > 0) {
      await this.deps.db.usage.record({
        organizationId: tenant.organizationId,
        projectId,
        metric: 'ai_tokens',
        quantity: tokens,
        periodStart: period,
      });
    }
    void agent;
  }

  private async audit(
    tenant: TenantContext,
    agent: string,
    outcome: 'success' | 'failure' | 'denied',
    metadata: Record<string, unknown>,
  ): Promise<void> {
    await this.deps.db.audit.record({
      organizationId: tenant.organizationId,
      actorId: tenant.userId,
      action: `ai.generate.${agent}`,
      entityType: 'ai_generation',
      entityId: null,
      outcome,
      // Never the prompt or the output: an audit log is not a content store,
      // and it would become a second copy of the customer's data.
      metadata,
      ipHash: null,
      userAgent: null,
    });
  }
}

/**
 * Trims conversation history to a token budget, keeping the MOST RECENT turns.
 *
 * Recent turns carry the thread of the conversation; the opening exchange is
 * usually the most disposable. Pairs are kept intact where possible so the
 * model never sees an answer with no question.
 */
export function trimHistory(history: readonly AiMessage[], budget: number): AiMessage[] {
  const kept: AiMessage[] = [];
  let used = 0;

  for (let index = history.length - 1; index >= 0; index -= 1) {
    const message = history[index]!;
    const cost = Math.ceil(message.content.length / 4);
    if (used + cost > budget) break;
    kept.unshift(message);
    used += cost;
  }

  // Never start the history with an assistant turn.
  while (kept.length > 0 && kept[0]!.role === 'assistant') kept.shift();
  return kept;
}

export { contextSources };
