/**
 * AI cost control.
 *
 * Generation is the only part of this product with a marginal cost per request,
 * and it is the one an abusive or looping client can run up fastest. Every
 * control here is enforced SERVER-SIDE, before the provider is called.
 *
 * Order of checks, cheapest first:
 *   1. rate limit        — requests per minute, per organization
 *   2. monthly quota     — generations and tokens per plan
 *   3. request size      — refuse an oversized prompt before paying for it
 *   4. cache             — an identical request within the window is free
 *   5. call, with a timeout and bounded retries
 *
 * Framework-free, deterministic (`now` is injectable) and fully unit tested.
 */

import { createHash } from 'node:crypto';

import { AiError, estimateRequestTokens, type CompletionRequest, type CompletionResult, type ModelSpec, type ProviderName } from './provider';
import type { Plan } from '@/lib/db/types';
import { effectiveLimits, type LimitOverride } from '@/lib/plans/resolve';

/* -------------------------------------------------------------------------- */
/* Quotas                                                                     */
/* -------------------------------------------------------------------------- */

export interface AiQuota {
  /** Generations per calendar month. */
  readonly generationsPerMonth: number;
  /** Total tokens (input + output) per calendar month. */
  readonly tokensPerMonth: number;
  /** Requests per minute, per organization. */
  readonly requestsPerMinute: number;
  /** Largest single request we will pay for, in estimated input tokens. */
  readonly maxInputTokens: number;
  readonly maxOutputTokens: number;
}

/**
 * Per-plan AI quotas.
 *
 * PHASE 7 SPLIT THIS IN TWO, and the split is the point.
 *
 *  · `generationsPerMonth` and `tokensPerMonth` ARE two of the eleven plan
 *    limits the brief names, so they are no longer written here. They come from
 *    `content/plans.ts` through the resolver, which means an admin can raise
 *    them for one customer without a deployment.
 *  · `requestsPerMinute`, `maxInputTokens` and `maxOutputTokens` are NOT plan
 *    limits. They are abuse and cost controls on a single request, they are not
 *    something a salesperson sells, and a customer should not be able to buy a
 *    larger single prompt by upgrading. They stay here.
 *
 * Conflating the two is how "upgrade for a bigger context window" ends up on a
 * pricing page by accident.
 */
export const AI_REQUEST_CEILINGS: Record<Plan, Pick<AiQuota, 'requestsPerMinute' | 'maxInputTokens' | 'maxOutputTokens'>> = {
  free: { requestsPerMinute: 5, maxInputTokens: 12_000, maxOutputTokens: 2_000 },
  pro: { requestsPerMinute: 10, maxInputTokens: 24_000, maxOutputTokens: 4_000 },
  business: { requestsPerMinute: 30, maxInputTokens: 60_000, maxOutputTokens: 8_000 },
  agency: { requestsPerMinute: 60, maxInputTokens: 120_000, maxOutputTokens: 16_000 },
};

/**
 * The full quota for a plan: the registry's monthly limits plus the per-request
 * ceilings above.
 *
 * `overrides` is threaded through so an admin's limit change is honoured here
 * too — the AI path was the only place limits were enforced before Phase 7, and
 * leaving it reading its own private table would have made the admin control a
 * lie on the one surface where it matters most.
 */
export function quotaFor(plan: Plan, overrides: readonly LimitOverride[] = []): AiQuota {
  const limits = effectiveLimits(plan, overrides);
  const ceilings = AI_REQUEST_CEILINGS[plan];
  return {
    // `null` means unlimited in the registry. Represented here as Infinity so
    // the comparisons below stay simple and a `null` cannot be coerced to 0,
    // which would refuse every request on the most expensive plan.
    generationsPerMonth: limits.ai_requests.value ?? Number.POSITIVE_INFINITY,
    tokensPerMonth: limits.tokens.value ?? Number.POSITIVE_INFINITY,
    ...ceilings,
  };
}


export interface UsageSnapshot {
  readonly generations: number;
  readonly tokens: number;
}

export type QuotaDecision =
  | { readonly allowed: true; readonly remaining: UsageSnapshot }
  | {
      readonly allowed: false;
      readonly reason: 'generations' | 'tokens' | 'requests' | 'input_too_large' | 'output_too_large';
      readonly message: string;
      readonly retryAfterSeconds?: number;
    };

/**
 * Checks a request against the plan quota.
 *
 * Returns a decision rather than throwing, so the caller can record the refusal
 * and tell the user which limit they hit and what to do about it.
 */
export function checkQuota(
  plan: Plan,
  used: UsageSnapshot,
  request: { inputTokens: number; maxOutputTokens: number },
  overrides: readonly LimitOverride[] = [],
): QuotaDecision {
  const quota = quotaFor(plan, overrides);

  if (request.inputTokens > quota.maxInputTokens) {
    return {
      allowed: false,
      reason: 'input_too_large',
      message: `That request is too large for the ${plan} plan (${quota.maxInputTokens.toLocaleString('en-US')} token limit). Narrow the scope or upgrade.`,
    };
  }
  if (request.maxOutputTokens > quota.maxOutputTokens) {
    return {
      allowed: false,
      reason: 'output_too_large',
      message: `Requested output exceeds the ${plan} plan limit of ${quota.maxOutputTokens.toLocaleString('en-US')} tokens.`,
    };
  }
  if (used.generations >= quota.generationsPerMonth) {
    return {
      allowed: false,
      reason: 'generations',
      message: `You have used all ${quota.generationsPerMonth.toLocaleString('en-US')} generations included this month. Upgrade or wait for the next billing period.`,
    };
  }
  // Budget the worst case: the whole request plus the full output allowance.
  if (used.tokens + request.inputTokens + request.maxOutputTokens > quota.tokensPerMonth) {
    return {
      allowed: false,
      reason: 'tokens',
      message: `This request would exceed your monthly token allowance. Upgrade or wait for the next billing period.`,
    };
  }

  return {
    allowed: true,
    remaining: {
      generations: quota.generationsPerMonth - used.generations,
      tokens: Math.max(0, quota.tokensPerMonth - used.tokens),
    },
  };
}

/** First day of the current billing month, matching `usage_records.period_start`. */
export function currentPeriod(now: number = Date.now()): string {
  const date = new Date(now);
  const month = String(date.getUTCMonth() + 1).padStart(2, '0');
  return `${date.getUTCFullYear()}-${month}-01`;
}

/* -------------------------------------------------------------------------- */
/* Per-organization request rate                                              */
/* -------------------------------------------------------------------------- */

interface Window {
  count: number;
  resetAt: number;
}

/**
 * Request-rate limiter, keyed by organization rather than by client address.
 *
 * Deliberately different from the address-based limiter in lib/security: the
 * cost here is ours per organization, so ten people in one company share one
 * budget, and one person on ten devices does not get ten budgets.
 */
export class AiRateLimiter {
  private readonly windows = new Map<string, Window>();

  check(
    organizationId: string,
    limitPerMinute: number,
    now: number = Date.now(),
  ): { allowed: boolean; retryAfterSeconds: number } {
    const existing = this.windows.get(organizationId);

    if (!existing || existing.resetAt <= now) {
      this.windows.set(organizationId, { count: 1, resetAt: now + 60_000 });
      return { allowed: true, retryAfterSeconds: 0 };
    }

    existing.count += 1;
    if (existing.count > limitPerMinute) {
      return {
        allowed: false,
        retryAfterSeconds: Math.ceil((existing.resetAt - now) / 1000),
      };
    }
    return { allowed: true, retryAfterSeconds: 0 };
  }

  reset(): void {
    this.windows.clear();
  }
}

/**
 * Phase 3 uses an in-process limiter, correct for a single instance. A
 * multi-instance deployment must replace it with a shared store, or an
 * organization simply gets one budget per instance.
 */
export const aiRateLimiter = new AiRateLimiter();

/* -------------------------------------------------------------------------- */
/* Model selection                                                            */
/* -------------------------------------------------------------------------- */

export type TaskWeight = 'light' | 'standard' | 'heavy';

/**
 * Picks a model for a task.
 *
 * Cheap work should not run on an expensive model. A caption rewrite is
 * 'light'; a full marketing strategy is 'heavy'. An explicit request is
 * honoured when the model exists, so the user can override.
 */
export function selectModel(
  models: readonly ModelSpec[],
  weight: TaskWeight,
  requested?: string,
): ModelSpec {
  if (models.length === 0) {
    throw new AiError('not_configured', 'The provider offers no models.');
  }
  if (requested) {
    const match = models.find((model) => model.id === requested);
    if (match) return match;
  }

  const preference: Record<TaskWeight, ModelSpec['tier'][]> = {
    light: ['fast', 'balanced', 'deep'],
    standard: ['balanced', 'deep', 'fast'],
    heavy: ['deep', 'balanced', 'fast'],
  };

  for (const tier of preference[weight]) {
    const match = models.find((model) => model.tier === tier);
    if (match) return match;
  }
  return models[0]!;
}

/* -------------------------------------------------------------------------- */
/* Caching                                                                    */
/* -------------------------------------------------------------------------- */

export interface CacheEntry {
  readonly result: CompletionResult;
  readonly storedAt: number;
}

/**
 * Response cache, keyed by the exact request.
 *
 * WHAT IS CACHED: deterministic work only. A request with temperature above
 * `CACHE_TEMPERATURE_CEILING` is NOT cached, because the user asked for
 * variation — returning the same text to someone who pressed "Regenerate"
 * would be a bug, not a saving. `bypass` forces a miss for exactly that case.
 *
 * The key includes the organization id, so one tenant can never be served
 * another tenant's generated content out of the cache.
 */
export const CACHE_TEMPERATURE_CEILING = 0.3;
export const CACHE_TTL_MS = 15 * 60 * 1000;

export class AiCache {
  private readonly entries = new Map<string, CacheEntry>();
  private readonly maxEntries: number;

  constructor(maxEntries = 500) {
    this.maxEntries = maxEntries;
  }

  static key(organizationId: string, model: string, request: CompletionRequest): string {
    const payload = JSON.stringify({
      organizationId,
      model,
      system: request.system,
      messages: request.messages,
      maxOutputTokens: request.maxOutputTokens,
      temperature: request.temperature,
      json: request.json ?? false,
    });
    return createHash('sha256').update(payload).digest('hex');
  }

  cacheable(request: CompletionRequest): boolean {
    return request.temperature <= CACHE_TEMPERATURE_CEILING;
  }

  get(key: string, now: number = Date.now()): CompletionResult | null {
    const entry = this.entries.get(key);
    if (!entry) return null;
    if (now - entry.storedAt > CACHE_TTL_MS) {
      this.entries.delete(key);
      return null;
    }
    // Refresh recency for the LRU eviction below.
    this.entries.delete(key);
    this.entries.set(key, entry);
    return entry.result;
  }

  set(key: string, result: CompletionResult, now: number = Date.now()): void {
    if (this.entries.size >= this.maxEntries) {
      const oldest = this.entries.keys().next().value;
      if (oldest) this.entries.delete(oldest);
    }
    this.entries.set(key, { result, storedAt: now });
  }

  clear(): void {
    this.entries.clear();
  }

  get size(): number {
    return this.entries.size;
  }
}

export const aiCache = new AiCache();

/* -------------------------------------------------------------------------- */
/* Retry and timeout                                                          */
/* -------------------------------------------------------------------------- */

export interface RetryPolicy {
  readonly maxAttempts: number;
  readonly baseDelayMs: number;
  readonly maxDelayMs: number;
}

export const DEFAULT_RETRY: RetryPolicy = {
  // Three attempts total. More than that on a paid API turns a provider blip
  // into a bill, and the user is already waiting.
  maxAttempts: 3,
  baseDelayMs: 500,
  maxDelayMs: 8_000,
};

export const DEFAULT_TIMEOUT_MS = 60_000;

/**
 * Exponential back-off with full jitter.
 *
 * Jitter matters: without it, every client that failed at the same moment
 * retries at the same moment, and the provider's recovery is met with a
 * synchronised thundering herd.
 */
export function backoffDelay(
  attempt: number,
  policy: RetryPolicy = DEFAULT_RETRY,
  random: () => number = Math.random,
): number {
  const ceiling = Math.min(policy.baseDelayMs * 2 ** (attempt - 1), policy.maxDelayMs);
  return Math.floor(random() * ceiling);
}

export interface RetryOutcome<T> {
  readonly result: T;
  readonly attempts: number;
}

/**
 * Runs an operation with bounded retries.
 *
 * Only RETRYABLE errors are retried. An unauthorized key or a filtered prompt
 * will fail identically every time; retrying those wastes the user's time and,
 * for some providers, their quota.
 */
export async function withRetry<T>(
  operation: (attempt: number) => Promise<T>,
  policy: RetryPolicy = DEFAULT_RETRY,
  sleep: (ms: number) => Promise<void> = (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
  random: () => number = Math.random,
): Promise<RetryOutcome<T>> {
  let lastError: unknown;

  for (let attempt = 1; attempt <= policy.maxAttempts; attempt += 1) {
    try {
      return { result: await operation(attempt), attempts: attempt };
    } catch (error) {
      lastError = error;

      const retryable = error instanceof AiError && error.retryable;
      if (!retryable || attempt === policy.maxAttempts) break;

      // Honour the provider's own Retry-After when it sent one.
      const hinted =
        error instanceof AiError && error.retryAfterSeconds !== undefined
          ? error.retryAfterSeconds * 1000
          : null;
      await sleep(Math.min(hinted ?? backoffDelay(attempt, policy, random), policy.maxDelayMs));
    }
  }

  throw lastError;
}

/* -------------------------------------------------------------------------- */
/* Accounting                                                                 */
/* -------------------------------------------------------------------------- */

export interface GenerationRecord {
  readonly organizationId: string;
  readonly projectId: string | null;
  readonly provider: ProviderName;
  readonly model: string;
  readonly inputTokens: number;
  readonly outputTokens: number;
  readonly cached: boolean;
  readonly attempts: number;
  readonly durationMs: number;
  readonly agent: string;
}

export function totalTokens(record: Pick<GenerationRecord, 'inputTokens' | 'outputTokens'>): number {
  return record.inputTokens + record.outputTokens;
}

/**
 * Pre-flight size check, before any provider is contacted.
 * Uses the estimate rather than real usage — the point is to refuse early.
 */
export function preflight(plan: Plan, request: CompletionRequest): QuotaDecision | null {
  const inputTokens = estimateRequestTokens(request);
  const decision = checkQuota(plan, { generations: 0, tokens: 0 }, {
    inputTokens,
    maxOutputTokens: request.maxOutputTokens,
  });
  return decision.allowed ? null : decision;
}
