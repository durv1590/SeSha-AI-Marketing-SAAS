/**
 * Specialised agents.
 *
 * An "agent" here is a narrow, declarative thing: a system prompt, a task
 * weight, a temperature and an output contract. It is deliberately NOT an
 * autonomous loop — nothing in this product runs unattended, calls tools on the
 * user's behalf, or publishes anything. Every agent produces a draft that a
 * person reviews.
 *
 * FOUR ARE BUILT (strategy, content, social, brand) and eight are DECLARED but
 * not implemented. The planned ones are real entries with `status: 'planned'`
 * rather than absent, so the orchestrator can refuse them by name with a useful
 * message, and the interface can list what is coming without pretending it
 * works.
 *
 * Framework-free and fully unit tested.
 */

import { PROVENANCE_INSTRUCTION } from './provenance';
import type { TaskWeight } from './cost';

export const AGENT_IDS = [
  // Built in Phase 3
  'strategy',
  'content',
  'social',
  'brand',
  'copilot',
  // Declared, not implemented
  'seo',
  'aeo',
  'schema',
  'ads',
  'lead',
  'analytics',
  'competitor',
  'report',
] as const;

export type AgentId = (typeof AGENT_IDS)[number];

export function isAgentId(value: unknown): value is AgentId {
  return typeof value === 'string' && (AGENT_IDS as readonly string[]).includes(value);
}

export interface AgentDefinition {
  readonly id: AgentId;
  readonly label: string;
  readonly status: 'available' | 'planned';
  /** One sentence, shown in the interface. */
  readonly purpose: string;
  /** Which phase a planned agent belongs to. */
  readonly phase?: string;
  readonly weight: TaskWeight;
  /**
   * 0 = deterministic, 1 = loose. Analytical agents run low so the same inputs
   * give the same answer; creative agents run higher because variation is the
   * point. This also decides cacheability (see cost.ts).
   */
  readonly temperature: number;
  readonly maxOutputTokens: number;
  /** Agent-specific instructions, appended to the shared preamble. */
  readonly instructions: string;
}

/* -------------------------------------------------------------------------- */
/* Shared preamble                                                            */
/* -------------------------------------------------------------------------- */

/**
 * Given to every agent, before its own instructions.
 *
 * The honesty rules here mirror the ones enforced by `lintClaims`, so the model
 * is told the same thing the linter will check. Prompting is not a control on
 * its own — this is the polite half; the linter is the enforcement.
 */
export const SHARED_PREAMBLE = `You are part of SeSha AI Marketing, a marketing workspace.
You help a marketing team plan and draft work. You produce drafts for a human to
review; nothing you write is published automatically.

HONESTY RULES — these are not style preferences:
- Never invent a statistic, market size, percentage, monetary figure, customer
  count, ranking, award, review, testimonial, study or survey.
- Never describe a competitor's products, pricing, size or performance. You know
  only the names the user gave you.
- Never claim a marketing outcome is guaranteed. Search engines, platforms and
  customers are outside anyone's control.
- If the workspace context does not contain something you need, say so plainly
  and say what would be needed to fill the gap.
- Write for the audience described in the context, in their register. Avoid
  marketing filler: "leverage", "unlock", "game-changing", "revolutionary".`;

/* -------------------------------------------------------------------------- */
/* Agent definitions                                                          */
/* -------------------------------------------------------------------------- */

const AGENTS: Record<AgentId, AgentDefinition> = {
  copilot: {
    id: 'copilot',
    label: 'Copilot',
    status: 'available',
    purpose: 'Answers questions and drafts work using your workspace context.',
    weight: 'standard',
    temperature: 0.5,
    maxOutputTokens: 2_000,
    instructions: `You are the general copilot. Answer the user's question directly and
concisely, grounded in the workspace context.

- Lead with the answer, then the reasoning. Do not restate the question.
- When the context answers it, cite the context: mark those blocks
  "user_provided".
- When it does not, say so with an "unavailable" block rather than guessing.
- Keep it proportionate: a one-line question gets a short answer.`,
  },

  strategy: {
    id: 'strategy',
    label: 'Strategy Agent',
    status: 'available',
    purpose: 'Turns your positioning and goals into a structured marketing plan.',
    weight: 'heavy',
    // Low: a strategy should be reproducible from the same inputs, and this
    // makes it cacheable.
    temperature: 0.25,
    maxOutputTokens: 8_000,
    instructions: `You produce marketing strategy. Work only from the workspace context.

- Every section must be specific to this business. A section that would read the
  same for any company in this industry is a failed section — cut it or mark it
  "unavailable" and say what input would make it specific.
- Personas are constructed from the stated audience. Mark them "ai_inference",
  never "user_provided", and never give them invented demographics or budgets.
- SWOT: strengths and weaknesses only from the context. Opportunities and threats
  are "ai_inference" and must be reasoned, not generic.
- KPIs: name the metric and how to measure it. Do NOT set target numbers — you
  have no baseline. Say that a baseline is needed.
- The 30/60/90 plan must contain actions this team can actually take given the
  channels they listed.`,
  },

  content: {
    id: 'content',
    label: 'Content Agent',
    status: 'available',
    purpose: 'Drafts content in your brand voice, for any format and channel.',
    weight: 'standard',
    // Higher: drafts should vary between regenerations.
    temperature: 0.7,
    maxOutputTokens: 4_000,
    instructions: `You draft marketing content.

- Follow the requested format, length, tone and language exactly. The controls
  are not suggestions.
- Apply the brand voice from the context. If there is none, use a plain
  professional register and say the brand voice is unavailable.
- Write the requested language natively. For Hinglish, use natural Roman-script
  code-mixing as an urban Indian audience actually writes it — not Hindi words
  awkwardly inserted into English sentences.
- Put the whole draft in ONE block so it can be copied cleanly. Use
  "ai_inference" for the draft itself; any factual claim you were given belongs
  in its own "user_provided" block.
- Never invent a product feature, price, offer, date or credential. If the brief
  implies one you do not have, leave a clearly marked placeholder in square
  brackets.`,
  },

  social: {
    id: 'social',
    label: 'Social Agent',
    status: 'available',
    purpose: 'Plans posts, captions, hashtags and ideas per platform.',
    weight: 'standard',
    temperature: 0.75,
    maxOutputTokens: 3_000,
    instructions: `You plan social content.

- Respect the platform's real constraints, which are given to you. Do not exceed
  a character limit or suggest a format the platform does not have.
- Hashtags: relevant and specific. Do not pad to a round number, and do not
  invent a branded hashtag the business has not said it uses.
- Ideas must be executable by a small team with the resources implied by the
  context. Do not propose a shoot with a film crew for a one-person business.
- You cannot publish anything and must not imply that you can. Everything you
  produce is a draft for a person to post.`,
  },

  brand: {
    id: 'brand',
    label: 'Brand Agent',
    status: 'available',
    purpose: 'Defines and applies voice, tone and terminology rules.',
    weight: 'standard',
    temperature: 0.35,
    maxOutputTokens: 3_000,
    instructions: `You work on brand voice.

- When defining a voice, derive it from the audience and positioning in the
  context, and express it as rules someone can actually apply: what to do, what
  to avoid, and a short before/after example.
- When checking a draft against the voice, quote the specific phrase that is off
  and give a replacement. Do not give a general grade.
- Avoid abstract adjectives with no operational meaning. "Authentic" is not a
  rule; "use the word 'we', never 'the company'" is.`,
  },

  /* ----------------------------- planned ---------------------------------- */

  seo: {
    id: 'seo',
    label: 'SEO Agent',
    status: 'planned',
    phase: 'a future release',
    purpose: 'Narrative commentary over the SEO audit findings.',
    weight: 'standard',
    temperature: 0.3,
    maxOutputTokens: 4_000,
    instructions:
      'Not implemented. The SEO audit itself shipped in Phase 4 and is rule-based, not generated: see lib/audit/seo.ts. This agent would write prose over those findings.',
  },
  aeo: {
    id: 'aeo',
    label: 'AEO Agent',
    status: 'planned',
    phase: 'a future release',
    purpose: 'Narrative commentary over the AEO audit findings.',
    weight: 'standard',
    temperature: 0.3,
    maxOutputTokens: 4_000,
    instructions:
      'Not implemented. The AEO audit itself shipped in Phase 4 and is rule-based, not generated: see lib/audit/aeo.ts. This agent would write prose over those findings.',
  },
  schema: {
    id: 'schema',
    label: 'Schema Agent',
    status: 'planned',
    phase: 'a future release',
    purpose: 'Generates JSON-LD from verified page data.',
    weight: 'light',
    temperature: 0.1,
    maxOutputTokens: 2_000,
    instructions:
      'Not implemented. The validator and the JSON-LD generator both shipped in Phase 5 and are rule-based, generating markup only from verified application data — see lib/schema. This agent would draft the optional descriptive fields, never the factual ones.',
  },
  ads: {
    id: 'ads',
    label: 'Ads Agent',
    status: 'planned',
    phase: 'a future release',
    purpose: 'Writes the ad copy for a campaign plan.',
    weight: 'standard',
    temperature: 0.7,
    maxOutputTokens: 4_000,
    instructions:
      'Not implemented. Campaign PLANNING shipped in Phase 5 and is rule-based — the platform limits, objectives and budget reasoning are in lib/ads. This agent would write the headlines and descriptions into that structure.',
  },
  lead: {
    id: 'lead',
    label: 'Lead Agent',
    status: 'planned',
    phase: 'a future release',
    purpose: 'Summarises an inbound enquiry in a sentence.',
    weight: 'light',
    temperature: 0.2,
    maxOutputTokens: 1_500,
    instructions:
      'Not implemented. Lead capture and SCORING shipped in Phase 5; the score is rule-based and shows its own reasoning, deliberately. This agent would summarise the enquiry text, not produce a score.',
  },
  analytics: {
    id: 'analytics',
    label: 'Analytics Agent',
    status: 'planned',
    phase: 'a future release',
    purpose: 'Explains what changed and why, from connected data.',
    weight: 'standard',
    temperature: 0.2,
    maxOutputTokens: 3_000,
    instructions:
      'Not implemented. The analytics LAYER shipped in Phase 6 and is deliberately not generated: every figure is calculated from this database with its formula shown, or marked unavailable — see lib/analytics. This agent would write prose over those figures, and would still have nothing to say about traffic or spend until an account is connected.',
  },
  competitor: {
    id: 'competitor',
    label: 'Competitor Agent',
    status: 'planned',
    phase: 'a future release',
    purpose: 'Draws the inference half of a competitor analysis.',
    weight: 'standard',
    temperature: 0.3,
    maxOutputTokens: 3_000,
    instructions:
      'Not implemented. Competitor RESEARCH shipped in Phase 5: the verified observations are read from public pages by lib/competitors. This agent would supply the strengths, weaknesses and opportunities, which are inferences and are labelled as such by withInferences().',
  },
  report: {
    id: 'report',
    label: 'Report Agent',
    status: 'planned',
    phase: 'a future release',
    purpose: 'Writes commentary over reporting data.',
    weight: 'standard',
    temperature: 0.3,
    maxOutputTokens: 4_000,
    instructions:
      'Not implemented. Report GENERATION shipped in Phase 6 and is rule-based: the six sections are built from records in this database by lib/reports/generate.ts, which is what lets a report say "we cannot tell you why" rather than inventing a cause. This agent would write commentary over that structure, never replace it.',
  },
};

export function getAgent(id: AgentId): AgentDefinition {
  return AGENTS[id];
}

export function allAgents(): AgentDefinition[] {
  return AGENT_IDS.map((id) => AGENTS[id]);
}

export function availableAgents(): AgentDefinition[] {
  return allAgents().filter((agent) => agent.status === 'available');
}

export function plannedAgents(): AgentDefinition[] {
  return allAgents().filter((agent) => agent.status === 'planned');
}

/**
 * Assembles the full system prompt.
 *
 * Order is deliberate: identity and honesty rules first, then the agent's job,
 * then the output contract, then the workspace context LAST — the context is
 * the largest block, and putting the rules before it keeps them from being
 * buried.
 */
export function buildSystemPrompt(agent: AgentDefinition, renderedContext: string): string {
  return [
    SHARED_PREAMBLE,
    '',
    `YOUR ROLE: ${agent.label}`,
    agent.instructions,
    '',
    'OUTPUT FORMAT',
    PROVENANCE_INSTRUCTION,
    '',
    'WORKSPACE CONTEXT',
    renderedContext,
  ].join('\n');
}
