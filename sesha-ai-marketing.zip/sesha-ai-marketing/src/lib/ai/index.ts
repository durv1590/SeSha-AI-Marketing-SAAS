/**
 * AI subsystem — public surface.
 *
 * Phase 2 shipped this file as a contract with no implementation. Phase 3
 * implements it. The Phase 2 names (`GenerationRequest`, `aiIsEnabled`) are
 * kept working so nothing that depended on them broke.
 *
 * SERVER ONLY. This module reaches provider adapters that read API keys from
 * `process.env`. A client component that imports it is a build failure, caught
 * by `scripts/verify-static.mjs` and asserted by `tests/ai-security.test.ts`.
 * The browser gets `publicStatus()` — names and capability flags, never a key.
 */

export {
  PROVIDERS,
  AiError,
  AnthropicProvider,
  GeminiProvider,
  OpenAiProvider,
  aiIsEnabled,
  allProviders,
  configuredProviders,
  defaultProvider,
  estimateRequestTokens,
  estimateTokens,
  isProviderName,
  providerByName,
  publicStatus,
  userFacingMessage,
  type AIProvider,
  type AiErrorCode,
  type AiMessage,
  type CompletionRequest,
  type CompletionResult,
  type ModelSpec,
  type ProviderName,
  type PublicAiStatus,
  type TokenUsage,
} from './provider';

export {
  PROVENANCE_DISPLAY,
  PROVENANCE_INSTRUCTION,
  PROVENANCE_KINDS,
  SOURCED_KINDS,
  UNSOURCED_KINDS,
  blocksToText,
  isProvenanceKind,
  isSourced,
  lintClaims,
  parseProvenance,
  summarize,
  type ClaimWarning,
  type ProvenanceBlock,
  type ProvenanceKind,
  type ProvenancedResponse,
} from './provenance';

export {
  AGENT_IDS,
  SHARED_PREAMBLE,
  allAgents,
  availableAgents,
  buildSystemPrompt,
  getAgent,
  isAgentId,
  plannedAgents,
  type AgentDefinition,
  type AgentId,
} from './agents';

export {
  AIOrchestrator,
  HISTORY_TOKEN_BUDGET,
  MAX_PROMPT_LENGTH,
  trimHistory,
  type OrchestratorDeps,
  type RunInput,
  type RunResult,
  type RunSuccess,
} from './orchestrator';

export {
  AI_REQUEST_CEILINGS,
  AiCache,
  AiRateLimiter,
  CACHE_TEMPERATURE_CEILING,
  CACHE_TTL_MS,
  DEFAULT_RETRY,
  DEFAULT_TIMEOUT_MS,
  aiCache,
  aiRateLimiter,
  backoffDelay,
  checkQuota,
  quotaFor,
  currentPeriod,
  selectModel,
  withRetry,
  type AiQuota,
  type GenerationRecord,
  type QuotaDecision,
  type TaskWeight,
  type UsageSnapshot,
} from './cost';

export {
  contextSources,
  isUsable,
  loadWorkspaceContext,
  renderContext,
  summarizeContext,
  type ContextSummary,
  type WorkspaceContext,
} from './context';

/* -------------------------------------------------------------------------- */
/* Phase 2 compatibility                                                      */
/* -------------------------------------------------------------------------- */

import { getAgent, type AgentId } from './agents';
import { defaultProvider } from './provider';
import type { ProvenanceBlock } from './provenance';

/** @deprecated Phase 2 name. Use `RunInput` on the orchestrator. */
export interface GenerationRequest {
  readonly kind: AgentId;
  readonly instruction: string;
  readonly context: { readonly workspaceId: string; readonly locale: string };
  readonly maxTokens?: number;
}

/** @deprecated Phase 2 name. Use `RunResult`. */
export interface GenerationResult {
  readonly text: string;
  readonly review: 'pending' | 'approved' | 'rejected';
  readonly usedSources: readonly { readonly type: string; readonly id: string }[];
  readonly claimsToVerify: readonly string[];
}

/**
 * Phase 2's `getAiProvider()` threw unconditionally. It now returns the
 * configured provider, and still throws when there is none — a caller that
 * relied on the throw for "AI is off" keeps working.
 */
export function getAiProvider() {
  const provider = defaultProvider();
  if (!provider) {
    throw new Error(
      'No AI provider is configured. Set OPENAI_API_KEY, ANTHROPIC_API_KEY or GEMINI_API_KEY.',
    );
  }
  return provider;
}

/**
 * The review state a generation starts in.
 *
 * Always `pending`. This is Phase 2's rule, unchanged: AI proposes, a person
 * approves, and nothing publishes itself. Every artefact Phase 3 writes to the
 * database is created as a draft.
 */
export function initialReviewState(): 'pending' {
  return 'pending';
}

/** Blocks a human must check before publishing — the unsourced ones. */
export function claimsToVerify(blocks: readonly ProvenanceBlock[]): string[] {
  return blocks
    .filter((block) => block.kind === 'ai_estimate' || block.kind === 'ai_inference')
    .map((block) => block.text);
}

export function agentLabel(id: AgentId): string {
  return getAgent(id).label;
}
