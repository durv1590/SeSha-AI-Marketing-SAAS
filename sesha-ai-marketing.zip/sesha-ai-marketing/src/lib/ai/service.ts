/**
 * AI service layer.
 *
 * Routes stay thin: they do HTTP (rate limit, CSRF, auth, envelope) and nothing
 * else. Everything that decides *what happens* lives here, framework-free, so
 * it is unit-testable without a running Next.js server.
 *
 * Two rules this layer exists to enforce:
 *   1. A generation is refused unless the caller owns the project. The tenant
 *      guard runs before the provider call, not after, so a cross-tenant prompt
 *      never reaches a paid API.
 *   2. An unsafe response — one the claim linter flagged as an error — is
 *      persisted with its warnings attached and surfaced as needing review. It
 *      is never silently cleaned up and presented as fact.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { NotFoundError, assertTenant, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { AiConversationRow, AiMessageRow, GeneratedBy, ReviewStatus } from '@/lib/db/types';
import type { GenerationRecord } from './cost';
import { allAgents, type AgentId } from './agents';
import { contextSources, loadWorkspaceContext, summarizeContext, type ContextSummary } from './context';
import { AIOrchestrator, type RunResult, type OrchestratorDeps } from './orchestrator';
import { blocksToText, type ProvenanceBlock, type ClaimWarning } from './provenance';
import { defaultProvider, providerByName, isProviderName, type AIProvider } from './provider';

export interface AiServiceContext {
  readonly db: Database;
  /** Injected in tests; resolved from environment in production. */
  readonly provider?: AIProvider;
  readonly orchestrator?: AIOrchestrator;
  readonly now?: () => number;
  readonly deps?: Partial<OrchestratorDeps>;
}

export class AiUnavailableError extends Error {
  readonly code = 'AI_UNAVAILABLE' as const;
  constructor(message = 'AI features are not configured on this deployment.') {
    super(message);
    this.name = 'AiUnavailableError';
  }
}

function resolveProvider(context: AiServiceContext): AIProvider {
  const provider = context.provider ?? defaultProvider();
  if (!provider) throw new AiUnavailableError();
  return provider;
}

function orchestratorFor(context: AiServiceContext): AIOrchestrator {
  if (context.orchestrator) return context.orchestrator;
  return new AIOrchestrator({
    db: context.db,
    provider: resolveProvider(context),
    ...(context.now ? { now: context.now } : {}),
    ...context.deps,
  });
}

/**
 * Confirms the project belongs to the caller's organization.
 *
 * Returns 404-shaped NotFoundError for a project in another tenant, which is
 * indistinguishable from one that does not exist — the same posture as Phase 2.
 */
async function requireProject(
  context: AiServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<void> {
  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  assertTenant(tenant, project, 'Project');
}

/* -------------------------------------------------------------------------- */
/* Running an agent                                                           */
/* -------------------------------------------------------------------------- */

export interface AgentRunInput {
  readonly agent: AgentId;
  readonly prompt: string;
  readonly projectId: string | null;
  readonly history?: readonly { readonly role: 'user' | 'assistant'; readonly content: string }[];
  readonly model?: string;
  readonly temperature?: number;
  readonly maxOutputTokens?: number;
  readonly bypassCache?: boolean;
}

/**
 * The single path every AI generation takes, whatever the surface.
 *
 * Ownership first, then the workspace context, then the orchestrator (which
 * handles quota, rate limit, cache, retry, timeout, provenance parsing and
 * usage recording).
 */
export async function runAgent(
  context: AiServiceContext,
  tenant: TenantContext,
  input: AgentRunInput,
): Promise<RunResult> {
  requirePermission(tenant.role, 'content:create');

  if (input.projectId) await requireProject(context, tenant, input.projectId);

  const workspace = await loadWorkspaceContext(context.db, tenant, input.projectId);

  return orchestratorFor(context).run(tenant, {
    agent: input.agent,
    prompt: input.prompt,
    context: workspace,
    projectId: input.projectId ?? null,
    ...(input.history ? { history: input.history } : {}),
    ...(input.model ? { model: input.model } : {}),
    ...(input.temperature === undefined ? {} : { temperature: input.temperature }),
    ...(input.maxOutputTokens === undefined ? {} : { maxOutputTokens: input.maxOutputTokens }),
    ...(input.bypassCache ? { bypassCache: true } : {}),
  });
}

/** The provenance stamp written onto every generated artefact. */
export function generatedByFrom(record: GenerationRecord, at = new Date()): GeneratedBy {
  return {
    provider: record.provider,
    model: record.model,
    agent: record.agent,
    at: at.toISOString(),
    cached: record.cached,
  };
}

/**
 * A generated artefact goes to `in_review` whenever the linter found an error,
 * and `draft` otherwise. Nothing reaches `approved` without a person doing it.
 */
export function reviewStatusFor(warnings: readonly ClaimWarning[]): ReviewStatus {
  return warnings.some((warning) => warning.severity === 'error') ? 'in_review' : 'draft';
}

/* -------------------------------------------------------------------------- */
/* Copilot conversations                                                      */
/* -------------------------------------------------------------------------- */

export interface CopilotTurn {
  readonly conversation: AiConversationRow;
  readonly userMessage: AiMessageRow;
  readonly assistantMessage: AiMessageRow | null;
  readonly result: RunResult;
  readonly contextSummary: ContextSummary;
}

/** A conversation title derived from the first question, never from the answer. */
export function titleFromPrompt(prompt: string): string {
  const line = prompt.trim().split('\n')[0]?.trim() ?? '';
  if (line.length === 0) return 'New conversation';
  return line.length > 60 ? `${line.slice(0, 57).trimEnd()}…` : line;
}

export async function listConversations(
  context: AiServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<AiConversationRow[]> {
  requirePermission(tenant.role, 'content:read');
  await requireProject(context, tenant, projectId);
  return context.db.aiConversations.listForProject(tenant.organizationId, projectId);
}

export async function getConversation(
  context: AiServiceContext,
  tenant: TenantContext,
  conversationId: string,
): Promise<{ conversation: AiConversationRow; messages: AiMessageRow[] }> {
  requirePermission(tenant.role, 'content:read');
  const row = await context.db.aiConversations.findById(tenant.organizationId, conversationId);
  const conversation = assertTenant(tenant, row, 'Conversation');
  const messages = await context.db.aiConversations.listMessages(tenant.organizationId, conversation.id);
  return { conversation, messages };
}

export interface CopilotAskInput {
  readonly prompt: string;
  readonly projectId: string;
  readonly conversationId?: string | null;
  readonly model?: string;
}

/**
 * One Copilot turn.
 *
 * The user's message is persisted BEFORE the provider call, so a failed or
 * timed-out generation still leaves a conversation the user recognises rather
 * than a question that vanished.
 */
export async function askCopilot(
  context: AiServiceContext,
  tenant: TenantContext,
  input: CopilotAskInput,
): Promise<CopilotTurn> {
  requirePermission(tenant.role, 'content:create');
  await requireProject(context, tenant, input.projectId);

  let conversation: AiConversationRow;
  if (input.conversationId) {
    const row = await context.db.aiConversations.findById(tenant.organizationId, input.conversationId);
    const existing = assertTenant(tenant, row, 'Conversation');
    if (existing.projectId !== input.projectId) {
      // Same tenant, wrong project: still a not-found, for the same reason.
      throw new NotFoundError('Conversation');
    }
    conversation = existing;
  } else {
    conversation = await context.db.aiConversations.create({
      organizationId: tenant.organizationId,
      projectId: input.projectId,
      userId: tenant.userId,
      title: titleFromPrompt(input.prompt),
      surface: 'copilot',
    });
  }

  const priorMessages = await context.db.aiConversations.listMessages(
    tenant.organizationId,
    conversation.id,
  );
  const history = priorMessages
    .filter((message) => message.role === 'user' || message.role === 'assistant')
    .map((message) => ({ role: message.role as 'user' | 'assistant', content: message.content }));

  const userMessage = await context.db.aiConversations.appendMessage({
    conversationId: conversation.id,
    organizationId: tenant.organizationId,
    role: 'user',
    content: input.prompt,
    contextSources: [],
    reviewState: 'not_applicable',
    tokenCount: null,
  });

  const workspace = await loadWorkspaceContext(context.db, tenant, input.projectId);
  const result = await orchestratorFor(context).run(tenant, {
    agent: 'copilot',
    prompt: input.prompt,
    history,
    context: workspace,
    projectId: input.projectId,
    ...(input.model ? { model: input.model } : {}),
  });

  if (!result.ok) {
    return {
      conversation,
      userMessage,
      assistantMessage: null,
      result,
      contextSummary: summarizeContext(workspace),
    };
  }

  const assistantMessage = await context.db.aiConversations.appendMessage({
    conversationId: conversation.id,
    organizationId: tenant.organizationId,
    role: 'assistant',
    content: blocksToText(result.response.blocks),
    contextSources: contextSources(workspace),
    // 'pending' either way: a clean lint is not a human review, and nothing
    // becomes 'approved' without a person saying so.
    reviewState: 'pending',
    tokenCount: result.record.outputTokens,
  });

  return {
    conversation,
    userMessage,
    assistantMessage,
    result,
    contextSummary: summarizeContext(workspace),
  };
}

/* -------------------------------------------------------------------------- */
/* Refinements                                                                */
/* -------------------------------------------------------------------------- */

export const REFINEMENTS = ['shorten', 'expand', 'translate', 'change_tone'] as const;
export type Refinement = (typeof REFINEMENTS)[number];

export function isRefinement(value: unknown): value is Refinement {
  return typeof value === 'string' && (REFINEMENTS as readonly string[]).includes(value);
}

export interface RefineInput {
  readonly refinement: Refinement;
  readonly text: string;
  readonly projectId: string | null;
  /** Target language for `translate`; target tone for `change_tone`. */
  readonly target?: string;
}

/**
 * Builds the refinement instruction.
 *
 * Each one says what must NOT change, because the common failure is a model
 * that "improves" a rewrite by inventing a statistic that was not in the source.
 */
export function buildRefinementPrompt(input: RefineInput): string {
  const preserve =
    'Do not add any fact, number, statistic, claim, name or date that is not already in the text below. ' +
    'If the text contains no numbers, your rewrite must contain no numbers.';

  const instruction: Record<Refinement, string> = {
    shorten: 'Rewrite the text below so it is meaningfully shorter while keeping every substantive point.',
    expand:
      'Expand the text below with more detail and explanation. Everything you add must follow from what is ' +
      'already there or be clearly marked as a recommendation.',
    translate: `Translate the text below into ${input.target ?? 'English'}. Keep names and product terms untranslated.`,
    change_tone: `Rewrite the text below in a ${input.target ?? 'neutral'} tone. The meaning must not change.`,
  };

  return `${instruction[input.refinement]}\n\n${preserve}\n\nTEXT:\n"""\n${input.text}\n"""`;
}

export async function refine(
  context: AiServiceContext,
  tenant: TenantContext,
  input: RefineInput,
): Promise<RunResult> {
  return runAgent(context, tenant, {
    agent: 'copilot',
    prompt: buildRefinementPrompt(input),
    projectId: input.projectId,
    // A rewrite must not be served from a cache keyed on a different source text.
    bypassCache: true,
  });
}

/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export const EXPORT_FORMATS = ['txt', 'md', 'json'] as const;
export type ExportFormat = (typeof EXPORT_FORMATS)[number];

export function isExportFormat(value: unknown): value is ExportFormat {
  return typeof value === 'string' && (EXPORT_FORMATS as readonly string[]).includes(value);
}

/**
 * Renders blocks for download.
 *
 * Markdown and JSON keep the provenance labels; plain text does not, because it
 * is the copy-and-paste format. That is a deliberate trade-off and the UI says
 * so at the point of export.
 */
export function exportBlocks(
  blocks: readonly ProvenanceBlock[],
  format: ExportFormat,
  meta: { readonly title?: string; readonly generatedAt?: string } = {},
): { readonly body: string; readonly contentType: string; readonly extension: string } {
  switch (format) {
    case 'json':
      return {
        body: JSON.stringify({ ...meta, blocks }, null, 2),
        contentType: 'application/json; charset=utf-8',
        extension: 'json',
      };
    case 'md': {
      const header = meta.title ? `# ${meta.title}\n\n` : '';
      return {
        body: header + blocksToText(blocks, { annotate: true }),
        contentType: 'text/markdown; charset=utf-8',
        extension: 'md',
      };
    }
    default:
      return {
        body: blocksToText(blocks),
        contentType: 'text/plain; charset=utf-8',
        extension: 'txt',
      };
  }
}

/** A filename that cannot escape a directory or carry a header. */
export function exportFilename(title: string, extension: string): string {
  const safe = title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
  return `${safe.length > 0 ? safe : 'sesha-export'}.${extension}`;
}

/* -------------------------------------------------------------------------- */
/* Status                                                                     */
/* -------------------------------------------------------------------------- */

export interface AiAvailability {
  readonly enabled: boolean;
  readonly agents: readonly {
    readonly id: AgentId;
    readonly label: string;
    readonly available: boolean;
    readonly phase?: string;
  }[];
}

/** What the dashboard may know: which agents exist and which are live. */
export function availability(context: AiServiceContext): AiAvailability {
  let provider: AIProvider | null = context.provider ?? null;
  if (!provider) provider = defaultProvider();

  return {
    enabled: provider !== null,
    agents: allAgents().map((agent) => ({
      id: agent.id,
      label: agent.label,
      available: agent.status === 'available',
      ...(agent.phase === undefined ? {} : { phase: agent.phase }),
    })),
  };
}

/** Resolves an explicitly requested provider, rejecting an unknown name. */
export function selectProvider(name: unknown): AIProvider | null {
  if (!isProviderName(name)) return null;
  return providerByName(name);
}
