/**
 * Account data export.
 *
 * WHAT THIS IS FOR: the right to get your data out. Under the DPDP Act in India
 * and the GDPR in Europe this is a legal obligation with a deadline, and the
 * version that satisfies it is a complete, machine-readable copy of what the
 * customer put in — not a summary, and not a PDF of some of it.
 *
 * TWO RULES SHAPE EVERY LINE BELOW.
 *
 * 1. EVERYTHING THE CUSTOMER CREATED IS INCLUDED. If they typed it, crawled it,
 *    generated it or organised it, it is in the file. An export that quietly
 *    omits a table is worse than no export, because it looks complete.
 *
 * 2. NOTHING THAT IS A CREDENTIAL IS INCLUDED, EVER. Password hashes, session
 *    token hashes, reset token hashes, share token hashes, OAuth tokens. These
 *    are not the customer's data in any useful sense — they are the means of
 *    impersonating the customer, and a data export is a file that gets emailed
 *    around, left in Downloads, and uploaded to whatever tool someone is using
 *    to read it. `assertNoCredentials()` below is the enforcement, and it runs
 *    over the finished document rather than trusting each builder.
 *
 * The export is organization-scoped, because that is the unit that owns the
 * data in this product. A member exporting gets the organization's content; the
 * personal fields are theirs alone.
 */

import type { Database } from '@/lib/db/repositories';

export const EXPORT_FORMAT_VERSION = 2;

export interface ExportContext {
  readonly db: Database;
  readonly now?: () => Date;
}

/**
 * Keys that must never appear anywhere in an export, at any depth.
 *
 * Checked by NAME, against the finished document. A builder that adds a new
 * table and forgets to strip its token column fails here rather than shipping.
 */
const FORBIDDEN_KEYS = [
  'passwordhash',
  'password',
  'tokenhash',
  'token',
  'secret',
  'apikey',
  'accesstoken',
  'refreshtoken',
  'csrftoken',
  'sessiontoken',
  'signature',
] as const;

export class ExportLeakError extends Error {
  constructor(readonly path: string) {
    super(
      `The export contained "${path}", which is a credential field. An export is a file that gets emailed around; it must never carry the means of impersonating the person it belongs to.`,
    );
    this.name = 'ExportLeakError';
  }
}

/**
 * Walks a finished export and throws if anything credential-shaped is in it.
 *
 * THE LAST LINE OF DEFENCE, and deliberately a separate pass rather than a
 * property of each builder: the builders are where the mistake gets made, so
 * the check cannot live inside them.
 */
export function assertNoCredentials(value: unknown, path = 'export'): void {
  if (value === null || typeof value !== 'object') return;

  if (Array.isArray(value)) {
    value.forEach((entry, index) => assertNoCredentials(entry, `${path}[${index}]`));
    return;
  }

  for (const [key, entry] of Object.entries(value as Record<string, unknown>)) {
    const normalised = key.toLowerCase().replace(/[-_]/g, '');
    if (FORBIDDEN_KEYS.some((forbidden) => normalised === forbidden)) {
      throw new ExportLeakError(`${path}.${key}`);
    }
    // Suffix rules, matching the logger's: `resetTokenHash`, `webhookSecret`.
    if (
      normalised.endsWith('tokenhash') ||
      normalised.endsWith('passwordhash') ||
      normalised.endsWith('secret')
    ) {
      throw new ExportLeakError(`${path}.${key}`);
    }
    assertNoCredentials(entry, `${path}.${key}`);
  }
}

export interface AccountExport {
  readonly formatVersion: number;
  readonly exportedAt: string;
  readonly about: {
    readonly product: string;
    readonly whatThisContains: string;
    readonly whatThisDoesNotContain: readonly string[];
  };
  readonly account: Record<string, unknown>;
  readonly organization: Record<string, unknown>;
  readonly people: readonly Record<string, unknown>[];
  // The two collections every account has are named, so readers need no `!`.
  readonly content: Readonly<Record<string, readonly Record<string, unknown>[]>> & {
    readonly businesses: readonly Record<string, unknown>[];
    readonly projects: readonly Record<string, unknown>[];
  };
  readonly counts: Readonly<Record<string, number>>;
}

/** Strips a row to plain JSON, dropping any field whose name is credential-shaped. */
function safeRow(row: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(row)) {
    const normalised = key.toLowerCase().replace(/[-_]/g, '');
    if (
      FORBIDDEN_KEYS.some((forbidden) => normalised === forbidden) ||
      normalised.endsWith('tokenhash') ||
      normalised.endsWith('passwordhash') ||
      normalised.endsWith('secret')
    ) {
      continue;
    }
    out[key] = value instanceof Date ? value.toISOString() : value;
  }
  return out;
}

function rows(list: readonly unknown[]): readonly Record<string, unknown>[] {
  return list.map((row) => safeRow(row as Record<string, unknown>));
}

/**
 * Builds the export.
 *
 * Reads are sequential rather than parallel on purpose: an export is a rare,
 * non-urgent operation, and firing twenty concurrent queries at the database on
 * behalf of one person is how a background task takes down a foreground one.
 */
export async function buildAccountExport(
  context: ExportContext,
  input: { readonly userId: string; readonly organizationId: string },
): Promise<AccountExport> {
  const { db } = context;
  const now = (context.now ?? (() => new Date()))();
  const organizationId = input.organizationId;

  const user = await db.users.findById(input.userId);
  const organization = await db.organizations.findById(organizationId);
  const memberships = await db.memberships.listForOrganization(organizationId);
  const businesses = await db.businesses.listForOrganization(organizationId);
  const projects = await db.projects.listForOrganization(organizationId);

  const content: Record<string, readonly Record<string, unknown>[]> = {};

  // Per-project content, flattened with the project id kept on each row so the
  // file can be read without cross-referencing.
  const perProject = async (
    name: string,
    read: (projectId: string) => Promise<readonly unknown[]>,
  ) => {
    const collected: Record<string, unknown>[] = [];
    for (const project of projects) {
      const found = await read(project.id);
      for (const row of found) collected.push(safeRow(row as Record<string, unknown>));
    }
    content[name] = collected;
  };

  await perProject('contentItems', (projectId) => db.content.listForProject(organizationId, projectId));
  await perProject('strategies', (projectId) => db.strategies.listForProject(organizationId, projectId));
  await perProject('socialPosts', (projectId) => db.socialPosts.listForProject(organizationId, projectId));
  await perProject('crawls', (projectId) => db.crawls.listForProject(organizationId, projectId));
  await perProject('audits', (projectId) => db.audits.listForProject(organizationId, projectId));
  await perProject('keywords', (projectId) => db.keywords.listForProject(organizationId, projectId));
  await perProject('competitors', (projectId) => db.competitors.listForProject(organizationId, projectId));
  await perProject('adPlans', (projectId) => db.adPlans.listForProject(organizationId, projectId));
  await perProject('leads', (projectId) => db.leads.listForProject(organizationId, projectId));
  await perProject('messagingPlans', (projectId) =>
    db.messagingPlans.listForProject(organizationId, projectId),
  );
  await perProject('videoScripts', (projectId) =>
    db.videoScripts.listForProject(organizationId, projectId),
  );
  await perProject('reports', (projectId) => db.reports.listForProject(organizationId, projectId));
  await perProject('automationRules', (projectId) =>
    db.automation.listRules(organizationId, projectId),
  );

  // Both of these are per-project singletons rather than lists.
  const brandKits: Record<string, unknown>[] = [];
  const marketingProfiles: Record<string, unknown>[] = [];
  for (const project of projects) {
    const kit = await db.brandKits.findByProject(organizationId, project.id);
    if (kit) brandKits.push(safeRow(kit as unknown as Record<string, unknown>));
    const profile = await db.marketingProfiles.findByProject(organizationId, project.id);
    if (profile) marketingProfiles.push(safeRow(profile as unknown as Record<string, unknown>));
  }
  content.brandKits = brandKits;
  content.marketingProfiles = marketingProfiles;

  const counts: Record<string, number> = {};
  for (const [name, list] of Object.entries(content)) counts[name] = list.length;
  counts.businesses = businesses.length;
  counts.projects = projects.length;
  counts.people = memberships.length;

  const document: AccountExport = {
    formatVersion: EXPORT_FORMAT_VERSION,
    exportedAt: now.toISOString(),
    about: {
      product: 'SeSha AI Marketing',
      whatThisContains:
        'Everything this organization created in SeSha: businesses, projects, content, strategies, audits, keywords, competitors, ad plans, leads, messaging plans, video scripts, reports and automation rules — plus your own account details.',
      // Stated in the file itself, so the person reading it knows what is
      // absent and why, rather than assuming the export is incomplete.
      whatThisDoesNotContain: [
        'Passwords and password hashes — these are not your data, they are the means of signing in as you.',
        'Session, reset and share tokens, for the same reason.',
        'Payment card details — SeSha never stores them; only a card brand and last four digits are kept, and they are included below if present.',
        'Other organizations’ data, including anything shared with you by another account.',
        'Internal audit records of staff activity, which are kept for security and are not part of your account.',
      ],
    },
    account: user
      ? safeRow({
          id: user.id,
          email: user.email,
          name: user.name,
          locale: user.locale,
          emailVerifiedAt: user.emailVerifiedAt,
          onboardingCompletedAt: user.onboardingCompletedAt,
          lastLoginAt: user.lastLoginAt,
          createdAt: user.createdAt,
        })
      : {},
    organization: organization ? safeRow(organization as unknown as Record<string, unknown>) : {},
    // Email and role only. A member's own content is theirs; their profile is
    // not the exporter's to take.
    people: memberships.map((membership) =>
      safeRow({ userId: membership.userId, role: membership.role, createdAt: membership.createdAt }),
    ),
    content: { ...content, businesses: rows(businesses), projects: rows(projects) },
    counts,
  };

  // The whole document, checked once, before anyone sees it.
  assertNoCredentials(document);
  return document;
}
