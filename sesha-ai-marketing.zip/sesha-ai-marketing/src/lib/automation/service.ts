/**
 * Automation service: creating, validating and running rules.
 *
 * VALIDATION HAPPENS ON EVERY WRITE, NOT ONLY ON CREATE
 * A rule edited to point at a field its trigger does not publish is a rule that
 * silently never fires again, and the person who edited it has no way to tell.
 * `checkRule` runs on create AND on update, and errors refuse the write.
 *
 * A RULE STARTS SWITCHED OFF
 * `enabled` defaults to false and turning it on is a separate, deliberate act.
 * An automation nobody chose is an automation nobody expects, and the first
 * surprise costs more trust than the feature earns.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { enforceOrThrow } from '@/lib/quota/service';
import { assertTenant, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { AutomationRuleRow, AutomationRunRow } from '@/lib/db/types';

import {
  RULE_TEMPLATES,
  checkRule,
  evaluate,
  hasRuleErrors,
  isActionKind,
  isTriggerKind,
  type Action,
  type Condition,
  type RuleProblem,
  type TriggerEvent,
  type TriggerKind,
} from './types';
import { dispatch, toRule, type DispatchResult, type EngineContext } from './engine';

export interface AutomationServiceContext extends EngineContext {
  readonly db: Database;
}

export class AutomationInputError extends Error {
  readonly code = 'INVALID_INPUT' as const;
  readonly problems: readonly RuleProblem[];
  constructor(message: string, problems: readonly RuleProblem[] = []) {
    super(message);
    this.name = 'AutomationInputError';
    this.problems = problems;
  }
}

export interface RuleInput {
  readonly name: string;
  readonly trigger: TriggerKind;
  readonly conditions: readonly Condition[];
  readonly actions: readonly Action[];
  readonly enabled?: boolean;
}

function normalise(input: RuleInput): RuleInput {
  if (!isTriggerKind(input.trigger)) {
    throw new AutomationInputError('That is not a trigger SeSha has.');
  }
  for (const action of input.actions) {
    if (!isActionKind(action.kind)) {
      throw new AutomationInputError('That is not an action SeSha can take.');
    }
  }
  return {
    name: input.name.trim(),
    trigger: input.trigger,
    conditions: input.conditions,
    actions: input.actions,
    enabled: input.enabled ?? false,
  };
}

export async function createRule(
  context: AutomationServiceContext,
  tenant: TenantContext,
  projectId: string,
  input: RuleInput,
): Promise<{ readonly rule: AutomationRuleRow; readonly warnings: readonly RuleProblem[] }> {
  requirePermission(tenant.role, 'campaign:manage');
  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  assertTenant(tenant, project, 'Project');

  // An absolute limit: how many rules may EXIST, counted across every project so
  // a customer cannot get more automations by creating more projects.
  await enforceOrThrow(context, tenant.organizationId, 'automations', {
    projectId,
    userId: tenant.userId,
  });

  const candidate = normalise(input);
  const problems = checkRule({ ...candidate, enabled: candidate.enabled ?? false });
  if (hasRuleErrors(problems)) {
    throw new AutomationInputError('That rule cannot be saved as written.', problems);
  }

  const rule = await context.db.automation.createRule({
    organizationId: tenant.organizationId,
    projectId,
    name: candidate.name,
    triggerKind: candidate.trigger,
    conditions: candidate.conditions as readonly unknown[] as readonly Readonly<Record<string, unknown>>[],
    actions: candidate.actions as readonly unknown[] as readonly Readonly<Record<string, unknown>>[],
    enabled: candidate.enabled ?? false,
    createdBy: tenant.userId,
  });

  return { rule, warnings: problems.filter((problem) => problem.severity === 'warning') };
}

export async function updateRule(
  context: AutomationServiceContext,
  tenant: TenantContext,
  id: string,
  patch: Partial<RuleInput>,
): Promise<{ readonly rule: AutomationRuleRow; readonly warnings: readonly RuleProblem[] }> {
  requirePermission(tenant.role, 'campaign:manage');
  const existing = await context.db.automation.findRule(tenant.organizationId, id);
  const row = assertTenant(tenant, existing, 'Automation');
  const current = toRule(row);

  const candidate = normalise({
    name: patch.name ?? current.name,
    trigger: patch.trigger ?? current.trigger,
    conditions: patch.conditions ?? current.conditions,
    actions: patch.actions ?? current.actions,
    enabled: patch.enabled ?? current.enabled,
  });

  // Re-validated in full, not just the changed field: changing the trigger can
  // invalidate a condition that was fine a moment ago.
  const problems = checkRule({ ...candidate, enabled: candidate.enabled ?? false });
  if (hasRuleErrors(problems)) {
    throw new AutomationInputError('That change cannot be saved.', problems);
  }

  const updated = await context.db.automation.updateRule(tenant.organizationId, id, {
    name: candidate.name,
    triggerKind: candidate.trigger,
    conditions: candidate.conditions as readonly unknown[] as readonly Readonly<Record<string, unknown>>[],
    actions: candidate.actions as readonly unknown[] as readonly Readonly<Record<string, unknown>>[],
    enabled: candidate.enabled ?? false,
  });

  return {
    rule: assertTenant(tenant, updated, 'Automation'),
    warnings: problems.filter((problem) => problem.severity === 'warning'),
  };
}

export async function removeRule(
  context: AutomationServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<void> {
  requirePermission(tenant.role, 'campaign:manage');
  const existing = await context.db.automation.findRule(tenant.organizationId, id);
  assertTenant(tenant, existing, 'Automation');
  await context.db.automation.removeRule(tenant.organizationId, id);
}

export async function listRules(
  context: AutomationServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<readonly AutomationRuleRow[]> {
  requirePermission(tenant.role, 'campaign:read');
  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  assertTenant(tenant, project, 'Project');
  return context.db.automation.listRules(tenant.organizationId, projectId);
}

export async function listRuns(
  context: AutomationServiceContext,
  tenant: TenantContext,
  ruleId: string,
  limit = 50,
): Promise<readonly AutomationRunRow[]> {
  requirePermission(tenant.role, 'campaign:read');
  const rule = await context.db.automation.findRule(tenant.organizationId, ruleId);
  assertTenant(tenant, rule, 'Automation');
  return context.db.automation.listRuns(tenant.organizationId, ruleId, limit);
}

/**
 * Creates a rule from one of the offered templates.
 *
 * Still switched off, and still validated: a template that stopped matching its
 * own trigger's fields after a refactor must fail here rather than be saved as a
 * rule that never fires.
 */
export async function createFromTemplate(
  context: AutomationServiceContext,
  tenant: TenantContext,
  projectId: string,
  templateName: string,
): Promise<AutomationRuleRow> {
  const template = RULE_TEMPLATES.find((candidate) => candidate.name === templateName);
  if (!template) throw new AutomationInputError('That is not one of the offered starting points.');
  const { rule } = await createRule(context, tenant, projectId, {
    name: template.name,
    trigger: template.trigger,
    conditions: template.conditions,
    actions: template.actions,
    enabled: false,
  });
  return rule;
}

/**
 * Fires an event at the rules listening for it.
 *
 * The entry point every other service calls — the lead service on a new lead,
 * the audit service when an audit finishes, and so on.
 */
export async function fire(
  context: AutomationServiceContext,
  organizationId: string,
  projectId: string,
  event: TriggerEvent,
  ownerUserId?: string,
): Promise<readonly DispatchResult[]> {
  return dispatch(context, organizationId, projectId, event, {
    ...(ownerUserId ? { ownerUserId } : {}),
  });
}

/**
 * Runs a rule against a made-up event without writing anything.
 *
 * The "will this do what I think" button, and the decision it makes is the same
 * one a real run makes: `evaluate` is the same function `dispatch` calls, so
 * there is no second implementation to drift.
 *
 * IT TESTS A DISABLED RULE AS THOUGH IT WERE ON. Going through `dispatch` would
 * have been tidier, but `dispatch` reads the ENABLED rules — and every rule
 * starts disabled, so the preview would have answered "the rule is switched off"
 * for the one case it exists to serve: checking a rule before turning it on.
 * `enabledForPreview` says which state was assumed, so the answer cannot be
 * misread as "this is running".
 */
export interface RuleTestResult extends DispatchResult {
  /** True when the stored rule is off and the preview assumed it were on. */
  readonly enabledForPreview: boolean;
}

export async function testRule(
  context: AutomationServiceContext,
  tenant: TenantContext,
  ruleId: string,
  payload: Readonly<Record<string, string | number | boolean | null>>,
): Promise<RuleTestResult> {
  requirePermission(tenant.role, 'campaign:read');
  const row = await context.db.automation.findRule(tenant.organizationId, ruleId);
  const stored = assertTenant(tenant, row, 'Automation');
  const rule = toRule(stored);

  const outcome = evaluate(
    { ...rule, enabled: true },
    { kind: rule.trigger, payload },
  );

  return {
    ruleId: rule.id,
    ruleName: rule.name,
    enabledForPreview: !rule.enabled,
    ...(outcome.matched
      ? { matched: true as const, actions: outcome.actions }
      : { matched: false as const, reason: outcome.reason, actions: [] }),
  };
}
