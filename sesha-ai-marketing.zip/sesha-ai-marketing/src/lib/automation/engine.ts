/**
 * The automation engine: turning a matched rule into things a person can act on.
 *
 * `evaluate()` in ./types.ts decides. This module DOES, and the separation is
 * what makes a dry run identical to a real one.
 *
 * WHAT "DOING" MEANS HERE
 * Six actions, and every one of them writes a row that waits for a human: a task,
 * a follow-up on a lead, an in-app notification, a content suggestion, a calendar
 * entry, a recommendation. Nothing is sent, published or spent, because SeSha
 * cannot do those things — and `isOutboundAction` is asserted over the whole
 * action list before anything runs, so an action added without that boundary in
 * mind fails loudly rather than quietly reaching someone.
 *
 * THE CEILING IS PER ORGANIZATION AND COUNTS SKIPS
 * A runaway rule costs work even when it matches nothing: every evaluation is a
 * row. `MAX_RUNS_PER_DAY` counts runs, not actions, so the limit binds on the
 * thing that actually runs away.
 */

import type { Database } from '@/lib/db/repositories';
import type { AutomationRuleRow, AutomationRunRow } from '@/lib/db/types';

import {
  MAX_RUNS_PER_DAY,
  evaluate,
  isActionKind,
  isOutboundAction,
  type Action,
  type AutomationRule,
  type Condition,
  type PlannedAction,
  type TriggerEvent,
  type TriggerKind,
} from './types';
import { shouldNotify, resolvePreferences, type NotificationKind } from '@/lib/notifications/types';

export interface EngineContext {
  readonly db: Database;
  readonly now?: () => Date;
}

function clock(context: EngineContext): Date {
  return context.now?.() ?? new Date();
}

/** A stored rule, as the domain functions expect it. */
export function toRule(row: AutomationRuleRow): AutomationRule {
  return {
    id: row.id,
    name: row.name,
    trigger: row.triggerKind as TriggerKind,
    // The jsonb columns come back as plain records. They were validated by
    // `checkRule` before they were written and are re-validated by `checkRule`
    // on every update, so the narrowing here is a restatement of an invariant
    // the service enforces rather than a hope about the data.
    conditions: row.conditions as readonly unknown[] as readonly Condition[],
    actions: row.actions as readonly unknown[] as readonly Action[],
    enabled: row.enabled,
  };
}

export interface DispatchResult {
  readonly ruleId: string;
  readonly ruleName: string;
  readonly matched: boolean;
  readonly reason?: string;
  readonly actions: readonly PlannedAction[];
}

export interface DispatchOptions {
  /** Decide but write nothing. Used by the "test this rule" button. */
  readonly dryRun?: boolean;
  /** Who the resulting notifications and tasks belong to. */
  readonly ownerUserId?: string;
}

/**
 * Runs every enabled rule listening for one event.
 *
 * Returns a result per rule, INCLUDING the ones that did not match, and records
 * each of them. A rule that quietly stops matching is otherwise invisible.
 */
export async function dispatch(
  context: EngineContext,
  organizationId: string,
  projectId: string,
  event: TriggerEvent,
  options: DispatchOptions = {},
): Promise<readonly DispatchResult[]> {
  const now = clock(context);
  const rows = await context.db.automation.listEnabledFor(organizationId, projectId, event.kind);
  if (rows.length === 0) return [];

  const dayStart = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  const alreadyRun = await context.db.automation.countRunsSince(organizationId, dayStart);
  const results: DispatchResult[] = [];
  let budget = MAX_RUNS_PER_DAY - alreadyRun;

  for (const row of rows) {
    const rule = toRule(row);

    if (budget <= 0) {
      // Recorded, not silently dropped: the person who built the rule has to be
      // able to find out that it stopped because of a ceiling rather than a bug.
      results.push({
        ruleId: rule.id,
        ruleName: rule.name,
        matched: false,
        reason: `The daily automation ceiling of ${MAX_RUNS_PER_DAY} runs was reached, so this rule was not evaluated.`,
        actions: [],
      });
      if (!options.dryRun) {
        await recordRun(context, organizationId, rule, event, {
          matched: false,
          reason: `Daily ceiling of ${MAX_RUNS_PER_DAY} runs reached.`,
          actions: [],
        }, now);
      }
      continue;
    }

    const outcome = evaluate(rule, event);
    budget -= 1;

    if (!outcome.matched) {
      results.push({ ruleId: rule.id, ruleName: rule.name, matched: false, reason: outcome.reason, actions: [] });
      if (!options.dryRun) {
        await recordRun(context, organizationId, rule, event, { matched: false, reason: outcome.reason, actions: [] }, now);
      }
      continue;
    }

    if (!options.dryRun) {
      for (const action of outcome.actions) {
        await perform(context, organizationId, projectId, action, event, options, now);
      }
      await recordRun(context, organizationId, rule, event, { matched: true, actions: outcome.actions }, now);
    }
    results.push({ ruleId: rule.id, ruleName: rule.name, matched: true, actions: outcome.actions });
  }

  return results;
}

async function recordRun(
  context: EngineContext,
  organizationId: string,
  rule: AutomationRule,
  event: TriggerEvent,
  outcome: { matched: boolean; reason?: string; actions: readonly PlannedAction[] },
  at: Date,
): Promise<AutomationRunRow> {
  return context.db.automation.recordRun({
    organizationId,
    ruleId: rule.id,
    triggerKind: event.kind,
    subjectId: event.subjectId ?? null,
    matched: outcome.matched,
    skipReason: outcome.matched ? null : (outcome.reason ?? 'No reason recorded.'),
    actionsTaken: outcome.actions.map((action) => ({
      kind: action.kind,
      text: action.text,
      offsetDays: action.offsetDays,
    })),
    ranAt: at,
  });
}

/**
 * Carries out one action.
 *
 * The guard at the top is not defensive coding for its own sake: it is the
 * single place where an action that could reach a third party would have to get
 * through, and it refuses rather than falling through to a default.
 */
async function perform(
  context: EngineContext,
  organizationId: string,
  projectId: string,
  action: PlannedAction,
  event: TriggerEvent,
  options: DispatchOptions,
  now: Date,
): Promise<void> {
  if (!isActionKind(action.kind) || isOutboundAction(action.kind)) {
    throw new Error(
      'An automation attempted an action that would reach a third party. SeSha cannot contact anyone automatically.',
    );
  }

  const dueDate = new Date(now.getTime() + action.offsetDays * 86_400_000);

  switch (action.kind) {
    case 'create_follow_up': {
      // A follow-up is an activity with a due date on the lead that fired the
      // rule. Without a lead there is nothing to attach it to, so it becomes a
      // notification instead of being silently dropped.
      if (!event.subjectId) {
        await notify(context, organizationId, projectId, 'new_lead', action, options, now);
        return;
      }
      await context.db.leadActivities.create({
        organizationId,
        leadId: event.subjectId,
        createdBy: null,
        kind: 'follow_up',
        note: `${action.text} (from the automation "${action.ruleName}")`,
        occurredAt: now,
        dueAt: dueDate,
        completedAt: null,
        fromStage: null,
        toStage: null,
      });
      return;
    }

    case 'add_calendar_entry': {
      await context.db.calendar.create({
        organizationId,
        projectId,
        kind: kindForTrigger(event.kind),
        title: action.text.slice(0, 200),
        notes: `Added by the automation "${action.ruleName}". Nothing fires on this date.`,
        eventDate: dueDate.toISOString().slice(0, 10),
        status: 'planned',
        origin: 'derived',
        sourceKind: 'audit_finding',
        sourceId: event.subjectId ?? null,
        campaign: null,
        createdBy: null,
      });
      return;
    }

    case 'create_task':
    case 'suggest_content':
    case 'recommend':
    case 'notify': {
      // All four surface as an in-app notification today. They are kept as
      // separate action kinds because they mean different things to the person
      // building the rule, and because the surfaces they will land on
      // (a task list, Content Studio) are the natural homes for them later.
      await notify(context, organizationId, projectId, notificationKindFor(event.kind), action, options, now);
      return;
    }
  }
}

function notificationKindFor(trigger: TriggerKind): NotificationKind {
  switch (trigger) {
    case 'lead_created':
    case 'lead_stage_changed':
    case 'lead_went_quiet':
      return 'new_lead';
    case 'campaign_plan_declined':
      return 'campaign_changed';
    case 'schema_error_found':
    case 'structured_data_lost':
      return 'schema_error';
    case 'crawl_completed':
      return 'crawl_complete';
    case 'audit_completed':
      return 'audit_complete';
    case 'validation_completed':
      return 'validation_complete';
    case 'content_approved':
      return 'content_scheduled';
  }
}

function kindForTrigger(trigger: TriggerKind): string {
  switch (trigger) {
    case 'schema_error_found':
    case 'structured_data_lost':
    case 'validation_completed':
      return 'schema_task';
    case 'audit_completed':
    case 'crawl_completed':
      return 'seo_task';
    case 'content_approved':
      return 'blog';
    case 'campaign_plan_declined':
      return 'ads';
    default:
      return 'event';
  }
}

/**
 * Writes a notification — through `shouldNotify`, like everything else.
 *
 * An automation does not get to bypass the user's preferences on the grounds
 * that they asked for the automation. Those are two different decisions: "run
 * this rule" and "tell me every time it runs".
 */
async function notify(
  context: EngineContext,
  organizationId: string,
  projectId: string,
  kind: NotificationKind,
  action: PlannedAction,
  options: DispatchOptions,
  now: Date,
): Promise<void> {
  const userId = options.ownerUserId;
  if (!userId) return;

  const stored = await context.db.notificationPreferences.listForUser(organizationId, userId);
  const decision = shouldNotify(kind, resolvePreferences(stored));
  if (!decision.send) return;

  await context.db.notifications.create({
    organizationId,
    userId,
    projectId,
    kind,
    title: action.text.slice(0, 120),
    body: `From the automation "${action.ruleName}". Nothing was sent to anyone; this is waiting for you.`,
    actionUrl: null,
  });
  void now;
}
