/**
 * The automation engine: Trigger → Condition → Action.
 *
 * THE BOUNDARY THAT DEFINES THIS FILE
 * An automation engine in a marketing product is normally a machine for sending
 * things to people without a human in the loop. This one cannot be, and the reason
 * is not caution — it is that the capability genuinely does not exist. SeSha
 * cannot send email or WhatsApp (Phase 5), cannot publish to a social platform
 * (Phase 3), and cannot spend money on ads (Phase 5).
 *
 * So the action vocabulary is closed, and every member of it produces something a
 * person then acts on: a task, a draft, a notification, a calendar entry, a
 * recommendation. `ACTION_KINDS` is the whole list, `isOutboundAction` exists to
 * assert that none of them is outbound, and `tests/automation.test.ts` fails if a
 * new action is added that could reach a third party.
 *
 * This matters more than it looks. "Inactive customer → re-engagement" is one of
 * the brief's own examples, and the obvious implementation is to send a
 * re-engagement email. The honest implementation drafts one and tells a person it
 * is waiting — which is also the only version that is lawful under the opt-in
 * rules Phase 5 enforces.
 *
 * EVERY RUN IS RECORDED, INCLUDING THE ONES THAT DID NOTHING
 * A rule that quietly stops matching is indistinguishable from a rule that never
 * runs, unless the non-matches are recorded too. `AutomationOutcome` has a
 * `skipped` variant carrying which condition failed.
 *
 * Framework-free and fully unit tested.
 */

/* -------------------------------------------------------------------------- */
/* Triggers                                                                   */
/* -------------------------------------------------------------------------- */

/**
 * The events a rule can fire on.
 *
 * Each one corresponds to something that genuinely happens inside SeSha. There
 * is no `campaign_performance_dropped` trigger, because no ad account is
 * connected and a trigger that can never fire is a promise on a settings screen.
 * `campaign_plan_declined` is the honest version of the brief's "campaign
 * decline": it fires when a person rejects a plan in review, which is an event
 * this product actually has.
 */
export const TRIGGER_KINDS = [
  'lead_created',
  'lead_stage_changed',
  'lead_went_quiet',
  'content_approved',
  'campaign_plan_declined',
  'schema_error_found',
  'structured_data_lost',
  'crawl_completed',
  'audit_completed',
  'validation_completed',
] as const;

export type TriggerKind = (typeof TRIGGER_KINDS)[number];

export const TRIGGER_LABEL: Readonly<Record<TriggerKind, string>> = {
  lead_created: 'A new lead arrives',
  lead_stage_changed: 'A lead moves stage',
  lead_went_quiet: 'A lead has had no activity for a while',
  content_approved: 'A piece of content is approved',
  campaign_plan_declined: 'A campaign plan is rejected in review',
  schema_error_found: 'A structured-data error is found',
  structured_data_lost: 'Markup that used to be on a page is gone',
  crawl_completed: 'A crawl finishes',
  audit_completed: 'An audit finishes',
  validation_completed: 'A validation finishes',
};

export function isTriggerKind(value: unknown): value is TriggerKind {
  return typeof value === 'string' && (TRIGGER_KINDS as readonly string[]).includes(value);
}

/* -------------------------------------------------------------------------- */
/* Conditions                                                                 */
/* -------------------------------------------------------------------------- */

export type ConditionOperator =
  | 'equals'
  | 'not_equals'
  | 'greater_than'
  | 'less_than'
  | 'contains'
  | 'is_set'
  | 'is_not_set';

export const OPERATOR_LABEL: Readonly<Record<ConditionOperator, string>> = {
  equals: 'is',
  not_equals: 'is not',
  greater_than: 'is more than',
  less_than: 'is less than',
  contains: 'contains',
  is_set: 'is set',
  is_not_set: 'is not set',
};

export interface Condition {
  /** A field on the trigger's own payload. Never a free-form expression. */
  readonly field: string;
  readonly operator: ConditionOperator;
  readonly value?: string | number;
}

/**
 * The fields each trigger publishes.
 *
 * Declared rather than inferred so the interface can offer a real list and a rule
 * cannot be saved against a field that will never exist. A condition on a
 * misspelled field is a rule that silently never fires.
 */
export const TRIGGER_FIELDS: Readonly<Record<TriggerKind, readonly string[]>> = {
  lead_created: ['source', 'score', 'stage', 'company', 'email', 'phone'],
  lead_stage_changed: ['fromStage', 'toStage', 'score', 'source'],
  lead_went_quiet: ['stage', 'score', 'daysSinceActivity', 'source'],
  content_approved: ['format', 'language', 'title'],
  campaign_plan_declined: ['platform', 'objective', 'campaignName'],
  schema_error_found: ['check', 'type', 'pageUrl', 'severity'],
  structured_data_lost: ['pageUrl', 'typesLost'],
  crawl_completed: ['pagesCrawled', 'pagesFailed', 'stoppedEarly'],
  audit_completed: ['kind', 'score', 'findingCount'],
  validation_completed: ['overallStatus', 'invalidCount', 'sourceUrl'],
};

/* -------------------------------------------------------------------------- */
/* Actions                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * What a rule may do. THE COMPLETE LIST.
 *
 * Every one produces something for a person. None of them contacts anybody, posts
 * anything or spends anything, because SeSha cannot do those things — and an
 * action that pretended to would be the dishonesty this whole codebase is built
 * to avoid, automated.
 */
export const ACTION_KINDS = [
  'create_task',
  'create_follow_up',
  'notify',
  'suggest_content',
  'add_calendar_entry',
  'recommend',
] as const;

export type ActionKind = (typeof ACTION_KINDS)[number];

export const ACTION_LABEL: Readonly<Record<ActionKind, string>> = {
  create_task: 'Create a task',
  create_follow_up: 'Create a follow-up on the lead',
  notify: 'Send an in-app notification',
  suggest_content: 'Suggest a piece of content',
  add_calendar_entry: 'Add a calendar entry',
  recommend: 'Record a recommendation',
};

/**
 * What each action actually does, in the words the interface shows when someone
 * is building a rule. The phrasing is deliberate: a person choosing
 * "Create a follow-up" should not be able to believe it sends anything.
 */
export const ACTION_EFFECT: Readonly<Record<ActionKind, string>> = {
  create_task: 'Adds a task to your list. Nothing is sent and nothing changes on your website.',
  create_follow_up:
    'Adds a dated follow-up to the lead, so it appears in what is due. It does not contact the lead — SeSha cannot send email or WhatsApp.',
  notify: 'Shows a notification inside SeSha to the people who asked for this kind.',
  suggest_content:
    'Drafts a suggestion in Content Studio for someone to write. It does not publish anything.',
  add_calendar_entry: 'Puts a planned entry on the marketing calendar. Nothing fires on that date.',
  recommend: 'Records a recommendation with its reasoning, for a person to accept or ignore.',
};

export function isActionKind(value: unknown): value is ActionKind {
  return typeof value === 'string' && (ACTION_KINDS as readonly string[]).includes(value);
}

/**
 * Whether an action would reach a third party.
 *
 * Always false for every current action — which is the point. This exists so the
 * gate test can assert it over the whole list rather than over the ones someone
 * remembered to check, and so that adding an outbound action means deliberately
 * making this return true.
 */
export function isOutboundAction(kind: ActionKind): boolean {
  const outbound: readonly ActionKind[] = [];
  return (outbound as readonly string[]).includes(kind);
}

export interface Action {
  readonly kind: ActionKind;
  /** What the task, notification or suggestion says. Templated with {{field}}. */
  readonly template: string;
  /** For a follow-up or calendar entry: how many days ahead. */
  readonly offsetDays?: number;
}

/* -------------------------------------------------------------------------- */
/* Rules                                                                      */
/* -------------------------------------------------------------------------- */

export interface AutomationRule {
  readonly id: string;
  readonly name: string;
  readonly trigger: TriggerKind;
  /** ALL conditions must hold. An empty list means the rule always fires. */
  readonly conditions: readonly Condition[];
  readonly actions: readonly Action[];
  readonly enabled: boolean;
}

export interface RuleProblem {
  readonly severity: 'error' | 'warning';
  readonly field: string;
  readonly message: string;
}

/** How many times a rule may fire for one organization in a day. */
export const MAX_RUNS_PER_DAY = 200;

export function checkRule(rule: Omit<AutomationRule, 'id'>): readonly RuleProblem[] {
  const problems: RuleProblem[] = [];

  if (rule.name.trim().length === 0) {
    problems.push({ severity: 'error', field: 'name', message: 'The rule needs a name.' });
  }
  if (!isTriggerKind(rule.trigger)) {
    problems.push({ severity: 'error', field: 'trigger', message: 'That is not a trigger SeSha has.' });
    return problems;
  }

  const fields = TRIGGER_FIELDS[rule.trigger];
  for (const condition of rule.conditions) {
    if (!fields.includes(condition.field)) {
      problems.push({
        severity: 'error',
        field: 'conditions',
        message: `"${TRIGGER_LABEL[rule.trigger]}" does not publish a field called "${condition.field}". A condition on a field that never exists is a rule that silently never fires.`,
      });
    }
    const needsValue = condition.operator !== 'is_set' && condition.operator !== 'is_not_set';
    if (needsValue && (condition.value === undefined || condition.value === '')) {
      problems.push({
        severity: 'error',
        field: 'conditions',
        message: `"${OPERATOR_LABEL[condition.operator]}" needs a value to compare against.`,
      });
    }
    if (
      (condition.operator === 'greater_than' || condition.operator === 'less_than') &&
      typeof condition.value === 'string' &&
      Number.isNaN(Number(condition.value))
    ) {
      problems.push({
        severity: 'error',
        field: 'conditions',
        message: `"${condition.value}" is not a number, so it cannot be compared with more-than or less-than.`,
      });
    }
  }

  if (rule.actions.length === 0) {
    problems.push({ severity: 'error', field: 'actions', message: 'A rule that does nothing is not a rule.' });
  }
  for (const action of rule.actions) {
    if (!isActionKind(action.kind)) {
      problems.push({ severity: 'error', field: 'actions', message: 'That is not an action SeSha can take.' });
      continue;
    }
    if (isOutboundAction(action.kind)) {
      problems.push({
        severity: 'error',
        field: 'actions',
        message: 'SeSha cannot contact anyone automatically. No action may reach a third party.',
      });
    }
    if (action.template.trim().length === 0) {
      problems.push({
        severity: 'error',
        field: 'actions',
        message: `"${ACTION_LABEL[action.kind]}" needs wording, or the task it creates says nothing.`,
      });
    }
    for (const token of templateTokens(action.template)) {
      if (!fields.includes(token)) {
        problems.push({
          severity: 'warning',
          field: 'actions',
          message: `The wording uses {{${token}}}, which "${TRIGGER_LABEL[rule.trigger]}" does not provide. It will be left blank.`,
        });
      }
    }
    if ((action.kind === 'create_follow_up' || action.kind === 'add_calendar_entry') && action.offsetDays === undefined) {
      problems.push({
        severity: 'warning',
        field: 'actions',
        message: `"${ACTION_LABEL[action.kind]}" has no offset, so it will be dated today.`,
      });
    }
  }

  if (rule.conditions.length === 0 && rule.trigger === 'lead_created') {
    problems.push({
      severity: 'warning',
      field: 'conditions',
      message: 'With no conditions this fires for every lead, including the ones with no contact details.',
    });
  }

  return problems;
}

export function hasRuleErrors(problems: readonly RuleProblem[]): boolean {
  return problems.some((problem) => problem.severity === 'error');
}

export function templateTokens(template: string): string[] {
  return [...template.matchAll(/\{\{\s*([a-zA-Z][a-zA-Z0-9_]*)\s*\}\}/g)].map((match) => match[1]!);
}

/* -------------------------------------------------------------------------- */
/* Evaluation                                                                 */
/* -------------------------------------------------------------------------- */

export type TriggerPayload = Readonly<Record<string, string | number | boolean | null>>;

export interface TriggerEvent {
  readonly kind: TriggerKind;
  readonly payload: TriggerPayload;
  /** The record that fired it, so an action can link back. */
  readonly subjectId?: string;
  readonly projectId?: string;
}

export interface PlannedAction {
  readonly kind: ActionKind;
  readonly text: string;
  readonly offsetDays: number;
  /** The rule that produced it, so every outcome is attributable. */
  readonly ruleId: string;
  readonly ruleName: string;
}

export type AutomationOutcome =
  | { readonly matched: true; readonly actions: readonly PlannedAction[] }
  | {
      readonly matched: false;
      /** Which condition failed, in words. Recorded so a silent rule is visible. */
      readonly reason: string;
    };

/**
 * Evaluates one rule against one event.
 *
 * Returns the actions it WOULD take; it does not take them. Deciding and doing are
 * separate so the decision can be tested without a database, and so a dry run is
 * the same code path as a real one.
 */
export function evaluate(rule: AutomationRule, event: TriggerEvent): AutomationOutcome {
  if (!rule.enabled) return { matched: false, reason: 'The rule is switched off.' };
  if (rule.trigger !== event.kind) {
    return { matched: false, reason: `This rule listens for "${TRIGGER_LABEL[rule.trigger]}".` };
  }

  for (const condition of rule.conditions) {
    const held = conditionHolds(condition, event.payload);
    if (!held) {
      const actual = event.payload[condition.field];
      return {
        matched: false,
        reason: `The condition "${condition.field} ${OPERATOR_LABEL[condition.operator]}${
          condition.value !== undefined ? ` ${condition.value}` : ''
        }" did not hold (it was ${actual === undefined || actual === null ? 'not set' : String(actual)}).`,
      };
    }
  }

  return {
    matched: true,
    actions: rule.actions.map((action) => ({
      kind: action.kind,
      text: render(action.template, event.payload),
      offsetDays: action.offsetDays ?? 0,
      ruleId: rule.id,
      ruleName: rule.name,
    })),
  };
}

export function conditionHolds(condition: Condition, payload: TriggerPayload): boolean {
  const actual = payload[condition.field];

  switch (condition.operator) {
    case 'is_set':
      return actual !== undefined && actual !== null && actual !== '';
    case 'is_not_set':
      return actual === undefined || actual === null || actual === '';
    case 'equals':
      return String(actual ?? '') === String(condition.value ?? '');
    case 'not_equals':
      return String(actual ?? '') !== String(condition.value ?? '');
    case 'contains':
      return String(actual ?? '')
        .toLowerCase()
        .includes(String(condition.value ?? '').toLowerCase());
    case 'greater_than': {
      const left = numeric(actual);
      const right = numeric(condition.value);
      // A non-numeric comparison is FALSE, not an error: a rule whose field
      // arrived as text should not fire, and should not crash the worker either.
      return left !== null && right !== null && left > right;
    }
    case 'less_than': {
      const left = numeric(actual);
      const right = numeric(condition.value);
      return left !== null && right !== null && left < right;
    }
  }
}

/**
 * A value as a number, or null when it is not one.
 *
 * `Number()` on its own is a trap here, and the trap bites in the direction that
 * makes rules fire wrongly: `Number(null)`, `Number('')` and `Number(false)` are
 * all 0, so "days since activity is less than 5" was TRUE for a lead whose field
 * was missing entirely. That is a re-engagement task created for every lead with
 * no data — found by a test, not by reasoning about it.
 */
function numeric(value: string | number | boolean | null | undefined): number | null {
  if (value === null || value === undefined) return null;
  if (typeof value === 'boolean') return null;
  if (typeof value === 'string' && value.trim() === '') return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

/** Fills {{field}} from the payload. An unknown token becomes an empty string. */
export function render(template: string, payload: TriggerPayload): string {
  return template.replace(/\{\{\s*([a-zA-Z][a-zA-Z0-9_]*)\s*\}\}/g, (_match, token: string) => {
    const value = payload[token];
    return value === undefined || value === null ? '' : String(value);
  });
}

/* -------------------------------------------------------------------------- */
/* Starting points                                                            */
/* -------------------------------------------------------------------------- */

/**
 * The brief's six examples, as rules a person can enable.
 *
 * Offered as templates rather than switched on by default: an automation nobody
 * chose is an automation nobody expects, and the first surprise costs more trust
 * than the feature earns.
 */
export const RULE_TEMPLATES: readonly {
  readonly name: string;
  readonly description: string;
  readonly trigger: TriggerKind;
  readonly conditions: readonly Condition[];
  readonly actions: readonly Action[];
}[] = [
  {
    name: 'New lead → follow up',
    description: 'When a lead arrives, put a follow-up on it for tomorrow.',
    trigger: 'lead_created',
    conditions: [{ field: 'email', operator: 'is_set' }],
    actions: [
      {
        kind: 'create_follow_up',
        template: 'Follow up with this {{source}} enquiry.',
        offsetDays: 1,
      },
    ],
  },
  {
    name: 'New article → social suggestion',
    description: 'When an article is approved, suggest a post about it.',
    trigger: 'content_approved',
    conditions: [{ field: 'format', operator: 'equals', value: 'blog' }],
    actions: [
      {
        kind: 'suggest_content',
        template: 'Draft a social post pointing at "{{title}}".',
      },
    ],
  },
  {
    name: 'Campaign plan rejected → recommendation',
    description: 'When a campaign plan is rejected in review, record what to reconsider.',
    trigger: 'campaign_plan_declined',
    conditions: [],
    actions: [
      {
        kind: 'recommend',
        template: 'Revisit the {{platform}} plan "{{campaignName}}": check the offer and the landing page before rewriting the copy.',
      },
    ],
  },
  {
    name: 'Lead went quiet → re-engagement draft',
    description:
      'When a lead has had no activity for a fortnight, draft something to send them yourself.',
    trigger: 'lead_went_quiet',
    conditions: [{ field: 'daysSinceActivity', operator: 'greater_than', value: 14 }],
    actions: [
      {
        kind: 'create_task',
        template: 'This lead has been quiet for {{daysSinceActivity}} days. Decide whether to re-engage or close it.',
      },
    ],
  },
  {
    name: 'Schema error → technical task',
    description: 'When a structured-data error is found, make a task to fix it.',
    trigger: 'schema_error_found',
    conditions: [],
    actions: [
      {
        kind: 'create_task',
        template: 'Fix the structured-data error "{{check}}" on {{pageUrl}}.',
      },
    ],
  },
  {
    name: 'Structured data disappeared → notify',
    description: 'When markup that used to be on a page is gone, tell someone.',
    trigger: 'structured_data_lost',
    conditions: [],
    actions: [
      {
        kind: 'notify',
        template: 'Markup is missing from {{pageUrl}} — it previously published {{typesLost}}.',
      },
    ],
  },
];
