/**
 * Tenant isolation.
 *
 * THE INVARIANT
 * Every row that belongs to a customer carries an `organizationId`. No query
 * and no response may ever cross that boundary. This module is the chokepoint
 * that enforces it in application code; PostgreSQL row-level security in
 * db/schema.sql enforces it again independently, so a repository that forgets
 * the filter still cannot leak.
 *
 * WHY CROSS-TENANT ACCESS RETURNS "NOT FOUND", NOT "FORBIDDEN"
 * A 403 confirms the resource exists. Given sequential or guessable ids, that
 * turns an authorization check into an enumeration oracle: an attacker learns
 * which project ids are real and roughly how many customers you have. Returning
 * 404 for "exists but is not yours" and for "does not exist" makes the two
 * indistinguishable.
 *
 * Framework-free and fully unit tested.
 */

import { AuthorizationError, requirePermission, type Permission, type Role } from '@/lib/auth/rbac';

export interface TenantContext {
  readonly userId: string;
  readonly organizationId: string;
  readonly role: Role;
  /** The project currently in scope, when the request is project-scoped. */
  readonly projectId?: string;
}

/** Any row that is owned by an organization. */
export interface TenantOwned {
  readonly organizationId: string;
}

/** Any row that additionally belongs to a project. */
export interface ProjectOwned extends TenantOwned {
  readonly projectId: string;
}

export class NotFoundError extends Error {
  readonly code = 'NOT_FOUND' as const;

  constructor(resource = 'Resource') {
    super(`${resource} not found.`);
    this.name = 'NotFoundError';
  }
}

/**
 * Asserts a row belongs to the caller's organization.
 *
 * Returns the row narrowed to non-null so call sites read as:
 *   const project = assertTenant(ctx, await repo.findById(id), 'Project');
 */
export function assertTenant<T extends TenantOwned>(
  context: TenantContext,
  row: T | null | undefined,
  resource = 'Resource',
): T {
  if (!row) throw new NotFoundError(resource);
  if (row.organizationId !== context.organizationId) {
    // Deliberately the same error as "missing" — see the note above.
    throw new NotFoundError(resource);
  }
  return row;
}

/** Asserts a row belongs to the caller's organization AND to a given project. */
export function assertProject<T extends ProjectOwned>(
  context: TenantContext,
  row: T | null | undefined,
  projectId: string,
  resource = 'Resource',
): T {
  const owned = assertTenant(context, row, resource);
  if (owned.projectId !== projectId) throw new NotFoundError(resource);
  return owned;
}

/**
 * The standard guard for a scoped operation: check the permission, then check
 * ownership. Permission first, because a user without the permission should not
 * learn whether the resource exists either.
 */
export function authorize<T extends TenantOwned>(
  context: TenantContext,
  permission: Permission,
  row: T | null | undefined,
  resource = 'Resource',
): T {
  requirePermission(context.role, permission);
  return assertTenant(context, row, resource);
}

/**
 * Filters a collection to the caller's organization.
 *
 * A repository should never return foreign rows in the first place — this is a
 * belt-and-braces filter for list endpoints, and `tests/authz.test.ts` asserts
 * it drops foreign rows silently rather than throwing (a list with one foreign
 * row should return the caller's rows, not fail the whole request).
 */
export function filterTenant<T extends TenantOwned>(
  context: TenantContext,
  rows: readonly T[],
): T[] {
  return rows.filter((row) => row.organizationId === context.organizationId);
}

/**
 * Builds the mandatory WHERE clause fragment for a tenant-scoped query.
 * Repositories use this so the filter is never hand-written and never omitted.
 */
export function tenantFilter(context: TenantContext): { organization_id: string } {
  return { organization_id: context.organizationId };
}

/**
 * The PostgreSQL session variable that row-level security reads.
 * Set on every connection checkout, after authentication, before any query.
 */
export const RLS_SETTING = 'app.current_organization';

export function rlsStatement(organizationId: string): { text: string; values: string[] } {
  // Parameterised: never interpolate an id into SQL, even one you trust.
  return { text: `SELECT set_config($1, $2, true)`, values: [RLS_SETTING, organizationId] };
}

export function isTenantError(error: unknown): error is NotFoundError | AuthorizationError {
  return error instanceof NotFoundError || error instanceof AuthorizationError;
}
