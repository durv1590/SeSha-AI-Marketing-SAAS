/**
 * The lead pipeline.
 *
 * THE SCORE IS THE INTERESTING PART
 * Every CRM shows a lead score. Almost none of them can tell you why. An opaque
 * number — "87" — is the same dishonesty as a fabricated search volume: it looks
 * like a measurement and is actually an opinion with the reasoning thrown away.
 *
 * So `LeadScore` carries its components. Each one names what it looked at, how
 * many points it contributed and why. The total is the sum of the parts shown, and
 * the tests assert that: a score whose components do not add up to
 * its total is a bug, not a rounding detail (`tests/marketing-ops.test.ts`). There is no machine-learning model
 * here and the interface does not imply one.
 *
 * Framework-free and fully unit tested.
 */

/** The seven stages from the brief, in order. */
export const LEAD_STAGES = [
  'new',
  'contacted',
  'qualified',
  'proposal',
  'negotiation',
  'won',
  'lost',
] as const;

export type LeadStage = (typeof LEAD_STAGES)[number];

export const STAGE_LABEL: Readonly<Record<LeadStage, string>> = {
  new: 'New',
  contacted: 'Contacted',
  qualified: 'Qualified',
  proposal: 'Proposal',
  negotiation: 'Negotiation',
  won: 'Won',
  lost: 'Lost',
};

export const TERMINAL_STAGES: readonly LeadStage[] = ['won', 'lost'];

export function isTerminal(stage: LeadStage): boolean {
  return TERMINAL_STAGES.includes(stage);
}

/**
 * Legal stage moves.
 *
 * Forward one step, or to `lost` from any open stage, or back one step — because a
 * salesperson mis-clicked, and an irreversible pipeline is a pipeline people keep
 * shadow copies of in a spreadsheet.
 *
 * What is NOT allowed is jumping from `new` to `won`: a deal nobody ever contacted
 * did not happen, and pipeline reporting built on that is worthless. Nor is
 * `lost` → `won`, which is the same edit with the evidence removed.
 */
export function canTransition(from: LeadStage, to: LeadStage): boolean {
  if (from === to) return false;
  if (isTerminal(from)) {
    // A closed deal can be reopened into the working pipeline, and a Won deal that
    // later falls through can be marked Lost — a cancelled order is ordinary, and
    // the stage-change activity records that it was Won first, so the history is
    // not lost by allowing it.
    //
    // What is still refused is Lost → Won directly: a deal recorded as lost and
    // then quietly marked won, with no record of the conversation in between, is
    // the pipeline edit that makes reporting indefensible.
    if (to === 'lost') return from === 'won';
    return to === 'contacted' || to === 'qualified' || to === 'negotiation' || to === 'proposal';
  }
  if (to === 'lost') return true;

  const order: readonly LeadStage[] = ['new', 'contacted', 'qualified', 'proposal', 'negotiation', 'won'];
  const fromIndex = order.indexOf(from);
  const toIndex = order.indexOf(to);
  if (fromIndex === -1 || toIndex === -1) return false;
  const step = toIndex - fromIndex;
  return step === 1 || step === -1;
}

export function transitionRefusal(from: LeadStage, to: LeadStage): string {
  if (from === to) return `The lead is already at ${STAGE_LABEL[to]}.`;
  if (isTerminal(from) && to === 'won') {
    return 'A closed lead cannot be moved straight to Won. Reopen it into the pipeline first so the history shows what happened.';
  }
  return `${STAGE_LABEL[from]} cannot move straight to ${STAGE_LABEL[to]} — move one stage at a time so the pipeline history stays true.`;
}

/**
 * Where a lead came from.
 *
 * `unknown` is a real option and is not hidden. A pipeline where every lead has a
 * confident source is a pipeline where someone guessed, and attribution built on
 * guesses is worse than attribution that admits its gaps.
 */
export const LEAD_SOURCES = [
  'website_form',
  'landing_page',
  'phone',
  'whatsapp',
  'email',
  'referral',
  'walk_in',
  'social',
  'paid_ad',
  'marketplace',
  'event',
  'imported',
  'manual',
  'unknown',
] as const;

export type LeadSource = (typeof LEAD_SOURCES)[number];

export const SOURCE_LABEL: Readonly<Record<LeadSource, string>> = {
  website_form: 'Website form',
  landing_page: 'Landing page',
  phone: 'Phone',
  whatsapp: 'WhatsApp',
  email: 'Email',
  referral: 'Referral',
  walk_in: 'Walk-in',
  social: 'Social',
  paid_ad: 'Paid ad',
  marketplace: 'Marketplace',
  event: 'Event',
  imported: 'Imported',
  manual: 'Added by hand',
  unknown: 'Unknown',
};

export function isLeadStage(value: unknown): value is LeadStage {
  return typeof value === 'string' && (LEAD_STAGES as readonly string[]).includes(value);
}

export function isLeadSource(value: unknown): value is LeadSource {
  return typeof value === 'string' && (LEAD_SOURCES as readonly string[]).includes(value);
}

/* -------------------------------------------------------------------------- */
/* Activities and follow-ups                                                  */
/* -------------------------------------------------------------------------- */

export const ACTIVITY_KINDS = [
  'note',
  'call',
  'email_sent',
  'email_received',
  'whatsapp_sent',
  'whatsapp_received',
  'meeting',
  'quote_sent',
  'stage_change',
  'follow_up',
] as const;

export type ActivityKind = (typeof ACTIVITY_KINDS)[number];

export const ACTIVITY_LABEL: Readonly<Record<ActivityKind, string>> = {
  note: 'Note',
  call: 'Call',
  email_sent: 'Email sent',
  email_received: 'Email received',
  whatsapp_sent: 'WhatsApp sent',
  whatsapp_received: 'WhatsApp received',
  meeting: 'Meeting',
  quote_sent: 'Quote sent',
  stage_change: 'Stage change',
  follow_up: 'Follow-up',
};

/**
 * Activity kinds that record an outbound message.
 *
 * These can only be logged by a person saying they sent something. SeSha does
 * not send email or WhatsApp — see `lib/messaging` — so an activity of this kind
 * is always a human record, never an automated one, and the interface says so.
 */
export const MANUAL_SEND_KINDS: readonly ActivityKind[] = [
  'email_sent',
  'whatsapp_sent',
  'call',
  'meeting',
  'quote_sent',
];

export function isActivityKind(value: unknown): value is ActivityKind {
  return typeof value === 'string' && (ACTIVITY_KINDS as readonly string[]).includes(value);
}

/* -------------------------------------------------------------------------- */
/* The score                                                                  */
/* -------------------------------------------------------------------------- */

export interface ScoreComponent {
  /** What was looked at, in the user's language. */
  readonly label: string;
  readonly points: number;
  /** Why those points. One sentence, specific to this lead. */
  readonly why: string;
}

export interface LeadScore {
  readonly total: number;
  readonly max: number;
  readonly components: readonly ScoreComponent[];
  /** What the score is and is not. Shown wherever the number is shown. */
  readonly basis: string;
  readonly band: 'hot' | 'warm' | 'cool';
}

export const SCORE_BASIS =
  'This is a rule-based score SeSha computes from the fields below, not a prediction and not a model. Every point is shown with its reason, and the parts add up to the total — so if you disagree with a rule, you can see exactly which one to ignore.';

/** The maximum each rule can contribute. The sum is the score's ceiling. */
export const SCORE_WEIGHTS = {
  contactable: 20,
  enquiryDetail: 20,
  source: 15,
  engagement: 25,
  recency: 20,
} as const;

export const SCORE_MAX =
  SCORE_WEIGHTS.contactable +
  SCORE_WEIGHTS.enquiryDetail +
  SCORE_WEIGHTS.source +
  SCORE_WEIGHTS.engagement +
  SCORE_WEIGHTS.recency;

export interface ScoreInput {
  readonly email?: string | null;
  readonly phone?: string | null;
  readonly company?: string | null;
  readonly enquiry?: string | null;
  readonly source: LeadSource;
  /** Activity kinds already logged against the lead. */
  readonly activities: readonly ActivityKind[];
  readonly createdAt: Date;
  readonly lastActivityAt?: Date | null;
  readonly now?: Date;
}

/**
 * Scores a lead from what is actually recorded.
 *
 * Every branch appends a component. A rule that fires silently would break the
 * "components add up to the total" guarantee, which is the only reason to trust
 * the number at all.
 */
export function scoreLead(input: ScoreInput): LeadScore {
  const now = input.now ?? new Date();
  const components: ScoreComponent[] = [];

  /* ------------------------------------------------------- contactable */
  const hasEmail = isNonEmpty(input.email);
  const hasPhone = isNonEmpty(input.phone);
  if (hasEmail && hasPhone) {
    components.push({
      label: 'Contact details',
      points: SCORE_WEIGHTS.contactable,
      why: 'Both an email address and a phone number are on file, so they can be reached either way.',
    });
  } else if (hasEmail || hasPhone) {
    components.push({
      label: 'Contact details',
      points: Math.round(SCORE_WEIGHTS.contactable * 0.6),
      why: `Only ${hasEmail ? 'an email address' : 'a phone number'} is on file.`,
    });
  } else {
    components.push({
      label: 'Contact details',
      points: 0,
      why: 'No email address and no phone number, so there is no way to follow up at all.',
    });
  }

  /* ----------------------------------------------------- enquiry detail */
  const enquiry = (input.enquiry ?? '').trim();
  if (enquiry.length >= 200) {
    components.push({
      label: 'What they asked for',
      points: SCORE_WEIGHTS.enquiryDetail,
      why: `They wrote ${enquiry.length} characters about what they need, which is a real enquiry rather than a form fill.`,
    });
  } else if (enquiry.length >= 40) {
    components.push({
      label: 'What they asked for',
      points: Math.round(SCORE_WEIGHTS.enquiryDetail * 0.6),
      why: 'They described what they need briefly.',
    });
  } else if (enquiry.length > 0) {
    components.push({
      label: 'What they asked for',
      points: Math.round(SCORE_WEIGHTS.enquiryDetail * 0.25),
      why: 'The enquiry is a few words, so what they want is mostly unknown.',
    });
  } else {
    components.push({
      label: 'What they asked for',
      points: 0,
      why: 'No enquiry text was captured.',
    });
  }

  /* ------------------------------------------------------------- source */
  const sourcePoints = sourceWeight(input.source);
  components.push({
    label: 'Source',
    points: sourcePoints.points,
    why: sourcePoints.why,
  });

  /* --------------------------------------------------------- engagement */
  const twoWay = input.activities.some(
    (kind) => kind === 'email_received' || kind === 'whatsapp_received' || kind === 'meeting',
  );
  const outbound = input.activities.some((kind) => MANUAL_SEND_KINDS.includes(kind));
  if (twoWay) {
    components.push({
      label: 'Engagement',
      points: SCORE_WEIGHTS.engagement,
      why: 'They have replied or met — the conversation is two-way.',
    });
  } else if (outbound) {
    components.push({
      label: 'Engagement',
      points: Math.round(SCORE_WEIGHTS.engagement * 0.4),
      why: 'Someone has reached out, but there is no recorded reply yet.',
    });
  } else {
    components.push({
      label: 'Engagement',
      points: 0,
      why: 'No contact has been logged against this lead yet.',
    });
  }

  /* ------------------------------------------------------------ recency */
  const reference = input.lastActivityAt ?? input.createdAt;
  const days = Math.floor((now.getTime() - reference.getTime()) / 86_400_000);
  if (days <= 2) {
    components.push({
      label: 'Recency',
      points: SCORE_WEIGHTS.recency,
      why: days <= 0 ? 'Active today.' : `Last activity ${days} day(s) ago.`,
    });
  } else if (days <= 7) {
    components.push({
      label: 'Recency',
      points: Math.round(SCORE_WEIGHTS.recency * 0.7),
      why: `Last activity ${days} days ago.`,
    });
  } else if (days <= 30) {
    components.push({
      label: 'Recency',
      points: Math.round(SCORE_WEIGHTS.recency * 0.3),
      why: `Last activity ${days} days ago, so this is going cold.`,
    });
  } else {
    components.push({
      label: 'Recency',
      points: 0,
      why: `Nothing has happened for ${days} days.`,
    });
  }

  const total = components.reduce((sum, component) => sum + component.points, 0);
  return {
    total,
    max: SCORE_MAX,
    components,
    basis: SCORE_BASIS,
    band: total >= 70 ? 'hot' : total >= 40 ? 'warm' : 'cool',
  };
}

/**
 * Source weighting.
 *
 * The reasoning is stated per source rather than hidden in a table of magic
 * numbers, because a user who disagrees that a referral beats a marketplace lead
 * is entitled to see that this is an opinion.
 */
function sourceWeight(source: LeadSource): { readonly points: number; readonly why: string } {
  const full = SCORE_WEIGHTS.source;
  switch (source) {
    case 'referral':
      return { points: full, why: 'A referral arrives with someone else\'s credibility attached.' };
    case 'phone':
    case 'walk_in':
      return { points: full, why: 'They made direct contact themselves, which takes more effort than a form.' };
    case 'website_form':
    case 'landing_page':
    case 'whatsapp':
    case 'email':
      return { points: Math.round(full * 0.8), why: 'They came to you and asked.' };
    case 'paid_ad':
      return { points: Math.round(full * 0.6), why: 'A paid click: real interest, but the bar to clicking is low.' };
    case 'event':
      return { points: Math.round(full * 0.6), why: 'Met at an event, so the context is known but the intent may not be.' };
    case 'social':
    case 'marketplace':
      return { points: Math.round(full * 0.4), why: 'Arrived through a third-party surface, often while comparing options.' };
    case 'imported':
    case 'manual':
      return { points: Math.round(full * 0.2), why: 'Added to the system by someone here rather than by the lead themselves.' };
    case 'unknown':
      return {
        points: 0,
        why: 'The source was not recorded, so it contributes nothing rather than being guessed at.',
      };
  }
}

/** Whether the components shown actually add up to the total. */
export function scoreIsConsistent(score: LeadScore): boolean {
  const sum = score.components.reduce((total, component) => total + component.points, 0);
  return sum === score.total;
}

/* -------------------------------------------------------------------------- */
/* Follow-ups                                                                 */
/* -------------------------------------------------------------------------- */

export interface FollowUp {
  readonly dueAt: Date;
  readonly note: string;
  readonly completedAt?: Date | null;
}

export type FollowUpState = 'due_later' | 'due_today' | 'overdue' | 'done';

export function followUpState(followUp: FollowUp, now: Date = new Date()): FollowUpState {
  if (followUp.completedAt) return 'done';
  const due = followUp.dueAt;
  const sameDay =
    due.getUTCFullYear() === now.getUTCFullYear() &&
    due.getUTCMonth() === now.getUTCMonth() &&
    due.getUTCDate() === now.getUTCDate();
  if (sameDay) return 'due_today';
  return due.getTime() < now.getTime() ? 'overdue' : 'due_later';
}

/**
 * Suggests when to follow up next, and says why.
 *
 * Not an automation: nothing here sends anything. It is a due date a person
 * chooses to accept.
 */
export function suggestFollowUp(
  stage: LeadStage,
  lastActivityAt: Date,
): { readonly dueAt: Date; readonly why: string } {
  const days =
    stage === 'new' ? 1 : stage === 'contacted' ? 2 : stage === 'qualified' ? 3 : stage === 'proposal' ? 3 : stage === 'negotiation' ? 2 : 7;
  const dueAt = new Date(lastActivityAt.getTime() + days * 86_400_000);
  return {
    dueAt,
    why: `At ${STAGE_LABEL[stage]}, ${days} day(s) keeps the conversation warm without crowding them. Change it to whatever suits how you actually work.`,
  };
}

/**
 * Pipeline counts by stage.
 *
 * Returns every stage, including the empty ones: a funnel chart that silently
 * omits a stage with no leads in it makes the pipeline look healthier than it is.
 */
export function pipelineCounts(
  leads: readonly { readonly stage: LeadStage }[],
): Readonly<Record<LeadStage, number>> {
  const counts = Object.fromEntries(LEAD_STAGES.map((stage) => [stage, 0])) as Record<LeadStage, number>;
  for (const lead of leads) counts[lead.stage] += 1;
  return counts;
}

function isNonEmpty(value: string | null | undefined): boolean {
  return typeof value === 'string' && value.trim().length > 0;
}
