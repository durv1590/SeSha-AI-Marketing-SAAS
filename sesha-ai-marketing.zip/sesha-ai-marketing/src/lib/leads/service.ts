/**
 * Lead service.
 *
 * THREE THINGS THIS ENFORCES THAT A CRM USUALLY DOES NOT
 *
 * 1. EVERY STAGE CHANGE IS LOGGED, as an activity with the stages recorded. A
 *    pipeline where someone can quietly move a deal back from Lost is a pipeline
 *    whose reporting nobody can defend in a meeting.
 *
 * 2. THE SCORE IS RECOMPUTED ON EVERY WRITE, with its components. A score left
 *    over from three weeks ago is worse than no score: it looks current.
 *
 * 3. A DUPLICATE IS REPORTED, NOT MERGED. The same person enquiring twice is
 *    common, and silently merging two enquiries loses the second one's context.
 *    The caller is told which lead already exists and decides.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { assertTenant, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { LeadActivityRow, LeadRow } from '@/lib/db/types';

import {
  STAGE_LABEL,
  canTransition,
  followUpState,
  isActivityKind,
  isLeadSource,
  isLeadStage,
  pipelineCounts,
  scoreLead,
  suggestFollowUp,
  transitionRefusal,
  type ActivityKind,
  type LeadScore,
  type LeadStage,
  type LeadSource,
} from './types';

export interface LeadServiceContext {
  readonly db: Database;
  readonly now?: () => Date;
}

function clock(context: LeadServiceContext): Date {
  return context.now?.() ?? new Date();
}

export class LeadInputError extends Error {
  readonly code = 'INVALID_INPUT' as const;
  constructor(message: string) {
    super(message);
    this.name = 'LeadInputError';
  }
}

export class DuplicateLeadError extends Error {
  readonly code = 'DUPLICATE_LEAD' as const;
  readonly existingId: string;
  constructor(existingId: string, how: string) {
    super(`A lead with the same ${how} already exists on this project.`);
    this.name = 'DuplicateLeadError';
    this.existingId = existingId;
  }
}

export class StageTransitionError extends Error {
  readonly code = 'INVALID_TRANSITION' as const;
  constructor(message: string) {
    super(message);
    this.name = 'StageTransitionError';
  }
}

export interface CreateLeadInput {
  readonly projectId: string;
  readonly name: string;
  readonly email?: string;
  readonly phone?: string;
  readonly company?: string;
  readonly enquiry?: string;
  readonly source?: LeadSource;
  readonly optInBasis?: LeadRow['optInBasis'];
  readonly ownerUserId?: string;
  readonly allowDuplicate?: boolean;
}

export async function createLead(
  context: LeadServiceContext,
  tenant: TenantContext,
  input: CreateLeadInput,
): Promise<{ readonly lead: LeadRow; readonly score: LeadScore }> {
  requirePermission(tenant.role, 'lead:manage');

  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, input.projectId),
    'Project',
  );

  const name = input.name.trim();
  if (name.length === 0) throw new LeadInputError('The lead needs a name.');

  const email = input.email?.trim() ?? '';
  const phone = input.phone?.trim() ?? '';
  const company = input.company?.trim() ?? '';
  if (email.length === 0 && phone.length === 0 && company.length === 0) {
    throw new LeadInputError(
      'A lead needs at least one of an email address, a phone number or a company — otherwise there is no way to follow up.',
    );
  }
  if (email.length > 0 && !/^[^@\s]+@[^@\s.]+\.[^@\s]+$/.test(email)) {
    throw new LeadInputError('That email address does not look right.');
  }

  const source = input.source ?? 'unknown';
  if (!isLeadSource(source)) throw new LeadInputError('That is not a lead source.');

  if (input.allowDuplicate !== true) {
    if (email.length > 0) {
      const existing = await context.db.leads.findByEmail(tenant.organizationId, project.id, email);
      if (existing) throw new DuplicateLeadError(existing.id, 'email address');
    }
    if (phone.length > 0) {
      const existing = await context.db.leads.findByPhone(tenant.organizationId, project.id, phone);
      if (existing) throw new DuplicateLeadError(existing.id, 'phone number');
    }
  }

  const now = clock(context);
  const score = scoreLead({
    email: email || null,
    phone: phone || null,
    company: company || null,
    enquiry: input.enquiry ?? null,
    source,
    activities: [],
    createdAt: now,
    now,
  });

  const lead = await context.db.leads.create({
    organizationId: tenant.organizationId,
    projectId: project.id,
    createdBy: tenant.userId,
    ownerUserId: input.ownerUserId ?? null,
    name,
    email: email || null,
    phone: phone || null,
    company: company || null,
    enquiry: input.enquiry?.trim() ?? '',
    source,
    sourcePath: null,
    sourceCampaign: null,
    stage: 'new',
    score: score.total,
    scoreComponents: score.components as unknown as readonly Readonly<Record<string, unknown>>[],
    scoreBasis: score.basis,
    scoredAt: now,
    optInBasis: input.optInBasis ?? 'enquiry_reply',
    lostReason: null,
    lastActivityAt: now,
  });

  await context.db.usage.record({
    organizationId: tenant.organizationId,
    projectId: project.id,
    metric: 'lead',
    quantity: 1,
    periodStart: `${now.toISOString().slice(0, 7)}-01`,
  });

  return { lead, score };
}

export async function listLeads(
  context: LeadServiceContext,
  tenant: TenantContext,
  projectId: string,
  filter?: { readonly stage?: LeadStage; readonly ownerUserId?: string },
): Promise<{
  readonly leads: readonly LeadRow[];
  readonly counts: Readonly<Record<LeadStage, number>>;
}> {
  requirePermission(tenant.role, 'lead:read');
  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, projectId),
    'Project',
  );
  // Counts are computed over the WHOLE pipeline, not the filtered view: a funnel
  // that changes shape when you filter it is not a funnel.
  const all = await context.db.leads.listForProject(tenant.organizationId, project.id);
  const leads = filter
    ? await context.db.leads.listForProject(tenant.organizationId, project.id, filter)
    : all;
  return { leads, counts: pipelineCounts(all) };
}

export async function getLead(
  context: LeadServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<{
  readonly lead: LeadRow;
  readonly activities: readonly LeadActivityRow[];
  readonly score: LeadScore;
}> {
  requirePermission(tenant.role, 'lead:read');
  const lead = assertTenant(
    tenant,
    await context.db.leads.findById(tenant.organizationId, id),
    'Lead',
  );
  const activities = await context.db.leadActivities.listForLead(tenant.organizationId, lead.id);
  return { lead, activities, score: await rescore(context, lead, activities) };
}

/**
 * Moves a lead to another stage.
 *
 * The transition is checked, the change is logged as an activity, and the score is
 * recomputed. A `lost` move requires a reason — the database enforces it too.
 */
export async function moveStage(
  context: LeadServiceContext,
  tenant: TenantContext,
  id: string,
  to: LeadStage,
  options: { readonly lostReason?: string; readonly note?: string } = {},
): Promise<{ readonly lead: LeadRow; readonly score: LeadScore }> {
  requirePermission(tenant.role, 'lead:manage');

  if (!isLeadStage(to)) throw new LeadInputError('That is not a pipeline stage.');

  const lead = assertTenant(
    tenant,
    await context.db.leads.findById(tenant.organizationId, id),
    'Lead',
  );

  if (!canTransition(lead.stage, to)) {
    throw new StageTransitionError(transitionRefusal(lead.stage, to));
  }

  const lostReason = options.lostReason?.trim() ?? '';
  if (to === 'lost' && lostReason.length === 0) {
    throw new LeadInputError(
      'Say why this was lost. A pipeline full of unexplained losses teaches nobody anything.',
    );
  }

  const now = clock(context);

  await context.db.leadActivities.create({
    organizationId: tenant.organizationId,
    leadId: lead.id,
    createdBy: tenant.userId,
    kind: 'stage_change',
    note: options.note?.trim() ?? `${STAGE_LABEL[lead.stage]} → ${STAGE_LABEL[to]}`,
    occurredAt: now,
    dueAt: null,
    completedAt: null,
    fromStage: lead.stage,
    toStage: to,
  });

  const activities = await context.db.leadActivities.listForLead(tenant.organizationId, lead.id);
  const score = scoreLead({
    email: lead.email,
    phone: lead.phone,
    company: lead.company,
    enquiry: lead.enquiry,
    source: (isLeadSource(lead.source) ? lead.source : 'unknown'),
    activities: activityKinds(activities),
    createdAt: lead.createdAt,
    lastActivityAt: now,
    now,
  });

  const updated = await context.db.leads.update(tenant.organizationId, lead.id, {
    stage: to,
    lostReason: to === 'lost' ? lostReason : null,
    lastActivityAt: now,
    score: score.total,
    scoreComponents: score.components as unknown as readonly Readonly<Record<string, unknown>>[],
    scoreBasis: score.basis,
    scoredAt: now,
  });
  if (!updated) throw new LeadInputError('That lead could not be updated.');
  return { lead: updated, score };
}

export interface LogActivityInput {
  readonly leadId: string;
  readonly kind: ActivityKind;
  readonly note?: string;
  /** For a follow-up. */
  readonly dueAt?: Date;
}

export async function logActivity(
  context: LeadServiceContext,
  tenant: TenantContext,
  input: LogActivityInput,
): Promise<{ readonly activity: LeadActivityRow; readonly score: LeadScore }> {
  requirePermission(tenant.role, 'lead:manage');

  if (!isActivityKind(input.kind)) throw new LeadInputError('That is not an activity kind.');
  if (input.kind === 'stage_change') {
    throw new LeadInputError('A stage change is recorded by moving the lead, not logged by hand.');
  }
  if (input.kind === 'follow_up' && !input.dueAt) {
    throw new LeadInputError('A follow-up needs a date.');
  }
  if (input.kind !== 'follow_up' && input.dueAt) {
    throw new LeadInputError('Only a follow-up carries a due date.');
  }

  const lead = assertTenant(
    tenant,
    await context.db.leads.findById(tenant.organizationId, input.leadId),
    'Lead',
  );

  const now = clock(context);
  const activity = await context.db.leadActivities.create({
    organizationId: tenant.organizationId,
    leadId: lead.id,
    createdBy: tenant.userId,
    kind: input.kind,
    note: input.note?.trim() ?? '',
    occurredAt: now,
    dueAt: input.dueAt ?? null,
    completedAt: null,
    fromStage: null,
    toStage: null,
  });

  const activities = await context.db.leadActivities.listForLead(tenant.organizationId, lead.id);
  const score = scoreLead({
    email: lead.email,
    phone: lead.phone,
    company: lead.company,
    enquiry: lead.enquiry,
    source: isLeadSource(lead.source) ? lead.source : 'unknown',
    activities: activityKinds(activities),
    createdAt: lead.createdAt,
    lastActivityAt: now,
    now,
  });

  await context.db.leads.update(tenant.organizationId, lead.id, {
    lastActivityAt: now,
    score: score.total,
    scoreComponents: score.components as unknown as readonly Readonly<Record<string, unknown>>[],
    scoreBasis: score.basis,
    scoredAt: now,
  });

  return { activity, score };
}

export async function completeFollowUp(
  context: LeadServiceContext,
  tenant: TenantContext,
  activityId: string,
): Promise<LeadActivityRow> {
  requirePermission(tenant.role, 'lead:manage');
  const completed = await context.db.leadActivities.complete(
    tenant.organizationId,
    activityId,
    clock(context),
  );
  if (!completed) throw new LeadInputError('That follow-up could not be found.');
  return completed;
}

/** Follow-ups that are due or overdue, soonest first. */
export async function dueFollowUps(
  context: LeadServiceContext,
  tenant: TenantContext,
): Promise<readonly { readonly activity: LeadActivityRow; readonly state: string }[]> {
  requirePermission(tenant.role, 'lead:read');
  const now = clock(context);
  const due = await context.db.leadActivities.listDue(tenant.organizationId, now);
  return due.map((activity) => ({
    activity,
    state: activity.dueAt
      ? followUpState({ dueAt: activity.dueAt, note: activity.note, completedAt: activity.completedAt }, now)
      : 'due_later',
  }));
}

/** The suggested next follow-up for a lead. A suggestion, not an automation. */
export async function nextFollowUp(
  context: LeadServiceContext,
  tenant: TenantContext,
  leadId: string,
): Promise<{ readonly dueAt: Date; readonly why: string }> {
  requirePermission(tenant.role, 'lead:read');
  const lead = assertTenant(
    tenant,
    await context.db.leads.findById(tenant.organizationId, leadId),
    'Lead',
  );
  return suggestFollowUp(lead.stage, lead.lastActivityAt ?? lead.createdAt);
}

export async function deleteLead(
  context: LeadServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<void> {
  requirePermission(tenant.role, 'lead:manage');
  const lead = assertTenant(
    tenant,
    await context.db.leads.findById(tenant.organizationId, id),
    'Lead',
  );
  await context.db.leads.softDelete(tenant.organizationId, lead.id, clock(context));
}

async function rescore(
  context: LeadServiceContext,
  lead: LeadRow,
  activities: readonly LeadActivityRow[],
): Promise<LeadScore> {
  return scoreLead({
    email: lead.email,
    phone: lead.phone,
    company: lead.company,
    enquiry: lead.enquiry,
    source: isLeadSource(lead.source) ? lead.source : 'unknown',
    activities: activityKinds(activities),
    createdAt: lead.createdAt,
    lastActivityAt: lead.lastActivityAt,
    now: clock(context),
  });
}

function activityKinds(activities: readonly LeadActivityRow[]): ActivityKind[] {
  return activities
    .map((activity) => activity.kind)
    .filter((kind): kind is ActivityKind => isActivityKind(kind));
}
