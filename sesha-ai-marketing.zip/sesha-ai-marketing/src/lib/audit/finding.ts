/**
 * The shape of every audit finding, SEO and AEO alike.
 *
 * The brief's requirement for AEO recommendations — issue, evidence,
 * recommended change, expected benefit, confidence, data basis — is applied to
 * BOTH audits, because the reason for it holds in both: a recommendation whose
 * basis is not stated is indistinguishable from one the tool invented.
 *
 * THE FORBIDDEN PROMISES
 * "Never promise AI ranking, AI citation, AI visibility or guaranteed traffic."
 * That is enforced by `lintFinding` below, which scans the text every finding
 * carries and rejects the claim rather than trusting the author of the rule not
 * to have written it. The same approach as the Phase 3 claim linter: the
 * instruction is the polite half, the linter is the control.
 *
 * EVIDENCE IS REQUIRED
 * A finding with no evidence cannot be constructed. `evidence` holds what was
 * actually observed, with the URLs it was observed on — so a user can check the
 * tool's work, and so a finding can never be a generic best practice dressed up
 * as an observation about their site.
 */

export const SEVERITIES = ['critical', 'high', 'medium', 'low', 'info'] as const;
export type Severity = (typeof SEVERITIES)[number];

/**
 * How much the audit trusts its own conclusion.
 *
 * `high` is reserved for things measured directly on the page — a missing title
 * is a fact. `medium` is an inference from the crawl. `low` is a judgement the
 * user should weigh themselves.
 */
export const CONFIDENCES = ['high', 'medium', 'low'] as const;
export type Confidence = (typeof CONFIDENCES)[number];

/**
 * Where the finding's facts came from. This is the provenance model from Phase 3
 * expressed for audit data, and it is required on every finding.
 */
export const DATA_BASES = [
  'crawled_page',
  'crawl_summary',
  'robots_txt',
  'sitemap',
  'structured_data',
  'user_provided',
  'heuristic',
  'unavailable',
] as const;
export type DataBasis = (typeof DATA_BASES)[number];

export const DATA_BASIS_LABELS: Record<DataBasis, string> = {
  crawled_page: 'Measured on your pages',
  crawl_summary: 'Measured across the crawl',
  robots_txt: 'Read from your robots.txt',
  sitemap: 'Read from your sitemap',
  structured_data: 'Read from your structured data',
  user_provided: 'From details you entered',
  heuristic: 'A general rule, not a measurement of your site',
  unavailable: 'Not measurable with the data available',
};

export interface Evidence {
  /** What was observed, stated as a fact. */
  readonly observation: string;
  /** The pages it was observed on. Empty only for site-level findings. */
  readonly urls: readonly string[];
  /** How many pages are affected, when that is larger than `urls`. */
  readonly affectedCount?: number;
  readonly totalCount?: number;
}

export interface Finding {
  readonly id: string;
  readonly category: string;
  readonly severity: Severity;
  /** What is wrong, in one line. */
  readonly issue: string;
  readonly evidence: Evidence;
  /** What to do about it. */
  readonly recommendation: string;
  /** What improving it is expected to achieve — hedged, never promised. */
  readonly expectedBenefit: string;
  readonly confidence: Confidence;
  readonly dataBasis: DataBasis;
}

/* -------------------------------------------------------------------------- */
/* The forbidden-promise linter                                               */
/* -------------------------------------------------------------------------- */

export interface FindingWarning {
  readonly findingId: string;
  readonly field: string;
  readonly message: string;
  readonly excerpt: string;
}

/**
 * Claims no audit finding may make.
 *
 * These are the four the brief names, plus the shapes they tend to arrive in. A
 * "will rank" is the same promise as a "guarantees ranking" and both are refused.
 */
const FORBIDDEN: readonly { readonly label: string; readonly pattern: RegExp }[] = [
  {
    label: 'a promise about AI or search ranking',
    pattern: /\b(will|shall|guarantee[ds]?|guaranteed|ensures?|ensure)\b[^.]{0,60}\b(rank|ranking|rankings|position|top \d+|first page|page one)\b/i,
  },
  {
    label: 'a promise of AI citation',
    pattern: /\b(will|shall|guarantee[ds]?|ensures?)\b[^.]{0,60}\b(be cited|citation|cite[ds]?|get cited|appear in (?:ai|chatgpt|perplexity|gemini|claude))\b/i,
  },
  {
    label: 'a promise of AI visibility',
    pattern: /\b(guarantee[ds]?|guaranteed|ensures?|will (?:give|get|deliver|achieve))\b[^.]{0,60}\b(ai visibility|visibility in ai|ai overview|ai answers?)\b/i,
  },
  {
    label: 'a traffic guarantee',
    pattern: /\b(guarantee[ds]?|guaranteed|ensures?|promise[ds]?)\b[^.]{0,60}\b(traffic|visitors|clicks|leads|conversions|revenue)\b/i,
  },
  {
    label: 'a quantified outcome with no source',
    pattern: /\b(?:increase|improve|boost|grow|lift|raise)\s+[^.]{0,30}\bby\s+\d{1,3}\s?%/i,
  },
  {
    // NOTE: \b cannot precede '#' — there is no word boundary between a space
    // and a punctuation character. The boundary goes INSIDE the alternation, on
    // the alternatives that actually start with a word character. This exact
    // mistake shipped in the Phase 3 claim linter and is repeated here as a
    // comment so it is not made a third time.
    label: 'a ranking superlative',
    pattern: /(#1\b|\bnumber one\b|\btop of (?:google|search)\b|\bfirst result\b)/i,
  },
];

/**
 * Checks one finding's prose.
 *
 * Runs over `issue`, `recommendation` and `expectedBenefit` — the three fields a
 * user reads as a claim. `evidence.observation` is excluded deliberately: it
 * states what was measured, and a measured percentage is a fact, not a promise.
 */
export function lintFinding(finding: Finding): FindingWarning[] {
  const warnings: FindingWarning[] = [];
  const fields: readonly [string, string][] = [
    ['issue', finding.issue],
    ['recommendation', finding.recommendation],
    ['expectedBenefit', finding.expectedBenefit],
  ];

  for (const [field, text] of fields) {
    for (const rule of FORBIDDEN) {
      const match = rule.pattern.exec(text);
      if (match) {
        warnings.push({
          findingId: finding.id,
          field,
          message: `Contains ${rule.label}, which this product does not make.`,
          excerpt: match[0].slice(0, 140),
        });
      }
    }
  }

  return warnings;
}

/** Every finding must carry real evidence and a basis. */
export function validateFinding(finding: Finding): string[] {
  const problems: string[] = [];
  if (finding.issue.trim().length === 0) problems.push('issue is empty');
  if (finding.recommendation.trim().length === 0) problems.push('recommendation is empty');
  if (finding.expectedBenefit.trim().length === 0) problems.push('expectedBenefit is empty');
  if (finding.evidence.observation.trim().length === 0) problems.push('evidence.observation is empty');

  // A heuristic finding is allowed to cite no URL — it is explicitly not a
  // measurement. Anything else must point at something real.
  if (
    finding.dataBasis !== 'heuristic' &&
    finding.dataBasis !== 'unavailable' &&
    finding.evidence.urls.length === 0 &&
    finding.evidence.affectedCount === undefined
  ) {
    problems.push('a measured finding must cite at least one URL or an affected count');
  }

  // A heuristic cannot be high confidence: it was not measured on this site.
  if (finding.dataBasis === 'heuristic' && finding.confidence === 'high') {
    problems.push('a heuristic finding cannot be high confidence');
  }
  return problems;
}

/**
 * The audit's own safety net.
 *
 * Returns the findings that passed, the warnings raised, and whether the report
 * is safe to show. A finding that makes a forbidden promise is DROPPED, not
 * flagged — unlike an AI response, an audit finding is written by this codebase,
 * so a violation is a bug to fix rather than a model to caveat.
 */
export interface LintedFindings {
  readonly findings: readonly Finding[];
  readonly warnings: readonly FindingWarning[];
  readonly dropped: readonly string[];
}

export function lintFindings(findings: readonly Finding[]): LintedFindings {
  const kept: Finding[] = [];
  const warnings: FindingWarning[] = [];
  const dropped: string[] = [];

  for (const finding of findings) {
    const structural = validateFinding(finding);
    const promises = lintFinding(finding);

    if (structural.length > 0) {
      dropped.push(finding.id);
      for (const problem of structural) {
        warnings.push({ findingId: finding.id, field: 'structure', message: problem, excerpt: '' });
      }
      continue;
    }
    if (promises.length > 0) {
      dropped.push(finding.id);
      warnings.push(...promises);
      continue;
    }
    kept.push(finding);
  }

  return { findings: kept, warnings, dropped };
}

/* -------------------------------------------------------------------------- */
/* Ordering and scoring                                                       */
/* -------------------------------------------------------------------------- */

const SEVERITY_ORDER: Record<Severity, number> = {
  critical: 0, high: 1, medium: 2, low: 3, info: 4,
};

const CONFIDENCE_ORDER: Record<Confidence, number> = { high: 0, medium: 1, low: 2 };

/** Most severe first, and within a severity, the best-evidenced first. */
export function sortFindings(findings: readonly Finding[]): Finding[] {
  return [...findings].sort((a, b) => {
    const bySeverity = SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity];
    if (bySeverity !== 0) return bySeverity;
    const byConfidence = CONFIDENCE_ORDER[a.confidence] - CONFIDENCE_ORDER[b.confidence];
    if (byConfidence !== 0) return byConfidence;
    return (b.evidence.affectedCount ?? b.evidence.urls.length) -
      (a.evidence.affectedCount ?? a.evidence.urls.length);
  });
}

export interface ScoreBreakdown {
  readonly score: number;
  readonly counts: Readonly<Record<Severity, number>>;
  /** Stated so the number is never mistaken for an external measurement. */
  readonly basis: string;
}

/**
 * A score out of 100.
 *
 * This is OUR weighting of OUR findings, and `basis` says so. It is not a
 * measurement of how a search engine sees the site, nobody else's scale agrees
 * with it, and presenting it as objective would be exactly the kind of invented
 * metric the project forbids elsewhere.
 */
export function scoreFindings(findings: readonly Finding[]): ScoreBreakdown {
  const weights: Record<Severity, number> = {
    critical: 15, high: 8, medium: 3, low: 1, info: 0,
  };
  const counts: Record<Severity, number> = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };

  let penalty = 0;
  for (const finding of findings) {
    counts[finding.severity] += 1;
    // Low-confidence findings count for less: a judgement should not cost as
    // much as a measurement.
    const discount = finding.confidence === 'low' ? 0.5 : finding.confidence === 'medium' ? 0.8 : 1;
    penalty += weights[finding.severity] * discount;
  }

  return {
    score: Math.max(0, Math.min(100, Math.round(100 - penalty))),
    counts,
    basis:
      'This score is SeSha’s own weighting of the issues found in this crawl. It is not a measurement from Google or any other search engine, and it cannot be compared with a score from another tool.',
  };
}
