/**
 * Technical SEO audit.
 *
 * Every check below reads the crawl and reports what it found. None of them
 * invents a number, and none of them reports a best practice as though it were
 * an observation about this site: a finding whose basis is `heuristic` says so,
 * and is capped at medium confidence by `validateFinding`.
 *
 * The brief's fifteen areas, and where each is covered:
 *   Technical SEO ............ statusAndHttps, indexability
 *   Metadata ................. titles, descriptions
 *   Headings ................. headings
 *   Content .................. content
 *   Canonicals ............... canonicals
 *   Sitemap .................. sitemapChecks
 *   Robots ................... robotsChecks
 *   Broken links ............. brokenLinks
 *   Images ................... images
 *   Mobile indicators ........ mobile
 *   HTTPS .................... statusAndHttps
 *   Performance indicators ... performance
 *   Structured data .......... structuredDataChecks
 *   Entity consistency ....... entityConsistency
 *   Internal links ........... internalLinks
 */

import type { CrawlReport } from '@/lib/crawler';
import type { PageData } from '@/lib/crawler';
import { normalizeUrl } from '@/lib/crawler';
import {
  lintFindings,
  scoreFindings,
  sortFindings,
  type Finding,
  type ScoreBreakdown,
} from './finding';

/* -------------------------------------------------------------------------- */
/* Thresholds — named, so the report can explain itself                       */
/* -------------------------------------------------------------------------- */

export const SEO_THRESHOLDS = {
  /** Google truncates around here; these are display guidelines, not rules. */
  titleMin: 15,
  titleMax: 60,
  descriptionMin: 70,
  descriptionMax: 160,
  /** Below this, a page has too little text to rank for anything specific. */
  thinContentWords: 150,
  /** A page slower than this is worth looking at. Not a Core Web Vital. */
  slowResponseMs: 1_500,
  largePageBytes: 1_500_000,
  /** Orphan-ish: reachable but barely linked. */
  minInboundLinks: 1,
} as const;

export interface SeoAudit {
  readonly findings: readonly Finding[];
  readonly score: ScoreBreakdown;
  readonly stats: SeoStats;
  /** Findings the linter refused to publish — a bug signal, shown in dev. */
  readonly suppressed: readonly string[];
  readonly checkedAt: Date;
  /** What could not be checked, and why. Always present. */
  readonly notChecked: readonly NotChecked[];
}

export interface NotChecked {
  readonly area: string;
  readonly reason: string;
  readonly whatWouldHelp: string;
}

export interface SeoStats {
  readonly pagesCrawled: number;
  readonly pagesFailed: number;
  readonly httpsPages: number;
  readonly indexablePages: number;
  readonly withTitle: number;
  readonly withDescription: number;
  readonly withCanonical: number;
  readonly withStructuredData: number;
  readonly totalInternalLinks: number;
  readonly totalExternalLinks: number;
  readonly medianResponseMs: number | null;
  readonly totalWords: number;
}

let counter = 0;
function nextId(prefix: string): string {
  counter += 1;
  return `${prefix}-${counter}`;
}

/** Caps a URL list so a finding stays readable and the row stays small. */
function sample(urls: readonly string[], limit = 10): string[] {
  return urls.slice(0, limit);
}

function pluralPages(count: number): string {
  return `${count} page${count === 1 ? '' : 's'}`;
}

/* -------------------------------------------------------------------------- */
/* The audit                                                                  */
/* -------------------------------------------------------------------------- */

export function auditSeo(report: CrawlReport): SeoAudit {
  counter = 0;
  const pages = report.pages;
  const raw: Finding[] = [
    ...statusAndHttps(report),
    ...indexability(pages),
    ...titles(pages),
    ...descriptions(pages),
    ...headings(pages),
    ...content(pages),
    ...canonicals(pages),
    ...sitemapChecks(report),
    ...robotsChecks(report),
    ...brokenLinks(report),
    ...images(pages),
    ...mobile(pages),
    ...performance(pages),
    ...structuredDataChecks(pages),
    ...entityConsistency(pages),
    ...internalLinks(report),
  ];

  const linted = lintFindings(raw);

  return {
    findings: sortFindings(linted.findings),
    score: scoreFindings(linted.findings),
    stats: statsOf(report),
    suppressed: linted.dropped,
    checkedAt: new Date(),
    notChecked: notChecked(report),
  };
}

function statsOf(report: CrawlReport): SeoStats {
  const pages = report.pages;
  const times = pages.map((page) => page.responseTimeMs).sort((a, b) => a - b);
  const median = times.length > 0
    ? times[Math.floor(times.length / 2)] ?? null
    : null;

  let internal = 0;
  let external = 0;
  for (const page of pages) {
    for (const link of page.links) {
      if (link.internal) internal += 1;
      else external += 1;
    }
  }

  return {
    pagesCrawled: pages.length,
    pagesFailed: report.failures.length,
    httpsPages: pages.filter((page) => page.https).length,
    indexablePages: pages.filter((page) => !page.robots.noindex).length,
    withTitle: pages.filter((page) => page.title !== null).length,
    withDescription: pages.filter((page) => page.metaDescription !== null).length,
    withCanonical: pages.filter((page) => page.canonical !== null).length,
    withStructuredData: pages.filter((page) => page.structuredData.length > 0).length,
    totalInternalLinks: internal,
    totalExternalLinks: external,
    medianResponseMs: median,
    totalWords: pages.reduce((sum, page) => sum + page.wordCount, 0),
  };
}

/**
 * What the audit could NOT assess.
 *
 * Always non-empty, because a crawl cannot measure everything and an audit that
 * silently omits an area reads as though the area is fine.
 */
function notChecked(report: CrawlReport): NotChecked[] {
  const out: NotChecked[] = [
    {
      area: 'Core Web Vitals',
      reason:
        'LCP, INP and CLS are measured in a real browser on real visits. This crawl records server response time, which is related but is not the same measurement.',
      whatWouldHelp: 'Google Search Console or PageSpeed Insights for field data.',
    },
    {
      area: 'Rankings and search traffic',
      reason:
        'SeSha has no access to search result positions or to your traffic, so no ranking or traffic figure appears anywhere in this report.',
      whatWouldHelp: 'Connecting Google Search Console.',
    },
    {
      area: 'JavaScript-rendered content',
      reason:
        'This crawler reads the HTML the server returns and does not execute JavaScript. Content added in the browser is not visible to it.',
      whatWouldHelp: 'Server-side rendering, or checking the rendered HTML in Search Console.',
    },
  ];

  if (report.pages.length === 0) {
    out.push({
      area: 'Everything page-level',
      reason: 'No page could be read, so nothing about page content could be assessed.',
      whatWouldHelp: 'A site that responds to the crawler, and a robots.txt that permits it.',
    });
  }
  if (report.stoppedEarly) {
    out.push({
      area: 'Pages beyond the crawl limit',
      reason: report.stoppedEarly,
      whatWouldHelp: 'A larger page budget, or a narrower starting point.',
    });
  }
  return out;
}

/* -------------------------------------------------------------------------- */
/* HTTPS and status                                                           */
/* -------------------------------------------------------------------------- */

function statusAndHttps(report: CrawlReport): Finding[] {
  const findings: Finding[] = [];
  const insecure = report.pages.filter((page) => !page.https);

  if (insecure.length > 0) {
    findings.push({
      id: nextId('seo-https'),
      category: 'HTTPS',
      severity: 'critical',
      issue: `${pluralPages(insecure.length)} were served over HTTP rather than HTTPS.`,
      evidence: {
        observation: `These URLs responded on http://, not https://.`,
        urls: sample(insecure.map((page) => page.url)),
        affectedCount: insecure.length,
        totalCount: report.pages.length,
      },
      recommendation:
        'Serve every page over HTTPS and redirect HTTP to HTTPS with a 301. Check that internal links and canonical tags use https:// too.',
      expectedBenefit:
        'HTTPS is a confirmed lightweight ranking signal, and browsers mark HTTP pages as not secure, which affects how visitors treat the page.',
      confidence: 'high',
      dataBasis: 'crawled_page',
    });
  }

  // Mixed HTTP and HTTPS is its own problem, separate from being all-HTTP.
  if (insecure.length > 0 && insecure.length < report.pages.length) {
    findings.push({
      id: nextId('seo-mixed-scheme'),
      category: 'HTTPS',
      severity: 'high',
      issue: 'The site answers on both HTTP and HTTPS, which splits it into two sites.',
      evidence: {
        observation: `${insecure.length} of ${report.pages.length} crawled pages were HTTP and the rest HTTPS.`,
        urls: sample(insecure.map((page) => page.url), 5),
        affectedCount: insecure.length,
        totalCount: report.pages.length,
      },
      recommendation: 'Redirect all HTTP URLs to their HTTPS equivalent, and pick HTTPS as the canonical scheme.',
      expectedBenefit:
        'Consolidating to one scheme means links and signals point at one set of URLs rather than being divided between two.',
      confidence: 'high',
      dataBasis: 'crawl_summary',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* Indexability                                                               */
/* -------------------------------------------------------------------------- */

function indexability(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];
  const noindexed = pages.filter((page) => page.robots.noindex);

  if (noindexed.length > 0) {
    // This can be entirely deliberate, so it is reported at the severity of
    // "you should know" rather than "this is broken".
    findings.push({
      id: nextId('seo-noindex'),
      category: 'Indexability',
      severity: noindexed.length === pages.length ? 'critical' : 'medium',
      issue:
        noindexed.length === pages.length
          ? 'Every crawled page asks search engines not to index it.'
          : `${pluralPages(noindexed.length)} ask search engines not to index them.`,
      evidence: {
        observation: `These pages carry a robots meta tag containing "noindex": ${noindexed
          .slice(0, 3)
          .map((page) => `${page.url} (${page.robots.raw})`)
          .join('; ')}`,
        urls: sample(noindexed.map((page) => page.url)),
        affectedCount: noindexed.length,
        totalCount: pages.length,
      },
      recommendation:
        'Remove the noindex directive from any page you want in search results. If it is intentional — a thank-you page, a staging area — no action is needed.',
      expectedBenefit: 'A page with noindex cannot appear in search results at all, so removing it is a precondition for any other SEO work on that page.',
      confidence: 'high',
      dataBasis: 'crawled_page',
    });
  }

  const nofollowed = pages.filter((page) => page.robots.nofollow);
  if (nofollowed.length > 0) {
    findings.push({
      id: nextId('seo-nofollow-page'),
      category: 'Indexability',
      severity: 'medium',
      issue: `${pluralPages(nofollowed.length)} tell search engines not to follow any of their links.`,
      evidence: {
        observation: 'These pages carry a page-level robots directive containing "nofollow".',
        urls: sample(nofollowed.map((page) => page.url)),
        affectedCount: nofollowed.length,
        totalCount: pages.length,
      },
      recommendation: 'Remove the page-level nofollow unless you specifically intend to stop link discovery through these pages.',
      expectedBenefit: 'Links on these pages would then contribute to how the rest of the site is discovered and understood.',
      confidence: 'high',
      dataBasis: 'crawled_page',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* Metadata                                                                   */
/* -------------------------------------------------------------------------- */

function titles(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];
  const missing = pages.filter((page) => page.title === null || page.title.trim().length === 0);
  const short = pages.filter((page) => page.title !== null && page.title.length > 0 && page.title.length < SEO_THRESHOLDS.titleMin);
  const long = pages.filter((page) => (page.title?.length ?? 0) > SEO_THRESHOLDS.titleMax);

  if (missing.length > 0) {
    findings.push({
      id: nextId('seo-title-missing'),
      category: 'Metadata',
      severity: 'critical',
      issue: `${pluralPages(missing.length)} have no title element.`,
      evidence: {
        observation: 'No non-empty <title> was found in the head of these pages.',
        urls: sample(missing.map((page) => page.url)),
        affectedCount: missing.length,
        totalCount: pages.length,
      },
      recommendation:
        `Give every page a unique title of roughly ${SEO_THRESHOLDS.titleMin}–${SEO_THRESHOLDS.titleMax} characters that describes that specific page.`,
      expectedBenefit:
        'The title is the primary thing search engines and people use to decide what a page is about, and it is the clickable line in a search result.',
      confidence: 'high',
      dataBasis: 'crawled_page',
    });
  }

  // Duplicates are reported separately because the fix is different.
  // Compared case-insensitively, but REPORTED as written: showing the user a
  // lowercased version of their own title reads as though we changed it.
  const byTitle = new Map<string, { display: string; urls: string[] }>();
  for (const page of pages) {
    if (!page.title) continue;
    const key = page.title.trim().toLowerCase();
    const existing = byTitle.get(key);
    if (existing) existing.urls.push(page.url);
    else byTitle.set(key, { display: page.title.trim(), urls: [page.url] });
  }
  const duplicated = [...byTitle.values()].filter((entry) => entry.urls.length > 1);

  if (duplicated.length > 0) {
    const affected = duplicated.reduce((sum, entry) => sum + entry.urls.length, 0);
    findings.push({
      id: nextId('seo-title-duplicate'),
      category: 'Metadata',
      severity: 'high',
      issue: `${duplicated.length} title${duplicated.length === 1 ? ' is' : 's are'} used on more than one page.`,
      evidence: {
        observation: duplicated
          .slice(0, 3)
          .map((entry) => `"${entry.display}" appears on ${entry.urls.length} pages (${entry.urls.slice(0, 2).join(', ')})`)
          .join('; '),
        urls: sample(duplicated.flatMap((entry) => entry.urls)),
        affectedCount: affected,
        totalCount: pages.length,
      },
      recommendation: 'Write a distinct title for each page, naming what is specific to it.',
      expectedBenefit:
        'Distinct titles help search engines tell the pages apart, and make a result list easier for a person to choose from.',
      confidence: 'high',
      dataBasis: 'crawl_summary',
    });
  }

  if (long.length > 0) {
    findings.push({
      id: nextId('seo-title-long'),
      category: 'Metadata',
      severity: 'low',
      issue: `${pluralPages(long.length)} have a title longer than ${SEO_THRESHOLDS.titleMax} characters.`,
      evidence: {
        observation: `The longest is ${Math.max(...long.map((page) => page.title?.length ?? 0))} characters.`,
        urls: sample(long.map((page) => page.url)),
        affectedCount: long.length,
        totalCount: pages.length,
      },
      recommendation:
        `Put the distinguishing words first. Titles are usually truncated around ${SEO_THRESHOLDS.titleMax} characters in a result list, though the exact point depends on pixel width rather than character count.`,
      expectedBenefit: 'More of the title is visible in a search result, so a person can see what the page offers.',
      confidence: 'medium',
      dataBasis: 'crawled_page',
    });
  }

  if (short.length > 0) {
    findings.push({
      id: nextId('seo-title-short'),
      category: 'Metadata',
      severity: 'low',
      issue: `${pluralPages(short.length)} have a very short title.`,
      evidence: {
        observation: short
          .slice(0, 3)
          .map((page) => `"${page.title}" (${page.title?.length} characters)`)
          .join('; '),
        urls: sample(short.map((page) => page.url)),
        affectedCount: short.length,
        totalCount: pages.length,
      },
      recommendation: 'Expand these titles to describe the page, rather than naming it in one or two words.',
      expectedBenefit: 'A fuller title gives search engines and readers more to match against what they were looking for.',
      confidence: 'medium',
      dataBasis: 'crawled_page',
    });
  }

  return findings;
}

function descriptions(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];
  const indexable = pages.filter((page) => !page.robots.noindex);
  const missing = indexable.filter((page) => page.metaDescription === null);
  const long = indexable.filter((page) => (page.metaDescription?.length ?? 0) > SEO_THRESHOLDS.descriptionMax);
  const short = indexable.filter(
    (page) => page.metaDescription !== null && page.metaDescription.length < SEO_THRESHOLDS.descriptionMin,
  );

  if (missing.length > 0) {
    findings.push({
      id: nextId('seo-desc-missing'),
      category: 'Metadata',
      severity: 'medium',
      issue: `${pluralPages(missing.length)} have no meta description.`,
      evidence: {
        observation: 'No <meta name="description"> was found on these pages.',
        urls: sample(missing.map((page) => page.url)),
        affectedCount: missing.length,
        totalCount: indexable.length,
      },
      recommendation:
        `Write a description of roughly ${SEO_THRESHOLDS.descriptionMin}–${SEO_THRESHOLDS.descriptionMax} characters for each page, saying what the reader will get.`,
      expectedBenefit:
        'Without one, search engines compose a snippet from the page text. Writing it yourself gives you control over what is shown, though search engines may still substitute their own.',
      confidence: 'high',
      dataBasis: 'crawled_page',
    });
  }

  if (long.length > 0) {
    findings.push({
      id: nextId('seo-desc-long'),
      category: 'Metadata',
      severity: 'low',
      issue: `${pluralPages(long.length)} have a meta description over ${SEO_THRESHOLDS.descriptionMax} characters.`,
      evidence: {
        observation: `The longest is ${Math.max(...long.map((page) => page.metaDescription?.length ?? 0))} characters.`,
        urls: sample(long.map((page) => page.url)),
        affectedCount: long.length,
        totalCount: indexable.length,
      },
      recommendation: 'Lead with the point. The tail is likely to be cut off in a result list.',
      expectedBenefit: 'The part of the description a person actually reads says what you meant it to say.',
      confidence: 'medium',
      dataBasis: 'crawled_page',
    });
  }

  if (short.length > 0) {
    findings.push({
      id: nextId('seo-desc-short'),
      category: 'Metadata',
      severity: 'low',
      issue: `${pluralPages(short.length)} have a very short meta description.`,
      evidence: {
        observation: `These descriptions are under ${SEO_THRESHOLDS.descriptionMin} characters.`,
        urls: sample(short.map((page) => page.url)),
        affectedCount: short.length,
        totalCount: indexable.length,
      },
      recommendation: 'Use the available space to say what the page covers and who it is for.',
      expectedBenefit: 'A fuller snippet gives a reader more reason to choose this result.',
      confidence: 'low',
      dataBasis: 'crawled_page',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* Headings                                                                   */
/* -------------------------------------------------------------------------- */

function headings(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];
  const noH1 = pages.filter((page) => page.h1.length === 0);
  const manyH1 = pages.filter((page) => page.h1.length > 1);
  const h3WithoutH2 = pages.filter((page) => page.h3.length > 0 && page.h2.length === 0);

  if (noH1.length > 0) {
    findings.push({
      id: nextId('seo-h1-missing'),
      category: 'Headings',
      severity: 'high',
      issue: `${pluralPages(noH1.length)} have no h1.`,
      evidence: {
        observation: 'No <h1> element was found in the body of these pages.',
        urls: sample(noH1.map((page) => page.url)),
        affectedCount: noH1.length,
        totalCount: pages.length,
      },
      recommendation: 'Give each page one h1 that states what the page is about.',
      expectedBenefit:
        'The h1 is a strong on-page signal of topic, and it is how screen-reader users identify the main heading of a page.',
      confidence: 'high',
      dataBasis: 'crawled_page',
    });
  }

  if (manyH1.length > 0) {
    findings.push({
      id: nextId('seo-h1-multiple'),
      category: 'Headings',
      severity: 'low',
      issue: `${pluralPages(manyH1.length)} have more than one h1.`,
      evidence: {
        observation: manyH1
          .slice(0, 3)
          .map((page) => `${page.url} has ${page.h1.length}`)
          .join('; '),
        urls: sample(manyH1.map((page) => page.url)),
        affectedCount: manyH1.length,
        totalCount: pages.length,
      },
      recommendation:
        'Use one h1 per page and h2 for the sections beneath it. Multiple h1s are valid HTML5 and search engines handle them, so this is a clarity improvement rather than an error.',
      expectedBenefit: 'A single h1 makes the page’s main subject unambiguous to both readers and parsers.',
      confidence: 'medium',
      dataBasis: 'crawled_page',
    });
  }

  if (h3WithoutH2.length > 0) {
    findings.push({
      id: nextId('seo-heading-skip'),
      category: 'Headings',
      severity: 'low',
      issue: `${pluralPages(h3WithoutH2.length)} use h3 without any h2, skipping a level.`,
      evidence: {
        observation: 'These pages contain h3 elements but no h2.',
        urls: sample(h3WithoutH2.map((page) => page.url)),
        affectedCount: h3WithoutH2.length,
        totalCount: pages.length,
      },
      recommendation: 'Use heading levels in order, so the document outline reflects the real structure.',
      expectedBenefit:
        'A correct outline is how assistive technology lets a user navigate a page, and it makes the section hierarchy legible to parsers.',
      confidence: 'high',
      dataBasis: 'crawled_page',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* Content                                                                    */
/* -------------------------------------------------------------------------- */

function content(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];
  const indexable = pages.filter((page) => !page.robots.noindex);
  const thin = indexable.filter((page) => page.wordCount < SEO_THRESHOLDS.thinContentWords);

  if (thin.length > 0) {
    findings.push({
      id: nextId('seo-thin-content'),
      category: 'Content',
      severity: thin.length > indexable.length / 2 ? 'high' : 'medium',
      issue: `${pluralPages(thin.length)} have under ${SEO_THRESHOLDS.thinContentWords} words of text.`,
      evidence: {
        observation: thin
          .slice(0, 3)
          .map((page) => `${page.url} has ${page.wordCount} words`)
          .join('; '),
        urls: sample(thin.map((page) => page.url)),
        affectedCount: thin.length,
        totalCount: indexable.length,
      },
      recommendation:
        'Expand these pages to answer what a visitor arriving on them actually wants to know, or merge them into a fuller page. Note that this crawler does not run JavaScript, so content added in the browser is not counted here.',
      expectedBenefit:
        'A page with substantive content has something specific to match a search against. There is no minimum word count that search engines require.',
      confidence: 'medium',
      dataBasis: 'crawled_page',
    });
  }

  // Near-duplicate body text, compared on a normalised prefix.
  const byText = new Map<string, string[]>();
  for (const page of indexable) {
    if (page.wordCount < 30) continue;
    const key = page.text.toLowerCase().replace(/\s+/g, ' ').slice(0, 500);
    const existing = byText.get(key);
    if (existing) existing.push(page.url);
    else byText.set(key, [page.url]);
  }
  const duplicated = [...byText.values()].filter((urls) => urls.length > 1);

  if (duplicated.length > 0) {
    findings.push({
      id: nextId('seo-duplicate-content'),
      category: 'Content',
      severity: 'medium',
      issue: `${duplicated.length} group${duplicated.length === 1 ? '' : 's'} of pages open with identical text.`,
      evidence: {
        observation: `Compared on the first 500 characters of body text. Example: ${duplicated[0]?.slice(0, 3).join(', ')}`,
        urls: sample(duplicated.flat()),
        affectedCount: duplicated.reduce((sum, urls) => sum + urls.length, 0),
        totalCount: indexable.length,
      },
      recommendation:
        'Differentiate these pages, or pick one as canonical and point the others at it. This check compares only the opening text, so verify before consolidating.',
      expectedBenefit:
        'Search engines choose one version of duplicated content to show. Choosing for them means the version you prefer is the one that appears.',
      confidence: 'medium',
      dataBasis: 'crawl_summary',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* Canonicals                                                                 */
/* -------------------------------------------------------------------------- */

function canonicals(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];
  const indexable = pages.filter((page) => !page.robots.noindex);
  const missing = indexable.filter((page) => page.canonical === null);

  const mismatched = indexable.filter((page) => {
    if (!page.canonical) return false;
    try {
      return normalizeUrl(page.canonical) !== normalizeUrl(page.url);
    } catch {
      return false;
    }
  });

  if (missing.length > 0) {
    findings.push({
      id: nextId('seo-canonical-missing'),
      category: 'Canonicals',
      severity: 'medium',
      issue: `${pluralPages(missing.length)} have no canonical link.`,
      evidence: {
        observation: 'No <link rel="canonical"> was found in the head of these pages.',
        urls: sample(missing.map((page) => page.url)),
        affectedCount: missing.length,
        totalCount: indexable.length,
      },
      recommendation:
        'Add a self-referencing canonical to each page, using the absolute HTTPS URL you want indexed.',
      expectedBenefit:
        'A canonical tells search engines which URL to treat as the real one when a page is reachable several ways — with and without a trailing slash, with tracking parameters, and so on.',
      confidence: 'high',
      dataBasis: 'crawled_page',
    });
  }

  if (mismatched.length > 0) {
    findings.push({
      id: nextId('seo-canonical-mismatch'),
      category: 'Canonicals',
      severity: 'medium',
      issue: `${pluralPages(mismatched.length)} name a different URL as canonical.`,
      evidence: {
        observation: mismatched
          .slice(0, 3)
          .map((page) => `${page.url} points at ${page.canonical}`)
          .join('; '),
        urls: sample(mismatched.map((page) => page.url)),
        affectedCount: mismatched.length,
        totalCount: indexable.length,
      },
      recommendation:
        'Confirm this is deliberate. A cross-canonical is correct for a genuine duplicate and is a mistake when it points at an unrelated page or at the home page.',
      expectedBenefit:
        'Where the canonical is wrong, the page is asking not to be indexed on its own merits, so correcting it makes the page eligible again.',
      confidence: 'medium',
      dataBasis: 'crawled_page',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* Sitemap and robots                                                         */
/* -------------------------------------------------------------------------- */

function sitemapChecks(report: CrawlReport): Finding[] {
  const findings: Finding[] = [];

  if (!report.sitemap.found) {
    findings.push({
      id: nextId('seo-sitemap-missing'),
      category: 'Sitemap',
      severity: 'medium',
      issue: 'No XML sitemap was found.',
      evidence: {
        observation: report.sitemap.note,
        urls: [report.robots.url],
        affectedCount: 1,
      },
      recommendation:
        'Publish a sitemap listing the URLs you want indexed, and reference it from robots.txt with a Sitemap: line.',
      expectedBenefit:
        'A sitemap gives search engines a direct list of your URLs rather than relying entirely on them finding everything by following links. It helps discovery; it does not by itself affect ranking.',
      confidence: 'high',
      dataBasis: 'crawl_summary',
    });
    return findings;
  }

  // URLs in the sitemap that the crawl could not read.
  const crawled = new Set(report.pages.map((page) => safeNormalize(page.url)));
  const failed = new Set(report.failures.map((failure) => safeNormalize(failure.url)));
  const brokenInSitemap = report.sitemap.urls.filter((url) => failed.has(safeNormalize(url)));

  if (brokenInSitemap.length > 0) {
    findings.push({
      id: nextId('seo-sitemap-broken'),
      category: 'Sitemap',
      severity: 'high',
      issue: `The sitemap lists ${brokenInSitemap.length} URL${brokenInSitemap.length === 1 ? '' : 's'} that did not load.`,
      evidence: {
        observation: 'These sitemap URLs returned an error or could not be fetched during this crawl.',
        urls: sample(brokenInSitemap),
        affectedCount: brokenInSitemap.length,
        totalCount: report.sitemap.urls.length,
      },
      recommendation: 'Remove URLs that no longer exist from the sitemap, or restore the pages.',
      expectedBenefit:
        'A sitemap that only lists working URLs spends a search engine’s crawl attention on pages that exist.',
      confidence: 'high',
      dataBasis: 'sitemap',
    });
  }

  // Pages found by crawling that the sitemap omits.
  const inSitemap = new Set(report.sitemap.urls.map(safeNormalize));
  const missingFromSitemap = [...crawled].filter((url) => !inSitemap.has(url));

  if (missingFromSitemap.length > 0 && report.sitemap.urls.length > 0) {
    findings.push({
      id: nextId('seo-sitemap-incomplete'),
      category: 'Sitemap',
      severity: 'low',
      issue: `${missingFromSitemap.length} crawled page${missingFromSitemap.length === 1 ? '' : 's'} are not in the sitemap.`,
      evidence: {
        observation: 'These pages were found by following links but are not listed in the sitemap.',
        urls: sample(missingFromSitemap),
        affectedCount: missingFromSitemap.length,
        totalCount: report.pages.length,
      },
      recommendation:
        'Add the pages you want indexed to the sitemap, or confirm their omission is deliberate. Note this crawl covered only part of the site if a page limit was reached.',
      expectedBenefit: 'Listed pages are discoverable without depending on the link path to them being followed.',
      confidence: 'medium',
      dataBasis: 'crawl_summary',
    });
  }

  return findings;
}

function safeNormalize(url: string): string {
  try {
    return normalizeUrl(url);
  } catch {
    return url;
  }
}

function robotsChecks(report: CrawlReport): Finding[] {
  const findings: Finding[] = [];

  if (!report.robots.found && report.robots.respected) {
    findings.push({
      id: nextId('seo-robots-missing'),
      category: 'Robots',
      severity: 'low',
      issue: 'No robots.txt was found.',
      evidence: {
        observation: `${report.robots.url} did not return a robots.txt file.`,
        urls: [report.robots.url],
        affectedCount: 1,
      },
      recommendation:
        'Add a robots.txt, even a permissive one, and use it to point at your sitemap. Without it, every crawler guesses.',
      expectedBenefit:
        'You gain a place to declare your sitemap and to keep crawlers out of areas that waste their time, such as faceted search URLs.',
      confidence: 'high',
      dataBasis: 'robots_txt',
    });
  }

  if (report.robots.blockedCount > 0) {
    findings.push({
      id: nextId('seo-robots-blocked'),
      category: 'Robots',
      severity: 'info',
      issue: `robots.txt blocked ${report.robots.blockedCount} URL${report.robots.blockedCount === 1 ? '' : 's'} from this crawl.`,
      evidence: {
        observation: `${report.robots.summary} These URLs were discovered but not fetched, in line with your rules.`,
        urls: [report.robots.url],
        affectedCount: report.robots.blockedCount,
      },
      recommendation:
        'No action needed if that is intended. If any of those pages should be in search results, loosen the matching rule.',
      expectedBenefit:
        'Understanding what robots.txt excludes tells you which parts of the site no search engine is reading.',
      confidence: 'high',
      dataBasis: 'robots_txt',
    });
  }

  if (report.robots.found && report.sitemap.found && report.robots.sitemapsDeclared.length === 0) {
    findings.push({
      id: nextId('seo-robots-no-sitemap'),
      category: 'Robots',
      severity: 'low',
      issue: 'robots.txt does not reference the sitemap.',
      evidence: {
        observation: `A sitemap was found at ${report.sitemap.locations[0] ?? 'a conventional location'}, but robots.txt contains no Sitemap: line.`,
        urls: [report.robots.url],
        affectedCount: 1,
      },
      recommendation: `Add "Sitemap: ${report.sitemap.locations[0] ?? 'https://your-site/sitemap.xml'}" to robots.txt.`,
      expectedBenefit: 'Crawlers find the sitemap without having to guess its location.',
      confidence: 'high',
      dataBasis: 'robots_txt',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* Broken links                                                               */
/* -------------------------------------------------------------------------- */

function brokenLinks(report: CrawlReport): Finding[] {
  const findings: Finding[] = [];
  const broken = report.failures.filter((failure) => failure.code === 'http_error');

  if (broken.length > 0) {
    // Which pages link to each broken URL — the information needed to fix it.
    const linkedFrom = new Map<string, string[]>();
    for (const page of report.pages) {
      for (const link of page.links) {
        if (broken.some((failure) => safeNormalize(failure.url) === safeNormalize(link.url))) {
          const existing = linkedFrom.get(link.url);
          if (existing) existing.push(page.url);
          else linkedFrom.set(link.url, [page.url]);
        }
      }
    }

    findings.push({
      id: nextId('seo-broken-links'),
      category: 'Broken links',
      severity: 'high',
      issue: `${broken.length} internal URL${broken.length === 1 ? '' : 's'} returned an error.`,
      evidence: {
        observation: broken
          .slice(0, 5)
          .map((failure) => {
            const sources = linkedFrom.get(failure.url);
            const from = sources && sources.length > 0 ? `, linked from ${sources[0]}` : '';
            return `${failure.url} returned ${failure.status ?? 'an error'}${from}`;
          })
          .join('; '),
        urls: sample(broken.map((failure) => failure.url)),
        affectedCount: broken.length,
      },
      recommendation:
        'Fix or remove the links pointing at these URLs. Where a page has moved, redirect the old URL to the new one with a 301 rather than leaving it to 404.',
      expectedBenefit:
        'Visitors stop hitting dead ends, and crawl attention goes to pages that exist rather than to errors.',
      confidence: 'high',
      dataBasis: 'crawl_summary',
    });
  }

  const unreachable = report.failures.filter(
    (failure) => failure.code === 'timeout' || failure.code === 'network_error',
  );
  if (unreachable.length > 0) {
    findings.push({
      id: nextId('seo-unreachable'),
      category: 'Technical',
      severity: 'high',
      issue: `${unreachable.length} URL${unreachable.length === 1 ? '' : 's'} could not be reached.`,
      evidence: {
        observation: unreachable
          .slice(0, 5)
          .map((failure) => `${failure.url}: ${failure.reason}`)
          .join('; '),
        urls: sample(unreachable.map((failure) => failure.url)),
        affectedCount: unreachable.length,
      },
      recommendation:
        'Check whether these pages are slow or intermittently failing. A crawler that times out is seeing what a visitor on a poor connection sees.',
      expectedBenefit: 'Reliably reachable pages can be indexed; intermittently failing ones may be dropped.',
      confidence: 'medium',
      dataBasis: 'crawl_summary',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* Images                                                                     */
/* -------------------------------------------------------------------------- */

function images(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];

  let total = 0;
  let missingAlt = 0;
  let withoutDimensions = 0;
  const pagesWithMissingAlt: string[] = [];

  for (const page of pages) {
    for (const image of page.images) {
      total += 1;
      // null means the attribute is absent; '' is a valid decorative image.
      if (image.alt === null) {
        missingAlt += 1;
        if (!pagesWithMissingAlt.includes(page.url)) pagesWithMissingAlt.push(page.url);
      }
      if (!image.hasDimensions) withoutDimensions += 1;
    }
  }

  if (missingAlt > 0) {
    findings.push({
      id: nextId('seo-image-alt'),
      category: 'Images',
      severity: 'medium',
      issue: `${missingAlt} image${missingAlt === 1 ? '' : 's'} have no alt attribute.`,
      evidence: {
        observation: `${missingAlt} of ${total} images across ${pluralPages(pagesWithMissingAlt.length)} have no alt attribute at all. An empty alt="" is correct for a decorative image and is not counted here.`,
        urls: sample(pagesWithMissingAlt),
        affectedCount: missingAlt,
        totalCount: total,
      },
      recommendation:
        'Describe each meaningful image in its alt text. Use alt="" for images that are purely decorative.',
      expectedBenefit:
        'Alt text is what a screen-reader user hears in place of the image, and it is how image search understands the picture. It is an accessibility requirement under WCAG as well as an SEO one.',
      confidence: 'high',
      dataBasis: 'crawled_page',
    });
  }

  if (withoutDimensions > 0 && total > 0) {
    findings.push({
      id: nextId('seo-image-dimensions'),
      category: 'Images',
      severity: 'low',
      issue: `${withoutDimensions} image${withoutDimensions === 1 ? '' : 's'} have no width and height attributes.`,
      evidence: {
        observation: `${withoutDimensions} of ${total} images omit width or height.`,
        urls: sample(pages.filter((page) => page.images.some((image) => !image.hasDimensions)).map((page) => page.url)),
        affectedCount: withoutDimensions,
        totalCount: total,
      },
      recommendation: 'Set width and height on images so the browser can reserve space before the image loads.',
      expectedBenefit:
        'Reserved space prevents content shifting as images arrive, which is what Cumulative Layout Shift measures.',
      confidence: 'high',
      dataBasis: 'crawled_page',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* Mobile                                                                     */
/* -------------------------------------------------------------------------- */

function mobile(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];
  const noViewport = pages.filter((page) => !page.hasViewportMeta);

  if (noViewport.length > 0) {
    findings.push({
      id: nextId('seo-viewport'),
      category: 'Mobile',
      severity: 'high',
      issue: `${pluralPages(noViewport.length)} have no viewport meta tag.`,
      evidence: {
        observation: 'No <meta name="viewport"> was found on these pages.',
        urls: sample(noViewport.map((page) => page.url)),
        affectedCount: noViewport.length,
        totalCount: pages.length,
      },
      recommendation: 'Add <meta name="viewport" content="width=device-width, initial-scale=1"> to every page.',
      expectedBenefit:
        'Without it, mobile browsers render the page at desktop width and scale it down, which makes text unreadable. Google indexes the mobile version of a page.',
      confidence: 'high',
      dataBasis: 'crawled_page',
    });
  }

  // A real mobile-friendliness assessment needs rendering, which this does not
  // do. That limitation is reported in `notChecked` rather than guessed at here.
  return findings;
}

/* -------------------------------------------------------------------------- */
/* Performance indicators                                                     */
/* -------------------------------------------------------------------------- */

function performance(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];
  const slow = pages.filter((page) => page.responseTimeMs > SEO_THRESHOLDS.slowResponseMs);
  const heavy = pages.filter((page) => page.bytes > SEO_THRESHOLDS.largePageBytes);

  if (slow.length > 0) {
    findings.push({
      id: nextId('seo-slow'),
      category: 'Performance',
      severity: 'medium',
      issue: `${pluralPages(slow.length)} took over ${SEO_THRESHOLDS.slowResponseMs} ms to respond.`,
      evidence: {
        observation: slow
          .slice(0, 3)
          .map((page) => `${page.url} took ${page.responseTimeMs} ms`)
          .join('; '),
        urls: sample(slow.map((page) => page.url)),
        affectedCount: slow.length,
        totalCount: pages.length,
      },
      recommendation:
        'Look at what is slow on the server for these URLs — an uncached query, a slow template, an external call in the request path.',
      expectedBenefit:
        'A faster server response shortens every page load. This is one input to Largest Contentful Paint; it is not a Core Web Vitals measurement, which needs a real browser.',
      confidence: 'medium',
      dataBasis: 'crawled_page',
    });
  }

  if (heavy.length > 0) {
    findings.push({
      id: nextId('seo-heavy'),
      category: 'Performance',
      severity: 'low',
      issue: `${pluralPages(heavy.length)} return more than ${(SEO_THRESHOLDS.largePageBytes / 1_000_000).toFixed(1)} MB of HTML.`,
      evidence: {
        observation: heavy
          .slice(0, 3)
          .map((page) => `${page.url} is ${(page.bytes / 1_000_000).toFixed(2)} MB`)
          .join('; '),
        urls: sample(heavy.map((page) => page.url)),
        affectedCount: heavy.length,
        totalCount: pages.length,
      },
      recommendation:
        'Check for inlined data or markup that could be loaded separately. This measures the HTML document only, not images or scripts.',
      expectedBenefit: 'A smaller document starts rendering sooner, especially on a slow connection.',
      confidence: 'medium',
      dataBasis: 'crawled_page',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* Structured data                                                            */
/* -------------------------------------------------------------------------- */

function structuredDataChecks(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];
  const withErrors = pages.filter((page) => page.structuredDataErrors.length > 0);
  const without = pages.filter(
    (page) => page.structuredData.length === 0 && page.structuredDataErrors.length === 0,
  );

  if (withErrors.length > 0) {
    findings.push({
      id: nextId('seo-sd-invalid'),
      category: 'Structured data',
      severity: 'high',
      issue: `${pluralPages(withErrors.length)} have structured data that does not parse.`,
      evidence: {
        observation: withErrors
          .slice(0, 3)
          .map((page) => `${page.url}: ${page.structuredDataErrors[0]}`)
          .join('; '),
        urls: sample(withErrors.map((page) => page.url)),
        affectedCount: withErrors.length,
        totalCount: pages.length,
      },
      recommendation:
        'Fix the JSON so it parses. Invalid structured data is ignored entirely, so these pages currently get nothing from it.',
      expectedBenefit:
        'Valid markup becomes eligible for rich result features. Eligibility is not a guarantee that any feature is shown.',
      confidence: 'high',
      dataBasis: 'structured_data',
    });
  }

  if (without.length > 0) {
    findings.push({
      id: nextId('seo-sd-missing'),
      category: 'Structured data',
      severity: 'medium',
      issue: `${pluralPages(without.length)} have no structured data.`,
      evidence: {
        observation: 'No JSON-LD block was found on these pages.',
        urls: sample(without.map((page) => page.url)),
        affectedCount: without.length,
        totalCount: pages.length,
      },
      recommendation:
        'Add the schema.org types that describe these pages honestly — Organization or LocalBusiness for the site, Article for posts, Product for products, FAQPage where you genuinely answer questions. Only describe what is actually on the page.',
      expectedBenefit:
        'Structured data states facts about the page in a form machines read directly, rather than leaving them to be inferred from the text.',
      confidence: 'medium',
      dataBasis: 'crawled_page',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* Entity consistency                                                         */
/* -------------------------------------------------------------------------- */

function entityConsistency(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];

  const names = new Set<string>();
  const phones = new Set<string>();
  const addresses = new Set<string>();
  for (const page of pages) {
    for (const name of page.entities.organizationNames) names.add(name.trim());
    for (const phone of page.entities.telephones) phones.add(normalizePhone(phone));
    for (const address of page.entities.addresses) addresses.add(address.trim().toLowerCase());
  }

  if (names.size > 1) {
    findings.push({
      id: nextId('seo-entity-name'),
      category: 'Entity consistency',
      severity: 'medium',
      issue: `The business is named ${names.size} different ways across the site.`,
      evidence: {
        observation: `Names found: ${[...names].slice(0, 5).map((name) => `"${name}"`).join(', ')}.`,
        urls: sample(pages.filter((page) => page.entities.organizationNames.length > 0).map((page) => page.url)),
        affectedCount: names.size,
      },
      recommendation:
        'Use one exact business name everywhere — structured data, page copy, the site name in Open Graph, and your listings elsewhere.',
      expectedBenefit:
        'A consistent name makes it easier for search engines to treat all mentions as one business rather than as several similar ones.',
      confidence: 'medium',
      dataBasis: 'structured_data',
    });
  }

  if (phones.size > 1) {
    findings.push({
      id: nextId('seo-entity-phone'),
      category: 'Entity consistency',
      severity: 'medium',
      issue: `${phones.size} different phone numbers appear in structured data.`,
      evidence: {
        observation: `Numbers found: ${[...phones].slice(0, 5).join(', ')}. Compared after removing spaces and punctuation.`,
        urls: sample(pages.filter((page) => page.entities.telephones.length > 0).map((page) => page.url)),
        affectedCount: phones.size,
      },
      recommendation:
        'Publish one primary number in structured data and keep it identical to the one in your business listings. Additional numbers belong in separate contactPoint entries, not as alternative primaries.',
      expectedBenefit:
        'A single consistent number is easier to match against other sources of information about the business.',
      confidence: 'medium',
      dataBasis: 'structured_data',
    });
  }

  if (addresses.size > 1) {
    findings.push({
      id: nextId('seo-entity-address'),
      category: 'Entity consistency',
      severity: 'low',
      issue: `${addresses.size} different addresses appear in structured data.`,
      evidence: {
        observation: `Distinct address strings: ${addresses.size}.`,
        urls: sample(pages.filter((page) => page.entities.addresses.length > 0).map((page) => page.url)),
        affectedCount: addresses.size,
      },
      recommendation:
        'Use one formatting of each location. If the business genuinely has several locations, model each one as its own entity rather than varying the address on one.',
      expectedBenefit: 'Consistent formatting avoids one location being read as several.',
      confidence: 'low',
      dataBasis: 'structured_data',
    });
  }

  const withSameAs = pages.filter((page) => page.entities.sameAs.length > 0);
  if (withSameAs.length === 0 && pages.length > 0) {
    findings.push({
      id: nextId('seo-entity-sameas'),
      category: 'Entity consistency',
      severity: 'low',
      issue: 'No sameAs links connect the business to its profiles elsewhere.',
      evidence: {
        observation: 'No sameAs property was found in any structured data across the crawl.',
        urls: sample(pages.map((page) => page.url), 3),
        affectedCount: pages.length,
      },
      recommendation:
        'Add sameAs to your Organization markup, listing the profiles you actually control — LinkedIn, your Google Business Profile, Wikidata if you have an entry.',
      expectedBenefit:
        'sameAs states explicitly that these profiles are the same organisation, rather than leaving it to be inferred.',
      confidence: 'low',
      dataBasis: 'crawl_summary',
    });
  }

  return findings;
}

function normalizePhone(input: string): string {
  return input.replace(/[^\d+]/g, '');
}

/* -------------------------------------------------------------------------- */
/* Internal links                                                             */
/* -------------------------------------------------------------------------- */

function internalLinks(report: CrawlReport): Finding[] {
  const findings: Finding[] = [];
  const pages = report.pages;
  if (pages.length < 2) return findings;

  const inbound = new Map<string, number>();
  for (const page of pages) inbound.set(safeNormalize(page.url), 0);

  for (const page of pages) {
    for (const link of page.links) {
      if (!link.internal) continue;
      const key = safeNormalize(link.url);
      if (key === safeNormalize(page.url)) continue; // self-links do not count
      if (inbound.has(key)) inbound.set(key, (inbound.get(key) ?? 0) + 1);
    }
  }

  const seed = safeNormalize(report.siteUrl);
  const orphans = [...inbound.entries()]
    .filter(([url, count]) => count < SEO_THRESHOLDS.minInboundLinks && url !== seed)
    .map(([url]) => url);

  if (orphans.length > 0) {
    findings.push({
      id: nextId('seo-orphans'),
      category: 'Internal links',
      severity: 'medium',
      issue: `${pluralPages(orphans.length)} have no internal links pointing at them.`,
      evidence: {
        observation:
          'These pages were found in the sitemap or by redirect, but no other crawled page links to them. Note this covers only the pages in this crawl, so a page linked from an uncrawled page would appear here too.',
        urls: sample(orphans),
        affectedCount: orphans.length,
        totalCount: pages.length,
      },
      recommendation:
        'Link to these pages from somewhere relevant — a navigation menu, a related-content block, or the body of a related page.',
      expectedBenefit:
        'Internal links are how both visitors and crawlers find a page, and they signal which pages you consider important.',
      confidence: 'medium',
      dataBasis: 'crawl_summary',
    });
  }

  const nofollowInternal = pages.flatMap((page) =>
    page.links.filter((link) => link.internal && link.nofollow).map(() => page.url),
  );
  if (nofollowInternal.length > 0) {
    const affectedPages = [...new Set(nofollowInternal)];
    findings.push({
      id: nextId('seo-nofollow-internal'),
      category: 'Internal links',
      severity: 'low',
      issue: `${nofollowInternal.length} internal link${nofollowInternal.length === 1 ? '' : 's'} carry rel="nofollow".`,
      evidence: {
        observation: `Found across ${pluralPages(affectedPages.length)}.`,
        urls: sample(affectedPages),
        affectedCount: nofollowInternal.length,
      },
      recommendation:
        'Remove nofollow from internal links unless there is a specific reason. It was never an effective way to control how crawlers move through a site.',
      expectedBenefit: 'Internal links contribute normally to how the site is crawled and understood.',
      confidence: 'medium',
      dataBasis: 'crawled_page',
    });
  }

  return findings;
}
