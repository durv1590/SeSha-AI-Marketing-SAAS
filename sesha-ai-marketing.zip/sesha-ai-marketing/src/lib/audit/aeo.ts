/**
 * AEO audit — answer engine optimisation.
 *
 * THE HONESTY PROBLEM THIS FILE HAS TO SOLVE
 * AEO is the area where a marketing tool is most tempted to lie. Nobody can
 * measure whether an AI system will cite a page, and no published algorithm
 * connects any on-page property to being quoted in an AI answer. A tool that
 * produces an "AI visibility score" is inventing a number.
 *
 * So this audit reports two kinds of thing and nothing else:
 *
 *  1. MEASURABLE STRUCTURE — does a page answer a question directly near the
 *     top, is the answer a self-contained passage, is there FAQ markup, is
 *     authorship stated, is the content dated. These are facts about the HTML.
 *
 *  2. REASONED OPPORTUNITIES — where the structure is absent, what adding it
 *     would plausibly achieve, stated as a possibility with its reasoning
 *     visible.
 *
 * Every `expectedBenefit` below is phrased as what the CHANGE does to the page,
 * not what it does to an AI system's behaviour. "A self-contained answer can be
 * quoted without surrounding context" is a fact about the text. "This will get
 * you cited by ChatGPT" is a fabrication, and `lintFindings` rejects it.
 *
 * The brief's twelve areas, and where each is covered:
 *   Direct answers ....................... directAnswers
 *   Conversational queries ............... conversational
 *   Question coverage .................... questionCoverage
 *   FAQ opportunities .................... faqOpportunities
 *   Entity consistency ................... entityClarity
 *   Topical authority .................... topicalAuthority
 *   Source opportunities ................. sourceSignals
 *   Passage-level answer opportunities ... passageReadiness
 *   Local answer readiness ............... localReadiness
 *   Product/service answer readiness ..... offeringReadiness
 *   Freshness ............................ freshness
 *   Content clarity ...................... clarity
 */

import { countWords, isQuestion, type CrawlReport, type PageData } from '@/lib/crawler';
import {
  lintFindings,
  scoreFindings,
  sortFindings,
  type Finding,
  type ScoreBreakdown,
} from './finding';
import type { NotChecked } from './seo';

export const AEO_THRESHOLDS = {
  /** A passage a machine can lift without surrounding context. */
  answerMinWords: 25,
  answerMaxWords: 120,
  /** Characters from the start of the body text that count as "near the top". */
  leadCharacters: 600,
  /** Sentences longer than this are hard to quote and hard to read. */
  longSentenceWords: 35,
  /** Content older than this is worth reviewing, not automatically stale. */
  freshnessMonths: 18,
  /** Below this many pages on a subject, topical depth is thin. */
  topicalDepthPages: 3,
} as const;

export interface AeoAudit {
  readonly findings: readonly Finding[];
  readonly score: ScoreBreakdown;
  readonly stats: AeoStats;
  readonly suppressed: readonly string[];
  readonly checkedAt: Date;
  readonly notChecked: readonly NotChecked[];
  /** Stated prominently wherever this audit is shown. */
  readonly disclaimer: string;
}

export interface AeoStats {
  readonly pagesAnalysed: number;
  readonly pagesWithDirectAnswer: number;
  readonly pagesWithFaqMarkup: number;
  readonly questionHeadings: number;
  readonly pagesWithAuthor: number;
  readonly pagesWithDate: number;
  readonly quotablePassages: number;
  readonly averageSentenceWords: number | null;
}

export const AEO_DISCLAIMER =
  'No tool can measure whether an AI system will cite a page, and SeSha does not claim to. ' +
  'This audit reports what is structurally present on your pages and what is missing. ' +
  'The benefits described are what each change does to the page itself — not a prediction about ' +
  'any AI system’s behaviour, and not a promise of visibility, citation or traffic.';

let counter = 0;
function nextId(prefix: string): string {
  counter += 1;
  return `${prefix}-${counter}`;
}

function sample(urls: readonly string[], limit = 10): string[] {
  return urls.slice(0, limit);
}

function pluralPages(count: number): string {
  return `${count} page${count === 1 ? '' : 's'}`;
}

/* -------------------------------------------------------------------------- */
/* Shared text analysis                                                       */
/* -------------------------------------------------------------------------- */

function sentences(text: string): string[] {
  return text
    .split(/(?<=[.!?])\s+(?=[A-Zऀ-ॿ])/)
    .map((sentence) => sentence.trim())
    .filter((sentence) => sentence.length > 0);
}

/**
 * Does the page answer something in its first screenful?
 *
 * The test is structural: a sentence in the lead that is declarative, of
 * quotable length, and not a question itself. This is a proxy and it is labelled
 * as a heuristic wherever it is reported.
 */
function hasDirectAnswer(page: PageData): boolean {
  const lead = page.text.slice(0, AEO_THRESHOLDS.leadCharacters);
  for (const sentence of sentences(lead)) {
    const words = countWords(sentence);
    if (words >= 8 && words <= AEO_THRESHOLDS.answerMaxWords && !sentence.trim().endsWith('?')) {
      return true;
    }
  }
  return false;
}

/** Passages of a length that can be quoted standalone. */
function quotablePassageCount(page: PageData): number {
  let count = 0;
  let run: string[] = [];
  for (const sentence of sentences(page.text)) {
    run.push(sentence);
    const words = run.reduce((sum, item) => sum + countWords(item), 0);
    if (words >= AEO_THRESHOLDS.answerMinWords && words <= AEO_THRESHOLDS.answerMaxWords) {
      count += 1;
      run = [];
    } else if (words > AEO_THRESHOLDS.answerMaxWords) {
      run = [sentence];
    }
  }
  return count;
}

function hasFaqMarkup(page: PageData): boolean {
  return page.entities.schemaTypes.includes('FAQPage') ||
    page.entities.schemaTypes.includes('QAPage') ||
    page.entities.schemaTypes.includes('Question');
}

/* -------------------------------------------------------------------------- */
/* The audit                                                                  */
/* -------------------------------------------------------------------------- */

export function auditAeo(report: CrawlReport): AeoAudit {
  counter = 0;
  const pages = report.pages.filter((page) => !page.robots.noindex);

  const raw: Finding[] = [
    ...directAnswers(pages),
    ...conversational(pages),
    ...questionCoverage(pages),
    ...faqOpportunities(pages),
    ...passageReadiness(pages),
    ...entityClarity(pages),
    ...topicalAuthority(pages),
    ...sourceSignals(pages),
    ...localReadiness(pages),
    ...offeringReadiness(pages),
    ...freshness(pages),
    ...clarity(pages),
  ];

  const linted = lintFindings(raw);

  return {
    findings: sortFindings(linted.findings),
    score: scoreFindings(linted.findings),
    stats: statsOf(pages),
    suppressed: linted.dropped,
    checkedAt: new Date(),
    notChecked: notChecked(pages),
    disclaimer: AEO_DISCLAIMER,
  };
}

function statsOf(pages: readonly PageData[]): AeoStats {
  let sentenceCount = 0;
  let wordCount = 0;
  for (const page of pages) {
    for (const sentence of sentences(page.text)) {
      sentenceCount += 1;
      wordCount += countWords(sentence);
    }
  }

  return {
    pagesAnalysed: pages.length,
    pagesWithDirectAnswer: pages.filter(hasDirectAnswer).length,
    pagesWithFaqMarkup: pages.filter(hasFaqMarkup).length,
    questionHeadings: pages.reduce(
      (sum, page) => sum + [...page.h2, ...page.h3].filter(isQuestion).length,
      0,
    ),
    pagesWithAuthor: pages.filter((page) => page.author !== null).length,
    pagesWithDate: pages.filter((page) => page.publishedAt !== null || page.modifiedAt !== null).length,
    quotablePassages: pages.reduce((sum, page) => sum + quotablePassageCount(page), 0),
    averageSentenceWords: sentenceCount > 0 ? Math.round(wordCount / sentenceCount) : null,
  };
}

function notChecked(pages: readonly PageData[]): NotChecked[] {
  const out: NotChecked[] = [
    {
      area: 'Whether any AI system cites your pages',
      reason:
        'AI systems publish no interface for querying what they cite, and their selection processes are not documented. This is not measurable by any tool.',
      whatWouldHelp: 'Nothing currently available. Treat any product claiming to measure it with suspicion.',
    },
    {
      area: 'How often your pages are retrieved as sources',
      reason: 'Retrieval happens inside the AI provider and is not reported to the site being retrieved from.',
      whatWouldHelp: 'Server log analysis can show AI crawler user agents visiting, which is visits rather than citations.',
    },
    {
      area: 'Search volume for the questions on your pages',
      reason: 'SeSha has no keyword data source connected, so no volume figure is shown anywhere.',
      whatWouldHelp: 'Connecting Google Search Console, or a keyword data provider.',
    },
  ];

  if (pages.length === 0) {
    out.push({
      area: 'Everything',
      reason: 'No indexable page was read, so there was no content to analyse.',
      whatWouldHelp: 'A crawl that reads at least one page that is not marked noindex.',
    });
  }
  return out;
}

/* -------------------------------------------------------------------------- */
/* 1. Direct answers                                                          */
/* -------------------------------------------------------------------------- */

function directAnswers(pages: readonly PageData[]): Finding[] {
  if (pages.length === 0) return [];
  const without = pages.filter((page) => !hasDirectAnswer(page));
  if (without.length === 0) return [];

  return [
    {
      id: nextId('aeo-direct'),
      category: 'Direct answers',
      severity: without.length > pages.length / 2 ? 'high' : 'medium',
      issue: `${pluralPages(without.length)} do not state a clear answer near the top.`,
      evidence: {
        observation:
          `In the first ${AEO_THRESHOLDS.leadCharacters} characters of these pages, no declarative sentence of quotable length was found. ` +
          `Checked structurally: sentence length and position, not meaning.`,
        urls: sample(without.map((page) => page.url)),
        affectedCount: without.length,
        totalCount: pages.length,
      },
      recommendation:
        'Open each page with one or two sentences that answer the question the page exists to answer, before the background, the history or the sales argument.',
      expectedBenefit:
        'A reader — and anything reading the page mechanically — finds the answer without having to synthesise it from several paragraphs. It also tends to reduce the number of people who leave without finding what they came for.',
      confidence: 'medium',
      dataBasis: 'crawled_page',
    },
  ];
}

/* -------------------------------------------------------------------------- */
/* 2. Conversational queries                                                  */
/* -------------------------------------------------------------------------- */

function conversational(pages: readonly PageData[]): Finding[] {
  if (pages.length === 0) return [];

  const withQuestionHeadings = pages.filter((page) =>
    [...page.h1, ...page.h2, ...page.h3].some(isQuestion),
  );

  if (withQuestionHeadings.length > 0) return [];

  return [
    {
      id: nextId('aeo-conversational'),
      category: 'Conversational queries',
      severity: 'medium',
      issue: 'No heading anywhere on the site is phrased as a question.',
      evidence: {
        observation: `Checked every h1, h2 and h3 across ${pluralPages(pages.length)}. None ends in a question mark or opens with a question word.`,
        urls: sample(pages.map((page) => page.url), 5),
        affectedCount: pages.length,
        totalCount: pages.length,
      },
      recommendation:
        'Where a section answers a question people actually ask, phrase the heading as that question — "How long does delivery take?" rather than "Delivery information".',
      expectedBenefit:
        'The heading then matches the wording of a spoken or typed question, and the section beneath it reads as an answer to a specific thing rather than as a topic area.',
      confidence: 'medium',
      dataBasis: 'crawl_summary',
    },
  ];
}

/* -------------------------------------------------------------------------- */
/* 3. Question coverage                                                       */
/* -------------------------------------------------------------------------- */

function questionCoverage(pages: readonly PageData[]): Finding[] {
  if (pages.length === 0) return [];

  const questionsAsked = new Set<string>();
  for (const page of pages) {
    for (const heading of [...page.h1, ...page.h2, ...page.h3]) {
      if (isQuestion(heading)) questionsAsked.add(heading.toLowerCase());
    }
    for (const faq of page.faqs) questionsAsked.add(faq.question.toLowerCase());
  }

  // A question heading with no text beneath it cannot be found structurally
  // without a real tree, so what is reported is the count and its limits.
  if (questionsAsked.size > 0 && questionsAsked.size < 5) {
    return [
      {
        id: nextId('aeo-question-coverage'),
        category: 'Question coverage',
        severity: 'low',
        issue: `Only ${questionsAsked.size} distinct question${questionsAsked.size === 1 ? ' is' : 's are'} addressed across the site.`,
        evidence: {
          observation: `Counted from question-phrased headings and FAQ markup: ${[...questionsAsked].slice(0, 4).map((q) => `"${q}"`).join(', ')}.`,
          urls: sample(pages.map((page) => page.url), 5),
          affectedCount: questionsAsked.size,
        },
        recommendation:
          'List the questions your customers actually ask — from sales calls, support messages, the contact form — and answer each one in its own section or page.',
        expectedBenefit:
          'Each question answered is one more specific thing the site can be matched against, instead of relying on a general description of the business.',
        confidence: 'low',
        dataBasis: 'crawl_summary',
      },
    ];
  }
  return [];
}

/* -------------------------------------------------------------------------- */
/* 4. FAQ opportunities                                                       */
/* -------------------------------------------------------------------------- */

function faqOpportunities(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];

  // Pages that clearly have Q&A content in their headings but no FAQ markup:
  // the one case where the recommendation is concrete and low-risk.
  const candidates = pages.filter((page) => {
    const questionHeadings = [...page.h2, ...page.h3].filter(isQuestion);
    return questionHeadings.length >= 2 && !hasFaqMarkup(page);
  });

  if (candidates.length > 0) {
    findings.push({
      id: nextId('aeo-faq-markup'),
      category: 'FAQ',
      severity: 'medium',
      issue: `${pluralPages(candidates.length)} contain question-and-answer content but no FAQPage markup.`,
      evidence: {
        observation: candidates
          .slice(0, 3)
          .map((page) => {
            const count = [...page.h2, ...page.h3].filter(isQuestion).length;
            return `${page.url} has ${count} question headings and no FAQPage structured data`;
          })
          .join('; '),
        urls: sample(candidates.map((page) => page.url)),
        affectedCount: candidates.length,
        totalCount: pages.length,
      },
      recommendation:
        'Add FAQPage structured data describing the questions and answers already on the page. Mark up only what is visible to a visitor — markup that does not match the page is a guidelines violation.',
      expectedBenefit:
        'Each question and its answer become explicitly paired in a machine-readable form, rather than being inferred from heading order.',
      confidence: 'high',
      dataBasis: 'crawled_page',
    });
  }

  const withFaqsNoAnswers = pages.filter(
    (page) => page.faqs.length > 0 && page.faqs.every((faq) => faq.answer === null),
  );
  if (withFaqsNoAnswers.length > 0 && candidates.length === 0) {
    findings.push({
      id: nextId('aeo-faq-answers'),
      category: 'FAQ',
      severity: 'low',
      issue: `${pluralPages(withFaqsNoAnswers.length)} have question headings whose answers could not be identified.`,
      evidence: {
        observation:
          'The questions were found as headings, but no answer text could be attributed to them structurally. This crawler reads HTML without building a full tree, so this may be a limitation of the analysis rather than of the page.',
        urls: sample(withFaqsNoAnswers.map((page) => page.url)),
        affectedCount: withFaqsNoAnswers.length,
        totalCount: pages.length,
      },
      recommendation:
        'Check that each question heading is followed directly by its answer, and consider adding FAQPage markup to pair them explicitly.',
      expectedBenefit: 'An explicitly paired question and answer leaves nothing to be inferred from layout.',
      confidence: 'low',
      dataBasis: 'heuristic',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* 5. Passage-level readiness                                                 */
/* -------------------------------------------------------------------------- */

function passageReadiness(pages: readonly PageData[]): Finding[] {
  if (pages.length === 0) return [];

  const poor = pages.filter((page) => page.wordCount >= 200 && quotablePassageCount(page) === 0);
  if (poor.length === 0) return [];

  return [
    {
      id: nextId('aeo-passage'),
      category: 'Passage readiness',
      severity: 'medium',
      issue: `${pluralPages(poor.length)} contain no self-contained passage of quotable length.`,
      evidence: {
        observation:
          `Looked for runs of ${AEO_THRESHOLDS.answerMinWords}–${AEO_THRESHOLDS.answerMaxWords} words that form a complete thought. ` +
          poor.slice(0, 3).map((page) => `${page.url} (${page.wordCount} words, 0 such passages)`).join('; '),
        urls: sample(poor.map((page) => page.url)),
        affectedCount: poor.length,
        totalCount: pages.length,
      },
      recommendation:
        'Break long stretches of prose into sections where each paragraph makes one point completely, without depending on the paragraph before it for context.',
      expectedBenefit:
        'A passage that stands alone can be quoted, excerpted or summarised without losing its meaning — and is easier to skim.',
      confidence: 'medium',
      dataBasis: 'crawled_page',
    },
  ];
}

/* -------------------------------------------------------------------------- */
/* 6. Entity clarity                                                          */
/* -------------------------------------------------------------------------- */

function entityClarity(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];
  if (pages.length === 0) return findings;

  const hasOrganization = pages.some((page) =>
    page.entities.schemaTypes.some((type) =>
      type === 'Organization' || type === 'LocalBusiness' || type === 'Corporation' ||
      type.endsWith('Business') || type === 'Restaurant' || type.endsWith('Store')),
  );

  if (!hasOrganization) {
    findings.push({
      id: nextId('aeo-entity-missing'),
      category: 'Entity clarity',
      severity: 'high',
      issue: 'Nothing on the site states what organisation it belongs to in machine-readable form.',
      evidence: {
        observation: `No Organization or LocalBusiness structured data was found across ${pluralPages(pages.length)}. Types found: ${
          [...new Set(pages.flatMap((page) => page.entities.schemaTypes))].slice(0, 8).join(', ') || 'none'
        }.`,
        urls: sample(pages.map((page) => page.url), 5),
        affectedCount: pages.length,
        totalCount: pages.length,
      },
      recommendation:
        'Add Organization or LocalBusiness structured data with the exact business name, URL, logo, and sameAs links to profiles you control.',
      expectedBenefit:
        'The site states who it belongs to as a fact rather than leaving it to be inferred from the page text, which is what makes mentions elsewhere connectable to this site.',
      confidence: 'high',
      dataBasis: 'structured_data',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* 7. Topical authority                                                       */
/* -------------------------------------------------------------------------- */

function topicalAuthority(pages: readonly PageData[]): Finding[] {
  if (pages.length < 2) return [];

  // Depth is approximated by URL path grouping, which is how sites actually
  // organise subjects. This is a structural proxy and is labelled as one.
  const sections = new Map<string, string[]>();
  for (const page of pages) {
    let segment: string;
    try {
      segment = new URL(page.url).pathname.split('/').filter(Boolean)[0] ?? '/';
    } catch {
      continue;
    }
    const existing = sections.get(segment);
    if (existing) existing.push(page.url);
    else sections.set(segment, [page.url]);
  }

  const thin = [...sections.entries()].filter(
    ([segment, urls]) => segment !== '/' && urls.length < AEO_THRESHOLDS.topicalDepthPages,
  );

  if (thin.length === 0 || sections.size < 2) return [];

  return [
    {
      id: nextId('aeo-topical'),
      category: 'Topical authority',
      severity: 'low',
      issue: `${thin.length} section${thin.length === 1 ? '' : 's'} of the site contain fewer than ${AEO_THRESHOLDS.topicalDepthPages} pages.`,
      evidence: {
        observation:
          `Grouped by the first path segment, which approximates how the site is organised: ${thin
            .slice(0, 4)
            .map(([segment, urls]) => `/${segment} (${urls.length})`)
            .join(', ')}. This is a structural grouping, not an analysis of what the pages are about.`,
        urls: sample(thin.flatMap(([, urls]) => urls)),
        affectedCount: thin.length,
        totalCount: sections.size,
      },
      recommendation:
        'Where a section matters to your business, cover the subject properly — the main page plus the specific questions, comparisons and how-tos around it — and link them to each other.',
      expectedBenefit:
        'Several linked pages covering one subject give a fuller treatment of it than a single page can, and make the relationships between the pieces explicit.',
      confidence: 'low',
      dataBasis: 'heuristic',
    },
  ];
}

/* -------------------------------------------------------------------------- */
/* 8. Source signals                                                          */
/* -------------------------------------------------------------------------- */

function sourceSignals(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];
  if (pages.length === 0) return findings;

  const withoutAuthor = pages.filter((page) => page.author === null);
  const withoutPublisher = pages.filter((page) => page.publisher === null);

  if (withoutAuthor.length === pages.length) {
    findings.push({
      id: nextId('aeo-author'),
      category: 'Source signals',
      severity: 'medium',
      issue: 'No page states who wrote it.',
      evidence: {
        observation: `Checked structured data author properties and the author meta tag across ${pluralPages(pages.length)}. None found.`,
        urls: sample(pages.map((page) => page.url), 5),
        affectedCount: pages.length,
        totalCount: pages.length,
      },
      recommendation:
        'Name the author on content pages, with a real byline and, where it is relevant, their credentials. Add the author property to your structured data.',
      expectedBenefit:
        'Attribution lets a reader judge who is making a claim. It is also one of the things Google’s quality guidelines describe looking for in content about consequential subjects.',
      confidence: 'medium',
      dataBasis: 'crawl_summary',
    });
  }

  if (withoutPublisher.length === pages.length) {
    findings.push({
      id: nextId('aeo-publisher'),
      category: 'Source signals',
      severity: 'low',
      issue: 'No page states who published it.',
      evidence: {
        observation: 'No publisher property in structured data and no og:site_name was found anywhere in the crawl.',
        urls: sample(pages.map((page) => page.url), 5),
        affectedCount: pages.length,
        totalCount: pages.length,
      },
      recommendation: 'Set the publisher in your structured data and add og:site_name.',
      expectedBenefit: 'The organisation behind the content is stated explicitly rather than inferred from the domain.',
      confidence: 'medium',
      dataBasis: 'crawl_summary',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* 9. Local readiness                                                         */
/* -------------------------------------------------------------------------- */

function localReadiness(pages: readonly PageData[]): Finding[] {
  if (pages.length === 0) return [];

  const hasLocalBusiness = pages.some((page) =>
    page.entities.schemaTypes.some((type) => type === 'LocalBusiness' || type.endsWith('Business') ||
      type === 'Restaurant' || type.endsWith('Store')),
  );
  const hasAddress = pages.some((page) => page.entities.addresses.length > 0);
  const hasPhone = pages.some((page) => page.entities.telephones.length > 0);

  const missing: string[] = [];
  if (!hasLocalBusiness) missing.push('LocalBusiness structured data');
  if (!hasAddress) missing.push('a postal address in structured data');
  if (!hasPhone) missing.push('a telephone number in structured data');

  if (missing.length === 0) return [];

  return [
    {
      id: nextId('aeo-local'),
      category: 'Local answers',
      severity: hasLocalBusiness ? 'low' : 'medium',
      issue: `The site is missing ${missing.join(', ')}.`,
      evidence: {
        observation: `Checked every page in the crawl for LocalBusiness types, address and telephone properties. Found: ${
          [hasLocalBusiness && 'LocalBusiness type', hasAddress && 'address', hasPhone && 'telephone']
            .filter(Boolean)
            .join(', ') || 'none of them'
        }.`,
        urls: sample(pages.map((page) => page.url), 5),
        affectedCount: missing.length,
      },
      recommendation:
        'If the business serves customers from a place — a shop, an office, a service area — publish LocalBusiness structured data with the address, telephone and opening hours, and keep them identical to your Google Business Profile. If the business has no physical location, this finding does not apply.',
      expectedBenefit:
        'Questions of the form "near me" or "in [city]" depend on the location being stated in a form that can be read directly. Without it, the location has to be guessed from page text.',
      confidence: 'medium',
      dataBasis: 'structured_data',
    },
  ];
}

/* -------------------------------------------------------------------------- */
/* 10. Product and service readiness                                          */
/* -------------------------------------------------------------------------- */

function offeringReadiness(pages: readonly PageData[]): Finding[] {
  if (pages.length === 0) return [];

  const hasOffering = pages.some((page) =>
    page.entities.schemaTypes.some((type) =>
      type === 'Product' || type === 'Service' || type === 'Offer' || type === 'OfferCatalog'),
  );
  if (hasOffering) return [];

  return [
    {
      id: nextId('aeo-offering'),
      category: 'Product and service answers',
      severity: 'medium',
      issue: 'Nothing on the site describes what is offered in machine-readable form.',
      evidence: {
        observation: `No Product, Service or Offer structured data was found across ${pluralPages(pages.length)}.`,
        urls: sample(pages.map((page) => page.url), 5),
        affectedCount: pages.length,
        totalCount: pages.length,
      },
      recommendation:
        'Add Service or Product structured data for what you actually sell, with the name, a description and the area served. Include price only where you publish a real price — marking up a price you do not display is a guidelines violation.',
      expectedBenefit:
        'What the business offers is stated as structured fact rather than being inferred from sales copy, so a question about whether you provide something has a direct source to read.',
      confidence: 'medium',
      dataBasis: 'structured_data',
    },
  ];
}

/* -------------------------------------------------------------------------- */
/* 11. Freshness                                                              */
/* -------------------------------------------------------------------------- */

function freshness(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];
  if (pages.length === 0) return findings;

  const undated = pages.filter((page) => page.publishedAt === null && page.modifiedAt === null);
  if (undated.length === pages.length) {
    findings.push({
      id: nextId('aeo-undated'),
      category: 'Freshness',
      severity: 'medium',
      issue: 'No page carries a publication or modification date.',
      evidence: {
        observation:
          `Checked datePublished and dateModified in structured data, and the article:published_time and article:modified_time meta tags, across ${pluralPages(pages.length)}.`,
        urls: sample(pages.map((page) => page.url), 5),
        affectedCount: pages.length,
        totalCount: pages.length,
      },
      recommendation:
        'Publish a date on content pages and update dateModified when you genuinely revise them. Do not change the date without changing the content — that is a transparent trick and it devalues the signal.',
      expectedBenefit:
        'A reader can tell whether the information is current. For anything time-sensitive, an undated page cannot be judged at all.',
      confidence: 'high',
      dataBasis: 'crawl_summary',
    });
    return findings;
  }

  const cutoff = new Date();
  cutoff.setMonth(cutoff.getMonth() - AEO_THRESHOLDS.freshnessMonths);

  const stale = pages.filter((page) => {
    const raw = page.modifiedAt ?? page.publishedAt;
    if (!raw) return false;
    const date = new Date(raw);
    return !Number.isNaN(date.getTime()) && date < cutoff;
  });

  if (stale.length > 0) {
    findings.push({
      id: nextId('aeo-stale'),
      category: 'Freshness',
      severity: 'low',
      issue: `${pluralPages(stale.length)} were last updated more than ${AEO_THRESHOLDS.freshnessMonths} months ago.`,
      evidence: {
        observation: stale
          .slice(0, 3)
          .map((page) => `${page.url} (${page.modifiedAt ?? page.publishedAt})`)
          .join('; '),
        urls: sample(stale.map((page) => page.url)),
        affectedCount: stale.length,
        totalCount: pages.length,
      },
      recommendation:
        'Review these pages and update what has changed. Age is not itself a problem — a reference page can be years old and still correct — so this is a prompt to check, not a defect.',
      expectedBenefit: 'Content that is still accurate, and visibly so, can be relied on by a reader.',
      confidence: 'low',
      dataBasis: 'crawled_page',
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* 12. Content clarity                                                        */
/* -------------------------------------------------------------------------- */

function clarity(pages: readonly PageData[]): Finding[] {
  const findings: Finding[] = [];
  if (pages.length === 0) return findings;

  const withLongSentences: { url: string; count: number; total: number }[] = [];
  for (const page of pages) {
    const all = sentences(page.text);
    if (all.length < 5) continue;
    const long = all.filter((sentence) => countWords(sentence) > AEO_THRESHOLDS.longSentenceWords);
    if (long.length > all.length / 4) {
      withLongSentences.push({ url: page.url, count: long.length, total: all.length });
    }
  }

  if (withLongSentences.length > 0) {
    findings.push({
      id: nextId('aeo-sentence-length'),
      category: 'Content clarity',
      severity: 'low',
      issue: `${pluralPages(withLongSentences.length)} are written largely in sentences over ${AEO_THRESHOLDS.longSentenceWords} words.`,
      evidence: {
        observation: withLongSentences
          .slice(0, 3)
          .map((item) => `${item.url}: ${item.count} of ${item.total} sentences`)
          .join('; '),
        urls: sample(withLongSentences.map((item) => item.url)),
        affectedCount: withLongSentences.length,
        totalCount: pages.length,
      },
      recommendation:
        'Split the longest sentences so each makes one point. Sentence length is a crude measure of readability, so use judgement rather than a target number.',
      expectedBenefit:
        'A shorter sentence is easier to read and easier to quote accurately, because less of it depends on the rest of the sentence.',
      confidence: 'low',
      dataBasis: 'crawled_page',
    });
  }

  const noLang = pages.filter((page) => page.lang === null);
  if (noLang.length > 0) {
    findings.push({
      id: nextId('aeo-lang'),
      category: 'Content clarity',
      severity: 'low',
      issue: `${pluralPages(noLang.length)} do not declare their language.`,
      evidence: {
        observation: 'No lang attribute was found on the html element of these pages.',
        urls: sample(noLang.map((page) => page.url)),
        affectedCount: noLang.length,
        totalCount: pages.length,
      },
      recommendation: 'Set lang on the html element — lang="en", lang="hi", and so on.',
      expectedBenefit:
        'The language is stated rather than detected, which matters for screen-reader pronunciation and for anything deciding whether the page matches a reader’s language.',
      confidence: 'high',
      dataBasis: 'crawled_page',
    });
  }

  return findings;
}
