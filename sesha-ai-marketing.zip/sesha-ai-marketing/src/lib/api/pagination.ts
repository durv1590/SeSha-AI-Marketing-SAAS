/**
 * Cursor pagination.
 *
 * WHY A CURSOR AND NOT AN OFFSET. Every list in this product is ordered newest
 * first and is being written to while someone reads it. With `OFFSET 100`, one
 * new row arriving between page one and page two shifts everything down by one,
 * so the reader sees the last item of page one again at the top of page two —
 * and, worse, an item can be skipped entirely when a row is deleted. A cursor
 * says "continue after this exact row", which is stable under both.
 *
 * It also avoids the other offset problem: `OFFSET 100000` makes the database
 * walk and discard a hundred thousand rows on every request, so the deepest
 * pages are the slowest, which is backwards.
 *
 * THE CURSOR IS OPAQUE AND VERIFIED. It encodes the sort key and the row id of
 * the last item seen. It is base64url of JSON — not encryption, and not
 * pretending to be: it is *tamper-evident* only in the sense that the decoder
 * validates the shape and refuses anything else. It carries no organization id
 * and no permission, so a forged cursor gets a caller nothing except a different
 * position in a list they were already allowed to read. That is the property
 * that makes an unsigned cursor acceptable here, and it is why the decoder must
 * never be given a field that grants anything.
 */

export const DEFAULT_PAGE_SIZE = 25;
export const MAX_PAGE_SIZE = 100;

export interface Cursor {
  /** The sort key of the last row on the previous page, as an ISO timestamp. */
  readonly at: string;
  /** The id of that row, to break ties when two rows share a timestamp. */
  readonly id: string;
}

export interface Page<T> {
  readonly items: readonly T[];
  /** Pass this back as `cursor` to get the next page. `null` means the end. */
  readonly nextCursor: string | null;
  /** True when a further page exists. */
  readonly hasMore: boolean;
}

export function encodeCursor(cursor: Cursor): string {
  return Buffer.from(JSON.stringify(cursor), 'utf8').toString('base64url');
}

/**
 * Decodes a cursor, or returns null.
 *
 * NULL FOR ANYTHING UNEXPECTED, and the caller treats null as "start at the
 * beginning". A malformed cursor must not be an error the user sees: cursors
 * get truncated by chat clients, mangled by email, and stale after a
 * deployment, and "start again from the top" is a better answer than a 400 for
 * all of those.
 */
export function decodeCursor(value: unknown): Cursor | null {
  if (typeof value !== 'string' || value.length === 0 || value.length > 512) return null;
  try {
    const parsed: unknown = JSON.parse(Buffer.from(value, 'base64url').toString('utf8'));
    if (typeof parsed !== 'object' || parsed === null) return null;
    const { at, id } = parsed as Record<string, unknown>;
    if (typeof at !== 'string' || typeof id !== 'string') return null;
    if (at.length > 40 || id.length > 200) return null;
    if (Number.isNaN(Date.parse(at))) return null;
    return { at, id };
  } catch {
    return null;
  }
}

/** Clamps a requested page size into the allowed range. */
export function pageSize(requested: unknown): number {
  const parsed = typeof requested === 'string' ? Number(requested) : requested;
  if (typeof parsed !== 'number' || !Number.isFinite(parsed)) return DEFAULT_PAGE_SIZE;
  if (!Number.isInteger(parsed) || parsed < 1) return DEFAULT_PAGE_SIZE;
  return Math.min(parsed, MAX_PAGE_SIZE);
}

/** Reads the pagination parameters off a request URL. */
export function pageParams(url: URL): { readonly limit: number; readonly cursor: Cursor | null } {
  return {
    limit: pageSize(url.searchParams.get('limit') ?? undefined),
    cursor: decodeCursor(url.searchParams.get('cursor')),
  };
}

/**
 * Turns an over-fetched array into a page.
 *
 * THE CALLER FETCHES `limit + 1` ROWS. That extra row is how `hasMore` is known
 * without a second `COUNT(*)` query — which on a large table is often more
 * expensive than the page itself, and which is wrong by the time it returns
 * anyway. The extra row is dropped before the items are returned.
 */
export function toPage<T>(
  rows: readonly T[],
  limit: number,
  key: (row: T) => Cursor,
): Page<T> {
  const hasMore = rows.length > limit;
  const items = hasMore ? rows.slice(0, limit) : rows;
  const last = items[items.length - 1];
  return {
    items,
    hasMore,
    nextCursor: hasMore && last ? encodeCursor(key(last)) : null,
  };
}

/**
 * Applies a cursor to an already-sorted, newest-first array.
 *
 * FOR THE IN-MEMORY ADAPTER. A SQL adapter expresses the same thing as
 * `WHERE (created_at, id) < ($1, $2) ORDER BY created_at DESC, id DESC` — the
 * row-value comparison, which is what makes the tie-break exact. Doing it by
 * hand here keeps the two adapters answering identically.
 */
export function applyCursor<T>(
  rows: readonly T[],
  cursor: Cursor | null,
  key: (row: T) => Cursor,
): readonly T[] {
  if (!cursor) return rows;
  const index = rows.findIndex((row) => {
    const rowKey = key(row);
    return rowKey.at === cursor.at && rowKey.id === cursor.id;
  });
  if (index >= 0) return rows.slice(index + 1);

  // The cursor's row is gone — deleted, or aged out. Fall back to the timestamp
  // so the reader continues from roughly the right place rather than being sent
  // back to the top of a list they have already read most of.
  return rows.filter((row) => {
    const rowKey = key(row);
    return rowKey.at < cursor.at || (rowKey.at === cursor.at && rowKey.id < cursor.id);
  });
}

/** The JSON shape every paginated endpoint returns, so clients learn one. */
export function pageResponse<T>(page: Page<T>): {
  readonly items: readonly T[];
  readonly nextCursor: string | null;
  readonly hasMore: boolean;
} {
  return { items: page.items, nextCursor: page.nextCursor, hasMore: page.hasMore };
}
