/**
 * The admin request guard.
 *
 * SEPARATE FROM `requireAuth` ON PURPOSE, and the separation is the security
 * property. `requireAuth` resolves a TENANT context — a customer acting inside
 * their own organization. `requireStaff` resolves a PLATFORM context, from the
 * `platform_staff` table, and returns no organization at all. A single guard
 * that returned both would invite a route to use whichever field was to hand.
 *
 * WHAT A NON-STAFF CALLER GETS: 404.
 * Not 403, and not a different shape of 404 from a missing route. To someone who
 * is not staff, the admin API does not exist. This is the same reasoning as
 * cross-tenant access returning 404 (Phase 2): a 403 confirms there is something
 * there, and an admin panel is worth a great deal more to an attacker than one
 * customer's project id.
 *
 * The ONE exception is `needsSudo`, which is 403 with a flag — that caller has
 * already been established as staff, so asking them to re-authenticate discloses
 * nothing they do not already know.
 */

import { getCurrentSession } from '@/lib/auth/current-session';
import { getDatabase } from '@/lib/db';
import { staffFor } from '@/lib/admin/service';
import {
  ADMIN_NOT_FOUND_MESSAGE,
  adminRefusal,
  checkAdminAccess,
  type AdminPermission,
  type StaffContext,
} from '@/lib/admin/auth';
import { isSudo } from '@/lib/auth/session';

import { guardCsrf, isGuardFailure, type GuardFailure } from './guard';
import { fail } from './respond';

export interface StaffRequestContext {
  readonly staff: StaffContext;
}

export function isStaffFailure(value: unknown): value is GuardFailure {
  return isGuardFailure(value);
}

/**
 * Requires a signed-in platform staff member, then CSRF for unsafe methods.
 *
 * Reads the staff row on EVERY request rather than trusting the session, so
 * revoking access takes effect immediately rather than when a thirty-day
 * session happens to expire.
 */
export async function requireStaff(
  request: Request,
  permission: AdminPermission,
): Promise<StaffRequestContext | GuardFailure> {
  const session = await getCurrentSession();
  // No session at all is also 404. "Sign in to continue" would tell an
  // unauthenticated prober that there is an admin API behind the door.
  if (!session) return { response: fail(404, ADMIN_NOT_FOUND_MESSAGE) };

  const csrf = await guardCsrf(request, session.session.id);
  if (csrf) return csrf;

  const staff = await staffFor(
    { db: getDatabase() },
    { id: session.user.id, email: session.user.email },
    {
      id: session.session.id,
      // The sudo window is computed from the session record, not carried in a
      // claim, so it cannot be extended by anything the client controls.
      sudo: isSudo(session.session, Date.now()),
      ipHash: null,
    },
  );

  const access = checkAdminAccess(staff, permission);
  if (!access.ok) {
    // The status and wording are decided by `adminRefusal` in lib/admin/auth, so
    // the rule is testable without a request. See its doc comment; a mutation
    // check caught this mapping being untestable here.
    const refusal = adminRefusal(access);
    return {
      response: fail(
        refusal.status,
        refusal.message,
        refusal.needsSudo ? { needsSudo: 'true' } : undefined,
      ),
    };
  }

  return { staff: staff as StaffContext };
}
