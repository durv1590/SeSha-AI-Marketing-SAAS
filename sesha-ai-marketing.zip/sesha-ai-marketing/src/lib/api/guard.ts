import { cookies, headers } from 'next/headers';

import { CSRF_COOKIE, CSRF_HEADER, isSafeMethod, verifyCsrf, verifyOrigin } from '@/lib/auth/csrf';
import { appSecret, getCurrentSession, isProduction } from '@/lib/auth/current-session';
import { AuthorizationError, can, type Permission } from '@/lib/auth/rbac';
import { NotFoundError, type TenantContext } from '@/lib/tenant';
import { QuotaExceededError } from '@/lib/quota/service';
import { ADMIN_NOT_FOUND_MESSAGE, AdminAuthorizationError } from '@/lib/admin/auth';
import { PlanLimitError } from '@/lib/workspace/service';
import { site } from '@/content/site';
import { fail } from './respond';
import type { ResolvedSession } from '@/lib/auth/service';

/**
 * Route guards.
 *
 * THE ORDER IS DELIBERATE and every authenticated mutation runs all of it:
 *   1. CSRF   — origin check, then signed double-submit token.
 *   2. AUTH   — is there a valid session at all?
 *   3. AUTHZ  — does this role hold the permission?
 * Tenant ownership is then checked at the service layer, which is where the
 * data actually is.
 *
 * Nothing here trusts a value from the client beyond comparing it to a value
 * the server issued.
 */

export type GuardFailure = { readonly response: Response };

export function isGuardFailure(value: unknown): value is GuardFailure {
  return typeof value === 'object' && value !== null && 'response' in value;
}

/** Verifies CSRF for a state-changing request. Safe methods pass through. */
export async function guardCsrf(request: Request, sessionId: string): Promise<GuardFailure | null> {
  if (isSafeMethod(request.method)) return null;

  const headerList = await headers();
  const allowedOrigin = process.env.NEXT_PUBLIC_SITE_URL ?? site.url;

  if (!verifyOrigin(headerList.get('origin'), headerList.get('referer'), allowedOrigin)) {
    return { response: fail(403, 'Request origin could not be verified.') };
  }

  const store = await cookies();
  const cookieValue = store.get(CSRF_COOKIE)?.value ?? null;
  const submitted = headerList.get(CSRF_HEADER);

  const result = verifyCsrf(cookieValue, submitted, sessionId, appSecret());
  if (!result.ok) {
    // The reason is never returned to the client — it would tell an attacker
    // which half of the check to work on.
    return { response: fail(403, 'Your session could not be verified. Please refresh and retry.') };
  }
  return null;
}

export interface AuthenticatedContext {
  readonly session: ResolvedSession;
  readonly tenant: TenantContext;
}

/**
 * Requires a valid session, then CSRF for unsafe methods.
 * Returns either the context or a ready-to-return Response.
 */
export async function requireAuth(request: Request): Promise<AuthenticatedContext | GuardFailure> {
  const session = await getCurrentSession();
  if (!session) return { response: fail(401, 'Sign in to continue.') };

  const csrf = await guardCsrf(request, session.session.id);
  if (csrf) return csrf;

  return {
    session,
    tenant: {
      userId: session.user.id,
      organizationId: session.user.organizationId,
      role: session.user.role,
    },
  };
}

/** Requires a session AND a permission. */
export async function requireAuthorized(
  request: Request,
  permission: Permission,
): Promise<AuthenticatedContext | GuardFailure> {
  const result = await requireAuth(request);
  if (isGuardFailure(result)) return result;

  if (!can(result.tenant.role, permission)) {
    return { response: fail(403, 'You do not have permission to do that.') };
  }
  return result;
}

/**
 * Maps a service-layer error to an HTTP response.
 *
 * NotFoundError is 404 even when the real cause was a cross-tenant access —
 * that is the point of it. An unexpected error becomes a generic 500 with
 * nothing from the exception in the body.
 */
export function errorResponse(error: unknown): Response {
  if (error instanceof NotFoundError) return fail(404, error.message);
  if (error instanceof AuthorizationError) return fail(403, error.message);
  if (error instanceof PlanLimitError) return fail(402, error.message);

  // A quota refusal is 402 Payment Required, carrying the numbers. "Quota
  // exceeded" with no figures is the message that generates a support ticket.
  if (error instanceof QuotaExceededError) {
    return fail(402, error.message, {
      limit: error.decision.limitId,
      reason: error.decision.reason,
      used: String(error.decision.used),
      ...(error.decision.limit === null ? {} : { allowed: String(error.decision.limit) }),
      ...(error.decision.resetsAt ? { resetsAt: error.decision.resetsAt } : {}),
    });
  }

  // An admin authorization failure is 404, not 403. To someone who is not
  // staff, the admin panel does not exist — the same reasoning as cross-tenant
  // access returning 404. A 403 would confirm there is a panel worth attacking.
  // `needsSudo` is the one exception: the caller IS staff and is being asked to
  // re-authenticate, so telling them is not a disclosure.
  if (error instanceof AdminAuthorizationError) {
    return error.needsSudo
      ? fail(403, error.message, { needsSudo: 'true' })
      : fail(404, ADMIN_NOT_FOUND_MESSAGE);
  }

  if (!isProduction) {
    console.error('[api] unhandled error', error);
  }
  return fail(500, 'Something went wrong. Please try again.');
}
