import { NextResponse } from 'next/server';

import { RATE_LIMITS, clientKey, rateLimitStore, type RateLimitOptions } from '@/lib/security/rate-limit';

/**
 * Shared API response helpers.
 *
 * Every route returns the same envelope shape, sets the same cache and
 * rate-limit headers, and never echoes unsanitised input back to the caller.
 */

export interface ApiSuccess<T> {
  readonly ok: true;
  readonly message?: string;
  readonly data?: T;
}

export interface ApiFailure {
  readonly ok: false;
  readonly message: string;
  readonly errors?: Record<string, string>;
}

const NO_STORE = 'no-store, max-age=0';

export function ok<T>(body: Omit<ApiSuccess<T>, 'ok'>, init?: ResponseInit): NextResponse {
  return NextResponse.json(
    { ok: true, ...body },
    { status: 200, ...init, headers: { 'Cache-Control': NO_STORE, ...init?.headers } },
  );
}

export function fail(
  status: number,
  message: string,
  errors?: Record<string, string>,
  init?: ResponseInit,
): NextResponse {
  return NextResponse.json(
    { ok: false, message, ...(errors ? { errors } : {}) } satisfies ApiFailure,
    { status, ...init, headers: { 'Cache-Control': NO_STORE, ...init?.headers } },
  );
}

/**
 * Parses a JSON body defensively: wrong content type, malformed JSON and
 * oversized payloads all produce a clean 400 rather than an unhandled throw.
 */
export async function readJson(request: Request, maxBytes = 256_000): Promise<unknown | null> {
  const contentType = request.headers.get('content-type') ?? '';
  if (!contentType.toLowerCase().includes('application/json')) return null;

  const declared = Number(request.headers.get('content-length') ?? '0');
  if (Number.isFinite(declared) && declared > maxBytes) return null;

  try {
    const text = await request.text();
    if (text.length === 0 || text.length > maxBytes) return null;
    const parsed: unknown = JSON.parse(text);
    return typeof parsed === 'object' && parsed !== null ? parsed : null;
  } catch {
    return null;
  }
}

export type LimitName = keyof typeof RATE_LIMITS;

/** Applies a rate limit and returns a ready 429 response when exceeded. */
export function enforceRateLimit(
  request: Request,
  name: LimitName,
): { allowed: true; headers: Record<string, string> } | { allowed: false; response: NextResponse } {
  const options: RateLimitOptions = RATE_LIMITS[name];
  const key = `${name}:${clientKey(request.headers)}`;
  const result = rateLimitStore.consume(key, options, Date.now());

  const headers: Record<string, string> = {
    'X-RateLimit-Limit': String(result.limit),
    'X-RateLimit-Remaining': String(result.remaining),
    'X-RateLimit-Reset': String(Math.ceil(result.resetAt / 1000)),
  };

  if (result.allowed) return { allowed: true, headers };

  return {
    allowed: false,
    response: fail(429, 'Too many requests. Please wait a moment and try again.', undefined, {
      headers: { ...headers, 'Retry-After': String(result.retryAfterSeconds) },
    }),
  };
}
