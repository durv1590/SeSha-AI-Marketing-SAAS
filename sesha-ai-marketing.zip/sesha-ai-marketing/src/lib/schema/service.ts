/**
 * Schema validation and generation, as the workspace uses them.
 *
 * WHAT THIS ADDS OVER THE ENGINE
 * The engine validates a document. This module is the part that makes a validator
 * useful over time:
 *
 *  · it STORES every run, with the validator's own version, so a history is
 *    comparable rather than merely chronological;
 *  · it COMPARES a run with the previous run for the same source, and says when
 *    a difference might be our rules changing rather than the customer's markup;
 *  · it reads markup from a CRAWLED PAGE, which is where the canonical URL comes
 *    from — so validating a real page runs checks that pasted markup cannot.
 *
 * The public tool at /schema-validator remains stateless and stores nothing. This
 * module is only reachable by an authenticated user inside their own project, and
 * it stores the result against that project.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { enforceOrThrow } from '@/lib/quota/service';
import { NotFoundError, assertTenant, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { SchemaValidationRow } from '@/lib/db/types';
import {
  buildCorrection,
  compareResults,
  validateSchema,
  type Correction,
  type ValidationResult,
  type ValidationSourceKind,
} from '@/lib/schema-validator';

import {
  generateSchema,
  type GeneratedKind,
  type GeneratedSchema,
  type PageFacts,
} from './generate';

export interface SchemaServiceContext {
  readonly db: Database;
  readonly now?: () => Date;
}

function clock(context: SchemaServiceContext): Date {
  return context.now?.() ?? new Date();
}

export class ValidationInputError extends Error {
  readonly code = 'INVALID_INPUT' as const;
  constructor(message: string) {
    super(message);
    this.name = 'ValidationInputError';
  }
}

export const MAX_SOURCE_BYTES = 200_000;

export interface ValidateRequest {
  readonly projectId: string;
  readonly sourceKind: ValidationSourceKind;
  /** The markup, for a pasted run. */
  readonly source?: string;
  /** The page to read, for a URL run. */
  readonly url?: string;
  /** Whether to keep the run in the project's history. */
  readonly store?: boolean;
}

export interface ValidateOutcome {
  readonly result: ValidationResult;
  readonly correction: Correction;
  /** The stored row, when the run was kept. */
  readonly stored?: SchemaValidationRow;
  /** Against the previous run for the same source, when there is one. */
  readonly comparison?: ReturnType<typeof compareResults>;
}

/**
 * Validates markup the user pasted, or markup already stored from a crawl.
 *
 * NOTE WHAT IS NOT HERE: there is no fetch. A URL run reads a page the Phase 4
 * crawler already fetched under the project's crawl consent. Fetching a URL here
 * would be an unconsented request to an arbitrary address from a validation
 * endpoint — the crawler's entire threat model, reintroduced in a quieter place.
 */
export async function validateForProject(
  context: SchemaServiceContext,
  tenant: TenantContext,
  request: ValidateRequest,
): Promise<ValidateOutcome> {
  requirePermission(tenant.role, 'content:read');

  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, request.projectId),
    'Project',
  );

  await enforceOrThrow(context, tenant.organizationId, 'schema_validations', {
    projectId: project.id,
    userId: tenant.userId,
  });

  let source: string;
  let sourceUrl: string | undefined;
  let canonicalUrl: string | undefined;
  const limitations: { code: string; detail: string }[] = [];

  if (request.sourceKind === 'pasted') {
    source = request.source ?? '';
    if (source.trim().length === 0) {
      throw new ValidationInputError('There is nothing to validate.');
    }
    if (Buffer.byteLength(source, 'utf8') > MAX_SOURCE_BYTES) {
      throw new ValidationInputError(
        `The document is larger than the ${MAX_SOURCE_BYTES.toLocaleString('en-IN')} byte limit.`,
      );
    }
  } else {
    const url = (request.url ?? '').trim();
    if (url.length === 0) throw new ValidationInputError('A page URL is needed.');

    const crawl = await context.db.crawls.findLatest(tenant.organizationId, project.id);
    if (!crawl) {
      throw new ValidationInputError(
        'No crawl has run for this project yet, so there is no stored copy of that page to validate. Run a crawl first, or paste the markup.',
      );
    }
    const pages = await context.db.crawls.listPages(tenant.organizationId, crawl.id);
    const page = pages.find((candidate) => sameUrl(candidate.url, url));
    if (!page) {
      throw new ValidationInputError(
        'That page is not in the most recent crawl of this site. Crawl it, or paste its markup.',
      );
    }

    // The structured data the crawler already extracted, re-serialised. The
    // crawler does not keep raw HTML, so Microdata and RDFa cannot be re-read
    // here — and that limit is reported rather than left to look like absence.
    source = JSON.stringify(page.structuredData ?? []);
    sourceUrl = page.url;
    canonicalUrl = page.canonical ?? undefined;
    limitations.push({
      code: 'from_stored_crawl',
      detail: `This validates the structured data recorded when the page was crawled at ${page.crawledAt.toISOString()}, not a fresh fetch. If the page has changed since, crawl it again.`,
    });
    limitations.push({
      code: 'json_ld_only_from_crawl',
      detail:
        'The crawler stores extracted structured data rather than raw HTML, so only JSON-LD can be re-checked from a stored page. Paste the page source to check Microdata or RDFa.',
    });
  }

  const now = clock(context);
  const result = validateSchema({
    source,
    sourceKind: request.sourceKind,
    ...(sourceUrl ? { sourceUrl } : {}),
    ...(canonicalUrl ? { canonicalUrl } : {}),
    limitations,
    now: () => now,
  });

  const correction = buildCorrection(source, result, sourceUrl ? { pageUrl: sourceUrl } : {});

  if (request.store === false) return { result, correction };

  requirePermission(tenant.role, 'content:create');

  const previous = await context.db.schemaValidations.findPreviousForSource(
    tenant.organizationId,
    project.id,
    sourceUrl ?? null,
    now,
  );

  const stored = await context.db.schemaValidations.create({
    organizationId: tenant.organizationId,
    projectId: project.id,
    createdBy: tenant.userId,
    sourceKind: result.sourceKind,
    sourceUrl: sourceUrl ?? null,
    canonicalUrl: canonicalUrl ?? null,
    syntaxes: result.syntaxes,
    validatorVersion: result.validatorVersion,
    overallStatus: result.overall,
    counts: { ...result.counts },
    typesFound: result.typesFound,
    entities: result.entities as unknown as readonly Readonly<Record<string, unknown>>[],
    issues: result.issues as unknown as readonly Readonly<Record<string, unknown>>[],
    limitations: result.limitations as unknown as readonly Readonly<Record<string, unknown>>[],
    checkedAt: new Date(result.checkedAt),
  });

  await context.db.usage.record({
    organizationId: tenant.organizationId,
    projectId: project.id,
    metric: 'schema_validation',
    quantity: 1,
    periodStart: metricPeriod(now),
  });

  return {
    result,
    correction,
    stored,
    ...(previous ? { comparison: compareResults(rowToResult(previous), result) } : {}),
  };
}

/** The project's validation history, newest first. */
export async function listValidationHistory(
  context: SchemaServiceContext,
  tenant: TenantContext,
  projectId: string,
  limit = 25,
): Promise<SchemaValidationRow[]> {
  requirePermission(tenant.role, 'content:read');
  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, projectId),
    'Project',
  );
  return context.db.schemaValidations.listForProject(tenant.organizationId, project.id, limit);
}

/**
 * Compares two stored runs.
 *
 * Both must belong to the caller's organization; a cross-tenant id is a 404 with
 * the same message as a missing one, as everywhere else.
 */
export async function compareStoredValidations(
  context: SchemaServiceContext,
  tenant: TenantContext,
  firstId: string,
  secondId: string,
): Promise<ReturnType<typeof compareResults>> {
  requirePermission(tenant.role, 'content:read');
  const first = await context.db.schemaValidations.findById(tenant.organizationId, firstId);
  const second = await context.db.schemaValidations.findById(tenant.organizationId, secondId);
  if (!first || !second) throw new NotFoundError('Validation');
  return compareResults(rowToResult(first), rowToResult(second));
}

/**
 * Reconstructs a result from a stored row.
 *
 * The stored row is the result, so this is a cast with the shape restated rather
 * than a re-validation: re-running the current engine over old markup would
 * silently rewrite history with today's rules.
 */
export function rowToResult(row: SchemaValidationRow): ValidationResult {
  return {
    validatorVersion: row.validatorVersion,
    checkedAt: row.checkedAt.toISOString(),
    sourceKind: row.sourceKind,
    ...(row.sourceUrl ? { sourceUrl: row.sourceUrl } : {}),
    syntaxes: row.syntaxes as ValidationResult['syntaxes'],
    parsed: true,
    entities: row.entities as unknown as ValidationResult['entities'],
    typesFound: row.typesFound,
    unsupportedTypes: [],
    issues: row.issues as unknown as ValidationResult['issues'],
    counts: row.counts as unknown as ValidationResult['counts'],
    limitations: row.limitations as unknown as ValidationResult['limitations'],
    overall: row.overallStatus as ValidationResult['overall'],
  };
}

/* -------------------------------------------------------------------------- */
/* Generation                                                                 */
/* -------------------------------------------------------------------------- */

export interface GenerateRequest {
  readonly projectId: string;
  readonly kind: GeneratedKind;
  /** A crawled page to take facts from, for page-level kinds. */
  readonly pageUrl?: string;
}

/**
 * Generates JSON-LD from the project's own verified data.
 *
 * Every fact comes from the business record the user filled in, or from a page
 * the crawler actually read. Nothing is inferred, and the refusal list is
 * returned alongside the output so the user sees what was deliberately left out.
 */
export async function generateForProject(
  context: SchemaServiceContext,
  tenant: TenantContext,
  request: GenerateRequest,
): Promise<GeneratedSchema> {
  requirePermission(tenant.role, 'content:create');

  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, request.projectId),
    'Project',
  );

  const business = project.businessId
    ? await context.db.businesses.findById(tenant.organizationId, project.businessId)
    : null;
  if (!business) {
    throw new ValidationInputError(
      'This project has no business details yet. Complete onboarding and the generated markup is built from them.',
    );
  }

  const profile = await context.db.marketingProfiles.findByProject(
    tenant.organizationId,
    project.id,
  );

  let page: PageFacts | undefined;
  if (request.pageUrl) {
    const crawl = await context.db.crawls.findLatest(tenant.organizationId, project.id);
    const pages = crawl ? await context.db.crawls.listPages(tenant.organizationId, crawl.id) : [];
    const found = pages.find((candidate) => sameUrl(candidate.url, request.pageUrl!));
    if (!found) {
      throw new ValidationInputError(
        'That page is not in the most recent crawl, so there are no verified facts to build from. Crawl the site first.',
      );
    }
    page = {
      url: found.url,
      title: found.title,
      metaDescription: found.metaDescription,
      headline: found.h1[0] ?? found.title,
      // The raw strings the page published, NOT normalised into a date here: if
      // the page's own date is unparseable, the validator must say so rather than
      // this service quietly inventing a valid one.
      datePublished: found.publishedAtRaw,
      dateModified: found.modifiedAtRaw,
      authorName: found.author,
      imageUrl: firstImageSrc(found.images),
      inLanguage: found.lang,
      // Only pairs that came from real FAQPage markup count as FAQ facts. A
      // question-shaped heading is not an answered question — the same
      // distinction the Phase 4 audit had to make.
      faqs: structuredDataFaqs(found.faqs),
    };
  }

  return generateSchema({
    kind: request.kind,
    business: {
      name: business.name,
      websiteUrl: business.websiteUrl,
      industry: business.industry,
      city: business.city,
      country: business.country,
      description: profile?.productsServices ?? null,
      productsServices: profile?.productsServices ?? null,
    },
    ...(page ? { page } : {}),
    ...(business.websiteUrl ? { siteUrl: business.websiteUrl } : {}),
    now: () => clock(context),
  });
}


/** The usage period a record belongs to: the first day of its month, as YYYY-MM-01. */
function metricPeriod(at: Date): string {
  return `${at.getUTCFullYear()}-${String(at.getUTCMonth() + 1).padStart(2, '0')}-01`;
}

/**
 * Narrowing helpers for the jsonb columns.
 *
 * `images` and `faqs` are `unknown[]` on the row because they are jsonb, and that
 * is the honest type for a column whose shape the database does not enforce. The
 * narrowing therefore happens here, once, with a guard — rather than with a cast
 * that would be wrong the first time an older row is read.
 */
function firstImageSrc(images: readonly unknown[]): string | null {
  for (const image of images) {
    if (typeof image === 'object' && image !== null && 'src' in image) {
      const src = (image as { src?: unknown }).src;
      if (typeof src === 'string' && src.trim().length > 0) return src;
    }
  }
  return null;
}

function structuredDataFaqs(
  faqs: readonly unknown[],
): readonly { readonly question: string; readonly answer: string }[] {
  const usable: { question: string; answer: string }[] = [];
  for (const entry of faqs) {
    if (typeof entry !== 'object' || entry === null) continue;
    const record = entry as { question?: unknown; answer?: unknown; source?: unknown };
    if (record.source !== 'structured_data') continue;
    if (typeof record.question !== 'string' || typeof record.answer !== 'string') continue;
    if (record.question.trim().length === 0 || record.answer.trim().length === 0) continue;
    usable.push({ question: record.question, answer: record.answer });
  }
  return usable;
}

/** Compares two URLs ignoring a trailing slash and the fragment. */
function sameUrl(a: string, b: string): boolean {
  const normalise = (value: string): string =>
    value.trim().split('#')[0]!.replace(/\/+$/, '').toLowerCase();
  return normalise(a) === normalise(b);
}
