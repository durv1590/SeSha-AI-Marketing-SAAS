/**
 * Generating JSON-LD for a customer's own website, from their own data.
 *
 * THE ONE RULE
 * Every value emitted here traces to a field the customer actually filled in, or
 * to a page that was actually crawled. Nothing is inferred, nothing is rounded
 * up, and nothing is invented — because the output of this module gets pasted
 * into the customer's website and published under their name. A generated
 * `aggregateRating` is not a marketing flourish; it is a false statement on their
 * own domain that a search engine can penalise them for.
 *
 * So the generator has three outcomes per property, and reports all three:
 *  · INCLUDED — with the field it came from, so the user can audit it.
 *  · OMITTED  — we do not have the data. Named, so the user knows what to supply
 *               rather than wondering why the output is thin.
 *  · REFUSED  — we could guess, and will not. Reviews, ratings, prices,
 *               availability, awards, certifications and credentials are on this
 *               list permanently, even when the user asks.
 *
 * The generator also runs its own output through the Phase 5 validator. A
 * generator that emits markup its own validator rejects is indefensible, and the
 * test for it is `tests/schema-generate.test.ts`.
 *
 * Framework-free and fully unit tested.
 */

import {
  NEVER_INVENT_PROPERTIES,
  validateSchema,
  type ValidationResult,
} from '@/lib/schema-validator';

import { prune, type JsonLdNode, type JsonValue } from './index';

export type GeneratedKind =
  | 'organization'
  | 'local_business'
  | 'website'
  | 'webpage'
  | 'article'
  | 'faq'
  | 'service'
  | 'breadcrumb';

export const GENERATED_KINDS: readonly GeneratedKind[] = [
  'organization',
  'local_business',
  'website',
  'webpage',
  'article',
  'faq',
  'service',
  'breadcrumb',
];

export const GENERATED_KIND_LABEL: Readonly<Record<GeneratedKind, string>> = {
  organization: 'Organization',
  local_business: 'Local business',
  website: 'Website',
  webpage: 'Web page',
  article: 'Article or blog post',
  faq: 'FAQ page',
  service: 'Service',
  breadcrumb: 'Breadcrumb trail',
};

/**
 * Where a value came from. The same seven-kind vocabulary as the AI provenance
 * system, narrowed to the three kinds a generator can legitimately use: if a
 * value is an estimate or an inference, it does not belong in structured data at
 * all.
 */
export type ValueSource = 'user_provided' | 'connected' | 'retrieved';

export const VALUE_SOURCE_LABEL: Readonly<Record<ValueSource, string>> = {
  user_provided: 'You told us this',
  connected: 'From a connected account',
  retrieved: 'Read from your website',
};

/** The customer's own details, as captured during onboarding. */
export interface BusinessFacts {
  readonly name: string;
  readonly websiteUrl?: string | null;
  readonly industry?: string | null;
  readonly city?: string | null;
  readonly country?: string | null;
  readonly description?: string | null;
  readonly telephone?: string | null;
  readonly email?: string | null;
  readonly streetAddress?: string | null;
  readonly postalCode?: string | null;
  readonly region?: string | null;
  readonly logoUrl?: string | null;
  readonly sameAs?: readonly string[];
  readonly openingHours?: string | null;
  readonly productsServices?: string | null;
}

/** Facts read from a crawled page. Never from the model. */
export interface PageFacts {
  readonly url: string;
  readonly title?: string | null;
  readonly metaDescription?: string | null;
  readonly headline?: string | null;
  readonly datePublished?: string | null;
  readonly dateModified?: string | null;
  readonly authorName?: string | null;
  readonly imageUrl?: string | null;
  readonly inLanguage?: string | null;
  /** Only pairs that came from real FAQPage markup or real page content. */
  readonly faqs?: readonly { readonly question: string; readonly answer: string }[];
  readonly breadcrumb?: readonly { readonly name: string; readonly url?: string }[];
}

export interface GenerateInput {
  readonly kind: GeneratedKind;
  readonly business: BusinessFacts;
  readonly page?: PageFacts;
  readonly siteUrl?: string;
  readonly now?: () => Date;
}

export interface IncludedValue {
  readonly property: string;
  readonly source: ValueSource;
  /** The field the value came from, named the way the user saw it. */
  readonly from: string;
}

export interface OmittedValue {
  readonly property: string;
  readonly why: string;
}

export interface GeneratedSchema {
  readonly kind: GeneratedKind;
  readonly graph: readonly JsonLdNode[];
  /** Pretty-printed, ready to paste. */
  readonly jsonLd: string;
  readonly included: readonly IncludedValue[];
  readonly omitted: readonly OmittedValue[];
  readonly refused: readonly OmittedValue[];
  /** The generator's own output, run through the validator. */
  readonly validation: ValidationResult;
  readonly generatedAt: string;
}

/**
 * Properties this generator will never emit, and the sentence shown when a user
 * asks why.
 *
 * Listed individually rather than as one blanket message because the reasons
 * differ: a price is a commercial fact that changes, a credential is a claim
 * about a person, and a rating is a claim about other people's opinions.
 */
export const REFUSAL_REASONS: Readonly<Record<string, string>> = {
  aggregateRating:
    'A rating is a claim about what your customers said. It can only come from reviews you have actually collected, published where visitors can read them.',
  review:
    'A review is a specific person\'s words. SeSha will not write one, and publishing an invented review is both a policy breach and, in most markets, unlawful.',
  ratingValue: 'Part of a rating, which must come from real reviews.',
  ratingCount: 'Part of a rating, which must come from real reviews.',
  reviewCount: 'Part of a rating, which must come from real reviews.',
  price:
    'A price is a commercial commitment and it changes. It must come from your own catalogue, not from a generator.',
  priceCurrency: 'Part of a price, which must come from your own catalogue.',
  priceValidUntil: 'Part of a price, which must come from your own catalogue.',
  offers:
    'An offer states a price and availability. Both must come from your own catalogue so that what is published is what you will honour.',
  availability:
    'Whether something is in stock is a fact about your inventory, which SeSha cannot see.',
  award: 'An award is a verifiable claim about a third party\'s decision.',
  awards: 'An award is a verifiable claim about a third party\'s decision.',
  hasCredential: 'A credential is a claim about a qualification someone holds.',
  hasCertification: 'A certification is a claim about an assessment someone passed.',
  certification: 'A certification is a claim about an assessment someone passed.',
  accreditation: 'An accreditation is a claim about recognition by a named body.',
};

export function refusalFor(property: string): string {
  return (
    REFUSAL_REASONS[property] ??
    'This would have to be invented, and SeSha does not publish invented facts on your website.'
  );
}

/**
 * Builds the requested node set.
 *
 * Returns a whole graph rather than one node because the useful unit is a graph:
 * an Article with a publisher that references the Organization by `@id` is
 * correct, and an Article with a publisher object duplicated inline is the
 * organisation-consistency problem the validator reports.
 */
export function generateSchema(input: GenerateInput): GeneratedSchema {
  const now = input.now ?? (() => new Date());
  const context: BuildContext = {
    included: [],
    omitted: [],
    refused: [],
    business: input.business,
    page: input.page,
    baseUrl: normalizeBase(input.siteUrl ?? input.business.websiteUrl ?? ''),
  };

  // Every kind refuses the same property list. Stated up front so the user sees
  // it even on a kind where it would not have applied anyway.
  for (const property of NEVER_INVENT_PROPERTIES) {
    if (REFUSAL_REASONS[property]) {
      context.refused.push({ property, why: refusalFor(property) });
    }
  }

  const graph = buildGraph(input.kind, context);
  const jsonLd = JSON.stringify(
    graph.length === 1 ? { '@context': 'https://schema.org', ...graph[0]! } : { '@context': 'https://schema.org', '@graph': graph },
    null,
    2,
  );

  return {
    kind: input.kind,
    graph,
    jsonLd,
    included: context.included,
    omitted: context.omitted,
    refused: dedupeByProperty(context.refused),
    validation: validateSchema({ source: jsonLd, sourceKind: 'pasted', now }),
    generatedAt: now().toISOString(),
  };
}

interface BuildContext {
  readonly included: IncludedValue[];
  readonly omitted: OmittedValue[];
  readonly refused: OmittedValue[];
  readonly business: BusinessFacts;
  readonly page?: PageFacts;
  readonly baseUrl: string;
}

function buildGraph(kind: GeneratedKind, context: BuildContext): JsonLdNode[] {
  switch (kind) {
    case 'organization':
      return [buildOrganization(context, 'Organization')];
    case 'local_business':
      return [buildOrganization(context, 'LocalBusiness')];
    case 'website':
      return [buildWebSite(context)];
    case 'webpage':
      return [buildWebPage(context)];
    case 'article':
      return buildArticle(context);
    case 'faq':
      return [buildFaq(context)];
    case 'service':
      return [buildService(context)];
    case 'breadcrumb':
      return [buildBreadcrumb(context)];
  }
}

/* -------------------------------------------------------------------------- */
/* Builders                                                                   */
/* -------------------------------------------------------------------------- */

function buildOrganization(context: BuildContext, type: 'Organization' | 'LocalBusiness'): JsonLdNode {
  const { business } = context;
  const node: Record<string, JsonValue | undefined> = {
    '@type': type,
    ...(context.baseUrl ? { '@id': `${context.baseUrl}/#organization` } : {}),
    name: take(context, 'name', business.name, 'user_provided', 'Business name'),
    url: take(context, 'url', business.websiteUrl, 'user_provided', 'Website'),
    description: take(context, 'description', business.description, 'user_provided', 'What you sell'),
    logo: take(context, 'logo', business.logoUrl, 'user_provided', 'Logo URL'),
    telephone: take(context, 'telephone', business.telephone, 'user_provided', 'Telephone'),
    email: take(context, 'email', business.email, 'user_provided', 'Email'),
    address: buildAddress(context),
    sameAs: takeList(context, 'sameAs', business.sameAs, 'user_provided', 'Social profiles'),
  };

  if (type === 'LocalBusiness') {
    node['openingHours'] = take(
      context,
      'openingHours',
      business.openingHours,
      'user_provided',
      'Opening hours',
    );
    // priceRange is a band, not a price, and schema.org expects a short symbol
    // string. It is still only emitted when the user stated it.
    if (!business.openingHours) {
      // already reported by `take`; nothing more to add.
    }
  }

  return prunedNode(node);
}

function buildAddress(context: BuildContext): JsonValue | undefined {
  const { business } = context;
  const parts = {
    streetAddress: business.streetAddress,
    addressLocality: business.city,
    addressRegion: business.region,
    postalCode: business.postalCode,
    addressCountry: business.country,
  };
  const present = Object.entries(parts).filter(([, value]) => hasText(value));
  if (present.length === 0) {
    context.omitted.push({
      property: 'address',
      why: 'No address was captured. Add your street, city, postcode and country in the workspace and it appears here.',
    });
    return undefined;
  }
  if (!hasText(business.city) || !hasText(business.country)) {
    context.omitted.push({
      property: 'address.addressLocality',
      why: 'The address is partial: city and country are what consumers rely on most.',
    });
  }
  context.included.push({ property: 'address', source: 'user_provided', from: 'Business location' });
  return prune({ '@type': 'PostalAddress', ...Object.fromEntries(present) }) ?? undefined;
}

function buildWebSite(context: BuildContext): JsonLdNode {
  const node: Record<string, JsonValue | undefined> = {
    '@type': 'WebSite',
    ...(context.baseUrl ? { '@id': `${context.baseUrl}/#website` } : {}),
    name: take(context, 'name', context.business.name, 'user_provided', 'Business name'),
    url: take(context, 'url', context.business.websiteUrl, 'user_provided', 'Website'),
    description: take(context, 'description', context.business.description, 'user_provided', 'What you sell'),
    inLanguage: take(context, 'inLanguage', context.page?.inLanguage, 'retrieved', 'Page language'),
    ...(context.baseUrl ? { publisher: { '@id': `${context.baseUrl}/#organization` } } : {}),
  };
  return prunedNode(node);
}

function buildWebPage(context: BuildContext): JsonLdNode {
  const page = context.page;
  if (!page) {
    context.omitted.push({
      property: 'url',
      why: 'No page was selected. Run a crawl or choose a page, and its real title, description and language are used.',
    });
    return prunedNode({ '@type': 'WebPage' });
  }
  const node: Record<string, JsonValue | undefined> = {
    '@type': 'WebPage',
    '@id': `${stripHash(page.url)}#webpage`,
    name: take(context, 'name', page.title, 'retrieved', 'Page title'),
    url: take(context, 'url', page.url, 'retrieved', 'Page URL'),
    description: take(context, 'description', page.metaDescription, 'retrieved', 'Meta description'),
    inLanguage: take(context, 'inLanguage', page.inLanguage, 'retrieved', 'Page language'),
    dateModified: take(context, 'dateModified', page.dateModified, 'retrieved', 'Last modified'),
    ...(context.baseUrl ? { isPartOf: { '@id': `${context.baseUrl}/#website` } } : {}),
  };
  return prunedNode(node);
}

function buildArticle(context: BuildContext): JsonLdNode[] {
  const page = context.page;
  if (!page) {
    context.omitted.push({
      property: 'headline',
      why: 'No page was selected, so there is no headline, date or author to use. Pick a crawled page.',
    });
    return [prunedNode({ '@type': 'Article' })];
  }

  const article: Record<string, JsonValue | undefined> = {
    '@type': 'Article',
    '@id': `${stripHash(page.url)}#article`,
    headline: take(context, 'headline', page.headline ?? page.title, 'retrieved', 'Page H1 or title'),
    description: take(context, 'description', page.metaDescription, 'retrieved', 'Meta description'),
    url: take(context, 'url', page.url, 'retrieved', 'Page URL'),
    image: take(context, 'image', page.imageUrl, 'retrieved', 'Main image'),
    datePublished: take(context, 'datePublished', page.datePublished, 'retrieved', 'Published date'),
    dateModified: take(context, 'dateModified', page.dateModified, 'retrieved', 'Last modified'),
    inLanguage: take(context, 'inLanguage', page.inLanguage, 'retrieved', 'Page language'),
    author: hasText(page.authorName)
      ? { '@type': 'Person', name: page.authorName!.trim() }
      : undefined,
    ...(context.baseUrl ? { publisher: { '@id': `${context.baseUrl}/#organization` } } : {}),
    mainEntityOfPage: { '@id': `${stripHash(page.url)}#webpage` },
  };

  if (hasText(page.authorName)) {
    context.included.push({ property: 'author', source: 'retrieved', from: 'Page byline' });
  } else {
    context.omitted.push({
      property: 'author',
      why: 'No author was found on the page. Published guidance asks for one; add a byline the page actually shows.',
    });
  }

  const nodes: JsonLdNode[] = [prunedNode(article)];
  // The organization node is included so the publisher reference resolves. A
  // publisher @id pointing at a node that is not in the graph is a dangling
  // reference, which is worse than no publisher.
  if (context.baseUrl) nodes.push(buildOrganization(context, 'Organization'));
  return nodes;
}

function buildFaq(context: BuildContext): JsonLdNode {
  const faqs = context.page?.faqs ?? [];
  if (faqs.length === 0) {
    context.omitted.push({
      property: 'mainEntity',
      why: 'No question-and-answer pairs were found on the page. FAQ markup must describe questions and answers a visitor can actually read on the page, so none were invented.',
    });
    return prunedNode({ '@type': 'FAQPage' });
  }

  context.included.push({ property: 'mainEntity', source: 'retrieved', from: 'Questions found on the page' });
  return prunedNode({
    '@type': 'FAQPage',
    ...(context.page ? { '@id': `${stripHash(context.page.url)}#faq` } : {}),
    name: take(context, 'name', context.page?.title, 'retrieved', 'Page title'),
    mainEntity: faqs.map((entry) => ({
      '@type': 'Question',
      name: entry.question.trim(),
      acceptedAnswer: { '@type': 'Answer', text: entry.answer.trim() },
    })),
  });
}

function buildService(context: BuildContext): JsonLdNode {
  const { business } = context;
  const node: Record<string, JsonValue | undefined> = {
    '@type': 'Service',
    name: take(context, 'name', business.productsServices, 'user_provided', 'What you sell'),
    description: take(context, 'description', business.description, 'user_provided', 'Business description'),
    serviceType: take(context, 'serviceType', business.industry, 'user_provided', 'Industry'),
    areaServed: take(context, 'areaServed', business.city, 'user_provided', 'City'),
    ...(context.baseUrl ? { provider: { '@id': `${context.baseUrl}/#organization` } } : {}),
  };
  // A Service with no price is correct and complete; the price is refused above.
  return prunedNode(node);
}

function buildBreadcrumb(context: BuildContext): JsonLdNode {
  const trail = context.page?.breadcrumb ?? [];
  if (trail.length === 0) {
    context.omitted.push({
      property: 'itemListElement',
      why: 'No breadcrumb trail was found on the page. A trail that does not match the page\'s own navigation would be wrong, so none was invented.',
    });
    return prunedNode({ '@type': 'BreadcrumbList' });
  }

  context.included.push({
    property: 'itemListElement',
    source: 'retrieved',
    from: 'Breadcrumb links on the page',
  });
  return prunedNode({
    '@type': 'BreadcrumbList',
    itemListElement: trail.map((entry, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: entry.name.trim(),
      // Only the final item may omit its URL, which is exactly what a trail
      // ending on the current page looks like.
      ...(entry.url ? { item: entry.url } : {}),
    })),
  });
}

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Uses a value if we have it, and records which it was.
 *
 * Nothing in this module writes a property without going through here, so the
 * `included` / `omitted` lists cannot drift from the output. That is the point:
 * a provenance list maintained by hand alongside a builder is a provenance list
 * that is wrong by the third edit.
 */
function take(
  context: BuildContext,
  property: string,
  value: string | null | undefined,
  source: ValueSource,
  from: string,
): string | undefined {
  if (!hasText(value)) {
    context.omitted.push({ property, why: `Not set. Add "${from}" in the workspace and it appears here.` });
    return undefined;
  }
  context.included.push({ property, source, from });
  return value.trim();
}

function takeList(
  context: BuildContext,
  property: string,
  values: readonly string[] | undefined,
  source: ValueSource,
  from: string,
): JsonValue | undefined {
  const usable = (values ?? []).map((value) => value.trim()).filter((value) => value.length > 0);
  if (usable.length === 0) {
    context.omitted.push({ property, why: `Not set. Add "${from}" in the workspace and they appear here.` });
    return undefined;
  }
  context.included.push({ property, source, from });
  return usable.length === 1 ? usable[0]! : usable;
}

function hasText(value: string | null | undefined): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}

function prunedNode(node: Record<string, JsonValue | undefined>): JsonLdNode {
  const pruned = prune(node);
  return (pruned && typeof pruned === 'object' && !Array.isArray(pruned) ? pruned : {}) as JsonLdNode;
}

function normalizeBase(url: string): string {
  const trimmed = url.trim().replace(/\/+$/, '');
  if (trimmed.length === 0) return '';
  try {
    const parsed = new URL(trimmed);
    return `${parsed.protocol}//${parsed.host}`;
  } catch {
    return '';
  }
}

function stripHash(url: string): string {
  return url.split('#')[0] ?? url;
}

function dedupeByProperty(values: readonly OmittedValue[]): OmittedValue[] {
  const seen = new Map<string, OmittedValue>();
  for (const value of values) {
    if (!seen.has(value.property)) seen.set(value.property, value);
  }
  return [...seen.values()];
}
