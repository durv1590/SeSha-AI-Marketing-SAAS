/**
 * Structured-data (JSON-LD) generation.
 *
 * Hard rules enforced by this module and its tests:
 *  1. Schema is generated ONLY from verified application data.
 *  2. `aggregateRating`, `review`, `award` and `offers` are never emitted from
 *     placeholder data. `buildOffers` refuses unverified pricing.
 *  3. Undefined / empty values are pruned so no empty properties are published.
 *
 * Framework-free: no Next.js imports, fully unit tested.
 */

import { organization, site, type Author } from '@/content/site';
import { absoluteUrl } from '@/lib/seo/core';
import { getBreadcrumbs } from '@/lib/routes';

export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };
export type JsonLdNode = { [key: string]: JsonValue };

const SCHEMA_CONTEXT = 'https://schema.org';

/** Stable @id anchors so nodes can reference each other inside one graph. */
export const schemaIds = {
  organization: `${site.url}/#organization`,
  website: `${site.url}/#website`,
  webPage: (path: string) => `${absoluteUrl(path)}#webpage`,
  breadcrumb: (path: string) => `${absoluteUrl(path)}#breadcrumb`,
  article: (path: string) => `${absoluteUrl(path)}#article`,
  faq: (path: string) => `${absoluteUrl(path)}#faq`,
  software: `${site.url}/#software`,
} as const;

/** Recursively removes undefined, null, empty strings, empty arrays/objects. */
export function prune(value: unknown): JsonValue | undefined {
  if (value === undefined || value === null) return undefined;
  if (typeof value === 'string') {
    const trimmed = value.trim();
    return trimmed.length > 0 ? trimmed : undefined;
  }
  if (typeof value === 'number') return Number.isFinite(value) ? value : undefined;
  if (typeof value === 'boolean') return value;
  if (Array.isArray(value)) {
    const items = value.map(prune).filter((v): v is JsonValue => v !== undefined);
    return items.length > 0 ? items : undefined;
  }
  if (typeof value === 'object') {
    const out: Record<string, JsonValue> = {};
    for (const [key, raw] of Object.entries(value as Record<string, unknown>)) {
      const cleaned = prune(raw);
      if (cleaned !== undefined) out[key] = cleaned;
    }
    return Object.keys(out).length > 0 ? out : undefined;
  }
  return undefined;
}

function node(input: Record<string, unknown>): JsonLdNode {
  return (prune(input) ?? {}) as JsonLdNode;
}

/* -------------------------------------------------------------------------- */
/* Organization                                                               */
/* -------------------------------------------------------------------------- */

export function organizationSchema(): JsonLdNode {
  return node({
    '@type': 'Organization',
    '@id': schemaIds.organization,
    name: organization.brandName,
    legalName: organization.legalName,
    url: `${site.url}/`,
    description: organization.description,
    email: organization.email,
    telephone: organization.telephone,
    foundingDate: organization.foundingYear ? String(organization.foundingYear) : undefined,
    logo: {
      '@type': 'ImageObject',
      url: absoluteUrl('/brand/logo-mark.svg'),
      caption: `${organization.brandName} logo`,
    },
    address: organization.address
      ? { '@type': 'PostalAddress', ...organization.address }
      : undefined,
    // sameAs is emitted only when verified profiles exist.
    sameAs: organization.sameAs.length > 0 ? [...organization.sameAs] : undefined,
    contactPoint: {
      '@type': 'ContactPoint',
      contactType: 'customer support',
      email: organization.email,
      availableLanguage: ['English'],
    },
  });
}

/* -------------------------------------------------------------------------- */
/* WebSite                                                                    */
/* -------------------------------------------------------------------------- */

export function webSiteSchema(): JsonLdNode {
  return node({
    '@type': 'WebSite',
    '@id': schemaIds.website,
    name: site.name,
    url: `${site.url}/`,
    description: organization.description,
    inLanguage: site.language,
    publisher: { '@id': schemaIds.organization },
    // No SearchAction: the site has no site-search endpoint in Phase 1.
    // Emitting one that does not resolve would be a fabricated capability.
  });
}

/* -------------------------------------------------------------------------- */
/* WebPage                                                                    */
/* -------------------------------------------------------------------------- */

export interface WebPageInput {
  readonly path: string;
  readonly name: string;
  readonly description: string;
  readonly dateModified?: string;
  readonly datePublished?: string;
  readonly primaryImage?: string;
}

export function webPageSchema(input: WebPageInput): JsonLdNode {
  const url = absoluteUrl(input.path);
  return node({
    '@type': 'WebPage',
    '@id': schemaIds.webPage(input.path),
    url,
    name: input.name,
    description: input.description,
    inLanguage: site.language,
    isPartOf: { '@id': schemaIds.website },
    about: { '@id': schemaIds.organization },
    datePublished: input.datePublished,
    dateModified: input.dateModified,
    primaryImageOfPage: input.primaryImage
      ? { '@type': 'ImageObject', url: absoluteUrl(input.primaryImage) }
      : undefined,
    breadcrumb: { '@id': schemaIds.breadcrumb(input.path) },
  });
}

/* -------------------------------------------------------------------------- */
/* BreadcrumbList                                                             */
/* -------------------------------------------------------------------------- */

export interface BreadcrumbItem {
  readonly path: string;
  readonly label: string;
}

export function breadcrumbSchema(path: string, trail?: readonly BreadcrumbItem[]): JsonLdNode {
  const items = trail ?? getBreadcrumbs(path);
  return node({
    '@type': 'BreadcrumbList',
    '@id': schemaIds.breadcrumb(path),
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.label,
      item: absoluteUrl(item.path),
    })),
  });
}

/* -------------------------------------------------------------------------- */
/* Article                                                                    */
/* -------------------------------------------------------------------------- */

export interface ArticleInput {
  readonly path: string;
  readonly headline: string;
  readonly description: string;
  readonly datePublished: string;
  readonly dateModified?: string;
  readonly author: Author;
  readonly image?: string;
  readonly wordCount?: number;
  readonly articleSection?: string;
}

export function articleSchema(input: ArticleInput): JsonLdNode {
  return node({
    '@type': 'Article',
    '@id': schemaIds.article(input.path),
    headline: input.headline.slice(0, 110),
    description: input.description,
    url: absoluteUrl(input.path),
    datePublished: input.datePublished,
    dateModified: input.dateModified ?? input.datePublished,
    inLanguage: site.language,
    articleSection: input.articleSection,
    wordCount: input.wordCount,
    author: {
      '@type': 'Organization',
      name: input.author.name,
      url: absoluteUrl(input.author.url),
      description: input.author.bio,
    },
    publisher: { '@id': schemaIds.organization },
    isPartOf: { '@id': schemaIds.website },
    mainEntityOfPage: { '@id': schemaIds.webPage(input.path) },
    image: input.image
      ? { '@type': 'ImageObject', url: absoluteUrl(input.image) }
      : undefined,
  });
}

/* -------------------------------------------------------------------------- */
/* FAQPage                                                                    */
/* -------------------------------------------------------------------------- */

export interface FaqEntry {
  readonly question: string;
  readonly answer: string;
}

export function faqPageSchema(path: string, entries: readonly FaqEntry[]): JsonLdNode | null {
  const usable = entries.filter(
    (e) => e.question.trim().length > 0 && e.answer.trim().length > 0,
  );
  if (usable.length === 0) return null;

  return node({
    '@type': 'FAQPage',
    '@id': schemaIds.faq(path),
    mainEntity: usable.map((entry) => ({
      '@type': 'Question',
      name: entry.question,
      acceptedAnswer: { '@type': 'Answer', text: entry.answer },
    })),
  });
}

/* -------------------------------------------------------------------------- */
/* SoftwareApplication                                                        */
/* -------------------------------------------------------------------------- */

export interface OfferInput {
  readonly name: string;
  readonly price: number;
  readonly currency: string;
  readonly billingPeriod: string;
  /** Must be true for the offer to be published. */
  readonly verified: boolean;
}

/**
 * Converts pricing tiers into schema.org Offers.
 * Unverified (placeholder) prices are DROPPED, never published — publishing a
 * placeholder price is a fabricated business fact.
 */
export function buildOffers(tiers: readonly OfferInput[]): JsonValue[] | undefined {
  const verified = tiers.filter((t) => t.verified && Number.isFinite(t.price));
  if (verified.length === 0) return undefined;
  return verified.map((tier) =>
    node({
      '@type': 'Offer',
      name: tier.name,
      price: tier.price,
      priceCurrency: tier.currency,
      availability: 'https://schema.org/InStock',
    }),
  );
}

export interface SoftwareApplicationInput {
  readonly applicationCategory: string;
  readonly operatingSystem: string;
  readonly featureList: readonly string[];
  readonly offers?: JsonValue[];
}

export function softwareApplicationSchema(input: SoftwareApplicationInput): JsonLdNode {
  return node({
    '@type': 'SoftwareApplication',
    '@id': schemaIds.software,
    name: organization.brandName,
    description: organization.description,
    url: `${site.url}/`,
    applicationCategory: input.applicationCategory,
    operatingSystem: input.operatingSystem,
    featureList: [...input.featureList],
    publisher: { '@id': schemaIds.organization },
    offers: input.offers,
    // aggregateRating / review intentionally never emitted: no verified
    // first-party review data exists.
  });
}

/* -------------------------------------------------------------------------- */
/* Graph assembly                                                             */
/* -------------------------------------------------------------------------- */

/** Wraps nodes into a single `@graph` document — one JSON-LD block per page. */
export function buildGraph(nodes: readonly (JsonLdNode | null | undefined)[]): JsonLdNode {
  return {
    '@context': SCHEMA_CONTEXT,
    '@graph': nodes.filter((n): n is JsonLdNode => Boolean(n && Object.keys(n).length > 0)),
  };
}

/** Serialises a graph safely for inline injection into a <script> tag. */
export function serializeJsonLd(graph: JsonLdNode): string {
  return JSON.stringify(graph).replace(/</g, '\\u003c').replace(/>/g, '\\u003e');
}
