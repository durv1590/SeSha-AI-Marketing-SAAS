/**
 * Report service: generating, storing, exporting and sharing.
 *
 * A GENERATED REPORT IS STORED WHOLE AND NEVER REGENERATED
 * `reports.document` holds the rendered report, including every metric with its
 * provenance. Exporting and sharing read that row; they do not re-run the
 * generator. A link sent to a client in March must show what it showed in March,
 * and a PDF downloaded twice must be the same PDF.
 *
 * The facts a report is built from come from the analytics service and from the
 * project's own records — never from anything invented for the narrative.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { enforceOrThrow } from '@/lib/quota/service';
import { periodStartOf } from '@/lib/usage/metrics';
import { assertTenant, NotFoundError, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { ReportRow, ReportShareRow } from '@/lib/db/types';
import { analyticsFor, connectionsFor, type AnalyticsServiceContext } from '@/lib/analytics/service';
import { toEvent } from '@/lib/calendar/service';

import {
  REPORT_LABEL,
  REPORT_SPAN_DAYS,
  isReportKind,
  type Report,
  type ReportKind,
} from './types';
import {
  REPORT_METRICS,
  generateReport,
  type ActivityFact,
  type CampaignFact,
  type CauseFact,
  type PageFact,
  type RecommendationFact,
  type ReportFacts,
} from './generate';
import { toCsv, toJson, type ExportFormat } from './export';
import { toPdfBytes } from './pdf';
import {
  DEFAULT_SHARE_DAYS,
  checkShare,
  createShareToken,
  hashShareToken,
  looksLikeShareToken,
  SHARE_DENIED_MESSAGE,
} from './share';

export interface ReportServiceContext extends AnalyticsServiceContext {
  readonly db: Database;
}

function clock(context: ReportServiceContext): Date {
  return context.now?.() ?? new Date();
}

export class ReportInputError extends Error {
  readonly code = 'INVALID_INPUT' as const;
  constructor(message: string) {
    super(message);
    this.name = 'ReportInputError';
  }
}

export class ShareDeniedError extends Error {
  readonly code = 'SHARE_DENIED' as const;
  /** For the audit log only. The page shows `SHARE_DENIED_MESSAGE`. */
  readonly reason: string;
  constructor(reason: string) {
    super(SHARE_DENIED_MESSAGE);
    this.name = 'ShareDeniedError';
    this.reason = reason;
  }
}

/* -------------------------------------------------------------------------- */
/* Generation                                                                 */
/* -------------------------------------------------------------------------- */

export async function generate(
  context: ReportServiceContext,
  tenant: TenantContext,
  projectId: string,
  kind: ReportKind,
): Promise<ReportRow> {
  requirePermission(tenant.role, 'analytics:read');
  if (!isReportKind(kind)) throw new ReportInputError('That is not a report SeSha produces.');

  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  const found = assertTenant(tenant, project, 'Project');

  await enforceOrThrow(context, tenant.organizationId, 'reports', {
    projectId,
    userId: tenant.userId,
  });

  const organization = await context.db.organizations.findById(tenant.organizationId);

  const now = clock(context);
  const days = REPORT_SPAN_DAYS[kind];
  const analytics = await analyticsFor(context, tenant, projectId, {
    days,
    label: periodLabel(kind, now, days),
    only: REPORT_METRICS[kind],
  });
  const connections = await connectionsFor(context, tenant, projectId);

  const facts: ReportFacts = {
    kind,
    id: 'pending',
    organizationName: organization?.name ?? found.name,
    period: analytics.period,
    generatedAt: analytics.generatedAt,
    metrics: analytics.metrics,
    connections,
    activity: await gatherActivity(context, tenant, projectId, analytics.period.from, analytics.period.to),
    campaigns: await gatherCampaigns(context, tenant, projectId),
    pages: await gatherPages(context, tenant, projectId),
    causes: await gatherCauses(context, tenant, projectId),
    recommendations: await gatherRecommendations(context, tenant, projectId),
  };

  const report = generateReport(facts);

  const row = await context.db.reports.create({
    organizationId: tenant.organizationId,
    projectId,
    kind,
    title: report.title,
    periodFrom: analytics.period.from.slice(0, 10),
    periodTo: analytics.period.to.slice(0, 10),
    periodLabel: analytics.period.label,
    document: report as unknown as Readonly<Record<string, unknown>>,
    connectedSources: report.provenance.connectedSources,
    generatedBy: tenant.userId,
    generatedAt: now,
  });

  // Phase 9: the `reports` limit was checked above but never consumed, so the
  // Free plan's monthly allowance never bound. Recorded after the row exists,
  // so a failed generation is not charged.
  await context.db.usage.record({
    organizationId: tenant.organizationId,
    projectId,
    metric: 'report',
    quantity: 1,
    periodStart: periodStartOf(new Date(now)),
  });
  return row;
}

function periodLabel(kind: ReportKind, now: Date, days: number): string {
  const date = now.toISOString().slice(0, 10);
  switch (kind) {
    case 'daily':
      return `Day to ${date}`;
    case 'weekly':
      return `Week to ${date}`;
    case 'monthly':
      return `Month to ${date}`;
    default:
      return `${REPORT_LABEL[kind]}, ${days} days to ${date}`;
  }
}

/* -------------------------------------------------------------------------- */
/* Gathering facts                                                            */
/* -------------------------------------------------------------------------- */

async function gatherActivity(
  context: ReportServiceContext,
  tenant: TenantContext,
  projectId: string,
  from: string,
  to: string,
): Promise<ActivityFact> {
  const start = new Date(from);
  const end = new Date(to);
  const inWindow = (at: Date): boolean => at.getTime() > start.getTime() && at.getTime() <= end.getTime();

  const leads = await context.db.leads.listForProject(tenant.organizationId, projectId);
  const content = await context.db.content.listForProject(tenant.organizationId, projectId);
  const events = await context.db.calendar.listInRange(
    tenant.organizationId,
    projectId,
    from.slice(0, 10),
    to.slice(0, 10),
  );

  const rules = await context.db.automation.listRules(tenant.organizationId, projectId);
  let automationRuns = 0;
  let automationActions = 0;
  for (const rule of rules) {
    const runs = await context.db.automation.listRuns(tenant.organizationId, rule.id, 500);
    for (const run of runs) {
      if (!inWindow(run.ranAt)) continue;
      automationRuns += 1;
      automationActions += run.actionsTaken.length;
    }
  }

  const contentInPeriod = content.filter((row) => inWindow(row.createdAt));

  return {
    contentCreated: contentInPeriod.length,
    contentApproved: contentInPeriod.filter((row) => row.status === 'approved').length,
    leadsCreated: leads.filter((row) => inWindow(row.createdAt)).length,
    leadsWon: leads.filter((row) => row.stage === 'won' && inWindow(row.updatedAt)).length,
    leadsLost: leads.filter((row) => row.stage === 'lost' && inWindow(row.updatedAt)).length,
    calendarDone: events.filter((row) => row.status === 'done').length,
    calendarPlanned: events.filter((row) => row.status === 'planned').length,
    calendarSkipped: events.filter((row) => row.status === 'skipped').length,
    automationRuns,
    automationActions,
  };
}

async function gatherCampaigns(
  context: ReportServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<readonly CampaignFact[]> {
  const plans = await context.db.adPlans.listForProject(tenant.organizationId, projectId);
  const facts: CampaignFact[] = [];

  for (const plan of plans) {
    const events = plan.campaignName
      ? (await context.db.calendar.listForCampaign(tenant.organizationId, plan.campaignName)).map(toEvent)
      : [];
    facts.push({
      id: plan.id,
      name: plan.campaignName ?? 'Untitled campaign',
      platform: plan.platform,
      status: plan.reviewState,
      planned: events.filter((event) => event.status === 'planned').length,
      done: events.filter((event) => event.status === 'done').length,
      // The honest version of "campaign decline": SeSha has no ads API, so the
      // only decline it can see is a person rejecting the plan in review.
      ...(plan.reviewState === 'rejected'
        ? { declinedReason: plan.reviewNote?.trim() || 'No reason was recorded.' }
        : {}),
    });
  }

  return facts;
}

async function gatherPages(
  context: ReportServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<readonly PageFact[]> {
  const byUrl = new Map<string, { label: string; severity: string; area: string }[]>();

  for (const kind of ['seo', 'aeo'] as const) {
    const audit = await context.db.audits.findLatest(tenant.organizationId, projectId, kind);
    if (!audit) continue;
    for (const raw of audit.findings) {
      // Stored findings are the audit's `Finding` shape: the pages live in
      // `evidence.urls` and the one-line label in `issue`. (This used to read
      // `url`/`title`, which no audit writes, so "Which pages?" was always empty.)
      const finding = raw as {
        evidence?: { urls?: readonly unknown[] };
        issue?: string;
        severity?: string;
      };
      const urls = Array.isArray(finding.evidence?.urls) ? finding.evidence.urls : [];
      for (const url of urls) {
        if (typeof url !== 'string' || url.length === 0) continue;
        const list = byUrl.get(url) ?? [];
        list.push({
          label: finding.issue ?? 'Finding',
          severity: finding.severity ?? 'unknown',
          area: kind.toUpperCase(),
        });
        byUrl.set(url, list);
      }
    }
  }

  return [...byUrl.entries()]
    .map(([url, issues]) => ({ url, issues }))
    .sort((a, b) => b.issues.length - a.issues.length);
}

/**
 * Real causes, from the customer's own records.
 *
 * Empty when there are none — the generator then says so rather than inventing
 * an explanation, which is the whole point of the section.
 */
async function gatherCauses(
  context: ReportServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<readonly CauseFact[]> {
  const causes: CauseFact[] = [];

  const crawl = await context.db.crawls.findLatest(tenant.organizationId, projectId);
  if (crawl?.stoppedEarly) {
    causes.push({
      what: 'The last crawl stopped early.',
      effect: `${crawl.stoppedEarly}. Everything below covers only the ${crawl.pagesCrawled} pages it reached, not your whole site.`,
      evidence: [crawl.id],
    });
  }
  if (crawl && crawl.pagesFailed > 0) {
    causes.push({
      what: `${crawl.pagesFailed} page${crawl.pagesFailed === 1 ? '' : 's'} could not be read on the last crawl.`,
      effect: 'A page the crawler cannot read is a page a search engine may not be reading either.',
      evidence: [crawl.id],
    });
  }

  const [validation] = await context.db.schemaValidations.listForProject(tenant.organizationId, projectId, 1);
  const invalid = validation?.counts.INVALID ?? 0;
  if (validation && invalid > 0) {
    causes.push({
      what: `Your most recent validation found ${invalid} structured-data error${invalid === 1 ? '' : 's'}.`,
      effect:
        'Search engines ignore markup they cannot parse, so any rich result depending on it will not appear.',
      evidence: [validation.id],
    });
  }

  return causes;
}

async function gatherRecommendations(
  context: ReportServiceContext,
  tenant: TenantContext,
  projectId: string,
): Promise<readonly RecommendationFact[]> {
  const recommendations: RecommendationFact[] = [];

  const seo = await context.db.audits.findLatest(tenant.organizationId, projectId, 'seo');
  if (seo && seo.findings.length > 0) {
    recommendations.push({
      text: `Work through the ${seo.findings.length} open SEO finding${seo.findings.length === 1 ? '' : 's'}.`,
      reason: `Your last audit scored ${seo.score}. ${seo.scoreBasis}`,
      evidence: [seo.id],
    });
  }

  const keywords = await context.db.keywords.listForProject(tenant.organizationId, projectId);
  const uncovered = keywords.filter((row) => row.coveringUrls.length === 0);
  if (uncovered.length > 0) {
    const examples = uncovered.slice(0, 3).map((row) => row.query);
    recommendations.push({
      text: `Write a page for one of: ${examples.join(', ')}.`,
      reason: `${uncovered.length} tracked keyword${uncovered.length === 1 ? ' has' : 's have'} no page addressing them. These came from your own site, not from a keyword tool.`,
    });
  }

  return recommendations;
}

/* -------------------------------------------------------------------------- */
/* Reading                                                                    */
/* -------------------------------------------------------------------------- */

export function toReport(row: ReportRow): Report {
  return row.document as unknown as Report;
}

export async function findReport(
  context: ReportServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<ReportRow> {
  requirePermission(tenant.role, 'analytics:read');
  const row = await context.db.reports.findById(tenant.organizationId, id);
  return assertTenant(tenant, row, 'Report');
}

export async function listReports(
  context: ReportServiceContext,
  tenant: TenantContext,
  projectId: string,
  limit = 50,
): Promise<readonly ReportRow[]> {
  requirePermission(tenant.role, 'analytics:read');
  const project = await context.db.projects.findById(tenant.organizationId, projectId);
  assertTenant(tenant, project, 'Project');
  return context.db.reports.listForProject(tenant.organizationId, projectId, limit);
}

/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export interface ExportedReport {
  readonly format: ExportFormat;
  readonly body: string | Uint8Array;
  readonly report: Report;
}

/**
 * Renders a STORED report in one of the three formats.
 *
 * Reads the stored document rather than regenerating, so a CSV and the PDF
 * downloaded a minute apart agree with each other and with what was on screen.
 */
export async function exportReport(
  context: ReportServiceContext,
  tenant: TenantContext,
  id: string,
  format: ExportFormat,
): Promise<ExportedReport> {
  const row = await findReport(context, tenant, id);
  const report = toReport(row);

  switch (format) {
    case 'json':
      return { format, body: toJson(report), report };
    case 'csv':
      return { format, body: toCsv(report), report };
    case 'pdf':
      return { format, body: toPdfBytes(report), report };
  }
}

/* -------------------------------------------------------------------------- */
/* Sharing                                                                    */
/* -------------------------------------------------------------------------- */

export interface CreatedShare {
  readonly share: ReportShareRow;
  /** Shown once. Not stored, and not recoverable afterwards. */
  readonly token: string;
  readonly path: string;
}

export async function shareReport(
  context: ReportServiceContext,
  tenant: TenantContext,
  id: string,
  days = DEFAULT_SHARE_DAYS,
): Promise<CreatedShare> {
  requirePermission(tenant.role, 'analytics:read');
  const row = await findReport(context, tenant, id);

  const now = clock(context);
  const created = createShareToken(days, now);
  const share = await context.db.reportShares.create({
    organizationId: tenant.organizationId,
    reportId: row.id,
    tokenHash: created.tokenHash,
    createdBy: tenant.userId,
    expiresAt: created.expiresAt,
    revokedAt: null,
  });

  await context.db.audit.record({
    organizationId: tenant.organizationId,
    actorId: tenant.userId,
    action: 'report.shared',
    entityType: 'report',
    entityId: row.id,
    outcome: 'success',
    metadata: { expiresAt: created.expiresAt.toISOString() },
    ipHash: null,
    userAgent: null,
  });

  return { share, token: created.token, path: `/share/${created.token}` };
}

export async function revokeShare(
  context: ReportServiceContext,
  tenant: TenantContext,
  shareId: string,
): Promise<ReportShareRow> {
  requirePermission(tenant.role, 'analytics:read');
  const revoked = await context.db.reportShares.revoke(tenant.organizationId, shareId, clock(context));
  if (!revoked) throw new NotFoundError('Share link');

  await context.db.audit.record({
    organizationId: tenant.organizationId,
    actorId: tenant.userId,
    action: 'report.share_revoked',
    entityType: 'report_share',
    entityId: shareId,
    outcome: 'success',
    metadata: {},
    ipHash: null,
    userAgent: null,
  });

  return revoked;
}

export async function listShares(
  context: ReportServiceContext,
  tenant: TenantContext,
  reportId: string,
): Promise<readonly ReportShareRow[]> {
  requirePermission(tenant.role, 'analytics:read');
  await findReport(context, tenant, reportId);
  return context.db.reportShares.listForReport(tenant.organizationId, reportId);
}

/**
 * Resolves a share token for an anonymous visitor.
 *
 * No TenantContext: the caller is not signed in, and the token is the only
 * credential. Every failure produces the same message, so a stranger cannot
 * learn from the wording whether the link was ever real.
 */
export async function viewShared(
  context: ReportServiceContext,
  token: string,
): Promise<{ readonly report: Report; readonly row: ReportRow }> {
  if (!looksLikeShareToken(token)) throw new ShareDeniedError('malformed');

  const now = clock(context);
  const share = await context.db.reportShares.findByTokenHash(hashShareToken(token));
  const check = checkShare(
    share ? { tokenHash: share.tokenHash, expiresAt: share.expiresAt, revokedAt: share.revokedAt } : null,
    now,
  );
  if (!check.ok) throw new ShareDeniedError(check.reason);

  const row = await context.db.reports.findById(share!.organizationId, share!.reportId);
  // A share whose report was deleted is refused identically: the reader learns
  // nothing about whether it ever existed.
  if (!row) throw new ShareDeniedError('report_deleted');

  await context.db.reportShares.recordView(share!.id, now);
  return { report: toReport(row), row };
}
