/**
 * Reports: the nine kinds, and the six questions every one of them answers.
 *
 * THE STRUCTURE IS THE PRODUCT
 * The brief asks for a report that answers: what happened, why, what next, which
 * campaigns, which pages, and where attention or budget should be reviewed. That
 * is not a layout — it is a promise that the report explains itself. So the six
 * sections are FIELDS ON A TYPE, not headings in a template string: a report that
 * cannot answer "why" has to say so in the `why` section rather than quietly
 * omitting it and leaving a confident-looking document behind.
 *
 * WHAT AN HONEST REPORT LOOKS LIKE WITH NOTHING CONNECTED
 * The tempting failure here is a beautifully formatted PDF whose numbers are all
 * invented, because a report is read away from the screen that would have shown
 * the caveat. Every figure in a report is a `MetricValue`, so it carries its own
 * provenance into the export; and a section with nothing behind it renders the
 * reason it is empty, which is genuinely useful information ("you have no traffic
 * figures because no analytics account is connected") rather than blank space.
 *
 * A report is a SNAPSHOT. It records what was known when it was generated,
 * including which connections existed, so a report read in six months is not
 * silently reinterpreted against today's data.
 *
 * Framework-free and fully unit tested.
 */

import type { Metric, MetricPeriod } from '../analytics/metrics';

/* -------------------------------------------------------------------------- */
/* Kinds                                                                      */
/* -------------------------------------------------------------------------- */

/** The nine report kinds the brief names, in its order. */
export const REPORT_KINDS = [
  'daily',
  'weekly',
  'monthly',
  'campaign',
  'seo',
  'aeo',
  'schema',
  'social',
  'executive',
] as const;

export type ReportKind = (typeof REPORT_KINDS)[number];

export const REPORT_LABEL: Readonly<Record<ReportKind, string>> = {
  daily: 'Daily report',
  weekly: 'Weekly report',
  monthly: 'Monthly report',
  campaign: 'Campaign report',
  seo: 'SEO report',
  aeo: 'AEO report',
  schema: 'Structured data report',
  social: 'Social report',
  executive: 'Executive summary',
};

export const REPORT_PURPOSE: Readonly<Record<ReportKind, string>> = {
  daily: 'What moved yesterday, and what is waiting for you today.',
  weekly: 'The week in your pipeline and your website, with what to do next week.',
  monthly: 'The month against the month before it, where a trend is long enough to mean something.',
  campaign: 'One campaign: what was planned, what was published, and what is known about it.',
  seo: 'The SEO findings from your most recent crawl, ordered by what they cost you.',
  aeo: 'How readable your pages are to answer engines, and what is in the way.',
  schema: 'Your structured data: what validates, what does not, and what search engines will ignore.',
  social: 'What you planned and approved for social, and what is known about how it did.',
  executive: 'One page for someone who will not read the others.',
};

/** How long a period each kind covers by default, in days. */
export const REPORT_SPAN_DAYS: Readonly<Record<ReportKind, number>> = {
  daily: 1,
  weekly: 7,
  monthly: 30,
  campaign: 90,
  seo: 30,
  aeo: 30,
  schema: 30,
  social: 30,
  executive: 30,
};

export function isReportKind(value: unknown): value is ReportKind {
  return typeof value === 'string' && (REPORT_KINDS as readonly string[]).includes(value);
}

/* -------------------------------------------------------------------------- */
/* The six sections                                                           */
/* -------------------------------------------------------------------------- */

/** The brief's six questions, as identifiers. */
export const SECTION_IDS = [
  'what_happened',
  'why',
  'what_next',
  'which_campaigns',
  'which_pages',
  'where_to_review',
] as const;

export type SectionId = (typeof SECTION_IDS)[number];

export const SECTION_QUESTION: Readonly<Record<SectionId, string>> = {
  what_happened: 'What happened?',
  why: 'Why?',
  what_next: 'What next?',
  which_campaigns: 'Which campaigns?',
  which_pages: 'Which pages?',
  where_to_review: 'Where should attention or budget be reviewed?',
};

/**
 * One line of a report.
 *
 * `detail` carries the reasoning; `evidence` names the records it came from, so a
 * reader who disagrees can go and look. A finding with no evidence is allowed —
 * some observations are about absence — but it must then say so in `detail`.
 */
export interface ReportPoint {
  readonly text: string;
  readonly detail?: string;
  /** Record ids or URLs this came from. */
  readonly evidence?: readonly string[];
  /**
   * Present when this point is about a figure. The figure keeps its provenance
   * all the way into the PDF, so a printed report cannot lose its caveats.
   */
  readonly metric?: Metric;
}

export interface ReportSection {
  readonly id: SectionId;
  readonly question: string;
  readonly points: readonly ReportPoint[];
  /**
   * Why the section is empty, when it is. Required rather than optional-in-spirit:
   * an empty section with no explanation reads as "nothing to report", which is a
   * claim, and usually the wrong one.
   */
  readonly emptyReason?: string;
}

/* -------------------------------------------------------------------------- */
/* The report                                                                 */
/* -------------------------------------------------------------------------- */

export interface ReportProvenance {
  /** Labels of the accounts that were connected when this was generated. */
  readonly connectedSources: readonly string[];
  /** True when nothing at all was connected. */
  readonly anyConnected: boolean;
  /** The sentence shown at the top of the report when nothing is connected. */
  readonly note: string;
}

export interface Report {
  readonly id: string;
  readonly kind: ReportKind;
  readonly title: string;
  readonly period: MetricPeriod;
  readonly generatedAt: string;
  readonly sections: readonly ReportSection[];
  /** Every metric the report drew on, whether or not it had a figure. */
  readonly metrics: readonly Metric[];
  readonly provenance: ReportProvenance;
}

/** Returns the sections in the brief's order, filling in any that were not built. */
export function orderedSections(sections: readonly ReportSection[]): readonly ReportSection[] {
  return SECTION_IDS.map(
    (id) =>
      sections.find((section) => section.id === id) ?? {
        id,
        question: SECTION_QUESTION[id],
        points: [],
        emptyReason: 'This report does not cover that question.',
      },
  );
}

export function section(
  id: SectionId,
  points: readonly ReportPoint[],
  emptyReason: string,
): ReportSection {
  return points.length > 0
    ? { id, question: SECTION_QUESTION[id], points }
    : { id, question: SECTION_QUESTION[id], points: [], emptyReason };
}

/** How many points the whole report carries. Used by the UI and by the tests. */
export function pointCount(report: Report): number {
  return report.sections.reduce((total, current) => total + current.points.length, 0);
}
