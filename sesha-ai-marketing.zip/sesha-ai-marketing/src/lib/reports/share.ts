/**
 * Sharing a report by link.
 *
 * A share link is an unauthenticated door into tenant data, which makes it the
 * most dangerous feature in Phase 6. Four decisions keep it safe, and each one is
 * a deliberate refusal of the convenient version:
 *
 * 1. THE TOKEN IS RANDOM, NOT DERIVED. A token built from the report id — even
 *    hashed — is enumerable the moment someone learns the scheme. 32 bytes from
 *    the platform CSPRNG, base64url, no structure to guess.
 *
 * 2. ONLY A HASH IS STORED. If the database leaks, the tokens in it are not usable
 *    links. The same reasoning as password storage, for the same reason: the
 *    stored value should not be the credential.
 *
 * 3. IT EXPIRES BY DEFAULT. A link with no expiry is a permanent hole that outlives
 *    the employee who created it. Ninety days maximum, thirty by default.
 *
 * 4. IT IS REVOCABLE, AND REVOCATION IS IMMEDIATE. Checked on every view, not
 *    cached.
 *
 * A shared report is a SNAPSHOT of the report as generated. It does not re-run
 * against today's data, because a link sent to a client in March must not silently
 * change in April.
 *
 * Framework-free and fully unit tested.
 */

import { randomBytes, createHash, timingSafeEqual } from 'node:crypto';

export const SHARE_TOKEN_BYTES = 32;
export const DEFAULT_SHARE_DAYS = 30;
export const MAX_SHARE_DAYS = 90;

export interface ShareToken {
  /** Given to the user once. Never stored. */
  readonly token: string;
  /** Stored. */
  readonly tokenHash: string;
  readonly expiresAt: Date;
}

export function hashShareToken(token: string): string {
  return createHash('sha256').update(token, 'utf8').digest('hex');
}

/**
 * Creates a share token.
 *
 * `now` is a parameter so the expiry is testable without waiting ninety days and
 * without a mocked clock.
 */
export function createShareToken(days: number, now: Date): ShareToken {
  const clamped = Math.min(Math.max(Math.floor(days), 1), MAX_SHARE_DAYS);
  const token = randomBytes(SHARE_TOKEN_BYTES).toString('base64url');
  return {
    token,
    tokenHash: hashShareToken(token),
    expiresAt: new Date(now.getTime() + clamped * 24 * 60 * 60 * 1000),
  };
}

export interface ShareRecord {
  readonly tokenHash: string;
  readonly expiresAt: Date;
  readonly revokedAt: Date | null;
}

export type ShareCheck =
  | { readonly ok: true }
  | { readonly ok: false; readonly reason: 'unknown' | 'expired' | 'revoked' };

/**
 * The one message an invalid link gets, whatever went wrong with it.
 *
 * "This link has expired" and "this link was revoked" are different sentences and
 * both tell a stranger that the link was once real, which is more than they need
 * to know. The `reason` is returned for the audit log, not for the page.
 */
export const SHARE_DENIED_MESSAGE =
  'This link is not available. Ask the person who sent it for a new one.';

export function checkShare(record: ShareRecord | null, now: Date): ShareCheck {
  if (!record) return { ok: false, reason: 'unknown' };
  if (record.revokedAt !== null) return { ok: false, reason: 'revoked' };
  if (record.expiresAt.getTime() <= now.getTime()) return { ok: false, reason: 'expired' };
  return { ok: true };
}

/**
 * Constant-time comparison of two token hashes.
 *
 * The lookup is by hash, so an attacker who could time the comparison could walk
 * the hash space a byte at a time. Cheap to do correctly.
 */
export function tokenHashesMatch(left: string, right: string): boolean {
  const a = Buffer.from(left, 'utf8');
  const b = Buffer.from(right, 'utf8');
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

/** The public path for a token. Relative, so it works on any deployment host. */
export function sharePath(token: string): string {
  return `/share/${encodeURIComponent(token)}`;
}

/**
 * Whether a token is even shaped like one of ours.
 *
 * Rejects the obviously-wrong before touching the database, so a scanner cannot
 * use lookup timing to distinguish a malformed token from a missing one.
 */
export function looksLikeShareToken(value: unknown): value is string {
  return typeof value === 'string' && /^[A-Za-z0-9_-]{40,64}$/.test(value);
}
