/**
 * Building a report from facts.
 *
 * A pure function from a fact bundle to a `Report`. No database, no clock, no
 * randomness — so a report can be regenerated from the same facts and come out
 * identical, which is what makes a shared report trustworthy over time.
 *
 * THE HARD PART IS "WHY?"
 * Every analytics product writes "what happened" by listing numbers. Very few
 * attempt "why", because the honest answer is usually "we cannot tell you from
 * here". This module writes a `why` section that either names a real cause found
 * in the customer's own records — a crawl that stopped early, a plan that was
 * declined, a page that lost its markup — or says plainly that the cause is not
 * visible to SeSha and what would make it visible.
 *
 * The alternative, which is what a generated narrative usually does, is to
 * restate the numbers in sentence form and call it analysis. That reads like
 * insight and contains none.
 *
 * Framework-free and fully unit tested.
 */

import {
  METRICS,
  change,
  formatValue,
  hasFigure,
  type Metric,
  type MetricId,
  type MetricPeriod,
} from '../analytics/metrics';
import type { ConnectionState } from '../analytics/connections';
import { analyticsStatus } from '../analytics/connections';
import {
  REPORT_LABEL,
  REPORT_PURPOSE,
  orderedSections,
  section,
  type Report,
  type ReportKind,
  type ReportPoint,
  type ReportSection,
} from './types';

/* -------------------------------------------------------------------------- */
/* Facts                                                                      */
/* -------------------------------------------------------------------------- */

export interface CampaignFact {
  readonly id: string;
  readonly name: string;
  readonly platform: string;
  readonly status: string;
  /** Entries on the calendar belonging to this campaign, done and planned. */
  readonly planned: number;
  readonly done: number;
  readonly declinedReason?: string;
}

export interface PageFact {
  readonly url: string;
  /** Findings on this page, worst first, already in the caller's severity order. */
  readonly issues: readonly { readonly label: string; readonly severity: string; readonly area: string }[];
  readonly lostMarkup?: readonly string[];
}

export interface ActivityFact {
  readonly contentCreated: number;
  readonly contentApproved: number;
  readonly leadsCreated: number;
  readonly leadsWon: number;
  readonly leadsLost: number;
  readonly calendarDone: number;
  readonly calendarPlanned: number;
  readonly calendarSkipped: number;
  readonly automationRuns: number;
  readonly automationActions: number;
}

export interface CauseFact {
  /** What happened, in the customer's words. */
  readonly what: string;
  /** Why it matters for the numbers above. */
  readonly effect: string;
  readonly evidence?: readonly string[];
}

export interface RecommendationFact {
  readonly text: string;
  readonly reason: string;
  readonly evidence?: readonly string[];
}

export interface ReportFacts {
  readonly kind: ReportKind;
  readonly id: string;
  readonly organizationName: string;
  readonly period: MetricPeriod;
  readonly generatedAt: string;
  readonly metrics: readonly Metric[];
  readonly connections: readonly ConnectionState[];
  readonly activity: ActivityFact;
  readonly campaigns: readonly CampaignFact[];
  readonly pages: readonly PageFact[];
  /** Real causes found in the customer's own records. May be empty. */
  readonly causes: readonly CauseFact[];
  readonly recommendations: readonly RecommendationFact[];
}

/* -------------------------------------------------------------------------- */
/* Which metrics belong in which report                                       */
/* -------------------------------------------------------------------------- */

/**
 * The metrics each report kind is ABOUT.
 *
 * A SEO report that also lists cost-per-click is a dashboard with a title. Each
 * kind names its own metrics, and anything outside the list is left out rather
 * than included "for completeness" — completeness is how a report becomes
 * unreadable and then unread.
 */
export const REPORT_METRICS: Readonly<Record<ReportKind, readonly MetricId[]>> = {
  daily: ['leads', 'conversion', 'crawl_errors', 'schema_issues'],
  weekly: ['leads', 'conversion', 'traffic', 'content_coverage', 'crawl_errors', 'schema_issues'],
  monthly: [
    'leads',
    'conversion',
    'traffic',
    'organic_search',
    'seo_score',
    'aeo_score',
    'content_coverage',
    'schema_issues',
  ],
  campaign: ['impressions', 'ctr', 'cpc', 'cpa', 'roas', 'campaign_performance', 'leads', 'conversion'],
  seo: ['seo_score', 'organic_search', 'crawl_errors', 'content_coverage'],
  aeo: ['aeo_score', 'content_coverage', 'schema_issues'],
  schema: ['schema_issues', 'crawl_errors'],
  social: ['followers', 'reach', 'engagement', 'content_performance'],
  executive: ['leads', 'conversion', 'traffic', 'seo_score', 'aeo_score', 'roas'],
};

function selectMetrics(facts: ReportFacts): readonly Metric[] {
  const wanted = REPORT_METRICS[facts.kind];
  return wanted
    .map((id) => facts.metrics.find((metric) => metric.id === id))
    .filter((metric): metric is Metric => metric !== undefined);
}

/* -------------------------------------------------------------------------- */
/* Sections                                                                   */
/* -------------------------------------------------------------------------- */

/**
 * "What happened?"
 *
 * Figures first, then activity. Activity is included even when every figure is
 * unavailable, because "you approved four articles and closed two deals" is a
 * true account of the period that does not need an analytics account — and a
 * report that said "no data" while the customer had worked all week would be
 * both useless and insulting.
 */
function whatHappened(facts: ReportFacts, metrics: readonly Metric[]): ReportSection {
  const points: ReportPoint[] = [];

  for (const metric of metrics) {
    if (!hasFigure(metric.value)) continue;
    const formatted = formatValue(metric.value);
    if (formatted === null) continue;
    const movement = change(metric.value, metric.previous);
    const trend =
      movement === null
        ? undefined
        : movement.direction === 'flat'
          ? 'Unchanged from the period before.'
          : `${movement.direction === 'up' ? 'Up' : 'Down'} ${
              movement.percent === null
                ? `${Math.abs(movement.delta)}`
                : `${Math.abs(Math.round(movement.percent))}%`
            } on the period before${
              METRICS[metric.id].higherIsBetter === (movement.direction === 'up') ? '.' : ', which is the wrong direction.'
            }`;
    points.push({
      text: `${metric.definition.label}: ${formatted}`,
      ...(trend ? { detail: trend } : {}),
      metric,
    });
  }

  const activity = activityPoints(facts);
  points.push(...activity);

  return section(
    'what_happened',
    points,
    'Nothing was recorded in this period: no leads, no content, no crawls and no validations. That is an accurate account of the period, not a missing figure.',
  );
}

function activityPoints(facts: ReportFacts): ReportPoint[] {
  const activity = facts.activity;
  const points: ReportPoint[] = [];

  if (activity.leadsCreated > 0 || activity.leadsWon > 0 || activity.leadsLost > 0) {
    points.push({
      text: `${activity.leadsCreated} lead${activity.leadsCreated === 1 ? '' : 's'} arrived; ${activity.leadsWon} won, ${activity.leadsLost} lost.`,
      detail: 'Counted from your own pipeline, not from any advertising platform.',
    });
  }
  if (activity.contentCreated > 0) {
    points.push({
      text: `${activity.contentCreated} content item${activity.contentCreated === 1 ? '' : 's'} created, ${activity.contentApproved} approved.`,
      detail:
        'This is work done, not results achieved. How these pieces performed needs a website analytics account.',
    });
  }
  if (activity.calendarDone > 0 || activity.calendarPlanned > 0 || activity.calendarSkipped > 0) {
    points.push({
      text: `Calendar: ${activity.calendarDone} done, ${activity.calendarPlanned} still planned, ${activity.calendarSkipped} skipped.`,
      ...(activity.calendarSkipped > activity.calendarDone
        ? { detail: 'More was skipped than completed, which usually means the plan is heavier than the week allows.' }
        : {}),
    });
  }
  if (activity.automationRuns > 0) {
    points.push({
      text: `${activity.automationRuns} automation run${activity.automationRuns === 1 ? '' : 's'} produced ${activity.automationActions} task${activity.automationActions === 1 ? '' : 's'} or suggestion${activity.automationActions === 1 ? '' : 's'}.`,
      detail: 'SeSha automations never contact anyone. Everything they produce waits for a person.',
    });
  }

  return points;
}

/**
 * "Why?"
 *
 * Real causes if there are any; otherwise the honest statement that the cause is
 * not visible from here. Never a restatement of the numbers.
 */
function why(facts: ReportFacts, metrics: readonly Metric[]): ReportSection {
  const points: ReportPoint[] = facts.causes.map((cause) => ({
    text: cause.what,
    detail: cause.effect,
    ...(cause.evidence ? { evidence: cause.evidence } : {}),
  }));

  const unavailable = metrics.filter((metric) => metric.value.kind === 'unavailable');
  if (unavailable.length > 0) {
    const names = unavailable.map((metric) => metric.definition.label);
    points.push({
      text: `${names.length} of the figures this report covers could not be measured: ${names.join(', ')}.`,
      detail:
        'That is not a dip — it is an absence of measurement. Until the relevant account is connected, no cause can be given for them, and none is guessed at here.',
    });
  }

  return section(
    'why',
    points,
    'Nothing in your records explains a change this period, and SeSha will not invent a cause. If you know what changed, note it against the campaign or the page so the next report can say so.',
  );
}

function whatNext(facts: ReportFacts): ReportSection {
  const points: ReportPoint[] = facts.recommendations.map((recommendation) => ({
    text: recommendation.text,
    detail: recommendation.reason,
    ...(recommendation.evidence ? { evidence: recommendation.evidence } : {}),
  }));

  return section(
    'what_next',
    points,
    'No recommendation this period. SeSha makes them from findings, declined plans and calendar gaps, and there were none.',
  );
}

function whichCampaigns(facts: ReportFacts): ReportSection {
  const points: ReportPoint[] = facts.campaigns.map((campaign) => ({
    text: `${campaign.name} (${campaign.platform}) — ${campaign.status}`,
    detail: campaign.declinedReason
      ? `Declined in review: ${campaign.declinedReason}`
      : `${campaign.done} of ${campaign.planned + campaign.done} planned entries completed. SeSha cannot read this campaign's delivery, because no advertising account is connected.`,
    evidence: [campaign.id],
  }));

  return section(
    'which_campaigns',
    points,
    'No campaign was planned or active in this period. Campaigns appear here once one is grouped on the calendar or planned in Ads.',
  );
}

function whichPages(facts: ReportFacts): ReportSection {
  const points: ReportPoint[] = facts.pages.slice(0, 25).map((page) => {
    const worst = page.issues[0];
    const lost = page.lostMarkup && page.lostMarkup.length > 0;
    return {
      text: page.url,
      detail: lost
        ? `Markup that used to be published here is gone: ${page.lostMarkup!.join(', ')}. Search engines will already have stopped seeing it.`
        : worst
          ? `${page.issues.length} finding${page.issues.length === 1 ? '' : 's'}, worst is "${worst.label}" (${worst.severity}, ${worst.area}).`
          : 'No findings recorded.',
      evidence: [page.url],
    };
  });

  return section(
    'which_pages',
    points,
    'No page-level findings in this period. Run a crawl or a validation and the pages that need work are listed here.',
  );
}

/**
 * "Where should attention or budget be reviewed?"
 *
 * SeSha will not tell anyone to move money. It has no spend data, and a
 * recommendation about budget without spend data is a guess wearing a suit. What
 * it can do is point at where a decision is waiting, and say what is missing that
 * would make the decision answerable.
 */
function whereToReview(facts: ReportFacts, metrics: readonly Metric[]): ReportSection {
  const points: ReportPoint[] = [];
  const status = analyticsStatus(facts.connections);

  const adsMetrics = metrics.filter((metric) => METRICS[metric.id].requires === 'ads_account');
  const adsUnavailable = adsMetrics.filter((metric) => metric.value.kind === 'unavailable');
  if (adsUnavailable.length > 0) {
    points.push({
      text: 'Budget cannot be reviewed from SeSha.',
      detail:
        'No advertising account is connected, so spend, cost per result and return are all unknown here. SeSha will not suggest moving money it cannot see. Connect the ads account in Settings, or review the budget in the platform itself.',
    });
  }

  const declined = facts.campaigns.filter((campaign) => campaign.declinedReason !== undefined);
  for (const campaign of declined) {
    points.push({
      text: `${campaign.name} is waiting on a decision.`,
      detail: `The plan was declined in review: ${campaign.declinedReason}. Nothing will happen on it until someone either revises it or closes it.`,
      evidence: [campaign.id],
    });
  }

  const stalled = facts.campaigns.filter(
    (campaign) => campaign.declinedReason === undefined && campaign.done === 0 && campaign.planned > 0,
  );
  for (const campaign of stalled) {
    points.push({
      text: `${campaign.name} has ${campaign.planned} planned entries and nothing completed.`,
      detail: 'Either the plan needs shortening or the work needs scheduling. It will not resolve itself.',
      evidence: [campaign.id],
    });
  }

  if (facts.activity.calendarSkipped > 0 && facts.activity.calendarSkipped >= facts.activity.calendarDone) {
    points.push({
      text: 'The calendar is being skipped more than it is being completed.',
      detail:
        'That is worth an honest look at capacity before adding anything else to it. A plan nobody can execute costs more than a smaller one.',
    });
  }

  if (!status.anyConnected) {
    points.push({
      text: 'Your attention is best spent on the things SeSha can actually measure.',
      detail:
        'With nothing connected, the measurable ground is your pipeline, your crawl findings, your structured data and your content coverage. Everything else in this report is marked unavailable and should be treated as unknown, not as zero.',
    });
  }

  return section(
    'where_to_review',
    points,
    'Nothing is waiting on a decision, and no campaign is stalled.',
  );
}

/* -------------------------------------------------------------------------- */
/* Assembly                                                                   */
/* -------------------------------------------------------------------------- */

export function reportTitle(kind: ReportKind, period: MetricPeriod, organizationName: string): string {
  return `${REPORT_LABEL[kind]} — ${organizationName} — ${period.label}`;
}

export function generateReport(facts: ReportFacts): Report {
  const metrics = selectMetrics(facts);
  const status = analyticsStatus(facts.connections);
  const connected = facts.connections
    .filter((state) => state.connected)
    .map((state) => state.definition.label);

  const sections = orderedSections([
    whatHappened(facts, metrics),
    why(facts, metrics),
    whatNext(facts),
    whichCampaigns(facts),
    whichPages(facts),
    whereToReview(facts, metrics),
  ]);

  return {
    id: facts.id,
    kind: facts.kind,
    title: reportTitle(facts.kind, facts.period, facts.organizationName),
    period: facts.period,
    generatedAt: facts.generatedAt,
    sections,
    metrics,
    provenance: {
      connectedSources: connected,
      anyConnected: status.anyConnected,
      note: status.message,
    },
  };
}

/** The one-line summary shown in a list of reports. */
export function reportSummary(report: Report): string {
  const measured = report.metrics.filter((metric) => hasFigure(metric.value)).length;
  const total = report.metrics.length;
  return `${REPORT_PURPOSE[report.kind]} ${measured} of ${total} figures measured; the rest are marked unavailable.`;
}
