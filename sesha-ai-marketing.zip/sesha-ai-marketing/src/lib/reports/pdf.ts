/**
 * A PDF writer, with no dependencies.
 *
 * WHY WRITE ONE RATHER THAN INSTALL ONE
 * SeSha has four production dependencies and has added none since Phase 1. A
 * PDF library is typically 2–15 MB, pulls a font stack and a canvas shim, and
 * runs untrusted layout code over user-controlled strings. What this product
 * actually needs is black text on white paper in one font family, and the PDF
 * format supports exactly that in about three hundred lines. So this writes the
 * bytes directly: `%PDF-1.7`, a catalogue, a page tree, uncompressed content
 * streams in the standard Helvetica faces, and a cross-reference table.
 *
 * The one genuinely fiddly part is that the cross-reference table stores BYTE
 * OFFSETS. Every object is therefore built as a latin1 string in which no
 * character exceeds 0xFF, which makes the byte offset equal to the string length
 * — `encodeWinAnsi` is what guarantees that, and it is not merely a text tidy-up.
 *
 * WHAT IT DELIBERATELY DOES NOT DO
 * No images, no tables, no compression, no embedded fonts — the fourteen standard
 * faces are built into every reader. A report that needs a chart needs a
 * connected data source first, and it does not have one.
 *
 * Framework-free and fully unit tested.
 */

import { formatValue, hasFigure } from '../analytics/metrics';
import { sourceColumn } from './export';
import type { Report } from './types';

/* -------------------------------------------------------------------------- */
/* Encoding                                                                   */
/* -------------------------------------------------------------------------- */

/**
 * Characters outside Latin-1 that we can represent honestly in WinAnsi.
 *
 * The typographic ones matter because this codebase writes in real prose: en and
 * em dashes, curly quotes, ellipses and the multiplication sign all appear in
 * metric formulas and report text. Turning them into `?` would corrupt sentences
 * whose accuracy is the entire point of the document.
 */
const WIN_ANSI_SUBSTITUTIONS: Readonly<Record<string, string>> = {
  '‘': '',
  '’': '',
  '‚': '',
  '“': '',
  '”': '',
  '„': '',
  '–': '',
  '—': '',
  '…': '',
  '•': '',
  '†': '',
  '‡': '',
  '‰': '',
  '€': '',
  '™': '',
  'Š': '',
  'š': '',
  'Ž': '',
  'ž': '',
  'Œ': '',
  'œ': '',
  'Ÿ': '',
  'ƒ': '',
  'ˆ': '',
  '˜': '',
  '‹': '',
  '›': '',
  // Currency and symbols with no WinAnsi code point: spell them, do not drop them.
  '₹': 'INR ',
  '→': '->',
  '≥': '>=',
  '≤': '<=',
  ' ': ' ',
};

/**
 * Maps a string into WinAnsi, one character per byte.
 *
 * Anything with no representation becomes a question mark rather than
 * disappearing, because a silently dropped character can change what a sentence
 * says while leaving it looking well-formed.
 */
export function encodeWinAnsi(text: string): string {
  let out = '';
  for (const character of text) {
    const substitution = WIN_ANSI_SUBSTITUTIONS[character];
    if (substitution !== undefined) {
      out += substitution;
      continue;
    }
    const code = character.codePointAt(0) ?? 63;
    out += code <= 0xff ? String.fromCharCode(code) : '?';
  }
  return out;
}

/** Escapes a WinAnsi string for a PDF literal string. */
export function escapePdfString(text: string): string {
  return text.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)').replace(/\r/g, '\\r');
}

/**
 * A string for the document information dictionary.
 *
 * NOT the same encoding as the page content, which is the trap here. Text drawn
 * on a page is decoded with the font's encoding — WinAnsi, as declared. A string
 * in the Info dictionary is decoded as PDFDocEncoding, where the WinAnsi byte for
 * an em dash means something else entirely: the report title came out of a reader
 * as "SEO report S Acme Ltd". Caught by extracting the metadata with a real PDF
 * parser rather than by reading the bytes back with our own code, which would
 * have agreed with itself.
 *
 * So anything non-ASCII is written as UTF-16BE with a byte-order mark, which every
 * reader understands and which has no such ambiguity.
 */
export function pdfTextString(text: string): string {
  if (/^[\x20-\x7e]*$/.test(text)) return `(${escapePdfString(text)})`;
  let hex = 'FEFF';
  for (const character of text) {
    const code = character.codePointAt(0) ?? 0x3f;
    if (code > 0xffff) {
      // Outside the basic plane: write the surrogate pair, as UTF-16BE requires.
      const offset = code - 0x10000;
      hex += (0xd800 + (offset >> 10)).toString(16).padStart(4, '0').toUpperCase();
      hex += (0xdc00 + (offset & 0x3ff)).toString(16).padStart(4, '0').toUpperCase();
    } else {
      hex += code.toString(16).padStart(4, '0').toUpperCase();
    }
  }
  return `<${hex}>`;
}

/* -------------------------------------------------------------------------- */
/* Metrics of the standard faces                                              */
/* -------------------------------------------------------------------------- */

export type PdfFace = 'regular' | 'bold' | 'italic';

const FONT_RESOURCE: Readonly<Record<PdfFace, string>> = {
  regular: 'F1',
  bold: 'F2',
  italic: 'F3',
};

const BASE_FONT: Readonly<Record<PdfFace, string>> = {
  regular: 'Helvetica',
  bold: 'Helvetica-Bold',
  italic: 'Helvetica-Oblique',
};

/** Helvetica advance widths for 0x20–0x7E, in 1/1000 em. From the Adobe AFM. */
const HELVETICA_WIDTHS: readonly number[] = [
  278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556,
  556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611,
  778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611,
  278, 278, 278, 469, 556, 333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556,
  556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584,
];

/** Helvetica-Bold advance widths for 0x20–0x7E. */
const HELVETICA_BOLD_WIDTHS: readonly number[] = [
  278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556,
  556, 556, 556, 556, 556, 556, 333, 333, 584, 584, 584, 611, 975, 722, 722, 722, 722, 667, 611, 778,
  722, 278, 556, 722, 611, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333,
  278, 333, 584, 556, 333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611,
  611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584,
];

/**
 * The width of one character, in 1/1000 em.
 *
 * Characters above 0x7E fall back to the width of `n`, which is close enough for
 * the accented Latin letters that actually occur and errs toward wrapping a line
 * early rather than running it off the page.
 */
export function charWidth(character: string, face: PdfFace): number {
  const table = face === 'bold' ? HELVETICA_BOLD_WIDTHS : HELVETICA_WIDTHS;
  const code = character.charCodeAt(0);
  if (code >= 0x20 && code <= 0x7e) return table[code - 0x20] ?? 556;
  if (code < 0x20) return 0;
  return face === 'bold' ? 611 : 556;
}

/** The width of a string at a given size, in points. */
export function textWidth(text: string, face: PdfFace, size: number): number {
  let total = 0;
  for (const character of text) total += charWidth(character, face);
  return (total * size) / 1000;
}

/**
 * Wraps text to a width.
 *
 * Words longer than the line — a URL, usually — are broken rather than allowed to
 * overflow, because a page report lists page URLs and losing half of one makes it
 * useless for the person who has to go and fix that page.
 */
export function wrapText(text: string, face: PdfFace, size: number, maxWidth: number): string[] {
  const lines: string[] = [];
  let current = '';

  const flush = (): void => {
    if (current.length > 0) {
      lines.push(current);
      current = '';
    }
  };

  for (const word of text.split(/\s+/).filter((part) => part.length > 0)) {
    const candidate = current.length === 0 ? word : `${current} ${word}`;
    if (textWidth(candidate, face, size) <= maxWidth) {
      current = candidate;
      continue;
    }
    flush();
    if (textWidth(word, face, size) <= maxWidth) {
      current = word;
      continue;
    }
    let chunk = '';
    for (const character of word) {
      if (textWidth(chunk + character, face, size) > maxWidth && chunk.length > 0) {
        lines.push(chunk);
        chunk = character;
      } else {
        chunk += character;
      }
    }
    current = chunk;
  }
  flush();

  return lines.length > 0 ? lines : [''];
}

/* -------------------------------------------------------------------------- */
/* Layout                                                                     */
/* -------------------------------------------------------------------------- */

export const PAGE_WIDTH = 595;
export const PAGE_HEIGHT = 842;
const MARGIN_X = 56;
const MARGIN_TOP = 64;
const MARGIN_BOTTOM = 64;
const CONTENT_WIDTH = PAGE_WIDTH - MARGIN_X * 2;

interface Line {
  readonly text: string;
  readonly face: PdfFace;
  readonly size: number;
  readonly indent: number;
  /** Space above this line, in points. */
  readonly spaceBefore: number;
  readonly grey?: boolean;
}

interface Block {
  readonly lines: readonly Line[];
  /** Keep with the next block where possible: a heading alone at the foot is ugly. */
  readonly keepWithNext?: boolean;
}

function paragraph(
  text: string,
  face: PdfFace,
  size: number,
  indent: number,
  spaceBefore: number,
  grey = false,
): Line[] {
  const wrapped = wrapText(text, face, size, CONTENT_WIDTH - indent);
  return wrapped.map((line, index) => ({
    text: line,
    face,
    size,
    indent,
    spaceBefore: index === 0 ? spaceBefore : 0,
    grey,
  }));
}

function lineHeight(line: Line): number {
  return line.size * 1.32;
}

/* -------------------------------------------------------------------------- */
/* The report, as blocks                                                      */
/* -------------------------------------------------------------------------- */

function reportBlocks(report: Report): Block[] {
  const blocks: Block[] = [];

  blocks.push({ lines: paragraph(report.title, 'bold', 17, 0, 0) });
  blocks.push({
    lines: paragraph(
      `${report.period.label}  ·  ${report.period.from} to ${report.period.to}  ·  generated ${report.generatedAt}`,
      'regular',
      9,
      0,
      6,
      true,
    ),
  });

  // The honesty banner. First thing on the page, before any figure, because a PDF
  // is read away from the screen that would otherwise have carried the caveat.
  blocks.push({
    lines: [
      ...paragraph(
        report.provenance.anyConnected
          ? `Connected: ${report.provenance.connectedSources.join(', ')}`
          : 'No data source is connected.',
        'bold',
        9.5,
        0,
        16,
      ),
      ...paragraph(report.provenance.note, 'regular', 9.5, 0, 3),
      ...paragraph(
        'Every figure below states where it came from. Figures marked unavailable were not measured — they are not zero.',
        'italic',
        9.5,
        0,
        3,
      ),
    ],
  });

  if (report.metrics.length > 0) {
    blocks.push({ lines: paragraph('Figures', 'bold', 12.5, 0, 22), keepWithNext: true });
    for (const metric of report.metrics) {
      const formatted = formatValue(metric.value);
      const lines: Line[] = [
        ...paragraph(
          formatted === null
            ? `${metric.definition.label}: not measured`
            : `${metric.definition.label}: ${formatted}`,
          'bold',
          10.5,
          0,
          10,
        ),
        ...paragraph(sourceColumn(metric.value), 'regular', 9, 12, 2, true),
      ];
      if (metric.value.kind === 'unavailable') {
        lines.push(...paragraph(metric.value.whatWouldMakeItAvailable, 'italic', 9, 12, 2, true));
      } else if (hasFigure(metric.value)) {
        lines.push(...paragraph(`Read at ${metric.value.asOf}.`, 'italic', 9, 12, 2, true));
      }
      blocks.push({ lines });
    }
  }

  for (const section of report.sections) {
    blocks.push({ lines: paragraph(section.question, 'bold', 12.5, 0, 22), keepWithNext: true });
    if (section.points.length === 0) {
      blocks.push({ lines: paragraph(section.emptyReason ?? 'Nothing to report.', 'italic', 10, 0, 8, true) });
      continue;
    }
    for (const point of section.points) {
      const lines: Line[] = [...paragraph(`• ${point.text}`, 'regular', 10.5, 0, 9)];
      if (point.detail) lines.push(...paragraph(point.detail, 'regular', 9.5, 14, 2, true));
      if (point.evidence && point.evidence.length > 0) {
        lines.push(...paragraph(`From: ${point.evidence.join(', ')}`, 'italic', 8.5, 14, 2, true));
      }
      blocks.push({ lines });
    }
  }

  return blocks;
}

/** Breaks blocks into pages. */
function paginate(blocks: readonly Block[]): Line[][] {
  const pages: Line[][] = [];
  let page: Line[] = [];
  let y = MARGIN_TOP;
  const limit = PAGE_HEIGHT - MARGIN_BOTTOM;

  const blockHeight = (block: Block): number =>
    block.lines.reduce((total, line) => total + line.spaceBefore + lineHeight(line), 0);

  for (let index = 0; index < blocks.length; index += 1) {
    const block = blocks[index]!;
    let needed = blockHeight(block);
    if (block.keepWithNext && index + 1 < blocks.length) {
      // Enough room for the heading plus the first line of what follows, or move
      // the whole thing to the next page.
      const next = blocks[index + 1]!;
      const firstLine = next.lines[0];
      if (firstLine) needed += firstLine.spaceBefore + lineHeight(firstLine);
    }
    if (y + needed > limit && page.length > 0) {
      pages.push(page);
      page = [];
      y = MARGIN_TOP;
    }
    for (const line of block.lines) {
      const height = line.spaceBefore + lineHeight(line);
      if (y + height > limit && page.length > 0) {
        pages.push(page);
        page = [];
        y = MARGIN_TOP;
        page.push({ ...line, spaceBefore: 0 });
        y += lineHeight(line);
        continue;
      }
      page.push(line);
      y += height;
    }
  }

  if (page.length > 0) pages.push(page);
  return pages.length > 0 ? pages : [[]];
}

/* -------------------------------------------------------------------------- */
/* Content streams                                                            */
/* -------------------------------------------------------------------------- */

function contentStream(lines: readonly Line[], pageNumber: number, pageCount: number, footer: string): string {
  const parts: string[] = [];
  let y = MARGIN_TOP;

  for (const line of lines) {
    y += line.spaceBefore + line.size;
    const text = escapePdfString(encodeWinAnsi(line.text));
    const grey = line.grey ? '0.35 0.35 0.35 rg' : '0 0 0 rg';
    parts.push(
      `BT ${grey} /${FONT_RESOURCE[line.face]} ${line.size} Tf 1 0 0 1 ${MARGIN_X + line.indent} ${
        Math.round((PAGE_HEIGHT - y) * 100) / 100
      } Tm (${text}) Tj ET`,
    );
    y += lineHeight(line) - line.size;
  }

  const footerY = MARGIN_BOTTOM - 28;
  const label = escapePdfString(encodeWinAnsi(footer));
  const pageLabel = escapePdfString(encodeWinAnsi(`Page ${pageNumber} of ${pageCount}`));
  const pageLabelWidth = textWidth(`Page ${pageNumber} of ${pageCount}`, 'regular', 8);
  parts.push(
    `BT 0.45 0.45 0.45 rg /F1 8 Tf 1 0 0 1 ${MARGIN_X} ${footerY} Tm (${label}) Tj ET`,
    `BT 0.45 0.45 0.45 rg /F1 8 Tf 1 0 0 1 ${
      Math.round((PAGE_WIDTH - MARGIN_X - pageLabelWidth) * 100) / 100
    } ${footerY} Tm (${pageLabel}) Tj ET`,
  );

  return parts.join('\n');
}

/* -------------------------------------------------------------------------- */
/* The document                                                               */
/* -------------------------------------------------------------------------- */

function pdfDate(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';
  const pad = (value: number): string => String(value).padStart(2, '0');
  return `D:${date.getUTCFullYear()}${pad(date.getUTCMonth() + 1)}${pad(date.getUTCDate())}${pad(
    date.getUTCHours(),
  )}${pad(date.getUTCMinutes())}${pad(date.getUTCSeconds())}Z`;
}

/**
 * Renders a report as a PDF document, returned as a latin1 string.
 *
 * Kept as a string rather than bytes so the offsets in the cross-reference table
 * can be computed as string lengths, and so tests can read the structure without
 * decoding. `toPdfBytes` is the byte-level entry point.
 */
export function renderPdf(report: Report): string {
  const pages = paginate(reportBlocks(report));
  const footer = `SeSha  ·  ${report.title}`;

  const objects: string[] = [];
  const push = (body: string): number => {
    objects.push(body);
    return objects.length; // object numbers are 1-based
  };

  // Reserve 1 (catalog) and 2 (pages) so the page objects can reference the tree.
  objects.push('', '');

  const fontIds: Record<PdfFace, number> = {
    regular: push(`<< /Type /Font /Subtype /Type1 /BaseFont /${BASE_FONT.regular} /Encoding /WinAnsiEncoding >>`),
    bold: push(`<< /Type /Font /Subtype /Type1 /BaseFont /${BASE_FONT.bold} /Encoding /WinAnsiEncoding >>`),
    italic: push(`<< /Type /Font /Subtype /Type1 /BaseFont /${BASE_FONT.italic} /Encoding /WinAnsiEncoding >>`),
  };

  const resources = `<< /Font << /F1 ${fontIds.regular} 0 R /F2 ${fontIds.bold} 0 R /F3 ${fontIds.italic} 0 R >> >>`;

  const pageIds: number[] = [];
  pages.forEach((lines, index) => {
    const stream = contentStream(lines, index + 1, pages.length, footer);
    const encoded = encodeWinAnsi(stream);
    const contentId = push(`<< /Length ${encoded.length} >>\nstream\n${encoded}\nendstream`);
    pageIds.push(
      push(
        `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_WIDTH} ${PAGE_HEIGHT}] /Resources ${resources} /Contents ${contentId} 0 R >>`,
      ),
    );
  });

  const infoId = push(
    `<< /Title ${pdfTextString(report.title)} /Producer (SeSha) /Creator (SeSha) /CreationDate (${pdfDate(
      report.generatedAt,
    )}) >>`,
  );

  objects[0] = '<< /Type /Catalog /Pages 2 0 R >>';
  objects[1] = `<< /Type /Pages /Kids [${pageIds.map((id) => `${id} 0 R`).join(' ')}] /Count ${pageIds.length} >>`;

  let pdf = '%PDF-1.7\n%âãÏÓ\n';
  const offsets: number[] = [];
  objects.forEach((body, index) => {
    offsets.push(pdf.length);
    pdf += `${index + 1} 0 obj\n${body}\nendobj\n`;
  });

  const xrefOffset = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (const offset of offsets) {
    pdf += `${String(offset).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R /Info ${infoId} 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;

  return pdf;
}

/** The PDF as bytes, ready to be sent as a response body. */
export function toPdfBytes(report: Report): Uint8Array {
  const pdf = renderPdf(report);
  const bytes = new Uint8Array(pdf.length);
  for (let index = 0; index < pdf.length; index += 1) {
    bytes[index] = pdf.charCodeAt(index) & 0xff;
  }
  return bytes;
}
