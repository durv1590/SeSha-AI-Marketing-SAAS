/**
 * Exporting a report: CSV and JSON.
 *
 * (PDF is its own file, because writing one without a library is a hundred lines
 * of byte counting that has no business next to the CSV escaper.)
 *
 * THE RULE THAT GOVERNS EVERY FORMAT
 * A number leaves SeSha with its provenance attached. In JSON that is the
 * `MetricValue` union, unchanged. In CSV it is two extra columns — `source` and
 * `as_of` — that cannot be omitted, because a CSV of bare figures opened in a
 * spreadsheet six months later is indistinguishable from measured data, and
 * someone will paste it into a board pack.
 *
 * An unavailable metric exports as a ROW, with an empty value and the reason in
 * the source column. Dropping it would let a reader count the rows and conclude
 * the missing metrics were zero.
 *
 * Framework-free and fully unit tested.
 */

import { SOURCE_LABEL, formatValue, hasFigure, type Metric, type MetricValue } from '../analytics/metrics';
import { SECTION_QUESTION, type Report } from './types';

export const EXPORT_FORMATS = ['pdf', 'csv', 'json'] as const;
export type ExportFormat = (typeof EXPORT_FORMATS)[number];

export const EXPORT_MIME: Readonly<Record<ExportFormat, string>> = {
  pdf: 'application/pdf',
  csv: 'text/csv; charset=utf-8',
  json: 'application/json; charset=utf-8',
};

export function isExportFormat(value: unknown): value is ExportFormat {
  return typeof value === 'string' && (EXPORT_FORMATS as readonly string[]).includes(value);
}

export function exportFilename(report: Report, format: ExportFormat): string {
  const slug = report.title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
  return `${slug || 'report'}.${format}`;
}

/* -------------------------------------------------------------------------- */
/* JSON                                                                       */
/* -------------------------------------------------------------------------- */

/**
 * The report as JSON.
 *
 * The `MetricValue` union goes across unchanged, so a consumer parsing this gets
 * the discriminator and cannot read a figure without seeing its kind. A flattened
 * `{ metric: value }` shape would be friendlier and would throw away the only
 * thing that makes these numbers safe to use.
 */
export function toJson(report: Report): string {
  return JSON.stringify(
    {
      schema: 'sesha.report.v1',
      id: report.id,
      kind: report.kind,
      title: report.title,
      period: report.period,
      generatedAt: report.generatedAt,
      provenance: report.provenance,
      metrics: report.metrics.map((metric) => ({
        id: metric.id,
        label: metric.definition.label,
        unit: metric.definition.unit,
        value: metric.value,
        ...(metric.previous ? { previous: metric.previous } : {}),
      })),
      sections: report.sections.map((section) => ({
        id: section.id,
        question: section.question,
        points: section.points.map((point) => ({
          text: point.text,
          ...(point.detail ? { detail: point.detail } : {}),
          ...(point.evidence ? { evidence: point.evidence } : {}),
          ...(point.metric ? { metricId: point.metric.id } : {}),
        })),
        ...(section.emptyReason ? { emptyReason: section.emptyReason } : {}),
      })),
    },
    null,
    2,
  );
}

/* -------------------------------------------------------------------------- */
/* CSV                                                                        */
/* -------------------------------------------------------------------------- */

/**
 * Escapes one CSV field.
 *
 * The leading-character guard is deliberate. A value beginning with `=`, `+`, `-`
 * or `@` is executed as a formula by Excel and Sheets when the file is opened,
 * which turns an exported report into a way of running something on the reader's
 * machine. Prefixing with an apostrophe is the standard defence and costs nothing
 * — none of our own values legitimately start with those characters, but a lead's
 * name or a page title is user-controlled and this is an export of user data.
 */
export function csvField(value: string): string {
  const guarded = /^[=+\-@\t\r]/.test(value) ? `'${value}` : value;
  return /[",\n\r]/.test(guarded) ? `"${guarded.replace(/"/g, '""')}"` : guarded;
}

export function csvRow(fields: readonly string[]): string {
  return fields.map(csvField).join(',');
}

/** The source column for a value: the label, plus the reason when there is none. */
export function sourceColumn(value: MetricValue): string {
  switch (value.kind) {
    case 'connected_api':
      return `${SOURCE_LABEL.connected_api} (${value.source})`;
    case 'user_provided':
      return `${SOURCE_LABEL.user_provided} (${value.enteredBy})`;
    case 'retrieved':
      return `${SOURCE_LABEL.retrieved} (${value.sourceUrl})`;
    case 'calculated':
      return `${SOURCE_LABEL.calculated}: ${value.formula}`;
    case 'ai_estimate':
      return `${SOURCE_LABEL.ai_estimate} (${value.band.replace('_', ' ')}) — ${value.basis}`;
    case 'unavailable':
      return `${SOURCE_LABEL.unavailable}: ${value.why}`;
  }
}

function asOfColumn(value: MetricValue): string {
  return hasFigure(value) ? value.asOf : '';
}

export const METRIC_CSV_HEADER: readonly string[] = [
  'metric',
  'value',
  'unit',
  'source',
  'as_of',
  'previous_value',
  'change',
];

export function metricsCsv(metrics: readonly Metric[]): string {
  const lines = [csvRow(METRIC_CSV_HEADER)];
  for (const metric of metrics) {
    const formatted = formatValue(metric.value);
    const previous = metric.previous ? formatValue(metric.previous) : null;
    lines.push(
      csvRow([
        metric.definition.label,
        formatted ?? '',
        metric.definition.unit,
        sourceColumn(metric.value),
        asOfColumn(metric.value),
        previous ?? '',
        previous !== null && formatted !== null && hasFigure(metric.value) && metric.previous && hasFigure(metric.previous)
          ? String(Math.round((metric.value.value - metric.previous.value) * 100) / 100)
          : '',
      ]),
    );
  }
  return lines.join('\r\n');
}

/**
 * The whole report as CSV.
 *
 * Two tables in one file, separated by a blank line and a heading row: the
 * metrics, then the narrative. A spreadsheet opens it happily, and a reader gets
 * the caveats in the same file as the figures rather than in a covering email
 * nobody forwards.
 */
export function toCsv(report: Report): string {
  const lines: string[] = [];

  lines.push(csvRow(['SeSha report', report.title]));
  lines.push(csvRow(['Period', `${report.period.from} to ${report.period.to}`]));
  lines.push(csvRow(['Generated', report.generatedAt]));
  lines.push(
    csvRow([
      'Connected sources',
      report.provenance.anyConnected ? report.provenance.connectedSources.join('; ') : 'None',
    ]),
  );
  lines.push(csvRow(['Note', report.provenance.note]));
  lines.push('');

  lines.push(csvRow(['METRICS']));
  lines.push(metricsCsv(report.metrics));
  lines.push('');

  lines.push(csvRow(['NARRATIVE']));
  lines.push(csvRow(['question', 'point', 'detail', 'evidence']));
  for (const section of report.sections) {
    if (section.points.length === 0) {
      lines.push(csvRow([SECTION_QUESTION[section.id], '', section.emptyReason ?? '', '']));
      continue;
    }
    for (const point of section.points) {
      lines.push(
        csvRow([
          SECTION_QUESTION[section.id],
          point.text,
          point.detail ?? '',
          point.evidence ? point.evidence.join('; ') : '',
        ]),
      );
    }
  }

  return lines.join('\r\n');
}
