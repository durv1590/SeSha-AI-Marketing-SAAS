import type { Metadata } from 'next';

import { site } from '@/content/site';
import { buildSeo, type SeoInput } from './core';

/**
 * Adapter: framework-free SEO payload -> Next.js Metadata.
 * Every page exports `metadata` (or `generateMetadata`) built through here so
 * titles, canonicals, OG and Twitter tags stay consistent site-wide.
 */
export function buildMetadata(input: SeoInput): Metadata {
  const seo = buildSeo(input);

  return {
    title: seo.title,
    description: seo.description,
    metadataBase: new URL(site.url),
    alternates: { canonical: seo.canonical },
    robots: {
      index: seo.robots.index,
      follow: seo.robots.follow,
      googleBot: {
        index: seo.robots.index,
        follow: seo.robots.follow,
        'max-image-preview': 'large',
        'max-snippet': -1,
        'max-video-preview': -1,
      },
    },
    openGraph: {
      type: seo.openGraph.type,
      url: seo.openGraph.url,
      title: seo.openGraph.title,
      description: seo.openGraph.description,
      siteName: seo.openGraph.siteName,
      locale: seo.openGraph.locale,
      images: seo.openGraph.images.map((image) => ({
        url: image.url,
        alt: image.alt,
        width: image.width,
        height: image.height,
      })),
      ...(seo.openGraph.publishedTime ? { publishedTime: seo.openGraph.publishedTime } : {}),
      ...(seo.openGraph.modifiedTime ? { modifiedTime: seo.openGraph.modifiedTime } : {}),
      ...(seo.openGraph.authors ? { authors: [...seo.openGraph.authors] } : {}),
    },
    twitter: {
      card: seo.twitter.card,
      title: seo.twitter.title,
      description: seo.twitter.description,
      images: [...seo.twitter.images],
      ...(seo.twitter.site ? { site: seo.twitter.site } : {}),
    },
    ...(seo.keywords ? { keywords: [...seo.keywords] } : {}),
  };
}

export type { SeoInput } from './core';
