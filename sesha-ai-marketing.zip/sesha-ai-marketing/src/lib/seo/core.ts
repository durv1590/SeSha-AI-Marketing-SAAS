/**
 * Framework-free SEO primitives.
 *
 * This module intentionally has ZERO Next.js imports so it can be unit tested
 * in isolation. `metadata.ts` adapts the output of these functions into the
 * Next.js `Metadata` shape.
 */

import { site, organization } from '@/content/site';
import { normalizePath } from '@/lib/routes';

export const TITLE_MAX = 60;
export const DESCRIPTION_MIN = 70;
export const DESCRIPTION_MAX = 160;

export interface SeoInput {
  /** Page title WITHOUT the brand suffix. */
  readonly title: string;
  readonly description: string;
  /** Site-relative path, e.g. "/pricing". */
  readonly path: string;
  /** Relative or absolute image URL. Defaults to the site OG image. */
  readonly image?: string;
  readonly imageAlt?: string;
  readonly type?: 'website' | 'article';
  readonly noindex?: boolean;
  readonly publishedTime?: string;
  readonly modifiedTime?: string;
  readonly authorName?: string;
  readonly keywords?: readonly string[];
}

export interface SeoOutput {
  readonly title: string;
  readonly description: string;
  readonly canonical: string;
  readonly robots: { readonly index: boolean; readonly follow: boolean };
  readonly openGraph: {
    readonly type: 'website' | 'article';
    readonly url: string;
    readonly title: string;
    readonly description: string;
    readonly siteName: string;
    readonly locale: string;
    readonly images: readonly { url: string; alt: string; width: number; height: number }[];
    readonly publishedTime?: string;
    readonly modifiedTime?: string;
    readonly authors?: readonly string[];
  };
  readonly twitter: {
    readonly card: 'summary_large_image';
    readonly title: string;
    readonly description: string;
    readonly images: readonly string[];
    readonly site?: string;
  };
  readonly keywords?: readonly string[];
}

/** Joins the site origin and a site-relative path into an absolute URL. */
export function absoluteUrl(path: string): string {
  if (/^https?:\/\//i.test(path)) return path;
  const normalized = path.startsWith('/') ? path : `/${path}`;
  if (normalized === '/') return `${site.url}/`;
  return `${site.url}${normalizePath(normalized)}`;
}

/**
 * Canonical URL for a page. Query strings and fragments are always stripped —
 * a canonical must point at one stable resource.
 */
export function canonicalUrl(path: string): string {
  return absoluteUrl(path);
}

/** Appends the brand suffix unless the title already carries it. */
export function formatTitle(title: string): string {
  const trimmed = title.trim();
  if (trimmed.length === 0) return site.name;
  if (trimmed.toLowerCase().includes(site.shortName.toLowerCase())) return trimmed;
  return `${trimmed} | ${site.shortName}`;
}

export function buildSeo(input: SeoInput): SeoOutput {
  const title = formatTitle(input.title);
  const description = input.description.trim();
  const canonical = canonicalUrl(input.path);
  const image = absoluteUrl(input.image ?? site.defaultOgImage);
  const imageAlt = input.imageAlt ?? `${site.name} — ${input.title}`;
  const type = input.type ?? 'website';

  return {
    title,
    description,
    canonical,
    robots: { index: !input.noindex, follow: !input.noindex },
    openGraph: {
      type,
      url: canonical,
      title,
      description,
      siteName: site.name,
      locale: site.locale,
      images: [{ url: image, alt: imageAlt, width: 1200, height: 630 }],
      ...(input.publishedTime ? { publishedTime: input.publishedTime } : {}),
      ...(input.modifiedTime ? { modifiedTime: input.modifiedTime } : {}),
      ...(input.authorName ? { authors: [input.authorName] } : {}),
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: [image],
      ...(site.twitterHandle ? { site: site.twitterHandle } : {}),
    },
    ...(input.keywords && input.keywords.length > 0 ? { keywords: input.keywords } : {}),
  };
}

export interface SeoIssue {
  readonly field: string;
  readonly severity: 'error' | 'warning';
  readonly message: string;
}

/**
 * Lints an SEO payload. Used by the metadata unit tests so that a page with a
 * truncated title or a missing description fails CI rather than shipping.
 */
export function lintSeo(input: SeoInput): SeoIssue[] {
  const issues: SeoIssue[] = [];
  const fullTitle = formatTitle(input.title);

  if (input.title.trim().length === 0) {
    issues.push({ field: 'title', severity: 'error', message: 'Title is empty.' });
  }
  if (fullTitle.length > TITLE_MAX) {
    issues.push({
      field: 'title',
      severity: 'warning',
      message: `Rendered title is ${fullTitle.length} chars (soft limit ${TITLE_MAX}).`,
    });
  }
  const description = input.description.trim();
  if (description.length === 0) {
    issues.push({ field: 'description', severity: 'error', message: 'Description is empty.' });
  } else if (description.length < DESCRIPTION_MIN) {
    issues.push({
      field: 'description',
      severity: 'warning',
      message: `Description is ${description.length} chars (below ${DESCRIPTION_MIN}).`,
    });
  } else if (description.length > DESCRIPTION_MAX) {
    issues.push({
      field: 'description',
      severity: 'error',
      message: `Description is ${description.length} chars (above ${DESCRIPTION_MAX}).`,
    });
  }
  if (!input.path.startsWith('/')) {
    issues.push({
      field: 'path',
      severity: 'error',
      message: 'Path must be site-relative and start with "/".',
    });
  }
  if (input.type === 'article' && !input.publishedTime) {
    issues.push({
      field: 'publishedTime',
      severity: 'warning',
      message: 'Article pages should declare a published time.',
    });
  }
  return issues;
}

export const seoDefaults = {
  siteName: site.name,
  organizationName: organization.legalName,
} as const;
