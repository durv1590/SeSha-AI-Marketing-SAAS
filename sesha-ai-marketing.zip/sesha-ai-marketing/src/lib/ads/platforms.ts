/**
 * Ad platform specifications.
 *
 * WHY THE LIMITS ARE DATA AND NOT PROMPT TEXT
 * The same reason as the social platform specs in Phase 3: a character limit that
 * exists only as a sentence in a prompt is a suggestion. Here it is a number the
 * validator enforces before anything is saved, so a Google headline cannot be
 * stored at 45 characters and discovered at upload time.
 *
 * WHY THE LIMITS CARRY A DATE
 * Ad platforms change their formats. These values are what the platforms'
 * published specifications said as of `AD_SPECS_AS_OF`, and the interface shows
 * that date next to the counters. A limit presented as timeless is wrong within a
 * year and the user only finds out when an upload is rejected.
 *
 * WHAT THIS MODULE DOES NOT DO
 * Nothing here connects to an ad account, reads performance, or spends money. No
 * platform API is connected in this phase — `adsDataStatus()` is the single place
 * that says so, and every screen reads it rather than claiming otherwise.
 *
 * Framework-free and fully unit tested.
 */

export const AD_SPECS_AS_OF = '2026-05';

export const AD_PLATFORMS = ['google_ads', 'meta', 'instagram', 'linkedin', 'youtube'] as const;
export type AdPlatform = (typeof AD_PLATFORMS)[number];

/**
 * Campaign objectives.
 *
 * Each platform's own vocabulary, not a harmonised invention: a user who picks
 * "Leads" here and sees a different word in Google Ads has been given a
 * translation problem instead of a plan.
 */
export const CAMPAIGN_OBJECTIVES = [
  'awareness',
  'traffic',
  'engagement',
  'leads',
  'sales',
  'app_installs',
  'video_views',
  'store_visits',
] as const;
export type CampaignObjective = (typeof CAMPAIGN_OBJECTIVES)[number];

export const OBJECTIVE_LABEL: Readonly<Record<CampaignObjective, string>> = {
  awareness: 'Awareness',
  traffic: 'Traffic',
  engagement: 'Engagement',
  leads: 'Leads',
  sales: 'Sales',
  app_installs: 'App installs',
  video_views: 'Video views',
  store_visits: 'Store visits',
};

export interface TextFieldSpec {
  readonly label: string;
  readonly maxCharacters: number;
  /** How many the format accepts. */
  readonly min: number;
  readonly max: number;
  /** What the field is for, in the platform's own terms. */
  readonly note: string;
}

export interface AdPlatformSpec {
  readonly id: AdPlatform;
  readonly label: string;
  /** The ad format these limits describe. Named, because limits are per format. */
  readonly format: string;
  readonly objectives: readonly CampaignObjective[];
  readonly headline: TextFieldSpec;
  readonly description: TextFieldSpec;
  /** Optional extra field, where the format has one. */
  readonly primaryText?: TextFieldSpec;
  /** Whether the platform's own UI supplies the call to action from a list. */
  readonly ctaFromList: boolean;
  readonly ctaOptions: readonly string[];
  readonly creativeNote: string;
  /** True only when SeSha can actually talk to the platform. */
  readonly canPublish: false;
}

export const AD_PLATFORM_SPECS: Readonly<Record<AdPlatform, AdPlatformSpec>> = {
  google_ads: {
    id: 'google_ads',
    label: 'Google Ads',
    format: 'Responsive search ad',
    objectives: ['sales', 'leads', 'traffic', 'awareness', 'app_installs', 'store_visits'],
    headline: {
      label: 'Headline',
      maxCharacters: 30,
      min: 3,
      max: 15,
      note: 'Google assembles up to three of these per impression, in an order it chooses — so each one has to make sense on its own.',
    },
    description: {
      label: 'Description',
      maxCharacters: 90,
      min: 2,
      max: 4,
      note: 'Two are usually shown. Write the two strongest first, but do not rely on order.',
    },
    ctaFromList: false,
    ctaOptions: [],
    creativeNote:
      'A search ad has no image. The creative work is the wording and the match between the query, the ad and the landing page.',
    canPublish: false,
  },
  meta: {
    id: 'meta',
    label: 'Meta (Facebook)',
    format: 'Single image or video ad',
    objectives: ['awareness', 'traffic', 'engagement', 'leads', 'sales', 'app_installs', 'video_views'],
    headline: {
      label: 'Headline',
      maxCharacters: 40,
      min: 1,
      max: 5,
      note: 'Shown under the image in bold. Truncated hard on mobile, so the point goes first.',
    },
    description: {
      label: 'Link description',
      maxCharacters: 30,
      min: 0,
      max: 5,
      note: 'Often not shown at all, depending on placement. Never put something essential only here.',
    },
    primaryText: {
      label: 'Primary text',
      maxCharacters: 125,
      min: 1,
      max: 5,
      note: 'Longer text is allowed but is collapsed behind "See more" at around 125 characters on most placements.',
    },
    ctaFromList: true,
    ctaOptions: ['Learn more', 'Shop now', 'Sign up', 'Book now', 'Get quote', 'Contact us', 'Send message', 'Download'],
    creativeNote:
      'One image at 1:1 or 4:5 for feed. Text inside the image reduces delivery on some placements.',
    canPublish: false,
  },
  instagram: {
    id: 'instagram',
    label: 'Instagram',
    format: 'Feed or Reels ad',
    objectives: ['awareness', 'traffic', 'engagement', 'leads', 'sales', 'video_views'],
    headline: {
      label: 'Headline',
      maxCharacters: 40,
      min: 1,
      max: 5,
      note: 'Used on some placements only. Instagram leans on the caption and the creative.',
    },
    description: {
      label: 'Link description',
      maxCharacters: 30,
      min: 0,
      max: 3,
      note: 'Rarely displayed on Instagram placements.',
    },
    primaryText: {
      label: 'Caption',
      maxCharacters: 125,
      min: 1,
      max: 5,
      note: 'Hard limit is far higher, but only about 125 characters show before "more".',
    },
    ctaFromList: true,
    ctaOptions: ['Learn more', 'Shop now', 'Sign up', 'Book now', 'Send message', 'View menu'],
    creativeNote:
      '4:5 for feed, 9:16 full-screen for Reels and Stories. Keep text and logos clear of the top and bottom 14% where the interface sits.',
    canPublish: false,
  },
  linkedin: {
    id: 'linkedin',
    label: 'LinkedIn',
    format: 'Sponsored content, single image',
    objectives: ['awareness', 'traffic', 'engagement', 'leads', 'video_views'],
    headline: {
      label: 'Headline',
      maxCharacters: 70,
      min: 1,
      max: 3,
      note: 'Longer headlines are accepted but truncate; 70 characters is what shows reliably.',
    },
    description: {
      label: 'Description',
      maxCharacters: 70,
      min: 0,
      max: 3,
      note: 'Shown on some placements only.',
    },
    primaryText: {
      label: 'Introductory text',
      maxCharacters: 150,
      min: 1,
      max: 3,
      note: 'Up to 600 characters are accepted; about 150 show before "see more" on desktop.',
    },
    ctaFromList: true,
    ctaOptions: ['Learn more', 'Register', 'Download', 'Sign up', 'Request demo', 'Subscribe', 'Apply now'],
    creativeNote:
      '1200×627 for a single image. A professional audience reads the intro text, so it carries more weight here than on other platforms.',
    canPublish: false,
  },
  youtube: {
    id: 'youtube',
    label: 'YouTube',
    format: 'Video ad (in-stream and in-feed)',
    objectives: ['awareness', 'video_views', 'traffic', 'leads', 'sales', 'app_installs'],
    headline: {
      label: 'Headline',
      maxCharacters: 15,
      min: 1,
      max: 5,
      note: 'In-feed headlines are very short — 15 characters. A longer 90-character headline is used for some formats.',
    },
    description: {
      label: 'Description',
      maxCharacters: 70,
      min: 1,
      max: 4,
      note: 'Two lines of 70 characters on in-feed placements.',
    },
    ctaFromList: true,
    ctaOptions: ['Learn more', 'Watch now', 'Subscribe', 'Shop now', 'Sign up', 'Book now'],
    creativeNote:
      'The video itself is the ad. The first five seconds decide whether a skippable in-stream ad is watched at all.',
    canPublish: false,
  },
};

export function adPlatformSpec(platform: AdPlatform): AdPlatformSpec {
  return AD_PLATFORM_SPECS[platform];
}

export function isAdPlatform(value: unknown): value is AdPlatform {
  return typeof value === 'string' && (AD_PLATFORMS as readonly string[]).includes(value);
}

export function isCampaignObjective(value: unknown): value is CampaignObjective {
  return typeof value === 'string' && (CAMPAIGN_OBJECTIVES as readonly string[]).includes(value);
}

/**
 * Whether SeSha can reach any ad platform. It cannot.
 *
 * The single source of truth, exactly like `publishingStatus()` for social in
 * Phase 3. Every ads screen reads this, so there is one place to change when an
 * API is genuinely connected and no screen can drift into implying otherwise.
 */
export function adsDataStatus(): {
  readonly connected: false;
  readonly canPublish: false;
  readonly canReadPerformance: false;
  readonly message: string;
} {
  return {
    connected: false,
    canPublish: false,
    canReadPerformance: false,
    message:
      'No ad account is connected. SeSha cannot create campaigns, spend money or read performance data — everything here is a plan you take to the platform yourself. Any figure on this screen is a recommendation, not a measurement.',
  };
}
