/**
 * An advertising plan: what you would take to the platform, not what ran.
 *
 * THE SEPARATION THE BRIEF ASKS FOR
 * "Separate AI recommendations from live data." There is no live data in this
 * phase — no ad account is connected — so the honest implementation is not a
 * column labelled "live data (empty)", it is a type that cannot hold a
 * measurement at all:
 *
 *  · `BudgetRecommendation` has NO variant carrying observed cost-per-click,
 *    conversion rate or spend. It holds a suggested range, the reasoning, and
 *    what it would take to replace the suggestion with a measurement.
 *  · `performanceStatus()` is the one place that says no data exists.
 *
 * This mirrors `SearchVolume` in Phase 4: the way to keep a number honest is to
 * make the dishonest version unrepresentable rather than to police it.
 *
 * Framework-free and fully unit tested.
 */

import {
  adPlatformSpec,
  type AdPlatform,
  type CampaignObjective,
  type TextFieldSpec,
} from './platforms';

export type ReviewState = 'draft' | 'in_review' | 'approved';

/** Who the campaign is for, in the user's own words plus structured hints. */
export interface AudienceBrief {
  /** Free text the user wrote. Never generated over the top of it. */
  readonly description: string;
  readonly locations: readonly string[];
  readonly languages: readonly string[];
  /** Interests or keywords to target, as the user or the model suggested. */
  readonly signals: readonly string[];
  /** Who to exclude. Often the more valuable half. */
  readonly exclusions: readonly string[];
}

export interface CreativeConcept {
  readonly title: string;
  /** What the viewer sees, described in words. */
  readonly visual: string;
  /** The single idea the concept is built on. */
  readonly angle: string;
  /**
   * Whether an image exists. Always false until an image-generation API is
   * connected: a concept is a description, not a picture.
   */
  readonly imageGenerated: false;
}

export interface AbIdea {
  /** What is being varied. One variable per test, or the result means nothing. */
  readonly variable: 'headline' | 'primary_text' | 'creative' | 'cta' | 'audience' | 'landing_page';
  readonly a: string;
  readonly b: string;
  /** The question the test answers. */
  readonly hypothesis: string;
  /**
   * How to read the result. Included because an A/B test run without a stopping
   * rule is a coin flip with extra steps.
   */
  readonly howToJudge: string;
}

/**
 * A budget suggestion.
 *
 * There is deliberately no `measured` variant. When an ad account is connected,
 * this type gains one — and it will demand a source and a date, exactly as
 * `SearchVolume` does.
 */
export interface BudgetRecommendation {
  readonly kind: 'ai_recommendation';
  readonly label: 'Recommendation, not a measurement';
  readonly currency: string;
  readonly dailyMin: number;
  readonly dailyMax: number;
  /** Why this range. Names the reasoning, not a benchmark we do not have. */
  readonly basis: string;
  /** What would make this a measurement instead of a suggestion. */
  readonly toMeasure: string;
}

export interface LandingPagePlan {
  readonly url: string;
  /** What must be true of the page for the ad to convert. */
  readonly mustMatch: readonly string[];
  /** Problems found by looking at the URL alone, where any. */
  readonly notes: readonly string[];
}

export interface AdPlan {
  readonly platform: AdPlatform;
  readonly objective: CampaignObjective;
  readonly campaignName: string;
  readonly audience: AudienceBrief;
  readonly headlines: readonly string[];
  readonly descriptions: readonly string[];
  readonly primaryText: readonly string[];
  readonly cta: string;
  readonly creativeConcepts: readonly CreativeConcept[];
  readonly landingPage: LandingPagePlan;
  readonly abIdeas: readonly AbIdea[];
  readonly budget: BudgetRecommendation;
  readonly reviewState: ReviewState;
}

export interface PlanProblem {
  readonly severity: 'error' | 'warning';
  readonly field: string;
  readonly message: string;
}

/**
 * Validates a plan against the platform's published limits.
 *
 * Errors block saving as approved; warnings do not. The distinction matters: a
 * headline one character over the limit will be rejected by the platform, which
 * is an error. A headline that repeats the brand name in every variant is a
 * warning — wasteful, not broken.
 */
export function checkAdPlan(plan: AdPlan): readonly PlanProblem[] {
  const spec = adPlatformSpec(plan.platform);
  const problems: PlanProblem[] = [];

  if (plan.campaignName.trim().length === 0) {
    problems.push({ severity: 'error', field: 'campaignName', message: 'The campaign needs a name.' });
  }

  if (!spec.objectives.includes(plan.objective)) {
    problems.push({
      severity: 'error',
      field: 'objective',
      message: `${spec.label} does not offer a "${plan.objective}" objective for a ${spec.format}.`,
    });
  }

  checkField(problems, 'headlines', plan.headlines, spec.headline);
  checkField(problems, 'descriptions', plan.descriptions, spec.description);
  if (spec.primaryText) {
    checkField(problems, 'primaryText', plan.primaryText, spec.primaryText);
  } else if (plan.primaryText.length > 0) {
    problems.push({
      severity: 'warning',
      field: 'primaryText',
      message: `A ${spec.format} has no primary text field, so this will not appear anywhere.`,
    });
  }

  if (spec.ctaFromList && plan.cta.trim().length > 0 && !spec.ctaOptions.includes(plan.cta)) {
    problems.push({
      severity: 'error',
      field: 'cta',
      message: `${spec.label} only accepts a call to action from its own list: ${spec.ctaOptions.join(', ')}.`,
    });
  }

  if (plan.audience.description.trim().length < 20) {
    problems.push({
      severity: 'warning',
      field: 'audience',
      message: 'The audience is described in fewer than twenty characters, which is not enough to build targeting from.',
    });
  }

  if (plan.landingPage.url.trim().length === 0) {
    problems.push({
      severity: 'error',
      field: 'landingPage',
      message: 'An ad needs somewhere to send people.',
    });
  } else if (!/^https:\/\//i.test(plan.landingPage.url.trim())) {
    problems.push({
      severity: /^http:\/\//i.test(plan.landingPage.url.trim()) ? 'warning' : 'error',
      field: 'landingPage',
      message: /^http:\/\//i.test(plan.landingPage.url.trim())
        ? 'The landing page is http rather than https. Most platforms still accept it; visitors see a warning.'
        : 'The landing page must be a full https URL.',
    });
  }

  for (const idea of plan.abIdeas) {
    if (idea.a.trim() === idea.b.trim()) {
      problems.push({
        severity: 'error',
        field: 'abIdeas',
        message: `The A/B test on ${idea.variable} has the same value on both sides, so it tests nothing.`,
      });
    }
  }

  if (plan.budget.dailyMin > plan.budget.dailyMax) {
    problems.push({
      severity: 'error',
      field: 'budget',
      message: 'The minimum daily budget is above the maximum.',
    });
  }
  if (plan.budget.basis.trim().length < 20) {
    problems.push({
      severity: 'error',
      field: 'budget',
      message: 'A budget recommendation must say what it is based on. A range with no reasoning reads as a measurement.',
    });
  }

  for (const concept of plan.creativeConcepts) {
    // The type makes this false, but a plan can arrive from a request body.
    if ((concept as { imageGenerated?: unknown }).imageGenerated === true) {
      problems.push({
        severity: 'error',
        field: 'creativeConcepts',
        message:
          'A creative concept cannot be marked as having a generated image: no image-generation API is connected, so no image exists.',
      });
    }
  }

  return problems;
}

function checkField(
  problems: PlanProblem[],
  field: string,
  values: readonly string[],
  spec: TextFieldSpec,
): void {
  const usable = values.map((value) => value.trim()).filter((value) => value.length > 0);

  if (usable.length < spec.min) {
    problems.push({
      severity: 'error',
      field,
      message: `${spec.label}: ${spec.min} needed, ${usable.length} written.`,
    });
  }
  if (usable.length > spec.max) {
    problems.push({
      severity: 'error',
      field,
      message: `${spec.label}: at most ${spec.max} are accepted, ${usable.length} written.`,
    });
  }

  usable.forEach((value, index) => {
    if (value.length > spec.maxCharacters) {
      problems.push({
        severity: 'error',
        field,
        message: `${spec.label} ${index + 1} is ${value.length} characters; the limit is ${spec.maxCharacters}.`,
      });
    }
  });

  const lowered = usable.map((value) => value.toLowerCase());
  const duplicates = lowered.filter((value, index) => lowered.indexOf(value) !== index);
  if (duplicates.length > 0) {
    problems.push({
      severity: 'warning',
      field,
      message: `${spec.label}: ${duplicates.length} duplicate(s). Platforms that assemble variations need them to differ.`,
    });
  }
}

export function hasErrors(problems: readonly PlanProblem[]): boolean {
  return problems.some((problem) => problem.severity === 'error');
}

/**
 * A budget recommendation, built so that its reasoning is always present.
 *
 * The floor is not invented from a benchmark. It is arithmetic the user can check:
 * a platform needs a minimum number of daily events before its optimisation does
 * anything, so the suggestion is expressed in terms of that and of the user's own
 * stated goal.
 */
export function recommendBudget(input: {
  readonly currency: string;
  readonly objective: CampaignObjective;
  readonly monthlyTarget?: number;
  readonly ownAverageOrderValue?: number;
}): BudgetRecommendation {
  const reasons: string[] = [];
  let dailyMin = 500;
  let dailyMax = 1_500;

  switch (input.objective) {
    case 'leads':
    case 'sales':
      dailyMin = 800;
      dailyMax = 2_500;
      reasons.push(
        'Lead and sales campaigns need enough daily conversions for the platform to optimise at all; below roughly one event a day it is effectively running blind.',
      );
      break;
    case 'awareness':
    case 'video_views':
      dailyMin = 300;
      dailyMax = 1_200;
      reasons.push('Awareness and view campaigns buy impressions, so a smaller daily budget still produces a usable volume.');
      break;
    default:
      reasons.push('A mid-range starting budget, chosen so that a week of spending produces enough data to judge.');
      break;
  }

  if (input.monthlyTarget !== undefined && input.monthlyTarget > 0) {
    reasons.push(
      `You said you want about ${input.monthlyTarget} results a month; the range assumes a starting cost per result that you will replace with your own once the first week has run.`,
    );
  }
  if (input.ownAverageOrderValue !== undefined && input.ownAverageOrderValue > 0) {
    reasons.push(
      `Your stated average order value of ${input.ownAverageOrderValue} ${input.currency} is the ceiling to judge cost per result against.`,
    );
  }

  return {
    kind: 'ai_recommendation',
    label: 'Recommendation, not a measurement',
    currency: input.currency,
    dailyMin,
    dailyMax,
    basis: reasons.join(' '),
    toMeasure:
      'Connect the ad account and run for a week. Real cost per click and cost per result from your own account replace this range — no benchmark from elsewhere is a substitute for it.',
  };
}

/**
 * What is known about performance. Nothing.
 *
 * Returns the same shape the connected version will, so a screen written against
 * it today does not change when data exists.
 */
export function performanceStatus(): {
  readonly hasData: false;
  readonly reason: string;
} {
  return {
    hasData: false,
    reason:
      'No ad account is connected, so there is no impression, click, spend or conversion data to show. SeSha will not display an estimate in place of a measurement.',
  };
}

/**
 * The landing-page checks that can be made from a URL alone.
 *
 * Deliberately modest: without fetching the page, what is knowable is whether the
 * URL is plausible, secure and free of the tracking mistakes that break
 * attribution. The notes say that is all this is.
 */
export function checkLandingPage(url: string, platform: AdPlatform): LandingPagePlan {
  const notes: string[] = [];
  const trimmed = url.trim();

  if (trimmed.length > 0) {
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol === 'http:') {
        notes.push('The page is served over http. Visitors will see a browser warning on a form.');
      }
      if (parsed.searchParams.has('gclid') || parsed.searchParams.has('fbclid')) {
        notes.push(
          'This URL already contains a click identifier, which belongs to one past click. Use the clean URL and let the platform add its own.',
        );
      }
      if (parsed.hash.length > 1) {
        notes.push('The URL points at a fragment. Some platforms strip it, so do not rely on it to land mid-page.');
      }
      if (parsed.pathname === '/' && platform === 'google_ads') {
        notes.push(
          'This is the home page. Search ads convert better on a page about the thing searched for, and the match between ad and page affects quality scoring.',
        );
      }
    } catch {
      notes.push('This is not a valid URL.');
    }
  }

  return {
    url: trimmed,
    mustMatch: [
      'The headline on the page repeats the promise made in the ad, in the same words.',
      'The action the ad asks for is visible without scrolling.',
      'Nothing on the page contradicts the offer in the ad — price, availability, location.',
      'The page loads on a phone on a slow connection.',
    ],
    notes,
  };
}
