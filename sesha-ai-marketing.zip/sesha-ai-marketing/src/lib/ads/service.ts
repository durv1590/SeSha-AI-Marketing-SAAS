/**
 * Advertising plan service.
 *
 * The validator runs on every write and its output is STORED with the plan. A
 * reviewer looking at an approved plan six weeks later can see what was known
 * about it at the time, rather than re-running today's rules against it and
 * wondering why the result differs.
 *
 * A plan with errors cannot be approved. It can be saved as a draft, because
 * half-finished work is real work — but "approved" means someone signed off on
 * something that will actually upload.
 */

import { requirePermission } from '@/lib/auth/rbac';
import { assertTenant, type TenantContext } from '@/lib/tenant';
import type { Database } from '@/lib/db/repositories';
import type { AdPlanRow } from '@/lib/db/types';

import {
  adsDataStatus,
  isAdPlatform,
  isCampaignObjective,
  type AdPlatform,
} from './platforms';
import {
  checkAdPlan,
  hasErrors,
  recommendBudget,
  checkLandingPage,
  type AdPlan,
  type PlanProblem,
} from './plan';

export interface AdServiceContext {
  readonly db: Database;
  readonly now?: () => Date;
}

function clock(context: AdServiceContext): Date {
  return context.now?.() ?? new Date();
}

export class AdPlanInputError extends Error {
  readonly code = 'INVALID_INPUT' as const;
  readonly problems: readonly PlanProblem[];
  constructor(message: string, problems: readonly PlanProblem[] = []) {
    super(message);
    this.name = 'AdPlanInputError';
    this.problems = problems;
  }
}

export interface SaveAdPlanInput {
  readonly projectId: string;
  readonly plan: AdPlan;
  readonly reviewState?: AdPlanRow['reviewState'];
}

export interface SavedAdPlan {
  readonly row: AdPlanRow;
  readonly problems: readonly PlanProblem[];
}

export async function saveAdPlan(
  context: AdServiceContext,
  tenant: TenantContext,
  input: SaveAdPlanInput,
): Promise<SavedAdPlan> {
  requirePermission(tenant.role, 'campaign:manage');

  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, input.projectId),
    'Project',
  );

  if (!isAdPlatform(input.plan.platform)) {
    throw new AdPlanInputError('That is not a platform SeSha plans for.');
  }
  if (!isCampaignObjective(input.plan.objective)) {
    throw new AdPlanInputError('That is not a campaign objective.');
  }

  const problems = checkAdPlan(input.plan);
  const requested = input.reviewState ?? 'draft';

  if (requested === 'approved' && hasErrors(problems)) {
    throw new AdPlanInputError(
      'This plan cannot be approved while it has errors — it would be rejected by the platform.',
      problems,
    );
  }

  const row = await context.db.adPlans.create({
    organizationId: tenant.organizationId,
    projectId: project.id,
    createdBy: tenant.userId,
    platform: input.plan.platform,
    objective: input.plan.objective,
    campaignName: input.plan.campaignName.trim(),
    reviewNote: null,
    reviewedBy: null,
    reviewedAt: null,
    plan: input.plan as unknown as Readonly<Record<string, unknown>>,
    problems: problems as unknown as readonly Readonly<Record<string, unknown>>[],
    reviewState: requested,
  });

  return { row, problems };
}

export async function listAdPlans(
  context: AdServiceContext,
  tenant: TenantContext,
  projectId: string,
  platform?: AdPlatform,
): Promise<AdPlanRow[]> {
  requirePermission(tenant.role, 'campaign:read');
  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, projectId),
    'Project',
  );
  return context.db.adPlans.listForProject(tenant.organizationId, project.id, platform);
}

export async function getAdPlan(
  context: AdServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<AdPlanRow> {
  requirePermission(tenant.role, 'campaign:read');
  return assertTenant(
    tenant,
    await context.db.adPlans.findById(tenant.organizationId, id),
    'Ad plan',
  );
}

/**
 * Changes the review state.
 *
 * Re-validates rather than trusting the stored problems: the rules may have been
 * tightened since the plan was written, and approving against stale rules is how
 * a plan gets approved that no longer passes.
 */
export async function setAdPlanReviewState(
  context: AdServiceContext,
  tenant: TenantContext,
  id: string,
  reviewState: AdPlanRow['reviewState'],
  reviewNote?: string,
): Promise<SavedAdPlan> {
  requirePermission(tenant.role, 'campaign:manage');

  const existing = assertTenant(
    tenant,
    await context.db.adPlans.findById(tenant.organizationId, id),
    'Ad plan',
  );

  const problems = checkAdPlan(existing.plan as unknown as AdPlan);
  if (reviewState === 'approved' && hasErrors(problems)) {
    throw new AdPlanInputError(
      'This plan still has errors, so it cannot be approved.',
      problems,
    );
  }

  // A rejection MUST say why. Rejecting silently leaves the author guessing,
  // and leaves the automation that recommends what to reconsider with nothing
  // to say. The database CHECK refuses the row too.
  const note = reviewNote?.trim() ?? '';
  if (reviewState === 'rejected' && note.length === 0) {
    throw new AdPlanInputError(
      'Say why you are rejecting this plan. Rejecting without a reason leaves whoever wrote it guessing.',
    );
  }

  const now = context.now?.() ?? new Date();
  const decided = reviewState === 'approved' || reviewState === 'rejected';
  const row = await context.db.adPlans.update(tenant.organizationId, existing.id, {
    reviewState,
    problems: problems as unknown as readonly Readonly<Record<string, unknown>>[],
    reviewNote: reviewState === 'rejected' ? note : (note || null),
    reviewedBy: decided ? tenant.userId : null,
    reviewedAt: decided ? now : null,
  });
  if (!row) throw new AdPlanInputError('That plan could not be updated.');
  return { row, problems };
}

export async function deleteAdPlan(
  context: AdServiceContext,
  tenant: TenantContext,
  id: string,
): Promise<void> {
  requirePermission(tenant.role, 'campaign:manage');
  const existing = assertTenant(
    tenant,
    await context.db.adPlans.findById(tenant.organizationId, id),
    'Ad plan',
  );
  await context.db.adPlans.softDelete(tenant.organizationId, existing.id, clock(context));
}

/**
 * A starting plan for a platform, built from the project's own profile.
 *
 * Deliberately EMPTY of copy. A plan pre-filled with generated headlines reads as
 * finished work and gets approved without being read; a plan with the structure in
 * place and the copy fields empty makes it obvious what still needs a person. The
 * AI layer fills the copy when the user asks it to, through the normal
 * provenance-checked path.
 */
export async function startAdPlan(
  context: AdServiceContext,
  tenant: TenantContext,
  input: { readonly projectId: string; readonly platform: AdPlatform; readonly objective: AdPlan['objective'] },
): Promise<{ readonly plan: AdPlan; readonly dataStatus: ReturnType<typeof adsDataStatus> }> {
  requirePermission(tenant.role, 'campaign:read');

  const project = assertTenant(
    tenant,
    await context.db.projects.findById(tenant.organizationId, input.projectId),
    'Project',
  );
  const profile = await context.db.marketingProfiles.findByProject(
    tenant.organizationId,
    project.id,
  );
  const business = project.businessId
    ? await context.db.businesses.findById(tenant.organizationId, project.businessId)
    : null;

  const plan: AdPlan = {
    platform: input.platform,
    objective: input.objective,
    campaignName: `${business?.name ?? project.name} — ${input.objective}`,
    audience: {
      description: profile?.targetAudience ?? '',
      locations: business?.city ? [business.city] : [],
      languages: [],
      signals: [],
      exclusions: [],
    },
    headlines: [],
    descriptions: [],
    primaryText: [],
    cta: '',
    creativeConcepts: [],
    landingPage: checkLandingPage(business?.websiteUrl ?? '', input.platform),
    abIdeas: [],
    budget: recommendBudget({ currency: 'INR', objective: input.objective }),
    reviewState: 'draft',
  };

  return { plan, dataStatus: adsDataStatus() };
}
