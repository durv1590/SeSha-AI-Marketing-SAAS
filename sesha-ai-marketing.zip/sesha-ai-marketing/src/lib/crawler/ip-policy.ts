/**
 * IP address policy — the authority on what the crawler may connect to.
 *
 * WHY THIS IS ITS OWN FILE
 * A crawler fetches URLs a user typed. If it will connect to anything, it is a
 * proxy into the private network it runs in: an attacker types
 * `http://169.254.169.254/latest/meta-data/iam/security-credentials/` and gets
 * the deployment's cloud credentials back in a "page content" field. Every
 * other part of the crawler is a feature; this is the part that makes the
 * feature safe to ship.
 *
 * THE DESIGN
 * Addresses are parsed to BYTES and compared against CIDR ranges numerically.
 * This is deliberate: string prefix matching is how these checks get bypassed.
 * `fe80::1` does not start with `fe8` after normalisation to `[fe80::1]`,
 * `::ffff:127.0.0.1` is loopback wearing an IPv6 costume, and `0x7f000001`,
 * `017700000001`, `2130706433` and `127.1` are all 127.0.0.1 written to look
 * like something else.
 *
 * DEFAULT DENY
 * `isAllowedAddress` returns false for anything it does not positively
 * recognise as a public unicast address. A new address family, a malformed
 * input or a parse failure is refused, not waved through.
 */

/* -------------------------------------------------------------------------- */
/* Parsing                                                                    */
/* -------------------------------------------------------------------------- */

export type IpVersion = 4 | 6;

export interface ParsedIp {
  readonly version: IpVersion;
  /** 4 bytes for IPv4, 16 for IPv6. */
  readonly bytes: readonly number[];
  /** An IPv4-mapped or IPv4-compatible IPv6 address, unwrapped to its IPv4. */
  readonly mappedIpv4: ParsedIp | null;
}

/**
 * Parses a dotted-quad IPv4 address.
 *
 * STRICT: exactly four decimal octets, no leading zeros beyond "0" itself.
 * Shorthand and alternative bases (`127.1`, `0x7f000001`, `017700000001`) are
 * rejected here rather than interpreted, because this function is also used on
 * values that did NOT come through a URL parser. WHATWG `URL` happens to
 * normalise those forms to dotted quad, so by the time a hostname reaches us
 * from a parsed URL it is already canonical — but a DNS answer, a redirect
 * header or a future caller may not be, and a parser that guesses is a parser
 * that disagrees with the one the network stack uses.
 */
export function parseIpv4(input: string): ParsedIp | null {
  const parts = input.split('.');
  if (parts.length !== 4) return null;

  const bytes: number[] = [];
  for (const part of parts) {
    if (part.length === 0 || part.length > 3) return null;
    if (!/^\d+$/.test(part)) return null;
    if (part.length > 1 && part.startsWith('0')) return null; // octal ambiguity
    const value = Number(part);
    if (value > 255) return null;
    bytes.push(value);
  }
  return { version: 4, bytes, mappedIpv4: null };
}

/** Parses an IPv6 address, with or without surrounding brackets. */
export function parseIpv6(input: string): ParsedIp | null {
  let text = input.trim();
  if (text.startsWith('[') && text.endsWith(']')) text = text.slice(1, -1);

  // A zone index (fe80::1%eth0) names a local interface by definition.
  const zoneIndex = text.indexOf('%');
  if (zoneIndex !== -1) text = text.slice(0, zoneIndex);

  if (text.length === 0 || !text.includes(':')) return null;
  if (/[^0-9a-fA-F:.]/.test(text)) return null;
  if (text.includes(':::')) return null;

  // A trailing dotted quad (::ffff:127.0.0.1) contributes the last four bytes.
  let tail: number[] = [];
  const lastColon = text.lastIndexOf(':');
  const afterLastColon = text.slice(lastColon + 1);
  if (afterLastColon.includes('.')) {
    const embedded = parseIpv4(afterLastColon);
    if (!embedded) return null;
    tail = [...embedded.bytes];
    text = text.slice(0, lastColon + 1);
    // Leave the separator so the group split below behaves consistently.
    text = text.slice(0, -1) + ':';
  }

  const doubleColon = text.indexOf('::');
  if (doubleColon !== -1 && text.indexOf('::', doubleColon + 1) !== -1) return null;

  const groupBytes: number[] = [];

  function pushGroups(section: string, into: number[]): boolean {
    if (section.length === 0) return true;
    for (const group of section.split(':')) {
      if (group.length === 0) return false;
      if (group.length > 4) return false;
      const value = Number.parseInt(group, 16);
      if (!Number.isInteger(value) || value < 0 || value > 0xffff) return false;
      into.push((value >> 8) & 0xff, value & 0xff);
    }
    return true;
  }

  if (doubleColon === -1) {
    if (!pushGroups(text.replace(/:$/, ''), groupBytes)) return null;
    const total = groupBytes.length + tail.length;
    if (total !== 16) return null;
    return finishIpv6([...groupBytes, ...tail]);
  }

  const head: number[] = [];
  const rest: number[] = [];
  if (!pushGroups(text.slice(0, doubleColon), head)) return null;
  if (!pushGroups(text.slice(doubleColon + 2).replace(/:$/, ''), rest)) return null;

  const known = head.length + rest.length + tail.length;
  if (known > 16) return null;
  const zeros = new Array<number>(16 - known).fill(0);
  return finishIpv6([...head, ...zeros, ...rest, ...tail]);
}

function finishIpv6(bytes: number[]): ParsedIp | null {
  if (bytes.length !== 16) return null;

  // ::ffff:a.b.c.d (IPv4-mapped) and ::a.b.c.d (IPv4-compatible, deprecated)
  // both reach an IPv4 destination, so they are judged as that IPv4 address.
  const firstTenAreZero = bytes.slice(0, 10).every((byte) => byte === 0);
  if (firstTenAreZero) {
    const marker = (bytes[10]! << 8) | bytes[11]!;
    const isMapped = marker === 0xffff;
    const isCompatible = marker === 0 && bytes.slice(12).some((byte) => byte !== 0);
    if (isMapped || isCompatible) {
      const ipv4: ParsedIp = { version: 4, bytes: bytes.slice(12), mappedIpv4: null };
      return { version: 6, bytes, mappedIpv4: ipv4 };
    }
  }

  // NAT64 (64:ff9b::/96) and 6to4 (2002::/16) also carry an embedded IPv4 that
  // the packet eventually reaches, so the embedded address is judged too.
  if (bytes[0] === 0x00 && bytes[1] === 0x64 && bytes[2] === 0xff && bytes[3] === 0x9b) {
    const ipv4: ParsedIp = { version: 4, bytes: bytes.slice(12), mappedIpv4: null };
    return { version: 6, bytes, mappedIpv4: ipv4 };
  }
  if (bytes[0] === 0x20 && bytes[1] === 0x02) {
    const ipv4: ParsedIp = { version: 4, bytes: bytes.slice(2, 6), mappedIpv4: null };
    return { version: 6, bytes, mappedIpv4: ipv4 };
  }

  return { version: 6, bytes, mappedIpv4: null };
}

/** Parses either family. Returns null for anything that is not an IP literal. */
export function parseIp(input: string): ParsedIp | null {
  const text = input.trim();
  if (text.length === 0) return null;
  if (text.includes(':') || text.startsWith('[')) return parseIpv6(text);
  return parseIpv4(text);
}

export function formatIp(ip: ParsedIp): string {
  if (ip.version === 4) return ip.bytes.join('.');
  const groups: string[] = [];
  for (let index = 0; index < 16; index += 2) {
    groups.push(((ip.bytes[index]! << 8) | ip.bytes[index + 1]!).toString(16));
  }
  return groups.join(':');
}

/* -------------------------------------------------------------------------- */
/* Ranges                                                                     */
/* -------------------------------------------------------------------------- */

interface Cidr {
  readonly label: string;
  readonly bytes: readonly number[];
  readonly prefix: number;
}

function cidr(label: string, notation: string): Cidr {
  const slash = notation.lastIndexOf('/');
  const address = notation.slice(0, slash);
  const prefix = Number(notation.slice(slash + 1));
  const parsed = parseIp(address);
  if (!parsed) throw new Error(`bad CIDR in ip-policy: ${notation}`);
  return { label, bytes: parsed.bytes, prefix };
}

/**
 * Every IPv4 range the crawler refuses.
 *
 * The list is long on purpose. Each entry is either a route into a private
 * network, an address with special meaning to the local stack, or a documented
 * cloud metadata endpoint. Omitting one is not a missing feature — it is a hole.
 */
const BLOCKED_V4: readonly Cidr[] = [
  cidr('"this network" / unspecified', '0.0.0.0/8'),
  cidr('private (RFC 1918)', '10.0.0.0/8'),
  cidr('shared address space (CGNAT)', '100.64.0.0/10'),
  cidr('loopback', '127.0.0.0/8'),
  cidr('link-local', '169.254.0.0/16'),
  cidr('private (RFC 1918)', '172.16.0.0/12'),
  cidr('IETF protocol assignments', '192.0.0.0/24'),
  cidr('documentation (TEST-NET-1)', '192.0.2.0/24'),
  cidr('6to4 relay anycast', '192.88.99.0/24'),
  cidr('private (RFC 1918)', '192.168.0.0/16'),
  cidr('benchmarking', '198.18.0.0/15'),
  cidr('documentation (TEST-NET-2)', '198.51.100.0/24'),
  cidr('documentation (TEST-NET-3)', '203.0.113.0/24'),
  cidr('multicast', '224.0.0.0/4'),
  cidr('reserved', '240.0.0.0/4'),
];

const BLOCKED_V6: readonly Cidr[] = [
  cidr('unspecified', '::/128'),
  cidr('loopback', '::1/128'),
  cidr('IPv4-mapped', '::ffff:0:0/96'),
  cidr('discard-only', '100::/64'),
  cidr('IETF protocol assignments', '2001::/23'),
  cidr('documentation', '2001:db8::/32'),
  cidr('unique local (private)', 'fc00::/7'),
  cidr('link-local', 'fe80::/10'),
  cidr('multicast', 'ff00::/8'),
];

/**
 * Cloud instance metadata endpoints, blocked individually as well as by range.
 *
 * 169.254.169.254 is already inside the link-local block, and it is listed
 * again here so that the denial message names it. A developer reading
 * "blocked: cloud metadata endpoint" in a log understands immediately; "blocked:
 * link-local" invites someone to wonder whether the rule is too broad.
 */
const METADATA_ADDRESSES: readonly { readonly address: string; readonly label: string }[] = [
  { address: '169.254.169.254', label: 'cloud metadata endpoint (AWS, Azure, GCP, DigitalOcean)' },
  { address: '169.254.170.2', label: 'AWS ECS task metadata endpoint' },
  { address: '100.100.100.200', label: 'Alibaba Cloud metadata endpoint' },
  { address: '192.0.0.192', label: 'Oracle Cloud metadata endpoint' },
  { address: 'fd00:ec2::254', label: 'AWS IPv6 metadata endpoint' },
];

const METADATA_BYTES = new Map<string, string>(
  METADATA_ADDRESSES.map((entry) => {
    const parsed = parseIp(entry.address);
    if (!parsed) throw new Error(`bad metadata address in ip-policy: ${entry.address}`);
    return [parsed.bytes.join(','), entry.label];
  }),
);

function inRange(bytes: readonly number[], range: Cidr): boolean {
  if (bytes.length !== range.bytes.length) return false;

  const wholeBytes = Math.floor(range.prefix / 8);
  for (let index = 0; index < wholeBytes; index += 1) {
    if (bytes[index] !== range.bytes[index]) return false;
  }

  const remainingBits = range.prefix % 8;
  if (remainingBits === 0) return true;

  const mask = 0xff << (8 - remainingBits) & 0xff;
  return (bytes[wholeBytes]! & mask) === (range.bytes[wholeBytes]! & mask);
}

/* -------------------------------------------------------------------------- */
/* The decision                                                               */
/* -------------------------------------------------------------------------- */

export type AddressVerdict =
  | { readonly allowed: true; readonly ip: ParsedIp }
  | { readonly allowed: false; readonly reason: string };

/**
 * Decides whether the crawler may connect to one address.
 *
 * An IPv6 address carrying an embedded IPv4 (mapped, NAT64, 6to4) is judged on
 * BOTH its own bytes and the embedded address, because the packet reaches the
 * embedded destination. `::ffff:127.0.0.1` is loopback whatever it looks like.
 */
export function checkAddress(input: string | ParsedIp): AddressVerdict {
  const ip = typeof input === 'string' ? parseIp(input) : input;
  if (!ip) return { allowed: false, reason: 'not a valid IP address' };

  const metadata = METADATA_BYTES.get(ip.bytes.join(','));
  if (metadata) return { allowed: false, reason: metadata };

  const ranges = ip.version === 4 ? BLOCKED_V4 : BLOCKED_V6;
  for (const range of ranges) {
    if (inRange(ip.bytes, range)) {
      return { allowed: false, reason: `${range.label} address (${formatIp(ip)})` };
    }
  }

  if (ip.mappedIpv4) {
    const embedded = checkAddress(ip.mappedIpv4);
    if (!embedded.allowed) {
      return {
        allowed: false,
        reason: `embeds a blocked IPv4 address — ${embedded.reason}`,
      };
    }
  }

  // Broadcast is not inside any block above and is not a unicast destination.
  if (ip.version === 4 && ip.bytes.every((byte) => byte === 255)) {
    return { allowed: false, reason: 'broadcast address' };
  }

  return { allowed: true, ip };
}

export function isAllowedAddress(input: string | ParsedIp): boolean {
  return checkAddress(input).allowed;
}

/* -------------------------------------------------------------------------- */
/* Hostnames                                                                  */
/* -------------------------------------------------------------------------- */

/**
 * Hostnames that resolve inside a private network by convention, and the
 * metadata hostnames the major clouds publish.
 *
 * This runs BEFORE DNS, so a name on this list is refused without a lookup —
 * which also means no DNS query for an internal name leaves the deployment.
 */
const BLOCKED_SUFFIXES: readonly string[] = [
  'localhost',
  '.localhost',
  '.local',
  '.localdomain',
  '.internal',
  '.intranet',
  '.intra',
  '.corp',
  '.home',
  '.home.arpa',
  '.lan',
  '.private',
  '.test',
  '.example',
  '.invalid',
  '.onion',
  '.in-addr.arpa',
  '.ip6.arpa',
];

const BLOCKED_HOSTNAMES: readonly string[] = [
  'metadata',
  'metadata.google.internal',
  'metadata.goog',
  'instance-data',
  'instance-data.ec2.internal',
];

export interface HostVerdict {
  readonly allowed: boolean;
  readonly reason?: string;
}

/**
 * Deployment-specific additions to the blocklist.
 *
 * `CRAWLER_EXTRA_BLOCKED_HOSTS` lets an operator refuse more hostnames — their
 * own internal domains, a partner's staging environment. It can only ADD: there
 * is deliberately no variable that removes anything, because an SSRF defence
 * that can be switched off in production is not a defence.
 *
 * Read on each call rather than cached, so a test can set it and a deployment
 * can change it without a restart. The list is tiny and the parse is trivial.
 */
function extraBlockedHosts(): string[] {
  const raw = process.env.CRAWLER_EXTRA_BLOCKED_HOSTS;
  if (!raw) return [];
  return raw
    .split(/[\s,]+/)
    .map((entry) => entry.trim().toLowerCase().replace(/^\*?\.?/, '.').replace(/\.$/, ''))
    .filter((entry) => entry.length > 1);
}

/**
 * Checks a hostname before any DNS lookup happens.
 *
 * An IP literal is decided here and now. A name is only screened for the
 * conventions above — whether it actually points somewhere private can only be
 * answered by resolving it, which is `resolver.ts`'s job.
 */
export function checkHostname(hostname: string): HostVerdict {
  const host = hostname.trim().toLowerCase().replace(/\.$/, '');
  if (host.length === 0) return { allowed: false, reason: 'empty hostname' };
  if (host.length > 253) return { allowed: false, reason: 'hostname is too long' };

  const literal = parseIp(host);
  if (literal) {
    const verdict = checkAddress(literal);
    return verdict.allowed ? { allowed: true } : { allowed: false, reason: verdict.reason };
  }

  if (BLOCKED_HOSTNAMES.includes(host)) {
    return { allowed: false, reason: `"${host}" is a cloud metadata hostname` };
  }

  for (const suffix of BLOCKED_SUFFIXES) {
    const matches = suffix.startsWith('.') ? host.endsWith(suffix) : host === suffix;
    if (matches) {
      return { allowed: false, reason: `"${suffix}" names an internal or reserved namespace` };
    }
  }

  // Operator additions, applied after the built-ins so they can never shadow one.
  for (const suffix of extraBlockedHosts()) {
    if (host === suffix.slice(1) || host.endsWith(suffix)) {
      return {
        allowed: false,
        reason: `"${suffix}" is blocked by this deployment's configuration`,
      };
    }
  }

  // A single label with no dot is a local name on most networks ("intranet",
  // "wiki"), and cannot be a registrable public domain.
  if (!host.includes('.')) {
    return { allowed: false, reason: 'not a fully qualified domain name' };
  }

  if (!/^[a-z0-9.-]+$/.test(host)) {
    // Punycode is ASCII by the time it reaches here; anything else is suspect.
    return { allowed: false, reason: 'hostname contains characters that are not allowed' };
  }
  if (host.includes('..') || host.startsWith('-') || host.endsWith('-')) {
    return { allowed: false, reason: 'malformed hostname' };
  }
  for (const label of host.split('.')) {
    if (label.length === 0 || label.length > 63) {
      return { allowed: false, reason: 'malformed hostname label' };
    }
  }

  return { allowed: true };
}

/** Exposed for the documentation page and the tests, not for decisions. */
export function blockedRangeLabels(): string[] {
  return [...new Set([...BLOCKED_V4, ...BLOCKED_V6].map((range) => range.label))].sort();
}
