/**
 * HTML extraction.
 *
 * No parser library. A DOM implementation is a large dependency whose whole job
 * is to execute attacker-controlled markup, and this phase needs to read about
 * twenty well-defined things from a document, not to build a live tree.
 *
 * WHAT THAT COSTS, STATED HONESTLY
 * Regular expressions cannot parse HTML in general. This reader is therefore
 * deliberately conservative: it strips script, style, template and comment
 * content FIRST so their contents can never be mistaken for page text, works on
 * the remainder, and reports what it could not determine rather than guessing.
 * Where a value is structurally ambiguous, the extractor prefers to return null
 * and let the audit say "could not be determined" — which is the honest answer
 * and the one the provenance rules require.
 *
 * Every string that leaves here is length-capped, so a hostile page cannot turn
 * one crawled URL into a multi-megabyte database row.
 */

import { checkUrl, looksLikeAsset, normalizeUrl, sameSite } from './url-policy';

export const LIMITS = {
  title: 300,
  metaDescription: 500,
  heading: 300,
  headingsPerLevel: 50,
  textCharacters: 200_000,
  links: 500,
  images: 200,
  structuredDataBlocks: 25,
  structuredDataBytes: 100_000,
  faqs: 50,
} as const;

export interface ExtractedLink {
  readonly url: string;
  readonly text: string;
  readonly rel: string | null;
  readonly internal: boolean;
  readonly nofollow: boolean;
}

export interface ExtractedImage {
  readonly src: string;
  readonly alt: string | null;
  readonly hasDimensions: boolean;
  readonly lazy: boolean;
}

export interface ExtractedFaq {
  readonly question: string;
  readonly answer: string | null;
  /**
   * Where the pair was found. This distinction is load-bearing: a question in
   * FAQPage structured data is a statement by the site that it answers that
   * question, whereas a question-phrased heading is an inference from wording.
   * Collapsing the two would let a keyword sourced from an h2 be reported as
   * having come from FAQ markup.
   */
  readonly source: 'structured_data' | 'heading';
}

export interface RobotsDirectives {
  readonly raw: string | null;
  readonly noindex: boolean;
  readonly nofollow: boolean;
  readonly noarchive: boolean;
  readonly nosnippet: boolean;
  readonly maxSnippet: number | null;
}

export interface EntitySignals {
  readonly organizationNames: readonly string[];
  readonly sameAs: readonly string[];
  readonly telephones: readonly string[];
  readonly addresses: readonly string[];
  /** `@type` values found in structured data, which is the strongest signal. */
  readonly schemaTypes: readonly string[];
}

export interface PageData {
  readonly url: string;
  readonly status: number;
  readonly https: boolean;
  readonly title: string | null;
  readonly metaDescription: string | null;
  readonly h1: readonly string[];
  readonly h2: readonly string[];
  readonly h3: readonly string[];
  readonly text: string;
  readonly wordCount: number;
  readonly links: readonly ExtractedLink[];
  readonly images: readonly ExtractedImage[];
  readonly canonical: string | null;
  readonly robots: RobotsDirectives;
  readonly structuredData: readonly unknown[];
  readonly structuredDataErrors: readonly string[];
  readonly faqs: readonly ExtractedFaq[];
  readonly author: string | null;
  readonly publisher: string | null;
  readonly publishedAt: string | null;
  readonly modifiedAt: string | null;
  readonly entities: EntitySignals;
  readonly lang: string | null;
  readonly hasViewportMeta: boolean;
  readonly hasCharset: boolean;
  readonly openGraph: Readonly<Record<string, string>>;
  readonly bytes: number;
  readonly responseTimeMs: number;
  /** Every page records when it was read. */
  readonly crawledAt: Date;
  readonly truncated: boolean;
}

/* -------------------------------------------------------------------------- */
/* Low-level helpers                                                          */
/* -------------------------------------------------------------------------- */

/** Removes comments and the content of elements whose text is not page text. */
function stripNonContent(html: string): string {
  return html
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi, ' ')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style\s*>/gi, ' ')
    .replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript\s*>/gi, ' ')
    .replace(/<template\b[^>]*>[\s\S]*?<\/template\s*>/gi, ' ')
    .replace(/<svg\b[^>]*>[\s\S]*?<\/svg\s*>/gi, ' ')
    .replace(/<iframe\b[^>]*>[\s\S]*?<\/iframe\s*>/gi, ' ');
}

const NAMED_ENTITIES: Readonly<Record<string, string>> = {
  amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ',
  ndash: '–', mdash: '—', hellip: '…', lsquo: '‘', rsquo: '’',
  ldquo: '“', rdquo: '”', copy: '©', reg: '®', trade: '™',
  eacute: 'é', egrave: 'è', agrave: 'à', ccedil: 'ç', uuml: 'ü', ouml: 'ö',
  auml: 'ä', szlig: 'ß', deg: '°', middot: '·', bull: '•', euro: '€',
  pound: '£', yen: '¥', cent: '¢', sect: '§', para: '¶', laquo: '«', raquo: '»',
  times: '×', divide: '÷', plusmn: '±', frac12: '½', frac14: '¼', sup2: '²',
};

export function decodeEntities(input: string): string {
  return input
    .replace(/&#x([0-9a-fA-F]{1,6});?/g, (_, hex: string) => codePoint(Number.parseInt(hex, 16)))
    .replace(/&#(\d{1,7});?/g, (_, dec: string) => codePoint(Number(dec)))
    .replace(/&([a-zA-Z][a-zA-Z0-9]{1,31});?/g, (whole, name: string) => {
      const value = NAMED_ENTITIES[name.toLowerCase()];
      return value ?? whole;
    });
}

function codePoint(value: number): string {
  if (!Number.isInteger(value) || value < 0 || value > 0x10ffff) return '';
  if (value >= 0xd800 && value <= 0xdfff) return '';
  try {
    return String.fromCodePoint(value);
  } catch {
    return '';
  }
}

/** Tag content to readable text: entities decoded, whitespace collapsed. */
function toText(fragment: string, limit: number): string {
  const withoutTags = fragment.replace(/<[^>]*>/g, ' ');
  return decodeEntities(withoutTags).replace(/\s+/g, ' ').trim().slice(0, limit);
}

/** Reads one attribute from a start tag, tolerating quoting styles. */
export function attribute(tag: string, name: string): string | null {
  const pattern = new RegExp(`\\b${name}\\s*=\\s*("([^"]*)"|'([^']*)'|([^\\s"'>]+))`, 'i');
  const match = pattern.exec(tag);
  if (!match) return null;
  const raw = match[2] ?? match[3] ?? match[4] ?? '';
  return decodeEntities(raw).trim();
}

/** Every `<meta>` tag, keyed by lowercased name or property. */
function metaTags(html: string): Map<string, string> {
  const found = new Map<string, string>();
  for (const match of html.matchAll(/<meta\b[^>]*>/gi)) {
    const tag = match[0];
    const key = attribute(tag, 'name') ?? attribute(tag, 'property') ?? attribute(tag, 'itemprop');
    const content = attribute(tag, 'content');
    if (!key || content === null) continue;
    const normalized = key.toLowerCase();
    // First wins: a duplicated meta tag is a bug on the page, and search
    // engines generally take the first.
    if (!found.has(normalized)) found.set(normalized, content);
  }
  return found;
}

function headings(html: string, level: 1 | 2 | 3): string[] {
  const pattern = new RegExp(`<h${level}\\b[^>]*>([\\s\\S]*?)</h${level}\\s*>`, 'gi');
  const out: string[] = [];
  for (const match of html.matchAll(pattern)) {
    if (out.length >= LIMITS.headingsPerLevel) break;
    const text = toText(match[1] ?? '', LIMITS.heading);
    if (text.length > 0) out.push(text);
  }
  return out;
}

/* -------------------------------------------------------------------------- */
/* Structured data                                                            */
/* -------------------------------------------------------------------------- */

interface StructuredDataResult {
  readonly blocks: readonly unknown[];
  readonly errors: readonly string[];
}

/**
 * Reads every JSON-LD block.
 *
 * A block that does not parse is recorded as an error rather than dropped — an
 * invalid JSON-LD block is one of the most valuable findings an SEO audit can
 * report, because the site owner almost certainly believes it is working.
 */
function structuredData(html: string): StructuredDataResult {
  const blocks: unknown[] = [];
  const errors: string[] = [];
  let index = 0;

  for (const match of html.matchAll(
    /<script\b[^>]*type\s*=\s*["']?application\/ld\+json["']?[^>]*>([\s\S]*?)<\/script\s*>/gi,
  )) {
    index += 1;
    if (blocks.length + errors.length >= LIMITS.structuredDataBlocks) break;

    const raw = (match[1] ?? '').trim().slice(0, LIMITS.structuredDataBytes);
    if (raw.length === 0) {
      errors.push(`Block ${index} is empty.`);
      continue;
    }
    try {
      // CDATA wrappers are legal and common in XHTML-flavoured markup.
      const cleaned = raw.replace(/^\s*(?:\/\/)?\s*<!\[CDATA\[/, '').replace(/\]\]>\s*$/, '');
      const parsed: unknown = JSON.parse(cleaned);
      if (Array.isArray(parsed)) blocks.push(...parsed.slice(0, LIMITS.structuredDataBlocks));
      else blocks.push(parsed);
    } catch (error) {
      errors.push(`Block ${index} is not valid JSON: ${(error as Error).message}`);
    }
  }

  return { blocks, errors };
}

/** Walks structured data, including @graph and nested objects. */
function* walkNodes(value: unknown, depth = 0): Generator<Record<string, unknown>> {
  if (depth > 8 || value === null || typeof value !== 'object') return;
  if (Array.isArray(value)) {
    for (const item of value) yield* walkNodes(item, depth + 1);
    return;
  }
  const node = value as Record<string, unknown>;
  yield node;
  for (const child of Object.values(node)) {
    if (child !== null && typeof child === 'object') yield* walkNodes(child, depth + 1);
  }
}

function typesOf(node: Record<string, unknown>): string[] {
  const raw = node['@type'];
  if (typeof raw === 'string') return [raw];
  if (Array.isArray(raw)) return raw.filter((item): item is string => typeof item === 'string');
  return [];
}

function textOf(value: unknown): string | null {
  if (typeof value === 'string') return value.trim() || null;
  if (typeof value === 'number') return String(value);
  if (value !== null && typeof value === 'object') {
    const node = value as Record<string, unknown>;
    for (const key of ['name', '@value', 'text', 'url']) {
      const candidate = node[key];
      if (typeof candidate === 'string' && candidate.trim().length > 0) return candidate.trim();
    }
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = textOf(item);
      if (found) return found;
    }
  }
  return null;
}

/* -------------------------------------------------------------------------- */
/* FAQ extraction                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Finds question/answer pairs.
 *
 * Structured FAQPage data is taken as authoritative. Beyond that, only headings
 * that are literally phrased as questions are reported — an `h3` that happens to
 * sit above a paragraph is not a FAQ, and counting it as one would inflate the
 * AEO score with content that does not exist.
 */
function extractFaqs(html: string, blocks: readonly unknown[], allHeadings: readonly string[]): ExtractedFaq[] {
  const faqs: ExtractedFaq[] = [];
  const seen = new Set<string>();

  for (const node of walkNodes(blocks)) {
    if (!typesOf(node).includes('Question')) continue;
    const question = textOf(node['name']);
    if (!question || seen.has(question.toLowerCase())) continue;
    const accepted = node['acceptedAnswer'];
    const answer = accepted ? textOf((accepted as Record<string, unknown>)['text'] ?? accepted) : null;
    seen.add(question.toLowerCase());
    faqs.push({
      question: question.slice(0, LIMITS.heading),
      answer: answer?.slice(0, 2_000) ?? null,
      source: 'structured_data',
    });
    if (faqs.length >= LIMITS.faqs) return faqs;
  }

  for (const heading of allHeadings) {
    if (faqs.length >= LIMITS.faqs) break;
    if (!isQuestion(heading)) continue;
    if (seen.has(heading.toLowerCase())) continue;
    seen.add(heading.toLowerCase());
    // The answer is not asserted: the text following a heading cannot be
    // attributed reliably without a real tree, so it is reported as unknown.
    faqs.push({ question: heading, answer: null, source: 'heading' });
  }

  void html;
  return faqs;
}

const QUESTION_WORDS = /^(what|who|when|where|why|how|which|can|do|does|did|is|are|was|were|should|would|will|may|must|have|has)\b/i;

export function isQuestion(text: string): boolean {
  const trimmed = text.trim();
  if (trimmed.endsWith('?')) return true;
  return QUESTION_WORDS.test(trimmed) && trimmed.split(/\s+/).length >= 3;
}

/* -------------------------------------------------------------------------- */
/* The extractor                                                              */
/* -------------------------------------------------------------------------- */

export interface ExtractInput {
  readonly url: string;
  readonly html: string;
  readonly status: number;
  readonly bytes: number;
  readonly responseTimeMs: number;
  readonly truncated?: boolean;
  readonly crawledAt?: Date;
}

export function extractPage(input: ExtractInput): PageData {
  const html = input.html;
  const content = stripNonContent(html);
  const meta = metaTags(html);
  const head = /<head\b[^>]*>([\s\S]*?)<\/head\s*>/i.exec(html)?.[1] ?? html.slice(0, 50_000);

  const sd = structuredData(html);
  const h1 = headings(content, 1);
  const h2 = headings(content, 2);
  const h3 = headings(content, 3);

  const titleMatch = /<title\b[^>]*>([\s\S]*?)<\/title\s*>/i.exec(head);
  const title = titleMatch ? toText(titleMatch[1] ?? '', LIMITS.title) || null : null;

  const bodyMatch = /<body\b[^>]*>([\s\S]*?)<\/body\s*>/i.exec(content);
  const bodySource = bodyMatch?.[1] ?? content;
  const text = toText(bodySource, LIMITS.textCharacters);

  const canonicalHref = linkHref(head, 'canonical');
  let canonical: string | null = null;
  if (canonicalHref) {
    const verdict = checkUrl(canonicalHref, input.url);
    canonical = verdict.ok ? verdict.url.toString() : null;
  }

  const openGraph: Record<string, string> = {};
  for (const [key, value] of meta) {
    if (key.startsWith('og:') || key.startsWith('twitter:')) openGraph[key] = value.slice(0, 500);
  }

  const entities = entitySignals(sd.blocks, meta);

  return {
    url: input.url,
    status: input.status,
    https: input.url.startsWith('https://'),
    title,
    metaDescription: meta.get('description')?.slice(0, LIMITS.metaDescription) ?? null,
    h1,
    h2,
    h3,
    text,
    wordCount: countWords(text),
    links: extractLinks(content, input.url),
    images: extractImages(content, input.url),
    canonical,
    robots: parseRobotsMeta(meta.get('robots') ?? meta.get('googlebot') ?? null),
    structuredData: sd.blocks,
    structuredDataErrors: sd.errors,
    faqs: extractFaqs(html, sd.blocks, [...h2, ...h3]),
    author: authorOf(sd.blocks, meta),
    publisher: publisherOf(sd.blocks, meta),
    publishedAt: dateOf(sd.blocks, meta, 'published'),
    modifiedAt: dateOf(sd.blocks, meta, 'modified'),
    entities,
    lang: attribute(/<html\b[^>]*>/i.exec(html)?.[0] ?? '', 'lang'),
    hasViewportMeta: meta.has('viewport'),
    hasCharset: /<meta\b[^>]*charset\s*=/i.test(head),
    openGraph,
    bytes: input.bytes,
    responseTimeMs: input.responseTimeMs,
    crawledAt: input.crawledAt ?? new Date(),
    truncated: input.truncated ?? false,
  };
}

function linkHref(head: string, rel: string): string | null {
  for (const match of head.matchAll(/<link\b[^>]*>/gi)) {
    const relValue = attribute(match[0], 'rel')?.toLowerCase();
    if (relValue === rel) return attribute(match[0], 'href');
  }
  return null;
}

export function countWords(text: string): number {
  const trimmed = text.trim();
  if (trimmed.length === 0) return 0;
  return trimmed.split(/\s+/).length;
}

function extractLinks(html: string, baseUrl: string): ExtractedLink[] {
  const links: ExtractedLink[] = [];
  const seen = new Set<string>();

  for (const match of html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi)) {
    if (links.length >= LIMITS.links) break;
    const tag = match[1] ?? '';
    const href = attribute(tag, 'href');
    if (!href || href.startsWith('#')) continue;

    // Validated here, so a `javascript:` or `file:` href never reaches the
    // frontier and never reaches the interface as a clickable link.
    const verdict = checkUrl(href, baseUrl);
    if (!verdict.ok) continue;

    let normalized: string;
    try {
      normalized = normalizeUrl(verdict.url);
    } catch {
      continue;
    }
    if (seen.has(normalized)) continue;
    seen.add(normalized);

    const rel = attribute(tag, 'rel');
    links.push({
      url: normalized,
      text: toText(match[2] ?? '', 200),
      rel,
      internal: sameSite(normalized, baseUrl),
      nofollow: (rel ?? '').toLowerCase().split(/\s+/).includes('nofollow'),
    });
  }
  return links;
}

function extractImages(html: string, baseUrl: string): ExtractedImage[] {
  const images: ExtractedImage[] = [];
  for (const match of html.matchAll(/<img\b([^>]*)>/gi)) {
    if (images.length >= LIMITS.images) break;
    const tag = match[1] ?? '';
    const src = attribute(tag, 'src') ?? attribute(tag, 'data-src');
    if (!src || src.startsWith('data:')) continue;

    const verdict = checkUrl(src, baseUrl);
    const resolved = verdict.ok ? verdict.url.toString() : null;
    if (!resolved) continue;

    // A missing alt and an empty alt are different: empty is the correct markup
    // for a decorative image, so it is recorded as '' rather than null.
    const alt = attribute(tag, 'alt');
    images.push({
      src: resolved,
      alt: alt === null ? null : alt,
      hasDimensions: attribute(tag, 'width') !== null && attribute(tag, 'height') !== null,
      lazy: (attribute(tag, 'loading') ?? '').toLowerCase() === 'lazy',
    });
  }
  return images;
}

export function parseRobotsMeta(raw: string | null): RobotsDirectives {
  if (!raw) {
    return { raw: null, noindex: false, nofollow: false, noarchive: false, nosnippet: false, maxSnippet: null };
  }
  const tokens = raw.toLowerCase().split(',').map((token) => token.trim());
  const maxSnippetToken = tokens.find((token) => token.startsWith('max-snippet:'));
  const maxSnippet = maxSnippetToken ? Number(maxSnippetToken.split(':')[1]) : null;

  return {
    raw: raw.slice(0, 200),
    noindex: tokens.includes('noindex') || tokens.includes('none'),
    nofollow: tokens.includes('nofollow') || tokens.includes('none'),
    noarchive: tokens.includes('noarchive'),
    nosnippet: tokens.includes('nosnippet'),
    maxSnippet: maxSnippet !== null && Number.isFinite(maxSnippet) ? maxSnippet : null,
  };
}

function authorOf(blocks: readonly unknown[], meta: Map<string, string>): string | null {
  for (const node of walkNodes(blocks)) {
    if (node['author']) {
      const name = textOf(node['author']);
      if (name) return name.slice(0, 200);
    }
  }
  return meta.get('author')?.slice(0, 200) ?? meta.get('article:author')?.slice(0, 200) ?? null;
}

function publisherOf(blocks: readonly unknown[], meta: Map<string, string>): string | null {
  for (const node of walkNodes(blocks)) {
    if (node['publisher']) {
      const name = textOf(node['publisher']);
      if (name) return name.slice(0, 200);
    }
  }
  for (const node of walkNodes(blocks)) {
    if (typesOf(node).some((type) => type === 'Organization' || type === 'LocalBusiness')) {
      const name = textOf(node['name']);
      if (name) return name.slice(0, 200);
    }
  }
  return meta.get('og:site_name')?.slice(0, 200) ?? null;
}

function dateOf(
  blocks: readonly unknown[],
  meta: Map<string, string>,
  which: 'published' | 'modified',
): string | null {
  const keys = which === 'published'
    ? ['datePublished', 'dateCreated', 'uploadDate']
    : ['dateModified'];
  for (const node of walkNodes(blocks)) {
    for (const key of keys) {
      const value = node[key];
      if (typeof value === 'string' && value.trim().length > 0) return value.trim().slice(0, 40);
    }
  }
  const metaKeys = which === 'published'
    ? ['article:published_time', 'datepublished', 'date']
    : ['article:modified_time', 'datemodified', 'last-modified'];
  for (const key of metaKeys) {
    const value = meta.get(key);
    if (value) return value.slice(0, 40);
  }
  return null;
}

function entitySignals(blocks: readonly unknown[], meta: Map<string, string>): EntitySignals {
  const organizationNames = new Set<string>();
  const sameAs = new Set<string>();
  const telephones = new Set<string>();
  const addresses = new Set<string>();
  const schemaTypes = new Set<string>();

  for (const node of walkNodes(blocks)) {
    for (const type of typesOf(node)) schemaTypes.add(type);

    const isOrganizationLike = typesOf(node).some((type) =>
      type === 'Organization' || type === 'LocalBusiness' || type === 'Corporation' ||
      type.endsWith('Business') || type.endsWith('Store') || type === 'Restaurant');

    if (isOrganizationLike) {
      const name = textOf(node['name']);
      if (name) organizationNames.add(name.slice(0, 200));
      const phone = textOf(node['telephone']);
      if (phone) telephones.add(phone.slice(0, 60));
      const address = node['address'];
      if (address) {
        const formatted = formatAddress(address);
        if (formatted) addresses.add(formatted);
      }
    }

    const same = node['sameAs'];
    if (typeof same === 'string') sameAs.add(same.slice(0, 300));
    else if (Array.isArray(same)) {
      for (const item of same) if (typeof item === 'string') sameAs.add(item.slice(0, 300));
    }
  }

  const siteName = meta.get('og:site_name');
  if (siteName) organizationNames.add(siteName.slice(0, 200));

  return {
    organizationNames: [...organizationNames].slice(0, 20),
    sameAs: [...sameAs].slice(0, 40),
    telephones: [...telephones].slice(0, 10),
    addresses: [...addresses].slice(0, 10),
    schemaTypes: [...schemaTypes].slice(0, 40),
  };
}

function formatAddress(value: unknown): string | null {
  if (typeof value === 'string') return value.trim().slice(0, 300) || null;
  if (value === null || typeof value !== 'object') return null;
  const node = value as Record<string, unknown>;
  const parts = ['streetAddress', 'addressLocality', 'addressRegion', 'postalCode', 'addressCountry']
    .map((key) => textOf(node[key]))
    .filter((part): part is string => part !== null);
  return parts.length > 0 ? parts.join(', ').slice(0, 300) : null;
}

/** Page URLs worth adding to the frontier, from one page's links. */
export function crawlableLinks(page: PageData): string[] {
  if (page.robots.nofollow) return [];
  return page.links
    .filter((link) => link.internal && !link.nofollow && !looksLikeAsset(link.url))
    .map((link) => link.url);
}
