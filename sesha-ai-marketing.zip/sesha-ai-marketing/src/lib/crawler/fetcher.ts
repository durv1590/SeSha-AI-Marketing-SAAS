/**
 * The safe fetcher — the only thing in the product that opens a socket to an
 * address a user chose.
 *
 * WHY NOT `fetch`
 * `fetch` resolves the hostname itself, inside the socket layer, with no way to
 * pin the address the policy approved. That makes DNS rebinding unavoidable: the
 * check runs on one answer and the connection uses another. `node:http` and
 * `node:https` accept a `lookup` function, which is the hook that closes the
 * gap — the socket is handed the address `resolver.ts` already approved and
 * cannot perform a second resolution.
 *
 * WHAT ELSE THIS ENFORCES
 *  · redirects are followed manually, and EVERY hop is re-validated from
 *    scratch: URL policy, hostname policy, fresh resolution, address policy;
 *  · the response body is capped and the connection destroyed the moment the cap
 *    is passed, so a 10 GB response cannot exhaust memory;
 *  · a wall-clock timeout covers the whole request, not just the socket idle
 *    time, because a server that trickles one byte a second never goes idle;
 *  · only text is read. A `Content-Type` that is not HTML, XML or plain text is
 *    refused before the body is consumed.
 */

import { request as httpRequest, type IncomingMessage } from 'node:http';
import { request as httpsRequest } from 'node:https';

import { formatIp } from './ip-policy';
import { resolveHost, type LookupFn } from './resolver';
import { checkUrl } from './url-policy';

export const USER_AGENT =
  'SeShaBot/1.0 (+https://seshaaimarketing.com/bot; website audit on behalf of the site owner)';

export const DEFAULT_TIMEOUT_MS = 15_000;
export const DEFAULT_MAX_BYTES = 2_000_000;
export const DEFAULT_MAX_REDIRECTS = 5;

export interface FetchOptions {
  readonly timeoutMs?: number;
  readonly maxBytes?: number;
  readonly maxRedirects?: number;
  /** Accept header; defaults to HTML. */
  readonly accept?: string;
  /** Injected in tests. */
  readonly lookup?: LookupFn;
  readonly transport?: Transport;
}

export interface FetchedPage {
  readonly url: string;
  /** The URL originally requested, before redirects. */
  readonly requestedUrl: string;
  readonly status: number;
  readonly headers: Readonly<Record<string, string>>;
  readonly body: string;
  readonly contentType: string;
  readonly bytes: number;
  /** True when the body hit the cap and was cut short. */
  readonly truncated: boolean;
  readonly redirects: readonly string[];
  readonly durationMs: number;
  /** The address actually connected to, recorded for the audit trail. */
  readonly address: string;
  readonly https: boolean;
}

export type FetchFailureCode =
  | 'blocked'
  | 'invalid_url'
  | 'not_found'
  | 'dns_error'
  | 'timeout'
  | 'too_large'
  | 'too_many_redirects'
  | 'unsupported_type'
  | 'http_error'
  | 'network_error';

export interface FetchFailure {
  readonly ok: false;
  readonly code: FetchFailureCode;
  readonly reason: string;
  readonly status?: number;
  readonly url: string;
}

export type FetchResult = ({ readonly ok: true } & FetchedPage) | FetchFailure;

/** Seam for tests: one low-level request, already pinned to an address. */
export interface Transport {
  (request: TransportRequest): Promise<TransportResponse>;
}

export interface TransportRequest {
  readonly url: string;
  readonly address: string;
  readonly family: 4 | 6;
  readonly headers: Readonly<Record<string, string>>;
  readonly timeoutMs: number;
  readonly maxBytes: number;
}

export interface TransportResponse {
  readonly status: number;
  readonly headers: Readonly<Record<string, string>>;
  readonly body: string;
  readonly bytes: number;
  readonly truncated: boolean;
}

const TEXTUAL_TYPES = [
  'text/html',
  'application/xhtml+xml',
  'text/plain',
  'text/xml',
  'application/xml',
  'application/rss+xml',
  'application/atom+xml',
  'text/robots',
];

function isTextual(contentType: string): boolean {
  const type = contentType.split(';')[0]?.trim().toLowerCase() ?? '';
  if (type.length === 0) return true; // absent header: read it and find out
  return TEXTUAL_TYPES.includes(type) || type.startsWith('text/');
}

/**
 * Fetches one URL safely, following redirects with full re-validation.
 *
 * Returns a failure object rather than throwing, because every caller is a
 * crawl loop that must record the outcome and carry on rather than unwind.
 */
export async function safeFetch(target: string, options: FetchOptions = {}): Promise<FetchResult> {
  const maxRedirects = options.maxRedirects ?? DEFAULT_MAX_REDIRECTS;
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const maxBytes = options.maxBytes ?? DEFAULT_MAX_BYTES;
  const transport = options.transport ?? nodeTransport;

  const startedAt = Date.now();
  const redirects: string[] = [];
  const seen = new Set<string>();
  let current = target;

  for (let hop = 0; hop <= maxRedirects; hop += 1) {
    // EVERY hop is validated from scratch. A redirect is attacker-controlled
    // input exactly as much as the original URL was.
    const urlVerdict = checkUrl(current);
    if (!urlVerdict.ok) {
      return {
        ok: false,
        code: hop === 0 ? 'invalid_url' : 'blocked',
        reason: hop === 0 ? urlVerdict.reason : `A redirect pointed somewhere we will not follow: ${urlVerdict.reason}`,
        url: current,
      };
    }
    const url = urlVerdict.url;

    // A redirect loop that alternates between two URLs never exceeds the hop
    // count per URL, so cycles are detected separately.
    if (seen.has(url.toString())) {
      return { ok: false, code: 'too_many_redirects', reason: 'The redirects form a loop.', url: current };
    }
    seen.add(url.toString());

    const resolved = await resolveHost(url.hostname, {
      ...(options.lookup ? { lookup: options.lookup } : {}),
    });
    if (!resolved.ok) {
      return {
        ok: false,
        code: resolved.code === 'blocked' ? 'blocked' : resolved.code,
        reason: resolved.reason,
        url: current,
      };
    }

    const elapsed = Date.now() - startedAt;
    const remaining = timeoutMs - elapsed;
    if (remaining <= 0) {
      return { ok: false, code: 'timeout', reason: 'The request timed out.', url: current };
    }

    const address = formatIp(resolved.host.pinned);
    let response: TransportResponse;
    try {
      response = await transport({
        url: url.toString(),
        address,
        family: resolved.host.pinned.version,
        headers: {
          'User-Agent': USER_AGENT,
          Accept: options.accept ?? 'text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.1',
          'Accept-Language': 'en',
          // No cookies are ever sent or stored: a crawl must see the page a
          // search engine sees, and carrying credentials between hosts on a
          // redirect is how a crawler leaks them.
          'Accept-Encoding': 'identity',
        },
        timeoutMs: remaining,
        maxBytes,
      });
    } catch (error) {
      const code = (error as { code?: string }).code;
      if (code === 'ETIMEDOUT' || code === 'TIMEOUT') {
        return { ok: false, code: 'timeout', reason: 'The request timed out.', url: current };
      }
      if (code === 'ERR_TOO_LARGE') {
        return {
          ok: false,
          code: 'too_large',
          reason: `The response was larger than the ${maxBytes.toLocaleString()}-byte limit.`,
          url: current,
        };
      }
      return {
        ok: false,
        code: 'network_error',
        reason: 'The server could not be reached.',
        url: current,
      };
    }

    const location = response.headers['location'];
    if (isRedirect(response.status) && location) {
      if (hop === maxRedirects) {
        return {
          ok: false,
          code: 'too_many_redirects',
          reason: `More than ${maxRedirects} redirects.`,
          url: current,
        };
      }
      // Resolve relative to the URL we just fetched, then loop — which
      // re-validates it from the top.
      const next = checkUrl(location, url.toString());
      if (!next.ok) {
        return {
          ok: false,
          code: 'blocked',
          reason: `A redirect pointed somewhere we will not follow: ${next.reason}`,
          url: location,
        };
      }
      redirects.push(url.toString());
      current = next.url.toString();
      continue;
    }

    const contentType = response.headers['content-type'] ?? '';
    if (!isTextual(contentType)) {
      return {
        ok: false,
        code: 'unsupported_type',
        reason: `That is a ${contentType.split(';')[0] ?? 'binary'} file, not a web page.`,
        status: response.status,
        url: url.toString(),
      };
    }

    return {
      ok: true,
      url: url.toString(),
      requestedUrl: target,
      status: response.status,
      headers: response.headers,
      body: response.body,
      contentType,
      bytes: response.bytes,
      truncated: response.truncated,
      redirects,
      durationMs: Date.now() - startedAt,
      address,
      https: url.protocol === 'https:',
    };
  }

  return {
    ok: false,
    code: 'too_many_redirects',
    reason: `More than ${maxRedirects} redirects.`,
    url: current,
  };
}

function isRedirect(status: number): boolean {
  return status === 301 || status === 302 || status === 303 || status === 307 || status === 308;
}

/* -------------------------------------------------------------------------- */
/* The Node transport                                                         */
/* -------------------------------------------------------------------------- */

/**
 * One request over `node:http`/`node:https`, pinned to a pre-approved address.
 *
 * The `lookup` option is the whole point: it returns the address the policy
 * approved and never consults DNS, so the socket connects where the check ran.
 * `Host` is set from the URL so virtual hosting still works.
 */
export const nodeTransport: Transport = async (req) => {
  const url = new URL(req.url);
  const secure = url.protocol === 'https:';
  const send = secure ? httpsRequest : httpRequest;

  return new Promise<TransportResponse>((resolve, reject) => {
    let settled = false;
    let wallClock: ReturnType<typeof setTimeout> | undefined;

    const finish = (fn: () => void) => {
      if (settled) return;
      settled = true;
      if (wallClock) clearTimeout(wallClock);
      fn();
    };

    const clientRequest = send(
      {
        protocol: url.protocol,
        hostname: url.hostname,
        port: url.port || (secure ? 443 : 80),
        path: `${url.pathname}${url.search}`,
        method: 'GET',
        headers: { ...req.headers, Host: url.host },
        // Redirects are handled by safeFetch so each hop is re-validated.
        // There is no autoFollow here to turn off; node never follows.
        //
        // THIS IS THE SOCKET-INACTIVITY TIMEOUT, AND IT IS NOT ENOUGH ON ITS
        // OWN. It fires only when nothing arrives for `timeoutMs`; a server
        // sending one byte every fourteen seconds against a fifteen-second
        // limit resets it forever and the request never ends. The wall-clock
        // timer below is what actually bounds the request. Both are kept: this
        // one frees a genuinely dead socket promptly, which the wall clock
        // would otherwise sit on for the full budget.
        timeout: req.timeoutMs,
        // THE PIN. The socket is given the approved address and performs no
        // lookup of its own, so the name cannot resolve to anything else
        // between the policy check and the connection.
        //
        // NODE CALLS THIS WITH `{ all: true }`, and then the callback MUST be
        // given an ARRAY of `{ address, family }`. Handing it a bare string
        // fails with `ERR_INVALID_IP_ADDRESS: undefined` — which is what the
        // first test to exercise this hook with a real hostname discovered in
        // Phase 8. Until then every crawler test injected a fake transport, and
        // the two that used the real one passed an IP literal as the hostname,
        // which makes Node skip `lookup` altogether. So the pin had never run.
        //
        // Both callback forms are honoured, because `all` is not contractual:
        // the agent sets it today and a future Node need not.
        lookup: ((
          _hostname: string,
          options: { readonly all?: boolean },
          callback: (
            error: NodeJS.ErrnoException | null,
            address: string | { address: string; family: number }[],
            family?: number,
          ) => void,
        ) => {
          if (options?.all) {
            callback(null, [{ address: req.address, family: req.family }]);
            return;
          }
          callback(null, req.address, req.family);
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
        }) as any,
        // A server presenting a certificate for a different name is not the
        // site we were asked to audit.
        servername: secure ? url.hostname : undefined,
      },
      (response: IncomingMessage) => {
        const headers: Record<string, string> = {};
        for (const [key, value] of Object.entries(response.headers)) {
          if (typeof value === 'string') headers[key.toLowerCase()] = value;
          else if (Array.isArray(value)) headers[key.toLowerCase()] = value.join(', ');
        }

        // A declared length over the cap is refused before a byte is read.
        const declared = Number(headers['content-length'] ?? '0');
        if (Number.isFinite(declared) && declared > req.maxBytes) {
          response.destroy();
          clientRequest.destroy();
          const error = new Error('response too large');
          (error as { code?: string }).code = 'ERR_TOO_LARGE';
          finish(() => reject(error));
          return;
        }

        const chunks: Buffer[] = [];
        let bytes = 0;
        let truncated = false;

        response.on('data', (chunk: Buffer) => {
          bytes += chunk.length;
          if (bytes > req.maxBytes) {
            // Cut the connection rather than buffering the rest. An undeclared
            // length is the case the Content-Length check above cannot cover.
            truncated = true;
            const keep = req.maxBytes - (bytes - chunk.length);
            if (keep > 0) chunks.push(chunk.subarray(0, keep));
            response.destroy();
            clientRequest.destroy();
            finish(() =>
              resolve({
                status: response.statusCode ?? 0,
                headers,
                body: Buffer.concat(chunks).toString('utf8'),
                bytes: req.maxBytes,
                truncated: true,
              }),
            );
            return;
          }
          chunks.push(chunk);
        });

        response.on('end', () => {
          finish(() =>
            resolve({
              status: response.statusCode ?? 0,
              headers,
              body: Buffer.concat(chunks).toString('utf8'),
              bytes,
              truncated,
            }),
          );
        });

        response.on('error', (error) => finish(() => reject(error)));
      },
    );

    clientRequest.on('timeout', () => {
      clientRequest.destroy();
      const error = new Error('request timed out');
      (error as { code?: string }).code = 'ETIMEDOUT';
      finish(() => reject(error));
    });

    /**
     * THE WALL CLOCK. The defence against a slow-drip server.
     *
     * The file header has claimed since Phase 4 that "a wall-clock timeout
     * covers the whole request, not just the socket idle time, because a server
     * that trickles one byte a second never goes idle" — and until Phase 8 the
     * only timer was the socket-inactivity one, which is precisely the timer
     * that a trickling server defeats. The comment described the intent; this
     * timer implements it.
     *
     * `unref()` so a pending crawl timer cannot hold the process open.
     */
    wallClock = setTimeout(() => {
      clientRequest.destroy();
      const error = new Error('request exceeded its time budget');
      (error as { code?: string }).code = 'ETIMEDOUT';
      finish(() => reject(error));
    }, req.timeoutMs);
    wallClock.unref?.();

    clientRequest.on('error', (error) => finish(() => reject(error)));
    clientRequest.end();
  });
};
