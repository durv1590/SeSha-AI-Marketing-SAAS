/**
 * Public surface of the crawler.
 *
 * Importing from here rather than from the individual files keeps the security
 * boundary visible: `safeFetch` is the only exported way to make a request, and
 * it cannot be called without the policy checks running first.
 */

export {
  checkAddress,
  checkHostname,
  formatIp,
  isAllowedAddress,
  parseIp,
  parseIpv4,
  parseIpv6,
  blockedRangeLabels,
  type AddressVerdict,
  type HostVerdict,
  type ParsedIp,
} from './ip-policy';

export {
  ALLOWED_PROTOCOLS,
  MAX_URL_LENGTH,
  checkUrl,
  looksLikeAsset,
  normalizeUrl,
  sameSite,
  type UrlVerdict,
} from './url-policy';

export {
  DNS_TIMEOUT_MS,
  resolveHost,
  type LookupFn,
  type ResolveVerdict,
  type ResolvedHost,
} from './resolver';

export {
  DEFAULT_MAX_BYTES,
  DEFAULT_MAX_REDIRECTS,
  DEFAULT_TIMEOUT_MS,
  USER_AGENT,
  nodeTransport,
  safeFetch,
  type FetchFailure,
  type FetchOptions,
  type FetchResult,
  type FetchedPage,
  type Transport,
  type TransportRequest,
  type TransportResponse,
} from './fetcher';

export {
  BOT_NAME,
  BOT_USER_AGENT,
  NO_ROBOTS,
  ROBOTS_UNAVAILABLE,
  crawlDelayMs,
  describeRobots,
  groupFor,
  isAllowed,
  parseRobots,
  robotsUrlFor,
  type Robots,
  type RobotsDecision,
  type RobotsGroup,
  type RobotsRule,
} from './robots';

export {
  EMPTY_SITEMAP,
  MAX_SITEMAP_INDEX_ENTRIES,
  MAX_SITEMAP_URLS,
  defaultSitemapUrls,
  parseLastModified,
  parseSitemap,
  type ParsedSitemap,
  type SitemapEntry,
} from './sitemap';

export {
  LIMITS,
  attribute,
  countWords,
  crawlableLinks,
  decodeEntities,
  extractPage,
  isQuestion,
  parseRobotsMeta,
  type EntitySignals,
  type ExtractedFaq,
  type ExtractedImage,
  type ExtractedLink,
  type PageData,
  type RobotsDirectives,
} from './parse';

export {
  CrawlQueue,
  DEFAULT_LIMITS,
  MAX_ALLOWED_PAGES,
  absoluteMaxPages,
  PolitenessGate,
  limitsForPlan,
  resolveLimits,
  type CrawlLimits,
  type DiscoverySource,
  type QueueItem,
  type SkipReason,
} from './queue';

export {
  crawlSite,
  type CrawlGrant,
  type CrawlOptions,
  type CrawlOutcome,
  type CrawlProgress,
  type CrawlReport,
  type PageFailure,
  type RobotsReport,
  type SitemapReport,
} from './crawler';
