/**
 * The crawl frontier.
 *
 * Everything here exists to keep the crawler from becoming a problem for the
 * site it is auditing, or for the deployment it runs in:
 *
 *  · MAX PAGES is a hard stop, checked on dequeue as well as enqueue, because a
 *    budget that is only checked when adding can be overshot by work already in
 *    flight.
 *  · DEDUPLICATION is on the normalised URL, so one page reached five ways is
 *    fetched once.
 *  · A POLITENESS DELAY is enforced between requests to the same host, honouring
 *    `Crawl-delay` when the site sets one.
 *  · CONCURRENCY is capped, so a crawl is never more load than a handful of
 *    simultaneous visitors.
 *  · DEPTH is bounded, which also bounds the shape of what gets crawled: a
 *    sprawling site contributes its top levels rather than one deep rabbit hole.
 *
 * The queue is a priority queue by depth, so the crawl is breadth-first. On a
 * site larger than the page budget, breadth-first returns the pages nearest the
 * home page — which are the ones an audit should look at — where depth-first
 * would return one arbitrary branch.
 */

import { normalizeUrl } from './url-policy';
import type { PlanId } from '@/content/plans';

export interface CrawlLimits {
  readonly maxPages: number;
  readonly maxDepth: number;
  readonly concurrency: number;
  /** Minimum gap between two requests to the same host. */
  readonly delayMs: number;
  /** Upper bound on a `Crawl-delay` the site asks for. */
  readonly maxDelayMs: number;
  readonly maxBytesPerPage: number;
  readonly timeoutMsPerPage: number;
  /** Whole-crawl wall-clock ceiling. */
  readonly totalTimeoutMs: number;
}

/**
 * The default limits, chosen to be polite rather than fast.
 *
 * 2 concurrent requests with a 500 ms gap is roughly one request per second —
 * less load than a single human browsing. These are the values a plan can lower
 * but not raise (see `limitsForPlan`).
 */
export const DEFAULT_LIMITS: CrawlLimits = {
  maxPages: 50,
  maxDepth: 3,
  concurrency: 2,
  delayMs: 500,
  maxDelayMs: 10_000,
  maxBytesPerPage: 2_000_000,
  timeoutMsPerPage: 15_000,
  totalTimeoutMs: 10 * 60 * 1_000,
};

/** The built-in absolute stop. No plan and no request can exceed it. */
export const MAX_ALLOWED_PAGES = 500;

/**
 * The deployment's own cap, which may be LOWER than the built-in one.
 *
 * `CRAWLER_MAX_PAGES` narrows; a value above `MAX_ALLOWED_PAGES`, or a value
 * that is not a positive number, is ignored rather than honoured. There is no
 * variable that raises the cap.
 */
export function absoluteMaxPages(): number {
  const configured = Number(process.env.CRAWLER_MAX_PAGES);
  if (!Number.isFinite(configured) || configured < 1) return MAX_ALLOWED_PAGES;
  return Math.min(Math.floor(configured), MAX_ALLOWED_PAGES);
}

/**
 * Per-plan ceilings for ONE crawl. A consent record may ask for fewer, never more.
 *
 * These are crawl MECHANICS — how deep, how wide, how fast a single run may go —
 * and are deliberately not among the eleven plan limits in `content/plans.ts`,
 * which count how many crawls a month. The two answer different questions and a
 * shared number would answer neither.
 */
export function limitsForPlan(plan: PlanId): CrawlLimits {
  switch (plan) {
    case 'agency':
      return { ...DEFAULT_LIMITS, maxPages: 300, maxDepth: 5, concurrency: 3 };
    case 'business':
      return { ...DEFAULT_LIMITS, maxPages: 150, maxDepth: 4 };
    case 'pro':
      return DEFAULT_LIMITS;
    case 'free':
      // Deliberately small. A free account crawling 50 pages of someone else's
      // site is the shape of abuse this product has to not be useful for.
      return { ...DEFAULT_LIMITS, maxPages: 10, maxDepth: 2, concurrency: 1 };
  }
}

/** Clamps a requested budget to the plan ceiling. Never raises it. */
export function resolveLimits(
  plan: PlanId,
  requested?: Partial<Pick<CrawlLimits, 'maxPages' | 'maxDepth'>>,
): CrawlLimits {
  const ceiling = limitsForPlan(plan);
  const maxPages = Math.min(
    Math.max(1, requested?.maxPages ?? ceiling.maxPages),
    ceiling.maxPages,
    absoluteMaxPages(),
  );
  const maxDepth = Math.min(Math.max(0, requested?.maxDepth ?? ceiling.maxDepth), ceiling.maxDepth);
  return { ...ceiling, maxPages, maxDepth };
}

export type DiscoverySource = 'seed' | 'sitemap' | 'link' | 'robots';

export interface QueueItem {
  readonly url: string;
  readonly depth: number;
  readonly source: DiscoverySource;
}

export type SkipReason =
  | 'duplicate'
  | 'too_deep'
  | 'budget_full'
  | 'invalid'
  | 'off_site'
  | 'robots';

export interface EnqueueResult {
  readonly accepted: boolean;
  readonly reason?: SkipReason;
}

/**
 * The frontier.
 *
 * `seen` holds every URL ever offered, accepted or not, so an offer that was
 * rejected once is not reconsidered on every page that links to it.
 */
export class CrawlQueue {
  private readonly buckets = new Map<number, QueueItem[]>();
  private readonly seen = new Set<string>();
  private readonly limits: CrawlLimits;
  private dequeued = 0;
  private readonly skipped = new Map<SkipReason, number>();

  constructor(limits: CrawlLimits) {
    this.limits = limits;
  }

  /** Offers a URL. Returns whether it was accepted, and if not, why. */
  enqueue(url: string, depth: number, source: DiscoverySource): EnqueueResult {
    let normalized: string;
    try {
      normalized = normalizeUrl(url);
    } catch {
      return this.skip('invalid');
    }

    if (this.seen.has(normalized)) return this.skip('duplicate');
    if (depth > this.limits.maxDepth) {
      this.seen.add(normalized);
      return this.skip('too_deep');
    }
    if (this.totalKnown() >= this.limits.maxPages) return this.skip('budget_full');

    this.seen.add(normalized);
    const bucket = this.buckets.get(depth);
    if (bucket) bucket.push({ url: normalized, depth, source });
    else this.buckets.set(depth, [{ url: normalized, depth, source }]);
    return { accepted: true };
  }

  /** Records a URL as known without queuing it — used for robots denials. */
  reject(url: string, reason: SkipReason): void {
    try {
      this.seen.add(normalizeUrl(url));
    } catch {
      /* an unparseable URL cannot be remembered, and will be rejected again */
    }
    this.skip(reason);
  }

  /**
   * Takes the next URL, shallowest first.
   *
   * Returns null once the page budget is spent, EVEN IF the queue still holds
   * items. The budget is about how many pages we fetch, not how many we found.
   */
  dequeue(): QueueItem | null {
    if (this.dequeued >= this.limits.maxPages) return null;

    const depths = [...this.buckets.keys()].sort((a, b) => a - b);
    for (const depth of depths) {
      const bucket = this.buckets.get(depth)!;
      const item = bucket.shift();
      if (bucket.length === 0) this.buckets.delete(depth);
      if (item) {
        this.dequeued += 1;
        return item;
      }
    }
    return null;
  }

  /** Queued plus already taken — what the budget is measured against. */
  private totalKnown(): number {
    let queued = 0;
    for (const bucket of this.buckets.values()) queued += bucket.length;
    return queued + this.dequeued;
  }

  private skip(reason: SkipReason): EnqueueResult {
    this.skipped.set(reason, (this.skipped.get(reason) ?? 0) + 1);
    return { accepted: false, reason };
  }

  get pending(): number {
    let total = 0;
    for (const bucket of this.buckets.values()) total += bucket.length;
    return total;
  }

  get processed(): number {
    return this.dequeued;
  }

  get budgetRemaining(): number {
    return Math.max(0, this.limits.maxPages - this.dequeued);
  }

  get isEmpty(): boolean {
    return this.pending === 0;
  }

  skipCounts(): Readonly<Record<string, number>> {
    return Object.fromEntries(this.skipped);
  }
}

/**
 * Per-host politeness.
 *
 * `wait()` resolves when it is this host's turn. The next permitted time is
 * reserved at the moment of the call rather than after the sleep, so two
 * concurrent workers cannot both observe "it is time" and fire together.
 */
export class PolitenessGate {
  private readonly nextAllowedAt = new Map<string, number>();

  constructor(
    private readonly delayMs: number,
    private readonly now: () => number = Date.now,
    private readonly sleep: (ms: number) => Promise<void> = (ms) =>
      new Promise((resolve) => setTimeout(resolve, ms)),
  ) {}

  async wait(host: string): Promise<number> {
    const current = this.now();
    const earliest = this.nextAllowedAt.get(host) ?? 0;
    const waitMs = Math.max(0, earliest - current);
    // Reserve before sleeping: otherwise both callers see the same `earliest`.
    this.nextAllowedAt.set(host, Math.max(current, earliest) + this.delayMs);
    if (waitMs > 0) await this.sleep(waitMs);
    return waitMs;
  }
}
