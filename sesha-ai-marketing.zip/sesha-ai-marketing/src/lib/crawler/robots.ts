/**
 * robots.txt — parsing and compliance.
 *
 * Written from the REP (RFC 9309) plus the conventions Google and Bing actually
 * implement, because a crawler that follows the spec but not the conventions
 * gets the wrong answer on real sites.
 *
 * Decisions worth stating:
 *  · The MOST SPECIFIC matching rule wins, measured by pattern length, and Allow
 *    wins a tie. That is the documented behaviour and it is what site owners
 *    expect when they write `Disallow: /admin` then `Allow: /admin/public`.
 *  · `*` and `$` wildcards are supported, because most real robots.txt files use
 *    them and ignoring them makes the crawler over-fetch.
 *  · A group for `SeShaBot` wins over `*` entirely — rules are not merged.
 *  · FAIL CLOSED on an ambiguous fetch. A 5xx or a timeout on robots.txt means
 *    "do not crawl", not "crawl everything"; a 404 means there are no rules,
 *    which genuinely does mean "crawl".
 */

import { USER_AGENT } from './fetcher';

export const BOT_NAME = 'seshabot';

export interface RobotsRule {
  readonly allow: boolean;
  readonly pattern: string;
}

export interface RobotsGroup {
  readonly agents: readonly string[];
  readonly rules: readonly RobotsRule[];
  readonly crawlDelaySeconds: number | null;
}

export interface Robots {
  readonly groups: readonly RobotsGroup[];
  readonly sitemaps: readonly string[];
  /** How the rules were obtained, which decides how much to trust them. */
  readonly source: 'fetched' | 'absent' | 'unavailable';
  /** When `source` is 'unavailable', nothing may be crawled. */
  readonly allowAll: boolean;
}

export const NO_ROBOTS: Robots = { groups: [], sitemaps: [], source: 'absent', allowAll: true };

/** robots.txt could not be read. Nothing is crawled: fail closed. */
export const ROBOTS_UNAVAILABLE: Robots = {
  groups: [],
  sitemaps: [],
  source: 'unavailable',
  allowAll: false,
};

const MAX_ROBOTS_BYTES = 500_000;
const MAX_RULES_PER_GROUP = 1_000;

/**
 * Parses a robots.txt body.
 *
 * Tolerant by design: unknown directives, BOMs, CRLF, comments and stray
 * whitespace are all normal in the wild and none of them should invalidate the
 * rules that follow.
 */
export function parseRobots(body: string): Robots {
  const text = body.slice(0, MAX_ROBOTS_BYTES).replace(/^﻿/, '');
  const groups: RobotsGroup[] = [];
  const sitemaps: string[] = [];

  let agents: string[] = [];
  let rules: RobotsRule[] = [];
  let crawlDelay: number | null = null;
  // A blank line does not end a group; a User-agent line after a rule does.
  let collectingAgents = false;

  function flush() {
    if (agents.length > 0) {
      groups.push({ agents: [...agents], rules: [...rules], crawlDelaySeconds: crawlDelay });
    }
    agents = [];
    rules = [];
    crawlDelay = null;
  }

  for (const rawLine of text.split(/\r?\n/)) {
    const withoutComment = rawLine.split('#')[0] ?? '';
    const line = withoutComment.trim();
    if (line.length === 0) continue;

    const colon = line.indexOf(':');
    if (colon === -1) continue;

    const field = line.slice(0, colon).trim().toLowerCase();
    const value = line.slice(colon + 1).trim();

    switch (field) {
      case 'user-agent': {
        // Consecutive User-agent lines share one group of rules.
        if (!collectingAgents) {
          flush();
          collectingAgents = true;
        }
        if (value.length > 0) agents.push(value.toLowerCase());
        break;
      }
      case 'disallow':
      case 'allow': {
        collectingAgents = false;
        if (agents.length === 0) break; // a rule with no group is meaningless
        if (rules.length >= MAX_RULES_PER_GROUP) break;
        // "Disallow:" with an empty value means allow everything, which is the
        // same as having no disallow rule at all.
        if (field === 'disallow' && value.length === 0) break;
        rules.push({ allow: field === 'allow', pattern: value });
        break;
      }
      case 'crawl-delay': {
        collectingAgents = false;
        const seconds = Number(value.replace(',', '.'));
        // Recorded as asked for, even when absurd. `crawlDelayMs` clamps it to
        // the crawl's own window; rejecting it here would silently fall back to
        // the FLOOR, which is the opposite of what the site requested.
        if (Number.isFinite(seconds) && seconds >= 0) crawlDelay = Math.min(seconds, 86_400);
        break;
      }
      case 'sitemap': {
        // Sitemap is a site-level directive, not part of any group.
        if (value.length > 0 && sitemaps.length < 100) sitemaps.push(value);
        break;
      }
      default:
        break;
    }
  }
  flush();

  return { groups, sitemaps, source: 'fetched', allowAll: false };
}

/**
 * Picks the group that applies to us.
 *
 * An exact match on our bot name wins. Otherwise the longest matching prefix of
 * our name wins (so `SeSha` matches `SeShaBot`), and `*` is the fallback.
 * Groups are NOT merged: a site that addresses us specifically has said
 * everything it wants to say to us.
 */
export function groupFor(robots: Robots, agent: string = BOT_NAME): RobotsGroup | null {
  const name = agent.toLowerCase();
  let best: RobotsGroup | null = null;
  let bestLength = -1;
  let wildcard: RobotsGroup | null = null;

  for (const group of robots.groups) {
    for (const candidate of group.agents) {
      if (candidate === '*') {
        wildcard ??= group;
        continue;
      }
      if (name.startsWith(candidate) && candidate.length > bestLength) {
        best = group;
        bestLength = candidate.length;
      }
    }
  }
  return best ?? wildcard;
}

/**
 * Turns a robots pattern into a regular expression.
 *
 * Everything except `*` and `$` is escaped, so a pattern containing regex
 * metacharacters — which paths routinely do — cannot change the meaning of the
 * expression or cause catastrophic backtracking.
 */
function patternToRegExp(pattern: string): RegExp {
  let source = '^';
  for (let index = 0; index < pattern.length; index += 1) {
    const character = pattern[index]!;
    if (character === '*') {
      source += '[\\s\\S]*';
    } else if (character === '$' && index === pattern.length - 1) {
      source += '$';
    } else {
      source += character.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
  }
  return new RegExp(source);
}

export interface RobotsDecision {
  readonly allowed: boolean;
  /** The rule that decided it, for the audit trail. */
  readonly rule: string | null;
  readonly reason: string;
}

/**
 * Decides whether one path may be fetched.
 *
 * The path compared is the path-and-query, which is what robots.txt patterns are
 * written against.
 */
export function isAllowed(robots: Robots, url: string, agent: string = BOT_NAME): RobotsDecision {
  if (robots.source === 'unavailable') {
    return {
      allowed: false,
      rule: null,
      // Fail closed, and say why, because this denial is not the site's fault.
      reason: 'robots.txt could not be read, so nothing is crawled.',
    };
  }
  if (robots.source === 'absent' || robots.groups.length === 0) {
    return { allowed: true, rule: null, reason: 'No robots.txt rules apply.' };
  }

  const group = groupFor(robots, agent);
  if (!group || group.rules.length === 0) {
    return { allowed: true, rule: null, reason: 'No rules for this crawler.' };
  }

  let path: string;
  try {
    const parsed = new URL(url);
    path = `${parsed.pathname}${parsed.search}`;
  } catch {
    path = url;
  }

  let decision: RobotsRule | null = null;
  for (const rule of group.rules) {
    if (!patternToRegExp(rule.pattern).test(path)) continue;
    if (
      decision === null ||
      rule.pattern.length > decision.pattern.length ||
      // Allow wins a tie of equal specificity, as Google documents.
      (rule.pattern.length === decision.pattern.length && rule.allow && !decision.allow)
    ) {
      decision = rule;
    }
  }

  if (!decision) {
    return { allowed: true, rule: null, reason: 'No rule matches this path.' };
  }
  return {
    allowed: decision.allow,
    rule: `${decision.allow ? 'Allow' : 'Disallow'}: ${decision.pattern}`,
    reason: decision.allow
      ? `Allowed by "Allow: ${decision.pattern}".`
      : `Disallowed by "Disallow: ${decision.pattern}".`,
  };
}

/** The crawl delay the site asked for, clamped to something sane. */
export function crawlDelayMs(robots: Robots, floorMs: number, ceilingMs: number): number {
  const group = groupFor(robots);
  const requested = group?.crawlDelaySeconds;
  if (requested === null || requested === undefined) return floorMs;
  return Math.min(Math.max(requested * 1_000, floorMs), ceilingMs);
}

export function robotsUrlFor(siteUrl: string): string {
  const url = new URL(siteUrl);
  return `${url.protocol}//${url.host}/robots.txt`;
}

/** What the audit reports about robots.txt. */
export function describeRobots(robots: Robots): string {
  switch (robots.source) {
    case 'absent':
      return 'No robots.txt was found. Crawlers will treat the whole site as crawlable.';
    case 'unavailable':
      return 'robots.txt could not be read, so this crawl did not proceed.';
    default: {
      const group = groupFor(robots);
      const count = group?.rules.length ?? 0;
      const delay = group?.crawlDelaySeconds;
      const parts = [`robots.txt found with ${count} rule${count === 1 ? '' : 's'} that apply to this crawler`];
      if (delay !== null && delay !== undefined) parts.push(`a crawl delay of ${delay}s`);
      if (robots.sitemaps.length > 0) {
        parts.push(`${robots.sitemaps.length} sitemap reference${robots.sitemaps.length === 1 ? '' : 's'}`);
      }
      return `${parts.join(', ')}.`;
    }
  }
}

/** The User-Agent string site owners should allow-list. Documented for the UI. */
export const BOT_USER_AGENT = USER_AGENT;
