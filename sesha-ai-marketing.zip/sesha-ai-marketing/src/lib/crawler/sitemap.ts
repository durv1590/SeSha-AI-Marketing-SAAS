/**
 * Sitemap parsing — `sitemap.xml`, sitemap indexes, and the plain-text form.
 *
 * No XML library. These documents have a flat, well-known shape, and a general
 * XML parser brings entity expansion with it — "billion laughs" and external
 * entity (XXE) attacks both arrive through a document the crawler was asked to
 * fetch. This reader extracts the handful of elements the sitemap protocol
 * defines and ignores everything else, so there is no entity resolver to abuse.
 *
 * Every extracted URL is still validated by `url-policy` before it is queued; a
 * sitemap is attacker-controlled input like any other fetched document.
 */

import { checkUrl, normalizeUrl, sameSite } from './url-policy';

export const MAX_SITEMAP_URLS = 50_000;
export const MAX_SITEMAP_INDEX_ENTRIES = 50;
export const MAX_SITEMAP_BYTES = 10_000_000;

export interface SitemapEntry {
  readonly url: string;
  readonly lastModified: string | null;
  readonly changeFrequency: string | null;
  readonly priority: number | null;
}

export interface ParsedSitemap {
  readonly kind: 'urlset' | 'sitemapindex' | 'text' | 'unknown';
  readonly entries: readonly SitemapEntry[];
  /** Child sitemap URLs, when this is an index. */
  readonly sitemaps: readonly string[];
  /** True when the document had more entries than the cap. */
  readonly truncated: boolean;
}

export const EMPTY_SITEMAP: ParsedSitemap = {
  kind: 'unknown',
  entries: [],
  sitemaps: [],
  truncated: false,
};

/** Decodes the five XML predefined entities and numeric character references. */
function decodeXmlText(input: string): string {
  return input
    .replace(/&#x([0-9a-fA-F]{1,6});/g, (_, hex: string) => safeCodePoint(Number.parseInt(hex, 16)))
    .replace(/&#(\d{1,7});/g, (_, dec: string) => safeCodePoint(Number(dec)))
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    // Ampersand last, so "&amp;lt;" decodes to "&lt;" and not to "<".
    .replace(/&amp;/g, '&');
}

function safeCodePoint(value: number): string {
  if (!Number.isInteger(value) || value < 0 || value > 0x10ffff) return '';
  // Surrogate halves are not valid standalone code points.
  if (value >= 0xd800 && value <= 0xdfff) return '';
  try {
    return String.fromCodePoint(value);
  } catch {
    return '';
  }
}

/** Pulls the text of the first `<tag>` inside a fragment. */
function firstTag(fragment: string, tag: string): string | null {
  const match = new RegExp(`<(?:\\w+:)?${tag}\\b[^>]*>([\\s\\S]*?)</(?:\\w+:)?${tag}>`, 'i').exec(fragment);
  if (!match?.[1]) return null;
  const value = decodeXmlText(match[1].replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')).trim();
  return value.length > 0 ? value : null;
}

function blocks(xml: string, tag: string): string[] {
  const pattern = new RegExp(`<(?:\\w+:)?${tag}\\b[^>]*>([\\s\\S]*?)</(?:\\w+:)?${tag}>`, 'gi');
  const out: string[] = [];
  for (const match of xml.matchAll(pattern)) {
    if (match[1]) out.push(match[1]);
    if (out.length >= MAX_SITEMAP_URLS + 1) break;
  }
  return out;
}

/**
 * Parses a sitemap document.
 *
 * `base` is the URL the document was fetched from, used to resolve relative
 * locations and to reject cross-site entries — a sitemap may only list URLs on
 * its own site, and honouring one that points elsewhere turns the crawler into
 * an open relay for someone else's link list.
 */
export function parseSitemap(body: string, base: string): ParsedSitemap {
  const text = body.slice(0, MAX_SITEMAP_BYTES);

  // A DOCTYPE or ENTITY declaration has no legitimate place in a sitemap and is
  // the vehicle for XXE and entity-expansion attacks. Refuse the document
  // rather than try to parse around it.
  if (/<!DOCTYPE/i.test(text) || /<!ENTITY/i.test(text)) {
    return EMPTY_SITEMAP;
  }

  const looksXml = /<\s*(?:\w+:)?(?:urlset|sitemapindex)\b/i.test(text);

  if (!looksXml) {
    // The plain-text form: one URL per line.
    const entries: SitemapEntry[] = [];
    let truncated = false;
    for (const line of text.split(/\r?\n/)) {
      const candidate = line.trim();
      if (candidate.length === 0 || candidate.startsWith('#')) continue;
      if (entries.length >= MAX_SITEMAP_URLS) {
        truncated = true;
        break;
      }
      const accepted = acceptUrl(candidate, base);
      if (accepted) {
        entries.push({ url: accepted, lastModified: null, changeFrequency: null, priority: null });
      }
    }
    return entries.length > 0
      ? { kind: 'text', entries, sitemaps: [], truncated }
      : EMPTY_SITEMAP;
  }

  const isIndex = /<\s*(?:\w+:)?sitemapindex\b/i.test(text);

  if (isIndex) {
    const sitemaps: string[] = [];
    for (const block of blocks(text, 'sitemap')) {
      if (sitemaps.length >= MAX_SITEMAP_INDEX_ENTRIES) break;
      const loc = firstTag(block, 'loc');
      if (!loc) continue;
      const accepted = acceptUrl(loc, base);
      if (accepted) sitemaps.push(accepted);
    }
    return { kind: 'sitemapindex', entries: [], sitemaps, truncated: false };
  }

  const entries: SitemapEntry[] = [];
  let truncated = false;
  for (const block of blocks(text, 'url')) {
    if (entries.length >= MAX_SITEMAP_URLS) {
      truncated = true;
      break;
    }
    const loc = firstTag(block, 'loc');
    if (!loc) continue;
    const accepted = acceptUrl(loc, base);
    if (!accepted) continue;

    const priorityText = firstTag(block, 'priority');
    const priority = priorityText === null ? null : Number(priorityText);

    entries.push({
      url: accepted,
      lastModified: firstTag(block, 'lastmod'),
      changeFrequency: firstTag(block, 'changefreq')?.toLowerCase() ?? null,
      priority: priority !== null && Number.isFinite(priority) && priority >= 0 && priority <= 1
        ? priority
        : null,
    });
  }

  return { kind: 'urlset', entries, sitemaps: [], truncated };
}

/** Validates, normalises and same-site checks one sitemap URL. */
function acceptUrl(candidate: string, base: string): string | null {
  const verdict = checkUrl(candidate, base);
  if (!verdict.ok) return null;
  if (!sameSite(verdict.url, base)) return null;
  try {
    return normalizeUrl(verdict.url);
  } catch {
    return null;
  }
}

/** The conventional locations to try when robots.txt names no sitemap. */
export function defaultSitemapUrls(siteUrl: string): string[] {
  const url = new URL(siteUrl);
  const origin = `${url.protocol}//${url.host}`;
  return [
    `${origin}/sitemap.xml`,
    `${origin}/sitemap_index.xml`,
    `${origin}/sitemap-index.xml`,
    `${origin}/sitemap.txt`,
  ];
}

/** Parses a sitemap `lastmod` into a date, tolerating the date-only form. */
export function parseLastModified(value: string | null): Date | null {
  if (!value) return null;
  const trimmed = value.trim();
  if (!/^\d{4}-\d{2}-\d{2}([T ]|$)/.test(trimmed)) return null;
  const parsed = new Date(trimmed.length === 10 ? `${trimmed}T00:00:00Z` : trimmed);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}
