/**
 * DNS resolution with policy enforcement.
 *
 * THE ATTACK THIS EXISTS TO STOP
 * Checking a hostname against a blocklist and then handing the hostname to
 * `fetch` is not a defence. Between the check and the connection the name is
 * resolved AGAIN, and an attacker who controls the DNS record can answer
 * `93.184.216.34` the first time and `127.0.0.1` the second. That is DNS
 * rebinding, and it defeats every string-level blocklist ever written.
 *
 * The fix is to make the check and the connection use the same answer:
 *   1. resolve the name here, once;
 *   2. check every address returned — not just the first;
 *   3. hand the CHECKED ADDRESS to the socket, never the name again.
 *
 * Step 3 lives in `fetcher.ts`, which passes a custom `lookup` to Node's HTTP
 * agent so the socket cannot perform its own resolution.
 *
 * WHY ALL ADDRESSES, NOT THE FIRST
 * A name can return several A and AAAA records, and which one the stack picks is
 * not ours to predict. If any answer is private, the name is refused outright.
 * Allowing the public ones and hoping the stack agrees is a race.
 */

import { lookup as dnsLookup, type LookupAddress } from 'node:dns';
import { promisify } from 'node:util';

import { checkAddress, checkHostname, formatIp, parseIp, type ParsedIp } from './ip-policy';

const resolveAll = promisify(dnsLookup) as (
  hostname: string,
  options: { all: true; verbatim: true },
) => Promise<LookupAddress[]>;

export interface ResolvedHost {
  readonly hostname: string;
  /** Every address the name resolved to, all of them policy-approved. */
  readonly addresses: readonly ParsedIp[];
  /** The address the socket must connect to. */
  readonly pinned: ParsedIp;
}

export type ResolveVerdict =
  | { readonly ok: true; readonly host: ResolvedHost }
  | { readonly ok: false; readonly reason: string; readonly code: ResolveFailure };

export type ResolveFailure = 'blocked' | 'not_found' | 'dns_error';

/** Injectable so the tests can exercise the policy without a network. */
export type LookupFn = (hostname: string) => Promise<readonly { address: string; family: number }[]>;

const defaultLookup: LookupFn = async (hostname) => resolveAll(hostname, { all: true, verbatim: true });

export interface ResolveOptions {
  readonly lookup?: LookupFn;
  readonly timeoutMs?: number;
}

export const DNS_TIMEOUT_MS = 5_000;

/**
 * Resolves a hostname and refuses it unless EVERY answer is allowed.
 *
 * An IP literal short-circuits: there is nothing to resolve, and re-resolving a
 * literal is how a "helpful" normalisation step reintroduces the bug.
 */
export async function resolveHost(
  hostname: string,
  options: ResolveOptions = {},
): Promise<ResolveVerdict> {
  const host = hostname.trim().toLowerCase().replace(/\.$/, '');

  const nameVerdict = checkHostname(host);
  if (!nameVerdict.allowed) {
    return { ok: false, code: 'blocked', reason: nameVerdict.reason ?? 'hostname is not allowed' };
  }

  const literal = parseIp(host);
  if (literal) {
    // checkHostname already approved it; this is belt and braces, and it keeps
    // the single exit path for "an address the crawler may use".
    const verdict = checkAddress(literal);
    if (!verdict.allowed) return { ok: false, code: 'blocked', reason: verdict.reason };
    return { ok: true, host: { hostname: host, addresses: [literal], pinned: literal } };
  }

  const lookup = options.lookup ?? defaultLookup;
  const timeoutMs = options.timeoutMs ?? DNS_TIMEOUT_MS;

  let answers: readonly { address: string; family: number }[];
  try {
    answers = await withTimeout(lookup(host), timeoutMs);
  } catch (error) {
    const code = (error as { code?: string }).code;
    if (code === 'ENOTFOUND' || code === 'ENODATA' || code === 'EAI_AGAIN') {
      return { ok: false, code: 'not_found', reason: 'That domain could not be found.' };
    }
    if (code === 'ETIMEDOUT') {
      return { ok: false, code: 'dns_error', reason: 'Looking up that domain timed out.' };
    }
    return { ok: false, code: 'dns_error', reason: 'That domain could not be looked up.' };
  }

  if (answers.length === 0) {
    return { ok: false, code: 'not_found', reason: 'That domain has no address records.' };
  }

  const approved: ParsedIp[] = [];
  for (const answer of answers) {
    const parsed = parseIp(answer.address);
    if (!parsed) {
      // An answer we cannot parse is an answer we cannot vet. Default deny.
      return {
        ok: false,
        code: 'blocked',
        reason: `DNS returned an address that could not be parsed (${answer.address}).`,
      };
    }
    const verdict = checkAddress(parsed);
    if (!verdict.allowed) {
      // Naming the address matters: this is the message that tells an honest
      // user their domain points at a private host, and tells an auditor that
      // the check ran on the resolved answer rather than the name.
      return {
        ok: false,
        code: 'blocked',
        reason: `${host} resolves to ${formatIp(parsed)}, which is a ${verdict.reason}.`,
      };
    }
    approved.push(parsed);
  }

  return {
    ok: true,
    host: { hostname: host, addresses: approved, pinned: approved[0]! },
  };
}

async function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => {
          const error = new Error('DNS lookup timed out');
          (error as { code?: string }).code = 'ETIMEDOUT';
          reject(error);
        }, ms);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}
