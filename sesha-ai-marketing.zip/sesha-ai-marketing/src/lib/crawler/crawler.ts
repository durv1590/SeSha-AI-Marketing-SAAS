/**
 * The crawler — the pipeline from the brief, in order:
 *
 *   URL → validation → security checks → robots.txt → sitemap → crawl queue
 *       → fetch → parse → store → analyze
 *
 * `analyze` is the next stage (lib/seo, lib/aeo) and is deliberately not called
 * from here: a crawl produces facts, an audit produces opinions, and keeping
 * them apart means an audit can be re-run on stored pages without re-crawling
 * the site.
 *
 * CONSENT IS A PRECONDITION, NOT A SETTING
 * `crawlSite` takes an explicit grant and refuses without one. Phase 2 captured
 * consent with a scope, a page limit and a retention period; this is where that
 * record becomes load-bearing. The limits in the grant can only narrow the plan
 * ceiling, never widen it.
 *
 * CANCELLATION
 * Checked between pages rather than mid-request, so a cancelled crawl stops
 * promptly without abandoning a half-read response.
 */

import { safeFetch, type FetchOptions, type FetchResult } from './fetcher';
import { extractPage, crawlableLinks, type PageData } from './parse';
import { CrawlQueue, PolitenessGate, type CrawlLimits, type DiscoverySource } from './queue';
import {
  NO_ROBOTS,
  ROBOTS_UNAVAILABLE,
  crawlDelayMs,
  describeRobots,
  isAllowed,
  parseRobots,
  robotsUrlFor,
  type Robots,
} from './robots';
import { defaultSitemapUrls, parseSitemap, type ParsedSitemap } from './sitemap';
import { checkUrl, normalizeUrl, sameSite } from './url-policy';

export interface CrawlGrant {
  /** The site the user consented to have crawled. */
  readonly websiteUrl: string;
  readonly respectRobots: boolean;
  readonly maxPages: number;
  readonly grantedAt: Date;
}

export interface CrawlOptions {
  readonly limits: CrawlLimits;
  readonly fetchOptions?: FetchOptions;
  readonly now?: () => number;
  readonly sleep?: (ms: number) => Promise<void>;
  /** Called after every page so a job row can record progress. */
  readonly onProgress?: (progress: CrawlProgress) => void | Promise<void>;
  /** Polled between pages. Returning true stops the crawl cleanly. */
  readonly isCancelled?: () => boolean | Promise<boolean>;
}

export interface CrawlProgress {
  readonly fetched: number;
  readonly failed: number;
  readonly pending: number;
  readonly budget: number;
  readonly currentUrl: string | null;
}

export interface PageFailure {
  readonly url: string;
  readonly code: string;
  readonly reason: string;
  readonly status?: number;
  readonly depth: number;
}

export interface CrawlReport {
  readonly siteUrl: string;
  readonly startedAt: Date;
  readonly finishedAt: Date;
  readonly pages: readonly PageData[];
  readonly failures: readonly PageFailure[];
  readonly robots: RobotsReport;
  readonly sitemap: SitemapReport;
  readonly skipped: Readonly<Record<string, number>>;
  readonly limits: CrawlLimits;
  /** Set when the crawl stopped early, with the reason. */
  readonly stoppedEarly: string | null;
  readonly cancelled: boolean;
}

export interface RobotsReport {
  readonly url: string;
  readonly found: boolean;
  readonly readable: boolean;
  readonly respected: boolean;
  readonly summary: string;
  readonly sitemapsDeclared: readonly string[];
  readonly blockedCount: number;
  readonly crawlDelayMs: number;
}

export interface SitemapReport {
  readonly found: boolean;
  readonly urls: readonly string[];
  readonly locations: readonly string[];
  readonly kind: ParsedSitemap['kind'] | null;
  readonly truncated: boolean;
  readonly note: string;
}

export type CrawlOutcome =
  | { readonly ok: true; readonly report: CrawlReport }
  | { readonly ok: false; readonly code: string; readonly reason: string };

/**
 * Crawls one site.
 *
 * Never throws for an expected condition — a refused URL, an unreachable site,
 * an unreadable robots.txt are all outcomes a job row must record, not
 * exceptions for a caller to interpret.
 */
export async function crawlSite(grant: CrawlGrant, options: CrawlOptions): Promise<CrawlOutcome> {
  const now = options.now ?? (() => Date.now());
  const startedAt = new Date(now());
  const deadline = now() + options.limits.totalTimeoutMs;

  /* --- 1 + 2. validation and security --------------------------------------- */

  const seedVerdict = checkUrl(grant.websiteUrl);
  if (!seedVerdict.ok) {
    return { ok: false, code: 'invalid_url', reason: seedVerdict.reason };
  }
  const seedUrl = normalizeUrl(seedVerdict.url);
  const origin = `${seedVerdict.url.protocol}//${seedVerdict.url.host}`;

  const fetchOptions: FetchOptions = {
    maxBytes: options.limits.maxBytesPerPage,
    timeoutMs: options.limits.timeoutMsPerPage,
    ...options.fetchOptions,
  };

  /* --- 3. robots.txt -------------------------------------------------------- */

  const robotsUrl = robotsUrlFor(seedUrl);
  let robots: Robots = NO_ROBOTS;
  let robotsFound = false;
  let robotsReadable = true;

  if (grant.respectRobots) {
    const fetched = await safeFetch(robotsUrl, { ...fetchOptions, accept: 'text/plain,*/*;q=0.5' });
    if (fetched.ok && fetched.status === 200) {
      robots = parseRobots(fetched.body);
      robotsFound = true;
    } else if (fetched.ok && fetched.status === 404) {
      // A 404 genuinely means "no rules". This is the one case where absence
      // permits crawling.
      robots = NO_ROBOTS;
    } else if (!fetched.ok && (fetched.code === 'blocked' || fetched.code === 'invalid_url')) {
      // The site itself is not crawlable; say so rather than blaming robots.
      return { ok: false, code: fetched.code, reason: fetched.reason };
    } else {
      // A 5xx, a timeout or a network error is ambiguous, and ambiguity means
      // stop. Crawling a site whose robots.txt we could not read risks ignoring
      // rules the owner did set.
      robots = ROBOTS_UNAVAILABLE;
      robotsReadable = false;
    }
  }

  const delayMs = grant.respectRobots
    ? crawlDelayMs(robots, options.limits.delayMs, options.limits.maxDelayMs)
    : options.limits.delayMs;

  if (robots.source === 'unavailable') {
    return {
      ok: false,
      code: 'robots_unavailable',
      reason:
        'robots.txt could not be read, so the crawl was not started. This is deliberate: without it we cannot tell which pages the site allows crawling.',
    };
  }

  const effectiveLimits: CrawlLimits = {
    ...options.limits,
    maxPages: Math.min(options.limits.maxPages, grant.maxPages),
    delayMs,
  };

  const queue = new CrawlQueue(effectiveLimits);
  const gate = new PolitenessGate(delayMs, now, options.sleep);

  const robotsBlocked: string[] = [];
  const allow = (url: string): boolean => {
    if (!grant.respectRobots) return true;
    const decision = isAllowed(robots, url);
    if (!decision.allowed) robotsBlocked.push(url);
    return decision.allowed;
  };

  /* --- 4. sitemap ----------------------------------------------------------- */

  // robots.txt governs the sitemap fetch as well: `Disallow: /` disallows
  // /sitemap.xml like any other path, and fetching it anyway would be a
  // compliance gap dressed up as discovery.
  const sitemap = await discoverSitemap(origin, robots, fetchOptions, effectiveLimits.maxPages, allow);

  /* --- 5. crawl queue ------------------------------------------------------- */

  if (allow(seedUrl)) queue.enqueue(seedUrl, 0, 'seed');
  else queue.reject(seedUrl, 'robots');

  for (const url of sitemap.urls) {
    if (!sameSite(url, seedUrl)) continue;
    if (!allow(url)) {
      queue.reject(url, 'robots');
      continue;
    }
    // Sitemap URLs are depth 1: the site is telling us they matter, but the home
    // page still goes first.
    queue.enqueue(url, 1, 'sitemap');
  }

  /* --- 6 + 7 + 8. fetch, parse, collect ------------------------------------- */

  const pages: PageData[] = [];
  const failures: PageFailure[] = [];
  let stoppedEarly: string | null = null;
  let cancelled = false;

  const workers = Math.max(1, Math.min(effectiveLimits.concurrency, 4));
  let currentUrl: string | null = null;

  async function report(): Promise<void> {
    if (!options.onProgress) return;
    await options.onProgress({
      fetched: pages.length,
      failed: failures.length,
      pending: queue.pending,
      budget: effectiveLimits.maxPages,
      currentUrl,
    });
  }

  async function worker(): Promise<void> {
    for (;;) {
      if (cancelled || stoppedEarly) return;

      if (options.isCancelled && (await options.isCancelled())) {
        cancelled = true;
        return;
      }
      if (now() > deadline) {
        stoppedEarly = 'The crawl reached its time limit.';
        return;
      }

      const item = queue.dequeue();
      if (!item) return;

      currentUrl = item.url;
      await gate.wait(new URL(item.url).host);

      const result: FetchResult = await safeFetch(item.url, fetchOptions);

      if (!result.ok) {
        failures.push({
          url: item.url,
          code: result.code,
          reason: result.reason,
          ...(result.status === undefined ? {} : { status: result.status }),
          depth: item.depth,
        });
        await report();
        continue;
      }

      const page = extractPage({
        url: result.url,
        html: result.body,
        status: result.status,
        bytes: result.bytes,
        responseTimeMs: result.durationMs,
        truncated: result.truncated,
        crawledAt: new Date(now()),
      });

      if (result.status >= 400) {
        failures.push({
          url: item.url,
          code: 'http_error',
          reason: `The server returned ${result.status}.`,
          status: result.status,
          depth: item.depth,
        });
      } else {
        pages.push(page);
      }

      // 9. discover more. A redirect can land us off-site, in which case its
      // links are not ours to follow.
      if (sameSite(result.url, seedUrl) && item.depth < effectiveLimits.maxDepth) {
        for (const link of crawlableLinks(page)) {
          if (!sameSite(link, seedUrl)) continue;
          if (!allow(link)) {
            queue.reject(link, 'robots');
            continue;
          }
          queue.enqueue(link, item.depth + 1, 'link');
        }
      }

      await report();
    }
  }

  await Promise.all(Array.from({ length: workers }, () => worker()));
  currentUrl = null;

  // Two ways a crawl can be truncated by the budget: URLs left in the queue, or
  // URLs refused at the door because the budget was already committed. Both mean
  // the audit covers part of the site, and the report has to say so.
  const skippedForBudget = queue.skipCounts().budget_full ?? 0;
  if (!stoppedEarly && !cancelled && (queue.pending > 0 || skippedForBudget > 0)) {
    const notFetched = queue.pending + skippedForBudget;
    stoppedEarly =
      `The page limit of ${effectiveLimits.maxPages} was reached. ` +
      `${notFetched} further URL${notFetched === 1 ? ' was' : 's were'} found but not read, ` +
      'so this audit covers part of the site.';
  }

  return {
    ok: true,
    report: {
      siteUrl: seedUrl,
      startedAt,
      finishedAt: new Date(now()),
      pages,
      failures,
      robots: {
        url: robotsUrl,
        found: robotsFound,
        readable: robotsReadable,
        respected: grant.respectRobots,
        summary: grant.respectRobots
          ? describeRobots(robots)
          : 'robots.txt was not consulted, because this crawl was configured to ignore it.',
        sitemapsDeclared: robots.sitemaps,
        blockedCount: new Set(robotsBlocked).size,
        crawlDelayMs: delayMs,
      },
      sitemap,
      skipped: queue.skipCounts(),
      limits: effectiveLimits,
      stoppedEarly,
      cancelled,
    },
  };
}

/**
 * Finds and reads the sitemap.
 *
 * robots.txt is the authoritative place to declare one; the conventional
 * locations are only tried when it does not. An index is followed one level
 * deep, which covers the overwhelming majority of real sites without letting a
 * nested index chain become unbounded.
 */
async function discoverSitemap(
  origin: string,
  robots: Robots,
  fetchOptions: FetchOptions,
  urlCap: number,
  allow: (url: string) => boolean,
): Promise<SitemapReport> {
  const candidates = robots.sitemaps.length > 0
    ? robots.sitemaps.slice(0, 10)
    : defaultSitemapUrls(origin);

  const collected: string[] = [];
  const locations: string[] = [];
  let kind: ParsedSitemap['kind'] | null = null;
  let truncated = false;

  const accept = 'application/xml,text/xml,text/plain;q=0.9,*/*;q=0.1';

  for (const candidate of candidates) {
    if (collected.length >= urlCap * 4) break;

    const verdict = checkUrl(candidate);
    if (!verdict.ok) continue;
    if (!allow(verdict.url.toString())) continue;

    const fetched = await safeFetch(verdict.url.toString(), { ...fetchOptions, accept });
    if (!fetched.ok || fetched.status !== 200) continue;

    const parsed = parseSitemap(fetched.body, fetched.url);
    if (parsed.entries.length === 0 && parsed.sitemaps.length === 0) continue;

    locations.push(fetched.url);
    kind ??= parsed.kind;
    truncated = truncated || parsed.truncated;

    for (const entry of parsed.entries) collected.push(entry.url);

    // One level of index following. A sitemap index of sitemap indexes is
    // pathological and not worth the unbounded recursion.
    for (const child of parsed.sitemaps.slice(0, 10)) {
      if (collected.length >= urlCap * 4) break;
      if (!allow(child)) continue;
      const childFetched = await safeFetch(child, { ...fetchOptions, accept });
      if (!childFetched.ok || childFetched.status !== 200) continue;
      const childParsed = parseSitemap(childFetched.body, childFetched.url);
      locations.push(childFetched.url);
      truncated = truncated || childParsed.truncated;
      for (const entry of childParsed.entries) collected.push(entry.url);
    }

    // Only the first sitemap that yields anything is used when robots.txt was
    // silent — the conventional locations are alternatives, not a set.
    if (robots.sitemaps.length === 0) break;
  }

  const unique = [...new Set(collected)];

  return {
    found: locations.length > 0,
    urls: unique,
    locations,
    kind,
    truncated,
    note: locations.length === 0
      ? robots.sitemaps.length > 0
        ? 'robots.txt declares a sitemap, but it could not be read.'
        : 'No sitemap was found at robots.txt or the conventional locations.'
      : `${unique.length} URL${unique.length === 1 ? '' : 's'} found across ${locations.length} sitemap file${locations.length === 1 ? '' : 's'}.`,
  };
}
