import type { MetadataRoute } from 'next';

import { postsNewestFirst } from '@/content/blog';
import { absoluteUrl } from '@/lib/seo/core';
import { sitemapRoutes } from '@/lib/routes';

/**
 * XML sitemap, generated from the route registry.
 *
 * Generated rather than hand-maintained on purpose: a new page registered in
 * lib/routes.ts is in the sitemap automatically, and a page that is not
 * registered cannot silently go missing from it.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();

  const staticEntries: MetadataRoute.Sitemap = sitemapRoutes().map((route) => ({
    url: absoluteUrl(route.path),
    lastModified: now,
    changeFrequency: route.sitemap.changeFrequency,
    priority: route.sitemap.priority,
  }));

  const postEntries: MetadataRoute.Sitemap = postsNewestFirst.map((post) => ({
    url: absoluteUrl(`/blog/${post.slug}`),
    lastModified: new Date(`${post.updatedAt}T00:00:00Z`),
    changeFrequency: 'monthly',
    priority: 0.6,
  }));

  return [...staticEntries, ...postEntries];
}
