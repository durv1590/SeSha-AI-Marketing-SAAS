import type { Metadata } from 'next';

import { ValidatorWorkspace, type HistoryEntry } from '@/components/schema/validator-workspace';
import { Badge } from '@/components/ui/badge';
import { getCurrentSession } from '@/lib/auth/current-session';
import { can } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { listValidationHistory } from '@/lib/schema/service';
import { SUPPORTED_SCHEMA_TYPES, VALIDATOR_VERSION } from '@/lib/schema-validator';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Schema Validator',
  description:
    'Validate JSON-LD, Microdata and RDFa, see what each finding actually means, and compare with your last check.',
  path: '/app/schema-validator',
  noindex: true,
});

export const dynamic = 'force-dynamic';

/**
 * The workspace validator.
 *
 * The same engine as the public tool, with the three things an authenticated
 * project makes possible: a stored history, a comparison against the last check of
 * the same source, and generation from the project's own verified data.
 */
export default async function WorkspaceValidatorPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);
  const project = projects[0] ?? null;

  let history: HistoryEntry[] = [];
  let crawledPages: string[] = [];

  if (project) {
    const rows = await listValidationHistory({ db }, tenant, project.id, 15);
    history = rows.map((row) => ({
      id: row.id,
      checkedAt: row.checkedAt.toISOString(),
      sourceKind: row.sourceKind,
      sourceUrl: row.sourceUrl,
      validatorVersion: row.validatorVersion,
      overallStatus: row.overallStatus,
      counts: row.counts,
      typesFound: row.typesFound,
    }));

    const crawl = await db.crawls.findLatest(tenant.organizationId, project.id);
    if (crawl) {
      const pages = await db.crawls.listPages(tenant.organizationId, crawl.id);
      crawledPages = pages.map((page) => page.url).slice(0, 50);
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Schema Validator</h1>
        <Badge tone="success">Available</Badge>
      </div>

      <p className="max-w-3xl text-base leading-relaxed text-fg-muted">
        Checks JSON-LD, Microdata and RDFa against {SUPPORTED_SCHEMA_TYPES.length} schema.org types.
        Findings are grouped by what they actually are — whether the markup is valid, what search
        engines&rsquo; published requirements ask for, ordinary on-page advice, and whether an AI
        system can read your facts. Those are four different things and this tool will not present one
        as another. Validator version {VALIDATOR_VERSION}.
      </p>

      <ValidatorWorkspace
        projectId={project?.id ?? null}
        crawledPages={crawledPages}
        history={history}
        canUse={can(session.user.role, 'content:create')}
      />
    </div>
  );
}
