import type { Metadata } from 'next';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { getCurrentSession } from '@/lib/auth/current-session';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Brand Kit',
  description: 'The brand voice and marketing profile captured for your workspace.',
  path: '/app/brand-kit',
  noindex: true,
});

export const dynamic = 'force-dynamic';

/**
 * Brand kit — shows the marketing profile captured during onboarding.
 *
 * Read-only in Phase 2: editing lands with Content Studio, which is what
 * actually consumes these rules. Displaying an editable form now would imply
 * the values feed something today.
 */
export default async function BrandKitPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };
  const projects = await listProjects({ db }, tenant);
  const project = projects[0];
  const profile = project
    ? await db.marketingProfiles.findByProject(session.user.organizationId, project.id)
    : null;

  return (
    <div className="flex max-w-3xl flex-col gap-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Brand Kit</h1>
        <Badge tone="success">Available</Badge>
      </div>

      {!profile ? (
        <Card className="p-6">
          <p className="text-sm text-fg-muted">
            No marketing profile yet. Complete onboarding to create one.
          </p>
          <Button href="/onboarding" size="sm" className="mt-4">
            Complete set-up
          </Button>
        </Card>
      ) : (
        <>
          <Card className="p-6">
            <div className="flex items-center justify-between gap-4">
              <h2 className="font-semibold tracking-tight">Profile completeness</h2>
              <span className="text-2xl font-semibold">{profile.completeness}%</span>
            </div>
            <div
              role="progressbar"
              aria-valuenow={profile.completeness}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label="Marketing profile completeness"
              className="mt-3 h-2 overflow-hidden rounded-full bg-bg-muted"
            >
              <div
                className="h-full rounded-full bg-primary"
                style={{ width: `${profile.completeness}%` }}
              />
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="font-semibold tracking-tight">Brand voice</h2>
            <div className="mt-3 flex flex-wrap gap-2">
              {((profile.brandVoice as { tones?: string[] }).tones ?? []).map((tone) => (
                <Badge key={tone} tone="brand">
                  {tone}
                </Badge>
              ))}
            </div>
            {(profile.brandVoice as { notes?: string }).notes ? (
              <p className="mt-4 text-sm leading-relaxed text-fg-muted">
                {(profile.brandVoice as { notes?: string }).notes}
              </p>
            ) : null}
          </Card>

          <Card className="p-6">
            <h2 className="font-semibold tracking-tight">Audience and offering</h2>
            <dl className="mt-4 flex flex-col gap-4 text-sm">
              <div>
                <dt className="text-xs uppercase tracking-[0.08em] text-fg-subtle">
                  Target audience
                </dt>
                <dd className="mt-1 leading-relaxed text-fg-muted">{profile.targetAudience}</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-[0.08em] text-fg-subtle">
                  Products and services
                </dt>
                <dd className="mt-1 leading-relaxed text-fg-muted">{profile.productsServices}</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-[0.08em] text-fg-subtle">Price range</dt>
                <dd className="mt-1 capitalize text-fg-muted">
                  {profile.priceRange?.replace('_', ' ')}
                </dd>
              </div>
            </dl>
          </Card>

          <Card className="p-6">
            <h2 className="font-semibold tracking-tight">Goals and channels</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {profile.marketingGoals.map((goal) => (
                <Badge key={goal} tone="outline">
                  {goal.replace(/-/g, ' ')}
                </Badge>
              ))}
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {profile.marketingChannels.map((channel) => (
                <Badge key={channel} tone="neutral">
                  {channel.replace(/-/g, ' ')}
                </Badge>
              ))}
            </div>
          </Card>

          <p className="text-sm text-fg-muted">
            Editing arrives with Content Studio in Phase 3, which is the first module that consumes
            these rules.
          </p>
        </>
      )}
    </div>
  );
}
