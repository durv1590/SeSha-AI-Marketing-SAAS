import type { Metadata } from 'next';

import { AdPlanner, type AdPlanSummary } from '@/components/ads/ad-planner';
import { Badge } from '@/components/ui/badge';
import { getCurrentSession } from '@/lib/auth/current-session';
import { can } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { listAdPlans } from '@/lib/ads/service';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Campaigns',
  description:
    'Plan Google, Meta, Instagram, LinkedIn and YouTube campaigns against the platforms’ real limits.',
  path: '/app/campaigns',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function CampaignsPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);
  const project = projects[0] ?? null;

  let plans: AdPlanSummary[] = [];
  if (project && can(session.user.role, 'campaign:read')) {
    const rows = await listAdPlans({ db }, tenant, project.id);
    plans = rows.map((row) => ({
      id: row.id,
      platform: row.platform,
      objective: row.objective,
      campaignName: row.campaignName,
      reviewState: row.reviewState,
      reviewNote: row.reviewNote,
      problems: row.problems as AdPlanSummary['problems'],
      createdAt: row.createdAt.toISOString(),
    }));
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Campaigns</h1>
        <Badge tone="success">Available</Badge>
      </div>

      <p className="max-w-3xl text-base leading-relaxed text-fg-muted">
        Campaign plans for five platforms: objective, audience, headlines, descriptions, creative
        concepts, landing page, A/B ideas and a budget range that says what it is based on. No ad
        account is connected, so nothing here spends money or reports performance.
      </p>

      <AdPlanner plans={plans} />
    </div>
  );
}
