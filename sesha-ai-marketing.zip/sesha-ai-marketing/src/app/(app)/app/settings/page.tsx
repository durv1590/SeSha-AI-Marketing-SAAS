import type { Metadata } from 'next';

import { DeleteAccountCard, ExportDataCard } from '@/components/app/account-settings';
import { NotificationPreferences } from '@/components/notifications/notification-preferences';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { getCurrentSession } from '@/lib/auth/current-session';
import { ROLE_DESCRIPTIONS, ROLE_LABELS, permissionsFor } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { emailIsConfigured } from '@/lib/email';
import { googleIsConfigured } from '@/lib/auth/oauth/google';
import { listProjects } from '@/lib/workspace/service';
import { preferenceView } from '@/lib/notifications/service';
import { CHANNELS, CHANNEL_IDS } from '@/lib/notifications/types';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Settings',
  description: 'Account, security, website access and workspace settings.',
  path: '/app/settings',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function SettingsPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const user = await db.users.findById(session.user.id);
  const sessions = await db.sessions.listActiveForUser(session.user.id, new Date());
  const oauthAccounts = await db.oauth.listForUser(session.user.id);

  const projects = await listProjects(
    { db },
    {
      userId: session.user.id,
      organizationId: session.user.organizationId,
      role: session.user.role,
    },
  );

  const notificationPreferences = await preferenceView(
    { db },
    {
      userId: session.user.id,
      organizationId: session.user.organizationId,
      role: session.user.role,
    },
  );
  const consent = projects[0]
    ? await db.crawlConsents.findActiveForProject(session.user.organizationId, projects[0].id)
    : null;

  return (
    <div className="flex max-w-3xl flex-col gap-6">
      <h1 className="text-2xl font-semibold tracking-tight">Settings</h1>

      <Card className="p-6">
        <h2 className="font-semibold tracking-tight">Account</h2>
        <dl className="mt-4 flex flex-col gap-3 text-sm">
          <Row term="Name">{session.user.name ?? 'Not set'}</Row>
          <Row term="Email">
            {session.user.email}{' '}
            {session.user.emailVerifiedAt ? (
              <Badge tone="success">Confirmed</Badge>
            ) : (
              <Badge tone="warning">Unconfirmed</Badge>
            )}
          </Row>
          <Row term="Sign-in method">
            {user?.passwordHash ? 'Password' : ''}
            {user?.passwordHash && oauthAccounts.length > 0 ? ' + ' : ''}
            {oauthAccounts.length > 0 ? 'Google' : ''}
          </Row>
          <Row term="Active sessions">{sessions.length}</Row>
        </dl>
      </Card>

      <Card className="p-6">
        <h2 className="font-semibold tracking-tight">Your role</h2>
        <div className="mt-3 flex items-center gap-3">
          <Badge tone="brand">{ROLE_LABELS[session.user.role]}</Badge>
          <p className="text-sm text-fg-muted">{ROLE_DESCRIPTIONS[session.user.role]}</p>
        </div>
        <p className="mt-4 text-xs text-fg-subtle">
          {permissionsFor(session.user.role).length} permissions. Roles are enforced by the API and
          the database, not only by what this interface shows you.
        </p>
      </Card>

      <Card className="p-6">
        <h2 className="font-semibold tracking-tight">Website access</h2>
        {consent ? (
          <>
            <dl className="mt-4 flex flex-col gap-3 text-sm">
              <Row term="Site">{consent.websiteUrl}</Row>
              <Row term="Limit">{consent.maxPages} pages</Row>
              <Row term="Retention">{consent.retentionDays} days</Row>
              <Row term="robots.txt">{consent.respectRobots ? 'Respected' : 'Ignored'}</Row>
              <Row term="Granted">{consent.grantedAt.toISOString().slice(0, 10)}</Row>
            </dl>
            <p className="mt-4 text-sm text-fg-muted">
              You can withdraw this at any time. Withdrawal takes effect immediately and deletes
              anything collected.
            </p>
            <Button variant="secondary" size="sm" className="mt-4" href="/app/website-audit">
              Manage website access
            </Button>
          </>
        ) : (
          <p className="mt-3 text-sm text-fg-muted">
            You have not granted access to any website. Nothing will be fetched without it.
          </p>
        )}
      </Card>

      <Card className="p-6">
        <h2 className="font-semibold tracking-tight">Deployment configuration</h2>
        <p className="mt-2 text-sm text-fg-muted">
          What this deployment actually has switched on.
        </p>
        <dl className="mt-4 flex flex-col gap-3 text-sm">
          <Row term="Email delivery">
            {emailIsConfigured ? (
              <Badge tone="success">Configured</Badge>
            ) : (
              <Badge tone="warning">Not configured — links are logged, not sent</Badge>
            )}
          </Row>
          <Row term="Google sign-in">
            {googleIsConfigured() ? (
              <Badge tone="success">Configured</Badge>
            ) : (
              <Badge tone="neutral">Not configured</Badge>
            )}
          </Row>
          <Row term="Database">
            {process.env.DATABASE_URL ? (
              <Badge tone="success">PostgreSQL</Badge>
            ) : (
              <Badge tone="warning">In-memory — data is lost on restart</Badge>
            )}
          </Row>
        </dl>
      </Card>

      <Card className="p-6">
        <h2 className="text-lg font-semibold tracking-tight">Notifications</h2>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-fg-muted">
          These are yours, not your organization&rsquo;s: nobody else can read or change them. Two
          kinds cannot be switched off, and the reason is shown beside each rather than left as a
          greyed-out switch.
        </p>
        <div className="mt-4">
          <NotificationPreferences
            preferences={notificationPreferences.map((entry) => ({
              kind: entry.preference.kind,
              label: entry.label,
              description: entry.description,
              inApp: entry.preference.inApp,
              email: entry.preference.email,
              locked: entry.lockedReason !== undefined,
              lockedReason: entry.lockedReason ?? null,
            }))}
            channels={CHANNEL_IDS.map((id) => ({
              id,
              label: CHANNELS[id].label,
              available: CHANNELS[id].available,
              unavailableReason: CHANNELS[id].unavailableReason ?? null,
            }))}
          />
        </div>
      </Card>

      <ExportDataCard />
      <DeleteAccountCard hasPassword={Boolean(user?.passwordHash)} />
    </div>
  );
}

function Row({ term, children }: { readonly term: string; readonly children: React.ReactNode }) {
  return (
    <div className="grid gap-1 sm:grid-cols-[10rem_1fr]">
      <dt className="text-xs uppercase tracking-[0.08em] text-fg-subtle">{term}</dt>
      <dd className="flex flex-wrap items-center gap-2 text-fg-muted">{children}</dd>
    </div>
  );
}
