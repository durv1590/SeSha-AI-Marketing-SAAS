import type { Metadata } from 'next';

import { BillingPanel } from '@/components/app/billing-panel';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getCurrentSession } from '@/lib/auth/current-session';
import { can } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { billingView } from '@/lib/billing/service';
import {
  EVENT_LABEL,
  STATUS_EXPLANATION,
  STATUS_LABEL,
  STATUS_TONE,
  type SubscriptionEvent,
} from '@/lib/billing/types';
import { PLANS_BY_RANK } from '@/content/plans';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Plan & billing',
  description: 'Your plan, its limits, and the state of your subscription.',
  path: '/app/settings/billing',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function BillingSettingsPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const view = await billingView(
    { db: getDatabase() },
    {
      userId: session.user.id,
      organizationId: session.user.organizationId,
      role: session.user.role,
    },
  );

  const canManage = can(session.user.role, 'billing:manage');

  return (
    <div className="flex max-w-4xl flex-col gap-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Plan &amp; billing</h1>
          <p className="mt-1 text-sm text-fg-muted">
            What your plan allows, what state your subscription is in, and every change made to it.
          </p>
        </div>
        <Button href="/app/usage" variant="secondary" size="sm">
          Usage
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <CardTitle as="h2">Subscription</CardTitle>
            <Badge tone={STATUS_TONE[view.status]}>{STATUS_LABEL[view.status]}</Badge>
          </div>
          <CardDescription>{STATUS_EXPLANATION[view.status]}</CardDescription>
        </CardHeader>

        <dl className="grid gap-x-6 gap-y-3 px-6 py-4 text-sm sm:grid-cols-2">
          {view.trialEndsAt ? (
            <Row label="Trial ends">{formatDate(view.trialEndsAt)}</Row>
          ) : null}
          {view.currentPeriodEnd ? (
            <Row label={view.cancelAtPeriodEnd ? 'Access ends' : 'Renews'}>
              {formatDate(view.currentPeriodEnd)}
            </Row>
          ) : null}
          {view.pastDueSince ? (
            <Row label="Payment failed">{formatDate(view.pastDueSince)}</Row>
          ) : null}
          <Row label="Payment method">
            {view.paymentMethod
              ? `${view.paymentMethod.brand} ending ${view.paymentMethod.last4}${
                  view.paymentMethod.expiryMonth && view.paymentMethod.expiryYear
                    ? ` · expires ${String(view.paymentMethod.expiryMonth).padStart(2, '0')}/${view.paymentMethod.expiryYear}`
                    : ''
                }`
              : 'None on file.'}
          </Row>
        </dl>

        <p className="border-t border-border px-6 py-4 text-xs text-fg-subtle">
          SeSha stores the brand and last four digits only, so you can tell which card is on file.
          The number, expiry and CVV are entered on the provider&rsquo;s own page and never reach our
          servers or our database.
        </p>
      </Card>

      <BillingPanel
        currentPlan={view.plan}
        plans={PLANS_BY_RANK}
        providerConfigured={view.provider.configured}
        providerMessage={view.provider.message}
        cancelAtPeriodEnd={view.cancelAtPeriodEnd}
        canManage={canManage}
      />

      <Card>
        <CardHeader>
          <CardTitle as="h2">History</CardTitle>
          <CardDescription>
            Every subscription change, including the ones that were received and not applied.
          </CardDescription>
        </CardHeader>
        {view.history.length === 0 ? (
          <p className="px-6 pb-6 text-sm text-fg-muted">
            Nothing yet. Changes appear here as they happen.
          </p>
        ) : (
          <ul className="flex flex-col divide-y divide-border px-6 pb-6 text-sm">
            {view.history.map((entry, index) => (
              <li
                key={`${entry.event}-${entry.occurredAt}-${index}`}
                className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1 py-3"
              >
                <span className="text-fg">
                  {EVENT_LABEL[entry.event as SubscriptionEvent] ?? entry.event}
                  {entry.applied ? null : (
                    <span className="ml-2 text-xs text-fg-subtle">
                      Recorded, not applied{entry.note ? ` — ${entry.note}` : ''}
                    </span>
                  )}
                </span>
                <span className="text-xs tabular-nums text-fg-subtle">
                  {formatDate(entry.occurredAt)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function Row({ label, children }: { readonly label: string; readonly children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-0.5">
      <dt className="text-xs uppercase tracking-wide text-fg-subtle">{label}</dt>
      <dd className="text-fg">{children}</dd>
    </div>
  );
}

function formatDate(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  });
}
