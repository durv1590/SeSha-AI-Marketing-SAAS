import type { Metadata } from 'next';

import { MetricBoard, type ConnectionView, type MetricView } from '@/components/analytics/metric-board';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { getCurrentSession } from '@/lib/auth/current-session';
import { can } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { analyticsFor, connectionsFor } from '@/lib/analytics/service';
import { analyticsStatus } from '@/lib/analytics/connections';
import { METRIC_IDS } from '@/lib/analytics/metrics';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Analytics',
  description:
    'Every figure carries where it came from. What SeSha cannot measure is marked unavailable rather than estimated.',
  path: '/app/analytics',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function AnalyticsPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);
  const project = projects[0] ?? null;

  let metrics: MetricView[] = [];
  let connections: ConnectionView[] = [];
  let anyConnected = false;
  let explanation = analyticsStatus([]).message;
  let periodLabel = 'Last 30 days';

  if (project && can(session.user.role, 'analytics:read')) {
    const report = await analyticsFor({ db }, tenant, project.id);
    const states = await connectionsFor({ db }, tenant, project.id);
    const status = analyticsStatus(states);

    anyConnected = report.anyConnected;
    explanation = status.message;
    periodLabel = report.period.label;
    metrics = report.metrics.map((metric) => ({
      id: metric.id,
      label: metric.definition.label,
      description: metric.definition.description,
      group: metric.definition.group,
      higherIsBetter: metric.definition.higherIsBetter,
      value: metric.value,
      ...(metric.previous ? { previous: metric.previous } : {}),
    }));
    connections = states.map((state) => ({
      provider: state.provider,
      label: state.definition.label,
      connected: state.connected,
      howToConnect: state.definition.howToConnect,
      problem: state.problem ?? null,
    }));
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Analytics</h1>
        <Badge tone="success">Available</Badge>
      </div>

      <p className="max-w-3xl text-base leading-relaxed text-fg-muted">
        {METRIC_IDS.length} metrics, each labelled with where its figure came from: a connected
        account, your own records, your own website, or nothing at all. SeSha does not estimate a
        number it could measure, and does not show a zero in place of something it has not measured.
      </p>

      {!project ? (
        <Alert tone="info" title="No project yet">
          Create a project and this page has something to measure.
        </Alert>
      ) : !can(session.user.role, 'analytics:read') ? (
        <Alert tone="info" title="Your role does not include analytics">
          Ask an owner or admin if you need access.
        </Alert>
      ) : (
        <MetricBoard
          metrics={metrics}
          connections={connections}
          anyConnected={anyConnected}
          explanation={explanation}
          periodLabel={periodLabel}
        />
      )}
    </div>
  );
}
