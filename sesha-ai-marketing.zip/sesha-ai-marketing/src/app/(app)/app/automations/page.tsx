import type { Metadata } from 'next';

import { AutomationBoard, type RuleView } from '@/components/automation/automation-board';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { getCurrentSession } from '@/lib/auth/current-session';
import { can } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { listRules } from '@/lib/automation/service';
import type { Action, Condition } from '@/lib/automation/types';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Automations',
  description:
    'Trigger, condition, action. Every action produces something that waits for a person — nothing is sent, posted or spent.',
  path: '/app/automations',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function AutomationsPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);
  const project = projects[0] ?? null;

  let rules: RuleView[] = [];
  if (project && can(session.user.role, 'campaign:read')) {
    const rows = await listRules({ db }, tenant, project.id);
    rules = rows.map((row) => ({
      id: row.id,
      name: row.name,
      trigger: row.triggerKind,
      conditions: row.conditions as readonly unknown[] as readonly Condition[],
      actions: row.actions as readonly unknown[] as readonly Action[],
      enabled: row.enabled,
    }));
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Automations</h1>
        <Badge tone="success">Available</Badge>
      </div>

      <p className="max-w-3xl text-base leading-relaxed text-fg-muted">
        A rule watches for something that happens inside SeSha, checks a condition, and produces
        work for a person. It does not contact anybody. That is not caution — SeSha has no way to
        send an email, post to a platform or spend an advertising budget, so an automation that
        claimed to would be a lie with a switch on it.
      </p>

      {!project ? (
        <Alert tone="info" title="No project yet">
          Create a project and automations have something to watch.
        </Alert>
      ) : (
        <AutomationBoard
          projectId={project.id}
          rules={rules}
          canEdit={can(session.user.role, 'campaign:manage')}
        />
      )}
    </div>
  );
}
