import type { Metadata } from 'next';

import { ContentStudio } from '@/components/ai/content-studio';
import { getCurrentSession } from '@/lib/auth/current-session';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { listContent } from '@/lib/content/service';
import { aiIsEnabled } from '@/lib/ai/provider';
import { buildMetadata } from '@/lib/seo/metadata';
import type { ContentItemRow } from '@/lib/db/types';

export const metadata: Metadata = buildMetadata({
  title: 'Content Studio',
  description:
    'Draft twenty kinds of marketing content in English, Hindi or Hinglish, with brand voice, tone, length and intent controls.',
  path: '/app/create',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function CreatePage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);

  // Recent drafts for the first project only: the studio switches project
  // client-side and reloads the rest, and loading every project's history on
  // first paint would be slow for no benefit.
  let recent: ContentItemRow[] = [];
  if (projects[0]) {
    recent = await listContent({ db }, tenant, projects[0].id, 20);
  }

  return (
    <ContentStudio
      projects={projects}
      recent={recent}
      enabled={aiIsEnabled()}
      disabledReason="No AI provider key is set on this deployment, so generation is unavailable. An administrator needs to configure one."
    />
  );
}
