import type { Metadata } from 'next';

import { MessagingPlanner, type MessagingPlanSummary } from '@/components/messaging/messaging-planner';
import { Badge } from '@/components/ui/badge';
import { getCurrentSession } from '@/lib/auth/current-session';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { listMessagingPlans } from '@/lib/messaging/service';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Email and WhatsApp',
  description:
    'Plan email and WhatsApp content against the official rules, with the lawful basis recorded.',
  path: '/app/messaging',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function MessagingPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);
  const project = projects[0] ?? null;

  let plans: MessagingPlanSummary[] = [];
  if (project) {
    const rows = await listMessagingPlans({ db }, tenant, project.id);
    plans = rows.map((row) => ({
      id: row.id,
      channel: row.channel,
      kind: row.kind,
      category: row.category,
      title: row.title,
      optInBasis: row.optInBasis,
      audienceNote: row.audienceNote,
      reviewState: row.reviewState,
      problems: row.problems as MessagingPlanSummary['problems'],
      createdAt: row.createdAt.toISOString(),
    }));
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Email and WhatsApp</h1>
        <Badge tone="success">Available</Badge>
      </div>

      <p className="max-w-3xl text-base leading-relaxed text-fg-muted">
        Write and plan email and WhatsApp content. SeSha does not send — it writes the message and
        checks it against the rules that actually apply, including the ones that are legal
        requirements rather than advice. A campaign to a bought or scraped list is refused outright.
      </p>

      <MessagingPlanner plans={plans} />
    </div>
  );
}
