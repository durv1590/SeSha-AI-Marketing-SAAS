import type { Metadata } from 'next';

import { ReportBoard, type ReportListView } from '@/components/reports/report-board';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { getCurrentSession } from '@/lib/auth/current-session';
import { can } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { listReports, toReport } from '@/lib/reports/service';
import { REPORT_KINDS, SECTION_IDS, SECTION_QUESTION, pointCount } from '@/lib/reports/types';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Reports',
  description:
    'Nine reports, each answering the same six questions — including what SeSha could not measure, and why.',
  path: '/app/reports',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function ReportsPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);
  const project = projects[0] ?? null;

  let reports: ReportListView[] = [];
  if (project && can(session.user.role, 'analytics:read')) {
    const rows = await listReports({ db }, tenant, project.id);
    reports = rows.map((row) => ({
      id: row.id,
      kind: row.kind,
      title: row.title,
      period: { from: row.periodFrom, to: row.periodTo, label: row.periodLabel },
      connectedSources: row.connectedSources,
      generatedAt: row.generatedAt.toISOString(),
      points: pointCount(toReport(row)),
    }));
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Reports</h1>
        <Badge tone="success">Available</Badge>
      </div>

      <p className="max-w-3xl text-base leading-relaxed text-fg-muted">
        {REPORT_KINDS.length} kinds of report, each answering the same six questions:{' '}
        {SECTION_IDS.map((id) => SECTION_QUESTION[id]).join(' ')} A report that cannot answer one of
        them says so, rather than leaving a confident-looking gap.
      </p>

      {!project ? (
        <Alert tone="info" title="No project yet">
          Create a project and there is something to report on.
        </Alert>
      ) : (
        <ReportBoard
          projectId={project.id}
          reports={reports}
          canGenerate={can(session.user.role, 'analytics:read')}
        />
      )}
    </div>
  );
}
