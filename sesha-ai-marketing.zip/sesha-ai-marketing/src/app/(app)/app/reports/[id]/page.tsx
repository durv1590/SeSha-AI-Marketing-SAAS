import type { Metadata } from 'next';
import { notFound } from 'next/navigation';

import { ReportView } from '@/components/reports/report-view';
import { getCurrentSession } from '@/lib/auth/current-session';
import { getDatabase } from '@/lib/db';
import { findReport, toReport } from '@/lib/reports/service';
import { NotFoundError } from '@/lib/tenant';
import { EXPORT_FORMATS } from '@/lib/reports/export';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Report',
  description: 'A generated report, with every figure carrying its source.',
  path: '/app/reports',
  noindex: true,
});

export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export default async function ReportPage({ params }: Params) {
  const session = await getCurrentSession();
  if (!session) return null;

  const { id } = await params;

  try {
    const row = await findReport(
      { db: getDatabase() },
      {
        userId: session.user.id,
        organizationId: session.user.organizationId,
        role: session.user.role,
      },
      id,
    );

    return (
      <div className="flex flex-col gap-6">
        <ReportView report={toReport(row)} />

        <div className="flex flex-wrap gap-2">
          {EXPORT_FORMATS.map((format) => (
            <a
              key={format}
              href={`/api/reports/${row.id}/export?format=${format}`}
              className="rounded-control border border-border px-3 py-1.5 text-sm font-medium uppercase"
            >
              Download {format}
            </a>
          ))}
        </div>
      </div>
    );
  } catch (error) {
    // A report belonging to another organization is NOT FOUND, not forbidden —
    // the same rule as everywhere else, so an id cannot be used to learn what
    // exists.
    if (error instanceof NotFoundError) notFound();
    throw error;
  }
}
