import type { Metadata } from 'next';

import { KeywordTable, type KeywordRowView } from '@/components/audit/keyword-table';
import { AuditRunner } from '@/components/audit/audit-runner';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { getCurrentSession } from '@/lib/auth/current-session';
import { can } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { getActiveCrawlConsent, listProjects } from '@/lib/workspace/service';
import { getLatestCrawl, listKeywords } from '@/lib/crawl/service';
import { KEYWORD_DATA_NOTE } from '@/lib/keywords/extract';
import { PRIORITY_BASIS } from '@/lib/keywords/types';
import { BOT_USER_AGENT, blockedRangeLabels } from '@/lib/crawler';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Website audit',
  description:
    'Crawl your own website with your explicit permission, and see what SeSha read, what it refused to read, and the queries your pages already cover.',
  path: '/app/website-audit',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function WebsiteAuditPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);
  const project = projects[0];

  const consent = project ? await getActiveCrawlConsent({ db }, tenant, project.id) : null;
  const crawl = project ? await getLatestCrawl({ db }, tenant, project.id) : null;
  const keywordRows = project ? await listKeywords({ db }, tenant, project.id) : [];

  const keywords: KeywordRowView[] = keywordRows.map((row) => ({
    id: row.id,
    query: row.query,
    kinds: row.kinds,
    intent: row.intent,
    relevanceScore: row.relevanceScore,
    relevanceBasis: row.relevanceBasis,
    coveringUrls: row.coveringUrls,
    volume: row.volume as KeywordRowView['volume'],
    competition: row.competition as KeywordRowView['competition'],
    priority: row.priority,
    contentFormat: row.contentFormat,
    entities: row.entities,
    source: row.source,
  }));

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Website audit</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-fg-muted">
          SeSha reads your website so the rest of the platform has something real to work from.
          It only ever reads the site you authorised, and only the pages your robots.txt allows.
        </p>
      </div>

      <AuditRunner
        projects={projects}
        consentGranted={consent !== null && consent.revokedAt === null}
        consentSite={consent?.websiteUrl ?? null}
        hasCrawl={crawl !== null && crawl.pagesCrawled > 0}
        canRequestCrawl={can(session.user.role, 'crawl:request')}
      />

      {crawl ? (
        <Card className="p-5">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <p className="text-sm font-semibold">The most recent crawl</p>
            <p className="text-xs text-fg-subtle">
              {new Date(crawl.startedAt).toLocaleString('en-GB')}
            </p>
          </div>
          <dl className="mt-3 grid grid-cols-2 gap-x-6 gap-y-3 sm:grid-cols-4">
            {[
              ['Pages read', String(crawl.pagesCrawled)],
              ['Failed', String(crawl.pagesFailed)],
              ['Sitemap URLs', String(crawl.sitemapUrlsFound)],
              ['Delay between requests', `${crawl.crawlDelayMs} ms`],
            ].map(([label, value]) => (
              <div key={label}>
                <dt className="text-xs text-fg-subtle">{label}</dt>
                <dd className="mt-0.5 text-lg font-semibold tabular-nums">{value}</dd>
              </div>
            ))}
          </dl>
          <p className="mt-3 text-xs leading-relaxed text-fg-subtle">{crawl.robotsSummary}</p>
          <p className="mt-1 text-xs leading-relaxed text-fg-subtle">{crawl.sitemapNote}</p>
          <div className="mt-4">
            <Button href="/app/seo-aeo" size="sm" variant="secondary">
              See the SEO and AEO findings
            </Button>
          </div>
        </Card>
      ) : null}

      <section className="flex flex-col gap-4">
        <div>
          <h2 className="text-lg font-semibold">Queries your pages already cover</h2>
          <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-fg-muted">
            Taken from your own titles, headings and FAQ content. Nothing here was invented.
          </p>
        </div>
        <KeywordTable
          keywords={keywords}
          dataNote={KEYWORD_DATA_NOTE}
          priorityBasis={PRIORITY_BASIS}
        />
      </section>

      <CrawlerPolicy />
    </div>
  );
}

/**
 * What the crawler will and will not do.
 *
 * Published in the product, not just in the documentation, because a user
 * authorising a crawler to read their site is entitled to know exactly what it
 * does — and because an auditor asking "is this crawler safe" should be able to
 * read the answer without reading the source.
 */
function CrawlerPolicy() {
  return (
    <Card className="p-5">
      <h2 className="text-base font-semibold">How the crawler behaves</h2>

      <dl className="mt-4 flex flex-col gap-4 text-sm leading-relaxed">
        <div>
          <dt className="font-medium">It identifies itself</dt>
          <dd className="mt-1 text-fg-muted">
            Every request carries <code className="text-fg">{BOT_USER_AGENT}</code>. You can
            allow-list or block it in your robots.txt like any other crawler.
          </dd>
        </div>

        <div>
          <dt className="font-medium">It obeys robots.txt, and fails closed</dt>
          <dd className="mt-1 text-fg-muted">
            Disallowed paths are never fetched. If robots.txt cannot be read at all &mdash; a 500,
            a timeout &mdash; the crawl does not start, because we cannot tell what you intended.
          </dd>
        </div>

        <div>
          <dt className="font-medium">It reads slowly</dt>
          <dd className="mt-1 text-fg-muted">
            A short gap between requests, a small number at a time, and your{' '}
            <code className="text-fg">Crawl-delay</code> honoured if you set one. A crawl is less
            load on your server than one person browsing.
          </dd>
        </div>

        <div>
          <dt className="font-medium">It cannot be pointed at a private network</dt>
          <dd className="mt-1 text-fg-muted">
            Only http and https, only public addresses. Loopback, private ranges, link-local and
            cloud metadata endpoints are refused &mdash; {blockedRangeLabels().length} address
            ranges in total &mdash; and the check runs on the address the hostname actually resolves
            to, not on the name, so a domain pointed at an internal host is still refused. Every
            redirect is re-checked from scratch.
          </dd>
        </div>

        <div>
          <dt className="font-medium">It stores the extracted text, not your markup</dt>
          <dd className="mt-1 text-fg-muted">
            Titles, headings, text, links, images and structured data &mdash; the fields the audit
            needs. The raw HTML is discarded. Everything is deleted at the end of the retention
            period you chose, and immediately if you withdraw permission.
          </dd>
        </div>

        <div>
          <dt className="font-medium">It does not run JavaScript</dt>
          <dd className="mt-1 text-fg-muted">
            The crawler reads the HTML your server returns. Content added in the browser is not
            visible to it, and the audits say so wherever that matters.
          </dd>
        </div>
      </dl>

      <Alert tone="info" className="mt-5">
        Withdrawing permission stops future crawls and deletes what was already read. You can do
        that at any time in Settings, with no effect on the rest of your workspace.
      </Alert>
    </Card>
  );
}
