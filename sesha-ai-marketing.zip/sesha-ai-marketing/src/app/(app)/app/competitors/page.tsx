import type { Metadata } from 'next';

import { CompetitorPanel, type CompetitorView } from '@/components/competitors/competitor-panel';
import { Badge } from '@/components/ui/badge';
import { getCurrentSession } from '@/lib/auth/current-session';
import { can } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { listCompetitors } from '@/lib/competitors/service';
import {
  COMPETITOR_ACKNOWLEDGEMENT,
  COMPETITOR_FETCH_POLICY,
} from '@/lib/competitors/analyze';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Competitors',
  description:
    'What your competitors publish publicly, read from their own pages — with verified observations kept separate from AI inference.',
  path: '/app/competitors',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function CompetitorsPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);
  const project = projects[0] ?? null;

  let competitors: CompetitorView[] = [];
  if (project) {
    const rows = await listCompetitors({ db }, tenant, project.id);
    competitors = await Promise.all(
      rows.map(async (row) => {
        const acknowledgement = await db.competitorAcknowledgements.findLive(
          tenant.organizationId,
          row.id,
        );
        const latest = await db.competitorAnalyses.findLatest(tenant.organizationId, row.id);
        return {
          id: row.id,
          name: row.name,
          websiteUrl: row.websiteUrl,
          source: row.source,
          notes: row.notes,
          acknowledged: acknowledgement !== null,
          lastAnalysedAt: latest?.analysedAt.toISOString() ?? null,
          verifiedCount: latest?.verifiedCount ?? 0,
          inferredCount: latest?.inferredCount ?? 0,
        };
      }),
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Competitors</h1>
        <Badge tone="success">Available</Badge>
      </div>

      <p className="max-w-3xl text-base leading-relaxed text-fg-muted">
        SeSha reads what a competitor publishes on their own public pages and summarises it. What it
        read is labelled as verified, with the URL and the time; what it concluded is labelled as an
        inference. Nothing about spend, traffic or customer numbers is shown, because none of it is
        visible from outside.
      </p>

      <CompetitorPanel
        projectId={project?.id ?? null}
        competitors={competitors}
        policy={{
          maxPages: COMPETITOR_FETCH_POLICY.maxPages,
          storesPageContent: COMPETITOR_FETCH_POLICY.storesPageContent,
          acknowledgement: COMPETITOR_ACKNOWLEDGEMENT,
        }}
        canEdit={can(session.user.role, 'content:create')}
      />
    </div>
  );
}
