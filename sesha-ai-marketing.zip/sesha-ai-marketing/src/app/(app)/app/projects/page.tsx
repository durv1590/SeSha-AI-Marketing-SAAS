import type { Metadata } from 'next';

import { ProjectManager } from '@/components/app/project-manager';
import { getCurrentSession } from '@/lib/auth/current-session';
import { can } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Projects',
  description: 'Create and manage the isolated projects inside your SeSha workspace.',
  path: '/app/projects',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function ProjectsPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const projects = await listProjects(
    { db: getDatabase() },
    {
      userId: session.user.id,
      organizationId: session.user.organizationId,
      role: session.user.role,
    },
  );

  return (
    <ProjectManager
      projects={projects}
      canCreate={can(session.user.role, 'project:create')}
      canDelete={can(session.user.role, 'project:delete')}
    />
  );
}
