import type { Metadata } from 'next';

import { SocialManager } from '@/components/ai/social-manager';
import { getCurrentSession } from '@/lib/auth/current-session';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { listPosts } from '@/lib/social/service';
import { aiIsEnabled } from '@/lib/ai/provider';
import { buildMetadata } from '@/lib/seo/metadata';
import type { SocialPostRow } from '@/lib/db/types';

export const metadata: Metadata = buildMetadata({
  title: 'Social',
  description:
    'Plan and draft social posts for seven platforms. SeSha does not publish to any platform — no official API is connected.',
  path: '/app/social',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function SocialPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);

  let posts: SocialPostRow[] = [];
  if (projects[0]) posts = await listPosts({ db }, tenant, projects[0].id);

  return (
    <SocialManager
      projects={projects}
      posts={posts}
      enabled={aiIsEnabled()}
      disabledReason="No AI provider key is set on this deployment, so drafting is unavailable. An administrator needs to configure one."
    />
  );
}
