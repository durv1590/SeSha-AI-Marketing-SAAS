import type { Metadata } from 'next';

import { Copilot } from '@/components/ai/copilot';
import { getCurrentSession } from '@/lib/auth/current-session';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { aiIsEnabled } from '@/lib/ai/provider';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'AI Copilot',
  description:
    'An assistant that answers questions using your own brand, strategy and project context, and labels where every part of its answer came from.',
  path: '/app/ai',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function CopilotPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const projects = await listProjects(
    { db: getDatabase() },
    {
      userId: session.user.id,
      organizationId: session.user.organizationId,
      role: session.user.role,
    },
  );

  return (
    <Copilot
      projects={projects}
      enabled={aiIsEnabled()}
      disabledReason="No AI provider key is set on this deployment, so generation is unavailable. An administrator needs to configure one."
    />
  );
}
