import type { Metadata } from 'next';

import { LeadBoard, type LeadView } from '@/components/leads/lead-board';
import { Badge } from '@/components/ui/badge';
import { getCurrentSession } from '@/lib/auth/current-session';
import { can } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { listLeads } from '@/lib/leads/service';
import { LEAD_STAGES, SCORE_BASIS, pipelineCounts } from '@/lib/leads/types';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Leads',
  description: 'Your pipeline, with a lead score that shows its own reasoning.',
  path: '/app/leads',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function LeadsPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);
  const project = projects[0] ?? null;

  let leads: LeadView[] = [];
  let counts = pipelineCounts([]);

  if (project && can(session.user.role, 'lead:read')) {
    const outcome = await listLeads({ db }, tenant, project.id);
    counts = outcome.counts;
    leads = outcome.leads.map((lead) => ({
      id: lead.id,
      name: lead.name,
      email: lead.email,
      phone: lead.phone,
      company: lead.company,
      source: lead.source,
      stage: lead.stage,
      score: lead.score,
      scoreBasis: lead.scoreBasis,
      lastActivityAt: lead.lastActivityAt?.toISOString() ?? null,
      createdAt: lead.createdAt.toISOString(),
    }));
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Leads</h1>
        <Badge tone="success">Available</Badge>
      </div>

      <p className="max-w-3xl text-base leading-relaxed text-fg-muted">
        {LEAD_STAGES.length} stages, and a score you can audit. Every point comes with the reason it
        was given, and the parts add up to the total — so a score you disagree with shows you exactly
        which rule to ignore. Nothing here sends email or WhatsApp; logging &ldquo;email sent&rdquo;
        records what you did.
      </p>

      <LeadBoard
        projectId={project?.id ?? null}
        leads={leads}
        counts={counts}
        scoreBasis={SCORE_BASIS}
        canEdit={can(session.user.role, 'lead:manage')}
      />
    </div>
  );
}
