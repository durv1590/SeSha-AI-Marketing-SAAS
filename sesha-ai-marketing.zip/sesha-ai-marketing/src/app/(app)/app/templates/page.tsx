import type { Metadata } from 'next';

import { ComingSoon } from '@/components/app/coming-soon';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: "Templates",
  description: "Reusable briefs, workflows and content structures.",
  path: "/app/templates",
  noindex: true,
});

export default function Page() {
  return (
    <ComingSoon
      title="Templates"
      description="Reusable briefs, workflows and content structures."
      // Phase 7 added the TEMPLATES staff control — the report footer and the
      // notification signature, which staff set for the whole platform. That is
      // not this: saved content and campaign presets a customer reuses are
      // still unbuilt (Phase 8 was production hardening only), so the screen names the next phase rather than the one
      // that has just shipped without them.
      phase="a future release"
      whatItWillDo={[
        "Reusable content and campaign templates",
        "Per-client delivery templates for agencies",
      ]}
    />
  );
}
