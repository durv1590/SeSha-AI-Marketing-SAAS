import type { Metadata } from 'next';

import { CalendarBoard } from '@/components/calendar/calendar-board';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { getCurrentSession } from '@/lib/auth/current-session';
import { can } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { calendarView } from '@/lib/calendar/service';
import { EVENT_KINDS, isCalendarView, type CalendarView } from '@/lib/calendar/types';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Marketing calendar',
  description:
    'Daily, weekly, monthly and campaign views of what you plan to do. Nothing is published or sent on a date — SeSha cannot publish or send.',
  path: '/app/calendar',
  noindex: true,
});

export const dynamic = 'force-dynamic';

type Search = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function CalendarPage({ searchParams }: Search) {
  const session = await getCurrentSession();
  if (!session) return null;

  const params = await searchParams;
  const rawView = typeof params.view === 'string' ? params.view : null;
  const view: CalendarView = isCalendarView(rawView) ? rawView : 'monthly';
  const anchor = typeof params.date === 'string' ? params.date : undefined;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);
  const project = projects[0] ?? null;

  const result =
    project && can(session.user.role, 'campaign:read')
      ? await calendarView({ db }, tenant, project.id, view, anchor)
      : null;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Marketing calendar</h1>
        <Badge tone="success">Available</Badge>
      </div>

      <p className="max-w-3xl text-base leading-relaxed text-fg-muted">
        {EVENT_KINDS.length} kinds of activity across four views. An entry is a plan, not a schedule:
        nothing fires on the date, because SeSha cannot publish a post or send a message. Suggestions
        for empty stretches are shown separately and only ever come from something SeSha actually
        knows about you.
      </p>

      {!project || !result ? (
        <Alert tone="info" title="No project yet">
          Create a project and the calendar has something to plan against.
        </Alert>
      ) : (
        <CalendarBoard
          projectId={project.id}
          view={result.view}
          anchor={result.anchor}
          range={result.range}
          events={result.events}
          suggestions={result.suggestions}
          canEdit={can(session.user.role, 'campaign:manage')}
        />
      )}
    </div>
  );
}
