import type { Metadata } from 'next';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';
import { appMoreNav, appPrimaryNav } from '@/content/app-nav';
import { getCurrentSession } from '@/lib/auth/current-session';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { emailIsConfigured } from '@/lib/email';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Workspace',
  description: 'Your SeSha AI Marketing workspace home, with projects and setup status.',
  path: '/app',
  noindex: true,
});

export const dynamic = 'force-dynamic';

/**
 * Workspace home.
 *
 * Shows real state only: actual projects, actual profile completeness, actual
 * configuration gaps. No sample charts and no placeholder metrics — there is no
 * marketing data yet, and inventing some would be the exact failure mode the
 * brief warns against.
 */
export default async function WorkspaceHome() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);
  const subscription = await db.subscriptions.findForOrganization(session.user.organizationId);
  const profile = projects[0]
    ? await db.marketingProfiles.findByProject(session.user.organizationId, projects[0].id)
    : null;
  const consent = projects[0]
    ? await db.crawlConsents.findActiveForProject(session.user.organizationId, projects[0].id)
    : null;

  const available = [...appPrimaryNav, ...appMoreNav].filter((i) => i.status === 'available').length;
  const planned = [...appPrimaryNav, ...appMoreNav].filter((i) => i.status === 'planned').length;

  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">
          Welcome{session.user.name ? `, ${session.user.name.split(' ')[0]}` : ''}
        </h1>
        <p className="mt-2 text-base text-fg-muted">
          Your workspace is set up. Here is exactly what is working today.
        </p>
      </div>

      <section aria-labelledby="status-heading">
        <h2 id="status-heading" className="text-sm font-semibold uppercase tracking-[0.12em] text-fg-subtle">
          Workspace status
        </h2>
        <dl className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Projects" value={String(projects.length)} />
          <StatCard label="Plan" value={subscription?.plan ?? 'starter'} note={subscription?.status} />
          <StatCard
            label="Profile completeness"
            value={profile ? `${profile.completeness}%` : '—'}
          />
          <StatCard
            label="Website access"
            value={consent ? 'Consented' : 'Not granted'}
            note={consent ? `${consent.maxPages} pages max` : 'No crawling without consent'}
          />
        </dl>
      </section>

      <section aria-labelledby="projects-heading">
        <div className="flex items-center justify-between gap-4">
          <h2 id="projects-heading" className="text-sm font-semibold uppercase tracking-[0.12em] text-fg-subtle">
            Projects
          </h2>
          <Button href="/app/projects" variant="secondary" size="sm">
            Manage projects
          </Button>
        </div>

        <ul className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((project) => (
            <li key={project.id}>
              <Card className="h-full p-5">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-semibold tracking-tight">{project.name}</h3>
                  <Badge tone={project.status === 'active' ? 'success' : 'neutral'}>
                    {project.status}
                  </Badge>
                </div>
                <p className="mt-2 text-sm text-fg-muted">
                  {project.description || 'No description yet.'}
                </p>
              </Card>
            </li>
          ))}
        </ul>
      </section>

      <section aria-labelledby="honesty-heading">
        <h2 id="honesty-heading" className="text-sm font-semibold uppercase tracking-[0.12em] text-fg-subtle">
          What is and is not built
        </h2>
        <Card className="mt-4 p-6">
          <p className="text-sm leading-relaxed text-fg-muted">
            This is Phase 2: accounts, projects and the application foundation. Of the{' '}
            {available + planned} workspace areas, <strong className="text-fg">{available}</strong>{' '}
            are working and <strong className="text-fg">{planned}</strong> are marked
            &ldquo;Soon&rdquo; in the sidebar. Nothing is mocked up to look finished.
          </p>

          {!emailIsConfigured ? (
            <p className="mt-4 flex items-start gap-2.5 text-sm leading-relaxed text-warning">
              <Icon name="alert" size={16} className="mt-0.5 shrink-0" />
              <span>
                Email delivery is not configured on this deployment, so confirmation and reset links
                are logged rather than sent. Set <code className="font-mono text-xs">SMTP_URL</code>{' '}
                to enable them.
              </span>
            </p>
          ) : null}
        </Card>
      </section>
    </div>
  );
}

function StatCard({
  label,
  value,
  note,
}: {
  readonly label: string;
  readonly value: string;
  readonly note?: string | null;
}) {
  return (
    <Card className="p-5">
      <dt className="text-xs uppercase tracking-[0.08em] text-fg-subtle">{label}</dt>
      <dd className="mt-1.5 text-2xl font-semibold capitalize tracking-tight">{value}</dd>
      {note ? <p className="mt-1 text-xs text-fg-muted">{note}</p> : null}
    </Card>
  );
}
