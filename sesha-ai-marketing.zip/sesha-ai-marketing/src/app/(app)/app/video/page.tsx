import type { Metadata } from 'next';

import { ScriptView, type ScriptSummary } from '@/components/video/script-view';
import { Badge } from '@/components/ui/badge';
import { getCurrentSession } from '@/lib/auth/current-session';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { listVideoScripts } from '@/lib/video/service';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Video and creative',
  description:
    'Video scripts with hooks, scenes, shot lists, voice-over and thumbnail concepts — written briefs, not generated images.',
  path: '/app/video',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function VideoPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);
  const project = projects[0] ?? null;

  let scripts: ScriptSummary[] = [];
  if (project) {
    const rows = await listVideoScripts({ db }, tenant, project.id);
    scripts = rows.map((row) => ({
      id: row.id,
      platform: row.platform,
      topic: row.topic,
      totalSeconds: row.totalSeconds,
      reviewState: row.reviewState,
      problems: row.problems as ScriptSummary['problems'],
      createdAt: row.createdAt.toISOString(),
    }));
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Video and creative</h1>
        <Badge tone="success">Available</Badge>
      </div>

      <p className="max-w-3xl text-base leading-relaxed text-fg-muted">
        Scripts built the way a shoot actually needs them: a hook, numbered scenes with a shot and a
        duration each, voice-over, on-screen text, a call to action, titles, description and tags.
        Thumbnail concepts are written briefs — no image-generation API is connected, so nothing here
        is a generated picture.
      </p>

      <ScriptView scripts={scripts} />
    </div>
  );
}
