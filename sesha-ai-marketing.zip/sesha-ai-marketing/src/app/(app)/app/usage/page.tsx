import type { Metadata } from 'next';

import { UsageDashboardView } from '@/components/app/usage-dashboard';
import { Button } from '@/components/ui/button';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getCurrentSession } from '@/lib/auth/current-session';
import { getDatabase } from '@/lib/db';
import { entitlementFor } from '@/lib/plans/service';
import { dashboard } from '@/lib/usage/service';
import { billingStatus } from '@/lib/billing/types';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Usage',
  description: 'What you have used this period, and the limits on your plan.',
  path: '/app/usage',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function UsagePage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const entitlement = await entitlementFor({ db }, session.user.organizationId);
  const data = await dashboard(
    { db },
    session.user.organizationId,
    entitlement.plan,
    entitlement.limits,
  );

  const billing = billingStatus();

  return (
    <div className="flex max-w-4xl flex-col gap-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Usage</h1>
          <p className="mt-1 text-sm text-fg-muted">
            Everything SeSha counts against your plan, and what it has counted so far.
          </p>
        </div>
        <Button href="/app/settings/billing" variant="secondary" size="sm">
          Plan &amp; billing
        </Button>
      </div>

      <UsageDashboardView
        data={data}
        planName={entitlement.definition.name}
        writable={entitlement.writable}
        blockedReason={entitlement.blockedReason}
      />

      {billing.configured ? null : (
        <Card tone="subtle">
          <CardHeader>
            <CardTitle as="h2">About these limits</CardTitle>
            <CardDescription>
              {billing.message}
            </CardDescription>
          </CardHeader>
        </Card>
      )}
    </div>
  );
}
