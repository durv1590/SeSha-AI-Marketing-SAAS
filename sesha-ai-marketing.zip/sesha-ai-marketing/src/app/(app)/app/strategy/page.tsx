import type { Metadata } from 'next';

import { StrategyBuilder } from '@/components/ai/strategy-builder';
import { getCurrentSession } from '@/lib/auth/current-session';
import { can } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { listProjects } from '@/lib/workspace/service';
import { aiIsEnabled } from '@/lib/ai/provider';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Marketing strategy',
  description:
    'A seventeen-section marketing strategy generated from your own business details, with every section stating what it could and could not be built from.',
  path: '/app/strategy',
  noindex: true,
});

export const dynamic = 'force-dynamic';

export default async function StrategyPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const projects = await listProjects(
    { db: getDatabase() },
    {
      userId: session.user.id,
      organizationId: session.user.organizationId,
      role: session.user.role,
    },
  );

  return (
    <StrategyBuilder
      projects={projects}
      enabled={aiIsEnabled()}
      disabledReason="No AI provider key is set on this deployment, so generation is unavailable. An administrator needs to configure one."
      canApprove={can(session.user.role, 'content:publish')}
    />
  );
}
