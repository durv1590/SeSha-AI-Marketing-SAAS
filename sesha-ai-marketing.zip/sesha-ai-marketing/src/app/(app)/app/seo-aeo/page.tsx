import type { Metadata } from 'next';

import { AuditView, type StoredAudit } from '@/components/audit/audit-view';
import { getCurrentSession } from '@/lib/auth/current-session';
import { can } from '@/lib/auth/rbac';
import { getDatabase } from '@/lib/db';
import { listProjects, getActiveCrawlConsent } from '@/lib/workspace/service';
import { getLatestAudit, getLatestCrawl } from '@/lib/crawl/service';
import { AEO_DISCLAIMER } from '@/lib/audit/aeo';
import { buildMetadata } from '@/lib/seo/metadata';
import type { AuditRow } from '@/lib/db/types';

export const metadata: Metadata = buildMetadata({
  title: 'SEO and AEO',
  description:
    'Technical SEO and answer-engine findings from a crawl of your own site, each with the evidence behind it.',
  path: '/app/seo-aeo',
  noindex: true,
});

export const dynamic = 'force-dynamic';

/** Serialises a stored audit for the client component. */
function toStored(row: AuditRow | null): StoredAudit | null {
  if (!row) return null;
  return {
    id: row.id,
    kind: row.kind,
    score: row.score,
    scoreBasis: row.scoreBasis,
    findings: row.findings as StoredAudit['findings'],
    stats: row.stats,
    notChecked: row.notChecked as StoredAudit['notChecked'],
    suppressed: row.suppressed,
    checkedAt: row.checkedAt.toISOString(),
  };
}

export default async function SeoAeoPage() {
  const session = await getCurrentSession();
  if (!session) return null;

  const db = getDatabase();
  const tenant = {
    userId: session.user.id,
    organizationId: session.user.organizationId,
    role: session.user.role,
  };

  const projects = await listProjects({ db }, tenant);
  const project = projects[0];

  if (!project) {
    return (
      <AuditView
        projects={[]}
        crawl={null}
        seo={null}
        aeo={null}
        consentGranted={false}
        consentSite={null}
        canRequestCrawl={can(session.user.role, 'crawl:request')}
        aeoDisclaimer={AEO_DISCLAIMER}
      />
    );
  }

  const consent = await getActiveCrawlConsent({ db }, tenant, project.id);
  const crawl = await getLatestCrawl({ db }, tenant, project.id);
  const seo = await getLatestAudit({ db }, tenant, project.id, 'seo');
  const aeo = await getLatestAudit({ db }, tenant, project.id, 'aeo');

  return (
    <AuditView
      projects={projects}
      crawl={crawl}
      seo={toStored(seo)}
      aeo={toStored(aeo)}
      consentGranted={consent !== null && consent.revokedAt === null}
      consentSite={consent?.websiteUrl ?? null}
      canRequestCrawl={can(session.user.role, 'crawl:request')}
      aeoDisclaimer={AEO_DISCLAIMER}
    />
  );
}
