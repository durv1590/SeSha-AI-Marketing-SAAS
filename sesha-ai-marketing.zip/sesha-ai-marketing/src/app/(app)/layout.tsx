import { redirect } from 'next/navigation';

import { AppShell } from '@/components/app/app-shell';
import { VerifyBanner } from '@/components/app/verify-banner';
import { getCurrentSession } from '@/lib/auth/current-session';

/**
 * Authenticated layout — THIS is the authorization boundary for pages.
 *
 * The Edge middleware only checks that a session cookie exists, because it
 * cannot reach the database. Here the session is actually resolved: expired,
 * revoked, idle-timed-out and deleted-user cases all fail and redirect.
 *
 * Every page inside this group can therefore assume a valid session, and every
 * API route re-checks independently rather than trusting that assumption.
 */
export default async function AppLayout({ children }: { readonly children: React.ReactNode }) {
  const session = await getCurrentSession();
  if (!session) redirect('/sign-in?next=/app');

  // Onboarding is mandatory before the workspace is usable.
  if (!session.user.onboardingCompletedAt) redirect('/onboarding');

  return (
    <AppShell
      user={{
        name: session.user.name,
        email: session.user.email,
        role: session.user.role,
        emailVerified: session.user.emailVerifiedAt !== null,
      }}
      banner={
        session.user.emailVerifiedAt === null ? <VerifyBanner email={session.user.email} /> : null
      }
    >
      {children}
    </AppShell>
  );
}
