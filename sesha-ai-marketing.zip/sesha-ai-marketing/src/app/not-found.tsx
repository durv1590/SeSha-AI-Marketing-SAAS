import type { Metadata } from 'next';

import { Button } from '@/components/ui/button';
import { Container, Section } from '@/components/layout/container';
import { Icon } from '@/components/ui/icon';
import { buildMetadata } from '@/lib/seo/metadata';

/**
 * 404 page.
 *
 * Marked noindex: a soft-404 that returns 200 and gets indexed is worse than
 * no page at all. It offers real navigation rather than a dead end, so a
 * visitor who lands here from a stale link has somewhere to go.
 */
export const metadata: Metadata = buildMetadata({
  title: 'Page not found',
  description:
    'The page you are looking for does not exist or has moved. Use these links to find what you need.',
  path: '/404',
  noindex: true,
});

const suggestions = [
  { label: 'Home', href: '/', description: 'Start from the top' },
  { label: 'Features', href: '/features', description: 'Every module in the platform' },
  { label: 'Solutions', href: '/solutions', description: 'By industry' },
  { label: 'Schema validator', href: '/schema-validator', description: 'Free JSON-LD tool' },
  { label: 'Resources', href: '/resources', description: 'Guides and articles' },
  { label: 'Contact', href: '/contact', description: 'Talk to the team' },
];

export default function NotFound() {
  return (
    <Section spacing="lg">
      <Container>
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.14em] text-primary">
            Error 404
          </p>
          <h1 className="mt-4 text-4xl font-semibold tracking-tight text-balance sm:text-5xl">
            We could not find that page
          </h1>
          <p className="mt-5 text-lg leading-relaxed text-fg-muted">
            The link may be out of date, or the address may have a typo. Everything below is a
            working starting point.
          </p>
          <div className="mt-8 flex justify-center">
            <Button href="/" size="lg">
              <Icon name="arrow-right" size={18} className="rotate-180" />
              Back to home
            </Button>
          </div>
        </div>

        <ul className="mx-auto mt-14 grid max-w-3xl gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {suggestions.map((item) => (
            <li key={item.href}>
              <Button
                href={item.href}
                variant="secondary"
                block
                className="h-auto flex-col items-start gap-0.5 py-4 text-left"
              >
                <span className="font-medium">{item.label}</span>
                <span className="text-xs font-normal text-fg-muted">{item.description}</span>
              </Button>
            </li>
          ))}
        </ul>
      </Container>
    </Section>
  );
}
