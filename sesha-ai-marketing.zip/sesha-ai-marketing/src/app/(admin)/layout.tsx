import { AdminShell } from '@/components/admin/admin-shell';
import { STAFF_ROLE_LABEL, permissionsFor } from '@/lib/admin/auth';
import { requireStaffPage } from '@/lib/admin/page-guard';

/**
 * The admin route group — THE authorization boundary for every admin page.
 *
 * Reaching this layout at all requires an active `platform_staff` row. Anyone
 * else gets the ordinary not-found page, so the panel is invisible rather than
 * merely locked.
 *
 * `admin:health:read` is the permission checked here because it is the lowest
 * one any staff role holds; each page then re-checks its own. The layout is not
 * the only gate — every service call re-checks and every API route re-checks —
 * but it is the one that stops a page from rendering its shell to a stranger.
 */
export const dynamic = 'force-dynamic';

export default async function AdminLayout({ children }: { readonly children: React.ReactNode }) {
  const { staff } = await requireStaffPage('admin:health:read');

  return (
    <AdminShell
      role={staff.role}
      roleLabel={STAFF_ROLE_LABEL[staff.role]}
      permissions={permissionsFor(staff.role)}
      sudo={staff.sudo}
    >
      {children}
    </AdminShell>
  );
}
