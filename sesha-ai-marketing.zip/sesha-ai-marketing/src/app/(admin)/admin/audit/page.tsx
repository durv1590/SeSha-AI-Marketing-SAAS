import type { Metadata } from 'next';
import Link from 'next/link';

import {
  AdminPageHeader,
  AdminTable,
  formatDateTime,
  shortId,
} from '@/components/admin/admin-primitives';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getDatabase } from '@/lib/db';
import { listAdminActions } from '@/lib/admin/service';
import { requireStaffPage } from '@/lib/admin/page-guard';

export const metadata: Metadata = {
  title: 'Admin audit trail',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

const OUTCOME_TONE = {
  success: 'neutral',
  failure: 'danger',
  denied: 'warning',
} as const;

export default async function AdminAuditPage({
  searchParams,
}: {
  readonly searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { staff } = await requireStaffPage('admin:audit:read');
  const params = await searchParams;
  const kind = params.kind === 'read' || params.kind === 'write' ? params.kind : undefined;

  const actions = await listAdminActions({ db: getDatabase() }, staff, {
    ...(kind ? { kind } : {}),
  });

  const writes = actions.filter((action) => action.kind === 'write').length;
  const denied = actions.filter((action) => action.outcome === 'denied').length;

  return (
    <>
      <AdminPageHeader
        title="Admin audit trail"
        summary="Every staff action, including every read. Opening this page is itself recorded, and your visit will appear the next time it loads."
      />

      <div className="flex flex-col gap-6">
        <nav aria-label="Filter the audit trail" className="flex flex-wrap gap-2">
          {[
            { label: 'Everything', href: '/admin/audit' },
            { label: 'Changes only', href: '/admin/audit?kind=write' },
            { label: 'Reads only', href: '/admin/audit?kind=read' },
          ].map((filter) => (
            <Link
              key={filter.href}
              href={filter.href}
              className="rounded-full border border-border px-3 py-1 text-sm text-fg-muted hover:text-fg"
            >
              {filter.label}
            </Link>
          ))}
        </nav>

        <Card>
          <CardHeader>
            <CardTitle as="h2">
              {actions.length.toLocaleString('en-IN')} recorded action
              {actions.length === 1 ? '' : 's'}
            </CardTitle>
            <CardDescription>
              {writes.toLocaleString('en-IN')} of them changed something.{' '}
              {denied > 0
                ? `${denied.toLocaleString('en-IN')} were refused — a refused attempt is recorded as carefully as a successful one.`
                : 'None were refused.'}
            </CardDescription>
          </CardHeader>
          <AdminTable
            caption="Admin actions"
            head={['When', 'Action', 'Kind', 'Role', 'Target', 'Organization', 'Outcome']}
            empty="Nothing recorded yet."
            minWidth="52rem"
          >
            {actions.map((action) => (
              <tr key={action.id}>
                <th scope="row" className="py-2.5 pr-4 text-left font-normal text-xs text-fg-muted">
                  {formatDateTime(action.createdAt)}
                </th>
                <td className="py-2.5 pr-4">
                  <span className="block">{action.action}</span>
                  <span className="block text-xs text-fg-subtle">{action.permission}</span>
                </td>
                <td className="py-2.5 pr-4">
                  <Badge tone={action.kind === 'write' ? 'brand' : 'outline'}>{action.kind}</Badge>
                </td>
                <td className="py-2.5 pr-4 text-xs text-fg-muted">{action.staffRole}</td>
                <td className="py-2.5 pr-4 text-xs text-fg-muted">
                  {action.targetType}
                  {action.targetId ? ` · ${shortId(action.targetId)}` : ''}
                </td>
                <td className="py-2.5 pr-4">
                  {action.targetOrganizationId ? (
                    <Link
                      href={`/admin/organizations/${action.targetOrganizationId}`}
                      className="text-xs text-primary underline underline-offset-2"
                    >
                      {shortId(action.targetOrganizationId)}
                    </Link>
                  ) : (
                    <span className="text-xs text-fg-subtle">Platform</span>
                  )}
                </td>
                <td className="py-2.5 pr-4">
                  <Badge tone={OUTCOME_TONE[action.outcome]}>{action.outcome}</Badge>
                </td>
              </tr>
            ))}
          </AdminTable>
        </Card>
      </div>
    </>
  );
}
