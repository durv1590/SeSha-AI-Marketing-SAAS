import type { Metadata } from 'next';

import {
  AdminPageHeader,
  CountRow,
  Stat,
  StatGrid,
} from '@/components/admin/admin-primitives';
import { HealthChecks } from '@/components/admin/health-checks';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getDatabase } from '@/lib/db';
import { health, overview } from '@/lib/admin/service';
import { requireStaffPage } from '@/lib/admin/page-guard';
import { LIMITS, PLANS_BY_RANK, type LimitId } from '@/content/plans';
import { METRIC_LABEL, WRITABLE_METRICS } from '@/lib/usage/metrics';
import { STATUS_LABEL, type SubscriptionStatus } from '@/lib/billing/types';

export const metadata: Metadata = {
  title: 'Platform overview',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

export default async function AdminOverviewPage() {
  const { staff } = await requireStaffPage('admin:health:read');
  const db = getDatabase();
  const data = await overview({ db }, staff);
  const report = await health({ db }, staff);

  const refusals = Object.entries(data.refusalsLast7Days)
    .filter(([, count]) => count > 0)
    .sort((a, b) => b[1] - a[1]);

  return (
    <>
      <AdminPageHeader
        title="Platform overview"
        summary="Counts, plan spread, subscription states and what the system can actually tell you about itself."
      />

      <div className="flex flex-col gap-6">
        <StatGrid>
          <Stat label="Organizations" value={data.organizations} />
          <Stat label="Users" value={data.users} />
          <Stat label="Projects" value={data.projects} />
          <Stat label="Reports" value={data.reports} />
        </StatGrid>

        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle as="h2">Plans</CardTitle>
              <CardDescription>How accounts are distributed across the registry.</CardDescription>
            </CardHeader>
            <ul className="flex flex-col gap-1.5 px-6 pb-6 text-sm">
              {PLANS_BY_RANK.map((plan) => (
                <li key={plan.id} className="flex justify-between gap-3">
                  <span className="text-fg-muted">{plan.name}</span>
                  <span className="tabular-nums text-fg">
                    {(data.planCounts[plan.id] ?? 0).toLocaleString('en-IN')}
                  </span>
                </li>
              ))}
            </ul>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle as="h2">Subscription states</CardTitle>
              <CardDescription>
                &ldquo;None&rdquo; means no subscription row exists — treated as free and writable,
                not locked out.
              </CardDescription>
            </CardHeader>
            <ul className="flex flex-col gap-1.5 px-6 pb-6 text-sm">
              {Object.entries(data.statusCounts).map(([status, count]) => (
                <li key={status} className="flex justify-between gap-3">
                  <span className="text-fg-muted">
                    {status === 'none'
                      ? 'No subscription row'
                      : (STATUS_LABEL[status as SubscriptionStatus] ?? status)}
                  </span>
                  <span className="tabular-nums text-fg">{count.toLocaleString('en-IN')}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle as="h2">Usage this period</CardTitle>
              <CardDescription>Every measurement, including the ones still at zero.</CardDescription>
            </CardHeader>
            <ul className="flex flex-col gap-1.5 px-6 pb-6 text-sm">
              {WRITABLE_METRICS.map((metric) => (
                <li key={metric} className="flex justify-between gap-3">
                  <span className="text-fg-muted">{METRIC_LABEL[metric]}</span>
                  <span className="tabular-nums text-fg">
                    {(data.usageThisPeriod[metric] ?? 0).toLocaleString('en-IN')}
                  </span>
                </li>
              ))}
            </ul>
          </Card>

          <div className="flex flex-col gap-4">
            <StatGrid>
              <Stat label="Open errors" value={data.openErrors} />
              <Stat label="New feedback" value={data.newFeedback} />
            </StatGrid>
            <Card>
              <CardHeader>
                <CardTitle as="h2">Jobs</CardTitle>
                <CardDescription>Counted now, not sampled over time.</CardDescription>
              </CardHeader>
              <div className="px-6 pb-6">
                <CountRow counts={data.jobCounts} />
              </div>
            </Card>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle as="h2">Refusals, last 7 days</CardTitle>
            <CardDescription>
              Where limits are actually biting. A limit that refuses constantly is either priced
              wrong or too low — this is the evidence for that argument.
            </CardDescription>
          </CardHeader>
          {refusals.length === 0 ? (
            <p className="px-6 pb-6 text-sm text-fg-muted">
              Nothing has been refused for a limit in the last seven days.
            </p>
          ) : (
            <ul className="flex flex-col gap-1.5 px-6 pb-6 text-sm">
              {refusals.map(([limitId, count]) => (
                <li key={limitId} className="flex justify-between gap-3">
                  <span className="text-fg-muted">
                    {LIMITS[limitId as LimitId]?.label ?? limitId}
                  </span>
                  <span className="tabular-nums text-fg">{count.toLocaleString('en-IN')}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          <CardHeader>
            <CardTitle as="h2">System health</CardTitle>
            <CardDescription>
              Active staff: {data.activeStaff.toLocaleString('en-IN')}.
            </CardDescription>
          </CardHeader>
          <div className="px-6 pb-6">
            <HealthChecks checks={report.checks} />
          </div>
        </Card>
      </div>
    </>
  );
}
