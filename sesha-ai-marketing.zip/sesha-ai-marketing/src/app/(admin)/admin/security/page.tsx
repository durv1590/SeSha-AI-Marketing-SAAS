import type { Metadata } from 'next';
import Link from 'next/link';

import {
  AdminPageHeader,
  AdminTable,
  Stat,
  StatGrid,
  formatDateTime,
  shortId,
} from '@/components/admin/admin-primitives';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getDatabase } from '@/lib/db';
import { listSecurityEvents } from '@/lib/admin/service';
import { requireStaffPage } from '@/lib/admin/page-guard';

export const metadata: Metadata = {
  title: 'Security events',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

export default async function AdminSecurityPage() {
  const { staff } = await requireStaffPage('admin:security:read');
  const events = await listSecurityEvents({ db: getDatabase() }, staff);

  const failures = events.filter((event) => event.outcome !== 'success').length;
  const byAction = new Map<string, number>();
  for (const event of events) {
    byAction.set(event.action, (byAction.get(event.action) ?? 0) + 1);
  }
  const top = [...byAction.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6);

  return (
    <>
      <AdminPageHeader
        title="Security events"
        summary="Security-relevant events from the tenant audit log — sign-in failures, password changes, invitations, permission denials. Staff activity has its own trail."
      />

      <div className="flex flex-col gap-6">
        <StatGrid>
          <Stat label="Events" value={events.length} note="Most recent 100." />
          <Stat
            label="Not successful"
            value={failures}
            note="Failures and refusals, together."
          />
          <Stat label="Distinct actions" value={byAction.size} />
        </StatGrid>

        <Card>
          <CardHeader>
            <CardTitle as="h2">Most frequent</CardTitle>
            <CardDescription>
              Shape first. A spike in one action is the thing worth escalating, not any single row.
            </CardDescription>
          </CardHeader>
          <AdminTable caption="Most frequent actions" head={['Action', 'Count']} minWidth="24rem">
            {top.map(([action, count]) => (
              <tr key={action}>
                <th scope="row" className="py-2.5 pr-4 text-left font-normal">
                  {action.replace(/[._]/g, ' ')}
                </th>
                <td className="py-2.5 pr-4 tabular-nums">{count.toLocaleString('en-IN')}</td>
              </tr>
            ))}
          </AdminTable>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle as="h2">Recent events</CardTitle>
            <CardDescription>
              The person behind each event is deliberately not shown. Which account it happened in
              is enough to escalate, and identifying individuals here would make this a surveillance
              screen.
            </CardDescription>
          </CardHeader>
          <AdminTable
            caption="Recent security events"
            head={['When', 'Action', 'Outcome', 'Organization']}
            empty="Nothing recorded."
            minWidth="36rem"
          >
            {events.map((event, index) => (
              <tr key={`${event.action}-${event.createdAt}-${index}`}>
                <th scope="row" className="py-2.5 pr-4 text-left font-normal text-xs text-fg-muted">
                  {formatDateTime(event.createdAt)}
                </th>
                <td className="py-2.5 pr-4">{event.action.replace(/[._]/g, ' ')}</td>
                <td className="py-2.5 pr-4">
                  <Badge tone={event.outcome === 'success' ? 'neutral' : 'warning'}>
                    {event.outcome}
                  </Badge>
                </td>
                <td className="py-2.5 pr-4">
                  {event.organizationId ? (
                    <Link
                      href={`/admin/organizations/${event.organizationId}`}
                      className="text-xs text-primary underline underline-offset-2"
                    >
                      {shortId(event.organizationId)}
                    </Link>
                  ) : (
                    <span className="text-xs text-fg-subtle">None</span>
                  )}
                </td>
              </tr>
            ))}
          </AdminTable>
        </Card>
      </div>
    </>
  );
}
