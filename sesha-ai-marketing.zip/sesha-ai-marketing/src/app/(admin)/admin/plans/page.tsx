import type { Metadata } from 'next';

import { AdminPageHeader } from '@/components/admin/admin-primitives';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { requireStaffPage } from '@/lib/admin/page-guard';
import { LIMITS, LIMIT_IDS, PLANS_BY_RANK, formatLimit } from '@/content/plans';

export const metadata: Metadata = {
  title: 'Plans',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

export default async function AdminPlansPage() {
  await requireStaffPage('admin:subscriptions:read');

  return (
    <>
      <AdminPageHeader
        title="Plans"
        summary="The registry as deployed. Every limit for every plan, in one table, so a claim on the pricing page can be checked against the code that enforces it."
      />

      <div className="flex flex-col gap-6">
        <Card tone="subtle">
          <CardHeader>
            <CardTitle as="h2">Why there is no edit button</CardTitle>
            <CardDescription>
              A plan definition is a promise made to every customer on it. Changing what
              &ldquo;Pro&rdquo; means for all of them at once is a release, reviewed and deployed
              from <code className="text-xs">src/content/plans.ts</code> — not a form. To give one
              account a different limit, open that organization and set an override with a reason;
              they will see the reason on their own usage screen.
            </CardDescription>
          </CardHeader>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle as="h2">Limits by plan</CardTitle>
            <CardDescription>
              A dash means unlimited. Zero means the feature is not included on that plan, which is
              a different thing from a limit of none left.
            </CardDescription>
          </CardHeader>
          <div className="overflow-x-auto px-6 pb-6">
            <table className="w-full min-w-[44rem] text-sm">
              <caption className="sr-only">Every limit for every plan</caption>
              <thead>
                <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-fg-subtle">
                  <th scope="col" className="py-2 pr-4 font-medium">
                    Limit
                  </th>
                  <th scope="col" className="py-2 pr-4 font-medium">
                    Counted
                  </th>
                  {PLANS_BY_RANK.map((plan) => (
                    <th key={plan.id} scope="col" className="py-2 pr-4 text-right font-medium">
                      {plan.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {LIMIT_IDS.map((id) => (
                  <tr key={id}>
                    <th scope="row" className="py-2.5 pr-4 text-left font-normal">
                      <span className="block text-fg">{LIMITS[id].label}</span>
                      <span className="block text-xs text-fg-subtle">
                        {LIMITS[id].description}
                      </span>
                    </th>
                    <td className="py-2.5 pr-4 text-xs text-fg-muted">
                      {LIMITS[id].kind === 'per_period' ? 'Per month' : 'Standing total'}
                    </td>
                    {PLANS_BY_RANK.map((plan) => (
                      <td
                        key={plan.id}
                        className="py-2.5 pr-4 text-right tabular-nums text-fg"
                      >
                        {formatLimit(plan.limits[id])}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle as="h2">Plan metadata</CardTitle>
            <CardDescription>
              Prices are not here. They live behind a verification guard in the marketing content
              and are published only once the business has confirmed them — a limit is an
              engineering fact, a price is a commitment.
            </CardDescription>
          </CardHeader>
          <ul className="flex flex-col divide-y divide-border px-6 pb-6 text-sm">
            {PLANS_BY_RANK.map((plan) => (
              <li key={plan.id} className="flex flex-col gap-1 py-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-medium text-fg">{plan.name}</span>
                  <Badge tone="outline">rank {plan.rank}</Badge>
                  {plan.requiresPayment ? (
                    <Badge tone="brand">Paid</Badge>
                  ) : (
                    <Badge tone="neutral">Free</Badge>
                  )}
                  {plan.trialDays > 0 ? (
                    <Badge tone="info">{plan.trialDays}-day trial</Badge>
                  ) : null}
                </div>
                <p className="text-fg-muted">{plan.audience}</p>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </>
  );
}
