import type { Metadata } from 'next';
import Link from 'next/link';

import { AdminPageHeader, formatDateTime, shortId } from '@/components/admin/admin-primitives';
import { FeedbackStatusButton } from '@/components/admin/triage-controls';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getDatabase } from '@/lib/db';
import { listFeedback } from '@/lib/admin/service';
import { requireStaffPage } from '@/lib/admin/page-guard';
import { permissionsFor } from '@/lib/admin/auth';
import type { FeedbackRow } from '@/lib/db/types';

export const metadata: Metadata = {
  title: 'Feedback',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

const STATUSES = ['new', 'triaged', 'answered', 'closed'] as const;

const KIND_TONE = {
  bug: 'danger',
  idea: 'info',
  praise: 'success',
  other: 'neutral',
} as const;

function isStatus(value: unknown): value is FeedbackRow['status'] {
  return typeof value === 'string' && (STATUSES as readonly string[]).includes(value);
}

export default async function AdminFeedbackPage({
  searchParams,
}: {
  readonly searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { staff } = await requireStaffPage('admin:feedback:read');
  const params = await searchParams;
  const status = params.status;

  const rows = await listFeedback(
    { db: getDatabase() },
    staff,
    isStatus(status) ? status : undefined,
  );
  const canTriage = permissionsFor(staff.role).includes('admin:feedback:write');

  return (
    <>
      <AdminPageHeader
        title="Feedback"
        summary="The one screen in this panel that shows what a customer wrote — because they wrote it in order to be read. Opening it is recorded like everything else."
      />

      <div className="flex flex-col gap-6">
        <nav aria-label="Filter feedback" className="flex flex-wrap gap-2">
          <Link
            href="/admin/feedback"
            aria-current={isStatus(status) ? undefined : 'page'}
            className="rounded-full border border-border px-3 py-1 text-sm text-fg-muted hover:text-fg"
          >
            All
          </Link>
          {STATUSES.map((entry) => (
            <Link
              key={entry}
              href={`/admin/feedback?status=${entry}`}
              aria-current={status === entry ? 'page' : undefined}
              className="rounded-full border border-border px-3 py-1 text-sm capitalize text-fg-muted hover:text-fg"
            >
              {entry}
            </Link>
          ))}
        </nav>

        <Card>
          <CardHeader>
            <CardTitle as="h2">
              {rows.length === 1 ? '1 note' : `${rows.length.toLocaleString('en-IN')} notes`}
            </CardTitle>
            <CardDescription>
              Newest first, capped at 100. SeSha cannot reply from here — there is no outbound
              path for feedback, so nothing on this screen promises the customer an answer.
            </CardDescription>
          </CardHeader>

          {rows.length === 0 ? (
            <p className="px-6 pb-6 text-sm text-fg-muted">
              {isStatus(status) ? `Nothing is ${status}.` : 'Nothing yet.'}
            </p>
          ) : (
            <ul className="flex flex-col divide-y divide-border px-6 pb-6">
              {rows.map((row) => (
                <li key={row.id} className="flex flex-col gap-2 py-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone={KIND_TONE[row.kind]}>{row.kind}</Badge>
                    <Badge tone="outline">{row.status}</Badge>
                    {row.surface ? (
                      <span className="text-xs text-fg-subtle">from {row.surface}</span>
                    ) : null}
                    <span className="text-xs text-fg-subtle">{formatDateTime(row.createdAt)}</span>
                    {row.organizationId ? (
                      <Link
                        href={`/admin/organizations/${row.organizationId}`}
                        className="text-xs text-primary underline underline-offset-2"
                      >
                        {shortId(row.organizationId)}
                      </Link>
                    ) : null}
                  </div>

                  <p className="whitespace-pre-wrap text-sm text-fg">{row.message}</p>

                  {canTriage ? <FeedbackStatusButton id={row.id} status={row.status} /> : null}
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </>
  );
}
