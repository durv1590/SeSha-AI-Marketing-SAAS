import type { Metadata } from 'next';

import { AdminPageHeader } from '@/components/admin/admin-primitives';
import { SettingEditor } from '@/components/admin/setting-controls';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getDatabase } from '@/lib/db';
import { listSettings } from '@/lib/admin/service';
import { requireStaffPage } from '@/lib/admin/page-guard';
import { permissionsFor } from '@/lib/admin/auth';
import { GROUP_LABEL, SETTING_GROUPS, type SettingGroup } from '@/lib/admin/settings';

export const metadata: Metadata = {
  title: 'System configuration',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

/**
 * Each group of settings maps to its own permission, so the audit trail records
 * which surface was touched rather than "a setting changed", and a role that may
 * edit prompts does not thereby gain the ability to close sign-ups.
 */
const GROUP_PERMISSION = {
  prompts: 'admin:prompts:write',
  templates: 'admin:templates:write',
  validator: 'admin:validator:write',
  system: 'admin:system:write',
} as const;

export default async function AdminSettingsPage() {
  const { staff } = await requireStaffPage('admin:system:write');
  const settings = await listSettings({ db: getDatabase() }, staff);
  const held = permissionsFor(staff.role);

  return (
    <>
      <AdminPageHeader
        title="System configuration"
        summary="Prompts, templates, validator behaviour and platform switches. A fixed registry, each value checked against its declared shape and bounds before it is stored."
      />

      <div className="flex flex-col gap-6">
        {SETTING_GROUPS.map((group) => {
          const inGroup = settings.filter((setting) => setting.group === group);
          if (inGroup.length === 0) return null;
          const canEdit = held.includes(GROUP_PERMISSION[group as SettingGroup]);

          return (
            <Card key={group}>
              <CardHeader>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <CardTitle as="h2">{GROUP_LABEL[group as SettingGroup]}</CardTitle>
                  {canEdit ? null : <Badge tone="outline">Read only for your role</Badge>}
                </div>
                <CardDescription>
                  {inGroup.length === 1 ? '1 setting' : `${inGroup.length} settings`}.
                </CardDescription>
              </CardHeader>

              <ul className="flex flex-col divide-y divide-border px-6 pb-6">
                {inGroup.map((setting) => (
                  <li key={setting.key} className="flex flex-col gap-2 py-4">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-medium text-fg">{setting.label}</span>
                      <code className="text-xs text-fg-subtle">{setting.key}</code>
                      <Badge tone="outline">{setting.shape.replace('_', ' ')}</Badge>
                    </div>
                    <p className="text-sm text-fg-muted">{setting.description}</p>

                    {canEdit ? (
                      <SettingEditor
                        settingKey={setting.key}
                        label={setting.label}
                        shape={setting.shape}
                        value={setting.value}
                        isDefault={setting.isDefault}
                      />
                    ) : (
                      <p className="text-sm text-fg">
                        Current value:{' '}
                        <code className="text-xs">{describe(setting.value)}</code>
                      </p>
                    )}
                  </li>
                ))}
              </ul>
            </Card>
          );
        })}
      </div>
    </>
  );
}

/** A value rendered for reading. An empty list says so rather than showing nothing. */
function describe(value: unknown): string {
  if (Array.isArray(value)) return value.length === 0 ? '(empty list)' : value.join(', ');
  if (value === '') return '(empty)';
  if (value === true) return 'on';
  if (value === false) return 'off';
  return String(value);
}
