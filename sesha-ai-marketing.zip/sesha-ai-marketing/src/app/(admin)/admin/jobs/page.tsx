import type { Metadata } from 'next';
import Link from 'next/link';

import {
  AdminPageHeader,
  AdminTable,
  formatDateTime,
  shortId,
} from '@/components/admin/admin-primitives';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getDatabase } from '@/lib/db';
import { listJobs } from '@/lib/admin/service';
import { requireStaffPage } from '@/lib/admin/page-guard';

export const metadata: Metadata = {
  title: 'Jobs',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

const STATUS_TONE: Readonly<Record<string, 'neutral' | 'info' | 'success' | 'warning' | 'danger'>> =
  {
    queued: 'neutral',
    running: 'info',
    succeeded: 'success',
    failed: 'danger',
    canceled: 'warning',
  };

const FILTERS = [
  { label: 'All', href: '/admin/jobs' },
  { label: 'Failed', href: '/admin/jobs?status=failed' },
  { label: 'Running', href: '/admin/jobs?status=running' },
  { label: 'Crawls', href: '/admin/jobs?kind=crawl' },
  { label: 'Schema', href: '/admin/jobs?kind=schema_validation' },
];

export default async function AdminJobsPage({
  searchParams,
}: {
  readonly searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { staff } = await requireStaffPage('admin:jobs:read');
  const params = await searchParams;
  const kind = typeof params.kind === 'string' ? params.kind : '';
  const status = typeof params.status === 'string' ? params.status : '';

  const jobs = await listJobs({ db: getDatabase() }, staff, {
    ...(kind ? { kind } : {}),
    ...(status ? { status } : {}),
  });

  return (
    <>
      <AdminPageHeader
        title="Jobs"
        summary="Crawl and schema work across every tenant. The input a customer typed is not shown — the kind, the state and the failure are what diagnose a stuck job."
      />

      <div className="flex flex-col gap-6">
        <nav aria-label="Filter jobs" className="flex flex-wrap gap-2">
          {FILTERS.map((filter) => (
            <Link
              key={filter.href}
              href={filter.href}
              className="rounded-full border border-border px-3 py-1 text-sm text-fg-muted hover:border-border-strong hover:text-fg"
            >
              {filter.label}
            </Link>
          ))}
        </nav>

        <Card>
          <CardHeader>
            <CardTitle as="h2">
              {jobs.length === 1 ? '1 job' : `${jobs.length.toLocaleString('en-IN')} jobs`}
            </CardTitle>
            <CardDescription>Newest first, capped at 100.</CardDescription>
          </CardHeader>
          <AdminTable
            caption="Jobs"
            head={['Kind', 'State', 'Progress', 'Attempts', 'Organization', 'Queued', 'Failure']}
            empty="No job matches that filter."
          >
            {jobs.map((job) => (
              <tr key={job.id}>
                <th scope="row" className="py-2.5 pr-4 text-left font-normal">
                  {job.kind.replace(/_/g, ' ')}
                </th>
                <td className="py-2.5 pr-4">
                  <Badge tone={STATUS_TONE[job.status] ?? 'neutral'}>{job.status}</Badge>
                  {job.cancelRequested ? (
                    <span className="ml-1 text-xs text-fg-subtle">cancel requested</span>
                  ) : null}
                </td>
                <td className="py-2.5 pr-4 tabular-nums text-xs">
                  {job.progressTotal === null
                    ? `${job.progressDone}`
                    : `${job.progressDone} / ${job.progressTotal}`}
                </td>
                <td className="py-2.5 pr-4 tabular-nums text-xs">{job.attempts}</td>
                <td className="py-2.5 pr-4">
                  <Link
                    href={`/admin/organizations/${job.organizationId}`}
                    className="text-xs text-primary underline underline-offset-2"
                  >
                    {shortId(job.organizationId)}
                  </Link>
                </td>
                <td className="py-2.5 pr-4 text-xs text-fg-muted">
                  {formatDateTime(job.createdAt)}
                </td>
                <td className="py-2.5 pr-4 text-xs text-fg-muted">
                  {job.failureCode ? (
                    <span title={job.failureDetail ?? undefined}>{job.failureCode}</span>
                  ) : (
                    '—'
                  )}
                </td>
              </tr>
            ))}
          </AdminTable>
        </Card>
      </div>
    </>
  );
}
