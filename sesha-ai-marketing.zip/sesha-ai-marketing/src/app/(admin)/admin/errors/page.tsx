import type { Metadata } from 'next';
import Link from 'next/link';

import {
  AdminPageHeader,
  AdminTable,
  formatDateTime,
  shortId,
} from '@/components/admin/admin-primitives';
import { ResolveErrorButton } from '@/components/admin/triage-controls';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getDatabase } from '@/lib/db';
import { listErrors } from '@/lib/admin/service';
import { requireStaffPage } from '@/lib/admin/page-guard';
import { permissionsFor } from '@/lib/admin/auth';

export const metadata: Metadata = {
  title: 'Errors',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

const SEVERITY_TONE = {
  warning: 'warning',
  error: 'danger',
  critical: 'danger',
} as const;

export default async function AdminErrorsPage() {
  const { staff } = await requireStaffPage('admin:errors:read');
  const errors = await listErrors({ db: getDatabase() }, staff);
  const canResolve = permissionsFor(staff.role).includes('admin:system:write');

  const occurrences = errors.reduce((total, row) => total + row.occurrences, 0);

  return (
    <>
      <AdminPageHeader
        title="Errors"
        summary="Grouped by fingerprint, so a loop that failed ten thousand times is one line. Messages are recorded with customer values stripped out."
      />

      <div className="flex flex-col gap-6">
        <Card>
          <CardHeader>
            <CardTitle as="h2">
              {errors.length === 1
                ? '1 open problem'
                : `${errors.length.toLocaleString('en-IN')} open problems`}
            </CardTitle>
            <CardDescription>
              {occurrences.toLocaleString('en-IN')} recorded occurrences between them. Resolving one
              changes a row, not the code — it comes back if it happens again.
            </CardDescription>
          </CardHeader>
          <AdminTable
            caption="Open errors"
            head={[
              'Message',
              'Severity',
              'Source',
              'Times',
              'First seen',
              'Last seen',
              'Organization',
              '',
            ]}
            empty="Nothing open. Errors appear here as they are recorded."
            minWidth="56rem"
          >
            {errors.map((row) => (
              <tr key={row.fingerprint}>
                <th scope="row" className="max-w-sm py-2.5 pr-4 text-left font-normal">
                  <span className="block truncate text-fg" title={row.message}>
                    {row.message}
                  </span>
                  <span className="block text-xs text-fg-subtle">{row.fingerprint}</span>
                </th>
                <td className="py-2.5 pr-4">
                  <Badge tone={SEVERITY_TONE[row.severity]}>{row.severity}</Badge>
                </td>
                <td className="py-2.5 pr-4 text-xs text-fg-muted">{row.source}</td>
                <td className="py-2.5 pr-4 tabular-nums">
                  {row.occurrences.toLocaleString('en-IN')}
                </td>
                <td className="py-2.5 pr-4 text-xs text-fg-muted">
                  {formatDateTime(row.firstSeenAt)}
                </td>
                <td className="py-2.5 pr-4 text-xs text-fg-muted">
                  {formatDateTime(row.lastSeenAt)}
                </td>
                <td className="py-2.5 pr-4">
                  {row.organizationId ? (
                    <Link
                      href={`/admin/organizations/${row.organizationId}`}
                      className="text-xs text-primary underline underline-offset-2"
                    >
                      {shortId(row.organizationId)}
                    </Link>
                  ) : (
                    <span className="text-xs text-fg-subtle">Platform</span>
                  )}
                </td>
                <td className="py-2.5">
                  {canResolve ? <ResolveErrorButton fingerprint={row.fingerprint} /> : null}
                </td>
              </tr>
            ))}
          </AdminTable>
        </Card>
      </div>
    </>
  );
}
