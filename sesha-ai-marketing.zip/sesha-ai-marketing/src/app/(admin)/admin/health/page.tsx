import type { Metadata } from 'next';

import { AdminPageHeader, NotMeasured } from '@/components/admin/admin-primitives';
import { HealthChecks } from '@/components/admin/health-checks';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getDatabase } from '@/lib/db';
import { health } from '@/lib/admin/service';
import { requireStaffPage } from '@/lib/admin/page-guard';

export const metadata: Metadata = {
  title: 'System health',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

export default async function AdminHealthPage() {
  const { staff } = await requireStaffPage('admin:health:read');
  const report = await health({ db: getDatabase() }, staff);

  const worst = report.checks.reduce<'ok' | 'warn' | 'fail' | 'unknown'>((acc, check) => {
    const order = { fail: 3, warn: 2, unknown: 1, ok: 0 } as const;
    return order[check.state] > order[acc] ? check.state : acc;
  }, 'ok');

  return (
    <>
      <AdminPageHeader
        title="System health"
        summary="Everything below is checked, not asserted. There is no uptime figure and no green tick, because neither would mean anything here."
      />

      <div className="flex flex-col gap-6">
        <Card>
          <CardHeader>
            <CardTitle as="h2">Checks</CardTitle>
            <CardDescription>
              {worst === 'ok'
                ? 'Every check that can be performed passed.'
                : worst === 'fail'
                  ? 'At least one check is failing. Read the detail before restarting anything.'
                  : 'At least one check needs attention.'}
            </CardDescription>
          </CardHeader>
          <div className="px-6 pb-6">
            <HealthChecks checks={report.checks} />
          </div>
        </Card>

        <NotMeasured items={report.notMeasured} />
      </div>
    </>
  );
}
