import type { Metadata } from 'next';

import {
  AdminPageHeader,
  AdminTable,
  NotMeasured,
  Stat,
  StatGrid,
} from '@/components/admin/admin-primitives';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getDatabase } from '@/lib/db';
import { platformUsage } from '@/lib/admin/service';
import { requireStaffPage } from '@/lib/admin/page-guard';
import { PLANS_BY_RANK } from '@/content/plans';
import { METRIC_LABEL, WRITABLE_METRICS } from '@/lib/usage/metrics';

export const metadata: Metadata = {
  title: 'Platform usage',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

export default async function AdminUsagePage() {
  const { staff } = await requireStaffPage('admin:usage:read');
  const usage = await platformUsage({ db: getDatabase() }, staff);

  return (
    <>
      <AdminPageHeader
        title="Platform usage"
        summary={`Everything counted for the period starting ${usage.periodStart}. AI figures cover the last 30 days.`}
      />

      <div className="flex flex-col gap-6">
        <StatGrid>
          <Stat label="AI requests" value={usage.ai.requests} note="Last 30 days." />
          <Stat label="Tokens" value={usage.ai.tokens} note="Last 30 days." />
          <Stat
            label="Accounts"
            value={usage.byPlan.reduce((total, entry) => total + entry.organizations, 0)}
          />
          <Stat label="Period" value={usage.periodStart} note="Resets on the 1st, UTC." />
        </StatGrid>

        <Card>
          <CardHeader>
            <CardTitle as="h2">Measurements</CardTitle>
            <CardDescription>
              All eight, including any still at zero. A missing row would be indistinguishable from
              a recording bug.
            </CardDescription>
          </CardHeader>
          <AdminTable caption="Usage by measurement" head={['Measurement', 'This period']} minWidth="24rem">
            {WRITABLE_METRICS.map((metric) => (
              <tr key={metric}>
                <th scope="row" className="py-2.5 pr-4 text-left font-normal">
                  {METRIC_LABEL[metric]}
                </th>
                <td className="py-2.5 pr-4 tabular-nums">
                  {(usage.totals[metric] ?? 0).toLocaleString('en-IN')}
                </td>
              </tr>
            ))}
          </AdminTable>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle as="h2">Accounts by plan</CardTitle>
            <CardDescription>Where the platform&rsquo;s load is actually coming from.</CardDescription>
          </CardHeader>
          <AdminTable caption="Accounts by plan" head={['Plan', 'Accounts']} minWidth="24rem">
            {PLANS_BY_RANK.map((plan) => (
              <tr key={plan.id}>
                <th scope="row" className="py-2.5 pr-4 text-left font-normal">
                  {plan.name}
                </th>
                <td className="py-2.5 pr-4 tabular-nums">
                  {(
                    usage.byPlan.find((entry) => entry.plan === plan.id)?.organizations ?? 0
                  ).toLocaleString('en-IN')}
                </td>
              </tr>
            ))}
          </AdminTable>
        </Card>

        <NotMeasured
          items={[
            'Cost — token counts are recorded, provider invoices are not, so no spend figure is shown here or anywhere else.',
            'Per-metric history — these are the totals for the period in progress. Earlier periods are readable per organization, not aggregated.',
            'Per-provider breakdown — usage is recorded per organization and metric, not per AI provider.',
          ]}
        />
      </div>
    </>
  );
}
