import type { Metadata } from 'next';
import Link from 'next/link';

import { AdminPageHeader, AdminTable, formatDateTime } from '@/components/admin/admin-primitives';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getDatabase } from '@/lib/db';
import { listOrganizations } from '@/lib/admin/service';
import { requireStaffPage } from '@/lib/admin/page-guard';
import { PLANS_BY_RANK, resolvePlanId } from '@/content/plans';
import { STATUS_LABEL, STATUS_TONE, type SubscriptionStatus } from '@/lib/billing/types';

export const metadata: Metadata = {
  title: 'Organizations',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

export default async function AdminOrganizationsPage({
  searchParams,
}: {
  readonly searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { staff } = await requireStaffPage('admin:businesses:read');
  const params = await searchParams;

  const query = typeof params.q === 'string' ? params.q : '';
  const plan = typeof params.plan === 'string' ? params.plan : '';

  const rows = await listOrganizations({ db: getDatabase() }, staff, {
    ...(query ? { query } : {}),
    ...(plan ? { plan } : {}),
  });

  return (
    <>
      <AdminPageHeader
        title="Organizations"
        summary="Metadata only — plan, members, projects and subscription state. No screen here shows a customer's content."
      />

      <div className="flex flex-col gap-6">
        <Card>
          <CardHeader>
            <CardTitle as="h2">Find an account</CardTitle>
            <CardDescription>
              Your search term is recorded in the audit trail. The results are not.
            </CardDescription>
          </CardHeader>
          {/* A GET form: searching is a read, and a read should be linkable,
              bookmarkable and back-button-safe. */}
          <form method="get" className="flex flex-wrap items-end gap-3 px-6 pb-6">
            <label className="flex flex-col gap-1.5 text-sm">
              <span className="font-medium">Name or slug</span>
              <input
                type="search"
                name="q"
                defaultValue={query}
                placeholder="Acme"
                className="w-56 rounded-control border border-border bg-surface px-3.5 py-2 text-sm"
              />
            </label>
            <label className="flex flex-col gap-1.5 text-sm">
              <span className="font-medium">Plan</span>
              <select
                name="plan"
                defaultValue={plan}
                className="w-40 rounded-control border border-border bg-surface px-3 py-2 text-sm"
              >
                <option value="">Any</option>
                {PLANS_BY_RANK.map((definition) => (
                  <option key={definition.id} value={definition.id}>
                    {definition.name}
                  </option>
                ))}
              </select>
            </label>
            <button
              type="submit"
              className="rounded-control bg-primary px-4 py-2 text-sm font-medium text-primary-fg"
            >
              Search
            </button>
            {query || plan ? (
              <Link href="/admin/organizations" className="py-2 text-sm text-fg-muted underline">
                Clear
              </Link>
            ) : null}
          </form>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle as="h2">
              {rows.length === 1 ? '1 account' : `${rows.length.toLocaleString('en-IN')} accounts`}
            </CardTitle>
            <CardDescription>
              Newest first, capped at 100. Narrow the search rather than paging.
            </CardDescription>
          </CardHeader>
          <AdminTable
            caption="Organizations"
            head={['Organization', 'Plan', 'Subscription', 'Members', 'Projects', 'Created']}
            empty={
              query || plan
                ? 'No account matches that. Check the spelling — search is exact on the slug and partial on the name.'
                : 'No accounts yet.'
            }
          >
            {rows.map((row) => {
              const planId = resolvePlanId(row.organization.plan);
              const status = row.subscription?.status as SubscriptionStatus | undefined;
              return (
                <tr key={row.organization.id}>
                  <th scope="row" className="py-2.5 pr-4 text-left font-normal">
                    <Link
                      href={`/admin/organizations/${row.organization.id}`}
                      className="font-medium text-primary underline underline-offset-2"
                    >
                      {row.organization.name}
                    </Link>
                    <span className="block text-xs text-fg-subtle">{row.organization.slug}</span>
                  </th>
                  <td className="py-2.5 pr-4">
                    {planId ? (
                      PLANS_BY_RANK.find((definition) => definition.id === planId)?.name
                    ) : (
                      // A stored plan the registry does not know is a real
                      // possibility after a rename, and hiding it would hide a
                      // bug. The customer is treated as free; staff see the raw
                      // value.
                      <Badge tone="danger">Unrecognised: {row.organization.plan}</Badge>
                    )}
                  </td>
                  <td className="py-2.5 pr-4">
                    {status ? (
                      <Badge tone={STATUS_TONE[status]}>{STATUS_LABEL[status]}</Badge>
                    ) : (
                      <span className="text-xs text-fg-subtle">No row</span>
                    )}
                  </td>
                  <td className="py-2.5 pr-4 tabular-nums">{row.memberCount}</td>
                  <td className="py-2.5 pr-4 tabular-nums">{row.projectCount}</td>
                  <td className="py-2.5 pr-4 text-xs text-fg-muted">
                    {formatDateTime(row.organization.createdAt)}
                  </td>
                </tr>
              );
            })}
          </AdminTable>
        </Card>
      </div>
    </>
  );
}
