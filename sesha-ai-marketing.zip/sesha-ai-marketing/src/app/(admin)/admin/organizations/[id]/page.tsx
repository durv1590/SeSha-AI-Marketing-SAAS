import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';

import {
  AdminPageHeader,
  AdminTable,
  Stat,
  StatGrid,
  formatDateTime,
} from '@/components/admin/admin-primitives';
import { OrganizationControls } from '@/components/admin/organization-controls';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getDatabase } from '@/lib/db';
import { organizationDetail } from '@/lib/admin/service';
import { requireStaffPage } from '@/lib/admin/page-guard';
import { permissionsFor } from '@/lib/admin/auth';
import { formatLimit, PLAN_DEFINITIONS } from '@/content/plans';
import { EVENT_LABEL, STATUS_LABEL, type SubscriptionEvent, type SubscriptionStatus } from '@/lib/billing/types';

export const metadata: Metadata = {
  title: 'Organization',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

export default async function AdminOrganizationPage({
  params,
}: {
  readonly params: Promise<{ readonly id: string }>;
}) {
  const { staff } = await requireStaffPage('admin:businesses:read');
  const { id } = await params;

  const detail = await organizationDetail({ db: getDatabase() }, staff, id);
  // Same 404 as a made-up id. Staff can read across tenants, but an id that does
  // not exist should not be distinguishable from one they cannot see.
  if (!detail) notFound();

  const held = permissionsFor(staff.role);
  const canOverride = held.includes('admin:limits:write');
  const canChangePlan = held.includes('admin:subscriptions:write');
  const status = detail.subscription?.status as SubscriptionStatus | undefined;
  const overridden = detail.limits.filter((entry) => entry.source === 'override');

  return (
    <>
      <AdminPageHeader
        title={detail.organization.name}
        summary={`${detail.organization.slug} · ${PLAN_DEFINITIONS[detail.plan].name}${status ? ` · ${STATUS_LABEL[status]}` : ' · no subscription row'}`}
        actions={
          <Link
            href="/admin/organizations"
            className="rounded-control border border-border px-3 py-1.5 text-sm text-fg-muted"
          >
            All organizations
          </Link>
        }
      />

      <div className="flex flex-col gap-6">
        <StatGrid>
          <Stat label="Members" value={detail.members.length} />
          <Stat label="Projects" value={detail.projects.length} />
          <Stat label="Businesses" value={detail.businesses.length} />
          <Stat
            label="Overrides"
            value={overridden.length}
            {...(overridden.length > 0 ? { note: 'This account is not on stock limits.' } : {})}
          />
        </StatGrid>

        <Card>
          <CardHeader>
            <CardTitle as="h2">Limits and usage</CardTitle>
            <CardDescription>
              The period in progress. An overridden row shows the reason it was granted.
            </CardDescription>
          </CardHeader>
          <AdminTable
            caption="Limits and usage"
            head={['Limit', 'Allowed', 'Used', 'Source']}
            minWidth="34rem"
          >
            {detail.limits.map((entry) => (
              <tr key={entry.limitId}>
                <th scope="row" className="py-2.5 pr-4 text-left font-normal">
                  {entry.label}
                </th>
                <td className="py-2.5 pr-4 tabular-nums">{formatLimit(entry.value)}</td>
                <td className="py-2.5 pr-4 tabular-nums">
                  {entry.used.toLocaleString('en-IN')}
                </td>
                <td className="py-2.5 pr-4">
                  {entry.source === 'override' ? (
                    <span className="flex flex-col gap-0.5">
                      <Badge tone="warning">Override</Badge>
                      {entry.overrideReason ? (
                        <span className="text-xs text-fg-muted">{entry.overrideReason}</span>
                      ) : null}
                    </span>
                  ) : (
                    <span className="text-xs text-fg-subtle">Plan</span>
                  )}
                </td>
              </tr>
            ))}
          </AdminTable>
        </Card>

        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle as="h2">People</CardTitle>
              <CardDescription>
                Email, name and role. Nothing they have written is readable from here.
              </CardDescription>
            </CardHeader>
            <ul className="flex flex-col divide-y divide-border px-6 pb-6 text-sm">
              {detail.members.map((member) => (
                <li key={member.email} className="flex justify-between gap-3 py-2">
                  <span className="min-w-0">
                    <span className="block truncate text-fg">{member.name ?? member.email}</span>
                    {member.name ? (
                      <span className="block truncate text-xs text-fg-subtle">{member.email}</span>
                    ) : null}
                  </span>
                  <span className="shrink-0 text-xs text-fg-muted">{member.role}</span>
                </li>
              ))}
            </ul>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle as="h2">Projects</CardTitle>
              <CardDescription>Names and states only.</CardDescription>
            </CardHeader>
            {detail.projects.length === 0 ? (
              <p className="px-6 pb-6 text-sm text-fg-muted">No projects.</p>
            ) : (
              <ul className="flex flex-col divide-y divide-border px-6 pb-6 text-sm">
                {detail.projects.map((project) => (
                  <li key={project.id} className="flex justify-between gap-3 py-2">
                    <span className="truncate text-fg">{project.name}</span>
                    <span className="shrink-0 text-xs text-fg-muted">{project.status}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle as="h2">Billing history</CardTitle>
              <CardDescription>
                Including events that were received and deliberately not applied.
              </CardDescription>
            </CardHeader>
            {detail.billingHistory.length === 0 ? (
              <p className="px-6 pb-6 text-sm text-fg-muted">Nothing recorded.</p>
            ) : (
              <ul className="flex flex-col divide-y divide-border px-6 pb-6 text-sm">
                {detail.billingHistory.map((entry, index) => (
                  <li
                    key={`${entry.event}-${entry.occurredAt}-${index}`}
                    className="flex flex-wrap justify-between gap-x-3 gap-y-1 py-2"
                  >
                    <span className="text-fg">
                      {EVENT_LABEL[entry.event as SubscriptionEvent] ?? entry.event}
                      {entry.applied ? null : (
                        <span className="ml-2 text-xs text-fg-subtle">not applied</span>
                      )}
                    </span>
                    <span className="text-xs tabular-nums text-fg-subtle">
                      {formatDateTime(entry.occurredAt)}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card>
            <CardHeader>
              <CardTitle as="h2">Recent refusals</CardTitle>
              <CardDescription>
                What this account was stopped from doing, in the words it was told.
              </CardDescription>
            </CardHeader>
            {detail.recentRefusals.length === 0 ? (
              <p className="px-6 pb-6 text-sm text-fg-muted">Nothing refused for a limit.</p>
            ) : (
              <ul className="flex flex-col gap-2 px-6 pb-6 text-sm">
                {detail.recentRefusals.map((refusal, index) => (
                  <li key={`${refusal.limitId}-${index}`} className="flex flex-col">
                    <span className="text-fg">{refusal.reason}</span>
                    <span className="text-xs text-fg-subtle">
                      {formatDateTime(refusal.refusedAt)}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>

        {canOverride || canChangePlan ? (
          <OrganizationControls
            organizationId={detail.organization.id}
            currentPlan={detail.plan}
            limits={detail.limits.map((entry) => ({
              limitId: entry.limitId,
              value: entry.value,
              source: entry.source,
            }))}
          />
        ) : (
          <Card tone="subtle">
            <CardHeader>
              <CardTitle as="h2">Read only</CardTitle>
              <CardDescription>
                Your role can see this account but cannot change its plan or its limits.
              </CardDescription>
            </CardHeader>
          </Card>
        )}
      </div>
    </>
  );
}
