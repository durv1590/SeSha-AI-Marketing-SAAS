import type { Metadata } from 'next';

import { AdminPageHeader } from '@/components/admin/admin-primitives';
import { FlagRuleEditor } from '@/components/admin/flag-controls';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getDatabase } from '@/lib/db';
import { listFlags } from '@/lib/admin/service';
import { requireStaffPage } from '@/lib/admin/page-guard';
import { permissionsFor } from '@/lib/admin/auth';
import { CATEGORY_LABEL, FLAG_CATEGORIES, type FlagCategory } from '@/lib/flags';
import { PLAN_DEFINITIONS, resolvePlanId } from '@/content/plans';

export const metadata: Metadata = {
  title: 'Feature flags',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

export default async function AdminFlagsPage() {
  const { staff } = await requireStaffPage('admin:flags:write');
  const flags = await listFlags({ db: getDatabase() }, staff);
  const canEdit = permissionsFor(staff.role).includes('admin:flags:write');

  return (
    <>
      <AdminPageHeader
        title="Feature flags"
        summary="A fixed registry, not free-form keys. A flag created by typing a new name into a form is one nobody documents and nobody removes."
      />

      <div className="flex flex-col gap-6">
        {FLAG_CATEGORIES.map((category) => {
          const inCategory = flags.filter((flag) => flag.category === category);
          if (inCategory.length === 0) return null;

          return (
            <Card key={category}>
              <CardHeader>
                <CardTitle as="h2">{CATEGORY_LABEL[category as FlagCategory]}</CardTitle>
                <CardDescription>
                  {inCategory.length === 1 ? '1 flag' : `${inCategory.length} flags`}.
                </CardDescription>
              </CardHeader>

              <ul className="flex flex-col divide-y divide-border px-6 pb-6">
                {inCategory.map((flag) => (
                  <li key={flag.key} className="flex flex-col gap-2 py-4">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-medium text-fg">{flag.label}</span>
                      <code className="text-xs text-fg-subtle">{flag.key}</code>
                      {flag.rule?.disabled ? (
                        <Badge tone="danger">Off for everyone</Badge>
                      ) : flag.rule ? (
                        <Badge tone="brand">Rule set</Badge>
                      ) : (
                        <Badge tone="outline">
                          Default: {flag.defaultValue ? 'on' : 'off'}
                        </Badge>
                      )}
                      {flag.available ? null : <Badge tone="warning">Not usable yet</Badge>}
                    </div>

                    <p className="text-sm text-fg-muted">{flag.description}</p>

                    {flag.unavailableReason ? (
                      <p className="text-xs text-warning">{flag.unavailableReason}</p>
                    ) : null}

                    {flag.rule ? (
                      <dl className="flex flex-wrap gap-x-6 gap-y-1 text-xs text-fg-muted">
                        <div className="flex gap-1">
                          <dt>Rollout:</dt>
                          <dd className="tabular-nums">{flag.rule.rolloutPercent}%</dd>
                        </div>
                        <div className="flex gap-1">
                          <dt>Plans:</dt>
                          <dd>
                            {flag.rule.plans.length === 0
                              ? 'none'
                              : flag.rule.plans
                                  .map((plan) => {
                                    const resolved = resolvePlanId(plan);
                                    return resolved ? PLAN_DEFINITIONS[resolved].name : plan;
                                  })
                                  .join(', ')}
                          </dd>
                        </div>
                        <div className="flex gap-1">
                          <dt>Named on:</dt>
                          <dd className="tabular-nums">{flag.rule.organizationIds.length}</dd>
                        </div>
                        <div className="flex gap-1">
                          <dt>Excluded:</dt>
                          <dd className="tabular-nums">
                            {flag.rule.excludedOrganizationIds.length}
                          </dd>
                        </div>
                        <div className="flex gap-1">
                          <dt>Changed:</dt>
                          <dd>{new Date(flag.rule.updatedAt).toISOString().slice(0, 10)}</dd>
                        </div>
                      </dl>
                    ) : null}

                    {canEdit ? (
                      <FlagRuleEditor
                        flagKey={flag.key}
                        label={flag.label}
                        rule={
                          flag.rule
                            ? {
                                disabled: flag.rule.disabled,
                                organizationIds: flag.rule.organizationIds,
                                excludedOrganizationIds: flag.rule.excludedOrganizationIds,
                                plans: flag.rule.plans,
                                rolloutPercent: flag.rule.rolloutPercent,
                              }
                            : null
                        }
                      />
                    ) : null}
                  </li>
                ))}
              </ul>
            </Card>
          );
        })}
      </div>
    </>
  );
}
