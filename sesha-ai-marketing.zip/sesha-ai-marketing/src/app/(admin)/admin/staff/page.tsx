import type { Metadata } from 'next';

import { AdminPageHeader, AdminTable, formatDateTime } from '@/components/admin/admin-primitives';
import { GrantStaffForm, RevokeStaffButton } from '@/components/admin/staff-controls';
import { Badge } from '@/components/ui/badge';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getDatabase } from '@/lib/db';
import { listStaff } from '@/lib/admin/service';
import { requireStaffPage } from '@/lib/admin/page-guard';
import { STAFF_ROLES, STAFF_ROLE_DESCRIPTION, STAFF_ROLE_LABEL, permissionsFor } from '@/lib/admin/auth';

export const metadata: Metadata = {
  title: 'Platform staff',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

export default async function AdminStaffPage() {
  const { staff } = await requireStaffPage('admin:staff:read');
  const rows = await listStaff({ db: getDatabase() }, staff);
  const canManage = permissionsFor(staff.role).includes('admin:staff:write');

  const active = rows.filter((row) => row.revokedAt === null);
  const revoked = rows.filter((row) => row.revokedAt !== null);
  const owners = active.filter((row) => row.role === 'platform_owner');

  return (
    <>
      <AdminPageHeader
        title="Platform staff"
        summary="Who can see across every tenant, who granted it, and why. Organization owners are not staff — the two are deliberately different things."
      />

      <div className="flex flex-col gap-6">
        <Card tone="subtle">
          <CardHeader>
            <CardTitle as="h2">The three roles</CardTitle>
            <CardDescription>
              Permissions are declared as a minimum role, so a new one cannot be accidentally
              granted to everybody or forgotten for a role.
            </CardDescription>
          </CardHeader>
          <ul className="flex flex-col gap-3 px-6 pb-6 text-sm">
            {STAFF_ROLES.map((role) => (
              <li key={role} className="flex flex-col gap-0.5">
                <span className="font-medium text-fg">{STAFF_ROLE_LABEL[role]}</span>
                <span className="text-fg-muted">{STAFF_ROLE_DESCRIPTION[role]}</span>
                <span className="text-xs text-fg-subtle">
                  {permissionsFor(role).length} permissions.
                </span>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle as="h2">
              {active.length === 1 ? '1 active grant' : `${active.length} active grants`}
            </CardTitle>
            <CardDescription>
              {owners.length === 1
                ? 'One platform owner. They cannot revoke themselves — with nobody holding the role, access could not be restored without direct database access.'
                : `${owners.length} platform owners.`}
            </CardDescription>
          </CardHeader>
          <AdminTable
            caption="Active platform staff"
            head={['User', 'Role', 'Reason', 'Granted', canManage ? '' : 'Granted by']}
            empty="Nobody holds platform access. That should not be possible while you are reading this page."
            minWidth="44rem"
          >
            {active.map((row) => (
              <tr key={row.id}>
                <th scope="row" className="py-2.5 pr-4 text-left font-normal">
                  <code className="text-xs">{row.userId}</code>
                </th>
                <td className="py-2.5 pr-4">
                  <Badge tone={row.role === 'platform_owner' ? 'danger' : 'outline'}>
                    {STAFF_ROLE_LABEL[row.role]}
                  </Badge>
                </td>
                <td className="max-w-xs py-2.5 pr-4 text-sm text-fg-muted">{row.reason}</td>
                <td className="py-2.5 pr-4 text-xs text-fg-muted">
                  {formatDateTime(row.grantedAt)}
                </td>
                <td className="py-2.5">
                  {canManage ? (
                    <RevokeStaffButton userId={row.userId} label={STAFF_ROLE_LABEL[row.role]} />
                  ) : (
                    <code className="text-xs text-fg-subtle">{row.grantedBy ?? '—'}</code>
                  )}
                </td>
              </tr>
            ))}
          </AdminTable>
        </Card>

        {canManage ? <GrantStaffForm /> : null}

        {revoked.length > 0 ? (
          <Card>
            <CardHeader>
              <CardTitle as="h2">Revoked</CardTitle>
              <CardDescription>
                Kept rather than deleted. &ldquo;Who used to have access&rdquo; is a question that
                gets asked after an incident, and a deleted row cannot answer it.
              </CardDescription>
            </CardHeader>
            <AdminTable
              caption="Revoked platform staff"
              head={['User', 'Role', 'Reason it was granted', 'Revoked']}
              minWidth="40rem"
            >
              {revoked.map((row) => (
                <tr key={row.id}>
                  <th scope="row" className="py-2.5 pr-4 text-left font-normal">
                    <code className="text-xs">{row.userId}</code>
                  </th>
                  <td className="py-2.5 pr-4 text-xs text-fg-muted">
                    {STAFF_ROLE_LABEL[row.role]}
                  </td>
                  <td className="max-w-xs py-2.5 pr-4 text-sm text-fg-muted">{row.reason}</td>
                  <td className="py-2.5 pr-4 text-xs text-fg-muted">
                    {row.revokedAt ? formatDateTime(row.revokedAt) : '—'}
                  </td>
                </tr>
              ))}
            </AdminTable>
          </Card>
        ) : null}
      </div>
    </>
  );
}
