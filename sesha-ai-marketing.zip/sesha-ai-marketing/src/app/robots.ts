import type { MetadataRoute } from 'next';

import { absoluteUrl } from '@/lib/seo/core';

/**
 * robots.txt.
 *
 * The API namespace is disallowed because those endpoints accept POST and
 * return JSON — there is nothing to index and crawling them only consumes the
 * rate-limit budget.
 */
export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/api/'],
      },
    ],
    sitemap: absoluteUrl('/sitemap.xml'),
    host: absoluteUrl('/'),
  };
}
