import { redirect } from 'next/navigation';
import type { Metadata } from 'next';

import { OnboardingWizard } from '@/components/app/onboarding-wizard';
import { Logo } from '@/components/layout/logo';
import { Container } from '@/components/layout/container';
import { getCurrentSession } from '@/lib/auth/current-session';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Set up your workspace',
  description: 'Tell us about your business so SeSha can build your AI marketing profile.',
  path: '/onboarding',
  noindex: true,
});

export const dynamic = 'force-dynamic';

/**
 * Onboarding.
 *
 * Outside the (app) route group, because the dashboard shell would be
 * misleading before a workspace exists. The session is still required, and
 * a user who has already onboarded is sent to the workspace.
 */
export default async function OnboardingPage() {
  const session = await getCurrentSession();
  if (!session) redirect('/sign-in?next=/onboarding');
  if (session.user.onboardingCompletedAt) redirect('/app');

  return (
    <div className="min-h-dvh bg-bg-subtle">
      <a
        href="#main"
        className="skip-link rounded-control bg-primary px-4 py-2 text-sm font-medium text-primary-fg shadow-lg"
      >
        Skip to main content
      </a>

      <header className="border-b border-border bg-bg">
        <Container className="flex h-16 items-center">
          <Logo href="/app" />
        </Container>
      </header>

      <main id="main" tabIndex={-1} className="focus:outline-none">
        <Container className="py-10 lg:py-14">
          <div className="mx-auto mb-8 max-w-2xl">
            <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
              Set up your workspace
            </h1>
            <p className="mt-2 text-base leading-relaxed text-fg-muted">
              Four short steps. This becomes the context every module reads from, so it is worth
              being specific.
            </p>
          </div>
          <OnboardingWizard />
        </Container>
      </main>
    </div>
  );
}
