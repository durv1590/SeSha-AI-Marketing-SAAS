import type { Metadata, Viewport } from 'next';

import './globals.css';
import { themeScript } from '@/components/layout/theme';
import { JsonLd } from '@/components/seo/json-ld';
import { site } from '@/content/site';
import { buildMetadata } from '@/lib/seo/metadata';
import { seoFor } from '@/content/seo-map';
import { buildGraph, organizationSchema, webSiteSchema } from '@/lib/schema';

/**
 * Root layout.
 *
 * Site-wide responsibilities that belong here and nowhere else:
 *  - the <html lang> attribute and viewport;
 *  - the no-flash theme script, inlined before paint;
 *  - the Organization and WebSite JSON-LD nodes, emitted once for the whole
 *    site so per-page graphs can reference them by @id.
 *
 * The header, footer and skip link live in `(marketing)/layout.tsx`, because
 * the authenticated application and the sign-in pages must NOT inherit
 * marketing navigation.
 */

export const metadata: Metadata = {
  ...buildMetadata(seoFor('/')),
  applicationName: site.name,
  authors: [{ name: site.name, url: site.url }],
  creator: site.name,
  publisher: site.name,
  formatDetection: { email: false, address: false, telephone: false },
  icons: {
    icon: [{ url: '/favicon.svg', type: 'image/svg+xml' }],
    apple: [{ url: '/icon-180.png', sizes: '180x180' }],
  },
  manifest: '/site.webmanifest',
  ...(process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION
    ? { verification: { google: process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION } }
    : {}),
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: site.themeColor.light },
    { media: '(prefers-color-scheme: dark)', color: site.themeColor.dark },
  ],
};

export default function RootLayout({ children }: { readonly children: React.ReactNode }) {
  const siteGraph = buildGraph([organizationSchema(), webSiteSchema()]);

  return (
    <html lang={site.language} suppressHydrationWarning>
      <head>
        {/*
          Runs before first paint so a dark-mode visitor never sees a white
          flash. It only toggles a class; it does not touch page content, so
          hydration is unaffected.
        */}
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="min-h-dvh bg-bg text-fg antialiased">
        {children}
        <JsonLd graph={siteGraph} />
      </body>
    </html>
  );
}
