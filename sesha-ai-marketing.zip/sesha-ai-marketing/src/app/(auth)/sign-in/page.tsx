import { Suspense } from 'react';
import Link from 'next/link';
import type { Metadata } from 'next';

import { AuthShell } from '@/components/auth/auth-shell';
import { AuthDivider, GoogleButton } from '@/components/auth/google-button';
import { SignInForm } from '@/components/auth/sign-in-form';
import { googleIsConfigured } from '@/lib/auth/oauth/google';
import { buildMetadata } from '@/lib/seo/metadata';

// Authenticated surfaces are never indexed.
export const metadata: Metadata = buildMetadata({
  title: 'Sign in',
  description: 'Sign in to your SeSha AI Marketing workspace to manage your marketing.',
  path: '/sign-in',
  noindex: true,
});

export default function SignInPage() {
  return (
    <AuthShell
      title="Sign in"
      intro="Welcome back. Sign in to your workspace."
      footer={
        <>
          New here?{' '}
          <Link href="/sign-up" className="font-medium text-primary hover:text-primary-hover">
            Create an account
          </Link>
        </>
      }
    >
      <GoogleButton configured={googleIsConfigured()} />
      <AuthDivider />
      {/* useSearchParams requires a Suspense boundary during prerender. */}
      <Suspense fallback={<p className="text-sm text-fg-muted">Loading…</p>}>
        <SignInForm />
      </Suspense>
    </AuthShell>
  );
}
