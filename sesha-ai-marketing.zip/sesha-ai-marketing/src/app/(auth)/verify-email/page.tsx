import { Suspense } from 'react';
import type { Metadata } from 'next';

import { AuthShell } from '@/components/auth/auth-shell';
import { VerifyEmailPanel } from '@/components/auth/recovery-forms';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Confirm your email',
  description: 'Confirm your email address to finish setting up your SeSha workspace account.',
  path: '/verify-email',
  noindex: true,
});

export default function VerifyEmailPage() {
  return (
    <AuthShell title="Confirm your email" intro="One moment while we check your link.">
      <Suspense fallback={<p className="text-sm text-fg-muted">Loading…</p>}>
        <VerifyEmailPanel />
      </Suspense>
    </AuthShell>
  );
}
