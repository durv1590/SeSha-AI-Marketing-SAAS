import Link from 'next/link';
import type { Metadata } from 'next';

import { AuthShell } from '@/components/auth/auth-shell';
import { AuthDivider, GoogleButton } from '@/components/auth/google-button';
import { SignUpForm } from '@/components/auth/sign-up-form';
import { googleIsConfigured } from '@/lib/auth/oauth/google';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Create your account',
  description: 'Create a SeSha AI Marketing workspace and set up your marketing profile.',
  path: '/sign-up',
  noindex: true,
});

export default function SignUpPage() {
  return (
    <AuthShell
      title="Create your account"
      intro="Set up a workspace for your business. It takes a couple of minutes."
      footer={
        <>
          Already have an account?{' '}
          <Link href="/sign-in" className="font-medium text-primary hover:text-primary-hover">
            Sign in
          </Link>
        </>
      }
    >
      <GoogleButton configured={googleIsConfigured()} />
      <AuthDivider />
      <SignUpForm />
    </AuthShell>
  );
}
