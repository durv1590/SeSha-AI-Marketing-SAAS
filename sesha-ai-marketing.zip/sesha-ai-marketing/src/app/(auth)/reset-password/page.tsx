import { Suspense } from 'react';
import type { Metadata } from 'next';

import { AuthShell } from '@/components/auth/auth-shell';
import { ResetPasswordForm } from '@/components/auth/recovery-forms';
import { buildMetadata } from '@/lib/seo/metadata';

export const metadata: Metadata = buildMetadata({
  title: 'Choose a new password',
  description: 'Set a new password for your SeSha AI Marketing workspace account.',
  path: '/reset-password',
  noindex: true,
});

export default function ResetPasswordPage() {
  return (
    <AuthShell
      title="Choose a new password"
      intro="Setting a new password signs you out on every other device."
    >
      <Suspense fallback={<p className="text-sm text-fg-muted">Loading…</p>}>
        <ResetPasswordForm />
      </Suspense>
    </AuthShell>
  );
}
