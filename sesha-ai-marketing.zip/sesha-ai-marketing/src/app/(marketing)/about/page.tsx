import type { Metadata } from 'next';

import { Container, Section } from '@/components/layout/container';
import { ArticleMeta } from '@/components/marketing/answer-block';
import { CtaBlock } from '@/components/marketing/cta-block';
import { PageHero } from '@/components/marketing/page-hero';
import { Prose } from '@/components/marketing/prose';
import { JsonLd } from '@/components/seo/json-ld';
import { aboutPage } from '@/content/pages';
import { seoFor } from '@/content/seo-map';
import { authors } from '@/content/site';
import { breadcrumbSchema, buildGraph, organizationSchema, webPageSchema } from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

const PATH = '/about';

export const metadata: Metadata = buildMetadata(seoFor(PATH));

export default function AboutPage() {
  const seo = seoFor(PATH);
  const author = authors.editorial;
  const graph = buildGraph([
    webPageSchema({
      path: PATH,
      name: seo.title,
      description: seo.description,
      dateModified: aboutPage.lastUpdated,
    }),
    breadcrumbSchema(PATH),
    organizationSchema(),
  ]);

  return (
    <>
      <PageHero path={PATH} eyebrow="Company" heading={aboutPage.heading} intro={aboutPage.intro}>
        {author ? (
          <ArticleMeta
            authorName={author.name}
            authorRole={author.role}
            lastUpdated={aboutPage.lastUpdated}
          />
        ) : null}
      </PageHero>

      <Section spacing="md">
        <Container>
          <div className="max-w-3xl">
            <Prose blocks={aboutPage.blocks} />
          </div>
        </Container>
      </Section>

      <CtaBlock
        id="about-cta"
        heading="Talk to the people building it"
        body="Questions about the product, the roadmap or what is usable today go straight to the team."
        primary={{ label: 'Contact us', href: '/contact' }}
        secondary={{ label: 'Read our security posture', href: '/security' }}
      />
      <JsonLd graph={graph} />
    </>
  );
}
