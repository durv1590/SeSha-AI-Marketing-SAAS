import type { Metadata } from 'next';

import { Container, Section } from '@/components/layout/container';
import { Alert } from '@/components/ui/alert';
import { PageHero } from '@/components/marketing/page-hero';
import { Prose } from '@/components/marketing/prose';
import { JsonLd } from '@/components/seo/json-ld';
import { effectiveDate, legalReviewNotice, requiresLegalReview, privacyPolicy } from '@/content/legal';
import { seoFor } from '@/content/seo-map';
import { breadcrumbSchema, buildGraph, webPageSchema } from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

const PATH = '/privacy';

export const metadata: Metadata = buildMetadata(seoFor(PATH));

export default function LegalPage() {
  const seo = seoFor(PATH);
  const graph = buildGraph([
    webPageSchema({
      path: PATH,
      name: seo.title,
      description: seo.description,
      dateModified: effectiveDate,
    }),
    breadcrumbSchema(PATH),
  ]);

  return (
    <>
      <PageHero path={PATH} eyebrow="Legal" heading={privacyPolicy.heading} intro={privacyPolicy.intro}>
        <p className="text-sm text-fg-muted">
          Effective <time dateTime={effectiveDate}>{new Date(`${effectiveDate}T00:00:00Z`).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' })}</time>
        </p>
      </PageHero>

      <Section spacing="md">
        <Container>
          <div className="max-w-3xl">
            {requiresLegalReview ? (
              <Alert tone="warning" title="Pending legal review" className="mb-10">
                {legalReviewNotice}
              </Alert>
            ) : null}
            <Prose blocks={privacyPolicy.blocks} />
          </div>
        </Container>
      </Section>
      <JsonLd graph={graph} />
    </>
  );
}
