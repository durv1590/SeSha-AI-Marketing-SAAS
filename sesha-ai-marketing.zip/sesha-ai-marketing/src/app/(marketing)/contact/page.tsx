import type { Metadata } from 'next';

import { Container, Section } from '@/components/layout/container';
import { ContactForm } from '@/components/marketing/contact-form';
import { PageHero } from '@/components/marketing/page-hero';
import { JsonLd } from '@/components/seo/json-ld';
import { Card } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';
import { formatPhone, organization } from '@/content/site';
import { seoFor } from '@/content/seo-map';
import { breadcrumbSchema, buildGraph, organizationSchema, webPageSchema } from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

const PATH = '/contact';

export const metadata: Metadata = buildMetadata(seoFor(PATH));

const routes = [
  {
    title: 'Product and pricing',
    body: 'Questions about what the platform does, what is available today, or what a plan would cost for your team.',
    icon: 'info' as const,
  },
  {
    title: 'Security disclosure',
    body: 'Reporting a vulnerability? Choose the security topic, or email us with "Security" in the subject line.',
    icon: 'alert' as const,
  },
  {
    title: 'Partnerships',
    body: 'Agencies, integrators and technology partners — tell us what you have in mind.',
    icon: 'brand' as const,
  },
];

export default function ContactPage() {
  const seo = seoFor(PATH);
  const graph = buildGraph([
    webPageSchema({ path: PATH, name: seo.title, description: seo.description, dateModified: '2026-09-11' }),
    breadcrumbSchema(PATH),
    organizationSchema(),
  ]);

  return (
    <>
      <PageHero
        path={PATH}
        eyebrow="Contact"
        heading="Tell us what you are working on"
        intro="We would rather answer a specific question than send you a brochure. Describe your situation and we will tell you honestly whether the platform fits."
      />

      <Section spacing="md">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)] lg:gap-16">
            <div>
              <h2 className="sr-only">Contact form</h2>
              <ContactForm />
            </div>

            <aside className="flex flex-col gap-5">
              <Card tone="subtle" className="p-6">
                <h2 className="font-semibold tracking-tight">Prefer email?</h2>
                <p className="mt-2 text-sm leading-relaxed text-fg-muted">
                  Write to us directly and the same team will pick it up.
                </p>
                <a
                  href={`mailto:${organization.email}`}
                  className="mt-3 inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary-hover"
                >
                  {organization.email}
                  <Icon name="arrow-right" size={15} />
                </a>
              </Card>

              {organization.telephone ? (
                <Card tone="subtle" className="p-6">
                  <h2 className="font-semibold tracking-tight">Prefer to talk?</h2>
                  <p className="mt-2 text-sm leading-relaxed text-fg-muted">
                    Call or message us on WhatsApp during Indian business hours.
                  </p>
                  <a
                    href={`tel:${organization.telephone}`}
                    className="mt-3 inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary-hover"
                  >
                    <Icon name="phone" size={15} />
                    {formatPhone(organization.telephone)}
                  </a>
                </Card>
              ) : null}

              {routes.map((route) => (
                <div key={route.title} className="flex gap-3">
                  <span className="mt-0.5 inline-flex size-9 shrink-0 items-center justify-center rounded-control bg-primary-subtle text-primary-subtle-fg">
                    <Icon name={route.icon} size={18} />
                  </span>
                  <div>
                    <h2 className="text-sm font-semibold">{route.title}</h2>
                    <p className="mt-1 text-sm leading-relaxed text-fg-muted">{route.body}</p>
                  </div>
                </div>
              ))}
            </aside>
          </div>
        </Container>
      </Section>
      <JsonLd graph={graph} />
    </>
  );
}
