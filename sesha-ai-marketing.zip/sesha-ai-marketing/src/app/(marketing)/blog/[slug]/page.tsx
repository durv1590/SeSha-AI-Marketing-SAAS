import { notFound } from 'next/navigation';
import type { Metadata } from 'next';

import { Accordion } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Container, Section } from '@/components/layout/container';
import { ArticleMeta, DirectAnswer, RelatedLinks } from '@/components/marketing/answer-block';
import { CtaBlock } from '@/components/marketing/cta-block';
import { PageHero } from '@/components/marketing/page-hero';
import { Prose } from '@/components/marketing/prose';
import { JsonLd } from '@/components/seo/json-ld';
import { headings } from '@/content/blocks';
import { getPost, posts } from '@/content/blog';
import { articleSchema, breadcrumbSchema, buildGraph, faqPageSchema, webPageSchema } from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

/**
 * Blog post.
 *
 * Fully static: `generateStaticParams` pre-renders every post and
 * `dynamicParams = false` makes an unknown slug a real 404. Article structured
 * data is generated from the same post record that renders the page, so the
 * markup cannot describe content the page does not contain.
 */

export function generateStaticParams() {
  return posts.map((post) => ({ slug: post.slug }));
}

export const dynamicParams = false;

type Params = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const post = getPost(slug);
  if (!post) {
    return buildMetadata({ title: 'Not found', description: 'Page not found.', path: '/404', noindex: true });
  }
  return buildMetadata({
    title: post.title.length > 48 ? `${post.title.slice(0, 45).trimEnd()}…` : post.title,
    description: post.excerpt.slice(0, 158),
    path: `/blog/${post.slug}`,
    type: 'article',
    publishedTime: post.publishedAt,
    modifiedTime: post.updatedAt,
    authorName: post.author.name,
  });
}

export default async function BlogPostPage({ params }: Params) {
  const { slug } = await params;
  const post = getPost(slug);
  if (!post) notFound();

  const path = `/blog/${post.slug}`;
  const wordCount = post.blocks.reduce((total, block) => {
    if (block.kind === 'list') return total + block.items.join(' ').split(/\s+/).length;
    if (block.kind === 'callout') return total + block.text.split(/\s+/).length;
    if (block.kind === 'definition') return total + block.text.split(/\s+/).length;
    if (block.kind === 'paragraph' || block.kind === 'heading') {
      return total + block.text.split(/\s+/).length;
    }
    return total;
  }, 0);

  const graph = buildGraph([
    webPageSchema({
      path,
      name: post.title,
      description: post.excerpt,
      datePublished: post.publishedAt,
      dateModified: post.updatedAt,
    }),
    breadcrumbSchema(path),
    articleSchema({
      path,
      headline: post.title,
      description: post.excerpt,
      datePublished: post.publishedAt,
      dateModified: post.updatedAt,
      author: post.author,
      articleSection: post.category,
      wordCount,
    }),
    faqPageSchema(path, post.faqs),
  ]);

  const toc = headings(post.blocks);

  return (
    <>
      <PageHero path={path} heading={post.title}>
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-3">
            <Badge tone="outline">{post.category}</Badge>
            <span className="text-sm text-fg-subtle">{post.readingMinutes} min read</span>
          </div>
          <ArticleMeta
            authorName={post.author.name}
            authorRole={post.author.role}
            authorHref={post.author.url}
            publishedAt={post.publishedAt}
            lastUpdated={post.updatedAt}
          />
        </div>
      </PageHero>

      <Section spacing="md">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[minmax(0,1fr)_16rem] lg:gap-16">
            <article className="flex max-w-3xl flex-col gap-10">
              <DirectAnswer>{post.directAnswer}</DirectAnswer>
              <Prose blocks={post.blocks} />

              <section aria-labelledby="post-faq-heading">
                <h2 id="post-faq-heading" className="text-2xl font-semibold tracking-tight">
                  Frequently asked questions
                </h2>
                <Accordion
                  className="mt-6"
                  items={post.faqs.map((f) => ({ question: f.question, answer: f.answer }))}
                />
              </section>

              <RelatedLinks links={post.related} heading="Related reading" />
            </article>

            {toc.length > 0 ? (
              <nav aria-label="On this page" className="hidden lg:block">
                <div className="sticky top-24">
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-fg-subtle">
                    On this page
                  </p>
                  <ul className="mt-4 flex flex-col gap-2.5 border-l border-border pl-4">
                    {toc.map((item) => (
                      <li key={item.id}>
                        <a
                          href={`#${item.id}`}
                          className="text-sm text-fg-muted transition-colors hover:text-fg"
                        >
                          {item.text}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </nav>
            ) : null}
          </div>
        </Container>
      </Section>

      <CtaBlock
        id="post-cta"
        heading="Bring this into your workflow"
        body="SeSha turns the practices in this article into repeatable steps rather than reminders."
        primary={{ label: 'Start Free', href: '/contact' }}
        secondary={{ label: 'More articles', href: '/blog' }}
      />
      <JsonLd graph={graph} />
    </>
  );
}
