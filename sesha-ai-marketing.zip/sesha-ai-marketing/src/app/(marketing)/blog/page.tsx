import Link from 'next/link';
import type { Metadata } from 'next';

import { Container, Section } from '@/components/layout/container';
import { CtaBlock } from '@/components/marketing/cta-block';
import { PageHero } from '@/components/marketing/page-hero';
import { JsonLd } from '@/components/seo/json-ld';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';
import { postsNewestFirst } from '@/content/blog';
import { seoFor } from '@/content/seo-map';
import { breadcrumbSchema, buildGraph, webPageSchema } from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

const PATH = '/blog';

export const metadata: Metadata = buildMetadata(seoFor(PATH));

export default function BlogIndexPage() {
  const seo = seoFor(PATH);
  const graph = buildGraph([
    webPageSchema({ path: PATH, name: seo.title, description: seo.description, dateModified: '2026-09-11' }),
    breadcrumbSchema(PATH),
  ]);

  return (
    <>
      <PageHero
        path={PATH}
        eyebrow="Blog"
        heading="Writing on AI marketing, search and structured data"
        intro="Practical pieces from the editorial team. Each one leads with a direct answer, because we write them to be quotable."
      />

      <Section spacing="md">
        <Container>
          <ul className="grid gap-6 lg:grid-cols-3">
            {postsNewestFirst.map((post) => (
              <li key={post.slug}>
                <Card interactive className="relative flex h-full flex-col p-6">
                  <div className="flex items-center gap-3">
                    <Badge tone="outline">{post.category}</Badge>
                    <span className="text-xs text-fg-subtle">{post.readingMinutes} min read</span>
                  </div>

                  <h2 className="mt-4 text-lg font-semibold leading-snug tracking-tight">
                    <Link
                      href={`/blog/${post.slug}`}
                      className="after:absolute after:inset-0 after:content-['']"
                    >
                      {post.title}
                    </Link>
                  </h2>

                  <p className="mt-3 flex-1 text-sm leading-relaxed text-fg-muted">
                    {post.excerpt}
                  </p>

                  <div className="mt-5 flex items-center justify-between text-xs text-fg-subtle">
                    <time dateTime={post.publishedAt}>
                      {new Date(`${post.publishedAt}T00:00:00Z`).toLocaleDateString('en-GB', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                        timeZone: 'UTC',
                      })}
                    </time>
                    <span className="inline-flex items-center gap-1.5 font-medium text-primary">
                      Read
                      <Icon name="arrow-right" size={14} />
                    </span>
                  </div>
                </Card>
              </li>
            ))}
          </ul>
        </Container>
      </Section>

      <CtaBlock
        id="blog-cta"
        heading="Try what we write about"
        body="The structured-data validator implements the checks described in these articles, and it is free."
        primary={{ label: 'Open the validator', href: '/schema-validator' }}
        secondary={{ label: 'Browse resources', href: '/resources' }}
      />
      <JsonLd graph={graph} />
    </>
  );
}
