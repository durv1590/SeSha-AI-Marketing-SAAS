import type { Metadata } from 'next';

import { Container, Section } from '@/components/layout/container';
import { Accordion } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { DefinitionBlock, DirectAnswer, RelatedLinks } from '@/components/marketing/answer-block';
import { CtaBlock } from '@/components/marketing/cta-block';
import { PageHero } from '@/components/marketing/page-hero';
import { ValidatorTool } from '@/components/marketing/validator-tool';
import { JsonLd } from '@/components/seo/json-ld';
import { seoFor } from '@/content/seo-map';
import { SUPPORTED_TYPES } from '@/lib/schema-validator/validate';
import { breadcrumbSchema, buildGraph, faqPageSchema, webPageSchema } from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

const PATH = '/schema-validator';

export const metadata: Metadata = buildMetadata(seoFor(PATH));

const faqs = [
  {
    question: 'What does this validator check?',
    answer:
      'It parses your JSON-LD, walks every node including those inside an @graph, and checks each recognised type for required and recommended properties. It also applies integrity rules: ISO 8601 dates, dateModified not preceding datePublished, absolute URLs, unique @id values, sequential breadcrumb positions, complete FAQ question and answer pairs, and offers that declare a currency alongside a price.',
  },
  {
    question: 'Is it the same as Google Rich Results Test?',
    answer:
      'No. This tool runs locally against our own rule set and does not contact any search engine. Use it to catch structural errors quickly during development, then confirm eligibility with the search engine tools before you rely on a rich result.',
  },
  {
    question: 'Do you store what I paste in?',
    answer:
      'No. Your input is processed to produce the report and is not written to a database or logged as content. As with any web form, avoid pasting secrets.',
  },
  {
    question: 'Why does it warn about ratings and reviews?',
    answer:
      'Because rating markup is the most commonly abused structured data type. If the ratings are not genuine first-party reviews displayed on the page, publishing them risks a manual action — so the tool flags it for you to confirm rather than silently approving it.',
  },
  {
    question: 'Can I use it for types that are not listed?',
    answer:
      'You can paste anything. Unknown types are checked structurally and reported as a note rather than an error, so the rest of your document is still validated.',
  },
];

export default function SchemaValidatorPage() {
  const seo = seoFor(PATH);
  const graph = buildGraph([
    webPageSchema({ path: PATH, name: seo.title, description: seo.description, dateModified: '2026-09-11' }),
    breadcrumbSchema(PATH),
    faqPageSchema(PATH, faqs),
  ]);

  return (
    <>
      <PageHero
        path={PATH}
        eyebrow="Free tool"
        heading="JSON-LD structured data validator"
        intro="Paste your structured data and get the exact node path of anything that would cause it to be ignored. No account, no sign-up, nothing stored."
      />

      <Section spacing="sm">
        <Container>
          <ValidatorTool />
        </Container>
      </Section>

      <Section tone="subtle" spacing="md">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[minmax(0,1fr)_18rem] lg:gap-16">
            <div className="flex max-w-3xl flex-col gap-10">
              <DefinitionBlock
                term="Structured data"
                definition="Structured data is machine-readable markup — usually JSON-LD — that tells search engines and answer engines what the content on a page actually is: an article, a product, a set of questions and answers, a breadcrumb trail."
              />

              <DirectAnswer>
                Invalid structured data almost never reports an error. A node missing a required
                property is silently ignored, so a page can carry broken markup for months with no
                visible signal. Validating before you publish is the only reliable way to catch it.
              </DirectAnswer>

              <section aria-labelledby="types-heading">
                <h2 id="types-heading" className="text-2xl font-semibold tracking-tight">
                  Types with full property rules
                </h2>
                <p className="mt-3 text-base leading-relaxed text-fg-muted">
                  These types are checked against their required and recommended properties.
                  Anything else is still parsed and structurally validated, and reported as a note.
                </p>
                <ul className="mt-5 flex flex-wrap gap-2">
                  {SUPPORTED_TYPES.map((type) => (
                    <li key={type}>
                      <Badge tone="outline">{type}</Badge>
                    </li>
                  ))}
                </ul>
              </section>

              <section aria-labelledby="validator-faq-heading">
                <h2 id="validator-faq-heading" className="text-2xl font-semibold tracking-tight">
                  Frequently asked questions
                </h2>
                <Accordion className="mt-6" items={faqs} />
              </section>
            </div>

            <div className="h-fit rounded-card border border-border bg-surface p-6">
              <RelatedLinks
                heading="Related"
                links={[
                  { label: 'What is AEO?', href: '/aeo' },
                  { label: 'SEO workspace', href: '/seo' },
                  { label: 'Structured data mistakes', href: '/blog' },
                  { label: 'E-commerce solutions', href: '/solutions/ecommerce' },
                ]}
              />
            </div>
          </div>
        </Container>
      </Section>

      <CtaBlock
        id="validator-cta"
        heading="Generate markup instead of debugging it"
        body="SeSha produces JSON-LD from your real page data, so the errors this tool finds never get written in the first place."
        primary={{ label: 'Start Free', href: '/contact' }}
        secondary={{ label: 'See all features', href: '/features' }}
      />
      <JsonLd graph={graph} />
    </>
  );
}
