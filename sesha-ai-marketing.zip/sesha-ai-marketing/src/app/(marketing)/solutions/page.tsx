import Link from 'next/link';
import type { Metadata } from 'next';

import { Container, Section } from '@/components/layout/container';
import { CtaBlock } from '@/components/marketing/cta-block';
import { PageHero } from '@/components/marketing/page-hero';
import { JsonLd } from '@/components/seo/json-ld';
import { Card } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';
import { seoFor } from '@/content/seo-map';
import { solutionList } from '@/content/solutions';
import { breadcrumbSchema, buildGraph, webPageSchema } from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

const PATH = '/solutions';

export const metadata: Metadata = buildMetadata(seoFor(PATH));

export default function SolutionsPage() {
  const seo = seoFor(PATH);
  const graph = buildGraph([
    webPageSchema({
      path: PATH,
      name: seo.title,
      description: seo.description,
      dateModified: '2026-09-11',
    }),
    breadcrumbSchema(PATH),
  ]);

  return (
    <>
      <PageHero
        path={PATH}
        eyebrow="Solutions"
        heading="The same platform, shaped to how your industry markets"
        intro="The modules do not change between industries. What changes is the plan they produce, the content types that matter, and the structured data your pages need."
      />

      <Section spacing="md">
        <Container>
          <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {solutionList.map((solution) => (
              <li key={solution.slug}>
                <Card interactive className="relative flex h-full flex-col p-6">
                  <h2 className="text-lg font-semibold tracking-tight">
                    <Link
                      href={`/solutions/${solution.slug}`}
                      className="after:absolute after:inset-0 after:content-['']"
                    >
                      {solution.name}
                    </Link>
                  </h2>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-fg-muted">
                    {solution.directAnswer}
                  </p>
                  <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-primary">
                    Read more
                    <Icon name="arrow-right" size={15} />
                  </span>
                </Card>
              </li>
            ))}
          </ul>
        </Container>
      </Section>

      <CtaBlock
        id="solutions-cta"
        heading="Not sure which fits?"
        body="Describe what you sell and who you sell it to, and we will tell you how the platform would be set up for you."
        primary={{ label: 'Start Free', href: '/contact' }}
        secondary={{ label: 'See all features', href: '/features' }}
      />
      <JsonLd graph={graph} />
    </>
  );
}
