import { notFound } from 'next/navigation';
import type { Metadata } from 'next';

import { Container, Section } from '@/components/layout/container';
import { Accordion } from '@/components/ui/accordion';
import { Icon } from '@/components/ui/icon';
import { Card } from '@/components/ui/card';
import {
  ArticleMeta,
  DefinitionBlock,
  DirectAnswer,
  ExampleList,
  RelatedLinks,
} from '@/components/marketing/answer-block';
import { CtaBlock } from '@/components/marketing/cta-block';
import { FeatureCard } from '@/components/marketing/feature-card';
import { PageHero } from '@/components/marketing/page-hero';
import { JsonLd } from '@/components/seo/json-ld';
import { getModule } from '@/content/modules';
import { seoFor } from '@/content/seo-map';
import { authors } from '@/content/site';
import { getSolution } from '@/content/solutions';
import { SOLUTION_SLUGS } from '@/lib/routes';
import { breadcrumbSchema, buildGraph, faqPageSchema, webPageSchema } from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

/**
 * Industry solution page.
 *
 * One dynamic route serves all nine verticals, and `generateStaticParams`
 * pre-renders every one at build time, so each is a real static URL rather
 * than a client-side filter of a single page. Anything outside the registered
 * slug list returns a genuine 404, not a soft one.
 */

export function generateStaticParams() {
  return SOLUTION_SLUGS.map((slug) => ({ slug }));
}

export const dynamicParams = false;

type Params = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const solution = getSolution(slug);
  if (!solution) return buildMetadata({ title: 'Not found', description: 'Page not found.', path: '/404', noindex: true });
  return buildMetadata(seoFor(`/solutions/${slug}`));
}

export default async function SolutionPage({ params }: Params) {
  const { slug } = await params;
  const solution = getSolution(slug);
  if (!solution) notFound();

  const path = `/solutions/${solution.slug}`;
  const seo = seoFor(path);
  const author = authors.editorial;

  const graph = buildGraph([
    webPageSchema({
      path,
      name: seo.title,
      description: seo.description,
      dateModified: solution.lastUpdated,
    }),
    breadcrumbSchema(path),
    faqPageSchema(path, solution.faqs),
  ]);

  return (
    <>
      <PageHero path={path} eyebrow={`Solutions · ${solution.name}`} heading={solution.heroHeading}>
        {author ? (
          <ArticleMeta
            authorName={author.name}
            authorRole={author.role}
            authorHref={author.url}
            lastUpdated={solution.lastUpdated}
          />
        ) : null}
      </PageHero>

      <Section spacing="md">
        <Container>
          <div className="flex max-w-3xl flex-col gap-10">
            <DefinitionBlock term={solution.name} definition={solution.definition} />
            <DirectAnswer>{solution.directAnswer}</DirectAnswer>
            <p className="text-base leading-relaxed text-fg-muted">{solution.explanation}</p>

            <section aria-labelledby="challenges-heading">
              <h2 id="challenges-heading" className="text-2xl font-semibold tracking-tight">
                What usually gets in the way
              </h2>
              <ul className="mt-5 flex flex-col gap-3">
                {solution.challenges.map((challenge) => (
                  <li key={challenge} className="flex items-start gap-3 text-base leading-relaxed">
                    <Icon name="alert" size={18} className="mt-1 shrink-0 text-warning" />
                    <span className="text-fg-muted">{challenge}</span>
                  </li>
                ))}
              </ul>
            </section>

            <ExampleList examples={solution.examples} heading="What this looks like in practice" />
          </div>
        </Container>
      </Section>

      <Section tone="subtle" spacing="md" aria-labelledby="modules-heading">
        <Container>
          <h2 id="modules-heading" className="text-2xl font-semibold tracking-tight">
            The modules that matter most here
          </h2>
          <ul className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {solution.keyModules.map((id) => (
              <li key={id}>
                <FeatureCard module={getModule(id)} />
              </li>
            ))}
          </ul>
        </Container>
      </Section>

      <Section spacing="md">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[minmax(0,1fr)_18rem] lg:gap-16">
            <div className="max-w-3xl">
              <h2 className="text-2xl font-semibold tracking-tight">
                Questions about {solution.name.toLowerCase()} marketing
              </h2>
              <Accordion
                className="mt-6"
                items={solution.faqs.map((f) => ({ question: f.question, answer: f.answer }))}
              />
            </div>
            <Card tone="subtle" className="h-fit p-6">
              <RelatedLinks links={solution.related} heading="Related" />
            </Card>
          </div>
        </Container>
      </Section>

      <CtaBlock
        id="solution-cta"
        heading={`Set SeSha up for ${solution.name.toLowerCase()}`}
        body="Tell us how you market today and we will show you the setup we would recommend."
        primary={{ label: 'Start Free', href: '/contact' }}
        secondary={{ label: 'See all solutions', href: '/solutions' }}
      />
      <JsonLd graph={graph} />
    </>
  );
}
