import type { Metadata } from 'next';

import { Accordion } from '@/components/ui/accordion';
import { Container, Section } from '@/components/layout/container';
import { CtaBlock } from '@/components/marketing/cta-block';
import { PageHero } from '@/components/marketing/page-hero';
import { JsonLd } from '@/components/seo/json-ld';
import { faqCategories, faqs, faqsByCategory } from '@/content/faq';
import { seoFor } from '@/content/seo-map';
import { breadcrumbSchema, buildGraph, faqPageSchema, webPageSchema } from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

const PATH = '/faq';

export const metadata: Metadata = buildMetadata(seoFor(PATH));

export default function FaqPage() {
  const seo = seoFor(PATH);
  const graph = buildGraph([
    webPageSchema({ path: PATH, name: seo.title, description: seo.description, dateModified: '2026-09-11' }),
    breadcrumbSchema(PATH),
    faqPageSchema(PATH, faqs),
  ]);

  return (
    <>
      <PageHero
        path={PATH}
        eyebrow="Answers"
        heading="Frequently asked questions"
        intro="Direct answers, including to the questions with inconvenient answers. Where something is not built yet, we say so."
      />

      <Section spacing="md">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[minmax(0,1fr)_14rem] lg:gap-16">
            <div className="flex max-w-3xl flex-col gap-12">
              {faqCategories.map((category) => {
                const items = faqsByCategory(category.id);
                if (items.length === 0) return null;
                return (
                  <section key={category.id} id={category.id} className="scroll-mt-24">
                    <h2 className="text-2xl font-semibold tracking-tight">{category.label}</h2>
                    <Accordion
                      className="mt-5"
                      defaultOpenIndex={null}
                      items={items.map((item) => ({
                        question: item.question,
                        answer: item.answer,
                      }))}
                    />
                  </section>
                );
              })}
            </div>

            <nav aria-label="FAQ categories" className="hidden lg:block">
              <div className="sticky top-24">
                <p className="text-xs font-semibold uppercase tracking-[0.12em] text-fg-subtle">
                  Categories
                </p>
                <ul className="mt-4 flex flex-col gap-2.5 border-l border-border pl-4">
                  {faqCategories.map((category) => (
                    <li key={category.id}>
                      <a
                        href={`#${category.id}`}
                        className="text-sm text-fg-muted transition-colors hover:text-fg"
                      >
                        {category.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </nav>
          </div>
        </Container>
      </Section>

      <CtaBlock
        id="faq-cta"
        heading="Still have a question?"
        body="Ask us directly. We would rather answer honestly than have you guess from a website."
        primary={{ label: 'Contact us', href: '/contact' }}
        secondary={{ label: 'Read the resources', href: '/resources' }}
      />
      <JsonLd graph={graph} />
    </>
  );
}
