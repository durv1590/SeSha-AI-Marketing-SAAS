import Link from 'next/link';
import type { Metadata } from 'next';

import { Container, Section } from '@/components/layout/container';
import { SectionHeader } from '@/components/layout/section-header';
import { CtaBlock } from '@/components/marketing/cta-block';
import { PageHero } from '@/components/marketing/page-hero';
import { JsonLd } from '@/components/seo/json-ld';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';
import { resourceCollections, resourceIntro } from '@/content/resources';
import { seoFor } from '@/content/seo-map';
import { breadcrumbSchema, buildGraph, webPageSchema } from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

const PATH = '/resources';

export const metadata: Metadata = buildMetadata(seoFor(PATH));

const kindLabels = {
  guide: 'Guide',
  tool: 'Free tool',
  article: 'Article',
  answers: 'Answers',
} as const;

export default function ResourcesPage() {
  const seo = seoFor(PATH);
  const graph = buildGraph([
    webPageSchema({ path: PATH, name: seo.title, description: seo.description, dateModified: '2026-09-11' }),
    breadcrumbSchema(PATH),
  ]);

  return (
    <>
      <PageHero
        path={PATH}
        eyebrow="Resources"
        heading={resourceIntro.heading}
        intro={resourceIntro.body}
      />

      {resourceCollections.map((collection, index) => (
        <Section
          key={collection.id}
          id={collection.id}
          tone={index % 2 === 1 ? 'subtle' : 'default'}
          spacing="sm"
          aria-labelledby={`${collection.id}-heading`}
        >
          <Container>
            <SectionHeader
              id={`${collection.id}-heading`}
              heading={collection.heading}
              intro={collection.intro}
            />
            <ul className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {collection.items.map((item) => (
                <li key={`${collection.id}-${item.title}`}>
                  <Card interactive className="relative flex h-full flex-col p-6">
                    <Badge tone={item.kind === 'tool' ? 'brand' : 'outline'} className="w-fit">
                      {kindLabels[item.kind]}
                    </Badge>
                    <h3 className="mt-4 font-semibold tracking-tight">
                      <Link
                        href={item.href}
                        className="after:absolute after:inset-0 after:content-['']"
                      >
                        {item.title}
                      </Link>
                    </h3>
                    <p className="mt-2 flex-1 text-sm leading-relaxed text-fg-muted">
                      {item.description}
                    </p>
                    <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary">
                      Open
                      <Icon name="arrow-right" size={15} />
                    </span>
                  </Card>
                </li>
              ))}
            </ul>
          </Container>
        </Section>
      ))}

      <CtaBlock
        id="resources-cta"
        heading="Put the theory to work"
        body="The schema validator is free and needs no account. Start there."
        primary={{ label: 'Open the validator', href: '/schema-validator' }}
        secondary={{ label: 'Read the blog', href: '/blog' }}
      />
      <JsonLd graph={graph} />
    </>
  );
}
