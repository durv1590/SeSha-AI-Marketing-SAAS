import type { Metadata } from 'next';

import { AnswerPageTemplate } from '@/components/marketing/answer-page';
import { JsonLd } from '@/components/seo/json-ld';
import { seoPage } from '@/content/pages';
import { seoFor } from '@/content/seo-map';
import { breadcrumbSchema, buildGraph, faqPageSchema, webPageSchema } from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

const PATH = '/seo';

export const metadata: Metadata = buildMetadata(seoFor(PATH));

export default function Page() {
  const seo = seoFor(PATH);
  const graph = buildGraph([
    webPageSchema({
      path: PATH,
      name: seo.title,
      description: seo.description,
      dateModified: '2026-09-11',
    }),
    breadcrumbSchema(PATH),
    faqPageSchema(PATH, seoPage.faqs),
  ]);

  return (
    <>
      <AnswerPageTemplate path={PATH} page={seoPage} eyebrow="Guide" />
      <JsonLd graph={graph} />
    </>
  );
}
