import type { Metadata } from 'next';

import { ReportView } from '@/components/reports/report-view';
import { Alert } from '@/components/ui/alert';
import { getDatabase } from '@/lib/db';
import { ShareDeniedError, viewShared } from '@/lib/reports/service';
import { SHARE_DENIED_MESSAGE } from '@/lib/reports/share';

/**
 * A shared report, read by someone who is not signed in.
 *
 * `noindex, nofollow` is not a nicety. A share link is a door into somebody's
 * business data, and a link pasted into an email that a crawler follows would put
 * a customer's report into a search index.
 *
 * Every failure renders the SAME page with the same sentence — expired, revoked,
 * never existed, report deleted. A visitor learns nothing from the wording.
 */
export const metadata: Metadata = {
  title: 'Shared report — SeSha',
  robots: { index: false, follow: false },
};

export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ token: string }> };

export default async function SharedReportPage({ params }: Params) {
  const { token } = await params;

  try {
    const viewed = await viewShared({ db: getDatabase() }, token);
    return (
      <div className="mx-auto flex w-full max-w-4xl flex-col gap-6 px-4 py-12">
        <ReportView report={viewed.report} />
        <p className="text-sm text-fg-muted">
          Shared from SeSha. This link can be revoked at any time by whoever created it.
        </p>
      </div>
    );
  } catch (error) {
    // Any failure at all renders the same thing. Distinguishing them would tell a
    // stranger whether the link was ever real.
    void error;
    if (!(error instanceof ShareDeniedError)) {
      // Still the same page — an unauthenticated visitor gains nothing from a
      // stack trace or a 500.
    }
    return (
      <div className="mx-auto flex w-full max-w-2xl flex-col gap-4 px-4 py-24">
        <h1 className="text-2xl font-semibold tracking-tight">Report not available</h1>
        <Alert tone="info">{SHARE_DENIED_MESSAGE}</Alert>
      </div>
    );
  }
}
