import { SiteHeader } from '@/components/layout/site-header';
import { SiteFooter } from '@/components/layout/site-footer';

/**
 * Public marketing layout.
 *
 * The site header and footer live here rather than in the root layout, so the
 * authenticated application and the sign-in pages do not inherit marketing
 * navigation. The root layout keeps only what is genuinely site-wide: the html
 * element, the theme script and the organization structured data.
 */
export default function MarketingLayout({ children }: { readonly children: React.ReactNode }) {
  return (
    <>
      <a
        href="#main"
        className="skip-link rounded-control bg-primary px-4 py-2 text-sm font-medium text-primary-fg shadow-lg"
      >
        Skip to main content
      </a>
      <SiteHeader />
      <main id="main" tabIndex={-1} className="focus:outline-none">
        {children}
      </main>
      <SiteFooter />
    </>
  );
}
