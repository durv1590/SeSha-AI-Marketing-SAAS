import Link from 'next/link';
import type { Metadata } from 'next';

import { Container, Section } from '@/components/layout/container';
import { SectionHeader } from '@/components/layout/section-header';
import { CtaBlock } from '@/components/marketing/cta-block';
import { FaqSection } from '@/components/marketing/faq-section';
import { Hero } from '@/components/marketing/hero';
import { ModuleSection } from '@/components/marketing/module-section';
import { PricingCard } from '@/components/marketing/pricing-card';
import { Steps } from '@/components/marketing/steps';
import { JsonLd } from '@/components/seo/json-ld';
import { Icon } from '@/components/ui/icon';
import { Card } from '@/components/ui/card';
import { finalCta, howItWorks, pricingPreview, problem, solution, useCases } from '@/content/home';
import { homeFaqs } from '@/content/faq';
import { featureList, modules } from '@/content/modules';
import { pricingTiers } from '@/content/pricing';
import { seoFor } from '@/content/seo-map';
import { solutionList } from '@/content/solutions';
import {
  breadcrumbSchema,
  buildGraph,
  buildOffers,
  faqPageSchema,
  softwareApplicationSchema,
  webPageSchema,
} from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

/**
 * Home page — the 23 sections required by the Phase 1 specification.
 *
 * Sections 4–17 render from the module catalogue rather than being written out
 * one by one, so a capability is defined once in content/modules.ts and stays
 * consistent between the home page, /features and every solution page.
 *
 * Section 23 (footer) lives in the root layout because it appears site-wide.
 */

export const metadata: Metadata = buildMetadata(seoFor('/'));

export default function HomePage() {
  const graph = buildGraph([
    webPageSchema({
      path: '/',
      name: seoFor('/').title,
      description: seoFor('/').description,
      dateModified: '2026-09-11',
    }),
    breadcrumbSchema('/'),
    softwareApplicationSchema({
      applicationCategory: 'BusinessApplication',
      operatingSystem: 'Web',
      featureList: featureList(),
      // Placeholder tiers are refused by buildOffers, so no unverified price
      // can reach structured data.
      offers: buildOffers(
        pricingTiers.map((tier) => ({
          name: tier.name,
          price: tier.monthlyPrice ?? 0,
          currency: tier.currency,
          billingPeriod: 'month',
          verified: tier.verified,
        })),
      ),
    }),
    faqPageSchema('/', homeFaqs),
  ]);

  return (
    <>
      {/* 1 — Hero */}
      <Hero />

      {/* 2 — Problem statement */}
      <Section id={problem.id} tone="default" aria-labelledby="problem-heading">
        <Container>
          <SectionHeader
            id="problem-heading"
            eyebrow={problem.eyebrow}
            heading={problem.heading}
            intro={problem.intro}
          />
          <div className="mt-12 grid gap-5 sm:grid-cols-2">
            {problem.points.map((point) => (
              <Card key={point.title} tone="subtle" className="p-6">
                <h3 className="font-semibold tracking-tight">{point.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-fg-muted">{point.body}</p>
              </Card>
            ))}
          </div>
        </Container>
      </Section>

      {/* 3 — The SeSha solution */}
      <Section id={solution.id} tone="subtle" aria-labelledby="solution-heading">
        <Container>
          <SectionHeader
            id="solution-heading"
            eyebrow={solution.eyebrow}
            heading={solution.heading}
            intro={solution.intro}
          />
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {solution.pillars.map((pillar) => (
              <Card key={pillar.title} className="p-6">
                <h3 className="font-semibold tracking-tight">{pillar.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-fg-muted">{pillar.body}</p>
              </Card>
            ))}
          </div>
        </Container>
      </Section>

      {/* 4–17 — The fourteen platform modules */}
      {modules.map((module, index) => (
        <ModuleSection key={module.id} module={module} index={index} />
      ))}

      {/* 18 — How it works */}
      <Section id={howItWorks.id} tone="subtle" aria-labelledby="how-it-works-heading">
        <Container>
          <SectionHeader
            id="how-it-works-heading"
            eyebrow={howItWorks.eyebrow}
            heading={howItWorks.heading}
            intro={howItWorks.intro}
          />
          <Steps steps={howItWorks.steps} />
        </Container>
      </Section>

      {/* 19 — Use cases */}
      <Section id={useCases.id} aria-labelledby="use-cases-heading">
        <Container>
          <SectionHeader
            id="use-cases-heading"
            eyebrow={useCases.eyebrow}
            heading={useCases.heading}
            intro={useCases.intro}
          />
          <ul className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {solutionList.map((item) => (
              <li key={item.slug}>
                <Card interactive className="relative h-full p-6">
                  <h3 className="font-semibold tracking-tight">
                    <Link
                      href={`/solutions/${item.slug}`}
                      className="after:absolute after:inset-0 after:content-['']"
                    >
                      {item.name}
                    </Link>
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-fg-muted">{item.directAnswer}</p>
                  <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary">
                    Read more
                    <Icon name="arrow-right" size={15} />
                  </span>
                </Card>
              </li>
            ))}
          </ul>
        </Container>
      </Section>

      {/* 20 — Pricing preview */}
      <Section id={pricingPreview.id} tone="subtle" aria-labelledby="pricing-preview-heading">
        <Container>
          <SectionHeader
            id="pricing-preview-heading"
            eyebrow={pricingPreview.eyebrow}
            heading={pricingPreview.heading}
            intro={pricingPreview.intro}
          />
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {pricingTiers.map((tier) => (
              <PricingCard key={tier.id} tier={tier} />
            ))}
          </div>
          <p className="mt-8">
            <Link
              href={pricingPreview.cta.href}
              className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary-hover"
            >
              {pricingPreview.cta.label}
              <Icon name="arrow-right" size={16} />
            </Link>
          </p>
        </Container>
      </Section>

      {/* 21 — FAQ */}
      <FaqSection
        id="home-faq"
        tone="default"
        eyebrow="Questions"
        heading="Frequently asked questions"
        intro="The questions we are asked most often, answered directly."
        items={homeFaqs.map((f) => ({ question: f.question, answer: f.answer }))}
      />

      {/* 22 — Final CTA */}
      <CtaBlock
        id={finalCta.id}
        heading={finalCta.heading}
        body={finalCta.body}
        primary={finalCta.primaryCta}
        secondary={finalCta.secondaryCta}
      />

      {/* 23 — Footer is rendered site-wide by the root layout. */}
      <JsonLd graph={graph} />
    </>
  );
}
