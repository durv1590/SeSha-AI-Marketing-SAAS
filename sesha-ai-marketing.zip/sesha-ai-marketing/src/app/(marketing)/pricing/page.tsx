import type { Metadata } from 'next';

import { Container, Section } from '@/components/layout/container';
import { SectionHeader } from '@/components/layout/section-header';
import { Alert } from '@/components/ui/alert';
import { Icon } from '@/components/ui/icon';
import { CtaBlock } from '@/components/marketing/cta-block';
import { FaqSection } from '@/components/marketing/faq-section';
import { PageHero } from '@/components/marketing/page-hero';
import { PricingCard } from '@/components/marketing/pricing-card';
import { JsonLd } from '@/components/seo/json-ld';
import { seoFor } from '@/content/seo-map';
import { pricingComparison, pricingFaqs, pricingIsProvisional, pricingTiers } from '@/content/pricing';
import { breadcrumbSchema, buildGraph, faqPageSchema, webPageSchema } from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

const PATH = '/pricing';

export const metadata: Metadata = buildMetadata(seoFor(PATH));

export default function PricingPage() {
  const seo = seoFor(PATH);
  const graph = buildGraph([
    webPageSchema({ path: PATH, name: seo.title, description: seo.description, dateModified: '2026-09-11' }),
    breadcrumbSchema(PATH),
    faqPageSchema(PATH, pricingFaqs),
    // No SoftwareApplication offers node: every tier is unverified, and
    // buildOffers() refuses to publish a placeholder price.
  ]);

  return (
    <>
      <PageHero
        path={PATH}
        eyebrow="Pricing"
        heading="Every plan includes every module"
        intro="Tiers differ by how many workspaces, seats and automation runs they cover — not by which parts of the product you are allowed to use."
      />

      <Section spacing="md">
        <Container>
          {pricingIsProvisional ? (
            <Alert tone="info" title="Prices are not published yet" className="mb-10">
              Plan pricing has not been finalised, and we do not publish figures we have not
              confirmed. Contact us and we will give you current pricing for your team size and
              workspace count. The plan structure below is accurate.
            </Alert>
          ) : null}

          <div className="grid gap-6 lg:grid-cols-3">
            {pricingTiers.map((tier) => (
              // h2: these cards sit directly beneath the page h1, with no
              // intervening section heading.
              <PricingCard key={tier.id} tier={tier} as="h2" />
            ))}
          </div>
        </Container>
      </Section>

      <Section tone="subtle" spacing="md" aria-labelledby="comparison-heading">
        <Container>
          <SectionHeader id="comparison-heading" heading={pricingComparison.heading} />
          <div className="mt-10 overflow-x-auto">
            <table className="w-full min-w-[36rem] border-collapse text-sm">
              <caption className="sr-only">
                Feature comparison across the Starter, Growth and Agency plans
              </caption>
              <thead>
                <tr className="border-b border-border-strong text-left">
                  <th scope="col" className="py-3 pr-4 font-semibold">
                    Capability
                  </th>
                  {pricingTiers.map((tier) => (
                    <th key={tier.id} scope="col" className="px-4 py-3 text-center font-semibold">
                      {tier.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {pricingComparison.rows.map((row) => (
                  <tr key={row.label} className="border-b border-border">
                    <th scope="row" className="py-3.5 pr-4 text-left font-normal text-fg-muted">
                      {row.label}
                    </th>
                    {[row.starter, row.growth, row.agency].map((included, index) => (
                      <td key={index} className="px-4 py-3.5 text-center">
                        {included ? (
                          <>
                            <Icon
                              name="check"
                              size={17}
                              className="mx-auto text-primary"
                              aria-hidden="true"
                            />
                            <span className="sr-only">Included</span>
                          </>
                        ) : (
                          <>
                            <span aria-hidden="true" className="text-fg-subtle">
                              &mdash;
                            </span>
                            <span className="sr-only">Not included</span>
                          </>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Container>
      </Section>

      <FaqSection
        id="pricing-faq"
        tone="default"
        heading="Pricing questions"
        items={pricingFaqs}
      />

      <CtaBlock
        id="pricing-cta"
        heading="Get pricing for your team"
        body="Tell us your team size and how many brands you run, and we will send current pricing."
        primary={{ label: 'Contact us', href: '/contact' }}
        secondary={{ label: 'See all features', href: '/features' }}
      />
      <JsonLd graph={graph} />
    </>
  );
}
