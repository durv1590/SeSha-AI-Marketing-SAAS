import type { Metadata } from 'next';

import { Container, Section } from '@/components/layout/container';
import { SectionHeader } from '@/components/layout/section-header';
import { CtaBlock } from '@/components/marketing/cta-block';
import { FeatureCard } from '@/components/marketing/feature-card';
import { PageHero } from '@/components/marketing/page-hero';
import { JsonLd } from '@/components/seo/json-ld';
import { Icon } from '@/components/ui/icon';
import { featureList, modules } from '@/content/modules';
import { seoFor } from '@/content/seo-map';
import {
  breadcrumbSchema,
  buildGraph,
  softwareApplicationSchema,
  webPageSchema,
} from '@/lib/schema';
import { buildMetadata } from '@/lib/seo/metadata';

const PATH = '/features';

export const metadata: Metadata = buildMetadata(seoFor(PATH));

export default function FeaturesPage() {
  const seo = seoFor(PATH);
  const graph = buildGraph([
    webPageSchema({
      path: PATH,
      name: seo.title,
      description: seo.description,
      dateModified: '2026-09-11',
    }),
    breadcrumbSchema(PATH),
    softwareApplicationSchema({
      applicationCategory: 'BusinessApplication',
      operatingSystem: 'Web',
      featureList: featureList(),
    }),
  ]);

  return (
    <>
      <PageHero
        path={PATH}
        eyebrow="Platform"
        heading="Every module, one shared context"
        intro="SeSha is fourteen modules that read from the same brand kit and strategy. That shared context is the difference between a tool that drafts something generic and one that drafts something you can actually use."
      />

      <Section spacing="md" aria-labelledby="modules-overview-heading">
        <Container>
          <SectionHeader
            id="modules-overview-heading"
            heading="The fourteen modules"
            intro="Each one is described in a single sentence here, and in full further down the page."
          />
          <ul className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {modules.map((module) => (
              <li key={module.id}>
                <FeatureCard module={module} />
              </li>
            ))}
          </ul>
        </Container>
      </Section>

      <Section tone="subtle" spacing="md" aria-labelledby="detail-heading">
        <Container>
          <SectionHeader
            id="detail-heading"
            eyebrow="In detail"
            heading="What each module actually does"
            intro="Capability lists, not adjectives. If something is not built yet, it is not listed here."
          />

          <div className="mt-12 flex flex-col gap-10">
            {modules.map((module) => (
              <article
                key={module.id}
                id={`feature-${module.id}`}
                className="scroll-mt-24 rounded-card border border-border bg-surface p-6 shadow-sm sm:p-8"
              >
                <div className="flex items-center gap-3">
                  <span className="inline-flex size-10 items-center justify-center rounded-control bg-primary-subtle text-primary-subtle-fg">
                    <Icon name={module.icon} size={20} />
                  </span>
                  <h3 className="text-xl font-semibold tracking-tight">{module.name}</h3>
                </div>
                <p className="mt-4 text-base leading-relaxed text-fg">{module.summary}</p>
                <p className="mt-3 text-sm leading-relaxed text-fg-muted">{module.detail}</p>
                <ul className="mt-5 grid gap-2.5 sm:grid-cols-2">
                  {module.capabilities.map((capability) => (
                    <li key={capability} className="flex items-start gap-2.5 text-sm">
                      <Icon name="check" size={16} className="mt-0.5 shrink-0 text-primary" />
                      <span className="text-fg-muted">{capability}</span>
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </Container>
      </Section>

      <CtaBlock
        id="features-cta"
        heading="See it against your own marketing"
        body="Tell us how your marketing runs today and we will show you which modules replace what."
        primary={{ label: 'Start Free', href: '/contact' }}
        secondary={{ label: 'Compare plans', href: '/pricing' }}
      />
      <JsonLd graph={graph} />
    </>
  );
}
