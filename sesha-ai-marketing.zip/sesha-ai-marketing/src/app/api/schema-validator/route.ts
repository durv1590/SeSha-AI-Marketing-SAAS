import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { validateJsonLd } from '@/lib/schema-validator/validate';

/**
 * Structured-data validation endpoint.
 *
 * Stateless by design: the submitted document is validated and discarded. It is
 * never persisted or logged as content, which is what the privacy page and the
 * tool's own UI promise.
 */

export const dynamic = 'force-dynamic';

const MAX_SOURCE_BYTES = 200_000;

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'schemaValidator');
  if (!limit.allowed) return limit.response;

  const body = await readJson(request, MAX_SOURCE_BYTES + 4_096);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const source = (body as { source?: unknown }).source;
  if (typeof source !== 'string') {
    return fail(400, 'Expected a "source" string containing JSON-LD.', undefined, {
      headers: limit.headers,
    });
  }
  if (source.trim().length === 0) {
    return fail(400, 'Nothing to validate.', undefined, { headers: limit.headers });
  }

  const report = validateJsonLd(source);
  return ok({ data: report, message: report.valid ? 'No errors found.' : 'Issues found.' }, {
    headers: limit.headers,
  });
}
