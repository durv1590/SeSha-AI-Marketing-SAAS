import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import type { FeedbackRow } from '@/lib/db/types';

/**
 * Customer feedback: the submission side of the admin panel's Feedback surface.
 *
 * Written together with `/api/admin/feedback` rather than after it, because a
 * triage queue with no way in is a dashboard of an empty table — the kind of
 * feature that looks finished and has never once been used.
 *
 * SIGNED IN ON PURPOSE. Anonymous feedback would need its own abuse handling and
 * would arrive without the one thing that makes it actionable: which
 * organization, on which plan, hit the thing being described. The public,
 * unauthenticated path already exists and is `/api/contact`.
 *
 * `surface` is the route the person was on, captured so a bug report reading
 * "this is broken" still has somewhere to look. It is truncated and stored as
 * given; it is never used to build a URL.
 */
export const dynamic = 'force-dynamic';

const KINDS = ['bug', 'idea', 'praise', 'other'] as const;
const MAX_MESSAGE = 4_000;

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const kind = input.kind;
  const message = typeof input.message === 'string' ? input.message.trim() : '';
  const surface = typeof input.surface === 'string' ? input.surface.trim().slice(0, 200) : '';

  const errors: Record<string, string> = {};
  if (!isKind(kind)) errors.kind = 'Choose what kind of feedback this is.';
  if (message.length === 0) errors.message = 'Tell us what happened.';
  if (message.length > MAX_MESSAGE) {
    errors.message = `That is longer than we can store. Please keep it under ${MAX_MESSAGE.toLocaleString('en-IN')} characters.`;
  }
  if (Object.keys(errors).length > 0) {
    return fail(422, 'Please check the form.', errors, { headers: limit.headers });
  }

  try {
    await getDatabase().feedback.create({
      organizationId: auth.tenant.organizationId,
      userId: auth.tenant.userId,
      kind: kind as FeedbackRow['kind'],
      message,
      surface: surface.length > 0 ? surface : null,
    });
  } catch (error) {
    return errorResponse(error);
  }

  // No promise of a reply. The product cannot currently send one — feedback has
  // no outbound path — and saying "we'll get back to you" when nothing will is
  // the same dishonesty as a fabricated metric.
  return ok(
    {
      data: {},
      message: 'Thank you — this is with the team. We read every note; we may not reply to each one.',
    },
    { headers: limit.headers },
  );
}

function isKind(value: unknown): value is FeedbackRow['kind'] {
  return typeof value === 'string' && (KINDS as readonly string[]).includes(value);
}
