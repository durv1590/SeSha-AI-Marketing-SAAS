import { enforceRateLimit, fail, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { applyWebhook } from '@/lib/billing/service';
import { nullProvider, SUBSCRIPTION_EVENTS, type SubscriptionEvent } from '@/lib/billing/types';
import { isPlanId } from '@/content/plans';

/**
 * The payment-provider webhook.
 *
 * THE MOST DANGEROUS ENDPOINT IN THE PRODUCT, because a caller who is believed
 * can grant themselves any plan. Four things protect it:
 *
 * 1. **THE SIGNATURE IS VERIFIED FIRST, AGAINST THE RAW BODY.** Providers sign
 *    the bytes, and re-serialising parsed JSON changes them — so the body is
 *    read as text and parsed only after verification. Reading it with
 *    `readJson()` first would make verification impossible.
 * 2. **The null provider returns false from `verifyWebhook`, always.** No
 *    webhook is ever applied while no provider is connected, which is today.
 *    That single line is why this route cannot currently be abused at all.
 * 3. **No authentication, and therefore no CSRF** — the caller is a machine with
 *    no session. The signature IS the authentication.
 * 4. **Idempotency** — the event id is unique in the database, so a retry is
 *    recorded as already-seen rather than applied twice.
 *
 * The response is deliberately uninformative. A provider needs a 2xx; anything
 * more tells an attacker whether their forgery got further than the signature.
 */
export const dynamic = 'force-dynamic';

/** The header each provider signs with. Checked in order; the first wins. */
const SIGNATURE_HEADERS = ['stripe-signature', 'x-razorpay-signature', 'x-webhook-signature'];

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const provider = nullProvider;

  // Read the RAW body. See point 1 above.
  let raw: string;
  try {
    raw = await request.text();
  } catch {
    return fail(400, 'Unreadable body.');
  }
  if (raw.length > 256_000) return fail(413, 'Body too large.');

  const signature =
    SIGNATURE_HEADERS.map((header) => request.headers.get(header)).find(
      (value): value is string => typeof value === 'string' && value.length > 0,
    ) ?? '';

  if (!provider.verifyWebhook(raw, signature)) {
    // 202 with no detail. A 401 would confirm to a forger that the endpoint is
    // live and that only the signature stood in their way; a 500 would suggest
    // they had found a bug. Nothing was applied either way.
    return new Response(JSON.stringify({ ok: true }), {
      status: 202,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // Unreachable while no provider is connected, and written so that connecting
  // one does not also require writing this.
  let payload: Record<string, unknown>;
  try {
    payload = JSON.parse(raw) as Record<string, unknown>;
  } catch {
    return fail(400, 'Unreadable body.');
  }

  const organizationId = typeof payload.organizationId === 'string' ? payload.organizationId : '';
  const event = payload.event;
  if (!organizationId || !isSubscriptionEvent(event)) {
    return fail(400, 'Unrecognised event.');
  }

  const outcome = await applyWebhook(
    { db: getDatabase(), provider },
    {
      organizationId,
      event,
      externalEventId: typeof payload.id === 'string' ? payload.id : null,
      ...(isPlanId(payload.plan) ? { plan: payload.plan } : {}),
      // A SUMMARY, never the raw payload: a provider body carries more customer
      // data than this product needs, and storing it wholesale would create a
      // second copy of it in a table staff can read.
      summary: { event, receivedAt: new Date().toISOString() },
    },
  );

  return ok({ data: { applied: outcome.ok && outcome.applied } });
}

function isSubscriptionEvent(value: unknown): value is SubscriptionEvent {
  return typeof value === 'string' && (SUBSCRIPTION_EVENTS as readonly string[]).includes(value);
}
