import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import {
  BillingError,
  billingView,
  cancel,
  changePlan,
  resumeCancellation,
  startCheckout,
} from '@/lib/billing/service';
import { STATUS_EXPLANATION, STATUS_LABEL } from '@/lib/billing/types';
import { PLANS_BY_RANK, formatLimit, isPlanId, LIMIT_IDS, LIMITS } from '@/content/plans';
import { site } from '@/content/site';

/**
 * Billing: read the subscription, or change it.
 *
 * The plan comparison is served from the registry, with LIMITS and no prices.
 * Prices live in `content/pricing.ts` behind the `verified` guard and are
 * published only when the business has confirmed them — a limit is an
 * engineering fact, a price is a commitment.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const view = await billingView({ db: getDatabase() }, auth.tenant);
    return ok(
      {
        data: {
          ...view,
          statusLabel: STATUS_LABEL[view.status],
          statusExplanation: STATUS_EXPLANATION[view.status],
          plans: PLANS_BY_RANK.map((plan) => ({
            id: plan.id,
            name: plan.name,
            audience: plan.audience,
            requiresPayment: plan.requiresPayment,
            trialDays: plan.trialDays,
            current: plan.id === view.plan,
            limits: LIMIT_IDS.map((id) => ({
              id,
              label: LIMITS[id].label,
              value: plan.limits[id],
              formatted: formatLimit(plan.limits[id]),
            })),
          })),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const action = typeof input.action === 'string' ? input.action : '';

  try {
    const db = getDatabase();

    switch (action) {
      case 'checkout': {
        if (!isPlanId(input.plan)) {
          return fail(422, 'Choose a plan.', { plan: 'Choose a plan.' }, { headers: limit.headers });
        }
        // The return URL is OUR OWN ORIGIN, built here rather than taken from
        // the request. A client-supplied return URL is an open redirect handed
        // to a payment provider.
        const result = await startCheckout(
          { db },
          auth.tenant,
          input.plan,
          `${site.url}/app/settings/billing`,
        );
        return ok({ data: result, message: 'Continue at the payment provider.' }, { headers: limit.headers });
      }

      case 'change_plan': {
        if (!isPlanId(input.plan)) {
          return fail(422, 'Choose a plan.', { plan: 'Choose a plan.' }, { headers: limit.headers });
        }
        const result = await changePlan({ db }, auth.tenant, input.plan);
        return ok({ data: result, message: result.message }, { headers: limit.headers });
      }

      case 'cancel': {
        const result = await cancel({ db }, auth.tenant, input.immediately === true);
        return ok({ data: {}, message: result.message }, { headers: limit.headers });
      }

      case 'resume': {
        const result = await resumeCancellation({ db }, auth.tenant);
        return ok({ data: {}, message: result.message }, { headers: limit.headers });
      }

      default:
        return fail(
          422,
          'That is not a billing action.',
          undefined,
          { headers: limit.headers },
        );
    }
  } catch (error) {
    if (error instanceof BillingError) {
      // 409, not 500: the request was understood and refused for a reason the
      // user can read and act on.
      return fail(409, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
