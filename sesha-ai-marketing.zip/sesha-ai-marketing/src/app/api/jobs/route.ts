import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { listJobs, toJobView } from '@/lib/crawl/service';
import { isJobKind } from '@/lib/jobs/types';

export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const params = new URL(request.url).searchParams;
  const projectId = params.get('projectId') ?? '';
  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', undefined, { headers: limit.headers });
  }

  const kindParam = params.get('kind');
  if (kindParam !== null && !isJobKind(kindParam)) {
    return fail(422, 'That is not a job kind.', undefined, { headers: limit.headers });
  }

  try {
    const jobs = await listJobs(
      { db: getDatabase() },
      auth.tenant,
      projectId,
      kindParam ?? undefined,
    );
    // The view, not the row: a row carries internal failure detail.
    return ok({ data: jobs.map(toJobView) }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
