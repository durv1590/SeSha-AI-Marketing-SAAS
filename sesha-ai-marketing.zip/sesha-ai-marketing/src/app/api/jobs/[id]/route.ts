import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import {
  JobConflictError,
  RetryNotAllowedError,
  cancelJob,
  getJob,
  retryJob,
  runJob,
  toJobView,
} from '@/lib/crawl/service';

/**
 * Poll, cancel or retry one job.
 *
 * GET is what the interface polls while a crawl runs. PATCH takes an action
 * rather than a field patch, because "cancel" and "retry" are transitions with
 * rules, not properties a client may set.
 */
export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const { id } = await params;
    const job = await getJob({ db: getDatabase() }, auth.tenant, id);
    return ok({ data: toJobView(job) }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const action = (body as Record<string, unknown>).action;
  if (action !== 'cancel' && action !== 'retry') {
    return fail(422, 'The action must be "cancel" or "retry".', undefined, { headers: limit.headers });
  }

  const context = { db: getDatabase() };

  try {
    const { id } = await params;

    if (action === 'cancel') {
      const job = await cancelJob(context, auth.tenant, id);
      return ok(
        {
          data: toJobView(job),
          message: job.status === 'cancelled'
            ? 'Cancelled.'
            : 'Stopping. The crawl will finish the page it is on and keep what it has read.',
        },
        { headers: limit.headers },
      );
    }

    const job = await retryJob(context, auth.tenant, id);
    void (async () => {
      // A retry carries a not-before time, so the claim only succeeds once the
      // backoff has passed. Attempting it now is harmless and saves a poll.
      const claimed = await context.db.jobs.claimNext(new Date(), [job.kind]);
      if (claimed) await runJob(context, claimed);
    })();

    return ok({ data: toJobView(job), message: 'Queued for another attempt.' }, {
      headers: limit.headers,
    });
  } catch (error) {
    if (error instanceof RetryNotAllowedError || error instanceof JobConflictError) {
      return fail(409, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
