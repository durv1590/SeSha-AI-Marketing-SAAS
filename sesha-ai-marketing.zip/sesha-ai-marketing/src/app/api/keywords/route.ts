import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { listKeywords } from '@/lib/crawl/service';
import { KEYWORD_DATA_NOTE } from '@/lib/keywords/extract';
import { PRIORITY_BASIS } from '@/lib/keywords/types';

/**
 * The project's keyword list.
 *
 * The response always carries `dataNote` and `priorityBasis`, so no client can
 * render the list without the statement that volume and competition are
 * unavailable and that priority does not include them.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const projectId = new URL(request.url).searchParams.get('projectId') ?? '';
  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', undefined, { headers: limit.headers });
  }

  try {
    const keywords = await listKeywords({ db: getDatabase() }, auth.tenant, projectId);
    return ok(
      { data: { keywords, dataNote: KEYWORD_DATA_NOTE, priorityBasis: PRIORITY_BASIS } },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
