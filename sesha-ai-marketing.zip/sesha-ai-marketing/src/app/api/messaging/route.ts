import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import {
  MessagingInputError,
  UnlawfulAudienceError,
  listMessagingPlans,
  saveMessagingPlan,
} from '@/lib/messaging/service';
import { sendingStatus, type MessagingPlan } from '@/lib/messaging/types';

/**
 * Email and WhatsApp plans.
 *
 * `sendingStatus()` travels in every response. SeSha cannot send: there is no
 * send endpoint to call, no scheduler, and no recipient list stored anywhere.
 *
 * A plan with no lawful basis — a bought list, scraped numbers, nothing recorded —
 * is REFUSED with 422 and a written reason. It is not saved as a draft with a
 * warning, because a draft is one click from being worked on.
 */
export const dynamic = 'force-dynamic';

function isChannel(value: unknown): value is 'email' | 'whatsapp' {
  return value === 'email' || value === 'whatsapp';
}

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const params = new URL(request.url).searchParams;
  const projectId = params.get('projectId') ?? '';
  const channel = params.get('channel');

  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', { projectId: 'A projectId is required.' }, {
      headers: limit.headers,
    });
  }

  try {
    const plans = await listMessagingPlans(
      { db: getDatabase() },
      auth.tenant,
      projectId,
      isChannel(channel) ? channel : undefined,
    );
    return ok(
      {
        data: {
          plans: plans.map((row) => ({
            id: row.id,
            channel: row.channel,
            kind: row.kind,
            category: row.category,
            title: row.title,
            optInBasis: row.optInBasis,
            audienceNote: row.audienceNote,
            reviewState: row.reviewState,
            problems: row.problems,
            createdAt: row.createdAt.toISOString(),
          })),
          sending: {
            email: sendingStatus('email'),
            whatsapp: sendingStatus('whatsapp'),
          },
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  const title = typeof input.title === 'string' ? input.title : '';

  if (projectId.length === 0 || typeof input.plan !== 'object' || input.plan === null) {
    return fail(
      422,
      'Please check the form.',
      {
        ...(projectId.length === 0 ? { projectId: 'Choose a project first.' } : {}),
        ...(typeof input.plan === 'object' && input.plan !== null ? {} : { plan: 'The plan is missing.' }),
      },
      { headers: limit.headers },
    );
  }

  try {
    const saved = await saveMessagingPlan({ db: getDatabase() }, auth.tenant, {
      projectId,
      title,
      plan: input.plan as MessagingPlan,
      ...(input.reviewState === 'approved' || input.reviewState === 'in_review'
        ? { reviewState: input.reviewState }
        : {}),
    });
    return ok(
      {
        data: { id: saved.row.id, problems: saved.problems, sending: saved.sending },
        message: saved.problems.length > 0 ? 'Saved, with notes.' : 'Saved.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof UnlawfulAudienceError) {
      return fail(422, error.message, { optInBasis: error.message }, { headers: limit.headers });
    }
    if (error instanceof MessagingInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
