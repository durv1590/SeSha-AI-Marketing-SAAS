import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import {
  MessagingInputError,
  deleteMessagingPlan,
  getMessagingPlan,
  setMessagingReviewState,
} from '@/lib/messaging/service';

/** One message plan: read it, mark it ready, or delete it. Nothing sends. */
export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;

  try {
    const found = await getMessagingPlan({ db: getDatabase() }, auth.tenant, id);
    return ok(
      {
        data: {
          plan: found.row.plan,
          meta: {
            id: found.row.id,
            channel: found.row.channel,
            kind: found.row.kind,
            category: found.row.category,
            reviewState: found.row.reviewState,
          },
          problems: found.problems,
          sending: found.sending,
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const state = (body as Record<string, unknown>).reviewState;
  if (state !== 'draft' && state !== 'in_review' && state !== 'approved') {
    return fail(422, 'Unknown review state.', undefined, { headers: limit.headers });
  }

  try {
    const saved = await setMessagingReviewState({ db: getDatabase() }, auth.tenant, id, state);
    return ok(
      {
        data: { reviewState: saved.row.reviewState, problems: saved.problems, sending: saved.sending },
        message:
          state === 'approved'
            ? 'Marked ready. You still send it from your own provider — SeSha cannot.'
            : 'Updated.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof MessagingInputError) {
      return fail(409, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}

export async function DELETE(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;

  try {
    await deleteMessagingPlan({ db: getDatabase() }, auth.tenant, id);
    return ok({ data: { removed: true }, message: 'Deleted.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
