import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { StrategyReviewError, deleteStrategy, getStrategy, setStrategyStatus } from '@/lib/strategy/service';
import type { ReviewStatus } from '@/lib/db/types';

export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

const STATUSES: readonly ReviewStatus[] = ['draft', 'in_review', 'approved', 'archived'];

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const { id } = await params;
    const strategy = await getStrategy({ db: getDatabase() }, auth.tenant, id);
    return ok({ data: strategy }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const status = (body as Record<string, unknown>).status;
  if (!STATUSES.includes(status as ReviewStatus)) {
    return fail(422, 'Please check the form.', { status: 'That is not a valid status.' }, {
      headers: limit.headers,
    });
  }

  try {
    const { id } = await params;
    const strategy = await setStrategyStatus(
      { db: getDatabase() },
      auth.tenant,
      id,
      status as ReviewStatus,
    );
    return ok({ data: strategy, message: 'Saved.' }, { headers: limit.headers });
  } catch (error) {
    // A strategy blocked from approval is a 409: the request was well-formed
    // and permitted, but the document's own state forbids it.
    if (error instanceof StrategyReviewError) {
      return fail(409, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}

export async function DELETE(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const { id } = await params;
    await deleteStrategy({ db: getDatabase() }, auth.tenant, id);
    return ok({ message: 'Deleted.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
