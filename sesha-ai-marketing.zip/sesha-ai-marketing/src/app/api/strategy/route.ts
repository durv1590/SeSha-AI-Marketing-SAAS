import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { generateStrategy, listStrategies, strategyPlan } from '@/lib/strategy/service';
import { STRATEGY_SECTIONS, type StrategySectionId } from '@/lib/strategy/sections';

/**
 * Strategy listing, planning and generation.
 *
 * GET with `?plan=1` answers "what could be generated right now, and what is
 * missing" WITHOUT calling a provider. The interface shows that first, so the
 * user sees which of the 17 sections are unavailable before spending a
 * generation on a document with holes in it.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const params = new URL(request.url).searchParams;
  const projectId = params.get('projectId') ?? '';
  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', undefined, { headers: limit.headers });
  }

  try {
    const db = getDatabase();
    if (params.get('plan') === '1') {
      const plan = await strategyPlan({ db }, auth.tenant, projectId);
      return ok(
        {
          data: plan.map((section) => ({
            id: section.spec.id,
            label: section.spec.label,
            availability: section.availability,
            missing: section.missing,
            note: section.note,
          })),
        },
        { headers: limit.headers },
      );
    }

    const strategies = await listStrategies({ db }, auth.tenant, projectId);
    return ok({ data: strategies }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  // aiBatch, not ai: one call here fans out into up to 17 provider calls.
  const limit = enforceRateLimit(request, 'aiBatch');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  if (projectId.length === 0) {
    return fail(422, 'Please check the form.', { projectId: 'Choose a project first.' }, { headers: limit.headers });
  }

  let sections: StrategySectionId[] | undefined;
  if (Array.isArray(input.sections)) {
    sections = input.sections.filter((id): id is StrategySectionId =>
      typeof id === 'string' && (STRATEGY_SECTIONS as readonly string[]).includes(id));
    if (sections.length === 0) {
      return fail(422, 'Please check the form.', { sections: 'None of those sections exist.' }, {
        headers: limit.headers,
      });
    }
  }

  try {
    const outcome = await generateStrategy({ db: getDatabase() }, auth.tenant, {
      projectId,
      ...(typeof input.title === 'string' ? { title: input.title } : {}),
      ...(sections ? { sections } : {}),
    });

    if (!outcome.ok) {
      return fail(502, outcome.message ?? 'The strategy could not be generated.', undefined, {
        headers: limit.headers,
      });
    }

    return ok(
      { data: { strategy: outcome.strategy, sections: outcome.sections } },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
