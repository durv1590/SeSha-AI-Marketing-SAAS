import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { getConversation } from '@/lib/ai/service';

export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const { id } = await params;
    // A conversation in another organization is a 404, not a 403.
    const data = await getConversation({ db: getDatabase() }, auth.tenant, id);
    return ok({ data }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
