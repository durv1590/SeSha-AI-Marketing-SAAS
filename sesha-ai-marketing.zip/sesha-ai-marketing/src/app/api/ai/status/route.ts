import { isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { availability } from '@/lib/ai/service';
import { publicStatus } from '@/lib/ai/provider';

/**
 * AI availability for the dashboard.
 *
 * Returns `publicStatus()`, which is deliberately narrow: provider NAMES, a
 * configured true/false, and model labels. No key, no base URL, no header
 * material. Signing in is still required — whether a deployment has AI
 * configured is not information for the public internet.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  return ok(
    { data: { ...publicStatus(), ...availability({ db: getDatabase() }) } },
    { headers: limit.headers },
  );
}
