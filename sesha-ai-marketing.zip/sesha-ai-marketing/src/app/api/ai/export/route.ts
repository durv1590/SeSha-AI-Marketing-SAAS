import { isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, readJson } from '@/lib/api/respond';
import { exportBlocks, exportFilename, isExportFormat } from '@/lib/ai/service';
import { parseProvenance } from '@/lib/ai/provenance';

/**
 * Download an AI output as txt, md or json.
 *
 * The blocks are re-parsed through `parseProvenance` even though they came
 * from this application a moment ago. Anything the client sends back is
 * untrusted, and the parser is what guarantees the exported file contains only
 * blocks with a valid provenance kind — a file is the artefact most likely to
 * outlive its context and be read as plain fact later.
 */
export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const format = isExportFormat(input.format) ? input.format : 'txt';

  const parsed = parseProvenance({ blocks: input.blocks });
  if (!parsed.ok) {
    return fail(422, 'That content could not be exported.', undefined, { headers: limit.headers });
  }

  const title = typeof input.title === 'string' ? input.title.slice(0, 120) : 'SeSha export';
  const rendered = exportBlocks(parsed.response.blocks, format, {
    title,
    generatedAt: new Date().toISOString(),
  });

  return new Response(rendered.body, {
    status: 200,
    headers: {
      'Content-Type': rendered.contentType,
      // The filename is slugified, so it cannot carry a quote, a newline, or a
      // path separator into this header.
      'Content-Disposition': `attachment; filename="${exportFilename(title, rendered.extension)}"`,
      'Cache-Control': 'no-store, max-age=0',
      'X-Content-Type-Options': 'nosniff',
      ...limit.headers,
    },
  });
}
