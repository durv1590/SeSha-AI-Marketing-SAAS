import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { askCopilot } from '@/lib/ai/service';
import { blocksToText, summarize } from '@/lib/ai/provenance';

/**
 * The Copilot turn endpoint.
 *
 * What comes back is the PROVENANCE BLOCKS, not a flat string. The interface
 * needs the per-block kinds to label what is sourced and what is not, and
 * flattening here would throw away the only thing that makes that labelling
 * possible. `text` is included alongside purely as a copy-and-paste convenience.
 */
export const dynamic = 'force-dynamic';

const MAX_PROMPT = 20_000;

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'ai');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const prompt = typeof input.prompt === 'string' ? input.prompt.trim() : '';
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';

  if (prompt.length === 0) {
    return fail(422, 'Please check the form.', { prompt: 'Enter a question first.' }, { headers: limit.headers });
  }
  if (prompt.length > MAX_PROMPT) {
    return fail(
      422,
      'Please check the form.',
      { prompt: `That is longer than the ${MAX_PROMPT.toLocaleString()} character limit.` },
      { headers: limit.headers },
    );
  }
  if (projectId.length === 0) {
    return fail(422, 'Please check the form.', { projectId: 'Choose a project first.' }, { headers: limit.headers });
  }

  try {
    const turn = await askCopilot({ db: getDatabase() }, auth.tenant, {
      prompt,
      projectId,
      conversationId: typeof input.conversationId === 'string' ? input.conversationId : null,
      ...(typeof input.model === 'string' ? { model: input.model } : {}),
    });

    if (!turn.result.ok) {
      // The user's message was saved, so the conversation id is still returned
      // and a retry continues the same thread rather than starting a new one.
      return fail(
        turn.result.code === 'rate_limited' ? 429 : 502,
        turn.result.message,
        undefined,
        {
          headers: {
            ...limit.headers,
            ...(turn.result.retryAfterSeconds
              ? { 'Retry-After': String(turn.result.retryAfterSeconds) }
              : {}),
          },
        },
      );
    }

    const { response, record, cached } = turn.result;

    return ok(
      {
        data: {
          conversationId: turn.conversation.id,
          messageId: turn.assistantMessage?.id ?? null,
          blocks: response.blocks,
          text: blocksToText(response.blocks),
          provenance: summarize(response.blocks),
          warnings: response.warnings,
          safe: response.safe,
          context: turn.contextSummary,
          // Deliberately no provider key, prompt, or system prompt.
          meta: { model: record.model, provider: record.provider, cached, truncated: turn.result.truncated },
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
