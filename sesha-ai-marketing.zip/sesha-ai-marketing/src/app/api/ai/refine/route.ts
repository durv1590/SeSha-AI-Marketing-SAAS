import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { isRefinement, refine } from '@/lib/ai/service';
import { blocksToText } from '@/lib/ai/provenance';

/**
 * Shorten, expand, translate, change tone.
 *
 * The source text comes from the client rather than being re-read from the
 * database, because the user may be refining an unsaved draft they have just
 * edited. It is therefore treated as untrusted input: length-capped, and
 * wrapped in the prompt rather than concatenated into instructions.
 */
export const dynamic = 'force-dynamic';

const MAX_TEXT = 16_000;

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'ai');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const errors: Record<string, string> = {};

  if (!isRefinement(input.refinement)) {
    errors.refinement = 'Choose shorten, expand, translate, or change_tone.';
  }

  const text = typeof input.text === 'string' ? input.text.trim() : '';
  if (text.length === 0) errors.text = 'There is nothing to rewrite.';
  else if (text.length > MAX_TEXT) errors.text = 'That is too long to rewrite in one go.';

  if (Object.keys(errors).length > 0 || !isRefinement(input.refinement)) {
    return fail(422, 'Please check the form.', errors, { headers: limit.headers });
  }

  try {
    const result = await refine({ db: getDatabase() }, auth.tenant, {
      refinement: input.refinement,
      text,
      projectId: typeof input.projectId === 'string' ? input.projectId : null,
      ...(typeof input.target === 'string' ? { target: input.target.slice(0, 60) } : {}),
    });

    if (!result.ok) {
      return fail(result.code === 'rate_limited' ? 429 : 502, result.message, undefined, {
        headers: limit.headers,
      });
    }

    return ok(
      {
        data: {
          blocks: result.response.blocks,
          text: blocksToText(result.response.blocks),
          warnings: result.response.warnings,
          safe: result.response.safe,
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
