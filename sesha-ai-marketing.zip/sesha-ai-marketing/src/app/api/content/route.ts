import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { listContent } from '@/lib/content/service';

export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const params = new URL(request.url).searchParams;
  const projectId = params.get('projectId') ?? '';
  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', undefined, { headers: limit.headers });
  }

  const requested = Number(params.get('limit') ?? '50');
  const take = Number.isFinite(requested) ? Math.min(Math.max(1, requested), 200) : 50;

  try {
    const items = await listContent({ db: getDatabase() }, auth.tenant, projectId, take);
    return ok({ data: items }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
