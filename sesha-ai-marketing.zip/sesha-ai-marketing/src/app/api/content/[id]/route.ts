import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { deleteContent, getContent, updateContent } from '@/lib/content/service';
import type { ReviewStatus } from '@/lib/db/types';

export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

const STATUSES: readonly ReviewStatus[] = ['draft', 'in_review', 'approved', 'archived'];

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const { id } = await params;
    const item = await getContent({ db: getDatabase() }, auth.tenant, id);
    return ok({ data: item }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  if (input.status !== undefined && !STATUSES.includes(input.status as ReviewStatus)) {
    return fail(422, 'Please check the form.', { status: 'That is not a valid status.' }, {
      headers: limit.headers,
    });
  }

  try {
    const { id } = await params;
    const item = await updateContent({ db: getDatabase() }, auth.tenant, id, {
      ...(typeof input.title === 'string' ? { title: input.title } : {}),
      ...(typeof input.body === 'string' ? { body: input.body } : {}),
      ...(input.status !== undefined ? { status: input.status as ReviewStatus } : {}),
    });
    return ok({ data: item, message: 'Saved.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function DELETE(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const { id } = await params;
    // Soft delete: the row is retained for the recovery window, as in Phase 2.
    await deleteContent({ db: getDatabase() }, auth.tenant, id);
    return ok({ message: 'Deleted.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
