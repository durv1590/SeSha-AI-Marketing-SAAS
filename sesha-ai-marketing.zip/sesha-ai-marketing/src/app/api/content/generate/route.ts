import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { generateContent, validateControls } from '@/lib/content/service';
import { blocksToText } from '@/lib/ai/provenance';

/**
 * Content Studio generation.
 *
 * `issues` is returned alongside the item rather than instead of it: a draft
 * that runs over a platform limit or mixes scripts is still the user's draft
 * to fix, and silently discarding it would be worse than showing it flagged.
 */
export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'ai');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  if (projectId.length === 0) {
    return fail(422, 'Please check the form.', { projectId: 'Choose a project first.' }, { headers: limit.headers });
  }

  const validated = validateControls(input);
  if (!validated.ok || !validated.controls) {
    return fail(422, 'Please check the form.', validated.errors, { headers: limit.headers });
  }

  try {
    const outcome = await generateContent({ db: getDatabase() }, auth.tenant, {
      projectId,
      controls: validated.controls,
      save: input.save !== false,
    });

    if (!outcome.result.ok) {
      return fail(outcome.result.code === 'rate_limited' ? 429 : 502, outcome.result.message, undefined, {
        headers: limit.headers,
      });
    }

    return ok(
      {
        data: {
          item: outcome.item,
          blocks: outcome.result.response.blocks,
          text: blocksToText(outcome.result.response.blocks),
          warnings: outcome.result.response.warnings,
          safe: outcome.result.response.safe,
          issues: outcome.issues,
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
