import { cronSecret } from '@/lib/auth/session';
import { getDatabase } from '@/lib/db';
import { isMaintenanceAuthorized, runMaintenance } from '@/lib/jobs/maintenance';

/**
 * Scheduler entry point. Called with `Authorization: Bearer $CRON_SECRET`.
 *
 * Unauthorised requests get a 404, not a 401: an internal endpoint does not
 * advertise that it exists (the same rule as the admin API).
 */
export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  if (!isMaintenanceAuthorized(request.headers.get('authorization'), cronSecret())) {
    return new Response('Not found', { status: 404 });
  }
  const report = await runMaintenance({ db: getDatabase() });
  return Response.json(report, { headers: { 'Cache-Control': 'no-store' } });
}
