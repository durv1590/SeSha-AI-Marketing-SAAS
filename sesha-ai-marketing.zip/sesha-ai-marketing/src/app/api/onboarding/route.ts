import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { completeOnboarding } from '@/lib/workspace/service';
import {
  validateBusiness,
  validateCrawlConsent,
  validateMarketingProfile,
} from '@/lib/validation/onboarding';

/**
 * Completes onboarding.
 *
 * The crawl consent block is optional and is validated SEPARATELY. If it is
 * absent, or the consent flag is not exactly `true`, no consent is recorded and
 * onboarding still succeeds — entering a website address is not permission to
 * fetch it.
 */

export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;

  const business = validateBusiness((input.business ?? {}) as Record<string, unknown>);
  if (!business.ok) {
    return fail(422, 'Please check your business details.', business.errors as Record<string, string>, {
      headers: limit.headers,
    });
  }

  const profile = validateMarketingProfile((input.profile ?? {}) as Record<string, unknown>);
  if (!profile.ok) {
    return fail(422, 'Please check your marketing profile.', profile.errors as Record<string, string>, {
      headers: limit.headers,
    });
  }

  let crawlConsent = null;
  if (input.crawlConsent && typeof input.crawlConsent === 'object') {
    const consent = validateCrawlConsent(input.crawlConsent as Record<string, unknown>);
    if (!consent.ok) {
      return fail(422, 'Please review the website access terms.', consent.errors as Record<string, string>, {
        headers: limit.headers,
      });
    }
    crawlConsent = consent.data;
  }

  try {
    const result = await completeOnboarding({ db: getDatabase() }, auth.tenant, {
      business: business.data,
      profile: profile.data,
      projectName: typeof input.projectName === 'string' ? input.projectName : undefined,
      crawlConsent,
    });
    return ok(
      {
        data: { projectId: result.project.id, completeness: result.profile.completeness },
        message: 'Your workspace is ready.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
