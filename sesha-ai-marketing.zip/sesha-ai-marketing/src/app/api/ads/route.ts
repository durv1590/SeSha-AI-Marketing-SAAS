import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { AdPlanInputError, listAdPlans, saveAdPlan, startAdPlan } from '@/lib/ads/service';
import { adsDataStatus, isAdPlatform, isCampaignObjective } from '@/lib/ads/platforms';

/**
 * Advertising plans.
 *
 * Every response carries `adsDataStatus()`, which says that no ad account is
 * connected and that nothing here spends money or reads performance. It is in the
 * payload rather than only in the interface so a client cannot render a plan
 * without the context that it is a plan.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const params = new URL(request.url).searchParams;
  const projectId = params.get('projectId') ?? '';
  const platform = params.get('platform');
  const start = params.get('start');
  const objective = params.get('objective');

  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', { projectId: 'A projectId is required.' }, {
      headers: limit.headers,
    });
  }

  const context = { db: getDatabase() };

  try {
    // `start=1` returns an empty structured plan rather than a stored one, so the
    // interface can open a blank form with the platform's real limits attached.
    if (start === '1' && isAdPlatform(platform) && isCampaignObjective(objective)) {
      const started = await startAdPlan(context, auth.tenant, {
        projectId,
        platform,
        objective,
      });
      return ok(
        { data: { plan: started.plan, dataStatus: started.dataStatus } },
        { headers: limit.headers },
      );
    }

    const plans = await listAdPlans(
      context,
      auth.tenant,
      projectId,
      isAdPlatform(platform) ? platform : undefined,
    );
    return ok(
      {
        data: {
          plans: plans.map((row) => ({
            id: row.id,
            platform: row.platform,
            objective: row.objective,
            campaignName: row.campaignName,
            reviewState: row.reviewState,
            problems: row.problems,
            createdAt: row.createdAt.toISOString(),
          })),
          dataStatus: adsDataStatus(),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  if (projectId.length === 0 || typeof input.plan !== 'object' || input.plan === null) {
    return fail(
      422,
      'Please check the form.',
      {
        ...(projectId.length === 0 ? { projectId: 'Choose a project first.' } : {}),
        ...(typeof input.plan === 'object' && input.plan !== null ? {} : { plan: 'The plan is missing.' }),
      },
      { headers: limit.headers },
    );
  }

  try {
    const saved = await saveAdPlan({ db: getDatabase() }, auth.tenant, {
      projectId,
      plan: input.plan as Parameters<typeof saveAdPlan>[2]['plan'],
      ...(input.reviewState === 'approved' || input.reviewState === 'in_review'
        ? { reviewState: input.reviewState }
        : {}),
    });
    return ok(
      {
        data: { id: saved.row.id, problems: saved.problems, dataStatus: adsDataStatus() },
        message: saved.problems.length > 0 ? 'Saved, with notes.' : 'Saved.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof AdPlanInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
