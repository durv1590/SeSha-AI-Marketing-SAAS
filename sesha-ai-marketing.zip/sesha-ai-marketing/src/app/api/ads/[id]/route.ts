import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import {
  AdPlanInputError,
  deleteAdPlan,
  getAdPlan,
  setAdPlanReviewState,
} from '@/lib/ads/service';
import { adsDataStatus } from '@/lib/ads/platforms';

/** One advertising plan: read it, change its review state, or delete it. */
export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;

  try {
    const row = await getAdPlan({ db: getDatabase() }, auth.tenant, id);
    return ok(
      { data: { plan: row.plan, meta: { id: row.id, reviewState: row.reviewState, problems: row.problems }, dataStatus: adsDataStatus() } },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const state = (body as Record<string, unknown>).reviewState;
  if (state !== 'draft' && state !== 'in_review' && state !== 'approved') {
    return fail(422, 'Unknown review state.', undefined, { headers: limit.headers });
  }

  try {
    const saved = await setAdPlanReviewState({ db: getDatabase() }, auth.tenant, id, state);
    return ok(
      { data: { reviewState: saved.row.reviewState, problems: saved.problems }, message: 'Updated.' },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof AdPlanInputError) {
      return fail(409, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}

export async function DELETE(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;

  try {
    await deleteAdPlan({ db: getDatabase() }, auth.tenant, id);
    return ok({ data: { removed: true }, message: 'Deleted.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
