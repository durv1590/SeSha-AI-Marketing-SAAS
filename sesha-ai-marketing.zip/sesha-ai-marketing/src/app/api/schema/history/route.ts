import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { compareStoredValidations, listValidationHistory } from '@/lib/schema/service';

/**
 * The project's validation history, and the comparison between two runs.
 *
 * A comparison names whether the validator's own version changed between the two
 * runs, because that confounds the diff: a finding that appeared might be the
 * customer's markup changing or our rules changing, and only one of those is
 * their problem.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const params = new URL(request.url).searchParams;
  const projectId = params.get('projectId') ?? '';
  const compareFrom = params.get('from');
  const compareTo = params.get('to');

  if (projectId.length === 0 && !(compareFrom && compareTo)) {
    return fail(422, 'A projectId is required.', { projectId: 'A projectId is required.' }, {
      headers: limit.headers,
    });
  }

  try {
    const context = { db: getDatabase() };
    if (compareFrom && compareTo) {
      const comparison = await compareStoredValidations(
        context,
        auth.tenant,
        compareFrom,
        compareTo,
      );
      return ok({ data: comparison }, { headers: limit.headers });
    }

    const history = await listValidationHistory(context, auth.tenant, projectId);
    return ok(
      {
        data: history.map((row) => ({
          id: row.id,
          checkedAt: row.checkedAt.toISOString(),
          sourceKind: row.sourceKind,
          sourceUrl: row.sourceUrl,
          validatorVersion: row.validatorVersion,
          overallStatus: row.overallStatus,
          counts: row.counts,
          typesFound: row.typesFound,
          syntaxes: row.syntaxes,
        })),
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
