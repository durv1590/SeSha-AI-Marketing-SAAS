import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { ValidationInputError, validateForProject } from '@/lib/schema/service';

/**
 * Validate structured data inside a project, and keep the run in its history.
 *
 * DIFFERENT FROM THE PUBLIC TOOL at /api/schema-validator, deliberately: that one
 * is stateless and stores nothing, which is what the privacy page promises. This
 * one is authenticated, scoped to a project and stores the result so the history
 * and the comparison over time exist.
 *
 * There is NO fetch here. A page-URL run reads the copy the Phase 4 crawler
 * already took under the project's own crawl consent. Fetching an arbitrary URL
 * from a validation endpoint would reintroduce the crawler's whole threat model
 * in a quieter place.
 */
export const dynamic = 'force-dynamic';

const MAX_BODY_BYTES = 210_000;

function isSourceKind(value: unknown): value is 'pasted' | 'page_url' | 'website_url' {
  return value === 'pasted' || value === 'page_url' || value === 'website_url';
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request, MAX_BODY_BYTES);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  const sourceKind = input.sourceKind;

  const errors: Record<string, string> = {};
  if (projectId.length === 0) errors.projectId = 'Choose a project first.';
  if (!isSourceKind(sourceKind)) errors.sourceKind = 'Say what is being validated.';
  if (Object.keys(errors).length > 0 || !isSourceKind(sourceKind)) {
    return fail(422, 'Please check the request.', errors, { headers: limit.headers });
  }

  try {
    const outcome = await validateForProject({ db: getDatabase() }, auth.tenant, {
      projectId,
      sourceKind,
      ...(typeof input.source === 'string' ? { source: input.source } : {}),
      ...(typeof input.url === 'string' ? { url: input.url } : {}),
      ...(input.store === false ? { store: false } : {}),
    });

    return ok(
      {
        data: {
          result: outcome.result,
          correction: outcome.correction,
          ...(outcome.stored ? { validationId: outcome.stored.id } : {}),
          ...(outcome.comparison ? { comparison: outcome.comparison } : {}),
        },
        message:
          outcome.result.overall === 'INVALID'
            ? 'Problems found.'
            : outcome.result.overall === 'NOT_EVALUATED'
              ? 'No structured data was found.'
              : 'Checked.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof ValidationInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
