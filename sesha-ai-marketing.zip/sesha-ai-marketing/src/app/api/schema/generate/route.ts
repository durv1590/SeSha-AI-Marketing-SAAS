import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { ValidationInputError, generateForProject } from '@/lib/schema/service';
import { GENERATED_KINDS, type GeneratedKind } from '@/lib/schema/generate';

/**
 * Generate JSON-LD from the project's own verified data.
 *
 * The response carries three lists, not one: what was included (with the field it
 * came from), what was omitted (because the data is missing), and what was
 * REFUSED (because generating it would mean inventing a review, a rating, a price
 * or a credential). The refusals are part of the answer, not an error.
 */
export const dynamic = 'force-dynamic';

function isKind(value: unknown): value is GeneratedKind {
  return typeof value === 'string' && (GENERATED_KINDS as readonly string[]).includes(value);
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';

  const errors: Record<string, string> = {};
  if (projectId.length === 0) errors.projectId = 'Choose a project first.';
  if (!isKind(input.kind)) errors.kind = 'Choose what to generate.';
  if (Object.keys(errors).length > 0 || !isKind(input.kind)) {
    return fail(422, 'Please check the request.', errors, { headers: limit.headers });
  }

  try {
    const generated = await generateForProject({ db: getDatabase() }, auth.tenant, {
      projectId,
      kind: input.kind,
      ...(typeof input.pageUrl === 'string' ? { pageUrl: input.pageUrl } : {}),
    });
    return ok(
      { data: generated, message: 'Generated from your own data.' },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof ValidationInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
