import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { createProject, listProjects } from '@/lib/workspace/service';
import { validateProject } from '@/lib/validation/onboarding';

export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const projects = await listProjects({ db: getDatabase() }, auth.tenant);
    return ok({ data: projects }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  // requireAuth also performs the origin and CSRF checks for POST.
  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const validated = validateProject(body as Record<string, unknown>);
  if (!validated.ok) {
    return fail(422, 'Please check the form.', validated.errors as Record<string, string>, {
      headers: limit.headers,
    });
  }

  try {
    const project = await createProject({ db: getDatabase() }, auth.tenant, validated.data);
    return ok({ data: project, message: 'Project created.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
