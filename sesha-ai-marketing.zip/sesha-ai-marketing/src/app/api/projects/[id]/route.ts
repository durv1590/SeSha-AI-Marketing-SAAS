import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { deleteProject, getProject, updateProject } from '@/lib/workspace/service';
import { validateProject } from '@/lib/validation/onboarding';

export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const { id } = await params;
    // getProject enforces both the permission and tenant ownership; a project
    // belonging to another organization surfaces as 404, never 403.
    const project = await getProject({ db: getDatabase() }, auth.tenant, id);
    return ok({ data: project }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const validated = validateProject(body as Record<string, unknown>);
  if (!validated.ok) {
    return fail(422, 'Please check the form.', validated.errors as Record<string, string>, {
      headers: limit.headers,
    });
  }

  try {
    const { id } = await params;
    const project = await updateProject({ db: getDatabase() }, auth.tenant, id, validated.data);
    return ok({ data: project, message: 'Project updated.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function DELETE(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const { id } = await params;
    await deleteProject({ db: getDatabase() }, auth.tenant, id);
    return ok({ message: 'Project deleted.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
