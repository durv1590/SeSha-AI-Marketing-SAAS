import { enforceRateLimit, fail, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { ShareDeniedError, viewShared } from '@/lib/reports/service';
import { SHARE_DENIED_MESSAGE } from '@/lib/reports/share';

/**
 * Reading a shared report. THE ONLY UNAUTHENTICATED ENDPOINT THAT RETURNS
 * TENANT DATA, and the reasoning behind every line here follows from that.
 *
 *  · No `requireAuth`: the caller is a client or a colleague with a link, and
 *    the token is the only credential.
 *  · Every failure — unknown, expired, revoked, deleted report, malformed —
 *    returns 404 with the SAME sentence. A stranger must not be able to learn
 *    from the wording whether the link was ever real.
 *  · Rate limited as a read, because an unauthenticated endpoint that looks
 *    things up by token is the one worth guessing at.
 *  · `no-store` and `noindex`: a report is somebody's business data, and a
 *    shared link must not end up in a search index or a shared cache.
 */
export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ token: string }> };

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const { token } = await params;

  try {
    const viewed = await viewShared({ db: getDatabase() }, token);
    return ok(
      {
        data: {
          report: viewed.report,
          generatedAt: viewed.row.generatedAt.toISOString(),
          note: 'This is a snapshot of the report as it was generated. It does not change.',
        },
      },
      {
        headers: {
          ...Object.fromEntries(limit.headers ? Object.entries(limit.headers) : []),
          'Cache-Control': 'private, no-store',
          'X-Robots-Tag': 'noindex, nofollow',
        },
      },
    );
  } catch (error) {
    if (error instanceof ShareDeniedError) {
      return fail(404, SHARE_DENIED_MESSAGE, undefined, { headers: limit.headers });
    }
    // Anything else is also a 404 here. An unauthenticated caller learns nothing
    // from a 500 except that they found something worth poking at.
    return fail(404, SHARE_DENIED_MESSAGE, undefined, { headers: limit.headers });
  }
}
