import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { AutomationInputError, createFromTemplate, createRule, listRules } from '@/lib/automation/service';
import {
  ACTION_EFFECT,
  ACTION_KINDS,
  ACTION_LABEL,
  MAX_RUNS_PER_DAY,
  OPERATOR_LABEL,
  RULE_TEMPLATES,
  TRIGGER_FIELDS,
  TRIGGER_KINDS,
  TRIGGER_LABEL,
  isActionKind,
  isOutboundAction,
  isTriggerKind,
  type Action,
  type Condition,
} from '@/lib/automation/types';

/**
 * Automations: Trigger → Condition → Action.
 *
 * The GET returns the whole vocabulary — triggers with the fields each one
 * publishes, and actions with what each ACTUALLY does — because a rule builder
 * that offers a field the trigger does not provide produces rules that silently
 * never fire.
 *
 * `outbound: false` is on every action, and it is not decoration: it is the
 * assertion that nothing here contacts anybody.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const projectId = new URL(request.url).searchParams.get('projectId') ?? '';
  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', { projectId: 'A projectId is required.' }, {
      headers: limit.headers,
    });
  }

  try {
    const rules = await listRules({ db: getDatabase() }, auth.tenant, projectId);
    return ok(
      {
        data: {
          rules: rules.map((rule) => ({
            id: rule.id,
            name: rule.name,
            trigger: rule.triggerKind,
            triggerLabel: isTriggerKind(rule.triggerKind) ? TRIGGER_LABEL[rule.triggerKind] : rule.triggerKind,
            conditions: rule.conditions,
            actions: rule.actions,
            enabled: rule.enabled,
            createdAt: rule.createdAt.toISOString(),
          })),
          triggers: TRIGGER_KINDS.map((kind) => ({
            id: kind,
            label: TRIGGER_LABEL[kind],
            fields: TRIGGER_FIELDS[kind],
          })),
          actions: ACTION_KINDS.map((kind) => ({
            id: kind,
            label: ACTION_LABEL[kind],
            effect: ACTION_EFFECT[kind],
            outbound: isOutboundAction(kind),
          })),
          operators: OPERATOR_LABEL,
          templates: RULE_TEMPLATES,
          maxRunsPerDay: MAX_RUNS_PER_DAY,
          note: 'SeSha automations never contact anyone, post anything or spend anything. Every action produces something that waits for a person.',
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  if (projectId.length === 0) {
    return fail(422, 'Choose a project first.', { projectId: 'Choose a project first.' }, {
      headers: limit.headers,
    });
  }

  try {
    const db = getDatabase();

    if (typeof input.template === 'string') {
      const rule = await createFromTemplate({ db }, auth.tenant, projectId, input.template);
      return ok(
        {
          data: { id: rule.id, enabled: rule.enabled },
          message: 'Added, switched off. Turn it on when you have read what it does.',
        },
        { headers: limit.headers },
      );
    }

    const name = typeof input.name === 'string' ? input.name : '';
    const errors: Record<string, string> = {};
    if (name.trim().length === 0) errors.name = 'Give the rule a name.';
    if (!isTriggerKind(input.trigger)) errors.trigger = 'Choose what this rule listens for.';
    if (!Array.isArray(input.actions) || input.actions.length === 0) {
      errors.actions = 'A rule that does nothing is not a rule.';
    }
    if (Object.keys(errors).length > 0) {
      return fail(422, 'Please check the rule.', errors, { headers: limit.headers });
    }

    const actions = (input.actions as unknown[]).filter(
      (action): action is Action =>
        typeof action === 'object' && action !== null && isActionKind((action as { kind?: unknown }).kind),
    );
    const conditions = Array.isArray(input.conditions) ? (input.conditions as Condition[]) : [];

    const created = await createRule({ db }, auth.tenant, projectId, {
      name,
      trigger: input.trigger as (typeof TRIGGER_KINDS)[number],
      conditions,
      actions,
      enabled: input.enabled === true,
    });

    return ok(
      {
        data: { id: created.rule.id, enabled: created.rule.enabled, warnings: created.warnings },
        message: created.rule.enabled ? 'Saved and switched on.' : 'Saved, switched off.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof AutomationInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
