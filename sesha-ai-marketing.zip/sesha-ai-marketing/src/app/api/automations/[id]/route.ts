import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import {
  AutomationInputError,
  listRuns,
  removeRule,
  testRule,
  updateRule,
} from '@/lib/automation/service';
import { isActionKind, isTriggerKind, type Action, type Condition } from '@/lib/automation/types';

/**
 * One automation: read its history, change it, test it, or remove it.
 *
 * The GET returns the runs INCLUDING the ones that did nothing, with the
 * condition that failed. That history is the only way to tell a rule that
 * stopped matching from a rule that never runs.
 */
export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  try {
    const runs = await listRuns({ db: getDatabase() }, auth.tenant, id);
    return ok(
      {
        data: {
          runs: runs.map((run) => ({
            id: run.id,
            matched: run.matched,
            skipReason: run.skipReason,
            actionsTaken: run.actionsTaken,
            ranAt: run.ranAt.toISOString(),
          })),
          matched: runs.filter((run) => run.matched).length,
          skipped: runs.filter((run) => !run.matched).length,
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;

  try {
    const db = getDatabase();

    // A dry run: decide what the rule WOULD do, and write nothing.
    if (input.test === true) {
      const payload = (typeof input.payload === 'object' && input.payload !== null
        ? input.payload
        : {}) as Readonly<Record<string, string | number | boolean | null>>;
      const result = await testRule({ db }, auth.tenant, id, payload);
      return ok(
        {
          data: result,
          message: result.enabledForPreview
            ? 'This rule is switched off. The preview shows what it would do if you turned it on.'
            : 'Preview only — nothing was written.',
        },
        { headers: limit.headers },
      );
    }

    const updated = await updateRule({ db }, auth.tenant, id, {
      ...(typeof input.name === 'string' ? { name: input.name } : {}),
      ...(isTriggerKind(input.trigger) ? { trigger: input.trigger } : {}),
      ...(Array.isArray(input.conditions) ? { conditions: input.conditions as Condition[] } : {}),
      ...(Array.isArray(input.actions)
        ? {
            actions: (input.actions as unknown[]).filter(
              (action): action is Action =>
                typeof action === 'object' &&
                action !== null &&
                isActionKind((action as { kind?: unknown }).kind),
            ),
          }
        : {}),
      ...(typeof input.enabled === 'boolean' ? { enabled: input.enabled } : {}),
    });

    return ok(
      {
        data: { id: updated.rule.id, enabled: updated.rule.enabled, warnings: updated.warnings },
        message: updated.rule.enabled ? 'Saved and switched on.' : 'Saved, switched off.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof AutomationInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}

export async function DELETE(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  try {
    await removeRule({ db: getDatabase() }, auth.tenant, id);
    return ok({ data: { id }, message: 'Removed, with its history.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
