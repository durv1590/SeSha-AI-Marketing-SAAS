import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { analyticsFor, connectionsFor } from '@/lib/analytics/service';
import { NO_CONNECTED_DATA, SOURCE_LABEL, SOURCE_MEANING, formatValue } from '@/lib/analytics/metrics';
import { analyticsStatus } from '@/lib/analytics/connections';

/**
 * Analytics.
 *
 * EVERY FIGURE LEAVES THIS ENDPOINT WITH ITS PROVENANCE.
 * The response carries the whole `MetricValue` union — the discriminator, the
 * formula, the as-of, or the reason it is unavailable. A flattened
 * `{ traffic: 4210 }` would be friendlier to consume and would throw away the
 * only thing that makes these numbers safe to use.
 *
 * `formatted` is a convenience for display and is NULL for anything without a
 * figure, so a client that renders it blindly shows nothing rather than "0".
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const params = new URL(request.url).searchParams;
  const projectId = params.get('projectId') ?? '';
  const days = Number.parseInt(params.get('days') ?? '30', 10);

  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', { projectId: 'A projectId is required.' }, {
      headers: limit.headers,
    });
  }

  try {
    const db = getDatabase();
    const report = await analyticsFor({ db }, auth.tenant, projectId, {
      days: Number.isFinite(days) && days > 0 && days <= 365 ? days : 30,
    });
    const connections = await connectionsFor({ db }, auth.tenant, projectId);
    const status = analyticsStatus(connections);

    return ok(
      {
        data: {
          period: report.period,
          generatedAt: report.generatedAt,
          anyConnected: report.anyConnected,
          // The sentence the brief asks for, verbatim, when there is nothing.
          headline: report.anyConnected ? status.message : NO_CONNECTED_DATA,
          explanation: status.message,
          counts: report.counts,
          sourceLabels: SOURCE_LABEL,
          sourceMeanings: SOURCE_MEANING,
          connections: connections.map((state) => ({
            provider: state.provider,
            label: state.definition.label,
            connected: state.connected,
            provides: state.definition.provides,
            howToConnect: state.definition.howToConnect,
            lastSyncedAt: state.lastSyncedAt ?? null,
            problem: state.problem ?? null,
          })),
          metrics: report.metrics.map((metric) => ({
            id: metric.id,
            label: metric.definition.label,
            description: metric.definition.description,
            group: metric.definition.group,
            unit: metric.definition.unit,
            higherIsBetter: metric.definition.higherIsBetter,
            requires: metric.definition.requires,
            value: metric.value,
            formatted: formatValue(metric.value),
            ...(metric.previous ? { previous: metric.previous } : {}),
          })),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
