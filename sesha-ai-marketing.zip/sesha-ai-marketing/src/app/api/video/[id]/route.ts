import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import {
  VideoInputError,
  deleteVideoScript,
  getVideoScript,
  setVideoReviewState,
} from '@/lib/video/service';

/** One video script: read it, mark it ready, or delete it. */
export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;

  try {
    const found = await getVideoScript({ db: getDatabase() }, auth.tenant, id);
    return ok(
      {
        data: {
          script: found.row.script,
          meta: {
            id: found.row.id,
            platform: found.row.platform,
            totalSeconds: found.row.totalSeconds,
            reviewState: found.row.reviewState,
          },
          problems: found.problems,
          images: found.images,
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const state = (body as Record<string, unknown>).reviewState;
  if (state !== 'draft' && state !== 'in_review' && state !== 'approved') {
    return fail(422, 'Unknown review state.', undefined, { headers: limit.headers });
  }

  try {
    const saved = await setVideoReviewState({ db: getDatabase() }, auth.tenant, id, state);
    return ok(
      { data: { reviewState: saved.row.reviewState, problems: saved.problems }, message: 'Updated.' },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof VideoInputError) {
      return fail(409, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}

export async function DELETE(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;

  try {
    await deleteVideoScript({ db: getDatabase() }, auth.tenant, id);
    return ok({ data: { removed: true }, message: 'Deleted.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
