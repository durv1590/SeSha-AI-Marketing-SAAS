import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { VideoInputError, listVideoScripts, saveVideoScript } from '@/lib/video/service';
import { imageGenerationStatus, type VideoScript } from '@/lib/video/types';

/**
 * Video scripts.
 *
 * `imageGenerationStatus()` travels in every response: no image-generation API is
 * connected, so thumbnail concepts are written briefs and nothing here is a
 * picture.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const projectId = new URL(request.url).searchParams.get('projectId') ?? '';
  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', { projectId: 'A projectId is required.' }, {
      headers: limit.headers,
    });
  }

  try {
    const scripts = await listVideoScripts({ db: getDatabase() }, auth.tenant, projectId);
    return ok(
      {
        data: {
          scripts: scripts.map((row) => ({
            id: row.id,
            platform: row.platform,
            topic: row.topic,
            totalSeconds: row.totalSeconds,
            reviewState: row.reviewState,
            problems: row.problems,
            createdAt: row.createdAt.toISOString(),
          })),
          images: imageGenerationStatus(),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  if (projectId.length === 0 || typeof input.script !== 'object' || input.script === null) {
    return fail(
      422,
      'Please check the form.',
      {
        ...(projectId.length === 0 ? { projectId: 'Choose a project first.' } : {}),
        ...(typeof input.script === 'object' && input.script !== null ? {} : { script: 'The script is missing.' }),
      },
      { headers: limit.headers },
    );
  }

  try {
    const saved = await saveVideoScript({ db: getDatabase() }, auth.tenant, {
      projectId,
      script: input.script as VideoScript,
      ...(input.reviewState === 'approved' || input.reviewState === 'in_review'
        ? { reviewState: input.reviewState }
        : {}),
    });
    return ok(
      {
        data: { id: saved.row.id, problems: saved.problems, images: saved.images },
        message: saved.problems.length > 0 ? 'Saved, with notes.' : 'Saved.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof VideoInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
