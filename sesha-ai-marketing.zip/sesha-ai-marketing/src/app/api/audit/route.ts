import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import {
  ConsentRequiredError,
  JobConflictError,
  getLatestAudit,
  requestJob,
  runJob,
  toJobView,
} from '@/lib/crawl/service';

/**
 * Run an SEO or AEO audit, or read the latest one.
 *
 * An audit reads the STORED crawl, so it needs no consent check of its own and
 * fetches nothing — which is also why it can be re-run cheaply after a fix.
 */
export const dynamic = 'force-dynamic';

function isKind(value: unknown): value is 'seo' | 'aeo' {
  return value === 'seo' || value === 'aeo';
}

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const params = new URL(request.url).searchParams;
  const projectId = params.get('projectId') ?? '';
  const kind = params.get('kind');

  const errors: Record<string, string> = {};
  if (projectId.length === 0) errors.projectId = 'A projectId is required.';
  if (!isKind(kind)) errors.kind = 'The kind must be "seo" or "aeo".';
  if (Object.keys(errors).length > 0 || !isKind(kind)) {
    return fail(422, 'Please check the request.', errors, { headers: limit.headers });
  }

  try {
    const audit = await getLatestAudit({ db: getDatabase() }, auth.tenant, projectId, kind);
    return ok({ data: audit }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  if (!isKind(input.kind) || projectId.length === 0) {
    return fail(
      422,
      'Please check the form.',
      {
        ...(projectId.length === 0 ? { projectId: 'Choose a project first.' } : {}),
        ...(isKind(input.kind) ? {} : { kind: 'The kind must be "seo" or "aeo".' }),
      },
      { headers: limit.headers },
    );
  }

  const context = { db: getDatabase() };
  const kind = input.kind === 'seo' ? 'seo_audit' : 'aeo_audit';

  try {
    const job = await requestJob(context, auth.tenant, { projectId, kind });

    void (async () => {
      const claimed = await context.db.jobs.claimNext(new Date(), [kind]);
      if (claimed) await runJob(context, claimed);
    })();

    return ok({ data: toJobView(job), message: 'Audit queued.' }, { headers: limit.headers });
  } catch (error) {
    if (error instanceof ConsentRequiredError || error instanceof JobConflictError) {
      return fail(409, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
