import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { NotificationInputError, preferenceView, updatePreferences } from '@/lib/notifications/service';
import { CHANNELS, CHANNEL_IDS, isNotificationKind, type PreferenceUpdate } from '@/lib/notifications/types';

/**
 * Notification preferences — the user's own, and only their own.
 *
 * Two things this endpoint refuses to do quietly:
 *  · it will not accept switching off a security or billing notice. It returns
 *    422 with the reason rather than accepting and ignoring, which would tell
 *    the user their setting had been saved when it had not;
 *  · it will not accept enabling email while no provider is connected. The
 *    channel is still LISTED, with the reason, rather than hidden.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const view = await preferenceView({ db: getDatabase() }, auth.tenant);
    return ok(
      {
        data: {
          preferences: view.map((entry) => ({
            kind: entry.preference.kind,
            label: entry.label,
            description: entry.description,
            inApp: entry.preference.inApp,
            email: entry.preference.email,
            locked: entry.lockedReason !== undefined,
            lockedReason: entry.lockedReason ?? null,
          })),
          channels: CHANNEL_IDS.map((id) => ({
            id,
            label: CHANNELS[id].label,
            available: CHANNELS[id].available,
            unavailableReason: CHANNELS[id].unavailableReason ?? null,
          })),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  if (!Array.isArray(input.preferences)) {
    return fail(422, 'Send a list of preferences.', undefined, { headers: limit.headers });
  }

  const updates: PreferenceUpdate[] = [];
  for (const raw of input.preferences as unknown[]) {
    if (typeof raw !== 'object' || raw === null) continue;
    const entry = raw as Record<string, unknown>;
    if (!isNotificationKind(entry.kind)) continue;
    updates.push({
      kind: entry.kind,
      ...(typeof entry.inApp === 'boolean' ? { inApp: entry.inApp } : {}),
      ...(typeof entry.email === 'boolean' ? { email: entry.email } : {}),
    });
  }

  try {
    const saved = await updatePreferences({ db: getDatabase() }, auth.tenant, updates);
    return ok({ data: { preferences: saved }, message: 'Saved.' }, { headers: limit.headers });
  } catch (error) {
    if (error instanceof NotificationInputError) {
      const errors: Record<string, string> = {};
      for (const problem of error.problems) errors[problem.kind] = problem.message;
      return fail(422, error.message, Object.keys(errors).length > 0 ? errors : undefined, {
        headers: limit.headers,
      });
    }
    return errorResponse(error);
  }
}
