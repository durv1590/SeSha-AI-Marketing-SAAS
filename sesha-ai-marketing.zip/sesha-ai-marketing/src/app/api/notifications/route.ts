import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { listForUser, markRead, unreadCount } from '@/lib/notifications/service';
import { NOTIFICATION_LABEL, isNotificationKind } from '@/lib/notifications/types';

/** The signed-in user's own notifications. Never anybody else's. */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const db = getDatabase();
    const rows = await listForUser({ db }, auth.tenant);
    const unread = await unreadCount({ db }, auth.tenant);

    return ok(
      {
        data: {
          unread,
          notifications: rows.map((row) => ({
            id: row.id,
            kind: row.kind,
            label: isNotificationKind(row.kind) ? NOTIFICATION_LABEL[row.kind] : row.kind,
            title: row.title,
            body: row.body,
            actionUrl: row.actionUrl,
            readAt: row.readAt?.toISOString() ?? null,
            createdAt: row.createdAt.toISOString(),
          })),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const id = typeof input.id === 'string' ? input.id : '';
  if (id.length === 0) {
    return fail(422, 'Which notification?', undefined, { headers: limit.headers });
  }

  try {
    await markRead({ db: getDatabase() }, auth.tenant, id);
    return ok({ data: { id }, message: 'Marked as read.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
