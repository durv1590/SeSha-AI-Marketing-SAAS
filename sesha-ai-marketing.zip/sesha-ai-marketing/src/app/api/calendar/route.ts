import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { CalendarInputError, calendarView, createEvent } from '@/lib/calendar/service';
import {
  EVENT_KINDS,
  EVENT_LABEL,
  ORIGIN_LABEL,
  STATUS_LABEL,
  isCalendarView,
  isEventKind,
} from '@/lib/calendar/types';

/**
 * The marketing calendar.
 *
 * SUGGESTIONS ARE RETURNED IN THEIR OWN FIELD, NEVER MIXED INTO `events`.
 * A suggestion rendered in the same list as real entries becomes, within a week,
 * something the user believes they planned. Keeping them apart in the response
 * means a client cannot merge them by accident.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const params = new URL(request.url).searchParams;
  const projectId = params.get('projectId') ?? '';
  const rawView = params.get('view');
  const anchor = params.get('date');

  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', { projectId: 'A projectId is required.' }, {
      headers: limit.headers,
    });
  }

  try {
    const result = await calendarView(
      { db: getDatabase() },
      auth.tenant,
      projectId,
      isCalendarView(rawView) ? rawView : 'monthly',
      anchor ?? undefined,
    );

    return ok(
      {
        data: {
          view: result.view,
          anchor: result.anchor,
          range: result.range,
          events: result.events,
          suggestions: result.suggestions,
          kinds: EVENT_KINDS.map((kind) => ({ id: kind, label: EVENT_LABEL[kind] })),
          statusLabels: STATUS_LABEL,
          originLabels: ORIGIN_LABEL,
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  const title = typeof input.title === 'string' ? input.title : '';
  const date = typeof input.date === 'string' ? input.date : '';

  const errors: Record<string, string> = {};
  if (projectId.length === 0) errors.projectId = 'Choose a project first.';
  if (title.trim().length === 0) errors.title = 'What is this entry?';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) errors.date = 'Pick a date.';
  if (!isEventKind(input.kind)) errors.kind = 'Choose what kind of activity this is.';
  if (Object.keys(errors).length > 0) {
    return fail(422, 'Please check the form.', errors, { headers: limit.headers });
  }

  try {
    const row = await createEvent({ db: getDatabase() }, auth.tenant, projectId, {
      kind: input.kind as (typeof EVENT_KINDS)[number],
      title,
      date,
      ...(typeof input.notes === 'string' ? { notes: input.notes } : {}),
      ...(typeof input.campaign === 'string' ? { campaign: input.campaign } : {}),
      ...(input.fromSuggestion === true ? { fromSuggestion: true } : {}),
    });

    return ok(
      {
        data: { id: row.id, origin: row.origin },
        message:
          row.origin === 'accepted_suggestion'
            ? 'Added, and recorded as a suggestion you accepted.'
            : 'Added. Nothing will be published on this date — SeSha cannot publish.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof CalendarInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
