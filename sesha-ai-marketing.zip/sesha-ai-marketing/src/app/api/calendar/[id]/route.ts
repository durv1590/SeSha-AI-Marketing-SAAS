import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { CalendarInputError, removeEvent, updateEvent } from '@/lib/calendar/service';

/** One calendar entry: change it, mark it done or skipped, or remove it. */
export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

const STATUSES = ['planned', 'done', 'skipped'] as const;

export async function PATCH(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const status = (STATUSES as readonly string[]).includes(String(input.status))
    ? (input.status as (typeof STATUSES)[number])
    : undefined;

  if (input.status !== undefined && status === undefined) {
    return fail(422, 'An entry is planned, done or skipped.', undefined, { headers: limit.headers });
  }

  try {
    const row = await updateEvent({ db: getDatabase() }, auth.tenant, id, {
      ...(typeof input.title === 'string' ? { title: input.title } : {}),
      ...(typeof input.notes === 'string' ? { notes: input.notes } : {}),
      ...(typeof input.date === 'string' ? { date: input.date } : {}),
      ...(status ? { status } : {}),
      ...(input.campaign === null || typeof input.campaign === 'string'
        ? { campaign: input.campaign as string | null }
        : {}),
    });
    return ok({ data: { id: row.id, status: row.status }, message: 'Saved.' }, { headers: limit.headers });
  } catch (error) {
    if (error instanceof CalendarInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}

export async function DELETE(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  try {
    await removeEvent({ db: getDatabase() }, auth.tenant, id);
    return ok({ data: { id }, message: 'Removed.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
