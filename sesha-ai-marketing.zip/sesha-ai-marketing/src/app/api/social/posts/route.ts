import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { createPost, listPosts, validatePost } from '@/lib/social/service';

/**
 * Social posts.
 *
 * There is no POST /publish, and there never will be until an official
 * platform API is connected. `status` accepts idea, draft, ready and archived
 * only; "published" and "scheduled" are rejected with a message that says why
 * rather than a generic validation error.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const projectId = new URL(request.url).searchParams.get('projectId') ?? '';
  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', undefined, { headers: limit.headers });
  }

  try {
    const posts = await listPosts({ db: getDatabase() }, auth.tenant, projectId);
    return ok({ data: posts }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  if (projectId.length === 0) {
    return fail(422, 'Please check the form.', { projectId: 'Choose a project first.' }, { headers: limit.headers });
  }

  const validated = validatePost(input);
  if (!validated.ok || !validated.draft) {
    return fail(422, 'Please check the form.', validated.errors, { headers: limit.headers });
  }

  try {
    const post = await createPost({ db: getDatabase() }, auth.tenant, projectId, validated.draft);
    return ok(
      { data: { post, issues: validated.issues }, message: 'Saved.' },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
