import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { SocialValidationError, deletePost, getPost, updatePost, validatePost } from '@/lib/social/service';

export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const { id } = await params;
    const post = await getPost({ db: getDatabase() }, auth.tenant, id);
    return ok({ data: post }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;

  try {
    const { id } = await params;
    const db = getDatabase();
    const existing = await getPost({ db }, auth.tenant, id);

    // Validate the MERGED post, not the patch alone: a caption that fits on its
    // own can still break the limit once the stored hashtags are counted.
    const validated = validatePost({
      platform: input.platform ?? existing.platform,
      format: input.format ?? existing.format,
      caption: input.caption ?? existing.caption,
      hashtags: input.hashtags ?? existing.hashtags,
      idea: input.idea ?? existing.idea,
      status: input.status ?? existing.status,
      plannedFor: input.plannedFor ?? existing.plannedFor,
    });

    if (!validated.ok || !validated.draft) {
      return fail(422, 'Please check the form.', validated.errors, { headers: limit.headers });
    }

    const post = await updatePost({ db }, auth.tenant, id, validated.draft);
    return ok({ data: { post, issues: validated.issues }, message: 'Saved.' }, { headers: limit.headers });
  } catch (error) {
    if (error instanceof SocialValidationError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}

export async function DELETE(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const { id } = await params;
    await deletePost({ db: getDatabase() }, auth.tenant, id);
    return ok({ message: 'Deleted.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
