import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { generatePost } from '@/lib/social/service';
import { PLATFORM_SPECS, isPlatform } from '@/lib/social/platforms';

export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'ai');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const errors: Record<string, string> = {};

  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  if (projectId.length === 0) errors.projectId = 'Choose a project first.';

  const platform = isPlatform(input.platform) ? input.platform : null;
  if (!platform) errors.platform = 'Choose a platform.';

  const format = typeof input.format === 'string' ? input.format : '';
  if (platform && !PLATFORM_SPECS[platform].formats.some((f) => f.id === format)) {
    errors.format = 'Choose a format this platform supports.';
  }

  const idea = typeof input.idea === 'string' ? input.idea.trim() : '';
  if (idea.length < 3) errors.idea = 'Describe what the post should be about.';

  if (!platform || Object.keys(errors).length > 0) {
    return fail(422, 'Please check the form.', errors, { headers: limit.headers });
  }

  try {
    const outcome = await generatePost({ db: getDatabase() }, auth.tenant, {
      projectId,
      platform,
      format,
      idea: idea.slice(0, 500),
      save: input.save !== false,
    });

    if (!outcome.result.ok) {
      return fail(outcome.result.code === 'rate_limited' ? 429 : 502, outcome.result.message, undefined, {
        headers: limit.headers,
      });
    }

    return ok(
      {
        data: {
          post: outcome.post,
          blocks: outcome.result.response.blocks,
          warnings: outcome.result.response.warnings,
          safe: outcome.result.response.safe,
          issues: outcome.issues,
          // Repeated on every generation so no interface can forget it.
          publishing: {
            canPublish: false,
            reason: PLATFORM_SPECS[platform].publishBlockedReason,
          },
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
