import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { calendar } from '@/lib/social/service';

/**
 * The planning calendar.
 *
 * A planned date is a note to a human, not a scheduled job. Nothing in this
 * application acts on these dates, and the response says so explicitly so that
 * no client can present the calendar as a publishing queue.
 */
export const dynamic = 'force-dynamic';

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const params = new URL(request.url).searchParams;
  const projectId = params.get('projectId') ?? '';
  const from = params.get('from') ?? '';
  const to = params.get('to') ?? '';

  const errors: Record<string, string> = {};
  if (projectId.length === 0) errors.projectId = 'A projectId is required.';
  if (!ISO_DATE.test(from)) errors.from = 'Use YYYY-MM-DD.';
  if (!ISO_DATE.test(to)) errors.to = 'Use YYYY-MM-DD.';
  if (Object.keys(errors).length === 0 && from > to) errors.to = 'The end date is before the start date.';

  if (Object.keys(errors).length > 0) {
    return fail(422, 'Please check the request.', errors, { headers: limit.headers });
  }

  try {
    const entries = await calendar({ db: getDatabase() }, auth.tenant, projectId, from, to);
    return ok(
      { data: { entries, scheduling: { enabled: false, reason: 'No platform API is connected, so nothing is published automatically.' } } },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
