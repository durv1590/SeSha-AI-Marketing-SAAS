import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { requestMeta, serviceContext } from '@/lib/auth/current-session';
import { requestPasswordReset } from '@/lib/auth/service';
import { sendPasswordResetEmail } from '@/lib/email';
import { sanitizeText } from '@/lib/security/sanitize';

/**
 * Password reset request.
 *
 * ALWAYS returns the same success response, whether or not the address has an
 * account. This is not politeness — a reset form that says "no such account" is
 * a public account-enumeration API.
 */

export const dynamic = 'force-dynamic';

const SAME_RESPONSE = 'If that address has an account, a reset link is on its way.';

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'passwordReset');
  if (!limit.allowed) return limit.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const email = sanitizeText((body as Record<string, unknown>).email, 254).toLowerCase();

  const issued = await requestPasswordReset(serviceContext(), email, await requestMeta());
  if (issued) await sendPasswordResetEmail(email, issued.token);

  return ok({ message: SAME_RESPONSE }, { headers: limit.headers });
}
