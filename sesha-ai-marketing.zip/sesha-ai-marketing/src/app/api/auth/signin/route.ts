import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { establishSession, requestMeta, serviceContext } from '@/lib/auth/current-session';
import { signIn } from '@/lib/auth/service';
import { sanitizeText } from '@/lib/security/sanitize';

export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'signin');
  if (!limit.allowed) return limit.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const email = sanitizeText(input.email, 254).toLowerCase();
  const password = typeof input.password === 'string' ? input.password : '';

  const result = await signIn(serviceContext(), { email, password }, await requestMeta());

  if (!result.ok) {
    if (result.reason === 'locked') {
      return fail(429, 'Too many attempts. Please wait before trying again.', undefined, {
        headers: { ...limit.headers, 'Retry-After': String(result.retryAfterSeconds ?? 60) },
      });
    }
    // One message for every credential failure — never "no such user".
    return fail(401, 'Email or password is incorrect.', undefined, { headers: limit.headers });
  }

  await establishSession(result.token, result.session.id);

  return ok(
    {
      message: 'Signed in.',
      data: {
        emailVerified: result.user.emailVerifiedAt !== null,
        onboardingComplete: result.user.onboardingCompletedAt !== null,
      },
    },
    { headers: limit.headers },
  );
}
