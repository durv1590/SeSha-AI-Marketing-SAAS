import { enforceRateLimit, ok } from '@/lib/api/respond';
import { getCurrentSession } from '@/lib/auth/current-session';
import { permissionsFor } from '@/lib/auth/rbac';

/**
 * Current session, for the client shell.
 *
 * Returns only what the UI needs to render. No token, no password hash, no
 * internal ids beyond the organization the user is already in.
 */

export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  // Phase 9: every session lookup is a database read, so it is rate limited
  // like any other read (it was the one unthrottled authenticated endpoint).
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const session = await getCurrentSession();
  if (!session) return ok({ data: { authenticated: false } }, { headers: limit.headers });

  return ok({
    data: {
      authenticated: true,
      user: {
        id: session.user.id,
        email: session.user.email,
        name: session.user.name,
        emailVerified: session.user.emailVerifiedAt !== null,
        onboardingComplete: session.user.onboardingCompletedAt !== null,
      },
      organizationId: session.user.organizationId,
      role: session.user.role,
      permissions: permissionsFor(session.user.role),
    },
  }, { headers: limit.headers });
}
