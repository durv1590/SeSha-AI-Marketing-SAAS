import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { serviceContext } from '@/lib/auth/current-session';
import { resendVerification } from '@/lib/auth/service';
import { sendVerificationEmail } from '@/lib/email';
import { sanitizeText } from '@/lib/security/sanitize';

export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'verifyEmail');
  if (!limit.allowed) return limit.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const email = sanitizeText((body as Record<string, unknown>).email, 254).toLowerCase();
  const issued = await resendVerification(serviceContext(), email);
  if (issued) await sendVerificationEmail(email, issued.token);

  // Same response either way.
  return ok({ message: 'If that address needs confirming, a new link is on its way.' }, {
    headers: limit.headers,
  });
}
