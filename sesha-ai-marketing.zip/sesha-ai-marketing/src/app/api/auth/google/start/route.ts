import { cookies } from 'next/headers';

import { enforceRateLimit, fail } from '@/lib/api/respond';
import { isProduction } from '@/lib/auth/current-session';
import { buildAuthorizationUrl, readGoogleConfig } from '@/lib/auth/oauth/google';

/**
 * Begins Google sign-in.
 *
 * The state, nonce and PKCE verifier are stored in a SHORT-LIVED, httpOnly,
 * SameSite=Lax cookie. httpOnly matters: if script could read the verifier, an
 * XSS would be able to complete the flow. Lax rather than Strict because the
 * callback arrives as a top-level navigation from Google.
 */

export const dynamic = 'force-dynamic';

export const OAUTH_STATE_COOKIE = 'sesha_oauth';
/** Ten minutes: long enough to pick an account, short enough to limit replay. */
const STATE_TTL_SECONDS = 600;

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'oauth');
  if (!limit.allowed) return limit.response;

  const config = readGoogleConfig();
  if (!config) {
    return fail(
      501,
      'Google sign-in is not configured on this deployment.',
      undefined,
      { headers: limit.headers },
    );
  }

  const authorization = buildAuthorizationUrl(config);

  const store = await cookies();
  store.set(
    OAUTH_STATE_COOKIE,
    JSON.stringify({
      state: authorization.state,
      nonce: authorization.nonce,
      codeVerifier: authorization.codeVerifier,
    }),
    {
      httpOnly: true,
      secure: isProduction,
      sameSite: 'lax',
      path: '/api/auth/google',
      maxAge: STATE_TTL_SECONDS,
    },
  );

  return Response.redirect(authorization.url, 302);
}
