import { cookies } from 'next/headers';

import { enforceRateLimit } from '@/lib/api/respond';
import { establishSession, isProduction, requestMeta, serviceContext } from '@/lib/auth/current-session';
import {
  exchangeCode,
  fetchGoogleJwks,
  readGoogleConfig,
  statesMatch,
  toIdentity,
  verifyIdToken,
} from '@/lib/auth/oauth/google';
import { signInWithOAuth } from '@/lib/auth/service';
import { site } from '@/content/site';
import { OAUTH_STATE_COOKIE } from '../start/route';

/**
 * Google sign-in callback.
 *
 * Every check from the module docblock runs here, in order, and the flow stops
 * at the first failure:
 *   state -> code exchange with PKCE verifier -> ID token signature -> claims
 *   (issuer, audience, expiry, nonce) -> email_verified -> session.
 *
 * Failures redirect to the sign-in page with a COARSE error code. The specific
 * reason is audited server-side but never shown in the URL, which would tell an
 * attacker exactly which check to defeat next.
 */

export const dynamic = 'force-dynamic';

function baseUrl(): string {
  return (process.env.NEXT_PUBLIC_SITE_URL ?? site.url).replace(/\/+$/, '');
}

function redirectWithError(code: string): Response {
  return Response.redirect(`${baseUrl()}/sign-in?error=${encodeURIComponent(code)}`, 302);
}

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'oauth');
  if (!limit.allowed) return limit.response;

  const config = readGoogleConfig();
  if (!config) return redirectWithError('google_unavailable');

  const url = new URL(request.url);
  const store = await cookies();

  // Always clear the one-shot state cookie, whatever happens next.
  const stored = store.get(OAUTH_STATE_COOKIE)?.value;
  store.set(OAUTH_STATE_COOKIE, '', {
    httpOnly: true,
    secure: isProduction,
    sameSite: 'lax',
    path: '/api/auth/google',
    maxAge: 0,
  });

  // The user declined, or Google returned an error.
  if (url.searchParams.get('error')) return redirectWithError('cancelled');

  const code = url.searchParams.get('code');
  const returnedState = url.searchParams.get('state');
  if (!code || !returnedState || !stored) return redirectWithError('invalid_request');

  let expected: { state: string; nonce: string; codeVerifier: string };
  try {
    expected = JSON.parse(stored) as typeof expected;
  } catch {
    return redirectWithError('invalid_request');
  }

  // 1. State — blocks login CSRF.
  if (!statesMatch(returnedState, expected.state)) return redirectWithError('invalid_request');

  // 2. Exchange, presenting the PKCE verifier.
  const exchanged = await exchangeCode(config, code, expected.codeVerifier);
  if (!exchanged.ok) return redirectWithError('exchange_failed');

  // 3 + 4. Signature and claims, including the nonce.
  let jwks = await fetchGoogleJwks();
  let verified = verifyIdToken(exchanged.tokens.id_token, jwks, {
    clientId: config.clientId,
    nonce: expected.nonce,
  });

  // An unknown key id usually means Google rotated keys — refetch once.
  if (!verified.ok && verified.error === 'unknown_key') {
    jwks = await fetchGoogleJwks(true);
    verified = verifyIdToken(exchanged.tokens.id_token, jwks, {
      clientId: config.clientId,
      nonce: expected.nonce,
    });
  }

  if (!verified.ok) return redirectWithError('verification_failed');

  // 5. email_verified is enforced inside signInWithOAuth.
  const result = await signInWithOAuth(
    serviceContext(),
    toIdentity(verified.claims),
    await requestMeta(),
  );

  if (!result.ok) {
    return redirectWithError(
      result.reason === 'email-taken' ? 'account_exists_use_password' : 'email_unverified',
    );
  }

  const session = await serviceContext().db.sessions.findByTokenHash(
    (await import('@/lib/auth/tokens')).hashToken(result.token),
  );
  if (session) await establishSession(result.token, session.id);

  return Response.redirect(`${baseUrl()}${result.created ? '/onboarding' : '/app'}`, 302);
}
