import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { establishSession, requestMeta, serviceContext } from '@/lib/auth/current-session';
import { verifyEmail } from '@/lib/auth/service';
import { sanitizeText } from '@/lib/security/sanitize';

export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'verifyEmail');
  if (!limit.allowed) return limit.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const token = sanitizeText((body as Record<string, unknown>).token, 256);
  const context = serviceContext();
  const result = await verifyEmail(context, token, await requestMeta());

  if (!result.ok) {
    return fail(400, 'That confirmation link is invalid or has expired.', undefined, {
      headers: limit.headers,
    });
  }

  // Verification rotated the session; hand the browser the new token.
  const session = await context.db.sessions.findByTokenHash(
    (await import('@/lib/auth/tokens')).hashToken(result.token),
  );
  if (session) await establishSession(result.token, session.id);

  return ok({ message: 'Your email address is confirmed.' }, { headers: limit.headers });
}
