import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { establishSession, requestMeta, serviceContext } from '@/lib/auth/current-session';
import { signIn, signUp } from '@/lib/auth/service';
import { sendVerificationEmail, sendDuplicateSignupEmail } from '@/lib/email';
import { isProbablyEmail, sanitizeText } from '@/lib/security/sanitize';

/**
 * Registration.
 *
 * THE RESPONSE IS IDENTICAL whether or not the address is already registered.
 * `signUp` returns the same shape either way; the only difference is which
 * email is sent. Varying the HTTP response here would undo that and turn this
 * endpoint into an account-enumeration oracle.
 */

export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'signup');
  if (!limit.allowed) return limit.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const email = sanitizeText(input.email, 254).toLowerCase();
  const password = typeof input.password === 'string' ? input.password : '';
  const name = sanitizeText(input.name, 120) || null;

  if (!isProbablyEmail(email)) {
    return fail(422, 'Please check your details.', { email: 'Enter a valid email address.' }, {
      headers: limit.headers,
    });
  }

  const context = serviceContext();
  const meta = await requestMeta();

  const result = await signUp(
    context,
    { email, password, name, organizationName: sanitizeText(input.organizationName, 160) || null },
    meta,
  );

  if (!result.ok) {
    return fail(422, result.problems[0] ?? 'Please choose a stronger password.', {
      password: result.problems.join(' '),
    }, { headers: limit.headers });
  }

  if (result.verificationToken && result.userId) {
    await sendVerificationEmail(email, result.verificationToken);
    // Sign the new user straight in so onboarding can begin; the email is
    // still unverified, and the UI gates on that.
    const signedIn = await signIn(context, { email, password }, meta);
    if (signedIn.ok) {
      await establishSession(signedIn.token, signedIn.session.id);
    }
  } else {
    // The address already has an account. Tell its owner, not the caller.
    await sendDuplicateSignupEmail(email);
  }

  return ok(
    { message: 'Check your email to confirm your address.' },
    { headers: limit.headers },
  );
}
