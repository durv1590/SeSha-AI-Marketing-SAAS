import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { clearSessionCookies, requestMeta, serviceContext } from '@/lib/auth/current-session';
import { resetPassword } from '@/lib/auth/service';
import { sanitizeText } from '@/lib/security/sanitize';

export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'passwordReset');
  if (!limit.allowed) return limit.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const token = sanitizeText(input.token, 256);
  const password = typeof input.password === 'string' ? input.password : '';

  const result = await resetPassword(serviceContext(), token, password, await requestMeta());

  if (!result.ok) {
    if (result.reason === 'weak-password') {
      return fail(422, 'Please choose a stronger password.', {
        password: (result.problems ?? []).join(' '),
      }, { headers: limit.headers });
    }
    return fail(400, 'That reset link is invalid or has expired. Request a new one.', undefined, {
      headers: limit.headers,
    });
  }

  // Every session was revoked, including this browser's. Clear the cookies so
  // the user is not left holding a dead token.
  await clearSessionCookies();
  return ok({ message: 'Password updated. Sign in with your new password.' }, { headers: limit.headers });
}
