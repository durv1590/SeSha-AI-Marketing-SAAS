import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, ok } from '@/lib/api/respond';
import { clearSessionCookies, requestMeta, serviceContext } from '@/lib/auth/current-session';
import { signOut } from '@/lib/auth/service';

export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  // Signing out is a mutation, and it was the one mutating route with no limit.
  // The risk is small but real: an unauthenticated flood still costs a session
  // lookup per request, and "small but real" is not a category this codebase
  // keeps.
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    await signOut(serviceContext(), auth.session.session.id, await requestMeta());
    await clearSessionCookies();
    return ok({ message: 'Signed out.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
