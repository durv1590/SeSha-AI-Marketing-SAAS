import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { exportReport } from '@/lib/reports/service';
import { EXPORT_MIME, exportFilename, isExportFormat } from '@/lib/reports/export';

/**
 * Downloading a report as PDF, CSV or JSON.
 *
 * Returns the FILE, not a JSON envelope, so a browser can save it directly.
 *
 * `Content-Disposition` uses a slug derived from the report title. The slug is
 * built by stripping everything but letters, digits and hyphens, which is what
 * keeps a title containing a quote or a newline from breaking out of the header.
 */
export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  const format = new URL(request.url).searchParams.get('format') ?? 'pdf';

  if (!isExportFormat(format)) {
    return fail(422, 'A report exports as pdf, csv or json.', undefined, { headers: limit.headers });
  }

  try {
    const exported = await exportReport({ db: getDatabase() }, auth.tenant, id, format);
    const filename = exportFilename(exported.report, format);

    const body: BodyInit =
      exported.body instanceof Uint8Array
        ? new Uint8Array(exported.body) // a fresh view, so the buffer is not shared
        : exported.body;

    return new Response(body, {
      status: 200,
      headers: {
        ...Object.fromEntries(limit.headers ? Object.entries(limit.headers) : []),
        'Content-Type': EXPORT_MIME[format],
        'Content-Disposition': `attachment; filename="${filename}"`,
        // A report is tenant data. It must never be held by a shared cache.
        'Cache-Control': 'private, no-store',
        'X-Content-Type-Options': 'nosniff',
      },
    });
  } catch (error) {
    return errorResponse(error);
  }
}
