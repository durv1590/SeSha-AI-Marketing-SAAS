import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { findReport, listShares, revokeShare, shareReport, toReport } from '@/lib/reports/service';
import { DEFAULT_SHARE_DAYS, MAX_SHARE_DAYS } from '@/lib/reports/share';

/**
 * One report: read it, or share it.
 *
 * THE SHARE TOKEN IS RETURNED EXACTLY ONCE.
 * Only its hash is stored, so it cannot be shown again. The response says so,
 * because a link the user assumes they can find later is a link they will
 * recreate — leaving a second live door open behind them.
 */
export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  try {
    const db = getDatabase();
    const row = await findReport({ db }, auth.tenant, id);
    const shares = await listShares({ db }, auth.tenant, id);

    return ok(
      {
        data: {
          report: toReport(row),
          shares: shares.map((share) => ({
            id: share.id,
            createdAt: share.createdAt.toISOString(),
            expiresAt: share.expiresAt.toISOString(),
            revokedAt: share.revokedAt?.toISOString() ?? null,
            lastViewedAt: share.lastViewedAt?.toISOString() ?? null,
            viewCount: share.viewCount,
            // Never the token, and never the hash: neither belongs in a response.
          })),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  const body = await readJson(request);
  const input = (body ?? {}) as Record<string, unknown>;

  try {
    const db = getDatabase();

    if (typeof input.revokeShareId === 'string') {
      const revoked = await revokeShare({ db }, auth.tenant, input.revokeShareId);
      return ok(
        {
          data: { id: revoked.id, revokedAt: revoked.revokedAt?.toISOString() ?? null },
          message: 'Revoked. The link stopped working immediately.',
        },
        { headers: limit.headers },
      );
    }

    const requested = typeof input.days === 'number' ? input.days : DEFAULT_SHARE_DAYS;
    if (requested > MAX_SHARE_DAYS) {
      return fail(
        422,
        `A share link lasts at most ${MAX_SHARE_DAYS} days. A link with no end outlives whoever created it.`,
        undefined,
        { headers: limit.headers },
      );
    }

    const created = await shareReport({ db }, auth.tenant, id, requested);
    return ok(
      {
        data: {
          shareId: created.share.id,
          path: created.path,
          expiresAt: created.share.expiresAt.toISOString(),
        },
        message:
          'Copy this link now — it is shown once and cannot be shown again. Anyone with it can read this report until it expires or you revoke it.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
