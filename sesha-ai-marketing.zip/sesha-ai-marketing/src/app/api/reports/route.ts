import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { ReportInputError, generate, listReports, toReport } from '@/lib/reports/service';
import {
  REPORT_KINDS,
  REPORT_LABEL,
  REPORT_PURPOSE,
  SECTION_IDS,
  SECTION_QUESTION,
  isReportKind,
  pointCount,
} from '@/lib/reports/types';
import { EXPORT_FORMATS } from '@/lib/reports/export';

/** Reports: list what has been generated, or generate one. */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const projectId = new URL(request.url).searchParams.get('projectId') ?? '';
  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', { projectId: 'A projectId is required.' }, {
      headers: limit.headers,
    });
  }

  try {
    const rows = await listReports({ db: getDatabase() }, auth.tenant, projectId);
    return ok(
      {
        data: {
          reports: rows.map((row) => ({
            id: row.id,
            kind: row.kind,
            title: row.title,
            period: { from: row.periodFrom, to: row.periodTo, label: row.periodLabel },
            connectedSources: row.connectedSources,
            generatedAt: row.generatedAt.toISOString(),
            points: pointCount(toReport(row)),
          })),
          kinds: REPORT_KINDS.map((kind) => ({
            id: kind,
            label: REPORT_LABEL[kind],
            purpose: REPORT_PURPOSE[kind],
          })),
          sections: SECTION_IDS.map((id) => ({ id, question: SECTION_QUESTION[id] })),
          formats: EXPORT_FORMATS,
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';

  const errors: Record<string, string> = {};
  if (projectId.length === 0) errors.projectId = 'Choose a project first.';
  if (!isReportKind(input.kind)) errors.kind = 'Choose which report to produce.';
  if (Object.keys(errors).length > 0) {
    return fail(422, 'Please check the form.', errors, { headers: limit.headers });
  }

  try {
    const row = await generate(
      { db: getDatabase() },
      auth.tenant,
      projectId,
      input.kind as (typeof REPORT_KINDS)[number],
    );
    const report = toReport(row);

    return ok(
      {
        data: {
          id: row.id,
          title: row.title,
          anyConnected: report.provenance.anyConnected,
          measured: report.metrics.filter((metric) => metric.value.kind !== 'unavailable').length,
          total: report.metrics.length,
        },
        message: report.provenance.anyConnected
          ? 'Generated.'
          : 'Generated. Nothing is connected, so the figures that need a connected account are marked unavailable rather than estimated.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof ReportInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
