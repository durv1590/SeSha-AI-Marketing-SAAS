import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import {
  CompetitorInputError,
  addCompetitor,
  listCompetitors,
} from '@/lib/competitors/service';
import {
  COMPETITOR_ACKNOWLEDGEMENT,
  COMPETITOR_FETCH_POLICY,
} from '@/lib/competitors/analyze';

/**
 * The project's competitor list.
 *
 * The GET response carries the research policy and the exact acknowledgement
 * wording, so the interface shows the user what they are agreeing to before they
 * agree to it rather than after.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const projectId = new URL(request.url).searchParams.get('projectId') ?? '';
  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', { projectId: 'A projectId is required.' }, {
      headers: limit.headers,
    });
  }

  try {
    const context = { db: getDatabase() };
    const competitors = await listCompetitors(context, auth.tenant, projectId);

    const withState = await Promise.all(
      competitors.map(async (competitor) => {
        const acknowledgement = await context.db.competitorAcknowledgements.findLive(
          auth.tenant.organizationId,
          competitor.id,
        );
        const latest = await context.db.competitorAnalyses.findLatest(
          auth.tenant.organizationId,
          competitor.id,
        );
        return {
          id: competitor.id,
          name: competitor.name,
          websiteUrl: competitor.websiteUrl,
          source: competitor.source,
          notes: competitor.notes,
          acknowledged: acknowledgement !== null,
          lastAnalysedAt: latest?.analysedAt.toISOString() ?? null,
          verifiedCount: latest?.verifiedCount ?? 0,
          inferredCount: latest?.inferredCount ?? 0,
        };
      }),
    );

    return ok(
      {
        data: {
          competitors: withState,
          policy: {
            maxPages: COMPETITOR_FETCH_POLICY.maxPages,
            storesPageContent: COMPETITOR_FETCH_POLICY.storesPageContent,
            acknowledgement: COMPETITOR_ACKNOWLEDGEMENT,
          },
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  const name = typeof input.name === 'string' ? input.name : '';

  const errors: Record<string, string> = {};
  if (projectId.length === 0) errors.projectId = 'Choose a project first.';
  if (name.trim().length === 0) errors.name = 'Who is the competitor?';
  if (Object.keys(errors).length > 0) {
    return fail(422, 'Please check the form.', errors, { headers: limit.headers });
  }

  try {
    const competitor = await addCompetitor({ db: getDatabase() }, auth.tenant, {
      projectId,
      name,
      ...(typeof input.websiteUrl === 'string' ? { websiteUrl: input.websiteUrl } : {}),
      ...(typeof input.notes === 'string' ? { notes: input.notes } : {}),
    });
    return ok({ data: { id: competitor.id }, message: 'Added.' }, { headers: limit.headers });
  } catch (error) {
    if (error instanceof CompetitorInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
