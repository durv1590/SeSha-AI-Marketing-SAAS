import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import {
  AcknowledgementRequiredError,
  CompetitorInputError,
  acknowledgeResearch,
  analyseCompetitor,
  latestAnalysis,
  removeCompetitor,
  withdrawAcknowledgement,
} from '@/lib/competitors/service';

/**
 * One competitor: read the latest analysis, acknowledge or withdraw, analyse,
 * or remove.
 *
 * PATCH takes an ACTION rather than a field patch, for the same reason the jobs
 * route does: "acknowledge" and "analyse" are transitions with rules attached,
 * not properties a client may set. In particular, `analyse` cannot run without a
 * live acknowledgement, and that is checked again inside the service immediately
 * before the first request.
 */
export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

type Action = 'acknowledge' | 'withdraw' | 'analyse';

function isAction(value: unknown): value is Action {
  return value === 'acknowledge' || value === 'withdraw' || value === 'analyse';
}

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;

  try {
    const analysis = await latestAnalysis({ db: getDatabase() }, auth.tenant, id);
    return ok(
      {
        data: analysis
          ? {
              id: analysis.id,
              analysedAt: analysis.analysedAt.toISOString(),
              findings: analysis.findings,
              pagesRead: analysis.pagesRead,
              limitations: analysis.limitations,
              notCovered: analysis.notCovered,
              verifiedCount: analysis.verifiedCount,
              inferredCount: analysis.inferredCount,
            }
          : null,
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  if (!isAction(input.action)) {
    return fail(422, 'Say what to do.', { action: 'Unknown action.' }, { headers: limit.headers });
  }

  const context = { db: getDatabase() };

  try {
    if (input.action === 'acknowledge') {
      await acknowledgeResearch(context, auth.tenant, id, input.accepted === true);
      return ok({ data: { acknowledged: true }, message: 'Recorded.' }, { headers: limit.headers });
    }
    if (input.action === 'withdraw') {
      await withdrawAcknowledgement(context, auth.tenant, id);
      return ok(
        {
          data: { acknowledged: false },
          message: 'Withdrawn. No further pages will be read; past analyses are kept.',
        },
        { headers: limit.headers },
      );
    }

    const outcome = await analyseCompetitor(context, auth.tenant, id);
    return ok(
      {
        data: {
          id: outcome.stored.id,
          analysis: outcome.analysis,
        },
        message: `Read ${outcome.analysis.pagesRead.length} page(s).`,
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof AcknowledgementRequiredError) {
      return fail(409, error.message, undefined, { headers: limit.headers });
    }
    if (error instanceof CompetitorInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}

export async function DELETE(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;

  try {
    await removeCompetitor({ db: getDatabase() }, auth.tenant, id);
    return ok({ data: { removed: true }, message: 'Removed.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
