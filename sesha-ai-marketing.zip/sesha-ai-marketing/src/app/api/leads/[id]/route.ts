import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import {
  LeadInputError,
  StageTransitionError,
  deleteLead,
  getLead,
  moveStage,
  nextFollowUp,
} from '@/lib/leads/service';
import { isLeadStage } from '@/lib/leads/types';

/**
 * One lead: read it with its history and score, move it, or delete it.
 *
 * A stage move is a PATCH with a `stage`, and an illegal move is a 409 with the
 * written reason rather than a silent no-op — so "New straight to Won" tells the
 * user why the pipeline will not do that.
 */
export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;

  try {
    const context = { db: getDatabase() };
    const found = await getLead(context, auth.tenant, id);
    const suggestion = await nextFollowUp(context, auth.tenant, id);
    return ok(
      {
        data: {
          lead: {
            id: found.lead.id,
            name: found.lead.name,
            email: found.lead.email,
            phone: found.lead.phone,
            company: found.lead.company,
            enquiry: found.lead.enquiry,
            source: found.lead.source,
            stage: found.lead.stage,
            optInBasis: found.lead.optInBasis,
            lostReason: found.lead.lostReason,
            createdAt: found.lead.createdAt.toISOString(),
          },
          score: found.score,
          activities: found.activities.map((activity) => ({
            id: activity.id,
            kind: activity.kind,
            note: activity.note,
            occurredAt: activity.occurredAt.toISOString(),
            dueAt: activity.dueAt?.toISOString() ?? null,
            completedAt: activity.completedAt?.toISOString() ?? null,
            fromStage: activity.fromStage,
            toStage: activity.toStage,
          })),
          suggestedFollowUp: { dueAt: suggestion.dueAt.toISOString(), why: suggestion.why },
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  if (!isLeadStage(input.stage)) {
    return fail(422, 'Which stage?', { stage: 'Unknown stage.' }, { headers: limit.headers });
  }

  try {
    const moved = await moveStage({ db: getDatabase() }, auth.tenant, id, input.stage, {
      ...(typeof input.lostReason === 'string' ? { lostReason: input.lostReason } : {}),
      ...(typeof input.note === 'string' ? { note: input.note } : {}),
    });
    return ok(
      { data: { stage: moved.lead.stage, score: moved.score }, message: 'Moved.' },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof StageTransitionError) {
      return fail(409, error.message, undefined, { headers: limit.headers });
    }
    if (error instanceof LeadInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}

export async function DELETE(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;

  try {
    await deleteLead({ db: getDatabase() }, auth.tenant, id);
    return ok({ data: { removed: true }, message: 'Deleted.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
