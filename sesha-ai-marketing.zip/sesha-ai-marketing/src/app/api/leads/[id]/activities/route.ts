import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { LeadInputError, completeFollowUp, logActivity } from '@/lib/leads/service';
import { MANUAL_SEND_KINDS, isActivityKind } from '@/lib/leads/types';

/**
 * Log an activity against a lead, or complete a follow-up.
 *
 * An "email sent" or "WhatsApp sent" activity is a PERSON'S RECORD that they sent
 * something. SeSha does not send email or WhatsApp, so the response says so
 * explicitly when one of those kinds is logged — otherwise a user could reasonably
 * read the entry as something the product did.
 */
export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export async function POST(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const { id } = await params;
  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const context = { db: getDatabase() };

  try {
    if (input.action === 'complete' && typeof input.activityId === 'string') {
      const completed = await completeFollowUp(context, auth.tenant, input.activityId);
      return ok({ data: { id: completed.id }, message: 'Done.' }, { headers: limit.headers });
    }

    if (!isActivityKind(input.kind)) {
      return fail(422, 'What kind of activity?', { kind: 'Unknown activity kind.' }, {
        headers: limit.headers,
      });
    }

    const dueAt =
      typeof input.dueAt === 'string' && input.dueAt.length > 0 ? new Date(input.dueAt) : undefined;
    if (dueAt && Number.isNaN(dueAt.getTime())) {
      return fail(422, 'That date could not be read.', { dueAt: 'Use an ISO date.' }, {
        headers: limit.headers,
      });
    }

    const logged = await logActivity(context, auth.tenant, {
      leadId: id,
      kind: input.kind,
      ...(typeof input.note === 'string' ? { note: input.note } : {}),
      ...(dueAt ? { dueAt } : {}),
    });

    return ok(
      {
        data: { id: logged.activity.id, score: logged.score },
        message: MANUAL_SEND_KINDS.includes(input.kind)
          ? 'Logged. SeSha did not send anything — this records what you did.'
          : 'Logged.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof LeadInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
