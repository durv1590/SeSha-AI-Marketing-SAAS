import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import {
  DuplicateLeadError,
  LeadInputError,
  createLead,
  listLeads,
} from '@/lib/leads/service';
import { SCORE_BASIS, isLeadSource, isLeadStage } from '@/lib/leads/types';

/**
 * The lead pipeline.
 *
 * Two things in the response worth noting:
 *  · the stage counts cover the WHOLE pipeline even when the list is filtered, so
 *    a funnel does not change shape when you narrow the view;
 *  · `scoreBasis` travels with every score. A number with no rubric is the opaque
 *    score this product exists not to show.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const params = new URL(request.url).searchParams;
  const projectId = params.get('projectId') ?? '';
  const stage = params.get('stage');

  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', { projectId: 'A projectId is required.' }, {
      headers: limit.headers,
    });
  }

  try {
    const outcome = await listLeads(
      { db: getDatabase() },
      auth.tenant,
      projectId,
      isLeadStage(stage) ? { stage } : undefined,
    );
    return ok(
      {
        data: {
          leads: outcome.leads.map((lead) => ({
            id: lead.id,
            name: lead.name,
            email: lead.email,
            phone: lead.phone,
            company: lead.company,
            source: lead.source,
            stage: lead.stage,
            score: lead.score,
            scoreBasis: lead.scoreBasis,
            lastActivityAt: lead.lastActivityAt?.toISOString() ?? null,
            createdAt: lead.createdAt.toISOString(),
          })),
          counts: outcome.counts,
          scoreBasis: SCORE_BASIS,
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  const name = typeof input.name === 'string' ? input.name : '';

  const errors: Record<string, string> = {};
  if (projectId.length === 0) errors.projectId = 'Choose a project first.';
  if (name.trim().length === 0) errors.name = 'Who is this?';
  if (Object.keys(errors).length > 0) {
    return fail(422, 'Please check the form.', errors, { headers: limit.headers });
  }

  try {
    const created = await createLead({ db: getDatabase() }, auth.tenant, {
      projectId,
      name,
      ...(typeof input.email === 'string' ? { email: input.email } : {}),
      ...(typeof input.phone === 'string' ? { phone: input.phone } : {}),
      ...(typeof input.company === 'string' ? { company: input.company } : {}),
      ...(typeof input.enquiry === 'string' ? { enquiry: input.enquiry } : {}),
      ...(isLeadSource(input.source) ? { source: input.source } : {}),
      ...(input.allowDuplicate === true ? { allowDuplicate: true } : {}),
    });
    return ok(
      {
        data: { id: created.lead.id, score: created.score },
        message: 'Added.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof DuplicateLeadError) {
      // 409, with the existing id, so the interface can offer to open it rather
      // than silently merging two enquiries into one.
      return fail(409, error.message, { existingId: error.existingId }, { headers: limit.headers });
    }
    if (error instanceof LeadInputError) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
