import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { entitlementFor } from '@/lib/plans/service';
import { dashboard } from '@/lib/usage/service';
import { LIMITS, PLAN_DEFINITIONS, formatLimit } from '@/content/plans';
import { billingStatus } from '@/lib/billing/types';

/**
 * The usage dashboard.
 *
 * Every limit carries its SOURCE — the plan, or an admin override with the
 * reason it was granted. A customer whose screen disagrees with the pricing page
 * is entitled to know why, and support looking at a strange quota needs to see
 * who granted it.
 *
 * `formatted` is provided so a client cannot accidentally render `null` (which
 * means unlimited) as zero.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  try {
    const db = getDatabase();
    const entitlement = await entitlementFor({ db }, auth.tenant.organizationId);
    const view = await dashboard(
      { db },
      auth.tenant.organizationId,
      entitlement.plan,
      entitlement.limits,
    );

    return ok(
      {
        data: {
          plan: {
            id: entitlement.plan,
            name: PLAN_DEFINITIONS[entitlement.plan].name,
            audience: PLAN_DEFINITIONS[entitlement.plan].audience,
          },
          writable: entitlement.writable,
          blockedReason: entitlement.blockedReason ?? null,
          periodStart: view.periodStart,
          resetsAt: view.resetsAt,
          billing: billingStatus(),
          limits: view.limits.map((status) => ({
            id: status.limit.id,
            label: status.limit.label,
            description: LIMITS[status.limit.id].description,
            kind: status.limit.kind,
            unit: status.limit.unit,
            limit: status.limit.value,
            formatted: formatLimit(status.limit.value),
            used: status.used,
            remaining: status.remaining,
            percentUsed: status.percentUsed,
            exhausted: status.exhausted,
            nearLimit: status.nearLimit,
            source: status.limit.source,
            ...(status.limit.override
              ? {
                  override: {
                    reason: status.limit.override.reason,
                    setAt: status.limit.override.setAt,
                  },
                }
              : {}),
          })),
          pressure: view.pressure.map((status) => status.limit.id),
          tracked: view.tracked,
          recentRefusals: view.recentRefusals,
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
