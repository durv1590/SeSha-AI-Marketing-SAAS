import { NextResponse } from 'next/server';

/**
 * Liveness probe.
 *
 * Deliberately returns nothing about the environment, versions or dependencies:
 * a health endpoint is the most-scanned path on any deployment and should not
 * be a reconnaissance surface.
 */
export const dynamic = 'force-dynamic';

export function GET(): NextResponse {
  return NextResponse.json(
    { ok: true, service: 'sesha-web', timestamp: new Date().toISOString() },
    { status: 200, headers: { 'Cache-Control': 'no-store, max-age=0' } },
  );
}
