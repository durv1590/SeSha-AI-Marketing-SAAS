import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { listErrors, resolveError } from '@/lib/admin/service';

/**
 * Open errors, grouped by fingerprint, and marking one resolved.
 *
 * Errors are stored by FINGERPRINT with an occurrence count, not one row per
 * throw. A loop failing ten thousand times is one line here, which is what makes
 * the list readable at the moment it matters most.
 *
 * `message` is recorded by `lib/observability` with customer values stripped, so
 * it is safe to show; this route does not re-derive that guarantee, it relies on
 * it, and `tests/admin-security.test.ts` asserts the stripping.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:errors:read');
  if (isStaffFailure(guard)) return guard.response;

  try {
    const rows = await listErrors({ db: getDatabase() }, guard.staff);
    return ok(
      {
        data: {
          errors: rows.map((row) => ({
            fingerprint: row.fingerprint,
            severity: row.severity,
            source: row.source,
            message: row.message,
            organizationId: row.organizationId,
            occurrences: row.occurrences,
            firstSeenAt: row.firstSeenAt.toISOString(),
            lastSeenAt: row.lastSeenAt.toISOString(),
          })),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'adminMutation');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:system:write');
  if (isStaffFailure(guard)) return guard.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const fingerprint = typeof input.fingerprint === 'string' ? input.fingerprint.trim() : '';
  if (fingerprint.length === 0) {
    return fail(422, 'Which error?', { fingerprint: 'Required.' }, { headers: limit.headers });
  }

  try {
    await resolveError({ db: getDatabase() }, guard.staff, fingerprint);
    // Deliberately honest wording: marking it resolved changes a row, not the
    // code. If it happens again it reopens by occurring.
    return ok(
      { data: {}, message: 'Marked resolved. It reappears here if it happens again.' },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
