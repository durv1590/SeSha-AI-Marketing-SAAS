import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, ok } from '@/lib/api/respond';
import { applyCursor, pageParams, toPage } from '@/lib/api/pagination';
import { getDatabase } from '@/lib/db';
import { listAdminActions } from '@/lib/admin/service';

/**
 * The admin audit trail: every staff action, INCLUDING every read.
 *
 * Two decisions worth stating.
 *
 * **Reads are recorded.** Most audit logs record writes, which answers "who
 * changed this" and not "who looked at this". For a panel that can see across
 * every tenant, looking IS the sensitive act, so `withAudit` records reads at
 * the same weight as writes and this endpoint can filter by `kind`.
 *
 * **Reading the audit trail requires `engineer`, and is itself audited.** Support
 * cannot read it — the people most likely to be asked awkward questions about
 * their own activity are not given the ability to review it — and the reviewer's
 * own read appears in the next page of results. There is no way to look at this
 * table without leaving a row saying you did.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:audit:read');
  if (isStaffFailure(guard)) return guard.response;

  const url = new URL(request.url);
  const params = url.searchParams;
  const kind = params.get('kind');
  const organizationId = params.get('organizationId');
  const { limit: pageLimit, cursor } = pageParams(url);

  try {
    const all = await listAdminActions({ db: getDatabase() }, guard.staff, {
      ...(kind === 'read' || kind === 'write' ? { kind } : {}),
      ...(organizationId ? { targetOrganizationId: organizationId } : {}),
    });

    // The audit trail is the list most likely to grow past one screen and the
    // one where "show me the rest" matters most, so it is the first to page.
    const key = (row: (typeof all)[number]) => ({ at: row.createdAt.toISOString(), id: row.id });
    const page = toPage(applyCursor(all, cursor, key).slice(0, pageLimit + 1), pageLimit, key);
    const rows = page.items;

    return ok(
      {
        data: {
          actions: rows.map((row) => ({
            id: row.id,
            staffUserId: row.staffUserId,
            staffRole: row.staffRole,
            permission: row.permission,
            action: row.action,
            kind: row.kind,
            targetType: row.targetType,
            targetId: row.targetId,
            targetOrganizationId: row.targetOrganizationId,
            metadata: row.metadata,
            outcome: row.outcome,
            createdAt: row.createdAt.toISOString(),
          })),
          // `items` is not spread in: this endpoint calls its list `actions`,
          // and two names for one array is how a client ends up rendering both.
          nextCursor: page.nextCursor,
          hasMore: page.hasMore,
          // Stated in the payload so the panel can say it on screen rather than
          // leaving a reviewer to wonder whether their own visit was recorded.
          note: 'Reading this page is itself recorded, and appears the next time it is loaded.',
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
