import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { health, overview } from '@/lib/admin/service';
import { STAFF_ROLE_DESCRIPTION, STAFF_ROLE_LABEL, permissionsFor } from '@/lib/admin/auth';

/**
 * The admin overview and system health.
 *
 * Returns the caller's own permissions alongside the data, so the panel renders
 * the controls this staff member actually holds rather than rendering all of
 * them and refusing on click.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:health:read');
  if (isStaffFailure(guard)) return guard.response;

  try {
    const db = getDatabase();
    return ok(
      {
        data: {
          staff: {
            role: guard.staff.role,
            roleLabel: STAFF_ROLE_LABEL[guard.staff.role],
            roleDescription: STAFF_ROLE_DESCRIPTION[guard.staff.role],
            permissions: permissionsFor(guard.staff.role),
            sudo: guard.staff.sudo,
          },
          overview: await overview({ db }, guard.staff),
          health: await health({ db }, guard.staff),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
