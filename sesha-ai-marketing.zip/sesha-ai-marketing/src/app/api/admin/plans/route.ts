import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { setPlan } from '@/lib/admin/service';
import { permissionsFor } from '@/lib/admin/auth';
import {
  LIMITS,
  LIMIT_IDS,
  PLANS_BY_RANK,
  formatLimit,
  isPlanId,
  planChange,
} from '@/content/plans';

/**
 * The plan registry as staff see it, and moving one organization between plans.
 *
 * WHY THERE IS NO "EDIT PLAN" HERE. Phase 7 asks for configurable plans, and
 * they are configurable — in `content/plans.ts`, under review, deployed. What
 * this endpoint does NOT do is let a logged-in human rewrite what "Pro" means
 * for everybody at once through a form. A plan definition is a promise made to
 * every customer on it; changing it silently for all of them is not an admin
 * action, it is a release. Per-organization deviations have their own mechanism
 * with a mandatory reason: `/api/admin/limits`.
 *
 * So: GET shows the definitions and where they come from, POST moves ONE
 * organization, and the diff between old and new is returned so the person
 * clicking can see what they are about to take away.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:subscriptions:read');
  if (isStaffFailure(guard)) return guard.response;

  return ok(
    {
      data: {
        plans: PLANS_BY_RANK.map((plan) => ({
          id: plan.id,
          name: plan.name,
          rank: plan.rank,
          audience: plan.audience,
          requiresPayment: plan.requiresPayment,
          trialDays: plan.trialDays,
          limits: LIMIT_IDS.map((id) => ({
            id,
            label: LIMITS[id].label,
            kind: LIMITS[id].kind,
            unit: LIMITS[id].unit,
            value: plan.limits[id],
            formatted: formatLimit(plan.limits[id]),
          })),
        })),
        editable: false,
        source: 'src/content/plans.ts',
        note:
          'Plan definitions are code, reviewed and deployed. To give one organization a different limit, set an override with a reason.',
        // The panel hides the plan-change control entirely rather than showing
        // a button that 404s. This is the ROLE's permission, not the sudo state:
        // an engineer who has let their sudo window lapse should still see the
        // control and be asked to re-authenticate, not watch it disappear.
        canChangeOrganizationPlan: permissionsFor(guard.staff.role).includes(
          'admin:subscriptions:write',
        ),
      },
    },
    { headers: limit.headers },
  );
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'adminMutation');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:subscriptions:write');
  if (isStaffFailure(guard)) return guard.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const organizationId = typeof input.organizationId === 'string' ? input.organizationId : '';
  const plan = input.plan;
  const reason = typeof input.reason === 'string' ? input.reason : '';

  const errors: Record<string, string> = {};
  if (organizationId.length === 0) errors.organizationId = 'Which organization?';
  if (!isPlanId(plan)) errors.plan = 'Choose a plan.';
  if (reason.trim().length === 0) {
    errors.reason = 'Say why. A plan change with no explanation looks like a billing error.';
  }
  if (Object.keys(errors).length > 0) {
    return fail(422, 'Please check the form.', errors, { headers: limit.headers });
  }
  if (!isPlanId(plan)) return fail(422, 'Choose a plan.', errors, { headers: limit.headers });

  try {
    const db = getDatabase();
    const existing = await db.subscriptions.findForOrganization(organizationId);
    const from = existing && isPlanId(existing.plan) ? existing.plan : null;

    await setPlan({ db }, guard.staff, organizationId, plan, reason);

    return ok(
      {
        data: {
          plan,
          ...(from ? { from, direction: planChange(from, plan) } : {}),
          // A downgrade does not delete anything. The organization keeps what it
          // has and cannot create more; saying so here stops staff assuming a
          // downgrade is destructive, and stops them assuming it is free.
          effect:
            from && planChange(from, plan) === 'downgrade'
              ? 'Existing projects and content are kept. New ones are refused once they are over the new limit.'
              : 'In effect on their next request.',
        },
        message: 'Plan changed. It is recorded in billing events and in the admin audit trail.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof Error && !('code' in error)) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
