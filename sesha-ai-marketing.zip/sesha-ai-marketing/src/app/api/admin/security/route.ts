import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { listSecurityEvents } from '@/lib/admin/service';

/**
 * Security events across the platform.
 *
 * These are TENANT audit-log rows whose action is security-relevant — failed
 * sign-ins, password changes, invitations, permission denials — not the admin
 * audit trail, which is `/api/admin/audit` and is a separate table on purpose
 * (see migration 0007). Mixing the two would mean staff activity could be lost
 * in the noise of ordinary customer sign-ins, which is exactly backwards.
 *
 * The actor is NOT returned: a support engineer looking at a spike of failed
 * sign-ins needs the shape of the spike, not the identity of the person behind
 * each attempt. `organizationId` is enough to escalate.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:security:read');
  if (isStaffFailure(guard)) return guard.response;

  try {
    const events = await listSecurityEvents({ db: getDatabase() }, guard.staff);

    const byAction: Record<string, number> = {};
    let failures = 0;
    for (const event of events) {
      byAction[event.action] = (byAction[event.action] ?? 0) + 1;
      if (event.outcome !== 'success') failures += 1;
    }

    return ok(
      {
        data: {
          events,
          summary: { total: events.length, failures, byAction },
          truncatedAt: 100,
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
