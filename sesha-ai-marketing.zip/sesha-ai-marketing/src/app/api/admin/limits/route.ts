import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { clearLimitOverride, setLimitOverride } from '@/lib/admin/service';
import { LIMIT_IDS, LIMITS, type LimitId } from '@/content/plans';

/**
 * Setting and clearing a per-organization limit override.
 *
 * `reason` is required, and the service refuses without one. An override nobody
 * can explain is an override nobody dares remove, and six months later it is
 * indistinguishable from a bug.
 */
export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'adminMutation');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:limits:write');
  if (isStaffFailure(guard)) return guard.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const organizationId = typeof input.organizationId === 'string' ? input.organizationId : '';
  const limitId = input.limitId;
  const reason = typeof input.reason === 'string' ? input.reason : '';

  const errors: Record<string, string> = {};
  if (organizationId.length === 0) errors.organizationId = 'Which organization?';
  if (!isLimitId(limitId)) errors.limitId = 'Which limit?';
  if (reason.trim().length === 0) errors.reason = 'Say why. This is shown to whoever asks later.';
  if (Object.keys(errors).length > 0) {
    return fail(422, 'Please check the form.', errors, { headers: limit.headers });
  }

  try {
    const db = getDatabase();

    if (input.clear === true) {
      await clearLimitOverride({ db }, guard.staff, organizationId, limitId as LimitId);
      return ok(
        { data: {}, message: `Override removed. ${LIMITS[limitId as LimitId].label} is back to the plan default.` },
        { headers: limit.headers },
      );
    }

    // `null` is unlimited and is distinct from absent.
    const value =
      input.value === null ? null : typeof input.value === 'number' ? input.value : undefined;
    if (value === undefined) {
      return fail(
        422,
        'A limit is a whole number of zero or more, or null for unlimited.',
        { value: 'Required.' },
        { headers: limit.headers },
      );
    }

    await setLimitOverride({ db }, guard.staff, organizationId, limitId as LimitId, value, reason);
    return ok(
      { data: { limitId, value }, message: 'Saved. It takes effect on the next request they make.' },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof Error && !('code' in error)) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}

function isLimitId(value: unknown): value is LimitId {
  return typeof value === 'string' && (LIMIT_IDS as readonly string[]).includes(value);
}
