import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { listJobs } from '@/lib/admin/service';

/**
 * Crawl jobs and schema jobs across every tenant.
 *
 * WHAT IS RETURNED, AND WHAT IS NOT. A job row carries an `input` object, and
 * for a crawl that input is a URL the customer entered — their own site, or a
 * competitor they are watching. `input` is therefore NOT forwarded; the panel
 * gets the kind, the status, the progress and the failure, which is everything
 * needed to answer "why is their crawl stuck" without reading what they typed.
 *
 * The two Phase 7 dashboard surfaces "Crawl jobs" and "Schema jobs" are the same
 * table filtered by kind, so this is one endpoint with a filter rather than two
 * that would drift apart.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:jobs:read');
  if (isStaffFailure(guard)) return guard.response;

  const url = new URL(request.url);
  const kind = url.searchParams.get('kind');
  const status = url.searchParams.get('status');

  try {
    const rows = await listJobs({ db: getDatabase() }, guard.staff, {
      ...(kind ? { kind } : {}),
      ...(status ? { status } : {}),
    });

    return ok(
      {
        data: {
          jobs: rows.map((row) => ({
            id: row.id,
            organizationId: row.organizationId,
            projectId: row.projectId,
            kind: row.kind,
            status: row.status,
            progressDone: row.progressDone,
            progressTotal: row.progressTotal,
            progressMessage: row.progressMessage,
            cancelRequested: row.cancelRequested,
            attempts: row.attempts,
            failureCode: row.failureCode,
            failureDetail: row.failureDetail,
            createdAt: row.createdAt.toISOString(),
            startedAt: row.startedAt ? row.startedAt.toISOString() : null,
            finishedAt: row.finishedAt ? row.finishedAt.toISOString() : null,
          })),
          // Named so the panel can say so rather than implying the list is all
          // there is.
          truncatedAt: 100,
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
