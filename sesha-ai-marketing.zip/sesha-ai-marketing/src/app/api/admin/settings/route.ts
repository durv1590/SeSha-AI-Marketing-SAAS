import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { listSettings, setSetting } from '@/lib/admin/service';
import { GROUP_LABEL, SETTING_GROUPS } from '@/lib/admin/settings';

/**
 * Prompts, templates, validator configuration and system configuration.
 *
 * Reading needs only the general admin read permission; WRITING is routed to the
 * permission for that setting's group, so the audit log records which
 * configuration surface was touched rather than "a setting changed".
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:health:read');
  if (isStaffFailure(guard)) return guard.response;

  try {
    const settings = await listSettings({ db: getDatabase() }, guard.staff);
    return ok(
      {
        data: {
          settings,
          groups: SETTING_GROUPS.map((id) => ({ id, label: GROUP_LABEL[id] })),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'adminMutation');
  if (!limit.allowed) return limit.response;

  // The broadest of the four configuration permissions is required to reach the
  // endpoint; the service then checks the specific one for the key being set.
  // Both checks are real: this one keeps a support account out entirely, and the
  // service's keeps the audit record accurate.
  const guard = await requireStaff(request, 'admin:system:write');
  if (isStaffFailure(guard)) return guard.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const key = typeof input.key === 'string' ? input.key : '';
  if (key.length === 0) {
    return fail(422, 'Which setting?', { key: 'Required.' }, { headers: limit.headers });
  }

  try {
    await setSetting({ db: getDatabase() }, guard.staff, key, input.value);
    return ok({ data: { key }, message: 'Saved.' }, { headers: limit.headers });
  } catch (error) {
    if (error instanceof Error && !('code' in error)) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
