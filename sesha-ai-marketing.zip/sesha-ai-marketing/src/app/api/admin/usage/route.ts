import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { platformUsage } from '@/lib/admin/service';
import { PLANS_BY_RANK } from '@/content/plans';
import { METRIC_LABEL, WRITABLE_METRICS } from '@/lib/usage/metrics';

/**
 * Usage across the whole platform, for the period in progress.
 *
 * THE METRIC LIST COMES FROM `WRITABLE_METRICS`, not from the totals. A metric
 * nothing has recorded yet must appear as zero rather than be missing: "we have
 * no figure for content generation" and "nobody generated content" look
 * identical in a sparse object, and the first of those is a bug worth seeing.
 *
 * `audit_run` is excluded because it is the legacy value nothing writes any more
 * (see `lib/usage/metrics.ts`); it is still readable, and historic rows carrying
 * it are still counted by the per-limit measures.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:usage:read');
  if (isStaffFailure(guard)) return guard.response;

  try {
    const usage = await platformUsage({ db: getDatabase() }, guard.staff);

    return ok(
      {
        data: {
          periodStart: usage.periodStart,
          metrics: WRITABLE_METRICS.map((metric) => ({
            id: metric,
            label: METRIC_LABEL[metric],
            total: usage.totals[metric] ?? 0,
          })),
          ai: {
            requests: usage.ai.requests,
            tokens: usage.ai.tokens,
            window: 'Last 30 days.',
          },
          byPlan: PLANS_BY_RANK.map((plan) => ({
            id: plan.id,
            name: plan.name,
            organizations:
              usage.byPlan.find((entry) => entry.plan === plan.id)?.organizations ?? 0,
          })),
          notMeasured: [
            'Cost — token counts are recorded, provider invoices are not, so no spend figure is shown.',
            'Per-metric history — totals are for the period in progress; earlier periods are readable per organization, not aggregated here.',
          ],
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
