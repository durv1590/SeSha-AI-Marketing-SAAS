import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { grantStaff, listStaff, revokeStaff } from '@/lib/admin/service';
import { STAFF_ROLES, STAFF_ROLE_DESCRIPTION, STAFF_ROLE_LABEL, isStaffRole } from '@/lib/admin/auth';

/**
 * Granting and revoking platform access.
 *
 * The one power that must not be self-serve: it is the power to give yourself
 * every other power. Reading the list needs `engineer`; changing it needs
 * `platform_owner`, and the service refuses to let the last owner revoke
 * themselves — with nobody holding the role, access cannot be restored without
 * direct database access at the worst possible moment.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:staff:read');
  if (isStaffFailure(guard)) return guard.response;

  try {
    const rows = await listStaff({ db: getDatabase() }, guard.staff);
    return ok(
      {
        data: {
          staff: rows.map((row) => ({
            userId: row.userId,
            role: row.role,
            roleLabel: STAFF_ROLE_LABEL[row.role],
            reason: row.reason,
            grantedAt: row.grantedAt.toISOString(),
            revokedAt: row.revokedAt?.toISOString() ?? null,
            active: row.revokedAt === null,
          })),
          roles: STAFF_ROLES.map((role) => ({
            id: role,
            label: STAFF_ROLE_LABEL[role],
            description: STAFF_ROLE_DESCRIPTION[role],
          })),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'adminMutation');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:staff:write');
  if (isStaffFailure(guard)) return guard.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const userId = typeof input.userId === 'string' ? input.userId : '';
  if (userId.length === 0) {
    return fail(422, 'Which user?', { userId: 'Required.' }, { headers: limit.headers });
  }

  try {
    const db = getDatabase();

    if (input.revoke === true) {
      await revokeStaff({ db }, guard.staff, userId);
      return ok(
        { data: { userId }, message: 'Revoked. It takes effect on their next request.' },
        { headers: limit.headers },
      );
    }

    const reason = typeof input.reason === 'string' ? input.reason : '';
    if (!isStaffRole(input.role)) {
      return fail(422, 'Choose a staff role.', { role: 'Required.' }, { headers: limit.headers });
    }
    if (reason.trim().length === 0) {
      return fail(
        422,
        'Say why this person needs platform access.',
        { reason: 'Required.' },
        { headers: limit.headers },
      );
    }

    await grantStaff({ db }, guard.staff, userId, input.role, reason);
    return ok({ data: { userId, role: input.role }, message: 'Granted.' }, { headers: limit.headers });
  } catch (error) {
    if (error instanceof Error && !('code' in error)) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
