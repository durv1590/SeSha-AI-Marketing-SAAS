import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { health } from '@/lib/admin/service';

/**
 * System health on its own, so the panel can refresh it without re-running the
 * whole overview (which counts every organization).
 *
 * `worst` is computed here rather than in the panel so two surfaces cannot
 * disagree about whether the platform is in trouble. `unknown` deliberately
 * ranks WORSE than `ok`: a check that could not be performed is not a pass.
 */
export const dynamic = 'force-dynamic';

const ORDER = { fail: 3, warn: 2, unknown: 1, ok: 0 } as const;

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:health:read');
  if (isStaffFailure(guard)) return guard.response;

  try {
    const report = await health({ db: getDatabase() }, guard.staff);

    let worst: keyof typeof ORDER = 'ok';
    for (const check of report.checks) {
      if (ORDER[check.state] > ORDER[worst]) worst = check.state;
    }

    return ok(
      {
        data: {
          ...report,
          worst,
          checkedAt: new Date().toISOString(),
          // No "all systems operational". The worst state and the list of
          // things not measured are the whole claim.
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
