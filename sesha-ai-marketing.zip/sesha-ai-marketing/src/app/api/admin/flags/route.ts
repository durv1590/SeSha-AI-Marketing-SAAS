import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { listFlags, setFlagRule } from '@/lib/admin/service';
import { CATEGORY_LABEL, FLAG_CATEGORIES } from '@/lib/flags';

/**
 * Feature flags.
 *
 * Each flag is returned with its AVAILABILITY as well as its state: a provider
 * flag switched on with no API key behind it is reported as unavailable rather
 * than as working, because a switch that appears to work and does nothing is
 * worse than one that is visibly unavailable.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:health:read');
  if (isStaffFailure(guard)) return guard.response;

  try {
    const flags = await listFlags({ db: getDatabase() }, guard.staff);
    return ok(
      {
        data: {
          flags,
          categories: FLAG_CATEGORIES.map((id) => ({ id, label: CATEGORY_LABEL[id] })),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'adminMutation');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:flags:write');
  if (isStaffFailure(guard)) return guard.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const key = typeof input.key === 'string' ? input.key : '';
  if (key.length === 0) {
    return fail(422, 'Which flag?', { key: 'Required.' }, { headers: limit.headers });
  }

  try {
    await setFlagRule({ db: getDatabase() }, guard.staff, {
      key,
      ...(typeof input.disabled === 'boolean' ? { disabled: input.disabled } : {}),
      ...(Array.isArray(input.organizationIds)
        ? { organizationIds: (input.organizationIds as unknown[]).filter((id): id is string => typeof id === 'string') }
        : {}),
      ...(Array.isArray(input.excludedOrganizationIds)
        ? {
            excludedOrganizationIds: (input.excludedOrganizationIds as unknown[]).filter(
              (id): id is string => typeof id === 'string',
            ),
          }
        : {}),
      ...(Array.isArray(input.plans)
        ? { plans: (input.plans as unknown[]).filter((plan): plan is string => typeof plan === 'string') }
        : {}),
      ...(typeof input.rolloutPercent === 'number' ? { rolloutPercent: input.rolloutPercent } : {}),
    });

    return ok(
      {
        data: { key },
        message:
          input.disabled === true
            ? 'Switched off for everyone. Nothing overrides a kill switch — not a plan, not a named organization, not a roll-out.'
            : 'Saved.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof Error && !('code' in error)) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
