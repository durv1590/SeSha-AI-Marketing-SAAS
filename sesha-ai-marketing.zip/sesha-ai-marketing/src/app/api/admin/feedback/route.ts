import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { listFeedback, setFeedbackStatus } from '@/lib/admin/service';
import type { FeedbackRow } from '@/lib/db/types';

/**
 * Customer feedback, and triaging it.
 *
 * THE ONE PLACE STAFF READ WHAT A CUSTOMER WROTE, and it is the only one that
 * should be: the customer typed it in order to be read. Every other admin
 * surface deliberately returns metadata only (see `AdminReadRepository`).
 *
 * Reading it is audited like everything else, so "who read the feedback" has an
 * answer even though reading it is the point.
 */
export const dynamic = 'force-dynamic';

const STATUSES = ['new', 'triaged', 'answered', 'closed'] as const;

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:feedback:read');
  if (isStaffFailure(guard)) return guard.response;

  const status = new URL(request.url).searchParams.get('status');

  try {
    const rows = await listFeedback(
      { db: getDatabase() },
      guard.staff,
      isStatus(status) ? status : undefined,
    );

    return ok(
      {
        data: {
          statuses: STATUSES,
          // Counts are only meaningful over the unfiltered list. Counting a
          // filtered list would render "new: 4, closed: 0" while the closed
          // ones simply were not fetched.
          ...(isStatus(status) ? {} : { counts: countByStatus(rows) }),
          feedback: rows.map((row) => ({
            id: row.id,
            kind: row.kind,
            message: row.message,
            surface: row.surface,
            status: row.status,
            organizationId: row.organizationId,
            createdAt: row.createdAt.toISOString(),
            triagedAt: row.triagedAt ? row.triagedAt.toISOString() : null,
          })),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'adminMutation');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:feedback:write');
  if (isStaffFailure(guard)) return guard.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const id = typeof input.id === 'string' ? input.id : '';
  const status = input.status;

  const errors: Record<string, string> = {};
  if (id.length === 0) errors.id = 'Which item?';
  if (!isStatus(status)) errors.status = 'Choose a status.';
  if (Object.keys(errors).length > 0) {
    return fail(422, 'Please check the form.', errors, { headers: limit.headers });
  }

  try {
    await setFeedbackStatus({ db: getDatabase() }, guard.staff, id, status as FeedbackRow['status']);
    return ok({ data: { id, status } }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

function isStatus(value: unknown): value is FeedbackRow['status'] {
  return typeof value === 'string' && (STATUSES as readonly string[]).includes(value);
}

function countByStatus(rows: readonly FeedbackRow[]): Readonly<Record<string, number>> {
  const counts: Record<string, number> = {};
  for (const status of STATUSES) counts[status] = 0;
  for (const row of rows) counts[row.status] = (counts[row.status] ?? 0) + 1;
  return counts;
}
