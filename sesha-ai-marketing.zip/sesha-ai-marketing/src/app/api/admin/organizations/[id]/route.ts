import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { organizationDetail, setPlan } from '@/lib/admin/service';
import { isPlanId } from '@/content/plans';

/**
 * One account.
 *
 * Metadata, limits, usage and billing history. NOT the customer's content —
 * `adminRead` has no method that returns a lead, an article or a report body,
 * and `tests/phase7-services.test.ts` asserts none of it leaks into this shape.
 */
export const dynamic = 'force-dynamic';

type Params = { params: Promise<{ id: string }> };

export async function GET(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:businesses:read');
  if (isStaffFailure(guard)) return guard.response;

  const { id } = await params;

  try {
    const detail = await organizationDetail({ db: getDatabase() }, guard.staff, id);
    if (!detail) return fail(404, 'Not found.', undefined, { headers: limit.headers });
    return ok({ data: detail }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request, { params }: Params): Promise<Response> {
  const limit = enforceRateLimit(request, 'adminMutation');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:subscriptions:write');
  if (isStaffFailure(guard)) return guard.response;

  const { id } = await params;
  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const reason = typeof input.reason === 'string' ? input.reason : '';

  if (!isPlanId(input.plan)) {
    return fail(422, 'Choose a plan.', { plan: 'Choose a plan.' }, { headers: limit.headers });
  }
  if (reason.trim().length === 0) {
    return fail(422, 'Say why this plan is being changed.', { reason: 'Required.' }, { headers: limit.headers });
  }

  try {
    await setPlan({ db: getDatabase() }, guard.staff, id, input.plan, reason);
    return ok(
      {
        data: { plan: input.plan },
        message:
          'Plan changed and recorded. This does NOT charge anyone — the billing consequence is a separate step at the provider.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    if (error instanceof Error && !('code' in error)) {
      return fail(422, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}
