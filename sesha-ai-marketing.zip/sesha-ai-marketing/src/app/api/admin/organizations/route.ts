import { errorResponse } from '@/lib/api/guard';
import { isStaffFailure, requireStaff } from '@/lib/api/admin-guard';
import { enforceRateLimit, ok } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { listOrganizations } from '@/lib/admin/service';

/**
 * Accounts, as metadata.
 *
 * The search term is recorded in the audit log, not the results — someone
 * fishing for a named customer leaves a trace, and logging the results would
 * copy customer data into the audit table.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'admin');
  if (!limit.allowed) return limit.response;

  const guard = await requireStaff(request, 'admin:businesses:read');
  if (isStaffFailure(guard)) return guard.response;

  const params = new URL(request.url).searchParams;

  try {
    const rows = await listOrganizations({ db: getDatabase() }, guard.staff, {
      ...(params.get('plan') ? { plan: params.get('plan') as string } : {}),
      ...(params.get('status') ? { status: params.get('status') as string } : {}),
      ...(params.get('q') ? { query: params.get('q') as string } : {}),
    });

    return ok(
      {
        data: {
          organizations: rows.map((entry) => ({
            id: entry.organization.id,
            name: entry.organization.name,
            slug: entry.organization.slug,
            plan: entry.organization.plan,
            status: entry.subscription?.status ?? null,
            memberCount: entry.memberCount,
            projectCount: entry.projectCount,
            createdAt: entry.organization.createdAt.toISOString(),
          })),
        },
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
