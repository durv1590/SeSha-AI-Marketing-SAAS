import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { looksAutomated, validateContact, type ContactRawInput } from '@/lib/validation/forms';

/**
 * Contact submissions.
 *
 * Order of operations matters and is deliberate:
 *   1. rate limit  — cheapest rejection first;
 *   2. body parse  — malformed input never reaches validation;
 *   3. bot checks  — silent, returning a normal success response so an
 *      automated client learns nothing about why it was dropped;
 *   4. validation  — server-side and authoritative;
 *   5. persistence — through a repository interface, so Phase 2 swaps the
 *      dev adapter for PostgreSQL without touching this file.
 */

export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'contact');
  if (!limit.allowed) return limit.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as ContactRawInput;

  // Silent drop: respond exactly as a successful submission would.
  if (looksAutomated(input)) {
    return ok({ message: 'Thanks — your message is with the team.' }, { headers: limit.headers });
  }

  const result = validateContact(input);
  if (!result.ok) {
    return fail(422, 'Please check the highlighted fields.', result.errors as Record<string, string>, {
      headers: limit.headers,
    });
  }

  try {
    await getDatabase().contact.create(result.data);
  } catch {
    // Never leak an internal error message to the client.
    return fail(500, 'We could not record your message. Please email us directly.', undefined, {
      headers: limit.headers,
    });
  }

  return ok(
    { message: 'Thanks — your message is with the team. We reply to every enquiry.' },
    { headers: limit.headers },
  );
}
