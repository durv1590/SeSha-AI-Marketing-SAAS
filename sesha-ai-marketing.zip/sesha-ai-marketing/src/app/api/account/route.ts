import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import {
  clearSessionCookies,
  establishSession,
  requestMeta,
  serviceContext,
} from '@/lib/auth/current-session';
import { changePassword, deleteAccount } from '@/lib/auth/service';
import { isSudo } from '@/lib/auth/session';

/**
 * Account deletion.
 *
 * Two gates, both required:
 *  · the session must be in its sudo window (recently authenticated), and
 *  · a password account must re-enter its password.
 * An OAuth-only account has no password, so the sudo window is the control.
 */

export const dynamic = 'force-dynamic';

export async function DELETE(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = (await readJson(request)) as Record<string, unknown> | null;
  const password = typeof body?.password === 'string' ? body.password : null;

  if (!isSudo(auth.session.session) && !password) {
    return fail(403, 'Please sign in again before deleting your account.', undefined, {
      headers: limit.headers,
    });
  }

  try {
    const result = await deleteAccount(
      serviceContext(),
      {
        userId: auth.session.user.id,
        password,
        organizationId: auth.session.user.organizationId,
      },
      await requestMeta(),
    );

    if (!result.ok) {
      return fail(403, 'That password is not correct.', undefined, { headers: limit.headers });
    }

    await clearSessionCookies();
    return ok(
      { message: 'Your account is closed. Data is erased after 30 days.' },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}

/**
 * Changing the password.
 *
 * WHY THIS ROUTE EXISTS AS OF PHASE 8: `changePassword` was written and tested
 * in Phase 2 and never given a route. It was unreachable — a signed-in user had
 * no way to change their password at all, which is both a security gap and the
 * first thing anyone does after suspecting a compromise.
 *
 * The current password is required even inside the sudo window. Sudo says "this
 * browser authenticated recently"; it does not say "the person at the keyboard
 * knows the password", and an unattended laptop is exactly the case that
 * separates the two.
 *
 * On success EVERY session is revoked, including this one, and a fresh token is
 * issued and set here — so the reply lands with the new cookie already in place
 * and the user is not signed out of the tab they are looking at.
 */
export async function PATCH(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'passwordReset');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const body = (await readJson(request)) as Record<string, unknown> | null;
  const currentPassword = typeof body?.currentPassword === 'string' ? body.currentPassword : '';
  const newPassword = typeof body?.newPassword === 'string' ? body.newPassword : '';

  if (currentPassword.length === 0 || newPassword.length === 0) {
    return fail(
      422,
      'Enter your current password and the new one.',
      {
        ...(currentPassword.length === 0 ? { currentPassword: 'Required.' } : {}),
        ...(newPassword.length === 0 ? { newPassword: 'Required.' } : {}),
      },
      { headers: limit.headers },
    );
  }

  try {
    const result = await changePassword(
      serviceContext(),
      {
        userId: auth.session.user.id,
        currentPassword,
        newPassword,
        currentSessionId: auth.session.session.id,
      },
      await requestMeta(),
    );

    if (!result.ok) {
      if (result.reason === 'weak-password') {
        return fail(
          422,
          'That password is not strong enough.',
          { newPassword: (result.problems ?? []).join(' ') || 'Choose a stronger password.' },
          { headers: limit.headers },
        );
      }
      // Deliberately the same wording whether the account has no password or the
      // password was wrong: a signed-in caller learns nothing either way, and
      // keeping one sentence means one thing to get right.
      return fail(
        422,
        'That is not your current password.',
        { currentPassword: 'Incorrect.' },
        { headers: limit.headers },
      );
    }

    await establishSession(result.token, result.session.id);
    return ok(
      {
        data: {},
        message:
          'Password changed. Every other signed-in device has been signed out, and this one has a new session.',
      },
      { headers: limit.headers },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
