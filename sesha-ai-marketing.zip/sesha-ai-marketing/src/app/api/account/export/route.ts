import { errorResponse, isGuardFailure, requireAuth } from '@/lib/api/guard';
import { enforceRateLimit, fail } from '@/lib/api/respond';
import { requestMeta } from '@/lib/auth/current-session';
import { getDatabase } from '@/lib/db';
import { buildAccountExport } from '@/lib/privacy/export';
import { can } from '@/lib/auth/rbac';
import { isSudo } from '@/lib/auth/session';
import { log } from '@/lib/observability/log';

/**
 * "Give me everything you hold about me", as a file.
 *
 * WHY IT IS GATED THE WAY IT IS
 * This single request produces the most complete copy of an organization's data
 * that exists anywhere. That makes it the most valuable request in the product
 * to an attacker holding a stolen session, so it carries the same two gates as
 * account deletion:
 *
 *  · the SUDO WINDOW — the browser must have authenticated recently, not merely
 *    hold a cookie from three weeks ago;
 *  · a PERMISSION — `billing:read` is the closest existing proxy for "acts for
 *    the organization, not just in it", so a junior team member cannot walk out
 *    with the whole account.
 *
 * It is also rate limited to the `aiBatch` bucket — five per ten minutes —
 * because it is expensive and nobody needs it twice in an hour.
 *
 * THE DOWNLOAD IS NOT CACHED ANYWHERE. `private, no-store` and a
 * `Content-Disposition` attachment: this file must not sit in a CDN, a proxy or
 * a browser's back-forward cache.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'aiBatch');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  if (!isSudo(auth.session.session)) {
    return fail(403, 'Please sign in again before exporting your data.', { needsSudo: 'true' }, {
      headers: limit.headers,
    });
  }

  if (!can(auth.tenant.role, 'billing:read')) {
    return fail(
      403,
      'Only an owner, admin or manager can export the organization’s data.',
      undefined,
      { headers: limit.headers },
    );
  }

  try {
    const db = getDatabase();
    const exported = await buildAccountExport({ db }, {
      userId: auth.tenant.userId,
      organizationId: auth.tenant.organizationId,
    });

    // Recorded in the tenant audit log: an export is a security-relevant event,
    // and "who took a full copy of the account, and when" is a question that
    // gets asked after someone leaves.
    const meta = await requestMeta();
    await db.audit.record({
      organizationId: auth.tenant.organizationId,
      actorId: auth.tenant.userId,
      action: 'account.export',
      entityType: 'organization',
      entityId: auth.tenant.organizationId,
      outcome: 'success',
      // COUNTS ONLY. The audit log records that an export happened and how big
      // it was; putting the export in it would make the audit log a second copy
      // of everything, which is the one thing it must never become.
      metadata: { counts: exported.counts },
      ipHash: null,
      userAgent: meta.userAgent ?? null,
    });

    log.info('account export produced', {
      organizationId: auth.tenant.organizationId,
      userId: auth.tenant.userId,
      // Counts only. The export itself must never reach a log line.
      counts: exported.counts,
    });

    const body = JSON.stringify(exported, null, 2);
    const stamp = exported.exportedAt.slice(0, 10);

    return new Response(body, {
      status: 200,
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="sesha-export-${stamp}.json"`,
        'Cache-Control': 'private, no-store',
        ...limit.headers,
      },
    });
  } catch (error) {
    return errorResponse(error);
  }
}
