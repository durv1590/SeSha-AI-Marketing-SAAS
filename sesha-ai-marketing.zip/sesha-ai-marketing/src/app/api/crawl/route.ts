import { errorResponse, isGuardFailure, requireAuth, requireAuthorized } from '@/lib/api/guard';
import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { revokeCrawlConsent } from '@/lib/workspace/service';
import {
  ConsentRequiredError,
  JobConflictError,
  getLatestCrawl,
  requestJob,
  runJob,
  toJobView,
} from '@/lib/crawl/service';

/**
 * Start a crawl, or read the latest one.
 *
 * THE JOB IS EXECUTED AFTER THE RESPONSE IS DECIDED, not during it. A crawl
 * takes minutes and a request must not hold a connection open for that long, so
 * the handler queues the job, returns its id, and the client polls
 * `/api/jobs/:id`. Execution is kicked off without awaiting — in a deployment
 * with a real worker process, that line is removed and the worker claims the job
 * instead. Either way the job row is the single source of truth.
 */
export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'read');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const projectId = new URL(request.url).searchParams.get('projectId') ?? '';
  if (projectId.length === 0) {
    return fail(422, 'A projectId is required.', undefined, { headers: limit.headers });
  }

  try {
    const crawl = await getLatestCrawl({ db: getDatabase() }, auth.tenant, projectId);
    return ok({ data: crawl }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request): Promise<Response> {
  // aiBatch, not mutation: a crawl is minutes of work and dozens of outbound
  // requests, so it is rate limited like a batch job rather than like a save.
  const limit = enforceRateLimit(request, 'aiBatch');
  if (!limit.allowed) return limit.response;

  // Crawling needs an explicit permission, not just a session.
  const auth = await requireAuthorized(request, 'crawl:request');
  if (isGuardFailure(auth)) return auth.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as Record<string, unknown>;
  const projectId = typeof input.projectId === 'string' ? input.projectId : '';
  if (projectId.length === 0) {
    return fail(422, 'Please check the form.', { projectId: 'Choose a project first.' }, {
      headers: limit.headers,
    });
  }

  const context = { db: getDatabase() };

  try {
    const job = await requestJob(context, auth.tenant, {
      projectId,
      kind: 'crawl',
      ...(typeof input.maxPages === 'number' ? { maxPages: input.maxPages } : {}),
      ...(typeof input.maxDepth === 'number' ? { maxDepth: input.maxDepth } : {}),
    });

    // Fire and forget. The job row records progress, success and failure, so
    // nothing is lost if this process is replaced mid-crawl — the stale-job
    // reaper will fail it and the user can retry.
    void (async () => {
      const claimed = await context.db.jobs.claimNext(new Date(), ['crawl']);
      if (claimed) await runJob(context, claimed);
    })();

    return ok({ data: toJobView(job), message: 'Crawl queued.' }, { headers: limit.headers });
  } catch (error) {
    if (error instanceof ConsentRequiredError) {
      // 409, not 403: the request is permitted, the workspace state forbids it.
      return fail(409, error.message, undefined, { headers: limit.headers });
    }
    if (error instanceof JobConflictError) {
      return fail(409, error.message, undefined, { headers: limit.headers });
    }
    return errorResponse(error);
  }
}

/**
 * Delete crawl history: withdraws a consent record and HARD deletes every page
 * crawled under it. Phase 8 — the service existed, but no route reached it, so a
 * customer had no way to remove crawled content short of deleting the account.
 *
 * `crawl:delete` is enforced by the service; a consent id from another
 * organization is a 404.
 */
export async function DELETE(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'mutation');
  if (!limit.allowed) return limit.response;

  const auth = await requireAuth(request);
  if (isGuardFailure(auth)) return auth.response;

  const consentId = new URL(request.url).searchParams.get('consentId') ?? '';
  if (consentId.length === 0) {
    return fail(422, 'A consentId is required.', undefined, { headers: limit.headers });
  }

  try {
    await revokeCrawlConsent({ db: getDatabase() }, auth.tenant, consentId, { deleteData: true });
    return ok({ message: 'Crawl consent withdrawn and crawled content deleted.' }, { headers: limit.headers });
  } catch (error) {
    return errorResponse(error);
  }
}
