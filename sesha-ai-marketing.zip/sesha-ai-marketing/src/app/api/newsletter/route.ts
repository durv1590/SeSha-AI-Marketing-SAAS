import { enforceRateLimit, fail, ok, readJson } from '@/lib/api/respond';
import { getDatabase } from '@/lib/db';
import { validateNewsletter, type NewsletterRawInput } from '@/lib/validation/forms';
import { sanitizeText } from '@/lib/security/sanitize';

export const dynamic = 'force-dynamic';

export async function POST(request: Request): Promise<Response> {
  const limit = enforceRateLimit(request, 'newsletter');
  if (!limit.allowed) return limit.response;

  const body = await readJson(request);
  if (!body) return fail(400, 'Expected a JSON body.', undefined, { headers: limit.headers });

  const input = body as NewsletterRawInput;

  if (sanitizeText(input.website, 200).length > 0) {
    return ok({ message: 'Thanks — you are on the list.' }, { headers: limit.headers });
  }

  const result = validateNewsletter(input);
  if (!result.ok) {
    return fail(422, 'Please check your email address.', result.errors as Record<string, string>, {
      headers: limit.headers,
    });
  }

  try {
    await getDatabase().newsletter.subscribe(result.data.email);
  } catch {
    return fail(500, 'We could not save that right now. Please try again later.', undefined, {
      headers: limit.headers,
    });
  }

  return ok({ message: 'Thanks — you are on the list.' }, { headers: limit.headers });
}
