/**
 * Minimal type declarations for the Next.js modules used by the domain and API
 * layers, so `scripts/typecheck.mjs` can type-check them offline.
 *
 * THESE ARE FOR VERIFICATION ONLY.
 *  · They are not referenced by the application's tsconfig.json, so they never
 *    affect a real build.
 *  · They are deliberately NARROWER than the real API: every declaration here
 *    describes only what this codebase actually calls. A narrow shim can cause
 *    a false error (which is investigable); a wide `any` shim would hide a real
 *    one, which is the failure mode that matters.
 *  · Once `npm install` runs, delete nothing — just run the real `tsc`, which
 *    ignores this file.
 */

declare module 'next/server' {
  export class NextResponse extends Response {
    static json(body: unknown, init?: ResponseInit): NextResponse;
    static redirect(url: string | URL, status?: number): NextResponse;
    static next(): NextResponse;
    readonly cookies: {
      set(name: string, value: string, options?: object): void;
      delete(name: string): void;
      get(name: string): { name: string; value: string } | undefined;
    };
  }

  export interface NextRequest extends Request {
    readonly nextUrl: URL;
    readonly cookies: {
      get(name: string): { name: string; value: string } | undefined;
      getAll(): { name: string; value: string }[];
    };
  }
}

declare module 'next/headers' {
  interface ReadonlyHeaders {
    get(name: string): string | null;
    has(name: string): boolean;
    entries(): IterableIterator<[string, string]>;
  }

  interface CookieRecord {
    name: string;
    value: string;
  }

  interface CookieStore {
    get(name: string): CookieRecord | undefined;
    getAll(): CookieRecord[];
    has(name: string): boolean;
    set(name: string, value: string, options?: object): void;
    delete(name: string): void;
  }

  export function headers(): Promise<ReadonlyHeaders>;
  export function cookies(): Promise<CookieStore>;
}

declare module 'next/navigation' {
  export function usePathname(): string;
  export function useSearchParams(): URLSearchParams;
  export function useRouter(): {
    push(href: string): void;
    replace(href: string): void;
    refresh(): void;
    back(): void;
  };
  export function redirect(url: string): never;
  export function notFound(): never;
}

declare module 'next' {
  export interface Metadata {
    applicationName?: string;
    creator?: string;
    publisher?: string;
    formatDetection?: { email?: boolean; address?: boolean; telephone?: boolean };
    icons?: unknown;
    manifest?: string;
    title?: unknown;
    description?: string;
    alternates?: unknown;
    openGraph?: unknown;
    twitter?: unknown;
    robots?: unknown;
    metadataBase?: URL;
    keywords?: string[];
    authors?: unknown;
    category?: string;
    other?: Record<string, string | number | (string | number)[]>;
  }
  export namespace MetadataRoute {
    type Robots = {
      rules: { userAgent?: string | string[]; allow?: string | string[]; disallow?: string | string[] }
        | { userAgent?: string | string[]; allow?: string | string[]; disallow?: string | string[] }[];
      sitemap?: string | string[];
      host?: string;
    };
    type Sitemap = {
      url: string;
      lastModified?: string | Date;
      changeFrequency?: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
      priority?: number;
      alternates?: { languages?: Record<string, string> };
    }[];
  }

  export interface Viewport {
    themeColor?: unknown;
    width?: string;
    initialScale?: number;
    colorScheme?: string;
  }
}

/**
 * The sandbox stand-ins for clsx and tailwind-merge are plain JavaScript.
 * These declarations match the real packages' signatures for the calls this
 * codebase makes, so `cn()` is type-checked rather than silently `any`.
 */
declare module 'clsx' {
  export type ClassValue =
    | string
    | number
    | null
    | undefined
    | false
    | ClassValue[]
    | { [key: string]: unknown };
  export function clsx(...inputs: ClassValue[]): string;
  export default clsx;
}

declare module 'tailwind-merge' {
  export function twMerge(...inputs: (string | undefined | null | false)[]): string;
  export default twMerge;
}
