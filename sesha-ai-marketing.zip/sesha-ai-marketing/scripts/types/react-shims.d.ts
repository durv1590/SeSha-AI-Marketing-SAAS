/**
 * Minimal React and JSX type declarations, so `.tsx` can be type-checked offline.
 *
 * WHY THIS EXISTS
 * `@types/react` is not installable here (the npm registry returns 403), so for
 * six phases `.tsx` went unchecked and every Phase report named that as the
 * largest unverified risk. Phase 6 proved the cost: `Field` takes a render prop,
 * eighteen call sites passed child elements instead, and thirteen of those had
 * shipped in earlier phases. Nothing caught it because nothing type-checked JSX.
 *
 * WHAT THIS DOES AND DOES NOT CHECK — read this before trusting a green run.
 *
 * ✅ CHECKED: every use of a component defined in THIS codebase. Prop names,
 *    prop types, required props, and the shape of `children` — including render
 *    props. The `Field` bug would have failed here. This is the whole point.
 *
 * ❌ NOT CHECKED: intrinsic DOM elements (`<div>`, `<input>`, `<svg>`).
 *    `JSX.IntrinsicElements` is an index signature to `any`, so a misspelled DOM
 *    attribute passes silently. Typing every HTML and SVG attribute correctly is
 *    what `@types/react` is *for*, and a hand-written approximation would produce
 *    hundreds of false errors on attributes I failed to anticipate — which is how
 *    a check gets disabled instead of read.
 *
 * ❌ NOT CHECKED: React's own runtime semantics — hook ordering, server/client
 *    boundaries, `use client` correctness. `scripts/verify-static.mjs` covers the
 *    boundary rules separately.
 *
 * THE DESIGN RULE, inherited from next-shims.d.ts: these declarations are
 * deliberately NARROWER than the real API. A narrow shim can produce a false
 * error, which is investigable in a minute. A wide `any` shim hides a real one
 * forever. So the HTML attribute interfaces below are CLOSED — they list only
 * what this codebase actually passes. If a legitimate new attribute errors, add
 * it here; do not reach for an index signature, because `CardProps extends
 * HTMLAttributes<HTMLDivElement>` means an index signature would also silence
 * every typo in every prop of every component that extends one.
 *
 * NOT REFERENCED BY THE APPLICATION'S tsconfig.json, so a real build ignores it
 * entirely. Once `npm install` runs, `npm run verify` is the authority and this
 * file becomes redundant — delete nothing, just stop relying on it.
 */

declare namespace React {
  type Key = string | number;

  type ReactNode =
    | ReactElement
    | string
    | number
    | bigint
    | boolean
    | null
    | undefined
    | Iterable<ReactNode>;

  interface ReactElement {
    type: unknown;
    props: unknown;
    key: Key | null;
  }

  /**
   * The `as` prop pattern (`<Container as="section">`). The function branch takes
   * `any` deliberately: narrowing it to `never` makes every polymorphic component
   * in the codebase unusable, which is a shim defect masquerading as a finding.
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  type ElementType = string | ((props: any) => ReactNode);

  /**
   * Returns `ReactElement | null`, not `ReactNode`.
   *
   * A component typed as returning `ReactNode` cannot be used as a JSX tag under
   * `JSX.Element`, which is what React's own types do too. Getting this wrong
   * produced twenty "'Link' cannot be used as a JSX component" errors on the
   * first run — a shim defect, not a codebase defect, and worth the comment so
   * the next person does not go looking for the bug in their own code.
   */
  type FC<P = Record<string, unknown>> = (props: P) => ReactElement | null;

  /* ------------------------------ events -------------------------------- */

  interface SyntheticEvent<T = Element> {
    readonly currentTarget: T;
    readonly target: EventTarget & T;
    preventDefault(): void;
    stopPropagation(): void;
  }

  interface FormEvent<T = Element> extends SyntheticEvent<T> {}

  interface ChangeEvent<T = Element> extends SyntheticEvent<T> {
    readonly target: EventTarget & T;
  }

  interface MouseEvent<T = Element> extends SyntheticEvent<T> {
    readonly altKey: boolean;
    readonly metaKey: boolean;
    readonly shiftKey: boolean;
    readonly ctrlKey: boolean;
  }

  interface KeyboardEvent<T = Element> extends SyntheticEvent<T> {
    readonly key: string;
    readonly altKey: boolean;
    readonly metaKey: boolean;
    readonly shiftKey: boolean;
    readonly ctrlKey: boolean;
  }

  interface DragEvent<T = Element> extends SyntheticEvent<T> {
    readonly dataTransfer: DataTransfer;
  }

  interface ClipboardEvent<T = Element> extends SyntheticEvent<T> {
    readonly clipboardData: DataTransfer;
  }

  interface FocusEvent<T = Element> extends SyntheticEvent<T> {
    readonly relatedTarget: EventTarget | null;
  }

  type EventHandler<E> = (event: E) => void;

  /* --------------------------- attributes -------------------------------- */

  /**
   * CLOSED ON PURPOSE. See the header: an index signature here would silence
   * every prop typo on every component extending it.
   */
  interface HTMLAttributes<T = Element> {
    readonly children?: ReactNode;
    readonly className?: string | undefined;
    readonly id?: string | undefined;
    readonly style?: CSSProperties | undefined;
    readonly title?: string | undefined;
    readonly hidden?: boolean | undefined;
    readonly tabIndex?: number | undefined;
    readonly role?: string | undefined;
    readonly key?: Key | undefined;
    readonly lang?: string | undefined;
    readonly dir?: string | undefined;
    readonly slot?: string | undefined;
    readonly onClick?: EventHandler<MouseEvent<T>> | undefined;
    readonly onSubmit?: EventHandler<FormEvent<T>> | undefined;
    readonly onChange?: EventHandler<ChangeEvent<T>> | undefined;
    readonly onInput?: EventHandler<FormEvent<T>> | undefined;
    readonly onFocus?: EventHandler<FocusEvent<T>> | undefined;
    readonly onBlur?: EventHandler<FocusEvent<T>> | undefined;
    readonly onKeyDown?: EventHandler<KeyboardEvent<T>> | undefined;
    readonly onKeyUp?: EventHandler<KeyboardEvent<T>> | undefined;
    readonly onMouseEnter?: EventHandler<MouseEvent<T>> | undefined;
    readonly onMouseLeave?: EventHandler<MouseEvent<T>> | undefined;
    readonly 'aria-label'?: string | undefined;
    readonly 'aria-labelledby'?: string | undefined;
    readonly 'aria-describedby'?: string | undefined;
    readonly 'aria-hidden'?: boolean | 'true' | 'false' | undefined;
    readonly 'aria-live'?: 'off' | 'polite' | 'assertive' | undefined;
    readonly 'aria-current'?: boolean | 'page' | 'step' | 'location' | 'true' | 'false' | undefined;
    readonly 'aria-expanded'?: boolean | 'true' | 'false' | undefined;
    readonly 'aria-controls'?: string | undefined;
    readonly 'aria-invalid'?: boolean | 'true' | 'false' | undefined;
    readonly 'aria-valuemin'?: number | undefined;
    readonly 'aria-valuemax'?: number | undefined;
    readonly 'aria-valuenow'?: number | undefined;
    readonly 'aria-atomic'?: boolean | 'true' | 'false' | undefined;
    readonly 'aria-disabled'?: boolean | 'true' | 'false' | undefined;
    readonly 'aria-pressed'?: boolean | 'true' | 'false' | undefined;
    readonly 'aria-selected'?: boolean | 'true' | 'false' | undefined;
    readonly 'aria-modal'?: boolean | 'true' | 'false' | undefined;
    readonly 'aria-haspopup'?: boolean | 'true' | 'false' | 'menu' | 'dialog' | undefined;
    readonly 'aria-required'?: boolean | 'true' | 'false' | undefined;
    readonly 'data-theme'?: string | undefined;
    readonly 'data-testid'?: string | undefined;
    readonly spellCheck?: boolean | undefined;
    readonly translate?: 'yes' | 'no' | undefined;
    readonly draggable?: boolean | undefined;
    readonly suppressHydrationWarning?: boolean | undefined;
    readonly dangerouslySetInnerHTML?: { readonly __html: string } | undefined;
  }

  interface AnchorHTMLAttributes<T = Element> extends HTMLAttributes<T> {
    readonly href?: string | undefined;
    readonly target?: string | undefined;
    readonly rel?: string | undefined;
    readonly download?: boolean | string | undefined;
    readonly type?: string | undefined;
  }

  interface ButtonHTMLAttributes<T = Element> extends HTMLAttributes<T> {
    readonly type?: 'button' | 'submit' | 'reset' | undefined;
    readonly disabled?: boolean | undefined;
    readonly name?: string | undefined;
    readonly value?: string | number | undefined;
    readonly form?: string | undefined;
    readonly formAction?: string | undefined;
  }

  interface InputHTMLAttributes<T = Element> extends HTMLAttributes<T> {
    readonly type?: string | undefined;
    readonly name?: string | undefined;
    readonly value?: string | number | readonly string[] | undefined;
    readonly defaultValue?: string | number | readonly string[] | undefined;
    readonly checked?: boolean | undefined;
    readonly defaultChecked?: boolean | undefined;
    readonly placeholder?: string | undefined;
    readonly required?: boolean | undefined;
    readonly disabled?: boolean | undefined;
    readonly readOnly?: boolean | undefined;
    readonly autoComplete?: string | undefined;
    readonly autoFocus?: boolean | undefined;
    readonly min?: number | string | undefined;
    readonly max?: number | string | undefined;
    readonly step?: number | string | undefined;
    readonly minLength?: number | undefined;
    readonly maxLength?: number | undefined;
    readonly pattern?: string | undefined;
    readonly inputMode?:
      | 'none'
      | 'text'
      | 'tel'
      | 'url'
      | 'email'
      | 'numeric'
      | 'decimal'
      | 'search'
      | undefined;
    readonly accept?: string | undefined;
    readonly multiple?: boolean | undefined;
    readonly form?: string | undefined;
  }

  interface TextareaHTMLAttributes<T = Element> extends HTMLAttributes<T> {
    readonly name?: string | undefined;
    readonly value?: string | number | readonly string[] | undefined;
    readonly defaultValue?: string | number | readonly string[] | undefined;
    readonly placeholder?: string | undefined;
    readonly required?: boolean | undefined;
    readonly disabled?: boolean | undefined;
    readonly readOnly?: boolean | undefined;
    readonly rows?: number | undefined;
    readonly cols?: number | undefined;
    readonly minLength?: number | undefined;
    readonly maxLength?: number | undefined;
    readonly autoComplete?: string | undefined;
    readonly form?: string | undefined;
  }

  interface SelectHTMLAttributes<T = Element> extends HTMLAttributes<T> {
    readonly name?: string | undefined;
    readonly value?: string | number | readonly string[] | undefined;
    readonly defaultValue?: string | number | readonly string[] | undefined;
    readonly required?: boolean | undefined;
    readonly disabled?: boolean | undefined;
    readonly multiple?: boolean | undefined;
    readonly size?: number | undefined;
    readonly form?: string | undefined;
  }

  interface SVGProps<T = Element> extends HTMLAttributes<T> {
    readonly viewBox?: string | undefined;
    readonly xmlns?: string | undefined;
    readonly width?: number | string | undefined;
    readonly height?: number | string | undefined;
    readonly fill?: string | undefined;
    readonly stroke?: string | undefined;
    readonly strokeWidth?: number | string | undefined;
    readonly strokeLinecap?: 'butt' | 'round' | 'square' | undefined;
    readonly strokeLinejoin?: 'miter' | 'round' | 'bevel' | undefined;
    readonly d?: string | undefined;
    readonly cx?: number | string | undefined;
    readonly cy?: number | string | undefined;
    readonly r?: number | string | undefined;
    readonly x?: number | string | undefined;
    readonly y?: number | string | undefined;
    readonly focusable?: boolean | 'true' | 'false' | undefined;
  }

  interface CSSProperties {
    readonly [property: string]: string | number | undefined;
  }

  /* ------------------------------- hooks --------------------------------- */

  type SetStateAction<S> = S | ((previous: S) => S);
  type Dispatch<A> = (value: A) => void;

  interface MutableRefObject<T> {
    current: T;
  }

  function useState<S>(initial: S | (() => S)): [S, Dispatch<SetStateAction<S>>];
  function useState<S = undefined>(): [S | undefined, Dispatch<SetStateAction<S | undefined>>];
  function useEffect(effect: () => void | (() => void), deps?: readonly unknown[]): void;
  function useLayoutEffect(effect: () => void | (() => void), deps?: readonly unknown[]): void;
  function useCallback<T extends (...args: never[]) => unknown>(fn: T, deps: readonly unknown[]): T;
  function useMemo<T>(factory: () => T, deps: readonly unknown[]): T;
  /**
   * The `useRef<T>(null)` overload comes FIRST, because it is what every DOM ref
   * in this codebase uses and the generic overload would otherwise infer
   * `T = null` and reject every later assignment.
   *
   * `current` is MUTABLE, matching React 19. A `readonly current` is right only
   * for refs React itself assigns; a ref holding a timer id is written by the
   * component, and `audit-runner.tsx` does exactly that.
   */
  function useRef<T>(initial: null): MutableRefObject<T | null>;
  function useRef<T>(initial: T): MutableRefObject<T>;
  function useRef<T = undefined>(): MutableRefObject<T | undefined>;
  function useId(): string;
  function useTransition(): [boolean, (callback: () => void) => void];
  function createElement(type: unknown, props?: unknown, ...children: unknown[]): ReactElement;

  const Suspense: FC<{ readonly children?: ReactNode; readonly fallback?: ReactNode }>;
  const Fragment: FC<{ readonly children?: ReactNode }>;
  const StrictMode: FC<{ readonly children?: ReactNode }>;
}

declare module 'react' {
  export = React;
}

declare module 'react/jsx-runtime' {
  export function jsx(type: unknown, props: unknown, key?: unknown): React.ReactElement;
  export function jsxs(type: unknown, props: unknown, key?: unknown): React.ReactElement;
  export const Fragment: unknown;
}

declare module 'react-dom/server' {
  export function renderToStaticMarkup(element: React.ReactNode): string;
  export function renderToString(element: React.ReactNode): string;
}

/**
 * The JSX namespace.
 *
 * `IntrinsicElements` is the documented gap: an index signature to `any`, so DOM
 * elements are not checked at all. Everything else here is what makes checking a
 * component's props work — `ElementAttributesProperty` and
 * `ElementChildrenAttribute` are how TypeScript learns which part of a component
 * signature is the props and which is the children.
 */
declare namespace JSX {
  interface Element extends React.ReactElement {}

  interface ElementClass {
    render(): React.ReactNode;
  }

  interface ElementAttributesProperty {
    props: unknown;
  }

  interface ElementChildrenAttribute {
    children: unknown;
  }

  interface IntrinsicAttributes {
    readonly key?: React.Key | undefined;
  }

  /**
   * THE GAP. See the header of this file.
   *
   * `any`, not `unknown`. `unknown` accepts no props at all, which turned every
   * `<div className=...>` in the codebase into an error on the first run — a
   * check that flags everything is a check nobody reads.
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  interface IntrinsicElements {
    [name: string]: any;
  }
}

/**
 * `next/link` — used only in `.tsx`, so it lives here rather than in
 * next-shims.d.ts, which serves the `.ts`-only check.
 *
 * `href` is REQUIRED, matching the real API. That is not pedantry: a `<Link>`
 * with no href is a dead control that still looks like a link, and it is exactly
 * the kind of thing a refactor leaves behind.
 */
declare module 'next/link' {
  // Extends the ANCHOR attributes, not the generic Element ones: a handler typed
  // `MouseEvent<HTMLAnchorElement>` — which is what every caller spreading anchor
  // props has — is not assignable to `MouseEvent<Element>`.
  interface LinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
    readonly href: string;
    readonly prefetch?: boolean | undefined;
    readonly replace?: boolean | undefined;
    readonly scroll?: boolean | undefined;
  }
  const Link: React.FC<LinkProps>;
  export default Link;
}

declare module 'next/image' {
  interface ImageProps extends React.HTMLAttributes<Element> {
    readonly src: string;
    /** Required by the real API, and the reason alt-text audits can be trusted. */
    readonly alt: string;
    readonly width?: number | undefined;
    readonly height?: number | undefined;
    readonly fill?: boolean | undefined;
    readonly priority?: boolean | undefined;
    readonly sizes?: string | undefined;
  }
  const Image: React.FC<ImageProps>;
  export default Image;
}

/**
 * Stylesheet side-effect imports.
 *
 * `import './globals.css'` is handled by the bundler, not by TypeScript. The
 * real build has this via `next-env.d.ts`; offline it needs declaring, or the
 * root layout reports a missing module that is not missing.
 */
declare module '*.css';
