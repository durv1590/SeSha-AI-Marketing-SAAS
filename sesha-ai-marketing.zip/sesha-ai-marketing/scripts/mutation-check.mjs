#!/usr/bin/env node
/**
 * Mutation check — does the test suite actually bite?
 *
 * WHY THIS EXISTS
 * A passing test suite proves the tests pass. It does not prove they would
 * notice if the code were wrong. Phase 7 added the modules where "looks tested"
 * and "is tested" differ most: a quota gate that always allows, a webhook that
 * trusts any signature, an admin guard that answers 403 instead of 404 — each
 * would leave 1,900 green tests if nothing asserted the specific behaviour.
 *
 * HOW IT WORKS
 * For each mutation below: apply one small, deliberate change to one source
 * file, run only the test files that should care, and restore the file. A
 * mutation that leaves those tests passing is reported as SURVIVED — the suite
 * has a hole exactly there, and the hole is the finding.
 *
 * Every mutation is chosen to be a plausible mistake or a plausible malicious
 * edit, not a syntax error. "Delete a line at random" proves nothing.
 *
 * Usage: node scripts/mutation-check.mjs [--only <id>]
 */

import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

/**
 * Each mutation: what it breaks, and which tests are supposed to scream.
 *
 * `find` must match exactly once in the file — a mutation that silently applies
 * to the wrong place, or to nothing, is worse than no mutation, so that is
 * checked before anything is run.
 */
const MUTATIONS = [
  {
    id: 'quota-always-allows',
    file: 'src/lib/quota/index.ts',
    why: 'The quota gate stops refusing. Every limit becomes decorative.',
    find: '  if (context.used + amount > limit.value) {',
    replace: '  if (false) {',
    tests: ['tests/quota.test.ts', 'tests/phase7-services.test.ts', 'tests/phase7-gate.test.ts'],
  },
  {
    id: 'quota-off-by-one',
    file: 'src/lib/quota/index.ts',
    why: 'One more request than the plan allows gets through. The classic off-by-one.',
    find: '  if (context.used + amount > limit.value) {',
    replace: '  if (context.used + amount > limit.value + 1) {',
    tests: ['tests/quota.test.ts', 'tests/phase7-services.test.ts'],
  },
  {
    id: 'quota-zero-is-mislabelled',
    file: 'src/lib/quota/index.ts',
    why: 'A feature not included in the plan is reported as a spent monthly allowance, so the customer is told to wait for a reset that will never grant it.',
    // Anchored on the line that follows, because `limit.value === 0` appears in
    // both checkLimit and limitStatus and a mutation must know which it broke.
    find: "      reason: 'not_included',",
    replace: "      reason: 'period_exhausted',",
    tests: ['tests/quota.test.ts', 'tests/phase7-services.test.ts', 'tests/phase7-gate.test.ts'],
  },
  {
    id: 'webhook-trusts-anyone',
    file: 'src/lib/billing/types.ts',
    why: 'The null provider verifies any signature. Anyone who can POST can grant themselves the Agency plan.',
    find: '  verifyWebhook: () => false,',
    replace: '  verifyWebhook: () => true,',
    tests: ['tests/billing.test.ts', 'tests/phase7-services.test.ts', 'tests/phase7-gate.test.ts'],
  },
  {
    id: 'past-due-revokes-reading',
    file: 'src/lib/billing/types.ts',
    why: 'A failed payment takes away read access — holding a customer’s own work hostage over a bank decline.',
    // `readable: true` appears seven times in this file, so the past-due branch
    // is anchored by the first words of its own reason string.
    find: [
      '        readable: true,',
      '        writable: false,',
      '        reason: `The last payment has been outstanding',
    ].join('\n'),
    replace: [
      '        readable: false,',
      '        writable: false,',
      '        reason: `The last payment has been outstanding',
    ].join('\n'),
    tests: ['tests/billing.test.ts', 'tests/phase7-gate.test.ts'],
  },
  {
    id: 'admin-answers-403',
    file: 'src/lib/admin/auth.ts',
    why: 'The admin API tells a stranger it exists. A 403 confirms there is a panel worth attacking.',
    // This mutation is the reason `adminRefusal` exists as a separate function.
    // It first ran against the guard itself and SURVIVED: the suite asserted the
    // decision and never the response, so the mapping was extracted to where a
    // test can reach it.
    find: "  return { status: 404, message: ADMIN_NOT_FOUND_MESSAGE, needsSudo: false };",
    replace: "  return { status: 403, message: access.message, needsSudo: false };",
    tests: ['tests/admin-security.test.ts', 'tests/phase7-gate.test.ts'],
  },
  {
    id: 'admin-leaks-the-role-it-wanted',
    file: 'src/lib/admin/auth.ts',
    why: 'The 404 body starts naming the role required, so a prober learns both that the endpoint exists and who can reach it.',
    find: "  return { status: 404, message: ADMIN_NOT_FOUND_MESSAGE, needsSudo: false };",
    replace: "  return { status: 404, message: access.message, needsSudo: false };",
    tests: ['tests/admin-security.test.ts'],
  },
  {
    id: 'revoked-staff-still-staff',
    file: 'src/lib/admin/auth.ts',
    why: 'A revoked staff row keeps working until the session expires — up to thirty days of access after it was taken away.',
    find: '  if (row.revokedAt !== null) return null;',
    replace: '  if (false) return null;',
    tests: ['tests/admin-security.test.ts', 'tests/phase7-services.test.ts', 'tests/phase7-gate.test.ts'],
  },
  {
    id: 'writes-need-no-sudo',
    file: 'src/lib/admin/auth.ts',
    why: 'Admin changes stop requiring a recent sign-in. A borrowed laptop becomes a platform takeover.',
    find: '  if (requiresSudo(permission) && !staff.sudo) {',
    replace: '  if (false) {',
    tests: ['tests/admin-security.test.ts', 'tests/phase7-services.test.ts'],
  },
  {
    id: 'flag-kill-switch-ignored',
    file: 'src/lib/flags/index.ts',
    why: 'The kill switch stops winning. A flag turned off for everyone is still on for named accounts.',
    find: '  if (rule?.disabled) {',
    replace: '  if (false) {',
    tests: ['tests/flags.test.ts', 'tests/phase7-services.test.ts'],
  },
  {
    id: 'override-accepts-nonsense',
    file: 'src/lib/plans/resolve.ts',
    why: 'A negative stored override is applied instead of ignored, so a limit of -1 refuses everything forever.',
    find: '  if (value < 0) return undefined;',
    replace: '  if (false) return undefined;',
    tests: ['tests/plans.test.ts', 'tests/phase7-gate.test.ts'],
  },
  {
    id: 'legacy-plan-unreadable',
    file: 'src/content/plans.ts',
    why: 'A subscription still stored under its old plan name stops resolving, and the account silently drops to free.',
    find: '    return LEGACY_PLAN_MAP[value as LegacyPlanId];',
    replace: '    return null;',
    tests: ['tests/plans.test.ts', 'tests/phase7-gate.test.ts'],
  },
  {
    id: 'audit-records-nothing',
    file: 'src/lib/admin/service.ts',
    why: 'Admin actions stop being recorded. Everything still works and nobody can ever say who did what.',
    find: '      await context.db.adminActions.record({',
    replace: '      if (false) await context.db.adminActions.record({',
    tests: ['tests/admin-security.test.ts', 'tests/phase7-services.test.ts'],
  },
  {
    id: 'slowloris-defeats-the-crawler',
    file: 'src/lib/crawler/fetcher.ts',
    why: 'The wall-clock timeout goes away and only the socket-idle timer is left, so a server trickling one byte at a time holds a crawl worker open forever. This is the hole Phase 8 found: the file header had promised the wall clock since Phase 4 and it was never there.',
    find: '    }, req.timeoutMs);',
    replace: '    }, 24 * 60 * 60 * 1000);',
    tests: ['tests/crawler-transport.test.ts'],
  },
  {
    id: 'reaper-throws-away-retryable-work',
    file: 'src/lib/crawl/service.ts',
    why: 'The reaper goes back to failing every stale job on sight. A deploy that rolls workers mid-crawl then fails every customer crawl in flight, even though a retry would have succeeded.',
    find: '    if (job.attempts < MAX_ATTEMPTS) {',
    replace: '    if (false) {',
    tests: ['tests/jobs.test.ts'],
  },
  {
    id: 'reaper-cycles-a-poison-job-forever',
    file: 'src/lib/crawl/service.ts',
    why: 'The attempts bound goes away, so a job that kills its worker is requeued forever and takes down every worker that picks it up in turn.',
    find: '    if (job.attempts < MAX_ATTEMPTS) {',
    replace: '    if (true) {',
    tests: ['tests/jobs.test.ts'],
  },
  {
    id: 'revocation-only-writes-the-marker',
    file: 'src/lib/workspace/service.ts',
    why: 'Consent revocation records that the data was deleted without deleting it — exactly the state Phase 8 found it in.',
    find: '    for (const crawl of crawls) pagesDeleted += await context.db.crawls.deletePages(crawl.id);',
    replace: '    void crawls;',
    tests: ['tests/jobs.test.ts'],
  },
  {
    id: 'redactor-stops-at-the-first-token',
    file: 'src/lib/observability/log.ts',
    why: 'The Bearer pattern loses its global flag, so a log line carrying two tokens redacts the first and writes the second in the clear — the state Phase 8 found it in.',
    find: '  /\\bBearer\\s+[A-Za-z0-9._~+/-]{12,}/gi,',
    replace: '  /\\bBearer\\s+[A-Za-z0-9._~+/-]{12,}/i,',
    tests: ['tests/phase8-gate.test.ts'],
  },
  {
    id: 'ai-breaker-counts-refusals-as-outages',
    file: 'src/lib/ai/orchestrator.ts',
    why: 'Every AI error, including one customer\'s filtered prompt, counts against the provider breaker, so seven refusals take AI down for every tenant for thirty seconds.',
    find: '!(error instanceof AiError) || OUTAGE_CODES.has(error.code),',
    replace: 'true,',
    tests: ['tests/failure-recovery.test.ts'],
  },
  {
    id: 'address-pin-returns-a-bare-string',
    file: 'src/lib/crawler/fetcher.ts',
    why: 'The DNS pin reverts to the single-address callback form. Node calls the hook with `{all: true}`, so every crawl of a real hostname dies with ERR_INVALID_IP_ADDRESS — which is exactly how the pin was found never to have run.',
    find: '          if (options?.all) {',
    replace: '          if (false) {',
    tests: ['tests/crawler-transport.test.ts'],
  },
  {
    id: 'narrow-only-ignored',
    file: 'src/lib/admin/settings.ts',
    why: 'The crawler ceiling can be RAISED from a form, so one setting change makes SeSha crawl harder than its own published policy.',
    find: "      if (definition.narrowOnly === 'lower' && typeof definition.defaultValue === 'number') {",
    replace: '      if (false) {',
    tests: ['tests/admin-security.test.ts', 'tests/phase7-services.test.ts'],
  },
];

const args = process.argv.slice(2);
const onlyIndex = args.indexOf('--only');
const only = onlyIndex > -1 ? args[onlyIndex + 1] : null;
const selected = only ? MUTATIONS.filter((m) => m.id === only) : MUTATIONS;

if (selected.length === 0) {
  console.error(only ? `No mutation called "${only}".` : 'No mutations.');
  process.exit(1);
}

/**
 * LEFTOVER CHECK, before anything else.
 *
 * If a previous run was killed between the write and the restore, a mutated
 * source is sitting on disk right now — and every subsequent run would happily
 * mutate and restore *around* it, reporting green while the codebase carries a
 * deliberate defect. That happened in Phase 8 and cost a confusing half hour:
 * the signal handlers below were added in response, and this is the belt to
 * their braces, because a `SIGKILL` runs no handler at all.
 *
 * A mutation's `replace` text present in its file, when its `find` text is not,
 * means exactly one thing.
 */
const leftovers = [];
for (const mutation of MUTATIONS) {
  const file = path.join(root, mutation.file);
  if (!existsSync(file)) continue;
  const source = readFileSync(file, 'utf8');
  if (!source.includes(mutation.find) && source.includes(mutation.replace)) {
    leftovers.push(`${mutation.id}: "${mutation.replace.trim().slice(0, 60)}" in ${mutation.file}`);
  }
}
if (leftovers.length > 0) {
  console.error('A PREVIOUS RUN LEFT A MUTATION IN THE SOURCE. Restore before continuing:\n');
  for (const line of leftovers) console.error(`  ${line}`);
  console.error('\nThese are deliberate defects, not code. Revert them.');
  process.exit(1);
}

// Check every mutation applies exactly once BEFORE running anything. A stale
// `find` string would silently test nothing and report a pass.
const stale = [];
for (const mutation of selected) {
  const file = path.join(root, mutation.file);
  const source = readFileSync(file, 'utf8');
  const count = source.split(mutation.find).length - 1;
  if (count !== 1) stale.push(`${mutation.id}: matches ${count} times in ${mutation.file}`);
}
if (stale.length > 0) {
  console.error('Mutation targets are out of date — the code moved:\n');
  for (const line of stale) console.error(`  ${line}`);
  console.error('\nUpdate scripts/mutation-check.mjs rather than ignoring this.');
  process.exit(1);
}

function runTests(files) {
  try {
    execFileSync(
      'node',
      ['--import', 'tsx', '--test', ...files],
      { cwd: root, stdio: 'pipe', timeout: 300_000 },
    );
    return true; // tests passed
  } catch {
    return false; // tests failed — the mutation was caught
  }
}

/**
 * Restore-on-signal.
 *
 * `finally` does NOT run when the process is killed, so a `timeout`, a Ctrl-C or
 * a CI cancellation between the write and the restore leaves a MUTATED source
 * file on disk — which is about the worst thing a tool like this can do. That
 * happened once during Phase 8: a run was killed mid-mutation and left the
 * crawler's wall-clock timeout set to 24 hours.
 *
 * `inFlight` holds the one file currently mutated and its original bytes, and
 * every exit path restores it.
 */
let inFlight = null;

function restoreInFlight() {
  if (!inFlight) return;
  writeFileSync(inFlight.file, inFlight.original);
  inFlight = null;
}

for (const signal of ['SIGINT', 'SIGTERM', 'SIGHUP']) {
  process.on(signal, () => {
    restoreInFlight();
    console.error(`\nInterrupted by ${signal} — source restored.`);
    process.exit(130);
  });
}
process.on('uncaughtException', (error) => {
  restoreInFlight();
  console.error('\nUncaught exception — source restored.');
  throw error;
});
process.on('exit', restoreInFlight);

console.log(`Mutation check — ${selected.length} mutation(s)\n`);

const survived = [];
const killed = [];

for (const mutation of selected) {
  const file = path.join(root, mutation.file);
  const original = readFileSync(file, 'utf8');
  process.stdout.write(`  ${mutation.id.padEnd(28)} `);

  try {
    inFlight = { file, original };
    writeFileSync(file, original.replace(mutation.find, mutation.replace));
    const passed = runTests(mutation.tests.map((t) => path.join(root, t)));
    if (passed) {
      survived.push(mutation);
      console.log('SURVIVED  ← the suite does not notice');
    } else {
      killed.push(mutation);
      console.log('killed');
    }
  } finally {
    // ALWAYS restore. The signal handlers above cover the case where this block
    // never gets to run at all.
    writeFileSync(file, original);
    inFlight = null;
  }
}

console.log('');
if (survived.length === 0) {
  console.log(`PASS — all ${killed.length} mutations were caught by the tests.`);
  process.exit(0);
}

console.log(`FAIL — ${survived.length} of ${selected.length} mutations survived:\n`);
for (const mutation of survived) {
  console.log(`  ${mutation.id}`);
  console.log(`    ${mutation.file}`);
  console.log(`    ${mutation.why}`);
  console.log(`    tests run: ${mutation.tests.join(', ')}\n`);
}
process.exit(1);
