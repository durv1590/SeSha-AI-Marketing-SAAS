#!/usr/bin/env node
/**
 * Static verification pass.
 *
 * WHY THIS EXISTS
 * The environment this project was built in has no access to the npm registry,
 * so `next build` and `tsc --noEmit` could not be run during development. This
 * script recovers the checks that do not need installed type definitions, using
 * the TypeScript compiler's own parser:
 *
 *   1. Syntax — every .ts/.tsx file parses cleanly.
 *   2. Module resolution — every relative and "@/" import resolves to a file
 *      that exists.
 *   3. Named exports — every named import actually exists in the target module
 *      (following `export *` re-exports).
 *   4. React Server Component rules — any file using hooks or DOM event props
 *      must carry the "use client" directive, and a client component must not
 *      import a server-only module.
 *   5. Next.js conventions — every route directory has the right default export.
 *
 * It does NOT replace `tsc --noEmit`: it cannot check types, only structure.
 * Run `npm run verify` once dependencies are installed for the real thing.
 *
 * Usage: node scripts/verify-static.mjs
 */

import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const ts = require('typescript');

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const srcDir = path.join(root, 'src');

const problems = [];
const notes = [];

function fail(file, message) {
  problems.push(`${path.relative(root, file)}: ${message}`);
}

function walk(dir) {
  const out = [];
  for (const entry of readdirSync(dir)) {
    if (entry === 'node_modules' || entry.startsWith('.')) continue;
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) out.push(...walk(full));
    else if (/\.(ts|tsx)$/.test(entry)) out.push(full);
  }
  return out;
}

const files = walk(srcDir);
const sources = new Map();

/* -------------------------------------------------------------------------- */
/* 1. Parse                                                                   */
/* -------------------------------------------------------------------------- */

for (const file of files) {
  const text = readFileSync(file, 'utf8');
  const source = ts.createSourceFile(
    file,
    text,
    ts.ScriptTarget.ES2022,
    /* setParentNodes */ true,
    file.endsWith('.tsx') ? ts.ScriptKind.TSX : ts.ScriptKind.TS,
  );
  sources.set(file, { source, text });

  // `parseDiagnostics` is internal but stable, and is the only way to surface
  // syntax errors without a full Program (which would need type definitions).
  const diagnostics = source.parseDiagnostics ?? [];
  for (const diagnostic of diagnostics) {
    const { line, character } = source.getLineAndCharacterOfPosition(diagnostic.start ?? 0);
    fail(file, `syntax error at ${line + 1}:${character + 1} — ${ts.flattenDiagnosticMessageText(diagnostic.messageText, ' ')}`);
  }
}

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

const EXTERNAL = new Set(['react', 'react-dom', 'next', 'clsx', 'tailwind-merge']);

function isExternal(specifier) {
  if (specifier.startsWith('.') || specifier.startsWith('@/')) return false;
  if (specifier.startsWith('node:')) return true;
  const pkg = specifier.startsWith('@')
    ? specifier.split('/').slice(0, 2).join('/')
    : specifier.split('/')[0];
  if (EXTERNAL.has(pkg) || specifier.startsWith('next/') || specifier.startsWith('react-dom/')) {
    return true;
  }
  notes.push(`unlisted external dependency "${specifier}" — confirm it is in package.json`);
  return true;
}

function resolveSpecifier(fromFile, specifier) {
  const base = specifier.startsWith('@/')
    ? path.join(srcDir, specifier.slice(2))
    : path.resolve(path.dirname(fromFile), specifier);

  const candidates = [
    `${base}.ts`,
    `${base}.tsx`,
    path.join(base, 'index.ts'),
    path.join(base, 'index.tsx'),
    base,
  ];
  for (const candidate of candidates) {
    try {
      if (statSync(candidate).isFile()) return candidate;
    } catch {
      /* keep looking */
    }
  }
  return null;
}

/** Collects every exported name from a parsed module, following `export *`. */
const exportCache = new Map();

function exportedNames(file, seen = new Set()) {
  if (exportCache.has(file)) return exportCache.get(file);
  if (seen.has(file)) return new Set();
  seen.add(file);

  const entry = sources.get(file);
  if (!entry) return new Set();

  const names = new Set();

  for (const statement of entry.source.statements) {
    const modifiers = ts.canHaveModifiers(statement) ? (ts.getModifiers(statement) ?? []) : [];
    const isExported = modifiers.some((m) => m.kind === ts.SyntaxKind.ExportKeyword);
    const isDefault = modifiers.some((m) => m.kind === ts.SyntaxKind.DefaultKeyword);

    if (isExported) {
      if (isDefault) names.add('default');
      if (ts.isFunctionDeclaration(statement) || ts.isClassDeclaration(statement)) {
        if (statement.name) names.add(statement.name.text);
      } else if (ts.isVariableStatement(statement)) {
        for (const declaration of statement.declarationList.declarations) {
          if (ts.isIdentifier(declaration.name)) names.add(declaration.name.text);
          else if (ts.isObjectBindingPattern(declaration.name)) {
            for (const element of declaration.name.elements) {
              if (ts.isIdentifier(element.name)) names.add(element.name.text);
            }
          }
        }
      } else if (
        ts.isInterfaceDeclaration(statement) ||
        ts.isTypeAliasDeclaration(statement) ||
        ts.isEnumDeclaration(statement)
      ) {
        names.add(statement.name.text);
      }
    }

    if (ts.isExportDeclaration(statement)) {
      if (statement.exportClause && ts.isNamedExports(statement.exportClause)) {
        for (const element of statement.exportClause.elements) names.add(element.name.text);
      } else if (statement.moduleSpecifier && ts.isStringLiteral(statement.moduleSpecifier)) {
        // export * from '...'
        const target = resolveSpecifier(file, statement.moduleSpecifier.text);
        if (target) for (const name of exportedNames(target, seen)) names.add(name);
      }
    }

    if (ts.isExportAssignment(statement)) names.add('default');
  }

  exportCache.set(file, names);
  return names;
}

/* -------------------------------------------------------------------------- */
/* 2 + 3. Imports resolve, and named imports exist                            */
/* -------------------------------------------------------------------------- */

for (const [file, { source }] of sources) {
  for (const statement of source.statements) {
    if (!ts.isImportDeclaration(statement)) continue;
    if (!ts.isStringLiteral(statement.moduleSpecifier)) continue;

    const specifier = statement.moduleSpecifier.text;
    if (isExternal(specifier)) continue;

    const target = resolveSpecifier(file, specifier);
    if (!target) {
      fail(file, `import "${specifier}" does not resolve to a file`);
      continue;
    }

    const clause = statement.importClause;
    if (!clause) continue;

    // `import type { X }` is erased at build time but must still exist.
    const available = exportedNames(target);

    if (clause.name && !available.has('default')) {
      fail(file, `"${specifier}" has no default export (imported as ${clause.name.text})`);
    }

    if (clause.namedBindings && ts.isNamedImports(clause.namedBindings)) {
      for (const element of clause.namedBindings.elements) {
        const imported = (element.propertyName ?? element.name).text;
        if (!available.has(imported)) {
          fail(file, `"${specifier}" does not export "${imported}"`);
        }
      }
    }
  }
}

/* -------------------------------------------------------------------------- */
/* 4. React Server Component rules                                            */
/* -------------------------------------------------------------------------- */

const HOOK_PATTERN = /\b(useState|useEffect|useLayoutEffect|useRef|useReducer|useCallback|useMemo|useId|useContext|useTransition|useOptimistic|useFormStatus)\s*[(<]/;
const EVENT_PROP_PATTERN = /\son(Click|Change|Submit|Input|Focus|Blur|KeyDown|KeyUp|MouseEnter|MouseLeave|PointerDown)=\{/;
const BROWSER_GLOBAL_PATTERN = /\b(window|document|localStorage|navigator)\./;

function hasUseClient(text) {
  return /^\s*['"]use client['"]\s*;?/m.test(text.split('\n').slice(0, 5).join('\n'));
}

for (const [file, { text, source }] of sources) {
  const relative = path.relative(root, file);
  const isClient = hasUseClient(text);

  // Strip comments before pattern matching, so a hook named in a comment does
  // not trip the rule.
  const code = text
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|\s)\/\/[^\n]*/g, '$1');

  // For the browser-global check, strip string and template literals too:
  // prose like "paste a JSON-LD document." must not read as `document.`.
  const codeWithoutLiterals = code
    .replace(/`(?:\\[\s\S]|\$\{[^}]*\}|[^`\\])*`/g, '``')
    .replace(/'(?:\\[\s\S]|[^'\\\n])*'/g, "''")
    .replace(/"(?:\\[\s\S]|[^"\\\n])*"/g, '""');

  const usesHooks = HOOK_PATTERN.test(code);
  const usesEvents = EVENT_PROP_PATTERN.test(code);

  if ((usesHooks || usesEvents) && !isClient) {
    // The theme module exports a string containing browser code for inlining;
    // that is data, not execution, so it is exempt when it has no hooks.
    fail(
      file,
      `uses ${usesHooks ? 'React hooks' : 'DOM event handlers'} but is missing the "use client" directive`,
    );
  }

  if (isClient) {
    // Checked against the AST, not the text, so that a TYPE-ONLY import is not
    // flagged: `import type { Row } from '@/lib/db/types'` is erased at build
    // time and pulls no server code into the client bundle. A value import from
    // the same module is a real problem.
    const SERVER_ONLY = ['@/lib/db', '@/lib/api/respond', '@/lib/auth/current-session', 'next/server'];

    for (const statement of source.statements) {
      if (!ts.isImportDeclaration(statement)) continue;
      if (!ts.isStringLiteral(statement.moduleSpecifier)) continue;

      const specifier = statement.moduleSpecifier.text;
      const matched = SERVER_ONLY.find((m) => specifier === m || specifier.startsWith(`${m}/`));
      if (!matched) continue;

      const clause = statement.importClause;
      // `import type { ... }` or `import type X`
      if (clause?.isTypeOnly) continue;

      // `import { type A, type B }` — every named binding marked type-only.
      const named = clause?.namedBindings;
      if (
        named &&
        ts.isNamedImports(named) &&
        !clause.name &&
        named.elements.every((element) => element.isTypeOnly)
      ) {
        continue;
      }

      fail(file, `client component imports server-only module "${specifier}" as a value`);
    }
  }

  // Browser globals at module scope crash during server rendering.
  if (!isClient && BROWSER_GLOBAL_PATTERN.test(codeWithoutLiterals)) {
    const insideFunction = /=>\s*\{[\s\S]*?(window|document|localStorage|navigator)\./.test(
      codeWithoutLiterals,
    );
    if (!insideFunction) {
      fail(file, 'references a browser global in a server component');
    }
  }

  void relative;
}

/* -------------------------------------------------------------------------- */
/* 5. Next.js route conventions                                               */
/* -------------------------------------------------------------------------- */

for (const [file, { source, text }] of sources) {
  const base = path.basename(file);
  // Scoped to src/app: these are Next.js conventions about a file's LOCATION,
  // not its name. `lib/crawler/robots.ts` is a robots.txt parser and owes
  // nothing to the routing convention.
  const inAppDirectory = path.relative(root, file).split(path.sep).slice(0, 2).join('/') === 'src/app';
  const isRouteFile =
    inAppDirectory &&
    ['page.tsx', 'layout.tsx', 'not-found.tsx', 'sitemap.ts', 'robots.ts'].includes(base);

  if (isRouteFile) {
    const hasDefault = source.statements.some((statement) => {
      const modifiers = ts.canHaveModifiers(statement) ? (ts.getModifiers(statement) ?? []) : [];
      return modifiers.some((m) => m.kind === ts.SyntaxKind.DefaultKeyword);
    });
    if (!hasDefault) fail(file, `${base} must have a default export`);
  }

  if (base === 'route.ts') {
    if (!/export\s+(async\s+)?function\s+(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\b/.test(text)) {
      fail(file, 'route.ts exports no HTTP method handler');
    }
  }

  if (base === 'page.tsx') {
    const hasMetadata = /export\s+(const\s+metadata|async\s+function\s+generateMetadata)/.test(text);
    if (!hasMetadata) fail(file, 'page has no metadata export — every page must declare SEO metadata');
  }

  // `Field` takes a RENDER PROP, not child elements: it calls children({ id,
  // describedBy, invalid }) so that the <label> and the control are genuinely
  // bound. Passing elements instead type-checks under our offline harness (.tsx
  // is not covered by tsc here) and then throws "children is not a function" the
  // first time the screen is rendered. Eighteen such usages were found at once in
  // Phase 6 — thirteen of them shipped in earlier phases, on screens the render
  // audit did not reach. This check is cheap and stops it recurring.
  if (/\bfrom '@\/components\/ui\/field'/.test(text)) {
    // Finding the end of a <Field …> opening tag needs a real scan, not a regex:
    // an attribute like hint={list.find((f) => f.id === x)?.note} contains a ">"
    // inside a JSX expression, and the first version of this check reported that
    // perfectly correct usage as broken. A check that cries wolf gets deleted.
    for (let index = text.indexOf('<Field'); index !== -1; index = text.indexOf('<Field', index + 1)) {
      if (/[A-Za-z]/.test(text[index + 6] ?? '')) continue; // <FieldSet, etc.
      let cursor = index + 6;
      let braces = 0;
      let selfClosing = false;
      while (cursor < text.length) {
        const character = text[cursor];
        if (character === '{') braces += 1;
        else if (character === '}') braces -= 1;
        else if (character === '>' && braces === 0) {
          selfClosing = text[cursor - 1] === '/';
          break;
        }
        cursor += 1;
      }
      const opening = text.slice(index, cursor);
      const line = text.slice(0, index).split('\n').length;

      if (!/\sid=/.test(opening)) {
        fail(file, `line ${line}: <Field> has no id, so its <label for> points at nothing.`);
      }
      if (selfClosing) continue;

      const rest = text.slice(cursor + 1);
      const firstChild = rest.replace(/^\s+/, '')[0];
      if (firstChild !== '{') {
        fail(
          file,
          `line ${line}: <Field> is given child elements. It takes a render prop — {({ id }) => <Input id={id} … />} — or the control is never bound to its label and the component throws at render.`,
        );
      }
    }
  }
}

/* -------------------------------------------------------------------------- */
/* Report                                                                     */
/* -------------------------------------------------------------------------- */

const uniqueNotes = [...new Set(notes)];

console.log(`Static verification — ${files.length} source files\n`);

if (uniqueNotes.length > 0) {
  console.log('Notes:');
  for (const note of uniqueNotes) console.log(`  · ${note}`);
  console.log('');
}

if (problems.length === 0) {
  console.log('PASS — no syntax errors, unresolved imports, missing exports or RSC violations.');
  process.exit(0);
}

console.log(`FAIL — ${problems.length} problem${problems.length === 1 ? '' : 's'}:\n`);
for (const problem of problems) console.log(`  ✗ ${problem}`);
process.exit(1);
