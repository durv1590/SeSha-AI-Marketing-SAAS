#!/usr/bin/env node
/**
 * Offline type check for `.tsx` — components and pages.
 *
 * WHAT THIS IS
 * A real `tsc` run over every `.tsx` file in the codebase, using the project's
 * real strict settings, against the narrow React and JSX declarations in
 * `scripts/types/react-shims.d.ts`. It is a SEPARATE script from
 * `typecheck.mjs` on purpose: that one is unqualified — within the files it
 * covers, it *is* type checking. This one is qualified, and conflating them
 * would let the qualification get lost.
 *
 * WHAT IT CATCHES — the highest-value category, and the one that has actually
 * bitten this project:
 *
 *   · wrong, misspelled or missing props on a component defined in this codebase;
 *   · a `children` shape that does not match — including a render prop passed
 *     child elements instead, which is the exact Phase 6 `Field` bug that
 *     shipped in thirteen places across three phases before anything noticed;
 *   · a component used with the wrong prop TYPES;
 *   · page and layout signatures, including the Next 15 promise-shaped
 *     `params` and `searchParams`.
 *
 * WHAT IT DOES NOT CATCH
 * Intrinsic DOM elements. `JSX.IntrinsicElements` is an index signature to
 * `any`, because typing every HTML and SVG attribute by hand would produce
 * false errors on everything I failed to anticipate, and a check that cries
 * wolf gets switched off. So `<div clasName="x">` still passes here, and only
 * `npm run build` will catch it.
 *
 * A GREEN RUN HERE IS NOT A GREEN BUILD. It narrows the gap; it does not close
 * it. `README.md` states the same thing in the same words, deliberately.
 *
 * Requires: node_modules/@types/node (scripts/sandbox-setup.mjs links it).
 * Usage: node scripts/typecheck-tsx.mjs
 */

import { createRequire } from 'node:module';
import { existsSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const ts = require('typescript');

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

if (!existsSync(path.join(root, 'node_modules', '@types', 'node'))) {
  console.error('No node_modules/@types/node — run: node scripts/sandbox-setup.mjs');
  process.exit(1);
}

function walk(dir, out = []) {
  if (!existsSync(dir)) return out;
  for (const entry of readdirSync(dir)) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) walk(full, out);
    else if (entry.endsWith('.tsx')) out.push(full);
  }
  return out;
}

const tsxFiles = [...walk(path.join(root, 'src'))].sort();

// The `.tsx` files import from `.ts` ones, so the whole program is loaded; only
// the diagnostics BELONGING to a .tsx file are reported here, because the .ts
// ones are already covered — unqualified — by scripts/typecheck.mjs.
const files = [
  ...tsxFiles,
  path.join(root, 'scripts', 'types', 'next-shims.d.ts'),
  path.join(root, 'scripts', 'types', 'react-shims.d.ts'),
];

const options = {
  target: ts.ScriptTarget.ES2022,
  lib: ['lib.dom.d.ts', 'lib.dom.iterable.d.ts', 'lib.es2022.d.ts'],
  module: ts.ModuleKind.ESNext,
  moduleResolution: ts.ModuleResolutionKind.Bundler,
  // The project's real strictness. Loosening any of these here would make the
  // run green without making the code correct.
  strict: true,
  noUncheckedIndexedAccess: true,
  noImplicitOverride: true,
  noFallthroughCasesInSwitch: true,
  forceConsistentCasingInFileNames: true,
  esModuleInterop: true,
  resolveJsonModule: true,
  skipLibCheck: true,
  noEmit: true,
  // `preserve` matches tsconfig.json and makes TypeScript resolve JSX against
  // the global `JSX` namespace declared in react-shims.d.ts.
  jsx: ts.JsxEmit.Preserve,
  types: ['node'],
  paths: { '@/*': [path.join(root, 'src', '*')] },
};

console.log(
  `Type check (.tsx) — ${tsxFiles.length} component and page files (strict, noUncheckedIndexedAccess)\n`,
);

const program = ts.createProgram(files, options);
const all = [
  ...program.getSyntacticDiagnostics(),
  ...program.getSemanticDiagnostics(),
  ...program.getGlobalDiagnostics(),
];

// Only .tsx diagnostics. A diagnostic in a .ts file is either already reported
// by typecheck.mjs or is an artefact of the shim, and reporting it twice trains
// people to skim.
const inTsx = all.filter((d) => d.file?.fileName.endsWith('.tsx'));

/**
 * Is this diagnostic a KNOWN consequence of the intrinsic-element gap?
 *
 * `onChange={(event) => ...}` on a `<textarea>` has no inferable parameter type
 * when `JSX.IntrinsicElements` is `any`, so `noImplicitAny` fires (TS7006). In a
 * real build with `@types/react` the parameter is inferred correctly and there is
 * no error at all.
 *
 * These are reported SEPARATELY rather than suppressed, and separately rather
 * than failed on. Failing would mean this check can never go green, and a check
 * that is always red is a check nobody runs. Suppressing silently would mean the
 * gap stops being visible. Neither is acceptable; naming them is.
 *
 * The test is narrow on purpose: code 7006 AND the node sits inside a JSX
 * attribute. An implicit `any` anywhere else in a .tsx file is a real error and
 * still fails the run.
 */
function isIntrinsicGapArtefact(diagnostic) {
  if (diagnostic.code !== 7006) return false;
  const source = diagnostic.file;
  if (!source || diagnostic.start === undefined) return false;

  let node = findNode(source, diagnostic.start);
  while (node) {
    if (node.kind === ts.SyntaxKind.JsxAttribute) return true;
    // Stop at the enclosing function: an implicit any in a plain callback that
    // merely happens to live inside a component is a real finding.
    if (
      node.kind === ts.SyntaxKind.FunctionDeclaration ||
      node.kind === ts.SyntaxKind.MethodDeclaration
    ) {
      return false;
    }
    node = node.parent;
  }
  return false;
}

function findNode(node, position) {
  if (position < node.getFullStart() || position >= node.getEnd()) return undefined;
  for (const child of node.getChildren()) {
    const found = findNode(child, position);
    if (found) return found;
  }
  return node;
}

const gapArtefacts = inTsx.filter(isIntrinsicGapArtefact);
const diagnostics = inTsx.filter((d) => !isIntrinsicGapArtefact(d));

function reportGap() {
  if (gapArtefacts.length === 0) return;
  console.log(
    `\nNot counted — ${gapArtefacts.length} uninferable JSX event parameter${
      gapArtefacts.length === 1 ? '' : 's'
    }:`,
  );
  for (const diagnostic of gapArtefacts) {
    const { line } = diagnostic.file.getLineAndCharacterOfPosition(diagnostic.start);
    console.log(`  ${path.relative(root, diagnostic.file.fileName)}:${line + 1}`);
  }
  console.log(
    '  These are a consequence of the intrinsic-element gap, not defects: with',
  );
  console.log(
    '  @types/react installed each parameter is inferred and no error is raised.',
  );
}

if (diagnostics.length === 0) {
  console.log('PASS — no type errors in the checked .tsx files.');
  reportGap();
  console.log('');
  console.log('Scope, stated plainly:');
  console.log('  · component props, prop types and children shapes ARE checked;');
  console.log('  · intrinsic DOM elements are NOT — see scripts/types/react-shims.d.ts.');
  console.log('  A green run here narrows the gap to a real build. It does not close it.');
  process.exit(0);
}

const formatted = ts.formatDiagnosticsWithColorAndContext(diagnostics, {
  getCanonicalFileName: (file) => file,
  getCurrentDirectory: () => root,
  getNewLine: () => '\n',
});

console.log(formatted);
reportGap();
console.log('');

const byFile = new Map();
for (const diagnostic of diagnostics) {
  const name = path.relative(root, diagnostic.file?.fileName ?? '(unknown)');
  byFile.set(name, (byFile.get(name) ?? 0) + 1);
}
console.log('Files with errors:');
for (const [name, count] of [...byFile.entries()].sort((a, b) => b[1] - a[1])) {
  console.log(`  ${String(count).padStart(3)}  ${name}`);
}
console.log('');
console.error(`FAIL — ${diagnostics.length} type error${diagnostics.length === 1 ? '' : 's'} in .tsx.`);
process.exit(1);
