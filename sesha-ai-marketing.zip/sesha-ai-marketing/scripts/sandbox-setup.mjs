#!/usr/bin/env node
/**
 * Sandbox setup — stand-in modules for offline verification.
 *
 * WHY THIS EXISTS
 * This project was developed in an environment with no npm registry access.
 * `scripts/render-check.mjs` server-renders the real components to verify their
 * HTML output, and to do that it needs *something* at the module specifiers the
 * components import. This script writes minimal stand-ins into node_modules.
 *
 * IMPORTANT
 *  · These are NOT the real packages. They implement just enough surface for a
 *    server render, and `tailwind-merge` in particular is approximate.
 *  · node_modules is gitignored, so nothing here ships.
 *  · Once `npm install` has run with real dependencies, DELETE node_modules and
 *    reinstall before running anything else: `rm -rf node_modules && npm install`.
 *    The real packages must win.
 *
 * Usage: node scripts/sandbox-setup.mjs
 */

import { mkdirSync, writeFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const modules = path.join(root, 'node_modules');

function writeModule(name, files) {
  const dir = path.join(modules, name);
  mkdirSync(dir, { recursive: true });
  for (const [file, contents] of Object.entries(files)) {
    const target = path.join(dir, file);
    mkdirSync(path.dirname(target), { recursive: true });
    writeFileSync(target, contents);
  }
  console.log(`  wrote stand-in: ${name}`);
}

if (existsSync(path.join(modules, 'next', 'dist'))) {
  console.error('Real Next.js is installed — refusing to overwrite it with stand-ins.');
  process.exit(1);
}

/* ------------------------------- next -------------------------------------- */

writeModule('next', {
  'package.json': JSON.stringify({ name: 'next', version: '0.0.0-sandbox', type: 'module' }, null, 2),
  'link.js': `import React from 'react';
export default function Link({ href, children, ...props }) {
  return React.createElement('a', { href, ...props }, children);
}
`,
  'navigation.js': `export function usePathname() { return '/'; }
export function useRouter() { return { push() {}, replace() {}, back() {} }; }
export function useSearchParams() { return new URLSearchParams(); }
export function notFound() {
  const error = new Error('NEXT_NOT_FOUND');
  error.digest = 'NEXT_NOT_FOUND';
  throw error;
}
`,
  'image.js': `import React from 'react';
export default function Image({ src, alt, ...props }) {
  return React.createElement('img', { src, alt, ...props });
}
`,
  'server.js': `export const NextResponse = {
  json(body, init = {}) {
    return new Response(JSON.stringify(body), {
      status: init.status ?? 200,
      headers: { 'content-type': 'application/json', ...(init.headers ?? {}) },
    });
  },
};
`,
});

/* -------------------------------- clsx ------------------------------------- */
// Faithful reimplementation — clsx's behaviour is small and fully specified.

writeModule('clsx', {
  'package.json': JSON.stringify(
    { name: 'clsx', version: '0.0.0-sandbox', type: 'module', main: 'index.js' },
    null,
    2,
  ),
  'index.js': `function toValue(input) {
  if (!input) return '';
  if (typeof input === 'string' || typeof input === 'number') return String(input);
  if (Array.isArray(input)) {
    return input.map(toValue).filter(Boolean).join(' ');
  }
  if (typeof input === 'object') {
    return Object.keys(input).filter((key) => input[key]).join(' ');
  }
  return '';
}

export function clsx(...inputs) {
  return inputs.map(toValue).filter(Boolean).join(' ');
}

export default clsx;
`,
});

/* ---------------------------- tailwind-merge -------------------------------- */
// APPROXIMATE. Implements last-wins conflict resolution for the utility groups
// this codebase actually uses. The real package covers the full Tailwind
// surface; do not rely on this beyond the render check.

writeModule('tailwind-merge', {
  'package.json': JSON.stringify(
    { name: 'tailwind-merge', version: '0.0.0-sandbox', type: 'module', main: 'index.js' },
    null,
    2,
  ),
  'index.js': `// Conflict groups: the LAST class in a group wins, matching tailwind-merge.
const GROUPS = [
  [/^h-/, 'height'],
  [/^w-/, 'width'],
  [/^size-/, 'size'],
  [/^p-/, 'padding'],
  [/^px-/, 'padding-x'],
  [/^py-/, 'padding-y'],
  [/^pt-/, 'padding-t'],
  [/^pb-/, 'padding-b'],
  [/^m-/, 'margin'],
  [/^mt-/, 'margin-t'],
  [/^mb-/, 'margin-b'],
  [/^text-(xs|sm|base|lg|xl|\\d)/, 'font-size'],
  [/^bg-/, 'background'],
  [/^border-\\d/, 'border-width'],
  [/^rounded/, 'radius'],
  [/^font-(thin|light|normal|medium|semibold|bold|extrabold)/, 'font-weight'],
  [/^flex-/, 'flex'],
  [/^gap-/, 'gap'],
];

function groupOf(className) {
  const bare = className.replace(/^[a-z-]+:/g, '');
  for (const [pattern, name] of GROUPS) {
    if (pattern.test(bare)) {
      const prefix = className.slice(0, className.length - bare.length);
      return prefix + name;
    }
  }
  return null;
}

export function twMerge(...inputs) {
  const classes = inputs.filter(Boolean).join(' ').split(/\\s+/).filter(Boolean);
  const seen = new Map();
  const plain = [];

  for (const className of classes) {
    const group = groupOf(className);
    if (group) seen.set(group, className);
    else if (!plain.includes(className)) plain.push(className);
  }

  const ordered = [];
  for (const className of classes) {
    const group = groupOf(className);
    if (group) {
      if (seen.get(group) === className && !ordered.includes(className)) ordered.push(className);
    } else if (!ordered.includes(className)) {
      ordered.push(className);
    }
  }
  return ordered.join(' ');
}

export default twMerge;
`,
});

/* ---------------------- link real globally-installed tools ----------------- */
// react, react-dom, typescript and tsx may already exist globally in an
// offline image. Link them rather than stubbing them — they are the real
// packages, and the render checks need genuine React.
import { symlinkSync, existsSync as exists } from 'node:fs';
import { execSync } from 'node:child_process';

try {
  const globalRoot = execSync('npm root -g', { encoding: 'utf8' }).trim();
  for (const name of ['react', 'react-dom', 'typescript', 'tsx']) {
    const source = nodePathJoin(globalRoot, name);
    const target = nodePathJoin(modules, name);
    if (exists(source) && !exists(target)) {
      symlinkSync(source, target, 'dir');
      console.log(`  linked global: ${name}`);
    }
  }
} catch {
  console.log('  (no global packages to link — install dependencies normally)');
}

/* ------------------------------- @types/node ------------------------------ */
// The type checker needs Node's own declarations for `process`, `Buffer` and
// `node:crypto`. In an offline image a copy usually ships inside some global
// tool's dependencies; link the newest one found rather than stubbing them,
// because a hand-written stub would hide real type errors.
try {
  const globalRoot = execSync('npm root -g', { encoding: 'utf8' }).trim();
  const typesDir = nodePathJoin(modules, '@types');
  const target = nodePathJoin(typesDir, 'node');

  if (!exists(target)) {
    const found = execSync(
      `find ${globalRoot} -maxdepth 4 -type d -path '*@types/node' 2>/dev/null | head -1`,
      { encoding: 'utf8', shell: '/bin/bash' },
    ).trim();

    if (found) {
      mkdirSync(typesDir, { recursive: true });
      symlinkSync(found, target, 'dir');
      console.log('  linked global: @types/node');
    } else {
      console.log('  (no @types/node found — scripts/typecheck.mjs will be skipped)');
    }
  }
} catch {
  console.log('  (could not link @types/node)');
}

function nodePathJoin(...parts) {
  return path.join(...parts);
}

console.log('\nSandbox stand-ins ready. Run: node --import tsx scripts/render-check.mjs');
console.log('Remember: rm -rf node_modules && npm install before using the real toolchain.');
