#!/usr/bin/env node
/**
 * Whole-page render audit.
 *
 * WHY THIS EXISTS
 * Built without npm registry access, so `next build` could not be run. This
 * script renders every page component to static HTML with react-dom/server
 * (against the stand-ins from scripts/sandbox-setup.mjs) and audits the output
 * the way a reviewer would audit a served page:
 *
 *   · exactly one <h1>, and no skipped heading levels;
 *   · every JSON-LD block parses AND passes this project's own validator;
 *   · no empty links, no empty buttons, no link-without-text;
 *   · every landmark and interactive control has an accessible name;
 *   · FAQ answers are present in the HTML (the AEO requirement);
 *   · no raw "undefined"/"NaN"/"[object Object]" leaked into the output.
 *
 * This is NOT a substitute for `next build` — it does not exercise the Next
 * runtime, routing, streaming or client hydration. It verifies the markup the
 * components produce.
 *
 * Usage: node scripts/sandbox-setup.mjs
 *        TSX_TSCONFIG_PATH=tsconfig.sandbox.json node --import tsx scripts/page-audit.mjs
 */

import { renderToStaticMarkup } from 'react-dom/server';
import React from 'react';

// Dynamic imports: tsx transpiles TypeScript on the fly, and static named
// imports from a .mjs into a .ts module are not always statically analysable.
const { validateJsonLd } = await import('../src/lib/schema-validator/validate.ts');
const { SOLUTION_SLUGS } = await import('../src/lib/routes.ts');
const { posts } = await import('../src/content/blog.ts');

const problems = [];
const stats = [];

function report(page, message) {
  problems.push(`${page}: ${message}`);
}

/* -------------------------------------------------------------------------- */
/* Audits                                                                     */
/* -------------------------------------------------------------------------- */

function auditHeadings(page, html) {
  const levels = [...html.matchAll(/<h([1-6])[\s>]/g)].map((m) => Number(m[1]));
  const h1Count = levels.filter((l) => l === 1).length;

  if (h1Count === 0) report(page, 'no <h1>');
  if (h1Count > 1) report(page, `${h1Count} <h1> elements (must be exactly one)`);

  let previous = 0;
  for (const level of levels) {
    if (previous !== 0 && level > previous + 1) {
      report(page, `heading level jumps from h${previous} to h${level}`);
      break;
    }
    previous = level;
  }
  return levels.length;
}

// Pages that are intentionally noindex carry no structured data: markup on a
// page that asks not to be indexed serves no consumer. Every authenticated and
// authentication surface is noindex by design.
const NO_SCHEMA_EXPECTED = new Set(['/404']);

function expectsSchema(page) {
  if (NO_SCHEMA_EXPECTED.has(page)) return false;
  // Authenticated and platform screens are noindex, so structured data on them
  // would be markup nobody will ever read. /admin is doubly so: it must not be
  // discoverable at all.
  return !page.startsWith('/sign-') && !page.startsWith('/app/') && !page.startsWith('/admin') &&
    !page.startsWith('/forgot-') && !page.startsWith('/reset-') && !page.startsWith('/verify-');
}

function auditJsonLd(page, html) {
  const blocks = [...html.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)];
  if (blocks.length === 0) {
    if (expectsSchema(page)) report(page, 'no JSON-LD block');
    return 0;
  }
  for (const [, raw] of blocks) {
    const json = raw.replace(/\\u003c/g, '<').replace(/\\u003e/g, '>');
    let parsed;
    try {
      parsed = JSON.parse(json);
    } catch (error) {
      report(page, `JSON-LD does not parse: ${error.message}`);
      continue;
    }
    const result = validateJsonLd(JSON.stringify(parsed));
    const errors = result.messages.filter((m) => m.severity === 'error');
    for (const error of errors) {
      report(page, `JSON-LD ${error.path}: ${error.message}`);
    }
  }
  return blocks.length;
}

function auditLinksAndButtons(page, html) {
  // A link or button with no text content and no accessible name is
  // unreachable for a screen-reader user.
  for (const [full, inner] of html.matchAll(/<a\s[^>]*>([\s\S]*?)<\/a>/g)) {
    const text = inner.replace(/<[^>]+>/g, '').trim();
    const hasLabel = /aria-label=|aria-labelledby=/.test(full);
    const hasTitledSvg = /<title>/.test(inner);
    if (!text && !hasLabel && !hasTitledSvg) {
      report(page, `link with no accessible name: ${full.slice(0, 90)}`);
    }
  }
  for (const [full, inner] of html.matchAll(/<button\s[^>]*>([\s\S]*?)<\/button>/g)) {
    const text = inner.replace(/<[^>]+>/g, '').trim();
    const hasLabel = /aria-label=|aria-labelledby=/.test(full);
    if (!text && !hasLabel) {
      report(page, `button with no accessible name: ${full.slice(0, 90)}`);
    }
  }
  const emptyHref = [...html.matchAll(/href="(#|)"/g)];
  if (emptyHref.length > 0) report(page, `${emptyHref.length} empty href attribute(s)`);
}

function auditLeakage(page, html) {
  for (const token of ['undefined', 'NaN', '[object Object]']) {
    // Only flag the token as rendered text, not inside an attribute value.
    const pattern = new RegExp(`>[^<]*\\b${token.replace(/[[\]]/g, '\\$&')}\\b[^<]*<`, 'g');
    const hits = [...html.matchAll(pattern)];
    if (hits.length > 0) {
      report(page, `rendered "${token}" in visible text: ${hits[0][0].slice(0, 80)}`);
    }
  }
}

function auditImages(page, html) {
  for (const match of html.matchAll(/<img\s[^>]*>/g)) {
    if (!/\salt=/.test(match[0])) report(page, `img without alt: ${match[0].slice(0, 70)}`);
  }
}

function auditFaqPresence(page, html) {
  const detailsCount = (html.match(/<details/g) ?? []).length;
  if (detailsCount === 0) return;
  // Every <details> must contain rendered answer content, open or not.
  const blocks = [...html.matchAll(/<details[\s\S]*?<\/details>/g)];
  for (const [block] of blocks.map((m) => [m[0]])) {
    const afterSummary = block.split('</summary>')[1] ?? '';
    if (afterSummary.replace(/<[^>]+>/g, '').trim().length === 0) {
      report(page, 'a collapsed FAQ answer is not present in the HTML (breaks AEO)');
      break;
    }
  }
}

async function audit(name, element) {
  let html;
  try {
    html = renderToStaticMarkup(element);
  } catch (error) {
    report(name, `render threw: ${error.message.split('\n')[0]}`);
    return;
  }

  const headings = auditHeadings(name, html);
  const jsonLdBlocks = auditJsonLd(name, html);
  auditLinksAndButtons(name, html);
  auditLeakage(name, html);
  auditImages(name, html);
  auditFaqPresence(name, html);

  stats.push({
    page: name,
    bytes: html.length,
    headings,
    jsonLdBlocks,
    links: (html.match(/<a\s/g) ?? []).length,
  });
}

/* -------------------------------------------------------------------------- */
/* Render every page                                                          */
/* -------------------------------------------------------------------------- */

const staticPages = [
  ['/', '../src/app/(marketing)/page.tsx'],
  ['/features', '../src/app/(marketing)/features/page.tsx'],
  ['/solutions', '../src/app/(marketing)/solutions/page.tsx'],
  ['/seo', '../src/app/(marketing)/seo/page.tsx'],
  ['/aeo', '../src/app/(marketing)/aeo/page.tsx'],
  ['/schema-validator', '../src/app/(marketing)/schema-validator/page.tsx'],
  ['/pricing', '../src/app/(marketing)/pricing/page.tsx'],
  ['/resources', '../src/app/(marketing)/resources/page.tsx'],
  ['/blog', '../src/app/(marketing)/blog/page.tsx'],
  ['/about', '../src/app/(marketing)/about/page.tsx'],
  ['/contact', '../src/app/(marketing)/contact/page.tsx'],
  ['/faq', '../src/app/(marketing)/faq/page.tsx'],
  ['/security', '../src/app/(marketing)/security/page.tsx'],
  ['/privacy', '../src/app/(marketing)/privacy/page.tsx'],
  ['/terms', '../src/app/(marketing)/terms/page.tsx'],
  ['/404', '../src/app/not-found.tsx'],
];

for (const [name, modulePath] of staticPages) {
  const mod = await import(modulePath);
  await audit(name, React.createElement(mod.default));
}

const SolutionPage = (await import('../src/app/(marketing)/solutions/[slug]/page.tsx')).default;
for (const slug of SOLUTION_SLUGS) {
  const element = await SolutionPage({ params: Promise.resolve({ slug }) });
  await audit(`/solutions/${slug}`, element);
}

const BlogPostPage = (await import('../src/app/(marketing)/blog/[slug]/page.tsx')).default;
for (const post of posts) {
  const element = await BlogPostPage({ params: Promise.resolve({ slug: post.slug }) });
  await audit(`/blog/${post.slug}`, element);
}

/* -------------------------------------------------------------------------- */
/* Phase 2 surfaces: authentication pages and coming-soon states              */
/* -------------------------------------------------------------------------- */
// The authenticated workspace pages themselves need a resolved session (and so
// a database and a cookie store), which this harness does not provide. What IS
// rendered here is everything that does not: the auth pages, and every
// coming-soon state, which is where a "fake functionality" regression would
// show up first.

const authPages = [
  ['/sign-in', '../src/app/(auth)/sign-in/page.tsx'],
  ['/sign-up', '../src/app/(auth)/sign-up/page.tsx'],
  ['/forgot-password', '../src/app/(auth)/forgot-password/page.tsx'],
  ['/reset-password', '../src/app/(auth)/reset-password/page.tsx'],
  ['/verify-email', '../src/app/(auth)/verify-email/page.tsx'],
];

for (const [name, modulePath] of authPages) {
  const mod = await import(modulePath);
  await audit(name, React.createElement(mod.default));
}

const { appMoreNav, appPrimaryNav } = await import('../src/content/app-nav.ts');
const plannedRoutes = [...appPrimaryNav, ...appMoreNav]
  .filter((item) => item.status === 'planned')
  .map((item) => item.href);

for (const href of plannedRoutes) {
  const slug = href.replace('/app/', '');
  const mod = await import(`../src/app/(app)/app/${slug}/page.tsx`);
  await audit(href, React.createElement(mod.default));
}

/* -------------------------------------------------------------------------- */
/* Phase 3 surfaces                                                           */
/* -------------------------------------------------------------------------- */
// These pages are server components that need a session, so the page module
// cannot be rendered here. The client component each one mounts IS the page
// body, so it is audited directly with representative props — headings,
// accessible names and leaked values are all checked exactly as elsewhere.
{
  const sampleProject = {
    id: 'p1',
    organizationId: 'o1',
    businessId: 'b1',
    name: 'Acme Coffee',
    slug: 'acme-coffee',
    description: null,
    createdBy: 'u1',
    deletedAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const { Copilot } = await import('../src/components/ai/copilot.tsx');
  const { ContentStudio } = await import('../src/components/ai/content-studio.tsx');
  const { StrategyBuilder } = await import('../src/components/ai/strategy-builder.tsx');
  const { SocialManager } = await import('../src/components/ai/social-manager.tsx');
  const { SocialCalendar } = await import('../src/components/ai/social-calendar.tsx');

  const surfaces = [
    ['/app/ai', Copilot, { projects: [sampleProject], enabled: true, disabledReason: '' }],
    ['/app/create', ContentStudio, { projects: [sampleProject], recent: [], enabled: true, disabledReason: '' }],
    ['/app/strategy', StrategyBuilder, { projects: [sampleProject], enabled: true, disabledReason: '', canApprove: true }],
    ['/app/social', SocialManager, { projects: [sampleProject], posts: [], enabled: true, disabledReason: '' }],
    ['/app/calendar', SocialCalendar, { projects: [sampleProject] }],
  ];

  for (const [name, Component, props] of surfaces) {
    await audit(name, React.createElement(Component, props));
  }

  /* ----------------------------- Phase 4 ---------------------------------- */
  // Minimal page shell for auditing a fragment in the position it really sits in.
  const Fragment2 = ({ heading, child }) =>
    React.createElement('div', null, React.createElement('h1', null, heading), child);

  // The crawl and audit screens. Rendered with a stored audit present, so the
  // findings, the score and the "what could not be checked" block are all
  // covered by the heading and accessible-name audits.
  const { AuditView } = await import('../src/components/audit/audit-view.tsx');
  const { AuditRunner } = await import('../src/components/audit/audit-runner.tsx');
  const { KeywordTable } = await import('../src/components/audit/keyword-table.tsx');
  const { AEO_DISCLAIMER } = await import('../src/lib/audit/aeo.ts');

  const sampleCrawl = {
    id: 'c1',
    organizationId: 'o1',
    projectId: 'p1',
    jobId: 'j1',
    consentId: 'cons1',
    startedBy: 'u1',
    siteUrl: 'https://example.com/',
    maxPages: 50,
    maxDepth: 3,
    respectRobots: true,
    crawlDelayMs: 500,
    pagesCrawled: 12,
    pagesFailed: 1,
    robotsFound: true,
    robotsReadable: true,
    robotsSummary: 'robots.txt found with 2 rules that apply to this crawler.',
    sitemapFound: true,
    sitemapNote: '12 URLs found across 1 sitemap file.',
    sitemapUrlsFound: 12,
    failures: [],
    skipped: {},
    stoppedEarly: null,
    cancelled: false,
    startedAt: new Date('2026-03-01T10:00:00Z'),
    finishedAt: new Date('2026-03-01T10:04:00Z'),
    expiresAt: new Date('2026-04-01T10:00:00Z'),
    createdAt: new Date('2026-03-01T10:00:00Z'),
    updatedAt: new Date('2026-03-01T10:04:00Z'),
  };

  const sampleAudit = {
    id: 'a1',
    kind: 'seo',
    score: 72,
    scoreBasis: "This score is SeSha's own weighting of the issues found in this crawl.",
    findings: [
      {
        id: 'seo-title-missing-1',
        category: 'Metadata',
        severity: 'critical',
        issue: '2 pages have no title element.',
        evidence: {
          observation: 'No non-empty <title> was found in the head of these pages.',
          urls: ['https://example.com/a', 'https://example.com/b'],
          affectedCount: 2,
          totalCount: 12,
        },
        recommendation: 'Give every page a unique title of roughly 15-60 characters.',
        expectedBenefit: 'The title is the primary thing search engines and people use to judge a page.',
        confidence: 'high',
        dataBasis: 'crawled_page',
      },
    ],
    stats: {},
    notChecked: [
      {
        area: 'Core Web Vitals',
        reason: 'These are measured in a real browser on real visits.',
        whatWouldHelp: 'Google Search Console or PageSpeed Insights.',
      },
    ],
    suppressed: [],
    checkedAt: '2026-03-01T10:05:00Z',
  };

  const phase4 = [
    ['/app/seo-aeo', AuditView, {
      projects: [sampleProject],
      crawl: sampleCrawl,
      seo: sampleAudit,
      aeo: null,
      consentGranted: true,
      consentSite: 'https://example.com/',
      canRequestCrawl: true,
      aeoDisclaimer: AEO_DISCLAIMER,
    }],
    ['/app/seo-aeo (no crawl)', AuditView, {
      projects: [sampleProject],
      crawl: null,
      seo: null,
      aeo: null,
      consentGranted: false,
      consentSite: null,
      canRequestCrawl: true,
      aeoDisclaimer: AEO_DISCLAIMER,
    }],
    // These two are page FRAGMENTS: the real page owns the h1 and they sit
    // beneath it. Wrapped in the same shape here so the heading-hierarchy audit
    // checks what the user actually sees rather than the component in isolation.
    ['/app/website-audit (runner)', Fragment2, {
      heading: 'Website audit',
      child: React.createElement(AuditRunner, {
        projects: [sampleProject],
        consentGranted: true,
        consentSite: 'https://example.com/',
        hasCrawl: true,
        canRequestCrawl: true,
      }),
    }],
    ['/app/website-audit (keywords)', Fragment2, {
      heading: 'Website audit',
      child: React.createElement(KeywordTable, {
        keywords: [
        {
          id: 'k1',
          query: 'How do we roast our coffee?',
          kinds: ['primary', 'question', 'long-tail'],
          intent: 'informational',
          relevanceScore: 80,
          relevanceBasis: 'Measured against the crawled text.',
          coveringUrls: ['https://example.com/roasting'],
          volume: { kind: 'unavailable', label: 'Data unavailable' },
          competition: { kind: 'unavailable', label: 'Data unavailable' },
          priority: 'medium',
          contentFormat: 'faq-entry',
          entities: ['Acme Coffee'],
          source: 'page_heading',
        },
      ],
        dataNote: 'Search volume and competition show "Data unavailable".',
        priorityBasis: 'Priority does not include search volume.',
      }),
    }],
  ];

  for (const [name, Component, props] of phase4) {
    await audit(name, React.createElement(Component, props));
  }

  /* ----------------------------- Phase 5 ---------------------------------- */
  // The validation report, the ads planner, the messaging planner and the video
  // view. Each is rendered with real data in it, so the heading hierarchy and the
  // accessible names on the new surfaces are audited rather than assumed.
  const { ValidationReport } = await import('../src/components/schema/validation-report.tsx');
  const { CorrectionView } = await import('../src/components/schema/correction-view.tsx');
  const { GeneratedSchemaView } = await import('../src/components/schema/generated-schema.tsx');
  const { AdPlanner } = await import('../src/components/ads/ad-planner.tsx');
  const { MessagingPlanner } = await import('../src/components/messaging/messaging-planner.tsx');
  const { ScriptView } = await import('../src/components/video/script-view.tsx');
  const { validateSchema, buildCorrection } = await import('../src/lib/schema-validator/index.ts');
  const { generateSchema } = await import('../src/lib/schema/generate.ts');

  const sampleSource = JSON.stringify({
    '@context': 'https://schema.org',
    '@type': 'LocalBusiness',
    name: 'Acme Coffee',
    datePublished: '14/03/2026',
  });
  const sampleResult = validateSchema({ source: sampleSource, sourceKind: 'pasted' });
  const sampleCorrection = buildCorrection(sampleSource, sampleResult);
  const sampleGenerated = generateSchema({
    kind: 'local_business',
    business: {
      name: 'Acme Coffee',
      websiteUrl: 'https://acme-coffee.example.com',
      city: 'Nagpur',
      country: 'IN',
      industry: 'hospitality',
    },
  });

  const phase5 = [
    ['/app/schema-validator (report)', Fragment2, {
      heading: 'Schema Validator',
      child: React.createElement(ValidationReport, { result: sampleResult }),
    }],
    ['/app/schema-validator (correction)', Fragment2, {
      heading: 'Schema Validator',
      child: React.createElement(CorrectionView, { correction: sampleCorrection }),
    }],
    ['/app/schema-validator (generated)', Fragment2, {
      heading: 'Schema Validator',
      child: React.createElement(GeneratedSchemaView, { generated: sampleGenerated }),
    }],
    ['/app/campaigns (planner)', Fragment2, {
      heading: 'Campaigns',
      child: React.createElement(AdPlanner, {
        plans: [
          {
            id: 'ap1',
            platform: 'google_ads',
            objective: 'leads',
            campaignName: 'Acme Coffee — leads',
            reviewState: 'draft',
            problems: [
              { severity: 'error', field: 'headlines', message: 'Headline: 3 needed, 0 written.' },
            ],
            createdAt: '2026-09-01T10:00:00.000Z',
          },
        ],
      }),
    }],
    ['/app/messaging (planner)', Fragment2, {
      heading: 'Email and WhatsApp',
      child: React.createElement(MessagingPlanner, {
        plans: [
          {
            id: 'mp1',
            channel: 'whatsapp',
            kind: 'offer',
            category: 'MARKETING',
            title: 'Monsoon offer',
            optInBasis: 'explicit_opt_in',
            audienceNote: 'Customers who opted in at the counter.',
            reviewState: 'draft',
            problems: [],
            createdAt: '2026-09-01T10:00:00.000Z',
          },
        ],
      }),
    }],
    ['/app/video (scripts)', Fragment2, {
      heading: 'Video and creative',
      child: React.createElement(ScriptView, {
        scripts: [
          {
            id: 'vs1',
            platform: 'instagram_reels',
            topic: 'Why your coffee tastes sour at home',
            totalSeconds: 45,
            reviewState: 'draft',
            problems: [],
            createdAt: '2026-09-01T10:00:00.000Z',
          },
        ],
      }),
    }],
  ];

  for (const [name, Component, props] of phase5) {
    await audit(name, React.createElement(Component, props));
  }

  // THE FOUR DIMENSIONS MUST BE VISIBLY SEPARATE on the validation report. A
  // single merged list would satisfy every other check in this script while
  // undoing the distinction the brief requires.
  {
    const html = renderToStaticMarkup(React.createElement(ValidationReport, { result: sampleResult }));
    for (const label of [
      'Schema.org validity',
      'Search-engine eligibility',
      'General SEO guidance',
      'AI / AEO clarity',
    ]) {
      if (!html.includes(label)) {
        problems.push(`validation report does not group findings under "${label}"`);
      }
    }
    if (!html.includes('What was not checked')) {
      problems.push('validation report hides what it did not evaluate');
    }
  }

  // A generated-schema view must always show the refusals: a user who cannot see
  // that the missing rating was a decision will simply add one.
  {
    const html = renderToStaticMarkup(
      React.createElement(GeneratedSchemaView, { generated: sampleGenerated }),
    );
    if (!html.includes('Never generated')) {
      problems.push('generated schema view does not show what it refuses to generate');
    }
    if (!/aggregateRating/.test(html)) {
      problems.push('generated schema view does not name aggregateRating among its refusals');
    }
  }

  // No screen may imply that SeSha sends messages or generates images.
  {
    const messaging = renderToStaticMarkup(
      React.createElement(MessagingPlanner, { plans: [] }),
    );
    if (!/cannot send/i.test(messaging)) {
      problems.push('the messaging planner does not say that SeSha cannot send');
    }
    const video = renderToStaticMarkup(React.createElement(ScriptView, { scripts: [] }));
    if (!/No images are generated/i.test(video)) {
      problems.push('the video screen does not say that no images are generated');
    }
    const ads = renderToStaticMarkup(React.createElement(AdPlanner, { plans: [] }));
    if (!/No ad account is connected/i.test(ads)) {
      problems.push('the campaigns screen does not say that no ad account is connected');
    }
  }

  // A keyword table must NEVER render a bare volume number.
  {
    const html = renderToStaticMarkup(
      React.createElement(KeywordTable, phase4[3][2].child.props),
    );
    if (!/Data unavailable/.test(html)) {
      report('/app/website-audit (keywords)', 'does not state that volume data is unavailable');
    }
  }

  // The same surfaces with nothing to work from: an empty state must explain
  // itself rather than render a form that cannot do anything.
  for (const [name, Component, props] of surfaces) {
    const empty = renderToStaticMarkup(
      React.createElement(Component, { ...props, projects: [] }),
    );
    if (!/Create a project first/i.test(empty)) {
      report(`${name} (no projects)`, 'does not explain why the surface is empty');
    }
  }
}

/* -------------------------------------------------------------------------- */
/* Phase 6 surfaces                                                           */
/* -------------------------------------------------------------------------- */
// Analytics, calendar, automations, reports and notification preferences. Each
// is rendered in the state that matters most for this phase: NOTHING CONNECTED.
// That is the state a real customer sees on day one, and it is the state in
// which a fabricated figure would appear if one were ever going to.
{
  const Fragment6 = ({ heading, child }) =>
    React.createElement('div', null, React.createElement('h1', null, heading), child);

  const { MetricBoard } = await import('../src/components/analytics/metric-board.tsx');
  const { CalendarBoard } = await import('../src/components/calendar/calendar-board.tsx');
  const { AutomationBoard } = await import('../src/components/automation/automation-board.tsx');
  const { ReportBoard } = await import('../src/components/reports/report-board.tsx');
  const { ReportView } = await import('../src/components/reports/report-view.tsx');
  const { NotificationPreferences } = await import(
    '../src/components/notifications/notification-preferences.tsx'
  );

  const { METRICS, METRIC_IDS, unavailable } = await import('../src/lib/analytics/metrics.ts');
  const { CONNECTION_DEFINITIONS, CONNECTION_PROVIDERS, analyticsStatus, connectionStates } =
    await import('../src/lib/analytics/connections.ts');
  const { generateReport } = await import('../src/lib/reports/generate.ts');
  const { preferenceViewFixture } = { preferenceViewFixture: null };
  const { NOTIFICATION_KINDS, NOTIFICATION_LABEL, NOTIFICATION_DESCRIPTION, ALWAYS_ON, CHANNELS, CHANNEL_IDS } =
    await import('../src/lib/notifications/types.ts');

  const AS_OF = '2026-03-01T00:00:00.000Z';
  const states = connectionStates([]);

  const metrics = METRIC_IDS.map((id) => ({
    id,
    label: METRICS[id].label,
    description: METRICS[id].description,
    group: METRICS[id].group,
    higherIsBetter: METRICS[id].higherIsBetter,
    value:
      METRICS[id].requires === 'none'
        ? {
            kind: 'calculated',
            value: 4,
            unit: METRICS[id].unit,
            formula: 'Counted from your own records in SeSha.',
            inputs: [{ label: 'Counted', value: 4 }],
            asOf: AS_OF,
          }
        : unavailable(
            'This can only come from a connected account, and none is connected.',
            'Connect the account in Settings.',
          ),
  }));

  const analyticsHtml = renderToStaticMarkup(
    React.createElement(Fragment6, {
      heading: 'Analytics',
      child: React.createElement(MetricBoard, {
        metrics,
        connections: CONNECTION_PROVIDERS.map((provider) => ({
          provider,
          label: CONNECTION_DEFINITIONS[provider].label,
          connected: false,
          howToConnect: CONNECTION_DEFINITIONS[provider].howToConnect,
          problem: null,
        })),
        anyConnected: false,
        explanation: analyticsStatus(states).message,
        periodLabel: 'Last 30 days',
      }),
    }),
  );

  // THE PHASE 6 REGRESSION THAT MATTERS MOST: an unavailable metric rendered as
  // a number. Each unavailable metric must render its reason, and none of them
  // may be followed by a figure.
  if (!/No connected data available/.test(analyticsHtml)) {
    report('/app/analytics (nothing connected)', 'does not display the required sentence');
  }
  if (!/they are not zero|not zero|has not been measured|have not been measured/i.test(analyticsHtml)) {
    report('/app/analytics (nothing connected)', 'does not distinguish unavailable from zero');
  }
  for (const id of ['traffic', 'impressions', 'roas', 'followers']) {
    const label = METRICS[id].label;
    const pattern = new RegExp(`${label}</h3>[\\s\\S]{0,400}?<p class="text-2xl`);
    if (pattern.test(analyticsHtml)) {
      report('/app/analytics (nothing connected)', `renders a figure for "${label}", which cannot be measured`);
    }
  }

  await audit('/app/analytics (nothing connected)', React.createElement(Fragment6, {
    heading: 'Analytics',
    child: React.createElement(MetricBoard, {
      metrics,
      connections: CONNECTION_PROVIDERS.map((provider) => ({
        provider,
        label: CONNECTION_DEFINITIONS[provider].label,
        connected: false,
        howToConnect: CONNECTION_DEFINITIONS[provider].howToConnect,
        problem: null,
      })),
      anyConnected: false,
      explanation: analyticsStatus(states).message,
      periodLabel: 'Last 30 days',
    }),
  }));

  const calendarElement = React.createElement(Fragment6, {
    heading: 'Marketing calendar',
    child: React.createElement(CalendarBoard, {
      projectId: 'p1',
      view: 'weekly',
      anchor: '2026-03-11',
      range: { from: '2026-03-09', to: '2026-03-15' },
      events: [
        {
          id: 'e1',
          kind: 'blog',
          title: 'Publish the catering page',
          notes: '',
          date: '2026-03-12',
          status: 'planned',
          origin: 'manual',
        },
      ],
      suggestions: [
        {
          date: '2026-03-14',
          kind: 'seo_task',
          title: 'Fix the missing titles',
          why: 'Four of your pages have no title element, found by your own last audit.',
          basedOn: ['An open finding in your own audits or validations.'],
        },
      ],
      canEdit: true,
    }),
  });
  const calendarHtml = renderToStaticMarkup(calendarElement);
  if (!/Suggestion</.test(calendarHtml)) {
    report('/app/calendar', 'a suggestion is not visibly marked as one');
  }
  await audit('/app/calendar (week)', calendarElement);

  const automationElement = React.createElement(Fragment6, {
    heading: 'Automations',
    child: React.createElement(AutomationBoard, {
      projectId: 'p1',
      rules: [
        {
          id: 'r1',
          name: 'New lead follow-up',
          trigger: 'lead_created',
          conditions: [{ field: 'email', operator: 'is_set' }],
          actions: [{ kind: 'create_follow_up', template: 'Ring the {{source}} lead.', offsetDays: 1 }],
          enabled: true,
        },
      ],
      canEdit: true,
    }),
  });
  const automationHtml = renderToStaticMarkup(automationElement);
  if (!/does not contact|Nothing is sent|cannot do any of those things/i.test(automationHtml)) {
    report('/app/automations', 'does not state that nothing is sent');
  }
  await audit('/app/automations', automationElement);

  const reportBoardElement = React.createElement(Fragment6, {
    heading: 'Reports',
    child: React.createElement(ReportBoard, { projectId: 'p1', reports: [], canGenerate: true }),
  });
  await audit('/app/reports (empty)', reportBoardElement);

  const report6 = generateReport({
    kind: 'weekly',
    id: 'rep1',
    organizationName: 'Acme Coffee',
    period: { from: '2026-03-02T00:00:00.000Z', to: '2026-03-08T00:00:00.000Z', label: 'Week of 2 March' },
    generatedAt: AS_OF,
    metrics: [
      {
        id: 'leads',
        definition: METRICS.leads,
        value: {
          kind: 'calculated',
          value: 4,
          unit: 'count',
          formula: 'Leads created inside the period, counted from your own pipeline.',
          inputs: [{ label: 'Leads in period', value: 4 }],
          asOf: AS_OF,
        },
      },
      {
        id: 'traffic',
        definition: METRICS.traffic,
        value: unavailable(
          'This can only come from a website analytics account, and none is connected.',
          'Connect Google Analytics in Settings.',
        ),
      },
    ],
    connections: states,
    activity: {
      contentCreated: 2,
      contentApproved: 1,
      leadsCreated: 4,
      leadsWon: 1,
      leadsLost: 0,
      calendarDone: 1,
      calendarPlanned: 2,
      calendarSkipped: 0,
      automationRuns: 3,
      automationActions: 2,
    },
    campaigns: [],
    pages: [],
    causes: [],
    recommendations: [{ text: 'Write the pricing page.', reason: 'It is what people ask about.' }],
  });

  const reportHtml = renderToStaticMarkup(React.createElement(ReportView, { report: report6 }));
  if (!/No connected data available/.test(reportHtml)) {
    report('/app/reports/[id]', 'a report with nothing connected does not say so');
  }
  if (/Traffic<\/h3>[\s\S]{0,300}?<p class="text-2xl/.test(reportHtml)) {
    report('/app/reports/[id]', 'renders a traffic figure that cannot be measured');
  }
  for (const question of [
    'What happened?',
    'Why?',
    'What next?',
    'Which campaigns?',
    'Which pages?',
    'Where should attention or budget be reviewed?',
  ]) {
    if (!reportHtml.includes(question)) {
      report('/app/reports/[id]', `the report omits the section "${question}"`);
    }
  }
  await audit('/app/reports/[id]', React.createElement(ReportView, { report: report6 }));

  // Rendered under an <h2>, exactly as the settings page nests it — the cards
  // inside are h3, so auditing it directly under the h1 would report a heading
  // jump that does not exist on the real screen.
  const preferencesElement = React.createElement(Fragment6, {
    heading: 'Settings',
    child: React.createElement(
      'section',
      null,
      React.createElement('h2', null, 'Notifications'),
      React.createElement(NotificationPreferences, {
      preferences: NOTIFICATION_KINDS.map((kind) => ({
        kind,
        label: NOTIFICATION_LABEL[kind],
        description: NOTIFICATION_DESCRIPTION[kind],
        inApp: true,
        email: false,
        locked: ALWAYS_ON[kind] !== undefined,
        lockedReason: ALWAYS_ON[kind] ?? null,
      })),
      channels: CHANNEL_IDS.map((id) => ({
        id,
        label: CHANNELS[id].label,
        available: CHANNELS[id].available,
        unavailableReason: CHANNELS[id].unavailableReason ?? null,
      })),
      }),
    ),
  });
  const preferencesHtml = renderToStaticMarkup(preferencesElement);
  if (!/Always on/.test(preferencesHtml)) {
    report('/app/settings (notifications)', 'does not mark the kinds that cannot be switched off');
  }
  if (!/attacker must not be able to silence it/.test(preferencesHtml)) {
    report('/app/settings (notifications)', 'locks a row without showing the reason');
  }
  if (!/No email provider is connected/.test(preferencesHtml)) {
    report('/app/settings (notifications)', 'hides the unavailable channel rather than explaining it');
  }
  await audit('/app/settings (notifications)', preferencesElement);
}

// Every planned feature must render a coming-soon state, never a fake UI.
{
  const { ComingSoon } = await import('../src/components/app/coming-soon.tsx');
  const html = renderToStaticMarkup(
    React.createElement(ComingSoon, {
      title: 'Example',
      description: 'Example description.',
      phase: 'Phase 9',
      whatItWillDo: ['One thing', 'Another thing'],
    }),
  );
  if (!/Not built yet/.test(html)) {
    report('coming-soon component', 'does not state that the feature is unbuilt');
  }
  if (/<table|<canvas|<svg[^>]*class="[^"]*chart/.test(html)) {
    report('coming-soon component', 'renders chart-like placeholder content');
  }
}

/* -------------------------------------------------------------------------- */
/* Phase 7: the usage dashboard, the billing screen and the admin shell       */
/* -------------------------------------------------------------------------- */

// These are audited as components rather than whole pages because the pages
// resolve a session and a database. What the audit adds over render-check is the
// leakage, heading and link scanning that every other screen gets.
{
  const { UsageDashboardView } = await import('../src/components/app/usage-dashboard.tsx');
  const { BillingPanel } = await import('../src/components/app/billing-panel.tsx');
  const { AdminShell } = await import('../src/components/admin/admin-shell.tsx');
  const { limitStatus } = await import('../src/lib/quota/index.ts');
  const { effectiveLimits } = await import('../src/lib/plans/resolve.ts');
  const { LIMIT_IDS: auditLimitIds, PLANS_BY_RANK: auditPlans } = await import(
    '../src/content/plans.ts'
  );
  const { permissionsFor: auditPermissionsFor } = await import('../src/lib/admin/auth.ts');

  const resolved = effectiveLimits('pro');
  const statuses = auditLimitIds.map((id) => limitStatus(resolved[id], 3));

  const usageElement = React.createElement('div', null, [
    React.createElement('h1', { key: 'h' }, 'Usage'),
    React.createElement(UsageDashboardView, {
      key: 'u',
      planName: 'Pro',
      writable: true,
      blockedReason: undefined,
      data: {
        plan: 'pro',
        periodStart: '2026-09-01',
        resetsAt: '2026-10-01T00:00:00.000Z',
        limits: statuses,
        pressure: statuses.filter((status) => status.nearLimit),
        tracked: [
          {
            metric: 'ai_generation',
            label: 'AI requests',
            total: 3,
            previousTotal: 1,
            limitId: 'ai_requests',
          },
        ],
        recentRefusals: [
          {
            limitId: 'ai_requests',
            reason: 'You have used all 500 AI requests on Pro this month.',
            refusedAt: '2026-09-10T09:00:00.000Z',
          },
        ],
      },
    }),
  ]);

  const usageHtml = renderToStaticMarkup(usageElement);
  // Every limit must appear. A dashboard that silently drops one is worse than
  // no dashboard, because it reads as an authoritative list.
  for (const id of auditLimitIds) {
    if (!usageHtml.includes(resolved[id].label)) {
      report('/app/usage', `does not render the "${id}" limit`);
    }
  }
  if (!/Resets monthly/.test(usageHtml)) {
    report('/app/usage', 'does not say when a per-period limit resets');
  }
  if (!/A standing total, not a monthly one/.test(usageHtml)) {
    report('/app/usage', 'does not distinguish a standing total from a monthly allowance');
  }
  await audit('/app/usage', usageElement);

  const billingElement = React.createElement('div', null, [
    React.createElement('h1', { key: 'h' }, 'Plan and billing'),
    React.createElement(BillingPanel, {
      key: 'b',
      currentPlan: 'pro',
      plans: auditPlans,
      providerConfigured: false,
      providerMessage:
        'No payment provider is connected yet, so no plan can be bought and nothing can be charged.',
      cancelAtPeriodEnd: false,
      canManage: true,
    }),
  ]);
  const billingHtml = renderToStaticMarkup(billingElement);
  if (/<(input|textarea|select)\b/i.test(billingHtml)) {
    report('/app/settings/billing', 'renders a data-entry control on the billing screen');
  }
  if (!/nothing can be charged/.test(billingHtml)) {
    report('/app/settings/billing', 'does not state that nothing can be charged');
  }
  if (/₹|\$|\bINR\b|\bUSD\b/.test(billingHtml)) {
    // Limits are engineering facts; prices are a commitment published only from
    // the verified pricing content. The plan comparison must carry neither.
    report('/app/settings/billing', 'renders a price in the plan comparison');
  }
  await audit('/app/settings/billing', billingElement);

  const adminElement = React.createElement(
    AdminShell,
    {
      role: 'platform_owner',
      roleLabel: 'Platform owner',
      permissions: auditPermissionsFor('platform_owner'),
      sudo: true,
    },
    React.createElement('h1', null, 'Platform overview'),
  );
  const adminHtml = renderToStaticMarkup(adminElement);
  if (!/Skip to content/.test(adminHtml)) {
    report('/admin', 'has no skip link');
  }
  if (!/aria-label="Admin"/.test(adminHtml)) {
    report('/admin', 'the admin navigation is not labelled');
  }
  if (!/Leave the panel/.test(adminHtml)) {
    report('/admin', 'offers no way back to the ordinary workspace');
  }
  await audit('/admin', adminElement);
}

/* -------------------------------------------------------------------------- */
/* Full document: root layout wrapping a page                                 */
/* -------------------------------------------------------------------------- */

// The audits above render page content only. This renders the whole document
// so the header, footer, skip link and site-wide structured data are covered.
//
// layout.tsx imports './globals.css', which the TypeScript loader cannot parse
// (a bundler handles that, and there is no bundler here). We compile a copy
// with the stylesheet import removed — the CSS has no effect on markup.
const { writeFileSync, rmSync, readFileSync: readSource } = await import('node:fs');
const { fileURLToPath } = await import('node:url');
const nodePath = (await import('node:path')).default;

const appDir = nodePath.resolve(nodePath.dirname(fileURLToPath(import.meta.url)), '..', 'src', 'app');
const layoutSource = readSource(nodePath.join(appDir, 'layout.tsx'), 'utf8').replace(
  /^import\s+'\.\/globals\.css';\s*$/m,
  '',
);
const tempLayout = nodePath.join(appDir, '__audit-layout.tsx');
writeFileSync(tempLayout, layoutSource);

let RootLayout;
let MarketingLayout;
let HomePage;
try {
  RootLayout = (await import(tempLayout)).default;
  MarketingLayout = (await import('../src/app/(marketing)/layout.tsx')).default;
  HomePage = (await import('../src/app/(marketing)/page.tsx')).default;
} finally {
  rmSync(tempLayout, { force: true });
}

{
  const name = 'full document (layout + /)';
  let html = '';
  try {
    html = renderToStaticMarkup(
      React.createElement(RootLayout, {
        children: React.createElement(MarketingLayout, {
          children: React.createElement(HomePage),
        }),
      }),
    );
  } catch (error) {
    report(name, `render threw: ${error.message.split('\n')[0]}`);
  }

  if (html) {
    if (!/<html lang="en"/.test(html)) report(name, 'html element is missing lang="en"');
    // Attribute order in the rendered output is not guaranteed, so match the
    // anchor tag and then look for both attributes within it.
    const skipLink = html.match(/<a\s[^>]*skip-link[^>]*>/);
    if (!skipLink || !/href="#main"/.test(skipLink[0])) {
      report(name, 'skip link missing or not pointing at #main');
    }
    if (!/id="main"/.test(html)) report(name, 'no #main landmark');
    if (!/<main /.test(html)) report(name, 'no <main> element');
    if ((html.match(/<main /g) ?? []).length > 1) report(name, 'more than one <main>');
    if (!/<header /.test(html)) report(name, 'no <header> element');
    if (!/<footer /.test(html)) report(name, 'no <footer> element');
    if (!/<nav [^>]*aria-label="Main"/.test(html)) report(name, 'main nav has no accessible name');
    if (!/<nav [^>]*aria-label="Footer"/.test(html)) report(name, 'footer nav has no accessible name');

    // Two JSON-LD blocks: site-wide (Organization + WebSite) and the page graph.
    const blocks = (html.match(/application\/ld\+json/g) ?? []).length;
    if (blocks < 2) report(name, `expected 2 JSON-LD blocks, found ${blocks}`);

    auditHeadings(name, html);
    auditJsonLd(name, html);
    auditLinksAndButtons(name, html);
    auditLeakage(name, html);
    auditImages(name, html);

    stats.push({
      page: name,
      bytes: html.length,
      headings: (html.match(/<h[1-6][\s>]/g) ?? []).length,
      jsonLdBlocks: blocks,
      links: (html.match(/<a\s/g) ?? []).length,
    });
  }
}

/* -------------------------------------------------------------------------- */
/* Report                                                                     */
/* -------------------------------------------------------------------------- */

console.log('Whole-page render audit\n');
console.log('  page                                 bytes  h*  ld  links');
console.log('  ' + '-'.repeat(62));
for (const row of stats) {
  console.log(
    `  ${row.page.padEnd(34)} ${String(row.bytes).padStart(7)} ${String(row.headings).padStart(3)} ${String(row.jsonLdBlocks).padStart(3)} ${String(row.links).padStart(6)}`,
  );
}
console.log('');

if (problems.length === 0) {
  console.log(`PASS — ${stats.length} pages rendered, 0 problems.`);
  process.exit(0);
}
console.log(`FAIL — ${problems.length} problem(s) across ${stats.length} pages:\n`);
for (const problem of problems) console.log(`  ✗ ${problem}`);
process.exit(1);
