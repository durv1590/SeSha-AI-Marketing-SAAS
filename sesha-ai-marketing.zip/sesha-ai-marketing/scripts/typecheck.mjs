#!/usr/bin/env node
/**
 * Offline type check.
 *
 * WHAT THIS IS
 * A real `tsc` run — the actual TypeScript compiler, the project's real
 * tsconfig settings (strict, noUncheckedIndexedAccess and all) — over every
 * `.ts` file in the codebase. It is not an approximation of type checking;
 * within the files it covers, it IS type checking.
 *
 * WHAT IT DOES NOT COVER
 * `.tsx` files. Type-checking JSX needs @types/react, which is not available
 * offline, and a hand-written stub would report confident nonsense. So the
 * components and pages are covered by scripts/render-check.mjs and
 * scripts/page-audit.mjs, which execute them instead, and remain the part of
 * the codebase most likely to surface errors on the first real `npm run build`.
 *
 * Requires: node_modules/@types/node (scripts/sandbox-setup.mjs links it).
 * Usage: node scripts/typecheck.mjs
 */

import { createRequire } from 'node:module';
import { existsSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const ts = require('typescript');

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

if (!existsSync(path.join(root, 'node_modules', '@types', 'node'))) {
  console.error('No node_modules/@types/node — run: node scripts/sandbox-setup.mjs');
  process.exit(1);
}

function walk(dir, out = []) {
  if (!existsSync(dir)) return out;
  for (const entry of readdirSync(dir)) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) walk(full, out);
    // .ts only: see "WHAT IT DOES NOT COVER" above.
    else if (entry.endsWith('.ts') && !entry.endsWith('.d.ts')) out.push(full);
  }
  return out;
}

const files = [
  ...walk(path.join(root, 'src', 'lib')),
  ...walk(path.join(root, 'src', 'content')),
  // API route handlers are .ts, so they are covered too.
  ...walk(path.join(root, 'src', 'app')),
  ...walk(path.join(root, 'tests')).filter((file) => !file.includes(`${path.sep}e2e${path.sep}`)),
  path.join(root, 'scripts', 'types', 'next-shims.d.ts'),
];

// The project's real options, minus the emit and JSX settings that do not
// apply to a check-only run of .ts files.
const options = {
  target: ts.ScriptTarget.ES2022,
  lib: ['lib.dom.d.ts', 'lib.dom.iterable.d.ts', 'lib.es2022.d.ts'],
  module: ts.ModuleKind.ESNext,
  moduleResolution: ts.ModuleResolutionKind.Bundler,
  strict: true,
  noUncheckedIndexedAccess: true,
  noImplicitOverride: true,
  noFallthroughCasesInSwitch: true,
  forceConsistentCasingInFileNames: true,
  esModuleInterop: true,
  resolveJsonModule: true,
  skipLibCheck: true,
  isolatedModules: true,
  noEmit: true,
  types: ['node'],
  paths: { '@/*': [path.join(root, 'src', '*')] },
};

console.log(`Type check — ${files.length} TypeScript files (strict, noUncheckedIndexedAccess)\n`);

const program = ts.createProgram(files, options);
const diagnostics = [
  ...program.getSyntacticDiagnostics(),
  ...program.getSemanticDiagnostics(),
  ...program.getGlobalDiagnostics(),
];

if (diagnostics.length === 0) {
  console.log('PASS — no type errors in the checked files.');
  console.log('(.tsx files are not covered: see the header of this script.)');
  process.exit(0);
}

const formatted = ts.formatDiagnosticsWithColorAndContext(diagnostics, {
  getCanonicalFileName: (file) => file,
  getCurrentDirectory: () => root,
  getNewLine: () => '\n',
});

console.log(formatted);
console.error(`FAIL — ${diagnostics.length} type error${diagnostics.length === 1 ? '' : 's'}.`);
process.exit(1);
