#!/usr/bin/env node
/**
 * WCAG contrast check over the design tokens.
 *
 * WHY THIS EXISTS
 * Contrast is the one accessibility property that cannot be checked by reading
 * the markup: it lives in the colour values, and a token pair that fails is
 * invisible in a code review and invisible in a screenshot to anyone with normal
 * vision. Phase 8's audit found no automated check, so every claim about
 * contrast in this project was an assertion.
 *
 * WHAT IT CHECKS
 * Every foreground token against every background token it is actually used on,
 * in BOTH themes, against the WCAG 2.1 thresholds:
 *   · 4.5:1 for body text (AA)
 *   · 3.0:1 for large text and for non-text elements such as borders and focus
 *     rings (AA)
 *
 * The pairs are declared explicitly rather than generated. A cross-product of
 * every token against every other would report hundreds of failures for
 * combinations nobody uses, and a report that is mostly noise is a report that
 * gets ignored — the same reasoning as the intrinsic-element gap in the .tsx
 * checker.
 *
 * THE COLOUR MATHS
 * Tokens are authored in OKLCH. Converting OKLCH → linear sRGB → relative
 * luminance is done here in full rather than approximated from the L channel,
 * because OKLCH's L is perceptual lightness and WCAG's formula wants relative
 * luminance — they are not the same number, and using one for the other gives
 * confidently wrong ratios. sRGB values outside [0,1] after conversion are
 * clamped, which is what a browser does when it renders an out-of-gamut colour.
 *
 * Usage: node scripts/contrast-check.mjs
 */

import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const css = readFileSync(path.join(root, 'src', 'app', 'globals.css'), 'utf8');

/* -------------------------------------------------------------------------- */
/* Colour                                                                     */
/* -------------------------------------------------------------------------- */

/** OKLCH → linear sRGB. The standard matrices, written out. */
function oklchToLinearRgb(L, C, hDeg) {
  const h = (hDeg * Math.PI) / 180;
  const a = C * Math.cos(h);
  const b = C * Math.sin(h);

  // OKLab → LMS'
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
  const s_ = L - 0.0894841775 * a - 1.291485548 * b;

  const l = l_ ** 3;
  const m = m_ ** 3;
  const s = s_ ** 3;

  // LMS → linear sRGB
  return [
    +4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
    -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
    -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s,
  ];
}

/** WCAG relative luminance, from LINEAR sRGB (no gamma step needed). */
function relativeLuminance([r, g, b]) {
  const clamp = (value) => Math.min(1, Math.max(0, value));
  return 0.2126 * clamp(r) + 0.7152 * clamp(g) + 0.0722 * clamp(b);
}

function contrastRatio(a, b) {
  const la = relativeLuminance(a);
  const lb = relativeLuminance(b);
  const lighter = Math.max(la, lb);
  const darker = Math.min(la, lb);
  return (lighter + 0.05) / (darker + 0.05);
}

/* -------------------------------------------------------------------------- */
/* Reading the tokens                                                         */
/* -------------------------------------------------------------------------- */

/**
 * Pulls `--name: oklch(L C H)` declarations out of one CSS block.
 *
 * Tokens defined as `var(--something)` are resolved against the same block, so
 * the neutral ramp indirection is followed rather than skipped.
 */
function readTokens(block, inherited = new Map()) {
  // `inherited` carries the tokens from `:root` — the brand/neutral ramps live
  // there and are NOT redefined per theme, so a dark-block declaration like
  // `--primary-subtle-fg: var(--brand-200)` can only be resolved against them.
  // Resolving within one block alone silently left such tokens at their light
  // value, which reported a contrast failure that did not exist. That happened,
  // and it nearly caused a working palette to be "fixed".
  const direct = new Map(inherited);
  const aliases = new Map();

  for (const match of block.matchAll(/--([\w-]+):\s*([^;]+);/g)) {
    const name = match[1];
    const value = match[2].trim();

    const oklch = /^oklch\(\s*([\d.]+)\s+([\d.]+)\s+([\d.]+)/.exec(value);
    if (oklch) {
      direct.set(name, [Number(oklch[1]), Number(oklch[2]), Number(oklch[3])]);
      continue;
    }
    const alias = /^var\(--([\w-]+)\)$/.exec(value);
    if (alias) aliases.set(name, alias[1]);
  }

  // Resolve aliases, following chains.
  for (const [name, target] of aliases) {
    let current = target;
    const seen = new Set([name]);
    while (current && !direct.has(current) && aliases.has(current) && !seen.has(current)) {
      seen.add(current);
      current = aliases.get(current);
    }
    if (current && direct.has(current)) direct.set(name, direct.get(current));
  }

  return direct;
}

function blockFor(selector) {
  // Matches `selector { ... }` up to the first closing brace at line start.
  const pattern = new RegExp(`${selector}\\s*\\{([\\s\\S]*?)\\n\\}`, 'm');
  const match = pattern.exec(css);
  return match ? match[1] : '';
}

const light = readTokens(blockFor(':root'));
// The dark block redefines only what changes, and its aliases point at ramps
// declared in `:root`, so the light map is passed in as the base.
const darkResolved = readTokens(blockFor('\\.dark'), light);

/* -------------------------------------------------------------------------- */
/* The pairs that are actually rendered                                       */
/* -------------------------------------------------------------------------- */

/**
 * `min` is the WCAG threshold this pair must meet.
 *
 * 4.5 for anything that is body copy at normal size; 3.0 for large text, and for
 * non-text contrast such as borders and the focus ring, which is the correct
 * threshold for those under WCAG 2.1 (1.4.11).
 */
const PAIRS = [
  // Body text on every surface it lands on.
  { fg: 'fg', bg: 'bg', min: 4.5, note: 'body text on the page' },
  { fg: 'fg', bg: 'surface', min: 4.5, note: 'body text on a card' },
  { fg: 'fg', bg: 'bg-subtle', min: 4.5, note: 'body text on a subtle panel' },
  { fg: 'fg', bg: 'bg-muted', min: 4.5, note: 'body text on a muted panel' },

  // Secondary text. This is the tier that usually fails.
  { fg: 'fg-muted', bg: 'bg', min: 4.5, note: 'secondary text on the page' },
  { fg: 'fg-muted', bg: 'surface', min: 4.5, note: 'secondary text on a card' },
  { fg: 'fg-muted', bg: 'bg-subtle', min: 4.5, note: 'secondary text on a subtle panel' },
  { fg: 'fg-subtle', bg: 'bg', min: 4.5, note: 'tertiary text on the page' },
  { fg: 'fg-subtle', bg: 'surface', min: 4.5, note: 'tertiary text on a card' },

  // Interactive.
  { fg: 'primary', bg: 'bg', min: 4.5, note: 'a link on the page' },
  { fg: 'primary', bg: 'surface', min: 4.5, note: 'a link on a card' },
  { fg: 'primary-fg', bg: 'primary', min: 4.5, note: 'text on a primary button' },
  { fg: 'accent-fg', bg: 'accent', min: 4.5, note: 'text on an accent surface' },
  { fg: 'primary-subtle-fg', bg: 'primary-subtle', min: 4.5, note: 'text on a subtle badge' },

  // Status colours, as text on the page and on their own subtle backgrounds.
  { fg: 'success', bg: 'bg', min: 4.5, note: 'success text' },
  { fg: 'success', bg: 'success-subtle', min: 4.5, note: 'success text on its badge' },
  { fg: 'warning', bg: 'bg', min: 4.5, note: 'warning text' },
  { fg: 'warning', bg: 'warning-subtle', min: 4.5, note: 'warning text on its badge' },
  { fg: 'danger', bg: 'bg', min: 4.5, note: 'error text' },
  { fg: 'danger', bg: 'danger-subtle', min: 4.5, note: 'error text on its badge' },
  { fg: 'info', bg: 'bg', min: 4.5, note: 'info text' },
  { fg: 'info', bg: 'info-subtle', min: 4.5, note: 'info text on its badge' },

  // Non-text: 3:1 under WCAG 2.1 SC 1.4.11.
  { fg: 'border-strong', bg: 'bg', min: 3, note: 'a control border' },
  { fg: 'border-strong', bg: 'surface', min: 3, note: 'a control border on a card' },
  { fg: 'ring', bg: 'bg', min: 3, note: 'the focus ring' },
  { fg: 'ring', bg: 'surface', min: 3, note: 'the focus ring on a card' },
  // The hover state of an input must remain discernible too.
  { fg: 'fg-muted', bg: 'surface', min: 3, note: 'an input border on hover' },
];

/**
 * DELIBERATELY NOT CHECKED: `--border` against `--bg` or `--surface`.
 *
 * It is a decorative rule — card edges, table dividers, section separators —
 * and WCAG 2.1 SC 1.4.11 covers "visual information required to identify user
 * interface components", which a divider is not. Holding it to 3:1 would make
 * every card on every page look like a wireframe for no accessibility gain.
 *
 * The distinction is load-bearing, so it is written down: controls use
 * `--border-strong`, decoration uses `--border`, and `components/ui/field.tsx`
 * says the same thing at the point of use.
 */

/* -------------------------------------------------------------------------- */
/* Run                                                                        */
/* -------------------------------------------------------------------------- */

const themes = [
  ['light', light],
  ['dark', darkResolved],
];

const failures = [];
const missing = [];
const rows = [];

for (const [themeName, tokens] of themes) {
  for (const pair of PAIRS) {
    const fg = tokens.get(pair.fg);
    const bg = tokens.get(pair.bg);
    if (!fg || !bg) {
      missing.push(`${themeName}: --${!fg ? pair.fg : pair.bg} is not defined`);
      continue;
    }
    const ratio = contrastRatio(oklchToLinearRgb(...fg), oklchToLinearRgb(...bg));
    const ok = ratio >= pair.min;
    rows.push({ themeName, pair, ratio, ok });
    if (!ok) failures.push({ themeName, pair, ratio });
  }
}

console.log(`Contrast check — ${rows.length} token pairs across light and dark\n`);

for (const [themeName] of themes) {
  console.log(`  ${themeName}`);
  for (const row of rows.filter((entry) => entry.themeName === themeName)) {
    const mark = row.ok ? 'ok  ' : 'FAIL';
    console.log(
      `    ${mark} ${row.ratio.toFixed(2).padStart(5)}:1  (needs ${row.pair.min})  ${row.pair.note}` +
        `  [--${row.pair.fg} on --${row.pair.bg}]`,
    );
  }
  console.log('');
}

if (missing.length > 0) {
  console.log('Tokens not found (the pair list and the stylesheet disagree):');
  for (const line of missing) console.log(`  ${line}`);
  console.log('');
}

if (failures.length === 0 && missing.length === 0) {
  console.log('PASS — every declared pair meets its WCAG threshold in both themes.');
  console.log('');
  console.log('Scope: these are the TOKEN pairs the design system declares. It does not');
  console.log('prove a particular screen uses them correctly — that needs a rendered page.');
  process.exit(0);
}

console.log(`FAIL — ${failures.length} pair(s) below threshold, ${missing.length} missing.`);
process.exit(1);
