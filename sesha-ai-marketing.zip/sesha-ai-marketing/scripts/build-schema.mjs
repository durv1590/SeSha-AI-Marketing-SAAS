#!/usr/bin/env node
/**
 * Regenerates db/schema.sql from db/migrations/*.sql.
 *
 * WHY: migrations are the source of truth (forward-only, never edited once
 * applied), but a single readable schema file is genuinely useful for review.
 * Maintaining both by hand guarantees drift, so this concatenates them and
 * `tests/database.test.ts` fails if the generated file is stale.
 *
 * Usage: node scripts/build-schema.mjs [--check]
 */

import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const migrationsDir = path.join(root, 'db', 'migrations');
const target = path.join(root, 'db', 'schema.sql');

export function buildSchema() {
  const files = readdirSync(migrationsDir)
    .filter((name) => name.endsWith('.sql'))
    .sort();

  const parts = [
    '-- ---------------------------------------------------------------------------',
    '-- SeSha AI Marketing — full schema',
    '-- ---------------------------------------------------------------------------',
    '-- GENERATED FILE. Do not edit.',
    '-- Source of truth: db/migrations/*.sql (forward-only).',
    '-- Regenerate with: node scripts/build-schema.mjs',
    '-- ---------------------------------------------------------------------------',
    '',
  ];

  for (const file of files) {
    const contents = readFileSync(path.join(migrationsDir, file), 'utf8')
      // Transaction wrappers belong to the individual migration, not the
      // concatenated view.
      .replace(/^\s*BEGIN;\s*$/m, '')
      .replace(/^\s*COMMIT;\s*$/m, '')
      .trim();
    parts.push(`-- ===== ${file} ${'='.repeat(Math.max(0, 60 - file.length))}`, '', contents, '');
  }

  return `${parts.join('\n').replace(/\n{4,}/g, '\n\n\n')}\n`;
}

const generated = buildSchema();

if (process.argv.includes('--check')) {
  const current = (() => {
    try {
      return readFileSync(target, 'utf8');
    } catch {
      return '';
    }
  })();
  if (current !== generated) {
    console.error('db/schema.sql is stale. Run: node scripts/build-schema.mjs');
    process.exit(1);
  }
  console.log('db/schema.sql is up to date.');
  process.exit(0);
}

writeFileSync(target, generated);
const tables = [...generated.matchAll(/CREATE TABLE (?:IF NOT EXISTS )?(\w+)/g)].map((m) => m[1]);
console.log(`Wrote db/schema.sql — ${tables.length} tables:`);
console.log(`  ${tables.join(', ')}`);
