#!/usr/bin/env node
/**
 * Server-render smoke check.
 *
 * WHY THIS EXISTS
 * This project was developed in an environment with no npm registry access, so
 * `next build` could not be run. This script gets as close as possible: it
 * server-renders the real components with react-dom/server against minimal
 * stand-ins for the handful of Next.js modules they import, then asserts on the
 * HTML that actually comes out.
 *
 * That verifies things a static parse cannot:
 *   · components render without throwing;
 *   · accessibility attributes are present in the OUTPUT, not just the source;
 *   · the FAQ accordion emits its answers into the HTML (the AEO requirement);
 *   · JSON-LD serialises to valid, escaped JSON;
 *   · form controls are correctly associated with their labels.
 *
 * REQUIREMENTS: the stand-in modules in node_modules/next created by
 * scripts/sandbox-setup.mjs. With the real Next.js installed, prefer
 * `npm run build` and the Playwright suite in tests/e2e — this script is a
 * fallback for environments that cannot install dependencies.
 *
 * Usage: node scripts/sandbox-setup.mjs && node scripts/render-check.mjs
 */

import assert from 'node:assert/strict';
import { renderToStaticMarkup } from 'react-dom/server';
import React from 'react';

const results = [];
let failures = 0;

function check(name, fn) {
  try {
    fn();
    results.push(`  ok   ${name}`);
  } catch (error) {
    failures += 1;
    results.push(`  FAIL ${name}\n         ${error.message.split('\n')[0]}`);
  }
}

const html = (element) => renderToStaticMarkup(element);

const { Button } = await import('../src/components/ui/button.tsx');
const { Accordion } = await import('../src/components/ui/accordion.tsx');
const { Badge } = await import('../src/components/ui/badge.tsx');
const { Alert } = await import('../src/components/ui/alert.tsx');
const { Field, Input, Checkbox, Honeypot } = await import('../src/components/ui/field.tsx');
const { Icon } = await import('../src/components/ui/icon.tsx');
const { Breadcrumbs } = await import('../src/components/layout/breadcrumbs.tsx');
const { JsonLd } = await import('../src/components/seo/json-ld.tsx');
const { Prose } = await import('../src/components/marketing/prose.tsx');
const { PricingCard } = await import('../src/components/marketing/pricing-card.tsx');
const { Steps } = await import('../src/components/marketing/steps.tsx');
const { pricingTiers } = await import('../src/content/pricing.ts');
const { buildGraph, organizationSchema, webSiteSchema } = await import('../src/lib/schema/index.ts');

/* --------------------------------- Button -------------------------------- */

check('Button renders a <button> with no href', () => {
  const out = html(React.createElement(Button, {}, 'Send'));
  assert.match(out, /^<button/);
  assert.ok(!out.includes('<a '));
});

check('Button renders an <a> when given an href', () => {
  const out = html(React.createElement(Button, { href: '/pricing' }, 'Pricing'));
  assert.match(out, /^<a[^>]+href="\/pricing"/);
});

check('Button marks external links rel="noopener noreferrer"', () => {
  const out = html(React.createElement(Button, { href: 'https://example.com' }, 'Out'));
  assert.match(out, /rel="noopener noreferrer"/);
});

check('Button applies the requested variant and size classes', () => {
  const out = html(React.createElement(Button, { variant: 'secondary', size: 'lg' }, 'X'));
  assert.match(out, /class="[^"]*h-12/);
  assert.match(out, /class="[^"]*border-border-strong/);
  // NOTE: class-conflict resolution is tailwind-merge's job. The sandbox
  // stand-in only approximates it, so asserting on dedup here would be testing
  // the stand-in rather than this codebase.
});

/* -------------------------------- Accordion ------------------------------- */

check('Accordion answers are present in the HTML (AEO requirement)', () => {
  const out = html(
    React.createElement(Accordion, {
      items: [
        { question: 'What is AEO?', answer: 'Answer engine optimisation.' },
        { question: 'Second question?', answer: 'A second answer that must also be in the DOM.' },
      ],
    }),
  );
  assert.ok(out.includes('Answer engine optimisation.'));
  // The second item is collapsed, and its answer must STILL be rendered.
  assert.ok(
    out.includes('A second answer that must also be in the DOM.'),
    'collapsed answers must still be server-rendered',
  );
  assert.match(out, /<details/);
  assert.match(out, /<summary/);
});

check('Accordion opens only the first item by default', () => {
  const out = html(
    React.createElement(Accordion, {
      items: [
        { question: 'One', answer: 'A' },
        { question: 'Two', answer: 'B' },
      ],
    }),
  );
  assert.equal((out.match(/<details[^>]*open/g) ?? []).length, 1);
});

/* ------------------------------ Breadcrumbs ------------------------------- */

check('Breadcrumbs render a labelled nav with aria-current on the last item', () => {
  const out = html(React.createElement(Breadcrumbs, { path: '/solutions/startups' }));
  assert.match(out, /aria-label="Breadcrumb"/);
  assert.match(out, /aria-current="page"/);
  assert.equal((out.match(/aria-current="page"/g) ?? []).length, 1);
  assert.ok(out.includes('Startups'));
  assert.ok(out.includes('Home'));
});

check('Breadcrumbs render nothing on the home page', () => {
  assert.equal(html(React.createElement(Breadcrumbs, { path: '/' })), '');
});

/* --------------------------------- Icons ---------------------------------- */

check('Decorative icons are hidden from assistive technology', () => {
  const out = html(React.createElement(Icon, { name: 'check' }));
  assert.match(out, /aria-hidden="true"/);
  assert.ok(!out.includes('<title>'));
});

check('Titled icons expose an accessible name', () => {
  const out = html(React.createElement(Icon, { name: 'check', title: 'Included' }));
  assert.match(out, /role="img"/);
  assert.match(out, /<title>Included<\/title>/);
  assert.ok(!out.includes('aria-hidden'));
});

/* ---------------------------------- Forms --------------------------------- */

check('Field associates label, hint and error with the control', () => {
  const out = html(
    React.createElement(Field, {
      id: 'email',
      label: 'Work email',
      hint: 'We only use this to reply.',
      error: 'Enter a valid email address.',
      required: true,
      children: ({ id, describedBy, invalid }) =>
        React.createElement(Input, {
          id,
          name: 'email',
          'aria-describedby': describedBy,
          'aria-invalid': invalid || undefined,
        }),
    }),
  );
  assert.match(out, /<label for="email"/);
  assert.match(out, /id="email-hint"/);
  assert.match(out, /id="email-error"/);
  assert.match(out, /aria-describedby="email-hint email-error"/);
  assert.match(out, /aria-invalid="true"/);
  assert.match(out, /role="alert"/);
});

check('Required asterisk is hidden from screen readers', () => {
  const out = html(
    React.createElement(Field, {
      id: 'x',
      label: 'Name',
      required: true,
      children: ({ id }) => React.createElement(Input, { id }),
    }),
  );
  assert.match(out, /<span class="[^"]*" aria-hidden="true">\*<\/span>/);
});

check('Checkbox links its label and error', () => {
  const out = html(
    React.createElement(Checkbox, { id: 'consent', label: 'I agree', error: 'Required.' }),
  );
  assert.match(out, /<label for="consent"/);
  assert.match(out, /aria-describedby="consent-error"/);
  assert.match(out, /type="checkbox"/);
});

check('Honeypot is hidden from both sighted users and screen readers', () => {
  const out = html(React.createElement(Honeypot, {}));
  assert.match(out, /aria-hidden="true"/);
  assert.match(out, /tabindex="-1"/);
  assert.match(out, /left-\[-9999px\]/);
});

/* --------------------------------- Alert ---------------------------------- */

check('Live alerts announce; static alerts do not', () => {
  const live = html(React.createElement(Alert, { tone: 'success', live: true }, 'Saved'));
  assert.match(live, /role="status"/);
  assert.match(live, /aria-live="polite"/);

  const stat = html(React.createElement(Alert, { tone: 'info' }, 'Note'));
  assert.ok(!stat.includes('aria-live'));
});

/* --------------------------------- Prose ---------------------------------- */

check('Prose emits semantic HTML with stable heading ids', () => {
  const out = html(
    React.createElement(Prose, {
      blocks: [
        { kind: 'heading', id: 'why', text: 'Why it matters' },
        { kind: 'paragraph', text: 'Because structure is readable.' },
        { kind: 'list', items: ['One', 'Two'] },
        { kind: 'list', ordered: true, items: ['First', 'Second'] },
        { kind: 'definition', term: 'AEO', text: 'Answer engine optimisation.' },
        { kind: 'callout', title: 'Note', text: 'A callout.' },
      ],
    }),
  );
  assert.match(out, /<h2 id="why"/);
  assert.match(out, /<ul/);
  assert.match(out, /<ol/);
  assert.match(out, /<dl/);
  assert.match(out, /<dt/);
  assert.match(out, /<dd/);
  assert.match(out, /<aside/);
});

/* ------------------------------- Pricing ---------------------------------- */

check('Unverified tiers never render a currency figure', () => {
  for (const tier of pricingTiers) {
    const out = html(React.createElement(PricingCard, { tier }));
    if (!tier.verified) {
      assert.ok(out.includes('Pricing on request'), `${tier.name} must show the request state`);
      assert.ok(!/[$€£]\s?\d/.test(out), `${tier.name} leaked a price figure`);
    }
  }
});

check('Pricing card renders its limits as a description list', () => {
  const out = html(React.createElement(PricingCard, { tier: pricingTiers[0] }));
  assert.match(out, /<dl/);
  assert.match(out, /<dt/);
});

/* --------------------------------- Steps ---------------------------------- */

check('Steps render an ordered list with screen-reader step numbers', () => {
  const out = html(
    React.createElement(Steps, {
      steps: [{ number: 1, title: 'Define', body: 'Set up the brand kit.' }],
    }),
  );
  assert.match(out, /<ol/);
  assert.match(out, /<span class="sr-only">Step 1: <\/span>/);
});

/* --------------------------------- JSON-LD -------------------------------- */

check('JSON-LD renders a valid, parseable script block', () => {
  const out = html(
    React.createElement(JsonLd, { graph: buildGraph([organizationSchema(), webSiteSchema()]) }),
  );
  assert.match(out, /<script type="application\/ld\+json">/);
  const json = out.replace(/^<script type="application\/ld\+json">/, '').replace(/<\/script>$/, '');
  const parsed = JSON.parse(json.replace(/\\u003c/g, '<').replace(/\\u003e/g, '>'));
  assert.equal(parsed['@context'], 'https://schema.org');
  assert.equal(parsed['@graph'].length, 2);
});

check('JSON-LD escapes a closing script tag in the data', () => {
  const out = html(
    React.createElement(JsonLd, { graph: { '@type': 'Thing', name: '</script><img onerror=1>' } }),
  );
  assert.ok(!out.includes('</script><img'), 'must not allow script breakout');
  assert.ok(out.includes('\\u003c'));
});

/* --------------------------------- Badge ---------------------------------- */

check('Badge renders each tone without class conflicts', () => {
  for (const tone of ['neutral', 'brand', 'success', 'warning', 'danger', 'info', 'outline']) {
    const out = html(React.createElement(Badge, { tone }, tone));
    assert.match(out, /^<span class="/);
  }
});

/* ------------------------- Phase 3: provenance ---------------------------- */
// The provenance display is the user-visible half of "never present AI
// assumptions as facts". These assertions check the rendered HTML, not the
// source, because the requirement is about what the reader actually sees.

const { ProvenanceBlocks, ClaimWarnings, ProvenanceLegend, ProvenanceBadge } = await import(
  '../src/components/ai/provenance-view.tsx'
);
const { PROVENANCE_KINDS, PROVENANCE_DISPLAY } = await import('../src/lib/ai/provenance.ts');

check('an unsourced block is LABELLED in the output', () => {
  const out = html(
    React.createElement(ProvenanceBlocks, {
      blocks: [{ kind: 'ai_estimate', text: 'Weekends are probably busier.' }],
    }),
  );
  assert.ok(out.includes(PROVENANCE_DISPLAY.ai_estimate.label), 'the estimate label is missing');
});

check('a sourced block is NOT labelled, so the labels stay meaningful', () => {
  const out = html(
    React.createElement(ProvenanceBlocks, {
      blocks: [{ kind: 'user_provided', text: 'You sell coffee.' }],
    }),
  );
  assert.ok(!out.includes(PROVENANCE_DISPLAY.ai_estimate.label));
  assert.ok(!out.includes(PROVENANCE_DISPLAY.user_provided.label));
  assert.ok(out.includes('You sell coffee.'));
});

check('every provenance kind renders a badge', () => {
  for (const kind of PROVENANCE_KINDS) {
    const out = html(React.createElement(ProvenanceBadge, { kind }));
    assert.ok(out.includes(PROVENANCE_DISPLAY[kind].label), `${kind} rendered no label`);
  }
});

check('a claim ERROR renders as a live alert with the offending excerpt', () => {
  const out = html(
    React.createElement(ClaimWarnings, {
      warnings: [
        {
          severity: 'error',
          message: 'States a percentage as fact with no source.',
          excerpt: 'grew 34% last year',
          kind: 'ai_inference',
          blockIndex: 0,
        },
      ],
    }),
  );
  assert.ok(out.includes('role="alert"'), 'an error must be announced');
  assert.ok(out.includes('grew 34% last year'), 'the excerpt must be shown');
});

check('a claim WARNING is not announced as an alert', () => {
  const out = html(
    React.createElement(ClaimWarnings, {
      warnings: [
        { severity: 'warning', message: 'Contains an estimate.', excerpt: 'about 20%', kind: 'ai_estimate', blockIndex: 0 },
      ],
    }),
  );
  assert.ok(!out.includes('role="alert"'));
});

check('no warnings renders nothing at all', () => {
  assert.equal(html(React.createElement(ClaimWarnings, { warnings: [] })), '');
});

check('the legend explains all seven kinds', () => {
  const out = html(React.createElement(ProvenanceLegend, {}));
  for (const kind of PROVENANCE_KINDS) {
    assert.ok(out.includes(PROVENANCE_DISPLAY[kind].label), `legend omits ${kind}`);
  }
});

/* ------------------------- Phase 3: no fake publishing -------------------- */

const { SocialManager } = await import('../src/components/ai/social-manager.tsx');
const { PLATFORMS, PLATFORM_SPECS } = await import('../src/lib/social/platforms.ts');

const project = {
  id: 'p1',
  organizationId: 'o1',
  businessId: 'b1',
  name: 'Acme Coffee',
  slug: 'acme-coffee',
  description: null,
  createdBy: 'u1',
  deletedAt: null,
  createdAt: new Date(),
  updatedAt: new Date(),
};

check('the social manager states on screen that nothing publishes', () => {
  const out = html(
    React.createElement(SocialManager, {
      projects: [project],
      posts: [],
      enabled: true,
      disabledReason: '',
    }),
  );
  assert.match(out, /does not publish to any platform/i);

  // No control on this screen offers to publish or schedule. Checked against
  // the rendered labels rather than the source, because a button is what a
  // user would actually click.
  const labels = [...out.matchAll(/>([^<>]{2,40})</g)].map((match) => match[1].trim());
  for (const label of labels) {
    assert.ok(
      !/^(publish|post now|schedule|send now|go live)$/i.test(label),
      `a control is labelled "${label}", which implies publishing`,
    );
  }
});

check('every platform is shown as NOT connected, with its requirement', () => {
  const out = html(
    React.createElement(SocialManager, {
      projects: [project],
      posts: [],
      enabled: true,
      disabledReason: '',
    }),
  );
  for (const id of PLATFORMS) {
    assert.ok(out.includes(PLATFORM_SPECS[id].label), `${id} is missing from the platform table`);
  }
  assert.ok(out.includes('Not connected'));
});

check('the social manager renders exactly one h1', () => {
  const out = html(
    React.createElement(SocialManager, {
      projects: [project],
      posts: [],
      enabled: true,
      disabledReason: '',
    }),
  );
  assert.equal((out.match(/<h1/g) ?? []).length, 1);
});

check('with no projects it explains why, rather than showing an empty form', () => {
  const out = html(
    React.createElement(SocialManager, {
      projects: [],
      posts: [],
      enabled: true,
      disabledReason: '',
    }),
  );
  assert.match(out, /Create a project first/i);
  assert.ok(!out.includes('<form'), 'a form with nothing to act on is worse than none');
});

/* ------------------------- Phase 3: other surfaces ------------------------ */

const { Copilot } = await import('../src/components/ai/copilot.tsx');
const { ContentStudio } = await import('../src/components/ai/content-studio.tsx');
const { StrategyBuilder } = await import('../src/components/ai/strategy-builder.tsx');
const { SocialCalendar } = await import('../src/components/ai/social-calendar.tsx');
const { CONTENT_FORMATS, FORMAT_SPECS, LANGUAGES, LANGUAGE_SPECS } = await import(
  '../src/lib/content/types.ts'
);

check('the copilot renders one h1 and its input', () => {
  const out = html(
    React.createElement(Copilot, { projects: [project], enabled: true, disabledReason: '' }),
  );
  assert.equal((out.match(/<h1/g) ?? []).length, 1);
  assert.ok(out.includes('<textarea'));
});

check('an unconfigured deployment SAYS SO instead of failing silently', () => {
  const out = html(
    React.createElement(Copilot, {
      projects: [project],
      enabled: false,
      disabledReason: 'No AI provider key is set on this deployment.',
    }),
  );
  assert.ok(out.includes('No AI provider key is set on this deployment.'));
  assert.ok(out.includes('disabled'), 'the control must actually be disabled, not just captioned');
});

check('content studio offers all twenty formats and all three languages', () => {
  const out = html(
    React.createElement(ContentStudio, {
      projects: [project],
      recent: [],
      enabled: true,
      disabledReason: '',
    }),
  );
  for (const format of CONTENT_FORMATS) {
    assert.ok(out.includes(FORMAT_SPECS[format].label), `format missing: ${format}`);
  }
  for (const language of LANGUAGES) {
    assert.ok(out.includes(LANGUAGE_SPECS[language].label), `language missing: ${language}`);
  }
});

check('content studio shows no invented draft before anything is generated', () => {
  const out = html(
    React.createElement(ContentStudio, {
      projects: [project],
      recent: [],
      enabled: true,
      disabledReason: '',
    }),
  );
  assert.match(out, /Your draft will appear here/i);
});

check('the strategy builder renders without a plan loaded', () => {
  const out = html(
    React.createElement(StrategyBuilder, {
      projects: [project],
      enabled: true,
      disabledReason: '',
      canApprove: true,
    }),
  );
  assert.equal((out.match(/<h1/g) ?? []).length, 1);
  assert.match(out, /Check what can be built/i);
});

check('the calendar calls its dates planned, never scheduled', () => {
  const out = html(React.createElement(SocialCalendar, { projects: [project] }));
  assert.match(out, /notes to you, not a schedule/i);
});

/* ------------------------- Phase 4: audit findings ------------------------ */
// A finding must show all six required parts, and the score must never appear
// without the sentence saying it is our own weighting.

const { FindingCard, ScoreCard, NotCheckedList, SuppressedNotice } = await import(
  '../src/components/audit/finding-list.tsx'
);
const { KeywordTable } = await import('../src/components/audit/keyword-table.tsx');
const { blockedRangeLabels, checkUrl, isAllowedAddress } = await import('../src/lib/crawler/index.ts');

const sampleFinding = {
  id: 'seo-title-missing-1',
  category: 'Metadata',
  severity: 'critical',
  issue: '2 pages have no title element.',
  evidence: {
    observation: 'No non-empty <title> was found in the head of these pages.',
    urls: ['https://example.com/a'],
    affectedCount: 2,
    totalCount: 12,
  },
  recommendation: 'Give every page a unique title of roughly 15 to 60 characters.',
  expectedBenefit: 'The title is what search engines and people use to judge what a page is about.',
  confidence: 'high',
  dataBasis: 'crawled_page',
};

check('a finding renders all six required parts', () => {
  const out = html(React.createElement(FindingCard, { finding: sampleFinding }));
  assert.ok(out.includes('2 pages have no title element.'), 'the issue is missing');
  assert.ok(out.includes('No non-empty'), 'the evidence is missing');
  assert.ok(out.includes('https://example.com/a'), 'the cited URL is missing');
  assert.ok(out.includes('Give every page a unique title'), 'the recommendation is missing');
  assert.ok(out.includes('The title is what search engines'), 'the expected benefit is missing');
  assert.match(out, /Confidence:/, 'the confidence is missing');
  assert.match(out, /Measured on your pages/, 'the data basis is missing');
});

check('a HEURISTIC finding says it is a general rule, not a measurement', () => {
  const out = html(
    React.createElement(FindingCard, {
      finding: { ...sampleFinding, dataBasis: 'heuristic', confidence: 'low' },
    }),
  );
  assert.match(out, /general rule, not a measurement/i);
});

check('the score is NEVER rendered without its basis', () => {
  const out = html(
    React.createElement(ScoreCard, {
      score: 72,
      basis: "This score is SeSha's own weighting of the issues found in this crawl.",
      counts: { critical: 1, high: 0, medium: 2, low: 0, info: 0 },
      title: 'Technical SEO',
    }),
  );
  assert.ok(out.includes('72'));
  assert.match(out, /own weighting/i, 'the score appeared without its basis');
});

check('the not-checked list states that absence is not a pass', () => {
  const out = html(
    React.createElement(NotCheckedList, {
      items: [
        {
          area: 'Core Web Vitals',
          reason: 'Measured in a real browser on real visits.',
          whatWouldHelp: 'PageSpeed Insights.',
        },
      ],
    }),
  );
  assert.match(out, /does not mean they are fine/i);
  assert.ok(out.includes('Core Web Vitals'));
});

check('a suppressed finding is reported as a SeSha bug, not a site problem', () => {
  const out = html(React.createElement(SuppressedNotice, { ids: ['seo-bad-1'] }));
  assert.ok(out.includes('role="alert"'));
  assert.match(out, /bug in SeSha, not a problem with your site/i);
});

check('no suppressed findings renders nothing', () => {
  assert.equal(html(React.createElement(SuppressedNotice, { ids: [] })), '');
});

/* ------------------------- Phase 4: no invented volume -------------------- */

const sampleKeyword = {
  id: 'k1',
  query: 'How do we roast our coffee?',
  kinds: ['primary', 'question'],
  intent: 'informational',
  relevanceScore: 80,
  relevanceBasis: 'Measured against the crawled text.',
  coveringUrls: ['https://example.com/roasting'],
  volume: { kind: 'unavailable', label: 'Data unavailable' },
  competition: { kind: 'unavailable', label: 'Data unavailable' },
  priority: 'medium',
  contentFormat: 'faq-entry',
  entities: ['Acme Coffee'],
  source: 'page_heading',
};

check('the keyword table prints "Data unavailable", never a volume number', () => {
  const out = html(
    React.createElement(KeywordTable, {
      keywords: [sampleKeyword],
      dataNote: 'Search volume and competition show "Data unavailable".',
      priorityBasis: 'Priority does not include search volume.',
    }),
  );
  assert.ok(out.includes('Data unavailable'), 'the unavailable label is missing');
  // No "N searches" or "N / month" anywhere in the rendered output.
  assert.ok(
    !/\d[\d,.]*\s*(?:searches|\/\s*month)/i.test(out),
    'a search volume figure was rendered',
  );
});

check('the keyword table states the absence ABOVE the table, not as a footnote', () => {
  const out = html(
    React.createElement(KeywordTable, {
      keywords: [sampleKeyword],
      dataNote: 'UNIQUE-NOTE-MARKER',
      priorityBasis: 'Priority does not include search volume.',
    }),
  );
  const notePosition = out.indexOf('UNIQUE-NOTE-MARKER');
  const tablePosition = out.indexOf('<table');
  assert.ok(notePosition > -1 && tablePosition > -1);
  assert.ok(notePosition < tablePosition, 'the data note appears after the table');
});

check('an empty keyword list explains why rather than showing an empty table', () => {
  const out = html(
    React.createElement(KeywordTable, { keywords: [], dataNote: 'x', priorityBasis: 'y' }),
  );
  assert.ok(!out.includes('<table'));
  assert.match(out, /does not generate a speculative list/i);
});

/* ------------------------- Phase 4: the policy is published ---------------- */

check('the crawler policy is exposed for the interface to publish', () => {
  // The website-audit page renders these, so the values have to be real.
  assert.ok(blockedRangeLabels().length >= 10);
  assert.equal(isAllowedAddress('169.254.169.254'), false);
  assert.equal(checkUrl('file:///etc/passwd').ok, false);
});

/* ======================= Phase 7: plans, usage, admin ===================== */

const { UsageMeter, UsageDashboardView } = await import(
  '../src/components/app/usage-dashboard.tsx'
);
const { BillingPanel } = await import('../src/components/app/billing-panel.tsx');
const { HealthChecks } = await import('../src/components/admin/health-checks.tsx');
const { AdminTable, NotMeasured, Stat } = await import(
  '../src/components/admin/admin-primitives.tsx'
);
const { AdminShell } = await import('../src/components/admin/admin-shell.tsx');
const { FlagRuleEditor } = await import('../src/components/admin/flag-controls.tsx');
const { SettingEditor } = await import('../src/components/admin/setting-controls.tsx');
const { GrantStaffForm } = await import('../src/components/admin/staff-controls.tsx');
const { PLANS_BY_RANK: p7Plans } = await import('../src/content/plans.ts');
const { permissionsFor: p7PermissionsFor } = await import('../src/lib/admin/auth.ts');

/** A LimitStatus, built by hand so the three zero-like states can be forced. */
function limitOf(id, label, value, used, extra = {}) {
  const limit = {
    id,
    label,
    kind: extra.kind ?? 'per_period',
    unit: extra.unit ?? null,
    value,
    source: extra.source ?? 'plan',
    ...(extra.override ? { override: extra.override } : {}),
  };
  if (value === null) {
    return { limit, used, remaining: null, percentUsed: null, exhausted: false, nearLimit: false };
  }
  if (value === 0) {
    return { limit, used, remaining: 0, percentUsed: 100, exhausted: true, nearLimit: true };
  }
  const percent = Math.min(100, Math.round((used / value) * 100));
  return {
    limit,
    used,
    remaining: Math.max(0, value - used),
    percentUsed: percent,
    exhausted: used >= value,
    nearLimit: percent >= 80,
  };
}

check('an UNLIMITED limit draws no bar and says so', () => {
  const out = html(
    React.createElement(UsageMeter, {
      status: limitOf('projects', 'Projects', null, 12, { kind: 'absolute' }),
    }),
  );
  assert.ok(out.includes('Unlimited'), 'the word "Unlimited" is missing');
  assert.ok(!out.includes('role="progressbar"'), 'an unlimited limit drew a progress bar');
  // The usage figure must not be presented as "12 of null" or "12 of 0".
  assert.ok(!/12\s*of/.test(out), 'a denominator was rendered for an unlimited limit');
});

check('a limit of ZERO says "Not on this plan", never "0 of 0 used"', () => {
  const out = html(
    React.createElement(UsageMeter, {
      status: limitOf('automations', 'Automations', 0, 0),
    }),
  );
  assert.ok(out.includes('Not on this plan'), 'the not-included wording is missing');
  assert.ok(!/0\s*of\s*0/.test(out), '"0 of 0" was rendered, which reads as a bug');
});

check('an unused limit still renders a real denominator', () => {
  const out = html(
    React.createElement(UsageMeter, {
      status: limitOf('ai_requests', 'AI requests', 500, 0),
    }),
  );
  assert.match(out, /0\s*of\s*500/, 'the denominator is missing for an unused limit');
  assert.ok(out.includes('role="progressbar"'));
});

check('an OVERRIDDEN limit shows the reason the customer was given it', () => {
  const out = html(
    React.createElement(UsageMeter, {
      status: limitOf('seo_audits', 'SEO audits', 400, 10, {
        source: 'override',
        override: { reason: 'Agreed during migration from their old tool.', setAt: 'x' },
      }),
    }),
  );
  assert.ok(
    out.includes('Agreed during migration from their old tool.'),
    'the override reason is not rendered',
  );
});

check('the usage dashboard says "New this month" rather than an infinite percentage', () => {
  const out = html(
    React.createElement(UsageDashboardView, {
      planName: 'Pro',
      writable: true,
      blockedReason: undefined,
      data: {
        plan: 'pro',
        periodStart: '2026-09-01',
        resetsAt: '2026-10-01T00:00:00.000Z',
        limits: [limitOf('ai_requests', 'AI requests', 500, 40)],
        pressure: [],
        tracked: [
          { metric: 'ai_generation', label: 'AI requests', total: 40, previousTotal: 0, limitId: 'ai_requests' },
          { metric: 'ai_tokens', label: 'Tokens', total: 10, previousTotal: 10, limitId: 'tokens' },
        ],
        recentRefusals: [],
      },
    }),
  );
  assert.ok(out.includes('New this month'), 'a rise from zero was not labelled');
  assert.ok(out.includes('No change'), 'an unchanged figure was not labelled');
  assert.ok(!out.includes('Infinity'), 'an infinite percentage was rendered');
});

check('a read-only account is told so, with the reason, on its usage screen', () => {
  const out = html(
    React.createElement(UsageDashboardView, {
      planName: 'Pro',
      writable: false,
      blockedReason: 'A payment did not go through, so new work is paused.',
      data: {
        plan: 'pro',
        periodStart: '2026-09-01',
        resetsAt: '2026-10-01T00:00:00.000Z',
        limits: [],
        pressure: [],
        tracked: [],
        recentRefusals: [],
      },
    }),
  );
  assert.ok(out.includes('Read-only'));
  assert.ok(out.includes('A payment did not go through'), 'the reason was not shown');
});

check('the billing screen renders NO field that could accept a card', () => {
  const out = html(
    React.createElement(BillingPanel, {
      currentPlan: 'free',
      plans: p7Plans,
      providerConfigured: false,
      providerMessage: 'No payment provider is connected yet.',
      cancelAtPeriodEnd: false,
      canManage: true,
    }),
  );
  // NO DATA-ENTRY CONTROL AT ALL on this screen, which is the strongest form
  // the claim can take: there is nothing here that could receive a card number
  // even by accident.
  assert.ok(!/<(input|textarea|select)\b/i.test(out), 'the billing screen rendered a control');
  // The word "card" DOES appear — "Free, with no card and no expiry" — and that
  // is the point. What must not appear is a prompt to enter one. Asserting on
  // the word alone would forbid the reassurance along with the field.
  assert.ok(
    !/\b(cvv|cvc|cardholder|card number|enter your card)\b/i.test(out),
    'the billing screen asks for card details',
  );
  assert.ok(out.includes('no card and no expiry'), 'the free plan no longer says no card is needed');
});

check('a paid plan cannot be bought while no provider is connected, and says why', () => {
  const out = html(
    React.createElement(BillingPanel, {
      currentPlan: 'free',
      plans: p7Plans,
      providerConfigured: false,
      providerMessage: 'x',
      cancelAtPeriodEnd: false,
      canManage: true,
    }),
  );
  assert.ok(
    out.includes('no payment provider is connected'),
    'the unavailability of checkout is not explained',
  );
  assert.ok(!/Move to Pro/.test(out), 'an unbuyable plan offered a buy button');
});

check('a member who cannot manage billing is told, not shown a button that fails', () => {
  const out = html(
    React.createElement(BillingPanel, {
      currentPlan: 'free',
      plans: p7Plans,
      providerConfigured: true,
      providerMessage: 'x',
      cancelAtPeriodEnd: false,
      canManage: false,
    }),
  );
  assert.ok(out.includes('Only an owner or admin can change the plan.'));
  assert.ok(!/Cancel at period end/.test(out), 'a non-manager was offered cancellation');
});

check('an UNKNOWN health check is not rendered as a pass', () => {
  const out = html(
    React.createElement(HealthChecks, {
      checks: [
        { id: 'a', label: 'Thing A', state: 'ok', detail: 'Fine.' },
        { id: 'b', label: 'Thing B', state: 'unknown', detail: 'Not instrumented.' },
      ],
    }),
  );
  assert.ok(out.includes('Not known'), 'an unknown check was not labelled as unknown');
  // "OK" appears once, for Thing A only.
  assert.equal(out.match(/>OK</g)?.length ?? 0, 1, 'an unknown check was labelled OK');
});

check('the panel lists what it does NOT measure', () => {
  const out = html(
    React.createElement(NotMeasured, { items: ['Uptime — no availability history is recorded.'] }),
  );
  assert.ok(out.includes('Not measured'));
  assert.ok(out.includes('no availability history is recorded'));
});

check('an empty admin table explains itself instead of rendering an empty table', () => {
  const out = html(
    React.createElement(AdminTable, {
      caption: 'Jobs',
      head: ['Kind'],
      empty: 'No job matches that filter.',
      children: [],
    }),
  );
  assert.ok(!out.includes('<table'), 'an empty table was rendered');
  assert.ok(out.includes('No job matches that filter.'));
});

check('a stat renders its figure and any caveat', () => {
  const out = html(React.createElement(Stat, { label: 'AI requests', value: 1234, note: 'Last 30 days.' }));
  assert.ok(out.includes('1,234'), 'the figure is not grouped for readability');
  assert.ok(out.includes('Last 30 days.'), 'the window caveat is missing');
});

check('the admin shell warns, on every page, whose data is on screen', () => {
  const out = html(
    React.createElement(
      AdminShell,
      {
        role: 'support',
        roleLabel: 'Support',
        permissions: p7PermissionsFor('support'),
        sudo: false,
      },
      React.createElement('p', null, 'body'),
    ),
  );
  // The shell writes the apostrophe as &rsquo;, which renders as U+2019.
  assert.match(out, /other people\u2019s accounts/i, 'the cross-tenant warning is missing');
  assert.ok(out.includes('recorded against'), 'the audit warning is missing');
});

check('the admin shell hides screens the role cannot open', () => {
  const support = html(
    React.createElement(
      AdminShell,
      { role: 'support', roleLabel: 'Support', permissions: p7PermissionsFor('support'), sudo: true },
      React.createElement('p', null, 'body'),
    ),
  );
  const owner = html(
    React.createElement(
      AdminShell,
      {
        role: 'platform_owner',
        roleLabel: 'Platform owner',
        permissions: p7PermissionsFor('platform_owner'),
        sudo: true,
      },
      React.createElement('p', null, 'body'),
    ),
  );
  // Support holds no audit or staff permission, so neither link may appear.
  assert.ok(!support.includes('/admin/audit'), 'support was shown the audit trail');
  assert.ok(!support.includes('/admin/staff'), 'support was shown staff management');
  assert.ok(owner.includes('/admin/audit') && owner.includes('/admin/staff'));
});

check('staff without a recent sign-in are warned BEFORE they fill in a form', () => {
  const out = html(
    React.createElement(
      AdminShell,
      { role: 'engineer', roleLabel: 'Engineer', permissions: p7PermissionsFor('engineer'), sudo: false },
      React.createElement('p', null, 'body'),
    ),
  );
  assert.ok(out.includes('Sign-in confirmation needed'), 'the sudo state is not surfaced');
});

check('the flag editor prints the precedence it will actually use', () => {
  const out = html(
    React.createElement(FlagRuleEditor, { flagKey: 'ai.openai', label: 'OpenAI', rule: null }),
  );
  // Collapsed by default: the affordance is a button, not a form nobody asked for.
  assert.ok(out.includes('Add a rule'));
  assert.ok(!out.includes('Off for everyone'), 'the editor opened itself');
});

check('the setting editor picks its control from the declared shape, not the value', () => {
  const emptyList = html(
    React.createElement(SettingEditor, {
      settingKey: 'validator.suppressed_checks',
      label: 'Suppressed checks',
      shape: 'string_list',
      value: [],
      isDefault: true,
    }),
  );
  assert.ok(emptyList.includes('<textarea'), 'an empty list did not render a list control');
  assert.ok(emptyList.includes('One value per line.'));

  const falseBoolean = html(
    React.createElement(SettingEditor, {
      settingKey: 'system.allow_signups',
      label: 'Allow new sign-ups',
      shape: 'boolean',
      value: false,
      isDefault: false,
    }),
  );
  assert.match(falseBoolean, /type="checkbox"/, 'a false boolean did not render a checkbox');
});

check('an unchanged setting says it is the value declared in the code', () => {
  const out = html(
    React.createElement(SettingEditor, {
      settingKey: 'system.service_banner',
      label: 'Service banner',
      shape: 'string',
      value: '',
      isDefault: true,
    }),
  );
  assert.ok(out.includes('Never changed'), 'a default value is indistinguishable from a set one');
});

check('granting platform access demands a reason on the form itself', () => {
  const out = html(React.createElement(GrantStaffForm, {}));
  assert.ok(out.includes('An unexplained staff row'), 'the reason is not justified to the operator');
  // Three required fields, each marked with the attribute rather than an asterisk alone.
  assert.ok(out.includes('Grant access'));
  assert.ok(
    out.includes('separate from any organization role'),
    'the panel does not distinguish platform staff from an org owner',
  );
});

/* --------------------------------- Report --------------------------------- */

console.log('Server-render smoke check\n');
for (const line of results) console.log(line);
console.log('');
if (failures === 0) {
  console.log(`PASS — ${results.length} render assertions, 0 failures.`);
  process.exit(0);
}
console.log(`FAIL — ${failures} of ${results.length} render assertions failed.`);
process.exit(1);
