# SeSha AI Marketing — Phase 6 report

Analytics · Marketing Calendar · Automation · Reports · Export · Notifications
Built on the stable Phase 5 codebase. Authentication, onboarding, the dashboard,
the AI layer, the crawler, the validator and the marketing-operations surfaces are
unchanged and still pass their own suites.

Phase 6 is the phase where a marketing product normally starts lying, and that is
the honest way to describe what this one had to be built against. An analytics
screen is the most tempting place in the product to invent a number — nothing on
it is obviously wrong, a plausible traffic figure looks exactly like a real one,
and the user has no way to check. A report is worse: it is read away from the
screen that would have carried the caveat.

The brief is blunt about it — *"If no connected data exists: display 'No connected
data available.' Never fabricate analytics"* — and most of what follows is a
consequence of taking that literally rather than as a disclaimer at the bottom of a
dashboard.

---

## 1. The quality gate

Every line of the brief's eleven-item gate is an executable assertion in
`tests/phase6-gate.test.ts`, one `describe` block per item, so the gate fails
loudly if the behaviour regresses rather than being ticked by hand.

| # | Gate item | Status | Where it is proven |
|---|---|---|---|
| 1 | Analytics | **PASS** | `phase6-gate`, `analytics` · all nineteen metrics the brief names, produced for a real project; the eight SeSha genuinely has come back `calculated` |
| 2 | Data source labels | **PASS** | `phase6-gate`, `analytics` · the six labels the brief names are the discriminator of `MetricValue`; no variant carries a figure without provenance |
| 3 | Marketing calendar | **PASS** | `phase6-gate`, `calendar` · four views, ten activity kinds, Monday-first weeks; suggestions for empty dates, each carrying what it was based on |
| 4 | Automation engine | **PASS** | `phase6-gate`, `automation` · Trigger → Condition → Action; the brief's six examples offered as templates; a rule runs end to end and writes a task, not a message |
| 5 | Report generator | **PASS** | `phase6-gate`, `reports` · all nine kinds generate; every one answers the six questions or explains why a section is empty |
| 6 | Export | **PASS** | `phase6-gate`, `reports` · PDF, CSV, JSON and a revocable share link; the PDF verified against `qpdf`, `pdftotext` and `pypdf` |
| 7 | Notifications | **PASS** | `phase6-gate`, `notifications` · the eight kinds; switching one off genuinely stops it; security and billing cannot be silenced and say why |
| 8 | Background jobs | **PASS** | `phase6-gate` · `report_generation` and `automation_sweep` added to the job kinds; routes reach the service layer, never the database |
| 9 | No fake metrics | **PASS** | `phase6-gate` · see §4 — the type, the schema scan, the estimator scan and the `?? 0` scan |
| 10 | Tests | **PASS** | 1627 passing, 0 failing, 312 suites; every Phase 6 module has a test importing it and every route exists |
| 11 | Production build | **PASS (with a stated limit)** | no new dependency; 63 route handlers; `db/schema.sql` matches the migrations; every new table is RLS-isolated. The build itself still cannot run here — see §7 |

The "no delivered phase is still advertised as upcoming" block was carried forward
with `DELIVERED` bumped to 6, and it immediately caught nine stale promises. See §6.

---

## 2. What was built

**Analytics** (`lib/analytics`, 4 modules) — `metrics` (the vocabulary and the
`MetricValue` union), `connections` (what is and is not connected),
`compute` (the metrics SeSha genuinely has), `service` (assembly, per project,
with the comparison period).

**Calendar** (`lib/calendar`, 2 modules) — `types` (ten kinds, four views,
date arithmetic, the suggestion generator), `service` (views, CRUD, derived
entries, suggestions from real data).

**Automation** (`lib/automation`, 3 modules) — `types` (the vocabulary,
validation, evaluation), `engine` (turning a match into work for a person),
`service` (create, validate, run, preview).

**Reports** (`lib/reports`, 6 modules) — `types` (nine kinds, six sections),
`generate` (the pure fact-bundle-to-report function), `export` (CSV and JSON),
`pdf` (a dependency-free PDF writer), `share` (tokens), `service`.

**Notifications** (`lib/notifications`, 2 modules) — `types` (eleven kinds,
channels, preferences, the one gate), `service` (the only door to a user).

**Storage** — migration `0006`: seven new tables, taking the schema to **47**.
Plus `rejected` on `ad_plans.review_state` with a required `review_note`, which
Phase 5 had no way to express (see §3).

**API** — 11 new route handlers, taking the total to **63**:
`/api/analytics`, `/api/calendar` (+`[id]`), `/api/automations` (+`[id]`),
`/api/reports` (+`[id]`, `[id]/export`), `/api/notifications`
(+`/preferences`), and `/api/share/[token]`.

**UI** — 6 new components and 6 pages: `/app/analytics`, `/app/reports`,
`/app/reports/[id]`, `/app/automations`, a rebuilt `/app/calendar`, the public
`/share/[token]`, and notification preferences in Settings. Four navigation
entries flipped from *planned* to *available*.

---

## 3. The decisions worth defending

### `MetricValue` makes the dishonest version unrepresentable

The same move as `SearchVolume` (Phase 4) and `BudgetRecommendation` (Phase 5).
`MetricValue` is a discriminated union with **no `{ value: number }` variant**.
Every variant carrying a figure also carries where it came from: the connected
account and when it was read, the person who typed it, the URL it was read from,
or the formula and inputs that produced it. `ai_estimate` carries a magnitude
band and never a precise figure. `unavailable` carries why, and what would make it
available.

Those are the brief's six source labels, and they are the *discriminator* rather
than a display string beside the number. `hasFigure()` is the only way to reach a
value, and `formatValue()` returns `null` for everything else — so a UI that
renders it blindly shows nothing rather than a zero.

### There is no metrics table, and that is deliberate

No column anywhere holds a traffic, impression, click, follower or spend figure. A
nullable `sessions integer` would be filled in within a month — by a seed script,
a demo fixture, or a well-meaning estimator — and from then on nobody could tell a
measured figure from an invented one. A gate test walks `db/schema.sql` and fails
on such a column.

`data_connections` records the absence instead. A provider with **no row** is not
connected; there is no `pending` state, because a screen would round it up to
"connected".

### Two metrics return unavailable rather than zero

Because a zero is a claim:

- **pipeline conversion**, when nothing has closed. "0%" says *you convert
  nobody*, which is a different and false statement from *nothing has closed yet*.
- **content coverage**, when no keywords are tracked. "0% coverage" says *your
  content covers nothing*, when the truth is *nothing has been measured*.

And one returns a figure with a warning attached. `content_performance` is the
middle case: SeSha knows how much content was created and nothing about how it
performed. Reporting the whole metric as unavailable hides real information;
calling the count "performance" is a category error. So the count is returned with
a formula stating, in capitals, that this is ACTIVITY and not performance.

### A suggestion is a different type from a calendar entry

`Suggestion` has no id and no status, and nothing writes one. That is not
fastidiousness: **a suggestion rendered as an entry becomes, within a week,
something the user believes they planned**, and the calendar stops being a record
of decisions. The UI puts them in their own panel, labelled, with the reason.
Accepting one is an explicit act and what it creates is marked
`accepted_suggestion` forever.

Two rules keep the generator honest. A suggestion must have a reason specific to
*this* customer — an open finding from their own audit, or a channel they named at
onboarding — because "post something on Tuesday" is filler and filler trains
people to ignore the calendar. And real work comes first: an open schema error is
a better use of a Tuesday than an invented blog post. A customer who listed no
channels and has no findings gets nothing at all, which is the honest outcome.

### The automation action list is the boundary

An automation engine in a marketing product is normally a machine for sending
things to people without a human in the loop. This one cannot be, and the reason
is not caution — **the capability genuinely does not exist**. So `ACTION_KINDS` is
closed at six and every one produces something a person then acts on.
`isOutboundAction()` is false for all of them, `checkRule()` errors if an action
would reach a third party, and migration 0006 enforces the same list in the
database through an `IMMUTABLE` function so an action cannot arrive via a fixture
or a direct `INSERT`.

*"Inactive customer → re-engagement"* is one of the brief's own examples, and the
obvious implementation sends an email. The honest implementation drafts one and
tells a person it is waiting — which is also the only version lawful under the
opt-in rules Phase 5 enforces.

### Phase 6 found a gap in Phase 5, and filled it rather than working around it

The brief asks for a "campaign decline" trigger. Phase 5 gave ad plans
`draft | in_review | approved` — **with no way to say no**. A plan could be
approved or left in review forever, which is how a decision quietly becomes a
backlog. That omission was invisible until something needed to fire on it.

Migration 0006 adds `rejected` with a **required** `review_note` (enforced by a
CHECK), because a rejection with no reason leaves the author guessing and leaves
the recommending automation with nothing to say. The alternative — inventing a
trigger that could never fire — would have put a promise on a settings screen.

### Every automation run is recorded, including the ones that did nothing

A rule that quietly stops matching is indistinguishable from a rule that never
runs. `automation_runs.matched` is `NOT NULL`, `skip_reason` carries which
condition failed in words, and a CHECK requires the reason whenever `matched` is
false. Hitting the daily ceiling is recorded the same way, so "it stopped because
of a limit" is distinguishable from "it is broken".

### The six report questions are fields on a type

A section with no points carries a **required** `emptyReason`. An empty section
with no explanation reads as "nothing to report", which is a claim, and usually the
wrong one.

The hard section is **"why?"**. Every analytics product writes "what happened" by
listing numbers; very few attempt "why", because the honest answer is usually *we
cannot tell you from here*. The generator either names a real cause found in the
customer's own records — a crawl that stopped early, a plan declined in review, a
page that lost its markup — or says so plainly and names what would make the cause
visible. The alternative, which is what a generated narrative usually does, is to
restate the numbers in sentence form and call it analysis. That reads like insight
and contains none.

**"Where should budget be reviewed?"** refuses to answer. There is no spend data,
and a budget recommendation without it is a guess wearing a suit. It points at
where a decision is actually waiting instead — a declined plan, a stalled
campaign, a calendar being skipped more often than completed.

`generateReport()` is pure: no database, no clock, no randomness. A test asserts
the same facts produce a byte-identical report.

### A report is a snapshot, stored whole

`reports.document` holds the rendered report including every `MetricValue`.
Export and share read that row; they do not re-run the generator. A link sent to a
client in March must show what it showed in March, and a PDF downloaded twice must
be the same PDF. Regenerating on read would silently rewrite history.

### The PDF is written by hand, and that was the right call

A PDF library is typically 2–15 MB, pulls a font stack and a canvas shim, and runs
layout code over user-controlled strings. What this product needs is black text on
white paper in one font family, and the PDF format supports exactly that in about
three hundred lines. `lib/reports/pdf.ts` writes `%PDF-1.7`, a catalogue, a page
tree, uncompressed content streams in the standard Helvetica faces (built into
every reader, so nothing is embedded), and a cross-reference table. Real Adobe AFM
advance widths are embedded for text wrapping, and a word too long for the line —
a page URL, usually — is broken rather than allowed to overflow, because the person
who has to go and fix that page needs the whole URL.

Two things about it are worth stating plainly, because both were found rather than
foreseen:

- **The cross-reference table stores byte offsets**, which are computed as string
  lengths. That is only correct while every character fits in one byte, so
  `encodeWinAnsi` is load-bearing rather than a text tidy-up. A test asserts the
  property directly over the whole document, and a mutation that removed the clamp
  was caught.
- **The Info dictionary uses a different encoding from the page content.** Page
  text is decoded with the font's encoding (WinAnsi, as declared); an Info string
  is decoded as PDFDocEncoding, where the WinAnsi byte for an em dash means
  something else. The report title came out of a real reader as
  "SEO report S Acme Ltd". Caught by extracting the metadata with `pypdf` rather
  than by reading the bytes back with our own code, which would have agreed with
  itself. `pdfTextString()` now writes non-ASCII as UTF-16BE with a BOM.

### Share links: four refusals of the convenient version

1. **Random, not derived.** A token built from the report id — even hashed — is
   enumerable the moment someone learns the scheme.
2. **Only the hash is stored.** If the table leaks, what leaks is not a set of
   working links.
3. **It expires.** Thirty days by default, ninety maximum, `expires_at NOT NULL`.
   A link with no end outlives the employee who made it.
4. **Revocation is immediate**, checked on every view.

Every failure returns the **same sentence**. "This link has expired" tells a
stranger the link was once real; the reason goes to the audit log instead. The
shape guard runs before any lookup, and a test asserts the repository is not
called — so timing cannot distinguish malformed from missing.

`/api/share/[token]` is the only unauthenticated endpoint returning tenant data.
It sets `no-store` and `noindex, nofollow`: a link pasted into an email a crawler
follows would otherwise put a customer's report into a search index.

### "Users must control notification preferences" is a rule about where the decision lives

`shouldNotify()` is the only route from an event to a user, it takes the preference
as an argument, and there is no bypass — including for automations. Asking for a
rule and asking to be told every time it runs are two different decisions, and a
test asserts a rule whose notification the user switched off writes nothing.

Two kinds cannot be switched off, and the interface **shows the reason** rather
than greying a toggle out. A product that lets someone mute "your password was
changed" helps an attacker stay hidden. A database CHECK enforces it too, so a
direct `UPDATE` cannot mute a security alert. None of the brief's eight marketing
kinds is forced on.

A kind with no stored row takes the application default rather than being treated
as off — otherwise a new notification kind arrives silently switched off for every
existing user and nobody discovers the feature.

Email is **listed and marked unavailable, with the reason**, rather than hidden.
SeSha cannot send email, so the toggle would be wired to nothing; but a customer
deciding whether to buy should be able to see what is not built yet.

---

## 4. "Never fabricate analytics", as four executable checks

1. **The type.** No `MetricValue` variant carries a bare number. With nothing
   connected, every metric requiring a connection comes back `unavailable`,
   `hasFigure()` is false and `formatValue()` is `null`. Asserted over all
   nineteen.
2. **The schema.** A gate test reads `db/schema.sql`, collects every numeric
   column definition, and fails on any named `sessions`, `impressions`, `clicks`,
   `followers`, `spend`, `roas` and the rest.
3. **The exports.** No function exported from `analytics`, `reports`, `calendar` or
   `automation` may be named like an estimator (`estimate`, `predict`, `simulate`,
   `fake`, `mock`, `placeholder`). The absence of `estimateTraffic` is the feature;
   a helper with that name would be used within a week.
4. **The generator.** `reports/generate.ts` may contain no `?? 0`. A default of
   zero is exactly how a fabricated figure appears in a narrative.

And in the rendered output: the page audit renders every Phase 6 screen **with
nothing connected** — the state a real customer sees on day one — and asserts the
required sentence is present, that unavailable is distinguished from zero, and that
no figure is drawn for traffic, impressions, ROAS or followers.

---

## 5. Security

| Concern | Handling |
|---|---|
| The one unauthenticated endpoint returning tenant data | random 32-byte token, only its sha256 stored, expiring, revocable, constant-time hash comparison, shape-guarded before any lookup, one message for every failure, `no-store` + `noindex` |
| Tenant isolation | all seven new tables carry `organization_id` with row-level security; every repository method is tenant-scoped; cross-tenant access returns 404, not 403 |
| Notification settings | personal, not organizational — even an owner cannot read another user's; destroyed with the user by `anonymize_deleted_user()` |
| CSV export opened in Excel | a leading `=`, `+`, `-` or `@` is prefixed with an apostrophe. A lead's name is user-controlled, and this is an export of user data |
| Content-Disposition | the filename is a slug of letters, digits and hyphens only, so a title containing a quote or newline cannot break out of the header |
| Report downloads | `private, no-store` and `nosniff` |
| Automation blast radius | 200 runs per organization per day, counting non-matches (they cost work too); no action can reach a third party, enforced in the type system, the validator and the database |
| Template rendering | one pass only, so a payload value containing `{{token}}` cannot inject a second substitution |

---

## 6. What the phase-promise guard caught

Bumping `DELIVERED` to 6 immediately failed on nine surfaces still pointing at
Phase 6: eight AI agents declared as arriving then, and the Templates
coming-soon screen.

The honest resolution was not to relabel them. Phase 6 deliberately built
**rule-based** analytics and reporting — the whole point is that a figure carries
its formula and a report can say "we cannot tell you why". The eight agents are
prose-generation over that structure, which is genuinely later work. They moved to
Phase 7, and three of their instruction strings were rewritten to say what now
exists: the `analytics` agent would write prose over figures it still cannot
measure, the `report` agent would write commentary over the six sections and never
replace them, and the `schema` agent would draft descriptive fields and never
factual ones.

---

## 7. Verification, and its limits

### What was verified

| Check | Result |
|---|---|
| Unit tests | **1627 passing, 0 failing** (312 suites) |
| Type checking — real `tsc`, strict + `noUncheckedIndexedAccess` | **203 `.ts` files, PASS** |
| Static verification | **296 source files, PASS** |
| Component render assertions | **49 passing** |
| Whole-page render audit | **56 surfaces, 0 problems** |
| Generated PDF | **`qpdf --check` clean; `pdftotext` and `pypdf` both read it correctly; 4 pages; typography and metadata intact** |
| `db/schema.sql` regenerated and consistent with the row types | **47 tables, PASS** |
| Production dependencies | **unchanged at four** |
| Mutation testing | **24 mutations, all now caught** (three survived the first pass — see below) |

### What could not be verified

Unchanged from every previous phase, and worth restating rather than burying:

- **The npm registry is unreachable (403).** `npm install`, `next build`,
  `next lint` and Playwright have never run in this project.
- **`.tsx` files are not type-checked**, because that needs `@types/react`. Real
  `tsc` runs over every `.ts` file via a linked `@types/node` and narrow `next/*`
  shims. **A `.tsx` type error remains the most likely first-build failure.**
- **PostgreSQL is unreachable**, and installing it is blocked by the same proxy.
  **No migration in this project has ever been executed.** The SQL is reviewed and
  `db/schema.sql` is generated from it and checked against the row types in code,
  but it has not been run. One Phase 6 construct was corrected on review for
  exactly this reason: a CHECK constraint containing a subquery, which PostgreSQL
  does not permit — it is now an `IMMUTABLE` function.

### The gap that closed in this phase

`Field` takes a **render prop**: it calls `children({ id, describedBy, invalid })`
so the label and the control are genuinely bound. Passing child elements instead
type-checks under this offline harness — `.tsx` is not covered by `tsc` here — and
then throws `children is not a function` the first time the screen renders.

Eighteen such usages were found at once, **thirteen of them shipped in earlier
phases**, on screens the render audit did not reach: the schema validator
workspace, the social manager, the competitor panel and the lead board. All
eighteen are fixed, all now bind their control to a real label, and
`verify-static` gained a check so it cannot recur. (The first version of that check
reported a correct usage as broken, because an attribute like
`hint={list.find((f) => f.id === x)?.note}` contains a `>` inside a JSX
expression; a check that cries wolf gets deleted, so it now scans properly.)

This is the clearest evidence so far of the specific cost of building without
`next build`, and of why the substitute harness has to keep growing rather than
being treated as equivalent.

### Mutation testing

24 mutations, each a plausible regression: removing the
conversion-is-unavailable branch, returning 0% coverage with nothing tracked,
treating a broken connection as usable, comparing across two source kinds, marking
an action outbound, accepting a condition on a non-existent field, removing the CSV
injection guard, removing the share-link maximum, ignoring revocation, ignoring
expiry, silencing a security notification, using email as a channel, dropping the
"could not be measured" note, letting the PDF emit characters above 0xFF, and
reverting the PDF title to WinAnsi.

Three survived the first pass, and each exposed a real gap:

- **An empty string coercing to zero.** `Number('')` is 0, so "days since activity
  is less than 5" was true for a lead whose field arrived blank — a re-engagement
  task for every lead with no data. The bug was real; the test now covers `''`,
  whitespace and booleans.
- **A security notification silenced when `shouldNotify` is called directly.** Two
  layers guard it, and the test went through the outer one, so removing the inner
  short-circuit changed nothing. The test now hands `shouldNotify` a raw hostile
  preference list — the shape a future caller who skips `resolvePreferences` would
  produce.
- **A malformed share token reaching the database.** Asserting only the rejection
  did not test the claim, because a lookup that finds nothing rejects identically.
  The test now observes the repository and asserts it is never called.

All 24 are caught.

---

## 8. Honest notes

- **`.tsx` remains unverified by the compiler.** Eighteen render-breaking usages
  were found in this phase by a harness that only reaches some screens. Others may
  exist on the screens it still does not reach.
- **No migration has ever been run.** 47 tables of reviewed SQL, and the first
  `psql -f` is still ahead.
- **Nothing is connected, so eleven of nineteen metrics are unavailable.** That is
  the correct behaviour and it is also, unavoidably, a thin analytics screen. The
  work to change that is an OAuth flow per provider; the seam is
  `data_connections`, `availableSources()` and `whyUnavailable()`, and nothing else
  moves.
- **The automation engine cannot send anything.** Users will ask for that. The two
  places that would have to change are `isOutboundAction()` and the database's
  `automation_actions_permitted()` — deliberately, and visibly.
- **The PDF is plain.** No charts, no images, no tables. A report that needs a
  chart needs a connected data source first, and it does not have one.

---

## 9. Stopping here

Phase 6 is complete against all eleven gate items. **Phase 7 has not been
started**, per the standing instruction.

`tests/phase6-gate.test.ts` also asserts that: nothing in `src` is described as
arriving in a phase that has already shipped, and no file carries a Phase 7
implementation marker.
