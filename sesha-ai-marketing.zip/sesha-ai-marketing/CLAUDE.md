# SeSha AI Marketing — instructions for Claude Code

Owner: SeSha AI Marketing. This file is read automatically at the start of every Claude Code session in this repository. Keep it accurate; it is the contract for how this codebase is changed.

## What this is

A multi-tenant AI marketing SaaS. Next.js 15 (App Router), React 19, TypeScript strict with `noUncheckedIndexedAccess`, Tailwind v4. Phases 1–9 are complete. The design record is `ARCHITECTURE.md` (Parts I–IX); the current state and blockers are in `PRODUCTION-READINESS-REPORT.md`; every other document is indexed in `docs/README.md`.

**Read before working:** `PRODUCTION-READINESS-REPORT.md` (blockers B1–B5) and the relevant ARCHITECTURE section.

## Environment note (important)

Phases 1–9 were written with **no npm registry access**, so `npm install`, `next build`, `next lint` and Playwright have **never run**. The repository ships an offline harness that writes stand-in modules into `node_modules`. On a machine with internet, the first thing to do is:

```bash
rm -rf node_modules && npm install     # the stand-ins must be replaced
npm run verify                         # typecheck + lint + tests + production build
```

Expect first-build errors, mostly in `.tsx` (the offline type check could not see real `@types/react`). Fix them without changing behaviour.

## Commands

| Command | Purpose |
|---|---|
| `npm run dev` / `npm run build` / `npm run start` | Next.js |
| `npm test` | 2,121 unit, service and gate tests (`node:test`, no browser) |
| `npm run verify` | typecheck → lint → tests → build (the real gate) |
| `npm run test:e2e` | Playwright: 5 breakpoints + Firefox, WebKit, Edge, Android, iOS |
| `npm run sandbox:all` | The offline harness (only when npm is unavailable) |
| `npm run verify:mutation` | 21 deliberate breakages, each with the test that must catch it |
| `node scripts/build-schema.mjs` | Regenerate `db/schema.sql` from the migrations |
| `node scripts/build-docs.mjs` | Regenerate `docs/API.md`, `docs/DATABASE.md`, `docs/ENVIRONMENT.md` |

Run a single test file with `npx tsx --test tests/<name>.test.ts`.

## Rules for changing this codebase

1. **Four production dependencies only** (`next`, `react`, `react-dom`, `clsx`, `tailwind-merge`). Adding one is a decision to raise with the owner first, with a reason. No ORM, no chart library, no PDF library, no payment SDK.
2. **Layering.** Route handlers in `src/app/api/**/route.ts` do HTTP only: guard → rate limit → parse → call a service → respond. Services in `src/lib/*/service.ts` are framework-free, take `{ db, now }` plus a `TenantContext`, and are unit-tested. Repositories take `organizationId` as their first argument.
3. **Copy and configuration are typed data** in `src/content/`, never inline strings in components.
4. **Tenant isolation.** Every query is scoped by `organizationId`, and a cross-tenant id returns **404, not 403**. Organization admin is not platform staff.
5. **Never invent a number.** No fabricated analytics, search volume, ratings, reviews, prices or business facts. Where a figure cannot be measured, the type system makes the dishonest version unrepresentable (`MetricValue`, `SearchVolume`, `BudgetRecommendation`, `PaymentMethodSummary`) — keep it that way. Demo content must be visibly labelled `SAMPLE DATA`.
6. **Secrets** are read only in `src/lib/auth`, `src/lib/ai/provider`, `src/lib/config` and `src/lib/env`, and only through helpers that return a boolean or the value to that module. A test enforces this. Never log a secret, a token or user content.
7. **Migrations are forward-only.** Add `db/migrations/00NN_*.sql`, one `BEGIN;`/`COMMIT;` per file, no `DROP TABLE` or `DROP COLUMN`, then run `node scripts/build-schema.mjs`. Every foreign key needs an index (`tests/database-audit.test.ts` fails otherwise).
8. **Tests are the guarantee.** Any bug fix gets a test that fails before it. For a security or correctness control, add a mutation to `scripts/mutation-check.mjs`. If a mutation survives, move the logic somewhere a test can reach it rather than deleting the mutation.
9. **Source scans run on comment-stripped code**, so a comment cannot satisfy a gate — but the explanatory comments are part of the guarantee. Do not delete them.
10. **Honesty over polish.** Do not claim something is verified when it has not run. Do not mark the product production ready while the blockers stand; `tests/phase9-gate.test.ts` checks that the report still matches the code.

## Where things are

```
src/app/(marketing)  public website          src/lib/auth       sessions, RBAC, CSRF, lockout
src/app/(auth)       sign-in, sign-up        src/lib/ai         provider, orchestrator, agents, provenance
src/app/(app)        the workspace           src/lib/crawler    SSRF policy, fetcher, robots, parse
src/app/(admin)      platform admin          src/lib/crawl      crawl/audit job services
src/app/api          84 route handlers       src/lib/db         repositories (interface) + memory-store
src/content          typed copy and config   src/lib/reliability timeout, retry, circuit breaker
src/components       UI and feature views    src/lib/observability logger (redacting), metrics
db/migrations        0001–0009               tests              2,121 tests incl. phase gates
scripts              offline harness, generators
```

## Current blockers (do not paper over these)

- **B1 Critical — no PostgreSQL adapter.** Only `MemoryDatabase` implements `Database` (`src/lib/db/repositories.ts`). With `DATABASE_URL` set the app refuses to start, deliberately. Implementing it means parameterised `pg` queries and `SET LOCAL app.current_organization` per request transaction so RLS applies.
- **B2 Critical — the real build has never run.** See the environment note.
- **B3 High — rate limiter, lockout and idempotency are per-process.** Run one instance until they move to Redis or Postgres.
- **B4 High — no email provider.** `deliver()` in `src/lib/email.ts` throws when `SMTP_URL` is set.
- **B5 High — legal copy pending review** (`src/content/legal.ts`).

When B1 or B4 is fixed, `tests/phase9-gate.test.ts` will fail on purpose: update `PRODUCTION-READINESS-REPORT.md` in the same change.

## Definition of done for any change

`npm run verify` passes, `npm run verify:mutation` passes, `node scripts/build-schema.mjs --check` and `node scripts/build-docs.mjs --check` are clean, and the docs that mention the changed behaviour are updated in the same commit.
