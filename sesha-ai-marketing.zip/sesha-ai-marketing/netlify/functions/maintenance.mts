import type { Config } from '@netlify/functions';

/**
 * Scheduled maintenance (Netlify Scheduled Function).
 *
 * Calls the app's own maintenance endpoint, which recovers jobs whose worker
 * died and deletes crawled pages whose retention period has passed. The
 * endpoint answers 404 to anything without the bearer secret, so CRON_SECRET
 * must be set in the Netlify environment (Site configuration → Environment
 * variables) — the same value the app itself has.
 *
 * Until the PostgreSQL adapter exists (blocker B1) this does nothing useful on
 * Netlify, because each function instance has its own in-memory database.
 * It is wired now so that it simply starts working when B1 lands.
 *
 * The schedule lives in netlify.toml, next to the rest of the deploy config.
 */
export default async (): Promise<Response> => {
  const secret = process.env.CRON_SECRET;
  const base = process.env.URL ?? process.env.NEXT_PUBLIC_SITE_URL;

  if (!secret || secret.length < 32) {
    console.warn(JSON.stringify({ event: 'maintenance.skipped', reason: 'CRON_SECRET missing or too short' }));
    return new Response('missing secret', { status: 200 });
  }
  if (!base) {
    console.warn(JSON.stringify({ event: 'maintenance.skipped', reason: 'no site URL' }));
    return new Response('no site url', { status: 200 });
  }

  const response = await fetch(new URL('/api/internal/maintenance', base), {
    method: 'POST',
    headers: { authorization: `Bearer ${secret}` },
  });

  // Status and counts only. Never log the secret or any customer content.
  console.log(JSON.stringify({
    event: 'maintenance.ran',
    status: response.status,
    body: response.ok ? await response.json().catch(() => null) : null,
  }));

  return new Response('ok', { status: 200 });
};

export const config: Config = { schedule: '*/15 * * * *' };
