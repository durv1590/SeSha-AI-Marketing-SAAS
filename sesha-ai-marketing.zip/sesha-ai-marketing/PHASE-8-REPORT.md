# Phase 8 Report: Production Security, Performance, Reliability and Accessibility

**Status: complete.** This phase added no product features. The only new user-facing pieces are a "Download your data" card and a crawl-history deletion endpoint, and both close gaps that the brief itself names (§3).

**The production build has not been run.** The npm registry returns 403 in this environment, so `next build`, ESLint and Playwright have never executed. The results below come from the offline harness.

## Results

| Check | Result |
|---|---|
| Unit tests | **2,045 / 2,045 pass** (1,900 at the end of Phase 7) |
| Phase 8 quality gate (`tests/phase8-gate.test.ts`, 16 items) | 40 / 40 |
| `verify:types`: real `tsc`, strict, over every `.ts` file | PASS |
| `verify:tsx`: `.tsx` files checked against React shims | PASS |
| `verify:static` (365 files) | PASS |
| `verify:contrast`: 27 pairs × 2 themes, WCAG AA | PASS |
| `sandbox:render` | 69 assertions, 0 failures |
| `sandbox:audit` | 59 pages, 0 problems |
| `verify:mutation` | 20 / 20 mutations caught |
| `build-schema --check` | schema up to date (57 tables) |

## Findings fixed

| Severity | Finding |
|---|---|
| Critical | The crawler had no wall-clock timeout, so a slowloris-style server could hold a worker open forever. |
| Critical | The DNS pin had never run: the `lookup` hook used the wrong callback shape, so every real-hostname crawl would have failed. |
| High | The rate-limit identity could be spoofed through `X-Forwarded-For`. |
| High | A password change left the acting (possibly stolen) session alive. |
| High | Revoking consent recorded a deletion but did not delete the crawled pages. |
| High | Retention deletion and stale-job recovery were never scheduled. |
| High | The log redactor removed only the first secret on a line; the patterns lacked the global flag. |
| Medium | The reaper discarded retryable work. The admin audit list was unbounded. Six contrast failures. No data export. No AI or crawling disclosure in the privacy policy. |
| Low | The sign-out route had no rate limit. The `/fonts` cache rule was dead. Some comments pointed to test files that don't exist. |

## Added, by brief section

1. **Security:** `SECURITY-AUDIT.md` maps every §1–§3 item to its code and its test.
2. **Crawler:** transport tests run against a real local server.
3. **Privacy:**
   - `GET /api/account/export` plus a Settings card.
   - `DELETE /api/crawl?consentId=`.
   - Revocation now deletes the crawled pages.
   - New privacy-policy sections covering app data, crawling and AI processing.
4. **Performance:**
   - Cursor pagination.
   - Migration 0008: 17 foreign-key indexes, 5 query-shape indexes, 2 cursor indexes, and a `jobs` heartbeat column.
   - Corrected cache headers.
5. **Reliability:**
   - `lib/reliability`: timeout, retry (idempotent calls only), circuit breaker, idempotency store.
   - An `idempotency_keys` table.
   - Job requeue with backoff.
   - `POST /api/internal/maintenance`.
6. **Observability:**
   - A structured, redacting logger and a closed metrics registry.
   - Exports and maintenance runs are logged with counts only.
7. **Accessibility:** contrast checker and token fixes, table captions, `useId` dialog labels, a skip link in the auth shell, and `role="alert"` on live error messages.
8. **Browsers:** Playwright projects for Firefox, WebKit, Edge, Android and iOS, plus a spec file, `tests/e2e/production.spec.ts`. These are **written but not run**.
9. **SEO/AEO:** checked by the gate (metadata on every marketing page, robots, sitemap, FAQPage, Organization). No regressions.
10. **Quality gate:** 16 items, including a backup strategy (`docs/OPERATIONS.md`).

## New environment variables

- `CRON_SECRET`: at least 32 characters.
- `TRUSTED_PROXY_COUNT`: default 1.

## Residual risks (details in SECURITY-AUDIT.md)

- The rate limiter and lockout run in-process only.
- There is no Postgres adapter, so row-level security is inert.
- The CSP still allows `'unsafe-inline'`.
- Durable idempotency exists as a schema only.
- There is no real build and no real-browser run.

## Before deploying, run

```bash
rm -rf node_modules && npm install
npm run verify
npm run test:e2e
```

Then schedule the maintenance endpoint and the backups as described in `docs/OPERATIONS.md`.

**Work stops here, after Phase 8.** Phase 9 has not been started and has no brief.
