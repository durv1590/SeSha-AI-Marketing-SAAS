## What and why

<!-- One or two sentences. Link the blocker (B1–B5) or roadmap item if it has one. -->

## Checklist

- [ ] `npm run verify` passes locally
- [ ] `npm run verify:mutation` passes (new control → new mutation)
- [ ] `node scripts/build-schema.mjs --check` and `node scripts/build-docs.mjs --check` are clean
- [ ] A test fails without this change (for a bug fix)
- [ ] No new production dependency, or one agreed with the owner and explained here
- [ ] No secret, token or customer content added to a log line
- [ ] Docs updated in this same PR (`ARCHITECTURE.md`, `docs/`, `PRODUCTION-READINESS-REPORT.md` if a blocker moved)
