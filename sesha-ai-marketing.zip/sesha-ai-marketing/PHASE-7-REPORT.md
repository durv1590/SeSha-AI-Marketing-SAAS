# SeSha AI Marketing — Phase 7 report

SaaS Subscriptions · Plan Limits · Usage · Billing Abstraction · Admin Platform · Feature Flags
Built on the stable Phase 6 codebase. Authentication, onboarding, the dashboard,
the AI layer, the crawler, the validator, the marketing-operations surfaces and the
Phase 6 analytics, calendar, automation and reporting layers are unchanged and
still pass their own suites.

Phase 7 adds the two powers a SaaS product can most easily abuse: the power to
charge people, and the power to look at everyone's account.

**Neither is switched on.** No payment provider is connected, so nothing can be
charged — and that is a fact about configuration rather than a promise in a
comment. No staff row exists in any database, so the admin panel is unreachable —
and to anyone not in that table it returns 404 rather than 403, so it does not
exist rather than merely being locked.

The brief's two hard instructions shaped most of the design. *"Do not hard-code
pricing into business logic"* is enforced by a scan over the modules that decide
entitlements. *"Do not store sensitive payment data unless required and properly
handled"* is met by a stronger claim than the brief asks for: **there is no column
in fifty-six tables that could hold a card, and no function signature anywhere
that would accept one.**

---

## 1. The quality gate

Every line of the brief's twelve-item gate is an executable assertion in
`tests/phase7-gate.test.ts`, one `describe` block per item, so the gate fails
loudly if the behaviour regresses rather than being ticked by hand. 64 assertions,
all passing.

| # | Gate item | Status | Where it is proven |
|---|---|---|---|
| 1 | Plans | **PASS** | `phase7-gate`, `plans` · four plans, eleven limits each, every limit declared for every plan; no price in the registry or in any module that decides an entitlement; comparison by rank; the earlier plan names still resolve |
| 2 | Usage | **PASS** | `phase7-gate`, `phase7-services` · the brief's eight items mapped onto nine metrics (audit usage is SEO and AEO separately); the legacy metric is readable and unwritable; dashboards for the customer and for staff |
| 3 | Quotas | **PASS** | `phase7-gate`, `quota` · eleven limits, each with a measurement; unlimited, not-included and unused distinguishable everywhere; an absolute limit never promises a reset; an impossible request says so; a malformed override cannot widen an entitlement |
| 4 | Billing abstraction | **PASS** | `phase7-gate`, `billing` · `PaymentProvider` with one null implementation that refuses everything and verifies no signature; no provider method and no screen could accept a card |
| 5 | Subscription state | **PASS** | `phase7-gate`, `billing`, `phase7-services` · every status reachable, no transition leaves a non-status, out-of-order webhooks recorded and ignored, **read access never revoked**, a grace window that does not restart |
| 6 | Admin panel | **PASS** | `phase7-gate` · all thirteen dashboard surfaces and all seven controls, each with a permission, a page and an endpoint; the feedback surface has a submission path |
| 7 | Admin security | **PASS** | `phase7-gate`, `admin-security` · the brief's six measures, one test each; 404 for non-staff *and* for staff with the wrong role |
| 8 | Feature flags | **PASS** | `phase7-gate`, `flags` · five categories, fixed registry, documented precedence, stable rollout cohort |
| 9 | Audit logs | **PASS** | `phase7-gate`, `admin-security` · every admin action including every read; no cascade to organizations; reading the trail is itself recorded |
| 10 | Tests | **PASS** | **1900 passing, 0 failing** (367 suites); plus 69 render assertions, 59 audited pages and **14 mutations, all caught** |
| 11 | No payment secrets exposed | **PASS** | `phase7-gate` · exactly four `payment_*` columns; no chargeable field in any type; no secret read outside the module that owns it; no component reads a server variable |
| 12 | Production build | **PASS (with a stated limit)** | no new dependency; 82 route handlers; `db/schema.sql` matches the migrations at 56 tables; every new admin page is `force-dynamic` and `noindex`. The build itself still cannot run here — see §8 |

---

## 2. Plans are content, limits are code, prices are neither

`src/content/plans.ts` declares `free`, `pro`, `business` and `agency`, with
eleven limits each. It contains no price, no currency symbol and no amount field.

The separation is not tidiness. A limit is an engineering fact the system enforces
and the team can verify. A price is a commitment the business makes, with tax,
invoicing and contract consequences. Keeping them in one object means changing a
price is a code deploy, and means a bug in a pricing table can change what someone
is *allowed* to do. Prices stay in `content/pricing.ts` behind the `verified` guard
that has been there since Phase 1 — unverified tiers still render no figure at all.

`planChange(from, to)` compares an integer **rank**, never a price or a name.
Comparing prices would make a promotional discount read as a downgrade; comparing
names alphabetically would put `agency` below `free`.

### The rename cost three SQL statements, in one order

Phases 2–6 shipped `starter`, `growth`, `agency`. Live rows carry those values, and
a `CHECK` constraint will not let you update a row to a value it forbids. Migration
`0007`:

1. **widens** the constraint to permit both spellings;
2. **UPDATEs** the rows;
3. **narrows** the constraint to the new spelling alone.

Doing 3 before 2 fails on the existing data. The gate asserts the order, because it
looks like noise in a diff and takes a production database down.

`resolvePlanId()` accepts the old spellings permanently (`starter → pro`,
`growth → business`), so a row that somehow still carries one resolves rather than
silently dropping the account to free.

---

## 3. Eleven limits, and the three zero-like states

Per-period limits (AI requests, tokens, content generations, website crawls, SEO
audits, AEO audits, schema validations, reports) reset on the 1st, UTC. Absolute
limits (projects, team members, automations) are standing totals that never reset;
deleting a project frees its place immediately.

A limit value is `number | null`, with three states that look identical if you are
careless:

| Value | Means | Renders as |
|---|---|---|
| `null` | unlimited | "Unlimited", and **no progress bar at all** |
| `0` | not included on this plan | "Not on this plan", full muted bar |
| `n > 0` | a ceiling | "3 of 500", proportional bar |

Conflating `0` with "no ceiling" hands every customer every feature. Conflating it
with "used up" tells someone to wait for a monthly reset that will never grant
them the feature. `limitStatus()` returns a distinct shape for each, `checkLimit()`
a distinct `reason`, and `scripts/render-check.mjs` asserts on the **rendered
HTML** that an unlimited limit draws no bar and a zero limit never prints "0 of 0".

`clampLimit()` drops a stored override that is not a number, is negative, is `NaN`
or is infinite — `undefined` means "ignore this row, use the plan". A **fraction is
floored rather than rejected**, and the direction is the argument: rejecting `1.5`
would fall back to the plan's own value, which may be *higher* than an override
someone set in order to restrict this account. Flooring can only ever give less
than was asked for.

---

## 4. One decision function, and refusals a person can act on

`checkLimit(limitId, context, amount = 1)` is the only place that decides. Its
order is the design: `blockedReason` first (no limit matters if the account cannot
write at all), then unlimited, then not-included, then over the ceiling.

The messages are written for the person refused:

- an **absolute** limit never mentions a reset — "Remove one, or upgrade for more";
- a **spent allowance** does say when it returns, because waiting works;
- a **single request larger than the whole monthly allowance** says exactly that,
  instead of telling someone to wait for a reset that cannot help.

Units are singularised at 1, because "1 automations" reads as unfinished software.

Every refusal is recorded in `quota_refusals` with usage **frozen at that moment**.
Raising a limit later must not rewrite why someone was blocked last Tuesday.

### A four-phase bug found while wiring this

`usage_records` has permitted the metric `audit_run` since migration `0002`, and
**nothing ever wrote it**. Audits had been running and recording no usage at all
since Phase 4. Phase 7 found it while connecting the audit limits and fixed it by
recording `seo_audit` / `aeo_audit`. The old value stays readable so historic rows
still count, and is excluded from `WRITABLE_METRICS` so nothing writes the
ambiguous one again.

---

## 5. Billing: an abstraction whose only implementation refuses

`PaymentProvider` is an interface — `createCheckout`, `createPortalSession`,
`changePlan`, `cancel`, `fetchSubscription`, `verifyWebhook`. `nullProvider` is the
only implementation; `configured` is `false`; every method returns
`{ ok: false, reason: NOT_CONFIGURED }`.

**`nullProvider.verifyWebhook` returns `false`. Always.** That is the single
load-bearing line of the phase: without it, anyone who can POST could grant
themselves the Agency plan. The mutation suite flips it to `true` to prove the
tests notice.

### What may ever be stored about a card

```ts
interface PaymentMethodSummary {
  readonly brand: string;          // "Visa"
  readonly last4: string;          // "4242"
  readonly expiryMonth: number | null;
  readonly expiryYear: number | null;
}
```

That is the whole type, and those four are the whole set of `payment_*` columns in
56 tables. No number, no token, no CVV, no bank detail — **the dishonest version is
unrepresentable**, the same technique as `SearchVolume` (Phase 4),
`BudgetRecommendation` (Phase 5) and `MetricValue` (Phase 6). The gate reads the
column names out of the DDL and asserts the set is exactly those four.

No screen collects payment details either: the billing screen renders **no
data-entry control at all**, asserted against rendered HTML, which is a stronger
claim than "no input named card".

### Subscription state, and the one thing never taken away

`TRANSITIONS` is a map expressed as data, so a test walks it: every status
reachable, no transition leaving a non-status. An event with no transition from the
current state is **ignored and recorded with a note**, never an error — providers
retry and deliver out of order, and a retried `payment_succeeded` must not break a
live subscription. `billing_events.external_event_id` is UNIQUE, so a retry is
recorded as already-seen rather than applied twice.

**`accessFor()` never revokes read access, in any state.** Past due, cancelled,
paused, incomplete — `readable` is `true` in every branch, and the gate asserts it
across all five. A customer whose card failed still owns their work and can export
it. A failed payment opens a seven-day grace window measured from `pastDueSince`,
so a second failure does not restart it; after it closes, writing stops and reading
does not.

### The webhook

The signature is verified **first, against the raw body**, because providers sign
the bytes and re-serialising parsed JSON changes them. The gate asserts
`request.text()`, then `verifyWebhook`, then `JSON.parse`, in that order, and that
`readJson()` is not used — it would consume the body and make verification
impossible.

A bad signature is answered **202 with no detail**. A 401 would confirm to a forger
that the endpoint is live and that only the signature stood in their way; a 500
would suggest they had found a bug. Only a *summary* of a provider payload is
stored, never the raw body, which carries more customer data than this product
needs.

---

## 6. The security decision the phase turns on

**An organization admin is not a platform admin.**

SeSha has had an `admin` role on `memberships` since Phase 2, meaning "can
administer *this organization*". Most paying customers have one. Platform staff is
a **separate table**, `platform_staff`, with three roles and twenty-four
permissions. Merging them would have been less code and would have meant every
customer who made themselves an admin could read every other customer's account.
`tests/phase7-services.test.ts` contains a test named exactly that.

`StaffContext` carries **no `organizationId`**: the panel reads across tenants by
definition, and a context offering one organization id invites a query to be scoped
by it, which silently returns nothing and looks like it worked.

`AdminReadRepository` is the one deliberate cross-tenant seam, and **no method on
it returns customer content** — no lead, no article, no report body, no message.
The single exception is feedback, which a customer wrote in order to be read, and
reading it is audited like everything else.

| Brief's measure | How |
|---|---|
| Separate admin authorization | `platform_staff`, `requireStaff`, a context with no tenant |
| Strong authentication | every `:write` needs a live sudo window, computed from the session record so a client cannot extend it |
| Role restrictions | permissions declared as a **minimum role**, so a new one cannot be granted to everyone by accident or forgotten for a role |
| Audit logs | `admin_actions` — every action **including every read** |
| Rate limits | `enforceRateLimit` on every admin route; the gate scans for one that lacks it |
| Session controls | the staff row is read on **every request**, so revocation is immediate rather than waiting out a thirty-day session |

Support holds exactly one write: moving feedback along its triage states. Every
other write is withheld, and the gate lists them individually rather than asserting
the neater and false "support holds no writes".

**Non-staff get 404**, the same not-found page a mistyped URL gets. Staff with the
*wrong role* also get 404 — a support engineer probing for staff management should
not learn it is there and that someone senior can reach it. The one exception is a
stale sign-in: 403 with a `needsSudo` flag, because that caller is already known to
be staff.

`admin_actions` has **no cascade to `organizations`**, so deleting an account does
not delete the record of what staff did to it. Reading the audit trail needs
`engineer` — support cannot review its own activity — and the read is recorded, so
the reviewer's visit appears the next time the page loads. The page says so on
screen.

---

## 7. What the panel will not tell you

`health()` reports only what is knowable here: which database adapter is live,
whether the required secrets are set, whether email and AI providers are
configured, how many jobs are stuck, how many errors are open in 24 hours.

Beside it, rendered under the heading **"Not measured"**: uptime (no availability
history is recorded, so any figure would be invented), response latency (not
instrumented), queue depth over time (jobs are counted now, not sampled), and
per-provider latency and error rates.

There is no "all systems operational" badge. `unknown` gets its own word and ranks
**worse than `ok`** — a check that could not be performed is not a pass. The
platform usage screen lists every metric including the ones at zero, because "we
have no figure" and "nobody did it" look identical in a sparse object and the first
is a bug worth seeing. No cost figure is shown anywhere: token counts are recorded,
provider invoices are not.

---

## 8. What was verified, and what still cannot be

### Verified

| Check | Result |
|---|---|
| Unit tests | **1900 passing, 0 failing** (367 suites) |
| Type checking — real `tsc`, strict + `noUncheckedIndexedAccess`, every `.ts` file | **260 files, PASS** |
| Static verification — syntax, imports, named exports, server/client boundary, route conventions, `Field` render-prop usage | **359 files, PASS** |
| Component render assertions against real HTML | **69 passing** (20 new) |
| Whole-page render audit | **59 surfaces, 0 problems** (3 new) |
| **Mutation testing** — 14 named mutations | **all 14 caught** |
| `db/schema.sql` regenerated from the migrations | **56 tables, matches** |
| Production dependencies | **still four** |

### The three bugs the harness found

The render check and page audit found these the first time they ran, and none would
have been visible without executing the components:

1. a heading jump from `h1` to `h3` on the usage screen;
2. the same on the billing screen — the plan cards are `h3` with no `h2` above
   them, which is a real accessibility defect, not a test artefact;
3. a structured-data expectation that should never have applied to a noindex admin
   page.

All three are fixed. A fourth finding came from the gate itself: eight planned AI
agents still said they would arrive "in Phase 7", which has now shipped without
them. They name Phase 8 now, and the Templates screen — whose *staff-side* settings
did ship, while the customer-facing presets did not — no longer names a phase
number at all in customer-facing copy.

### One mutation survived, and the fix was a design change

`admin-answers-403` changed the admin guard's refusal from 404 to 403 and **the
entire suite stayed green**. Every test asserted the *decision*
(`checkAdminAccess`); none asserted the *response*, because the mapping lived
inline in a request handler behind `getCurrentSession` where no test could reach
it.

The fix was not an extra assertion. The mapping is now `adminRefusal()`, a pure
function with six tests of its own, and the gate asserts the guard still delegates
to it. A surviving mutation is a design finding.

### Still not verified

Unchanged from Phase 6, and still the largest risk in the project:

- **`npm install` has never run.** The npm registry returns 403 here, so
  `next build`, `next lint` and Playwright have never executed.
- **No migration has ever been executed.** 56 tables of reviewed SQL.
  `db/schema.sql` is generated from the migrations so the two cannot drift, but no
  PostgreSQL server has seen either.
- **`.tsx` is not type-checked.** JSX needs `@types/react`, unavailable offline; a
  hand-written stub would report confident nonsense. A `.tsx` type error remains
  the single most likely first-build failure.

Run these first:

```bash
rm -rf node_modules && npm install
npm run verify                     # typecheck -> lint -> test -> build
npm run verify:mutation            # proves the tests bite
npm run build && npm run test:e2e  # Playwright, five breakpoints
```

---

## 9. Files added

**Domain and logic** — `src/content/plans.ts`, `src/content/admin-nav.ts`,
`src/lib/plans/{resolve,service}.ts`, `src/lib/usage/{metrics,service}.ts`,
`src/lib/quota/index.ts`, `src/lib/billing/{types,service}.ts`,
`src/lib/flags/{index,service}.ts`,
`src/lib/admin/{auth,service,settings,page-guard}.ts`,
`src/lib/api/admin-guard.ts`.

**Storage** — `db/migrations/0007_subscriptions_usage_admin.sql`: nine tables
(`quota_refusals`, `plan_limit_overrides`, `platform_staff`, `admin_actions`,
`billing_events`, `feature_flag_rules`, `system_settings`, `error_events`,
`feedback`) taking the schema to 56, plus the plan rename and the four
display-only payment columns.

**Routes** — `/api/usage`, `/api/billing`, `/api/billing/webhook`, `/api/feedback`,
and `/api/admin` plus `organizations`, `organizations/[id]`, `limits`, `plans`,
`flags`, `settings`, `staff`, `jobs`, `errors`, `feedback`, `security`, `audit`,
`usage`, `health`.

**Screens** — `/app/usage`, `/app/settings/billing`, and the `(admin)` route group:
`/admin` plus `organizations`, `organizations/[id]`, `usage`, `health`, `jobs`,
`errors`, `feedback`, `security`, `plans`, `flags`, `settings`, `audit`, `staff`.

**Components** — `app/usage-dashboard.tsx`, `app/billing-panel.tsx`, and
`admin/{admin-shell,admin-primitives,health-checks,organization-controls,triage-controls,flag-controls,setting-controls,staff-controls}.tsx`.

**Tests** — `plans`, `quota`, `billing`, `flags`, `admin-security`,
`phase7-services`, `phase7-gate`, plus a README-migration test in `database`.

**Tooling** — `scripts/mutation-check.mjs` (`npm run verify:mutation`), twenty
render assertions, three page audits.

---

## 10. Stopping here

Phase 7 is complete and Phase 8 has not been started, per the phased development
instruction. The seams a later phase would use are listed in ARCHITECTURE §90 —
most importantly that connecting a real payment provider means implementing one
interface, because `billingStatus()`, the checkout route and the webhook all
already branch on `configured`.
