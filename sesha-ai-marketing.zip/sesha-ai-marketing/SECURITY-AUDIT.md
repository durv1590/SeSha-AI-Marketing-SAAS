# SeSha AI Marketing — Phase 8 Security & Privacy Audit

Scope: the Phase 7 codebase, audited against the Phase 8 brief (§1 security, §2 crawler, §3 privacy).
Each row names the control, where it lives, and the test that fails if it is removed.
"Mutation" means `scripts/mutation-check.mjs` deliberately breaks the control and confirms a test catches it.

**Environment caveat.** npm was unreachable throughout development, so `next build`, ESLint and Playwright have never run. The database is the in-memory adapter, which means the Postgres RLS policies exist but have never been exercised. Every claim below is backed by unit tests, source-scanning gates, or an offline harness. None of it has been checked against a deployed build.

## Findings fixed in Phase 8

| # | Severity | Finding | Fix | Proof |
|---|---|---|---|---|
| 1 | Critical | The crawler had no wall-clock timeout. A server that trickled one byte at a time could hold a worker open indefinitely (slowloris). The file header had promised this timeout since Phase 4. | A `setTimeout` wall clock in `nodeTransport` destroys the request. | `tests/crawler-transport.test.ts`, mutation `slowloris-defeats-the-crawler` |
| 2 | Critical | The DNS pin passed a bare string where Node's `lookup` hook expects `{all:true}`. Every crawl of a real hostname failed, which means the pin had never actually run. | The hook honours `options.all`. | Transport test using a `.invalid` host, mutation `address-pin-returns-a-bare-string` |
| 3 | High | `clientKey` trusted the first `X-Forwarded-For` entry, so any client could spoof its rate-limit identity. | Count from the right by `TRUSTED_PROXY_COUNT`. | `tests/security.test.ts` (spoofing suite) |
| 4 | High | Changing the password kept the acting session alive. If the password was changed because that session was stolen, the attacker stayed signed in. | Revoke all sessions and issue a new one with sudo. | `tests/auth-flow.test.ts` |
| 5 | High | Revoking crawl consent set `data_deleted_at` but deleted no pages, so the record claimed a deletion that never happened. | `revokeCrawlConsent` deletes pages first, then writes the marker. | `tests/jobs.test.ts`, mutation `revocation-only-writes-the-marker` |
| 6 | High | Nothing ever called `reapStaleJobs` or `deleteExpiredCrawlData`, so retention was not enforced and dead jobs ran forever. | `lib/jobs/maintenance.ts` plus `POST /api/internal/maintenance` (bearer `CRON_SECRET`; 404 otherwise). | `tests/maintenance.test.ts` |
| 7 | Medium | The reaper failed every stale job, throwing away work that could have been retried. | Requeue with backoff while attempts remain; abandon at `MAX_ATTEMPTS`. | Mutations `reaper-throws-away-retryable-work` and `reaper-cycles-a-poison-job-forever` |
| 8 | Medium | The admin audit list read an unbounded result set. | Cursor pagination, capped at 100. | `tests/phase8-gate.test.ts` |
| 9 | Medium | Six design-token pairs failed WCAG contrast, including control borders at 1.4.11. | Tokens adjusted. | `npm run verify:contrast` |
| 10 | Medium | There was no data export, and the privacy policy did not mention AI processing, crawling or app data. | `GET /api/account/export` (sudo plus permission, no-store, credential walk), a Settings card, and new policy sections. | `tests/privacy.test.ts` |
| 11 | Low | The sign-out route had no rate limit. | `mutation` bucket. | Phase 8 gate |
| 12 | Low | The `/fonts` cache rule was dead: the route does not exist. | Replaced with a revalidating rule for `/brand` and `/og`. | Phase 8 gate |

## §1 Security

| Area | Control | Location | Test |
|---|---|---|---|
| Authentication | scrypt N=65536 r=8 p=1 with per-hash parameters; account lockout after 5 failures and per-address lockout after 20; unverified OAuth email rejected | `lib/auth/password.ts`, `lockout.ts`, `service.ts` | `auth-crypto`, `auth-flow`, `oauth` |
| Session handling | Opaque token, stored only as a hash; httpOnly, SameSite=Lax, Secure in production; 14-day idle and 90-day absolute limits; sudo window for destructive actions; rotation on password change | `lib/auth/session.ts`, `tokens.ts` | `auth-flow` |
| Password security | Passwords are never logged or exported (redactor plus export walker); reset tokens are single-use and hashed | `lib/observability/log.ts`, `lib/privacy/export.ts` | `observability`, `privacy` |
| Authorization | RBAC permission matrix; organization admin is separate from platform staff; admin refusal returns 404 unless the caller is staff | `lib/auth/rbac.ts`, `lib/admin/auth.ts` | `authz`, `admin-security` |
| Tenant isolation | Every repository method takes `organizationId`; `assertTenant` returns 404 across tenants; RLS policies on every tenant table (inert until Postgres) | `lib/tenant`, `db/migrations` | `authz`, `database`, `privacy` (cross-tenant export) |
| API security | CSRF double-submit token plus Origin check on unsafe methods; JSON body size and shape validation | `lib/auth/csrf.ts`, `lib/api/respond.ts` | `security` |
| SQL injection | No string-built SQL. The Postgres adapter must use parameters; the migrations are static | `db/` | `verify-static` |
| XSS | React escaping; `sanitizeText`; the CSP blocks third-party script | `lib/security/sanitize.ts`, `headers.ts` | `security`, `content-policy` |
| SSRF / URL validation | See §2 | `lib/crawler/*` | `crawler-security`, `crawler-transport` |
| File handling | No user file uploads exist. Exports are generated server-side and served as attachments with `no-store` | export routes | `privacy` |
| Rate limiting | 15 named buckets; right-counted `X-Forwarded-For` | `lib/security/rate-limit.ts` | `security` |
| Secret exposure | Secrets are read only in `lib/auth`, `lib/ai/provider`, `lib/config` and `lib/env`; no component can read a secret; the logger redacts by key name and by value shape | gates | `phase7-gate` (gate 11), `observability` |
| Admin security | Staff table, sudo for writes, every read audited, noindex, 404 to non-staff | `lib/admin` | `admin-security`, `phase7-gate` |
| Payment data | No card data is stored; only brand and last four digits. Webhooks are verified by signature | `lib/billing` | `billing` |

## §2 Crawler security

| Threat | Control | Test |
|---|---|---|
| Localhost, private IPs, cloud metadata (169.254.169.254, fd00:ec2::254) | `ip-policy.ts` block list covering IPv4, IPv6, IPv4-mapped, NAT64 and 6to4 | `crawler-security` |
| DNS rebinding | Resolve once, then pin the connection to the vetted address with a custom `lookup` | `crawler-transport` (pin) |
| Redirect attacks, excessive redirects | Every hop is re-validated; at most 5 redirects | `crawler-security` |
| Dangerous protocols | Only `http:` and `https:`; `file:`, `gopher:`, `data:` and similar are refused with a reason | `crawler-security` |
| Large responses | 2 MB cap, both on the declared length and while streaming | `crawler-transport` |
| Slow responses | 15 s wall clock plus a socket idle timer | `crawler-transport` |
| Resource exhaustion | Page and depth caps, one active crawl per project, `aiBatch` rate limit, per-plan quota | `crawler-limits`, `jobs`, `quota` |
| Consent | No crawl without a recorded consent; revoking consent deletes the crawled pages | `workspace`, `jobs` |

## §3 Data privacy

| Obligation | Implementation |
|---|---|
| Data export | `GET /api/account/export`: requires sudo and `billing:read`; format v2; counts included; declares its own omissions; credential walk |
| Account deletion | `DELETE /api/account`: re-authentication, then immediate soft delete and revocation of all sessions and tokens; anonymisation after 30 days by the SQL `anonymize_deleted_user` routine |
| Crawl history deletion | `DELETE /api/crawl?consentId=`: withdraws consent and hard-deletes the crawled pages |
| Retention controls | Retention chosen per consent (90 days by default, 365 at most), enforced by scheduled maintenance |
| Privacy and AI disclosure | Privacy Policy sections `account-data`, `crawling` and `ai-processing`; AI output carries provenance labels |

## Residual risks, stated plainly

1. **Rate limiter and lockout are in-process.** Each instance counts on its own, so multiple instances multiply the limits. Move them to Redis or Postgres before scaling out.
2. **No Postgres adapter yet.** The RLS policies are therefore inert, and application-level scoping is the only tenant barrier in running code.
3. **The CSP allows `'unsafe-inline'`** for scripts (the theme bootstrap) and styles. A nonce-based CSP is the follow-up.
4. **HSTS is sent only when `NODE_ENV=production`.** This is correct behaviour, but a staging deployment running in development mode gets no HSTS.
5. **`AUTH_SECRET` has a development fallback.** Production refuses to start without it.
6. **Anonymisation of deleted accounts** is a SQL routine and needs pg_cron or the maintenance runner once Postgres is attached.
7. **Durable idempotency** (`idempotency_keys`, migration 0008) has a schema only. The in-memory store is per-process.
8. **Nothing has been verified against a real build**: no `next build`, ESLint, Playwright, or real browsers.

## Phase 9 final review

The Phase 9 review re-ran every §1–§3 control above with the full suite and added the journey, failure-injection and database-audit tests. New findings:

| # | Severity | Finding | Fix | Proof |
|---|---|---|---|---|
| 13 | High | **DoS on the public schema validator.** Arrays nested inside arrays didn't count toward the depth limit, so about 10 KB of `[[[…]]]` crashed the request with a stack overflow | Nested arrays now count as depth | `tests/failure-recovery.test.ts` |
| 14 | Medium | The schema validator reported "no errors" for `null`, `[]`, `42` and markup-free HTML | Returns `valid:false` with an explanation | same |
| 15 | Medium | An AI provider outage made every request wait out its timeout and retries | Circuit breaker per provider; only outage-class errors count | same, and mutation `ai-breaker-counts-refusals-as-outages` |
| 16 | Medium | The `reports` and `content_generations` limits were checked but never consumed, so the plan limits never applied | Usage is recorded after the row is created | `tests/journey.test.ts` |
| 17 | Medium | 41 foreign keys had no index: slow cascading deletes, with locks held | Migration 0009; a test fails on any new unindexed FK | `tests/database-audit.test.ts` |
| 18 | Low | `/api/auth/session` was the one unthrottled endpoint | `read` bucket | `docs/API.md` |
| 19 | Low | "Which pages?" in reports was always empty, because it read the wrong fields | Reads `evidence.urls` and `issue` | `tests/journey.test.ts` |

**Secret scan.** I scanned the source for provider-key shapes (`sk-`, `sk_live_`, `AKIA`, `AIza`, `ghp_`, `xox*-`), PEM private keys and credentialed `postgres://` URLs. **Nothing was found.** The only literal secret is the development-only `AUTH_SECRET` fallback, which production refuses to use. Every `process.env` variable read in `src/` appears in `.env.example`, `.env*` files are git-ignored, and the Phase 7 gate confines secret reads to four modules.
