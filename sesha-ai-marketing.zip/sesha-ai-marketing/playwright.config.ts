import { defineConfig, devices } from '@playwright/test';

/**
 * End-to-end configuration.
 *
 * These specs require a running build, so they were authored but NOT executed
 * in the offline environment this project was developed in. Run them with:
 *   npm install && npm run build && npm run test:e2e
 *
 * PROJECTS
 *  · Five BREAKPOINT projects (Phase 1 brief), all on Chromium, which run every
 *    spec.
 *  · Phase 8 BROWSER projects: Firefox, WebKit (Safari's engine), Edge, and two
 *    real device profiles (Android Chrome, iOS Safari). These run the specs in
 *    `@cross-browser`-tagged tests only — engine differences show up in layout,
 *    focus and form behaviour, not in business logic, so running every spec
 *    six more times buys CI time and nothing else.
 *
 * Edge uses the `msedge` channel and needs Edge installed on the runner
 * (`npx playwright install msedge`); it is skipped when E2E_SKIP_EDGE is set.
 * WebKit is the closest thing to Safari that runs on Linux CI; a true Safari
 * pass still needs macOS.
 */
export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: true,
  forbidOnly: Boolean(process.env.CI),
  retries: process.env.CI ? 2 : 0,
  reporter: process.env.CI ? 'github' : 'list',

  use: {
    baseURL: process.env.E2E_BASE_URL ?? 'http://localhost:3000',
    trace: 'on-first-retry',
  },

  webServer: process.env.E2E_BASE_URL
    ? undefined
    : {
        command: 'npm run start',
        url: 'http://localhost:3000',
        reuseExistingServer: !process.env.CI,
        timeout: 120_000,
      },

  projects: [
    { name: 'mobile', use: { ...devices['Pixel 7'] } },
    { name: 'tablet', use: { ...devices['iPad (gen 7)'] } },
    { name: 'laptop', use: { ...devices['Desktop Chrome'], viewport: { width: 1366, height: 768 } } },
    { name: 'desktop', use: { ...devices['Desktop Chrome'], viewport: { width: 1680, height: 1050 } } },
    { name: 'large', use: { ...devices['Desktop Chrome'], viewport: { width: 2560, height: 1440 } } },

    // Phase 8 — browsers and devices.
    { name: 'firefox', grep: /@cross-browser/, use: { ...devices['Desktop Firefox'] } },
    { name: 'webkit', grep: /@cross-browser/, use: { ...devices['Desktop Safari'] } },
    ...(process.env.E2E_SKIP_EDGE
      ? []
      : [{ name: 'edge', grep: /@cross-browser/, use: { ...devices['Desktop Edge'], channel: 'msedge' } }]),
    { name: 'android', grep: /@cross-browser/, use: { ...devices['Pixel 7'] } },
    { name: 'ios', grep: /@cross-browser/, use: { ...devices['iPhone 14'] } },
  ],
});
