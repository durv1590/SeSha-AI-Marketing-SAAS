# Phase 2 — Completion Report

**SeSha AI Marketing** · Authentication, User Accounts, Business Onboarding, SaaS Foundation
SeSha AI Marketing · 11 September 2026

Phase 1 was not rebuilt. The public website is unchanged in behaviour; it moved into a
`(marketing)` route group so the sign-in pages and the workspace do not inherit marketing
navigation. All 197 Phase 1 tests still pass alongside the 255 new ones.

---

## 1. Quality gate

| | Item | Status | Evidence |
|---|---|---|---|
| ☑ | **Registration** | Verified | Real sign-up runs in `tests/auth-flow.test.ts`: user, organization, owner membership and trial subscription created; password never stored in plaintext |
| ☑ | **Login** | Verified | Correct password succeeds; wrong password and unknown account are byte-identical failures |
| ☑ | **Logout** | Verified | Token invalid immediately after sign-out; other sessions survive |
| ☑ | **Password reset** | Verified | Single-use, 30-minute link; reissuing invalidates the previous one; a weak password does not consume the token; every session revoked on success |
| ☑ | **Email verification** | Verified | Single-use token, session rotated on success, resend invalidates the old link |
| ☑ | **Google auth** | Verified — **implemented, not just architected** | Full OAuth 2.0 + PKCE + OIDC. 38 tests against **real RS256 signatures**: tampering, `alg:none`, algorithm confusion, wrong key, wrong issuer, wrong audience, expiry, nonce replay all rejected |
| ☑ | **Authorization** | Verified | 4 roles, 27 permissions, monotonic across the role order; enforced at API, service and database layers |
| ☑ | **Tenant isolation** | Verified | Two real organizations created through sign-up; every cross-tenant read, update, delete and grant returns **404, not 403** — and "not yours" is byte-identical to "does not exist" |
| ☑ | **Business creation** | Verified | All 12 specified fields validated server-side |
| ☑ | **Project creation** | Verified | Plan limits enforced in the service layer; slugs unique per organization; cross-tenant business attachment refused |
| ☑ | **Onboarding** | Verified | Business + project + AI Marketing Profile + optional consent, with a stored completeness score |
| ☑ | **Dashboard shell** | Verified | Renders in the page audit; 12 planned areas render explicit coming-soon states |
| ☑ | **Database migrations** | Verified (not applied) | 24 tables, forward-only migrations, generated schema, 21 consistency tests. **Not run against a live PostgreSQL** — see §5 |
| ☑ | **Security checks** | Verified | Rate limiting, lockout, CSRF, session expiry, secure cookies, audit logging, SSRF guard — all tested |
| ☑ | **Tests** | **452 passing, 0 failing** | Plus 152 files statically verified and 46 pages rendered |
| ☐ | **Production build** | **NOT RUN** | npm registry blocked — see §5 |

---

## 2. What was built

### Authentication (`src/lib/auth/`)

Zero new dependencies. Everything security-critical is built on Node's `crypto`.

- **Password hashing** — scrypt at N=2^16, r=8, 64-byte output (above the OWASP floor),
  unique 16-byte salt, versioned self-describing format, `needsRehash` for opportunistic
  upgrades, and `dummyVerify` so a missing account costs the same CPU as a real one.
- **Sessions** — opaque 256-bit tokens; the database stores only a SHA-256 hash. Three
  independent expiry rules (own expiry, 14-day idle, 90-day absolute that activity cannot
  extend). Rotated on every privilege change.
- **Email verification and password reset** — single-use hashed tokens, 24 hours and 30
  minutes respectively.
- **Google Sign-In** — Authorization Code + PKCE S256, state, nonce, and ID token
  verification against Google's JWKS with issuer/audience/expiry/nonce checks.
- **Account deletion** — two-stage: immediate soft delete (sign-in blocked, sessions
  revoked, tokens void) then scheduled anonymisation.

### Authorization and tenancy

Four roles — `user < team_member < manager < admin` — per organization, not global.
Permissions are declared as a **minimum role per permission**, so a new permission cannot
be accidentally granted to nobody or to everybody.

Enforced at four independent layers: UI (courtesy), API route, service layer, and
PostgreSQL row-level security. The repository interfaces make the tenant filter impossible
to omit: there is no `findById(id)` for a scoped row, only `findById(organizationId, id)`.

### Business onboarding and crawl consent

Four steps producing an AI Marketing Profile from all 12 specified fields.

**Website crawl consent is the part that matters.** Entering a URL grants nothing — a test
asserts precisely that. The consent step states what would be accessed, why, the page and
rate limits, robots.txt handling, retention, how to stop and delete, and that the crawler
is not built yet. The checkbox starts unchecked, the step is skippable, and each grant
records a `consent_version` so a later change to the wording cannot retroactively widen an
existing consent.

The URL validator doubles as an SSRF guard, rejecting loopback, link-local, private,
carrier-grade-NAT and cloud-metadata addresses.

### Database

24 tables across two forward-only migrations. `db/schema.sql` is **generated** from them.
Conventions enforced by test: a primary key everywhere, `timestamptz` everywhere,
`organization_id` + row-level security on every tenant-scoped table, `ON DELETE` on every
foreign key, `citext` emails, hashed tokens only, no plaintext password column.

Soft delete is per-table and deliberate: `users`, `businesses` and `projects` use
`deleted_at`; `sessions` and tokens are hard-deleted. The audit log is append-only,
enforced by database rules.

### Dashboard

Navigation exactly as specified. Every item declares `available` or `planned`; a planned
item renders as a **disabled element with a "Soon" badge, not a link**, and its page says
what the feature will do and which phase it belongs to. 3 of 16 areas are available
(Schema Validator, Brand Kit, Settings) plus the workspace home and projects.

The Edge middleware is **not** the authorization boundary — it cannot reach the database,
so it only checks that a cookie exists. The `(app)` layout resolves the session properly,
and every API route re-checks independently.

---

## 3. Problems found and fixed

Found by the tests during development, all fixed and re-verified:

1. **Phase 1's contact and newsletter routes broke** when the repository layer was
   restructured. Fixed by adding both to the `Database` facade, preserving Phase 1's
   privacy posture (receipt logged, content and address not retained).
2. **Auth pages inherited the marketing header and footer.** Fixed by restructuring into
   `(marketing)` and `(auth)` route groups and slimming the root layout to html/body/theme.
3. **Heading-hierarchy and link tests broke** on the restructure. Updated to cover the new
   surface — including a new assertion that every route-group layout provides a skip link
   and `#main`, following one level of component delegation.
4. **The static verifier flagged a type-only import** of `@/lib/db/types` from a client
   component. The check is now AST-accurate: type-only imports are erased at build time and
   no longer flagged, value imports still are.
5. **A database convention test matched a comment**, not a column — the phrase "never a
   naive timestamp" inside a migration. Fixed by stripping SQL comments before scanning.
6. **A crawl-consent test asserted URL formatting** rather than the invariant it existed to
   protect. Rewritten to assert what matters: no consent without an explicit grant.

---

## 4. Verified in this environment

| Check | Result |
|---|---|
| Unit tests (14 suites) | **452 passing, 0 failing** |
| Static verification, 152 files | **PASS** |
| Component render assertions | **22 passing** |
| Whole-page render audit | **46 pages, 0 problems** |
| Database schema consistency | **21 tests passing** |

The security-critical assertions worth naming:

- A password is never stored in plaintext and never appears in an audit record.
- Sign-up, sign-in and password reset are indistinguishable for registered and
  unregistered addresses — including in elapsed time.
- Every cross-tenant access path returns "not found", with an identical message to a
  genuinely missing resource.
- A tampered Google ID token, an `alg:none` token, a token signed by another key, one
  minted for a different client, and a replayed nonce are all rejected.
- Raw IP addresses never reach the audit log; they are keyed-hashed.
- An unbuilt feature renders no chart-like or table-like placeholder content.

---

## 5. Not verified — run these first

The npm registry is still blocked in the build environment (`registry.npmjs.org` →
`403 Forbidden`), so `npm install`, `tsc --noEmit`, `next lint`, `next build` and
Playwright **could not be executed**, in Phase 2 as in Phase 1.

```bash
rm -rf node_modules && npm install
npm run typecheck      # most likely source of a first-build error
npm run lint
npm run build
npm run test:e2e
```

Specifically unverified:

1. **Types.** Structure, imports, exports and all runtime behaviour are verified; types are
   not, because the definitions were not installable.
2. **The production build.** Next.js has never compiled this code.
3. **Visual appearance.** Tailwind was never compiled, so no screenshot exists.
4. **The database against real PostgreSQL.** The schema is internally consistent and
   convention-checked, but `psql` has never run it. Row-level security policies in
   particular are asserted to exist, not observed to work.
5. **Browser behaviour** — cookie flags, redirects, the OAuth round trip. Playwright specs
   are written for all of it.

---

## 6. Remaining non-critical issues

1. **No transactions in the in-memory adapter.** `completeOnboarding` performs several
   writes; a failure part-way leaves partial state. The PostgreSQL adapter must wrap it in
   one transaction — noted in `src/lib/db/index.ts` and in the service.
2. **Rate limiting and lockout are per-instance.** Correct for one instance; a
   multi-instance deployment needs the Redis-backed store the interfaces anticipate, or the
   `login_attempts` table. An attacker otherwise spreads attempts across instances.
3. **Email is not sent.** `SMTP_URL` is unset, so links are logged. The workspace says so
   on screen rather than leaving users waiting.
4. **Google OAuth needs credentials.** The implementation is complete; without
   `GOOGLE_CLIENT_ID`/`SECRET`/`REDIRECT_URI` the button renders disabled with an
   explanation.
5. **CSP still permits inline scripts**, required by Next's hydration bootstrap and the
   no-flash theme script. Per-request nonces remain outstanding.
6. **Team invitations are not built.** The `memberships` table and the role model support
   multiple members; the invite flow itself is later-phase work, so every account is
   currently a single-owner organization.
7. **Brand kit is read-only.** Editing lands with Content Studio, which is the first module
   that consumes those rules.
8. **The breach-corpus password check is a small local blocklist.** A production deployment
   should add a Have I Been Pwned k-anonymity range lookup in the sign-up route — a network
   call, so it belongs there rather than in the pure policy function.
9. **`scrypt`, not Argon2id.** A legitimate OWASP-accepted choice, made because Argon2
   requires a native npm package that could not be installed. The `PasswordHasher`
   interface makes swapping it a single-file change.

---

## Phase 3 has not been started

Per the phased development instruction, work stops here. The seams Phase 3 plugs into are
documented in ARCHITECTURE.md § 22.
