import { NextResponse, type NextRequest } from 'next/server';

/**
 * Edge middleware.
 *
 * WHAT THIS DOES: a cheap cookie-presence check, to redirect signed-out
 * visitors away from /app and /onboarding before a page renders, and to bounce
 * signed-in users off the sign-in page.
 *
 * WHAT THIS IS NOT: the authorization boundary. Middleware runs on the Edge
 * runtime, where the database is not reachable, so it CANNOT validate a session
 * — only observe that a cookie exists. A forged or expired cookie sails past
 * it. The real checks are:
 *   · `src/app/(app)/layout.tsx`, which resolves the session server-side and
 *     redirects if it is invalid;
 *   · `requireAuth` / `requireAuthorized` in every API route;
 *   · tenant ownership at the service layer.
 *
 * Treating middleware as the gate is a common and serious mistake. It is a
 * user-experience optimisation here, nothing more.
 */

const SESSION_COOKIE = 'sesha_session';

const PROTECTED_PREFIXES = ['/app', '/onboarding'];
const AUTH_PAGES = ['/sign-in', '/sign-up', '/forgot-password'];

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const hasSessionCookie = Boolean(request.cookies.get(SESSION_COOKIE)?.value);

  if (PROTECTED_PREFIXES.some((prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`))) {
    if (!hasSessionCookie) {
      const url = request.nextUrl.clone();
      url.pathname = '/sign-in';
      // Round-trip the destination so sign-in can return the user to it.
      // Only a path is carried, never a full URL — an open redirect otherwise.
      url.search = `?next=${encodeURIComponent(pathname)}`;
      return NextResponse.redirect(url);
    }
  }

  if (hasSessionCookie && AUTH_PAGES.includes(pathname)) {
    const url = request.nextUrl.clone();
    url.pathname = '/app';
    url.search = '';
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  // Everything except static assets and the API (routes guard themselves).
  matcher: ['/((?!api|_next/static|_next/image|favicon.svg|og|brand|.*\\.png$).*)'],
};
