import assert from 'node:assert/strict';
import { test, describe } from 'node:test';
import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/**
 * PHASE 9 GATE — final QA, deployment preparation, documentation, and the
 * honesty of the readiness verdict.
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (relative: string) => readFileSync(path.join(root, relative), 'utf8');

function walk(dir: string, filter: RegExp): string[] {
  const out: string[] = [];
  if (!existsSync(dir)) return out;
  for (const entry of readdirSync(dir)) {
    if (entry === 'node_modules' || entry === '.next') continue;
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) out.push(...walk(full, filter));
    else if (filter.test(entry)) out.push(full);
  }
  return out;
}

describe('gate: QA suites exist and cover the brief', () => {
  test('the journey test walks every stage, in order', () => {
    const journey = read('tests/journey.test.ts');
    const stages = [
      'Registration', 'Verification', 'Login', 'onboarding', 'Brand kit', 'Copilot', 'strategy',
      'Content', 'crawl', 'SEO', 'AEO', 'Schema', 'Competitor', 'Advertising', 'Campaign', 'Lead',
      'Calendar', 'Automation', 'Analytics', 'Report', 'Subscription',
    ];
    let cursor = 0;
    for (const stage of stages) {
      const at = journey.toLowerCase().indexOf(stage.toLowerCase(), cursor);
      assert.ok(at >= 0, `the journey does not reach "${stage}" after the previous stage`);
      cursor = at;
    }
  });

  test('the failure suite simulates all twelve failure modes', () => {
    const failures = read('tests/failure-recovery.test.ts');
    for (let item = 1; item <= 12; item += 1) {
      assert.match(failures, new RegExp(`describe\\('${item}\\. `), `failure mode ${item} is missing`);
    }
  });

  test('the database audit exists', () => {
    assert.ok(existsSync(path.join(root, 'tests', 'database-audit.test.ts')));
  });
});

describe('gate: secrets', () => {
  const SHAPES = [
    /sk-[A-Za-z0-9]{20,}/, /sk_live_[A-Za-z0-9]{10,}/, /AKIA[0-9A-Z]{16}/, /AIza[0-9A-Za-z_-]{35}/,
    /ghp_[A-Za-z0-9]{36}/, /xox[baprs]-[A-Za-z0-9-]{10,}/, /-----BEGIN [A-Z ]*PRIVATE KEY-----/,
    /postgres(?:ql)?:\/\/[^\s'"`:@]+:[^\s'"`@]+@/,
  ];

  test('no credential-shaped string is committed anywhere outside tests', () => {
    const offenders: string[] = [];
    for (const file of walk(root, /\.(ts|tsx|mjs|js|json|sql|md|yml|yaml|env|example|txt)$|^Dockerfile$/)) {
      const relative = path.relative(root, file);
      if (relative.startsWith('tests')) continue;
      const text = readFileSync(file, 'utf8');
      for (const shape of SHAPES) if (shape.test(text)) offenders.push(`${relative}: ${shape}`);
    }
    assert.deepEqual(offenders, []);
  });

  test('every environment variable the code reads is documented in .env.example', () => {
    const example = read('.env.example');
    const used = new Set<string>();
    for (const file of [...walk(path.join(root, 'src'), /\.(ts|tsx)$/), path.join(root, 'middleware.ts')]) {
      for (const match of readFileSync(file, 'utf8').matchAll(/process\.env\.([A-Z0-9_]+)/g)) used.add(match[1]!);
    }
    used.delete('NODE_ENV');
    const missing = [...used].filter((name) => !new RegExp(`^#?\\s?${name}=`, 'm').test(example));
    assert.deepEqual(missing, []);
  });

  test('.env.example holds placeholders only, and real env files are ignored', () => {
    for (const line of read('.env.example').split('\n')) {
      const match = /^(\w*(?:SECRET|KEY|PASSWORD|TOKEN)\w*)=(.*)$/.exec(line);
      if (match) assert.equal(match[2]!.trim(), '', `${match[1]} has a value in .env.example`);
    }
    const ignore = read('.gitignore');
    for (const pattern of ['.env', '.env.local', '.env.production']) assert.ok(ignore.includes(pattern));
  });
});

describe('gate: deployment', () => {
  test('the image builds only after the full gate passes, and runs as non-root', () => {
    const docker = read('Dockerfile');
    assert.match(docker, /npm run typecheck && npm run lint && npm test/);
    assert.match(docker, /npm run build/);
    assert.match(docker, /USER app/);
    assert.match(docker, /HEALTHCHECK/);
    assert.match(read('Dockerfile'), /NEXT_OUTPUT_STANDALONE=true/);
    assert.match(read('next.config.ts'), /NEXT_OUTPUT_STANDALONE/);
  });

  test('the topology migrates, schedules maintenance and terminates TLS', () => {
    const compose = read('docker-compose.yml');
    for (const service of ['app:', 'postgres:', 'migrate:', 'scheduler:', 'proxy:']) assert.ok(compose.includes(service));
    assert.match(compose, /api\/internal\/maintenance/);
    assert.ok(existsSync(path.join(root, 'deploy', 'Caddyfile')));
  });

  test('the deployment doc does not pretend the database works', () => {
    assert.match(read('docs/DEPLOYMENT.md'), /NOT deployable to production yet/);
  });
});

describe('gate: documentation', () => {
  test('every topic in the brief has a home', () => {
    const index = read('docs/README.md');
    for (const topic of [
      'Architecture', 'Database', 'API', 'Authentication', 'AI architecture', 'AI providers', 'SEO', 'AEO',
      'Schema', 'Crawler', 'Advertising integrations', 'Social integrations', 'Analytics', 'Subscriptions',
      'Admin', 'Deployment', 'Testing', 'Security', 'Privacy', 'Environment variables', 'Troubleshooting', 'Roadmap',
    ]) {
      assert.ok(index.includes(topic), `docs/README.md has no entry for ${topic}`);
    }
    for (const match of index.matchAll(/\]\(([^)]+\.md)\)/g)) {
      assert.ok(existsSync(path.join(root, 'docs', match[1]!)), `broken link ${match[1]}`);
    }
  });

  test('the generated API, database and environment docs are current', () => {
    const run = spawnSync(process.execPath, [path.join(root, 'scripts', 'build-docs.mjs'), '--check'], { encoding: 'utf8' });
    assert.equal(run.status, 0, run.stdout);
  });
});

describe('gate: the readiness verdict is honest', () => {
  const report = read('PRODUCTION-READINESS-REPORT.md');

  test('all thirty sections are present, in order', () => {
    for (let section = 1; section <= 30; section += 1) {
      assert.match(report, new RegExp(`^## ${section}\\. `, 'm'), `section ${section} is missing`);
    }
  });

  test('it does NOT declare the product production ready while blockers remain', () => {
    assert.match(report, /NOT production ready/);
    const affirmative = report.replace(/NOT production ready|"Production Ready"/gi, '');
    assert.ok(!/\bis production[- ]ready\b|\bproduction ready\b(?!.*claim)/i.test(affirmative.split('\n').slice(0, 12).join('\n')));
  });

  test('every critical issue states issue, severity, impact, fix and why', () => {
    assert.match(report, /\| ID \| Issue \| Severity \| Impact \| Recommended fix \| Why it must be fixed before launch \|/);
    assert.match(report, /\*\*B1\*\*[^\n]*\*\*Critical\*\*/);
    assert.match(report, /\*\*B2\*\*[^\n]*\*\*Critical\*\*/);
  });

  test('the blockers it names are still true in the code (so the report cannot go stale silently)', () => {
    // B1: when a Postgres adapter lands, this assertion fails and the report must be revised.
    assert.match(read('src/lib/db/index.ts'), /PostgreSQL adapter is not implemented yet/);
    // B4: likewise for email delivery.
    assert.match(read('src/lib/email.ts'), /no email provider is implemented yet/);
  });
});
