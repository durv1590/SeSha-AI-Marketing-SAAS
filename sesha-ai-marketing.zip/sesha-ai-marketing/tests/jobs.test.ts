import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { signUp, toRole } from '../src/lib/auth/service';
import { completeOnboarding, grantCrawlConsent, revokeCrawlConsent } from '../src/lib/workspace/service';
import { NotFoundError, type TenantContext } from '../src/lib/tenant';
import { CRAWL_CONSENT_VERSION } from '../src/lib/validation/onboarding';
import {
  JOB_STATUSES,
  MAX_ATTEMPTS,
  TERMINAL_STATUSES,
  canRetry,
  canTransition,
  explainFailure,
  isJobKind,
  isJobStatus,
  isRetryable,
  isTerminal,
  progressOf,
  retryDelayMs,
} from '../src/lib/jobs/types';
import {
  ConsentRequiredError,
  JobConflictError,
  RetryNotAllowedError,
  cancelJob,
  deleteCrawlDataForConsent,
  deleteExpiredCrawlData,
  getLatestAudit,
  listJobs,
  listKeywords,
  reapStaleJobs,
  requestJob,
  resolveGrant,
  retryJob,
  runJob,
  toJobView,
  type CrawlServiceContext,
} from '../src/lib/crawl/service';
import type { Transport } from '../src/lib/crawler';

/**
 * Background jobs, consent enforcement and the crawl-to-audit pipeline.
 *
 * The most important assertions here are the consent ones. A crawler that
 * fetches a site the user did not authorise is not a bug in a feature, it is
 * unauthorised access performed by our infrastructure on their behalf — so
 * consent is checked when the job is queued AND again when it runs, and both
 * checks are tested.
 */

const PASSWORD = 'a genuinely long passphrase 2026';
// A realistic hostname. NOT `*.example`, `*.test` or `*.invalid`: those are
// RFC 2606 reserved namespaces that the crawler's hostname policy refuses
// outright, which is correct behaviour and would make this fixture untestable.
const SITE = 'https://acme-coffee.example.com';

/* -------------------------------------------------------------------------- */
/* Fixtures                                                                   */
/* -------------------------------------------------------------------------- */

function pageHtml(title: string, links: string[] = []): string {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>${title}</title>
    <meta name="description" content="A description of ${title} long enough to pass the audit threshold comfortably.">
    <link rel="canonical" href="${SITE}/">
    <script type="application/ld+json">${JSON.stringify({
      '@type': 'Organization',
      name: 'Acme Coffee',
      telephone: '+91 712 000 0000',
    })}</script>
    </head><body><h1>${title}</h1><h2>How do we roast our coffee?</h2>
    <p>${'We roast our coffee slowly in small batches every morning. '.repeat(15)}</p>
    ${links.map((href) => `<a href="${href}">${href}</a>`).join('')}
    </body></html>`;
}

function siteTransport(pages: Record<string, { status: number; body?: string; type?: string }>): {
  transport: Transport;
  requests: string[];
} {
  const requests: string[] = [];
  const transport: Transport = async (request) => {
    requests.push(request.url);
    const scripted = pages[request.url];
    if (!scripted) {
      return { status: 404, headers: { 'content-type': 'text/html' }, body: '', bytes: 0, truncated: false };
    }
    const body = scripted.body ?? '';
    return {
      status: scripted.status,
      headers: { 'content-type': scripted.type ?? 'text/html' },
      body,
      bytes: Buffer.byteLength(body),
      truncated: false,
    };
  };
  return { transport, requests };
}

const defaultSite: Record<string, { status: number; body?: string; type?: string }> = {
  [`${SITE}/robots.txt`]: { status: 404 },
  [`${SITE}/`]: { status: 200, body: pageHtml('Acme Coffee', ['/about']) },
  [`${SITE}/about`]: { status: 200, body: pageHtml('About us') },
};

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: SITE,
};

const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic'] as const,
  marketingChannels: ['organic-search'] as const,
  brandVoice: { tones: ['friendly'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters' }],
};

let db: MemoryDatabase;
let tenant: TenantContext;
let projectId: string;
let service: CrawlServiceContext;
let requests: string[];

async function makeTenant(email: string): Promise<{ tenant: TenantContext; projectId: string }> {
  const signed = await signUp(
    { db, lockout: new MemoryLockoutStore(), secret: 'test-secret-value-at-least-32-bytes-long' },
    { email, password: PASSWORD },
  );
  if (!signed.ok || !signed.userId) throw new Error('signup failed');

  const memberships = await db.memberships.findForUser(signed.userId);
  const context: TenantContext = {
    userId: signed.userId,
    organizationId: memberships[0]!.organizationId,
    role: toRole(memberships[0]!.role),
  };
  await db.subscriptions.update(context.organizationId, { plan: 'agency' });
  const onboarded = await completeOnboarding({ db }, context, { business, profile });
  return { tenant: context, projectId: onboarded.project.id };
}

/** Grants consent the way the onboarding wizard does. */
async function grant(
  target: TenantContext = tenant,
  project: string = projectId,
  options: { maxPages?: number } = {},
) {
  return grantCrawlConsent({ db }, target, project, {
    websiteUrl: SITE,
    consentVersion: CRAWL_CONSENT_VERSION,
    maxPages: options.maxPages ?? 25,
    respectRobots: true,
    retentionDays: 30,
  });
}

function serviceWith(site = defaultSite): CrawlServiceContext {
  const scripted = siteTransport(site);
  requests = scripted.requests;
  return {
    db,
    fetchOptions: {
      transport: scripted.transport,
      lookup: async () => [{ address: '93.184.216.34', family: 4 }],
    },
    sleep: async () => {},
  };
}

/** Claims and runs the next queued job, the way a worker would. */
async function workOne(context = service) {
  const claimed = await db.jobs.claimNext(new Date());
  if (!claimed) throw new Error('nothing queued');
  return runJob(context, claimed);
}

beforeEach(async () => {
  db = new MemoryDatabase();
  const made = await makeTenant('owner@example.com');
  tenant = made.tenant;
  projectId = made.projectId;
  service = serviceWith();
});

/* -------------------------------------------------------------------------- */
/* The state machine                                                          */
/* -------------------------------------------------------------------------- */

describe('the job state machine', () => {
  test('has exactly the five states the brief names', () => {
    assert.deepEqual([...JOB_STATUSES], ['queued', 'running', 'completed', 'failed', 'cancelled']);
  });

  test('a terminal state is final', () => {
    for (const status of TERMINAL_STATUSES) {
      assert.equal(isTerminal(status), true);
      for (const target of JOB_STATUSES) {
        assert.equal(canTransition(status, target), false, `${status} -> ${target} was allowed`);
      }
    }
  });

  test('queued can go straight to cancelled, without ever running', () => {
    // A user who changes their mind before a worker picks the job up must not
    // have to wait for it to start.
    assert.equal(canTransition('queued', 'cancelled'), true);
    assert.equal(canTransition('queued', 'running'), true);
    assert.equal(canTransition('queued', 'completed'), false);
  });

  test('running can complete, fail or cancel', () => {
    assert.equal(canTransition('running', 'completed'), true);
    assert.equal(canTransition('running', 'failed'), true);
    assert.equal(canTransition('running', 'cancelled'), true);
    assert.equal(canTransition('running', 'queued'), false);
  });

  test('the type guards reject anything else', () => {
    assert.equal(isJobStatus('running'), true);
    assert.equal(isJobStatus('paused'), false);
    assert.equal(isJobKind('crawl'), true);
    assert.equal(isJobKind('publish'), false);
  });

  test('progress reports a percentage only when the total is known', () => {
    assert.equal(progressOf(5, 10, 'x').percent, 50);
    assert.equal(progressOf(5, null, 'x').percent, null);
    assert.equal(progressOf(15, 10, 'x').percent, 100, 'percent must not exceed 100');
  });
});

describe('failure classification', () => {
  test('a transient failure is retryable', () => {
    for (const code of ['timeout', 'network_error', 'dns_error', 'robots_unavailable']) {
      assert.equal(isRetryable(code), true, `${code} should be retryable`);
    }
  });

  test('a PERMANENT failure is not, because retrying wastes the user a minute', () => {
    for (const code of ['blocked', 'invalid_url', 'not_found', 'no_consent', 'consent_revoked']) {
      assert.equal(isRetryable(code), false, `${code} must not be retryable`);
    }
  });

  test('an unknown code is not retryable — default deny', () => {
    assert.equal(isRetryable('something_new'), false);
    assert.equal(isRetryable(null), false);
  });

  test('attempts are capped', () => {
    assert.equal(canRetry(0, 'timeout'), true);
    assert.equal(canRetry(2, 'timeout'), true);
    assert.equal(canRetry(3, 'timeout'), false);
  });

  test('the retry delay grows and is floored at a minute', () => {
    assert.ok(retryDelayMs(1) >= 60_000, 'retrying within a minute just reproduces the failure');
    assert.ok(retryDelayMs(2) > retryDelayMs(1));
    assert.ok(retryDelayMs(10) <= 15 * 60_000, 'the delay must be capped');
  });

  test('every failure code has a plain-language explanation', () => {
    for (const code of ['timeout', 'blocked', 'robots_unavailable', 'no_consent', 'nothing_crawled']) {
      const explanation = explainFailure(code);
      assert.ok(explanation.length > 10, `${code} has no explanation`);
      assert.ok(!explanation.includes('_'), `${code} explanation leaks the raw code`);
    }
  });
});

/* -------------------------------------------------------------------------- */
/* Consent                                                                    */
/* -------------------------------------------------------------------------- */

describe('consent is a precondition for crawling', () => {
  test('with NO consent, a crawl cannot even be queued', async () => {
    await assert.rejects(
      () => requestJob(service, tenant, { projectId, kind: 'crawl' }),
      ConsentRequiredError,
    );
  });

  test('with no consent, nothing is fetched', async () => {
    await requestJob(service, tenant, { projectId, kind: 'crawl' }).catch(() => {});
    assert.deepEqual(requests, [], 'a request was made without consent');
  });

  test('with consent, the crawl runs', async () => {
    await grant();
    const job = await requestJob(service, tenant, { projectId, kind: 'crawl' });
    assert.equal(job.status, 'queued');

    const outcome = await workOne();
    assert.equal(outcome.job.status, 'completed');
    assert.ok(outcome.crawl);
    assert.ok((outcome.crawl?.pagesCrawled ?? 0) > 0);
  });

  test('consent is checked AGAIN when the worker starts', async () => {
    // The window that matters: the user withdrew permission after queueing.
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });

    const consent = await db.crawlConsents.findActiveForProject(tenant.organizationId, projectId);
    await revokeCrawlConsent({ db }, tenant, consent!.id);

    const outcome = await workOne();
    assert.equal(outcome.job.status, 'failed');
    assert.equal(outcome.job.failureCode, 'consent_revoked');
    assert.ok(
      !requests.some((url) => url === `${SITE}/`),
      'the home page was fetched after consent was withdrawn',
    );
  });

  test('the grant limits the crawl, and cannot be widened by the plan', async () => {
    // Consent says 2 pages; the agency plan allows 300. The narrower wins.
    await grant(tenant, projectId, { maxPages: 2 });
    await requestJob(service, tenant, { projectId, kind: 'crawl', maxPages: 300 });
    const outcome = await workOne();

    assert.equal(outcome.crawl?.maxPages, 2);
    assert.ok((outcome.crawl?.pagesCrawled ?? 0) <= 2);
  });

  test('resolveGrant refuses a revoked record', async () => {
    await grant();
    const consent = await db.crawlConsents.findActiveForProject(tenant.organizationId, projectId);
    await revokeCrawlConsent({ db }, tenant, consent!.id);

    await assert.rejects(() => resolveGrant(service, tenant, projectId), ConsentRequiredError);
  });

  test('REGRESSION: consent can actually be revoked', async () => {
    // Phase 2 shipped `revokeCrawlConsent` looking the record up via
    // `tenant.projectId`, which is optional on TenantContext and is not set on a
    // settings request. The lookup always came back empty, so revocation always
    // threw NotFound and consent could never be withdrawn. Found in Phase 4 by
    // the test above that needed to revoke in order to check the second consent
    // gate.
    await grant();
    const consent = await db.crawlConsents.findActiveForProject(tenant.organizationId, projectId);
    assert.ok(consent);

    await revokeCrawlConsent({ db }, tenant, consent.id);

    const after = await db.crawlConsents.findById(tenant.organizationId, consent.id);
    assert.ok(after?.revokedAt, 'the consent record was not marked revoked');
    assert.equal(
      await db.crawlConsents.findActiveForProject(tenant.organizationId, projectId),
      null,
      'a revoked consent is still being returned as active',
    );
  });

  test('the crawl row records WHICH consent authorised it', async () => {
    await grant();
    const consent = await db.crawlConsents.findActiveForProject(tenant.organizationId, projectId);
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();

    assert.equal(outcome.crawl?.consentId, consent?.id);
  });
});

/* -------------------------------------------------------------------------- */
/* Tenant isolation                                                           */
/* -------------------------------------------------------------------------- */

describe('tenant isolation', () => {
  test("another organization's job is NOT FOUND", async () => {
    await grant();
    const job = await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const other = await makeTenant('intruder@example.com');

    await assert.rejects(() => cancelJob(service, other.tenant, job.id), NotFoundError);
    await assert.rejects(() => retryJob(service, other.tenant, job.id), NotFoundError);
  });

  test('a crawl cannot be queued against another organization’s project', async () => {
    await grant();
    const other = await makeTenant('intruder@example.com');

    await assert.rejects(
      () => requestJob(service, other.tenant, { projectId, kind: 'crawl' }),
      NotFoundError,
    );
  });

  test('another tenant sees none of our jobs', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const other = await makeTenant('intruder@example.com');

    assert.deepEqual(await listJobs(service, other.tenant, other.projectId), []);
  });

  test('crawled pages are scoped to the organization', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();
    const other = await makeTenant('intruder@example.com');

    const theirs = await db.crawls.listPages(other.tenant.organizationId, outcome.crawl!.id);
    assert.deepEqual(theirs, [], 'another organization could read our crawled pages');
  });
});

/* -------------------------------------------------------------------------- */
/* Duplicates, cancellation, retry                                            */
/* -------------------------------------------------------------------------- */

describe('one active job of a kind per project', () => {
  test('a second crawl is refused while one is queued', async () => {
    await grant();
    const first = await requestJob(service, tenant, { projectId, kind: 'crawl' });

    await assert.rejects(
      () => requestJob(service, tenant, { projectId, kind: 'crawl' }),
      (error: unknown) => error instanceof JobConflictError && error.existingJobId === first.id,
    );
  });

  test('a new crawl is allowed once the first finishes', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();

    const second = await requestJob(service, tenant, { projectId, kind: 'crawl' });
    assert.equal(second.status, 'queued');
  });
});

describe('cancellation', () => {
  test('a QUEUED job is cancelled outright', async () => {
    await grant();
    const job = await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const cancelled = await cancelJob(service, tenant, job.id);

    assert.equal(cancelled.status, 'cancelled');
    assert.ok(cancelled.finishedAt);
  });

  test('a cancelled job is never claimed by a worker', async () => {
    await grant();
    const job = await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await cancelJob(service, tenant, job.id);

    assert.equal(await db.jobs.claimNext(new Date()), null);
    assert.deepEqual(requests, []);
  });

  test('a RUNNING job is only ASKED to stop, and acknowledges itself', async () => {
    // The worker is never killed mid-write; it polls the flag and transitions.
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const claimed = await db.jobs.claimNext(new Date());

    const asked = await cancelJob(service, tenant, claimed!.id);
    assert.equal(asked.status, 'running');
    assert.equal(asked.cancelRequested, true);

    const outcome = await runJob(service, claimed!);
    assert.equal(outcome.job.status, 'cancelled');
  });

  test('cancelling a finished job is a no-op, not an error', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();

    const result = await cancelJob(service, tenant, outcome.job.id);
    assert.equal(result.status, 'completed');
  });
});

describe('retry', () => {
  test('a retryable failure can be retried, and is delayed', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });

    // robots.txt returns 500: ambiguous, so the crawl fails closed.
    const failing = serviceWith({ [`${SITE}/robots.txt`]: { status: 500 } });
    const outcome = await workOne(failing);
    assert.equal(outcome.job.status, 'failed');
    assert.equal(outcome.job.failureCode, 'robots_unavailable');

    const requeued = await retryJob(service, tenant, outcome.job.id);
    assert.equal(requeued.status, 'queued');
    assert.ok(requeued.notBefore, 'a retry must not run immediately');
  });

  test('a retry is NOT claimed before its delay has passed', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne(serviceWith({ [`${SITE}/robots.txt`]: { status: 500 } }));
    const requeued = await retryJob(service, tenant, outcome.job.id);

    assert.equal(await db.jobs.claimNext(new Date()), null);
    assert.ok(await db.jobs.claimNext(new Date(requeued.notBefore!.getTime() + 1)));
  });

  test('a PERMANENT failure cannot be retried, and says why', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });

    // Nothing answers: every page 404s, so no page could be read.
    const outcome = await workOne(serviceWith({ [`${SITE}/robots.txt`]: { status: 404 } }));
    assert.equal(outcome.job.status, 'failed');
    assert.equal(outcome.job.failureCode, 'nothing_crawled');

    await assert.rejects(() => retryJob(service, tenant, outcome.job.id), RetryNotAllowedError);
  });

  test('retries stop at the attempt cap', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const failing = serviceWith({ [`${SITE}/robots.txt`]: { status: 500 } });

    let jobId = '';
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const claimed = await db.jobs.claimNext(new Date(Date.now() + 60 * 60_000));
      if (!claimed) break;
      const outcome = await runJob(failing, claimed);
      jobId = outcome.job.id;
      if (attempt < 2) await retryJob(service, tenant, jobId);
    }

    await assert.rejects(() => retryJob(service, tenant, jobId), RetryNotAllowedError);
  });
});

describe('stale jobs are recovered', () => {
  const HOUR_AGO = () => new Date(Date.now() - 60 * 60_000);

  test('A STALE JOB WITH ATTEMPTS LEFT IS REQUEUED, not failed', async () => {
    // A dead worker says nothing about whether the job would have succeeded.
    // A deploy rolling pods mid-crawl is the common cause, and retrying works.
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await db.jobs.claimNext(HOUR_AGO());

    const outcome = await reapStaleJobs({ db, now: () => Date.now() });
    assert.deepEqual(outcome, { requeued: 1, abandoned: 0 });

    const jobs = await listJobs(service, tenant, projectId);
    assert.equal(jobs[0]?.status, 'queued');
    assert.equal(jobs[0]?.failureCode, null);
    // With a backoff, so a job that kills workers does not do so in a tight loop.
    assert.ok(jobs[0]!.notBefore!.getTime() > Date.now());
  });

  test('A JOB THAT HAS USED EVERY ATTEMPT IS ABANDONED, not cycled forever', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });

    // Each round: a worker claims the job, then dies. The clock moves a day per
    // round so the backoff never hides the job from the next claim.
    let outcome = { requeued: 0, abandoned: 0 };
    for (let round = 0; round < MAX_ATTEMPTS; round += 1) {
      const claimAt = Date.now() + (round + 1) * 24 * 60 * 60_000;
      const claimed = await db.jobs.claimNext(new Date(claimAt));
      assert.ok(claimed, `round ${round}: nothing to claim`);
      outcome = await reapStaleJobs({ db, now: () => claimAt + 60 * 60_000 });
      if (round < MAX_ATTEMPTS - 1) assert.equal(outcome.requeued, 1, `round ${round}`);
    }

    assert.deepEqual(outcome, { requeued: 0, abandoned: 1 });
    const jobs = await listJobs(service, tenant, projectId);
    assert.equal(jobs[0]?.status, 'failed');
    assert.equal(jobs[0]?.failureCode, 'worker_error');
    assert.equal(jobs[0]?.attempts, MAX_ATTEMPTS);
  });

  test('a fresh running job is left alone', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await db.jobs.claimNext(new Date());

    assert.deepEqual(await reapStaleJobs({ db, now: () => Date.now() }), { requeued: 0, abandoned: 0 });
  });
});

/* -------------------------------------------------------------------------- */
/* Progress and the view                                                      */
/* -------------------------------------------------------------------------- */

describe('progress is recorded as the job runs', () => {
  test('a finished crawl has progress written to it', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();

    const job = (await listJobs(service, tenant, projectId))[0]!;
    assert.ok(job.progressDone > 0, 'no progress was recorded');
    assert.equal(job.progressTotal, outcome.crawl?.maxPages);
  });

  test('the view never exposes an internal failure detail as the message', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne(serviceWith({ [`${SITE}/robots.txt`]: { status: 500 } }));

    const view = toJobView(outcome.job);
    assert.equal(view.status, 'failed');
    assert.ok(view.failure);
    assert.ok(!view.failure.includes('robots_unavailable'), 'the raw code leaked to the interface');
    assert.equal(view.canRetry, true);
  });

  test('the view reports canRetry false for a permanent failure', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne(serviceWith({ [`${SITE}/robots.txt`]: { status: 404 } }));

    assert.equal(toJobView(outcome.job).canRetry, false);
  });
});

/* -------------------------------------------------------------------------- */
/* Crawl to audit                                                             */
/* -------------------------------------------------------------------------- */

describe('the crawl feeds the audits', () => {
  test('pages are stored with their crawl timestamp', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();

    const pages = await db.crawls.listPages(tenant.organizationId, outcome.crawl!.id);
    assert.ok(pages.length > 0);
    for (const page of pages) {
      assert.ok(page.crawledAt instanceof Date, 'a page has no crawl timestamp');
      assert.ok(page.title, 'the title was not extracted');
    }
  });

  test('an audit cannot be queued before a crawl has run', async () => {
    await assert.rejects(
      () => requestJob(service, tenant, { projectId, kind: 'seo_audit' }),
      ConsentRequiredError,
    );
  });

  test('an SEO audit runs on the stored crawl, with no further fetching', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();

    const countBefore = requests.length;
    await requestJob(service, tenant, { projectId, kind: 'seo_audit' });
    const outcome = await workOne();

    assert.equal(outcome.job.status, 'completed');
    assert.ok(outcome.audit);
    assert.equal(requests.length, countBefore, 'the audit re-fetched the site');
  });

  test('the stored audit carries its score BASIS, not just a number', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();
    await requestJob(service, tenant, { projectId, kind: 'seo_audit' });
    await workOne();

    const audit = await getLatestAudit(service, tenant, projectId, 'seo');
    assert.ok(audit);
    assert.match(audit.scoreBasis, /own weighting/i);
    assert.ok(audit.notChecked.length > 0, 'the audit stored nothing about its limits');
  });

  test('an AEO audit also runs and stores findings', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();
    await requestJob(service, tenant, { projectId, kind: 'aeo_audit' });
    const outcome = await workOne();

    assert.equal(outcome.audit?.kind, 'aeo');
    assert.ok(outcome.audit!.findings.length > 0);
  });

  test('keywords are extracted from the crawl, with volume unavailable', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();

    const keywords = await listKeywords(service, tenant, projectId);
    assert.ok(keywords.length > 0, 'no keywords were extracted');
    for (const keyword of keywords) {
      assert.equal(
        (keyword.volume as { kind?: string }).kind,
        'unavailable',
        `"${keyword.query}" was stored with a volume figure`,
      );
    }
  });

  test('a crawl records page usage so it can be billed and limited', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();

    const period = new Date().toISOString().slice(0, 7) + '-01';
    const usage = await db.usage.listForPeriod(tenant.organizationId, period);
    const pages = usage.find((row) => row.metric === 'crawl_page');
    assert.equal(pages?.quantity, outcome.crawl?.pagesCrawled);
    assert.ok(usage.some((row) => row.metric === 'crawl_run'));
  });
});

/* -------------------------------------------------------------------------- */
/* Retention                                                                  */
/* -------------------------------------------------------------------------- */

describe('retention is honoured', () => {
  test('the crawl expires according to the consent record', async () => {
    await grant(); // retentionDays: 30
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();

    const days = (outcome.crawl!.expiresAt.getTime() - Date.now()) / (24 * 60 * 60 * 1000);
    assert.ok(days > 29 && days < 31, `expiry is ${days} days, not the 30 consented to`);
  });

  test('expired page content is HARD deleted, and the crawl record is kept', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();

    // Jump past the retention window.
    const later = Date.now() + 40 * 24 * 60 * 60 * 1000;
    const deleted = await deleteExpiredCrawlData({ db, now: () => later });

    assert.ok(deleted > 0);
    assert.deepEqual(
      await db.crawls.listPages(tenant.organizationId, outcome.crawl!.id),
      [],
      'page content survived its retention period',
    );
    // The crawl row stays: it is the record that a crawl happened, which the
    // consent trail needs.
    assert.ok(await db.crawls.findById(tenant.organizationId, outcome.crawl!.id));
  });

  test('revoking consent deletes what was crawled under it', async () => {
    // Revocation that left the content in place would not be revocation.
    await grant();
    const consent = await db.crawlConsents.findActiveForProject(tenant.organizationId, projectId);
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();

    const deleted = await deleteCrawlDataForConsent(service, tenant, consent!.id);
    assert.ok(deleted > 0);
    assert.deepEqual(await db.crawls.listPages(tenant.organizationId, outcome.crawl!.id), []);
  });

  test('REVOKING THROUGH THE WORKSPACE SERVICE DELETES THE PAGES, not just the marker', async () => {
    // Phase 8 found `revokeCrawlConsent` set `data_deleted_at` and deleted nothing.
    await grant();
    const consent = await db.crawlConsents.findActiveForProject(tenant.organizationId, projectId);
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();
    assert.ok((await db.crawls.listPages(tenant.organizationId, outcome.crawl!.id)).length > 0);

    await revokeCrawlConsent({ db }, tenant, consent!.id, { deleteData: true });
    assert.deepEqual(
      await db.crawls.listPages(tenant.organizationId, outcome.crawl!.id),
      [],
      'the consent says the data was deleted, and it was not',
    );
  });

  test('an audit on a crawl whose pages were deleted fails honestly', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();
    await db.crawls.deletePages(outcome.crawl!.id);

    await requestJob(service, tenant, { projectId, kind: 'seo_audit' });
    const audited = await workOne();

    assert.equal(audited.job.status, 'failed');
    assert.equal(audited.job.failureCode, 'nothing_crawled');
    assert.match(audited.job.failureDetail ?? '', /deleted/i);
  });
});

/* -------------------------------------------------------------------------- */
/* The worker claim                                                           */
/* -------------------------------------------------------------------------- */

describe('claiming a job', () => {
  test('a claim moves the job to running and counts the attempt', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const claimed = await db.jobs.claimNext(new Date());

    assert.equal(claimed?.status, 'running');
    assert.equal(claimed?.attempts, 1);
    assert.ok(claimed?.startedAt);
  });

  test('a claimed job is not claimed a second time', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    assert.ok(await db.jobs.claimNext(new Date()));
    assert.equal(await db.jobs.claimNext(new Date()), null, 'the same job was claimed twice');
  });

  test('runJob refuses a job that has not been claimed', async () => {
    await grant();
    const job = await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await assert.rejects(() => runJob(service, job), /must be claimed first/);
  });

  test('a claim can be restricted to certain kinds', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    assert.equal(await db.jobs.claimNext(new Date(), ['seo_audit']), null);
    assert.ok(await db.jobs.claimNext(new Date(), ['crawl']));
  });
});
