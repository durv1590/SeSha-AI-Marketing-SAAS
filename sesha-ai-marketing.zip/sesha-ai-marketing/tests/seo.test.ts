import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  DESCRIPTION_MAX,
  TITLE_MAX,
  absoluteUrl,
  buildSeo,
  canonicalUrl,
  formatTitle,
  lintSeo,
} from '../src/lib/seo/core';
import { pageSeo } from '../src/content/seo-map';

describe('absoluteUrl / canonicalUrl', () => {
  test('builds absolute URLs from site-relative paths', () => {
    assert.match(absoluteUrl('/pricing'), /^https?:\/\/[^/]+\/pricing$/);
  });

  test('passes through already-absolute URLs', () => {
    assert.equal(absoluteUrl('https://cdn.example.com/a.png'), 'https://cdn.example.com/a.png');
  });

  test('root keeps a single trailing slash', () => {
    assert.match(absoluteUrl('/'), /\/$/);
    assert.doesNotMatch(absoluteUrl('/'), /\/\/$/);
  });

  test('canonical strips query strings and fragments', () => {
    assert.equal(canonicalUrl('/pricing?utm_source=nl#plans'), canonicalUrl('/pricing'));
  });

  test('canonical strips a trailing slash', () => {
    assert.equal(canonicalUrl('/features/'), canonicalUrl('/features'));
  });
});

describe('formatTitle', () => {
  test('appends the brand suffix', () => {
    assert.equal(formatTitle('Pricing'), 'Pricing | SeSha');
  });

  test('does not double-append when the brand is already present', () => {
    assert.equal(formatTitle('SeSha AI Marketing'), 'SeSha AI Marketing');
  });

  test('empty title falls back to the site name', () => {
    assert.ok(formatTitle('   ').length > 0);
  });
});

describe('buildSeo', () => {
  const seo = buildSeo({
    title: 'Pricing',
    description:
      'Compare SeSha AI Marketing plans and pick the workspace that fits your marketing team today.',
    path: '/pricing',
  });

  test('canonical matches the page path', () => {
    assert.equal(seo.canonical, canonicalUrl('/pricing'));
  });

  test('open graph url equals the canonical', () => {
    assert.equal(seo.openGraph.url, seo.canonical);
  });

  test('defaults to an indexable website page', () => {
    assert.equal(seo.robots.index, true);
    assert.equal(seo.robots.follow, true);
    assert.equal(seo.openGraph.type, 'website');
  });

  test('emits a 1200x630 social image with alt text', () => {
    const image = seo.openGraph.images[0];
    assert.ok(image);
    assert.equal(image.width, 1200);
    assert.equal(image.height, 630);
    assert.ok(image.alt.length > 0);
    assert.match(image.url, /^https?:\/\//);
  });

  test('twitter card is summary_large_image', () => {
    assert.equal(seo.twitter.card, 'summary_large_image');
  });

  test('noindex propagates to robots', () => {
    const hidden = buildSeo({
      title: 'Hidden',
      description: 'x'.repeat(80),
      path: '/hidden',
      noindex: true,
    });
    assert.equal(hidden.robots.index, false);
  });

  test('article metadata carries dates and author', () => {
    const article = buildSeo({
      title: 'What is answer engine optimisation',
      description: 'y'.repeat(90),
      path: '/blog/what-is-aeo',
      type: 'article',
      publishedTime: '2026-01-10',
      modifiedTime: '2026-02-01',
      authorName: 'SeSha Editorial Team',
    });
    assert.equal(article.openGraph.type, 'article');
    assert.equal(article.openGraph.publishedTime, '2026-01-10');
    assert.deepEqual(article.openGraph.authors, ['SeSha Editorial Team']);
  });
});

describe('lintSeo', () => {
  test('flags an empty title as an error', () => {
    const issues = lintSeo({ title: '', description: 'z'.repeat(90), path: '/x' });
    assert.ok(issues.some((i) => i.field === 'title' && i.severity === 'error'));
  });

  test('flags an over-long description as an error', () => {
    const issues = lintSeo({ title: 'Ok', description: 'z'.repeat(DESCRIPTION_MAX + 1), path: '/x' });
    assert.ok(issues.some((i) => i.field === 'description' && i.severity === 'error'));
  });

  test('flags a non-relative path', () => {
    const issues = lintSeo({ title: 'Ok', description: 'z'.repeat(90), path: 'pricing' });
    assert.ok(issues.some((i) => i.field === 'path' && i.severity === 'error'));
  });

  test('clean input produces no issues', () => {
    const issues = lintSeo({
      title: 'Pricing',
      description:
        'Compare SeSha AI Marketing plans and pick the workspace that fits your marketing team today.',
      path: '/pricing',
    });
    assert.deepEqual(issues, []);
  });
});

describe('every page in the SEO map passes the linter', () => {
  for (const [path, input] of Object.entries(pageSeo)) {
    test(`${path} has valid, non-truncated metadata`, () => {
      const issues = lintSeo(input);
      const blocking = issues.filter((i) => i.severity === 'error');
      assert.deepEqual(
        blocking,
        [],
        `${path}: ${blocking.map((i) => `${i.field} — ${i.message}`).join('; ')}`,
      );
      assert.ok(
        formatTitle(input.title).length <= TITLE_MAX,
        `${path}: title renders at ${formatTitle(input.title).length} chars`,
      );
    });
  }

  test('every registered route has an SEO entry', async () => {
    const { routes } = await import('../src/lib/routes');
    for (const route of routes) {
      assert.ok(pageSeo[route.path], `no SEO entry for ${route.path}`);
    }
  });

  test('descriptions are unique across pages', () => {
    const seen = new Map<string, string>();
    for (const [path, input] of Object.entries(pageSeo)) {
      const previous = seen.get(input.description);
      assert.equal(previous, undefined, `${path} duplicates the description of ${previous}`);
      seen.set(input.description, path);
    }
  });

  test('titles are unique across pages', () => {
    const seen = new Map<string, string>();
    for (const [path, input] of Object.entries(pageSeo)) {
      const title = formatTitle(input.title);
      const previous = seen.get(title);
      assert.equal(previous, undefined, `${path} duplicates the title of ${previous}`);
      seen.set(title, path);
    }
  });
});
