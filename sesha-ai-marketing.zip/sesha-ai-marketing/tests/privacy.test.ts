import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { signUp, toRole } from '../src/lib/auth/service';
import { completeOnboarding } from '../src/lib/workspace/service';
import type { TenantContext } from '../src/lib/tenant';
import {
  EXPORT_FORMAT_VERSION,
  ExportLeakError,
  assertNoCredentials,
  buildAccountExport,
} from '../src/lib/privacy/export';

/**
 * Data privacy: export and deletion.
 *
 * The two obligations that have deadlines attached in law, and the two that are
 * easiest to ship in a form that looks right and is not. An export that omits a
 * table looks complete; a deletion that leaves rows behind looks done.
 */

const PASSWORD = 'a-long-enough-passphrase-9';

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: 'https://acme-coffee.example.com',
};

const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic'] as const,
  marketingChannels: ['organic-search'] as const,
  brandVoice: { tones: ['friendly'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters' }],
};

let db: MemoryDatabase;

async function makeTenant(
  email: string,
  overrides: { name?: string } = {},
): Promise<TenantContext> {
  const signed = await signUp(
    { db, lockout: new MemoryLockoutStore(), secret: 'test-secret-value-at-least-32-bytes-long' },
    { email, password: PASSWORD },
  );
  if (!signed.ok || !signed.userId) throw new Error('signup failed');
  const memberships = await db.memberships.findForUser(signed.userId);
  const tenant: TenantContext = {
    userId: signed.userId,
    organizationId: memberships[0]!.organizationId,
    role: toRole(memberships[0]!.role),
  };
  await completeOnboarding(
    { db },
    tenant,
    { business: { ...business, ...(overrides.name ? { name: overrides.name } : {}) }, profile },
  );
  return tenant;
}

const seed = () => makeTenant('owner@example.com');

beforeEach(() => {
  db = new MemoryDatabase();
});

describe('the credential guard', () => {
  test('A PASSWORD HASH ANYWHERE IN THE DOCUMENT IS A HARD FAILURE', () => {
    assert.throws(
      () => assertNoCredentials({ account: { passwordHash: 'scrypt$...' } }),
      (error: unknown) => {
        assert.ok(error instanceof ExportLeakError);
        assert.match((error as Error).message, /export\.account\.passwordHash/);
        return true;
      },
    );
  });

  test('catches a credential nested inside an array, with its path', () => {
    assert.throws(
      () => assertNoCredentials({ sessions: [{ ok: true }, { tokenHash: 'abc' }] }),
      /export\.sessions\[1\]\.tokenHash/,
    );
  });

  test('the SUFFIX rules catch the ones a new table would bring', () => {
    for (const key of ['resetTokenHash', 'webhookSecret', 'sharePasswordHash']) {
      assert.throws(() => assertNoCredentials({ [key]: 'x' }), ExportLeakError, `${key} passed`);
    }
  });

  test('ordinary customer fields are untouched', () => {
    assert.doesNotThrow(() =>
      assertNoCredentials({
        campaignName: 'Diwali push',
        // A field about a token is fine; a field that IS one is not.
        tokenBudget: 4_000,
        notes: 'the password policy was discussed',
      }),
    );
  });
});

describe('the account export', () => {
  test('carries a format version and the time it was taken', async () => {
    const tenant = await seed();
    const exported = await buildAccountExport({ db }, tenant);
    assert.equal(exported.formatVersion, EXPORT_FORMAT_VERSION);
    assert.match(exported.exportedAt, /^\d{4}-\d{2}-\d{2}T/);
  });

  test('INCLUDES THE ORGANIZATION\'S CONTENT, not a summary of it', async () => {
    const tenant = await seed();
    const exported = await buildAccountExport({ db }, tenant);

    assert.ok(exported.content.businesses.length > 0, 'the business is missing');
    assert.ok(exported.content.projects.length > 0, 'the project is missing');
    assert.equal(exported.account.email, 'owner@example.com');
    assert.ok(Object.keys(exported.organization).length > 0);
  });

  test('NO PASSWORD HASH SURVIVES, even though the user row has one', async () => {
    const tenant = await seed();
    const stored = await db.users.findById(tenant.userId);
    assert.ok(stored?.passwordHash, 'the fixture has no hash, so this proves nothing');

    const exported = await buildAccountExport({ db }, tenant);
    assert.equal(exported.account.passwordHash, undefined);
    // And the whole document, walked again from the outside.
    assert.doesNotThrow(() => assertNoCredentials(exported));
  });

  test('the serialised file contains no credential-shaped key at all', async () => {
    const tenant = await seed();
    const serialised = JSON.stringify(await buildAccountExport({ db }, tenant));
    for (const forbidden of ['passwordHash', 'tokenHash', 'password"', 'apiKey']) {
      assert.ok(!serialised.includes(forbidden), `the export contains ${forbidden}`);
    }
  });

  test('SAYS WHAT IT DOES NOT CONTAIN, in the file itself', async () => {
    // Someone reading the export must be able to tell an omission from a gap.
    const tenant = await seed();
    const exported = await buildAccountExport({ db }, tenant);
    assert.ok(exported.about.whatThisDoesNotContain.length >= 4);
    assert.ok(
      exported.about.whatThisDoesNotContain.some((line) => /password/i.test(line)),
      'the file does not explain that passwords are excluded',
    );
    assert.ok(
      exported.about.whatThisDoesNotContain.some((line) => /card/i.test(line)),
      'the file does not address payment data',
    );
  });

  test('counts every collection, so a truncated file is detectable', async () => {
    const tenant = await seed();
    const exported = await buildAccountExport({ db }, tenant);
    assert.equal(exported.counts.projects, exported.content.projects.length);
    assert.equal(exported.counts.businesses, exported.content.businesses.length);
    assert.ok('contentItems' in exported.counts);
  });

  test('ONE ORGANIZATION\'S EXPORT CONTAINS NOTHING OF ANOTHER\'S', async () => {
    const first = await seed();

    await makeTenant('other@example.com', { name: 'Rival Industries' });

    const exported = await buildAccountExport({ db }, first);
    const serialised = JSON.stringify(exported);
    assert.ok(!serialised.includes('Rival Industries'), 'another tenant leaked into the export');
    assert.ok(!serialised.includes('other@example.com'), 'another user leaked into the export');
  });

  test('an empty account exports successfully rather than failing', async () => {
    // A brand-new account with nothing in it must still get a file. Erroring
    // here would mean the least-experienced user gets the worst experience.
    const signed = await signUp(
      { db, lockout: new MemoryLockoutStore(), secret: 'test-secret-value-at-least-32-bytes-long' },
      { email: 'fresh@example.com', password: PASSWORD },
    );
    if (!signed.ok || !signed.userId) throw new Error('sign-up failed');
    const memberships = await db.memberships.findForUser(signed.userId);

    const exported = await buildAccountExport(
      { db },
      { userId: signed.userId, organizationId: memberships[0]!.organizationId },
    );
    assert.equal(exported.content.projects.length, 0);
    assert.equal(exported.counts.projects, 0);
    assert.ok(exported.about.whatThisContains.length > 0);
  });
});
