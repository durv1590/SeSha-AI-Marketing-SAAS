import assert from 'node:assert/strict';
import { test, describe } from 'node:test';
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  LEGACY_PLAN_MAP,
  LIMITS,
  LIMIT_IDS,
  PLANS,
  PLANS_BY_RANK,
  PLAN_DEFINITIONS,
  planChange,
  resolvePlanId,
} from '../src/content/plans';
import { clampLimit, effectiveLimits } from '../src/lib/plans/resolve';
import { MEASURES, TRACKED_METRICS, USAGE_METRICS, WRITABLE_METRICS } from '../src/lib/usage/metrics';
import { checkLimit, limitStatus } from '../src/lib/quota';
import {
  PAST_DUE_GRACE_DAYS,
  SUBSCRIPTION_EVENTS,
  SUBSCRIPTION_STATUSES,
  TRANSITIONS,
  accessFor,
  applyEvent,
  billingStatus,
  nullProvider,
} from '../src/lib/billing/types';
import { FLAG_CATEGORIES, FLAG_DEFINITIONS } from '../src/lib/flags';
import {
  ADMIN_PERMISSIONS,
  ADMIN_NOT_FOUND_MESSAGE,
  STAFF_ROLES,
  adminRefusal,
  checkAdminAccess,
  permissionsFor,
  requiresSudo,
  staffRoleFrom,
} from '../src/lib/admin/auth';
import { SETTING_DEFINITIONS, SETTING_GROUPS } from '../src/lib/admin/settings';
import { ADMIN_NAV, adminRoutes } from '../src/content/admin-nav';
import { TABLES } from '../src/lib/db/types';
import { routes } from '../src/lib/routes';

/**
 * The Phase 7 quality gate, executed.
 *
 * Twelve boxes, one describe block each, named after the brief's line — the same
 * shape as the Phase 3, 4, 5 and 6 gates. A checklist someone ticks by hand is
 * a claim; this file makes each line fail loudly if the behaviour regresses.
 *
 * These are STRUCTURAL assertions about the shape of the delivery. The
 * behaviour behind each one is tested in plans, quota, billing, flags,
 * admin-security and phase7-services; the gate exists so that deleting one of
 * those surfaces cannot pass silently.
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function walk(dir: string, filter = /\.(ts|tsx)$/): string[] {
  const out: string[] = [];
  if (!existsSync(dir)) return out;
  for (const entry of readdirSync(dir)) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) out.push(...walk(full, filter));
    else if (filter.test(entry)) out.push(full);
  }
  return out;
}

const libFiles = walk(path.join(root, 'src', 'lib'));
const appFiles = walk(path.join(root, 'src', 'app'));
const componentFiles = walk(path.join(root, 'src', 'components'));

function read(file: string): string {
  return readFileSync(file, 'utf8');
}

/**
 * A file's CODE, with its comments removed.
 *
 * EVERY SCAN FOR A FORBIDDEN WORD HAS TO USE THIS. These files document their
 * decisions at length — "no method takes a card", "no CVV is stored", "there is
 * no all-systems-operational badge" — and a scan over raw text flags the very
 * sentence that promises the thing it is checking for. That exact mistake cost
 * a debugging cycle in Phase 6, and an assertion that fails on its own
 * documentation gets deleted rather than read.
 */
function code(file: string): string {
  return read(file)
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/^\s*\/\/.*$/gm, '');
}

/** The same, for SQL, where comments start with `--`. */
function sqlCode(file: string): string {
  return read(file).replace(/^\s*--.*$/gm, '');
}

/** A route file exists for this URL path. */
function routeFileExists(urlPath: string): boolean {
  const segments = urlPath.replace(/^\//, '').split('/');
  return appFiles.some((file) => {
    const relative = path.relative(path.join(root, 'src', 'app'), file).split(path.sep);
    if (relative[relative.length - 1] !== 'route.ts') return false;
    // Drop the filename and any (group) segments — they do not appear in a URL.
    const parts = relative.slice(0, -1).filter((part) => !part.startsWith('('));
    return parts.join('/') === segments.join('/');
  });
}

function pageFileExists(urlPath: string): boolean {
  const segments = urlPath.replace(/^\//, '').split('/').filter(Boolean);
  return appFiles.some((file) => {
    const relative = path.relative(path.join(root, 'src', 'app'), file).split(path.sep);
    if (relative[relative.length - 1] !== 'page.tsx') return false;
    const parts = relative.slice(0, -1).filter((part) => !part.startsWith('('));
    return parts.join('/') === segments.join('/');
  });
}

/* -------------------------------------------------------------------------- */
/* 1. Plans                                                                   */
/* -------------------------------------------------------------------------- */

describe('gate 1: configurable plans — Free, Pro, Business, Agency', () => {
  test('exactly the four plans the brief names, each fully defined', () => {
    assert.deepEqual([...PLANS], ['free', 'pro', 'business', 'agency']);
    for (const id of PLANS) {
      const definition = PLAN_DEFINITIONS[id];
      assert.ok(definition.name.length > 0, `${id} has no name`);
      assert.ok(definition.audience.length > 0, `${id} says nothing about who it is for`);
      for (const limitId of LIMIT_IDS) {
        assert.ok(
          limitId in definition.limits,
          `${id} does not declare a value for ${limitId}, so the limit would be undefined`,
        );
      }
    }
  });

  test('PRICING IS NOT HARD-CODED INTO BUSINESS LOGIC', () => {
    // The brief's instruction, enforced mechanically: no plan definition carries
    // a price, and nothing under src/lib reads one. Prices live in the marketing
    // content behind a verification guard, where changing one is a content edit
    // rather than a change to the code that decides what a customer may do.
    const planFile = path.join(root, 'src', 'content', 'plans.ts');
    const planCode = code(planFile);
    assert.ok(
      !/\b(price|amount|currency|inr|usd|paise|cents|monthly_?cost)\b/i.test(planCode),
      'the plan registry declares a money field',
    );
    assert.ok(!/[₹$€£]/.test(planCode), 'the plan registry contains a currency symbol');
    // The PROSE must still explain why, and it uses the word "price" to do it.
    // Scanning the comments for that word would fail the test on the sentence
    // that states the rule — so the code is scanned and the prose is required.
    assert.match(
      read(planFile),
      /a limit is an engineering fact, a price is a commitment/i,
      'nothing in the registry explains why prices live elsewhere',
    );

    // THE DECISION PATH is what must be price-free: the modules that work out
    // what an account may do. Scanning all of src/lib would be a worse test, not
    // a stricter one — the schema validator knows about `priceCurrency` because
    // schema.org does, the crawler parses prices off customers' own pages, and
    // the PDF writer formats money a customer typed. None of those decides an
    // entitlement, and flagging them would train the next person to delete the
    // assertion rather than read it.
    const decisionPath = libFiles.filter((file) =>
      ['plans', 'quota', 'billing', 'usage'].some((area) =>
        file.includes(`${path.sep}lib${path.sep}${area}${path.sep}`),
      ),
    );
    assert.ok(decisionPath.length >= 6, 'the entitlement modules could not be found');

    const offenders: string[] = [];
    for (const file of decisionPath) {
      const text = read(file);
      if (/[₹€£]/.test(text) || /\bpriceInPaise\b|\bamountDue\b|\bmonthlyPrice\b|\bunitAmount\b/.test(text)) {
        offenders.push(path.relative(root, file));
      }
    }
    assert.deepEqual(offenders, [], 'a price reached the code that decides entitlements');
  });

  test('plan comparison is by RANK, so renaming or repricing cannot invert it', () => {
    assert.equal(planChange('free', 'pro'), 'upgrade');
    assert.equal(planChange('agency', 'pro'), 'downgrade');
    assert.equal(planChange('business', 'business'), 'same');
    const ranks = PLANS_BY_RANK.map((plan) => plan.rank);
    assert.deepEqual(ranks, [...ranks].sort((a, b) => a - b), 'ranks are not strictly ordered');
    assert.equal(new Set(ranks).size, ranks.length, 'two plans share a rank');
  });

  test('the earlier plan names still resolve, so no stored row becomes unreadable', () => {
    for (const [legacy, current] of Object.entries(LEGACY_PLAN_MAP)) {
      assert.equal(resolvePlanId(legacy), current, `${legacy} does not resolve`);
    }
    assert.equal(resolvePlanId('not-a-plan'), null);
    assert.equal(resolvePlanId(undefined), null);
  });
});

/* -------------------------------------------------------------------------- */
/* 2. Usage                                                                   */
/* -------------------------------------------------------------------------- */

describe('gate 2: usage tracking — the eight things the brief lists', () => {
  test('all eight are tracked, and each maps to a real metric', () => {
    // The brief names eight things. They map onto NINE metrics, because "audit
    // usage" is recorded as SEO and AEO separately — the brief itself asks for
    // those as two independent limits, and one shared counter could not enforce
    // both. Asserting a bare count of 8 would either be wrong or would pressure
    // the implementation into merging two limits that must stay apart, so the
    // mapping is what is asserted.
    const brief: Readonly<Record<string, readonly string[]>> = {
      'AI requests': ['ai_generation'],
      'Token usage': ['ai_tokens'],
      'Content generation': ['content_item'],
      'Crawl usage': ['crawl_run'],
      'Audit usage': ['seo_audit', 'aeo_audit'],
      'Schema validation': ['schema_validation'],
      Reports: ['report'],
      'API calls': ['api_call'],
    };
    assert.equal(Object.keys(brief).length, 8, 'the brief lists eight things to track');

    const expected = Object.values(brief).flat();
    for (const metric of expected) {
      assert.ok(
        (USAGE_METRICS as readonly string[]).includes(metric),
        `${metric} is not a declared metric`,
      );
      assert.ok(
        (TRACKED_METRICS as readonly string[]).includes(metric),
        `${metric} is declared but not tracked, so nothing would count it`,
      );
    }
    // And nothing is tracked that the brief did not ask for: an extra counter
    // nobody asked for is an extra thing to keep honest.
    assert.deepEqual([...TRACKED_METRICS].sort(), [...expected].sort());
  });

  test('the legacy metric is readable but can never be written again', () => {
    assert.ok(
      (USAGE_METRICS as readonly string[]).includes('audit_run'),
      'the legacy value was removed, which would orphan the rows already carrying it',
    );
    assert.ok(
      !(WRITABLE_METRICS as readonly string[]).includes('audit_run'),
      'the legacy value is still writable, so new rows would use the ambiguous metric',
    );
  });

  test('the usage dashboard exists, for the customer and for staff', () => {
    assert.ok(routeFileExists('/api/usage'), 'no usage endpoint');
    assert.ok(pageFileExists('/app/usage'), 'no usage dashboard page');
    assert.ok(routeFileExists('/api/admin/usage'), 'no platform usage endpoint');
    assert.ok(pageFileExists('/admin/usage'), 'no platform usage page');
  });

  test('the dashboard renders every limit, including the ones at zero', () => {
    // The component is asserted by scripts/render-check.mjs; here the guarantee
    // is that the page cannot be built from a partial list.
    const source = read(path.join(root, 'src', 'components', 'app', 'usage-dashboard.tsx'));
    assert.ok(
      /Not on this plan/.test(source),
      'a limit of zero would render as "0 of 0", which reads as a bug',
    );
    assert.ok(/Unlimited/.test(source), 'an unlimited limit has no wording of its own');
  });
});

/* -------------------------------------------------------------------------- */
/* 3. Quotas                                                                  */
/* -------------------------------------------------------------------------- */

describe('gate 3: quotas — eleven configurable limits, all enforced', () => {
  test('exactly the eleven limits the brief lists', () => {
    assert.deepEqual(
      [...LIMIT_IDS],
      [
        'ai_requests',
        'tokens',
        'content_generations',
        'website_crawls',
        'seo_audits',
        'aeo_audits',
        'schema_validations',
        'projects',
        'team_members',
        'reports',
        'automations',
      ],
    );
  });

  test('every limit knows how it is measured — none is decorative', () => {
    for (const id of LIMIT_IDS) {
      const measure = MEASURES[id];
      assert.ok(measure, `${id} has no measurement, so it could never be enforced`);
      assert.equal(
        measure.kind,
        LIMITS[id].kind,
        `${id} is declared ${LIMITS[id].kind} but measured as ${measure.kind}`,
      );
      if (measure.kind === 'per_period') {
        assert.ok(measure.metrics.length > 0, `${id} counts no metrics`);
      } else {
        assert.ok(measure.countable.length > 0, `${id} counts no rows`);
      }
    }
  });

  test('the three zero-like states are distinguishable, everywhere', () => {
    const limits = effectiveLimits('free');
    // `null` is unlimited; `0` is not included; a number is a ceiling. A quota
    // check that conflated them would refuse paying customers or let free ones
    // through.
    const unlimited = limitStatus({ ...limits.projects, value: null }, 5);
    assert.equal(unlimited.exhausted, false);
    assert.equal(unlimited.percentUsed, null);

    const notIncluded = limitStatus({ ...limits.projects, value: 0 }, 0);
    assert.equal(notIncluded.exhausted, true);

    const unused = limitStatus({ ...limits.projects, value: 10 }, 0);
    assert.equal(unused.exhausted, false);
    assert.equal(unused.remaining, 10);
  });

  test('a refusal explains itself, and never tells someone to wait for nothing', () => {
    const limits = effectiveLimits('free');
    const at = (used: number) => ({
      plan: 'free' as const,
      limits,
      used,
      periodStart: '2026-09-01',
      now: new Date('2026-09-11T00:00:00Z'),
    });

    // AN ABSOLUTE LIMIT MUST NOT PROMISE A RESET. Nothing resets; the customer
    // has to delete something or upgrade, and "your allowance resets in 20
    // days" would be a straightforward lie.
    const atCapacity = checkLimit('projects', at(1));
    assert.equal(atCapacity.allowed, false, 'a free account at its project limit was allowed another');
    if (!atCapacity.allowed) {
      assert.equal(atCapacity.reason, 'at_capacity');
      assert.ok(
        !/resets?\b/i.test(atCapacity.message),
        `an at-capacity refusal mentions a reset: ${atCapacity.message}`,
      );
      assert.match(atCapacity.message, /\d/, 'the refusal names no figure');
    }

    // A SPENT MONTHLY ALLOWANCE does say when it returns, because waiting works.
    const exhausted = checkLimit('ai_requests', at(25));
    assert.equal(exhausted.allowed, false);
    if (!exhausted.allowed) {
      assert.equal(exhausted.reason, 'period_exhausted');
      assert.match(exhausted.message, /resets?\b/i, 'a spent allowance does not say when it returns');
    }

    // A REQUEST BIGGER THAN THE WHOLE MONTH is a third case, and telling that
    // customer to wait would be useless advice.
    const unreachable = checkLimit('ai_requests', at(0), 500);
    assert.equal(unreachable.allowed, false);
    if (!unreachable.allowed) {
      assert.ok(
        !/resets? (?:today|tomorrow|in \d)/i.test(unreachable.message),
        `an impossible request was told to wait: ${unreachable.message}`,
      );
      assert.match(unreachable.message, /whole month|Narrow the scope/i);
    }

    // A limit of zero is "not included", not "used up".
    const business = effectiveLimits('business');
    void business;
    const notIncluded = checkLimit('automations', {
      plan: 'free',
      limits: { ...limits, automations: { ...limits.automations, value: 0 } },
      used: 0,
      periodStart: '2026-09-01',
      now: new Date('2026-09-11T00:00:00Z'),
    });
    assert.equal(notIncluded.allowed, false);
    if (!notIncluded.allowed) assert.equal(notIncluded.reason, 'not_included');
  });

  test('a stored override that is not a limit at all is refused', () => {
    // `undefined` means "ignore this row and use the plan", so anything that is
    // not a number is dropped rather than guessed at.
    assert.equal(clampLimit('40' as unknown), undefined);
    assert.equal(clampLimit(true as unknown), undefined);
    assert.equal(clampLimit(Number.NaN), undefined);
    assert.equal(clampLimit(Number.POSITIVE_INFINITY), undefined);
    assert.equal(clampLimit(-1), undefined);

    // null is unlimited and 0 is not-included: both are meaningful, neither is
    // a mistake.
    assert.equal(clampLimit(null), null);
    assert.equal(clampLimit(0), 0);

    // A FRACTION IS FLOORED, NOT REJECTED, and the direction matters. Rejecting
    // 1.5 would fall back to the plan's own value — which may be HIGHER than the
    // override someone set to restrict this account. Flooring can only ever give
    // less than was asked for, so a malformed row cannot widen an entitlement.
    assert.equal(clampLimit(1.5), 1);
    assert.equal(clampLimit(0.9), 0);
  });

  test('the override control exists, and demands a reason', () => {
    assert.ok(routeFileExists('/api/admin/limits'), 'no limit override endpoint');
    const source = read(path.join(root, 'src', 'app', 'api', 'admin', 'limits', 'route.ts'));
    assert.match(source, /reason/i, 'the endpoint does not take a reason');
    assert.match(
      source,
      /Say why/i,
      'an override can be set without an explanation, which is how one becomes permanent',
    );
  });
});

/* -------------------------------------------------------------------------- */
/* 4. Billing abstraction                                                     */
/* -------------------------------------------------------------------------- */

describe('gate 4: a payment-provider abstraction', () => {
  test('the provider is an interface with a working no-op implementation', () => {
    assert.equal(nullProvider.configured, false);
    assert.equal(typeof nullProvider.createCheckout, 'function');
    assert.equal(typeof nullProvider.changePlan, 'function');
    assert.equal(typeof nullProvider.cancel, 'function');
    assert.equal(typeof nullProvider.verifyWebhook, 'function');
    // THE LINE THAT MAKES THE WEBHOOK SAFE TODAY: with no provider connected,
    // no signature can ever verify, so no webhook is ever applied.
    assert.equal(nullProvider.verifyWebhook('{}', 'anything'), false);
    assert.equal(nullProvider.verifyWebhook('', ''), false);
  });

  test('the product says plainly that nothing can be charged', () => {
    const status = billingStatus();
    assert.equal(status.configured, false);
    assert.match(status.message, /nothing can be charged/i);
  });

  test('NO PROVIDER METHOD COULD ACCEPT A CARD', () => {
    const file = path.join(root, 'src', 'lib', 'billing', 'types.ts');
    assert.ok(
      !/\b(cardNumber|pan|cvv|cvc|cardholderName|expiryDate)\b/i.test(code(file)),
      'a billing type names a chargeable card field',
    );
    // And the documentation that explains WHY is still there. The prose is part
    // of the guarantee: a reader who does not know the rule will add the field.
    assert.match(read(file), /never/i);
  });

  test('no screen anywhere collects payment details', () => {
    const offenders: string[] = [];
    for (const file of [...componentFiles, ...appFiles.filter((f) => f.endsWith('.tsx'))]) {
      const text = read(file);
      if (/name=["'](?:cardNumber|cvv|cvc|cardnumber|card_number)["']/i.test(text)) {
        offenders.push(path.relative(root, file));
      }
      if (/autoComplete=["']cc-(?:number|csc|exp)["']/i.test(text)) {
        offenders.push(path.relative(root, file));
      }
    }
    assert.deepEqual(offenders, [], 'a card field was rendered');
  });
});

/* -------------------------------------------------------------------------- */
/* 5. Subscription state                                                      */
/* -------------------------------------------------------------------------- */

describe('gate 5: subscription state — the seven things the brief lists', () => {
  test('every lifecycle event the brief names has a transition', () => {
    // Trial, upgrade, downgrade, cancellation, renewal, failed payment, status.
    for (const event of ['trial_started', 'plan_changed', 'cancellation_requested', 'renewed', 'payment_failed'] as const) {
      assert.ok(
        (SUBSCRIPTION_EVENTS as readonly string[]).includes(event),
        `${event} is not a declared event`,
      );
      const reachable = SUBSCRIPTION_STATUSES.some((status) => TRANSITIONS[status][event]);
      assert.ok(reachable, `${event} can never be applied from any state`);
    }
  });

  test('every status is reachable, and no transition leaves a non-status', () => {
    const reached = new Set<string>(['incomplete']);
    for (const status of SUBSCRIPTION_STATUSES) {
      for (const next of Object.values(TRANSITIONS[status])) {
        assert.ok(
          next !== undefined && (SUBSCRIPTION_STATUSES as readonly string[]).includes(next),
          `${status} transitions to "${String(next)}", which is not a status`,
        );
        if (next) reached.add(next);
      }
    }
    for (const status of SUBSCRIPTION_STATUSES) {
      assert.ok(reached.has(status), `${status} is unreachable`);
    }
  });

  test('an out-of-order webhook is recorded and ignored, never an error', () => {
    // Providers retry and deliver out of order. Throwing would let a retried
    // success break a live subscription.
    const outcome = applyEvent('canceled', 'payment_succeeded');
    assert.equal(outcome.changed, false);
    assert.ok(outcome.note && outcome.note.length > 0, 'the reason it was ignored is not recorded');
  });

  test('READ ACCESS IS NEVER REVOKED, in any state', () => {
    for (const status of SUBSCRIPTION_STATUSES) {
      const access = accessFor(status, { pastDueSince: null, now: new Date('2026-09-11T00:00:00Z') });
      assert.equal(
        access.readable,
        true,
        `a ${status} subscription cannot read its own work, which would hold a customer's data hostage`,
      );
    }
  });

  test('a failed payment has a grace window, and it does not restart', () => {
    assert.ok(PAST_DUE_GRACE_DAYS >= 1, 'a failed payment locks the account the same day');
    const failedAt = new Date('2026-09-01T00:00:00Z');
    const inside = accessFor('past_due', {
      pastDueSince: failedAt,
      now: new Date('2026-09-05T00:00:00Z'),
    });
    assert.equal(inside.writable, true, 'a card that failed four days ago already blocks work');
    const outside = accessFor('past_due', {
      pastDueSince: failedAt,
      now: new Date('2026-09-20T00:00:00Z'),
    });
    assert.equal(outside.writable, false, 'the grace window never closes');
    assert.equal(outside.readable, true);
  });

  test('the customer can see and change their own subscription', () => {
    assert.ok(routeFileExists('/api/billing'), 'no billing endpoint');
    assert.ok(routeFileExists('/api/billing/webhook'), 'no webhook endpoint');
    assert.ok(pageFileExists('/app/settings/billing'), 'no billing screen');
  });

  test('the webhook verifies the signature against the RAW body, first', () => {
    const file = path.join(root, 'src', 'app', 'api', 'billing', 'webhook', 'route.ts');
    const source = code(file);
    const rawRead = source.indexOf('request.text()');
    const verify = source.indexOf('verifyWebhook');
    const parse = source.indexOf('JSON.parse');
    assert.ok(rawRead > -1, 'the body is not read as raw text');
    assert.ok(verify > -1 && verify > rawRead, 'the signature is not verified after reading the body');
    assert.ok(
      parse > verify,
      'THE BODY IS PARSED BEFORE THE SIGNATURE IS VERIFIED — re-serialising changes the bytes the provider signed',
    );
    assert.ok(
      !/readJson\(/.test(source),
      'the webhook uses readJson, which consumes the body and makes verification impossible',
    );
    // The doc comment that explains all of this must survive too: the ordering
    // above is load-bearing and invisible, so the next reader needs the reason.
    assert.match(read(file), /signs the bytes|SIGNATURE IS VERIFIED FIRST/i);
  });
});

/* -------------------------------------------------------------------------- */
/* 6. Admin panel                                                             */
/* -------------------------------------------------------------------------- */

describe('gate 6: the admin panel — thirteen surfaces and seven controls', () => {
  test('every dashboard surface the brief lists is reachable', () => {
    // Users, Businesses, Projects, Subscriptions, Usage, AI requests, Errors,
    // System health, Reports, Feedback, Crawl jobs, Schema jobs, Security.
    const surfaces: readonly { readonly name: string; readonly permission: string }[] = [
      { name: 'Users', permission: 'admin:users:read' },
      { name: 'Businesses', permission: 'admin:businesses:read' },
      { name: 'Projects', permission: 'admin:projects:read' },
      { name: 'Subscriptions', permission: 'admin:subscriptions:read' },
      { name: 'Usage', permission: 'admin:usage:read' },
      { name: 'AI requests', permission: 'admin:ai:read' },
      { name: 'Errors', permission: 'admin:errors:read' },
      { name: 'System health', permission: 'admin:health:read' },
      { name: 'Reports', permission: 'admin:reports:read' },
      { name: 'Feedback', permission: 'admin:feedback:read' },
      { name: 'Crawl and schema jobs', permission: 'admin:jobs:read' },
      { name: 'Security events', permission: 'admin:security:read' },
      { name: 'Audit trail', permission: 'admin:audit:read' },
    ];
    assert.equal(surfaces.length, 13, 'the brief lists thirteen surfaces');
    for (const surface of surfaces) {
      assert.ok(
        (ADMIN_PERMISSIONS as readonly string[]).includes(surface.permission),
        `${surface.name} has no permission of its own`,
      );
    }
  });

  test('every control the brief lists exists', () => {
    // Plans, Limits, Templates, Prompts, Feature flags, Validator config,
    // System config.
    for (const permission of [
      'admin:plans:write',
      'admin:limits:write',
      'admin:templates:write',
      'admin:prompts:write',
      'admin:flags:write',
      'admin:validator:write',
      'admin:system:write',
    ] as const) {
      assert.ok(
        (ADMIN_PERMISSIONS as readonly string[]).includes(permission),
        `${permission} is not declared`,
      );
    }
    // Templates, prompts and validator configuration are settings groups;
    // plans, limits and flags have endpoints of their own.
    assert.deepEqual([...SETTING_GROUPS], ['prompts', 'templates', 'validator', 'system']);
    for (const group of SETTING_GROUPS) {
      assert.ok(
        SETTING_DEFINITIONS.some((definition) => definition.group === group),
        `the "${group}" control has no settings, so the screen would be empty`,
      );
    }
  });

  test('every admin screen has both a page and an endpoint behind it', () => {
    for (const route of adminRoutes) {
      assert.ok(pageFileExists(route), `${route} is in the navigation but has no page`);
    }
    for (const route of [
      '/api/admin',
      '/api/admin/organizations',
      '/api/admin/limits',
      '/api/admin/plans',
      '/api/admin/flags',
      '/api/admin/settings',
      '/api/admin/staff',
      '/api/admin/jobs',
      '/api/admin/errors',
      '/api/admin/feedback',
      '/api/admin/security',
      '/api/admin/audit',
      '/api/admin/usage',
      '/api/admin/health',
    ]) {
      assert.ok(routeFileExists(route), `${route} is missing`);
    }
  });

  test('the feedback surface has a way in, or it is a screen of an empty table', () => {
    assert.ok(routeFileExists('/api/feedback'), 'customers cannot submit feedback');
  });

  test('nothing in the panel reports a figure the deployment does not measure', () => {
    const file = path.join(root, 'src', 'lib', 'admin', 'service.ts');
    assert.match(read(file), /notMeasured/, 'health reports no list of what it cannot measure');

    // Scanned over CODE only. The file's own doc comment says there is no
    // "all systems operational" badge, and the notMeasured list names uptime as
    // something it will not invent — both would trip a scan over raw text.
    const source = code(file);
    assert.ok(!/\buptime\s*[:=]\s*\d/i.test(source), 'an uptime figure is reported');
    assert.ok(
      !/'[^']*all systems operational[^']*'/i.test(source),
      'a green badge that means nothing is worse than no badge',
    );
    // The notMeasured list is not empty, and it names the things most likely to
    // be asked for.
    const measured = /notMeasured: \[([\s\S]*?)\]/.exec(source)?.[1] ?? '';
    assert.match(measured, /Uptime/i, 'uptime is not declared as unmeasured');
    assert.match(measured, /latency/i, 'latency is not declared as unmeasured');
  });
});

/* -------------------------------------------------------------------------- */
/* 7. Admin security                                                          */
/* -------------------------------------------------------------------------- */

describe('gate 7: admin security — the six measures the brief lists', () => {
  test('1. admin authorization is SEPARATE from tenant authorization', () => {
    assert.ok(
      TABLES.includes('platform_staff'),
      'platform access is not its own table, so it is a role on a membership',
    );
    // The staff context deliberately carries no organizationId: a cross-tenant
    // read scoped to the staff member's own organization silently returns
    // nothing and looks like it worked.
    const source = read(path.join(root, 'src', 'lib', 'admin', 'auth.ts'));
    const contextBlock = /export interface StaffContext \{([\s\S]*?)\n\}/.exec(source)?.[1] ?? '';
    assert.ok(contextBlock.length > 0, 'StaffContext could not be found');
    assert.ok(
      !/organizationId/.test(contextBlock),
      'StaffContext carries an organizationId, which invites a cross-tenant read to be scoped by accident',
    );
  });

  test('2. authentication is re-confirmed for every change', () => {
    for (const permission of ADMIN_PERMISSIONS) {
      if (permission.endsWith(':write')) {
        assert.ok(requiresSudo(permission), `${permission} can be exercised on a stale sign-in`);
      }
    }
    // Reading the audit trail also requires it: reviewing who did what is
    // sensitive enough to be worth a password.
    assert.ok(requiresSudo('admin:audit:read'));
  });

  test('3. roles actually restrict — support cannot change entitlements or configuration', () => {
    const support = permissionsFor('support');
    assert.ok(support.length > 0);

    // Support DOES hold exactly one write: moving a piece of feedback along its
    // triage states. That is the job, it touches a status field on a note the
    // customer wrote in order to be read, and it changes nothing about what any
    // account may do. Every other write is withheld, and that is the invariant
    // worth asserting — "support holds no :write at all" would be a neater
    // sentence and a false one.
    const supportWrites = support.filter((permission) => permission.endsWith(':write'));
    assert.deepEqual(supportWrites, ['admin:feedback:write']);

    for (const permission of [
      'admin:plans:write',
      'admin:limits:write',
      'admin:subscriptions:write',
      'admin:flags:write',
      'admin:system:write',
      'admin:prompts:write',
      'admin:templates:write',
      'admin:validator:write',
      'admin:staff:write',
    ] as const) {
      assert.ok(!support.includes(permission), `support holds ${permission}`);
    }
    assert.ok(!support.includes('admin:audit:read'), 'support can review its own activity');
    assert.ok(!support.includes('admin:staff:read'), 'support can enumerate who has platform access');

    const owner = permissionsFor('platform_owner');
    for (const permission of ADMIN_PERMISSIONS) {
      assert.ok(owner.includes(permission), `the platform owner cannot ${permission}`);
    }
    // The roles are strictly nested, so a promotion never takes anything away.
    const engineer = permissionsFor('engineer');
    for (const permission of support) {
      assert.ok(engineer.includes(permission), `promotion to engineer loses ${permission}`);
    }
  });

  test('4. every admin action is recorded, INCLUDING every read', () => {
    assert.ok(TABLES.includes('admin_actions'), 'there is no admin audit table');
    const source = code(path.join(root, 'src', 'lib', 'admin', 'service.ts'));

    // Split the file at every top-level `export` so each function's body is
    // bounded by the next declaration rather than by the first `\n}`, which a
    // nested object literal ends early.
    const chunks = source.split(/\nexport (?=async function|function|interface|const)/);
    const functions = chunks
      .map((chunk) => ({ name: /^(?:async )?function (\w+)\(/.exec(chunk)?.[1] ?? '', body: chunk }))
      .filter((entry) => entry.name.length > 0);

    assert.ok(functions.length >= 15, `the admin service has only ${functions.length} functions`);

    // The two deliberate exceptions, each for a stated reason:
    //  · staffFor RESOLVES the caller — auditing it would record a row for every
    //    request before anyone has asked to do anything;
    //  · settingValue serves the rest of the product, needs no permission, and
    //    returning a banner string is not a staff action.
    const exempt = new Set(['staffFor', 'settingValue', 'limitRowsFor']);
    const unaudited = functions
      .filter((entry) => !exempt.has(entry.name) && !/withAudit\(/.test(entry.body))
      .map((entry) => entry.name);
    assert.deepEqual(unaudited, [], 'an admin service function does not record what it did');

    // Reads are audited, not only writes — the whole point for a cross-tenant
    // panel, where looking IS the sensitive act.
    const reads = functions.filter((entry) => /kind: 'read'/.test(entry.body));
    assert.ok(reads.length >= 8, `only ${reads.length} reads are audited`);
    // And a refused attempt is recorded as carefully as a successful one.
    assert.match(source, /'denied'/, 'a denial is not recorded');
  });

  test('5. admin endpoints are rate limited', () => {
    const offenders: string[] = [];
    for (const file of appFiles) {
      if (!file.includes(`${path.sep}admin${path.sep}`)) continue;
      if (!file.endsWith('route.ts')) continue;
      const text = read(file);
      if (!/enforceRateLimit\(/.test(text)) offenders.push(path.relative(root, file));
    }
    assert.deepEqual(offenders, [], 'an admin endpoint has no rate limit');
  });

  test('6. session controls — the staff row is read on EVERY request', () => {
    const guard = read(path.join(root, 'src', 'lib', 'api', 'admin-guard.ts'));
    assert.match(guard, /staffFor\(/, 'the guard does not resolve the staff row');
    assert.match(guard, /isSudo\(/, 'the sudo window is not checked from the session record');
    // A revoked row grants nothing, immediately, rather than when a thirty-day
    // session happens to expire.
    assert.equal(staffRoleFrom({ role: 'engineer', revokedAt: new Date() }), null);
    assert.equal(staffRoleFrom({ role: 'engineer', revokedAt: null }), 'engineer');
    assert.equal(staffRoleFrom(null), null);
  });

  test('ADMIN APIS ARE NEVER EXPOSED TO NORMAL USERS — 404, not 403', () => {
    assert.equal(ADMIN_NOT_FOUND_MESSAGE, 'Not found.');
    const refused = checkAdminAccess(null, 'admin:users:read');
    assert.equal(refused.ok, false);
    if (!refused.ok) {
      assert.equal(refused.needsSudo, false);
      // Nothing in the message admits that an admin API exists.
      assert.ok(
        !/admin|permission|staff|forbidden/i.test(refused.message),
        `a refusal discloses the panel: ${refused.message}`,
      );
    }

    // The MAPPING is a pure function so it can be asserted directly, which is
    // what tests/admin-security.test.ts does. Here the gate asserts the guard
    // still delegates to it — the mapping being right is worth nothing if the
    // request handler has gone back to deciding for itself.
    const guard = code(path.join(root, 'src', 'lib', 'api', 'admin-guard.ts'));
    assert.match(guard, /adminRefusal\(access\)/, 'the guard decides its own refusal status');
    assert.match(guard, /fail\(404, ADMIN_NOT_FOUND_MESSAGE\)/, 'an absent session is not a 404');
    // No hand-rolled 403 anywhere in the guard: the only one comes from the
    // mapping, via refusal.status.
    assert.ok(!/fail\(403/.test(guard), 'the guard writes a 403 of its own');

    const refusals = [
      adminRefusal({ ok: false, needsSudo: false, message: 'That needs the Engineer role.' }),
      adminRefusal({ ok: false, needsSudo: true, message: 'Confirm your password again.' }),
    ];
    assert.deepEqual(
      refusals.map((refusal) => refusal.status),
      [404, 403],
      'a wrong-role refusal and a stale sign-in are not answered differently',
    );
    assert.equal(refusals[0]?.message, ADMIN_NOT_FOUND_MESSAGE, 'the 404 body leaks the reason');

    // Every admin route uses the admin guard, not the tenant one.
    const offenders: string[] = [];
    for (const file of appFiles) {
      if (!file.includes(`${path.sep}admin${path.sep}`) || !file.endsWith('route.ts')) continue;
      const text = read(file);
      if (!/requireStaff\(/.test(text)) offenders.push(path.relative(root, file));
      if (/\brequireAuth\(/.test(text)) {
        offenders.push(`${path.relative(root, file)} (uses the tenant guard)`);
      }
    }
    assert.deepEqual(offenders, [], 'an admin route is not behind the admin guard');
  });

  test('the admin panel is absent from every public surface', () => {
    for (const route of routes) {
      assert.ok(!route.path.startsWith('/admin'), `${route.path} is in the public route registry`);
    }
    for (const route of adminRoutes) {
      assert.ok(route.startsWith('/admin'), `${route} is registered as an admin route`);
    }
    // And the customer's own navigation must not mention it.
    const appNav = read(path.join(root, 'src', 'content', 'app-nav.ts'));
    assert.ok(!/\/admin/.test(appNav), 'the customer sidebar links to the admin panel');
  });

  test('the panel reads metadata, never customer content', () => {
    const repositories = read(path.join(root, 'src', 'lib', 'db', 'repositories.ts'));
    const block = /export interface AdminReadRepository \{([\s\S]*?)\n\}/.exec(repositories)?.[1] ?? '';
    assert.ok(block.length > 0, 'AdminReadRepository could not be found');
    // No method returns a lead, an article, a report body or a message.
    assert.ok(
      !/\b(leadBody|articleBody|reportBody|messageBody|listLeads|listContent|listMessages)\b/.test(block),
      'the admin read interface can reach customer content',
    );
  });
});

/* -------------------------------------------------------------------------- */
/* 8. Feature flags                                                           */
/* -------------------------------------------------------------------------- */

describe('gate 8: feature flags — the five categories the brief lists', () => {
  test('all five categories exist and each has at least one flag', () => {
    assert.equal(FLAG_CATEGORIES.length, 5, 'the brief lists five categories');
    for (const category of FLAG_CATEGORIES) {
      assert.ok(
        FLAG_DEFINITIONS.some((definition) => definition.category === category),
        `the "${category}" category has no flags, so it is a heading with nothing under it`,
      );
    }
  });

  test('flags are a fixed registry, not free-form strings', () => {
    const source = read(path.join(root, 'src', 'lib', 'flags', 'index.ts'));
    assert.match(source, /export function isFlagKey/, 'an unknown key cannot be rejected');
    const service = read(path.join(root, 'src', 'lib', 'admin', 'service.ts'));
    assert.match(
      service,
      /if \(!isFlagKey\(input\.key\)\)/,
      'a rule can be stored for a flag the product does not declare',
    );
  });

  test('every flag says what turning it on does, and declares a default', () => {
    for (const definition of FLAG_DEFINITIONS) {
      assert.ok(definition.label.length > 0, `${definition.key} has no label`);
      assert.ok(
        definition.description.length > 20,
        `${definition.key} does not explain itself to whoever is on call`,
      );
      assert.equal(typeof definition.defaultValue, 'boolean');
    }
  });

  test('the flag control exists', () => {
    assert.ok(routeFileExists('/api/admin/flags'));
    assert.ok(pageFileExists('/admin/flags'));
  });
});

/* -------------------------------------------------------------------------- */
/* 9. Audit logs                                                              */
/* -------------------------------------------------------------------------- */

describe('gate 9: audit logs', () => {
  test('the admin trail is separate from the tenant one', () => {
    assert.ok(TABLES.includes('admin_actions'));
    assert.ok(TABLES.includes('audit_log'), 'the tenant audit log is gone');
    // Two tables, not one. Staff activity must not be lost in the noise of
    // ordinary customer sign-ins, which is what a shared table would mean.
    assert.notEqual('audit_log', 'admin_actions');
  });

  test('the audit table does not cascade away with an organization', () => {
    const migration = read(
      path.join(root, 'db', 'migrations', '0007_subscriptions_usage_admin.sql'),
    );
    const table =
      /CREATE TABLE (?:IF NOT EXISTS )?admin_actions \(([\s\S]*?)\n\);/.exec(migration)?.[1] ?? '';
    assert.ok(table.length > 0, 'the admin_actions table could not be found in the migration');
    assert.ok(
      !/ON DELETE CASCADE/.test(table),
      'deleting an organization would delete the record of what staff did to it',
    );
  });

  test('an admin action records the outcome, not just the attempt', () => {
    const migration = read(
      path.join(root, 'db', 'migrations', '0007_subscriptions_usage_admin.sql'),
    );
    assert.match(migration, /outcome/, 'the outcome is not stored');
    assert.match(migration, /'denied'/, 'a refused action cannot be recorded');
  });

  test('the audit trail is readable, and reading it is itself recorded', () => {
    assert.ok(routeFileExists('/api/admin/audit'));
    assert.ok(pageFileExists('/admin/audit'));
    const source = read(path.join(root, 'src', 'lib', 'admin', 'service.ts'));
    const block = /export async function listAdminActions\(([\s\S]*?)\n\}/.exec(source)?.[1] ?? '';
    assert.match(block, /withAudit\(/, 'reading the audit trail is not recorded');
  });

  test('the audit log is not a second copy of the customer data', () => {
    const types = read(path.join(root, 'src', 'lib', 'db', 'types.ts'));
    assert.match(
      types,
      /Never customer content/,
      'nothing documents what may not go into an audit record',
    );
  });
});

/* -------------------------------------------------------------------------- */
/* 10. Tests                                                                  */
/* -------------------------------------------------------------------------- */

describe('gate 10: tests', () => {
  test('every Phase 7 concern has a suite of its own', () => {
    for (const file of [
      'plans.test.ts',
      'quota.test.ts',
      'billing.test.ts',
      'flags.test.ts',
      'admin-security.test.ts',
      'phase7-services.test.ts',
      'phase7-gate.test.ts',
    ]) {
      assert.ok(existsSync(path.join(root, 'tests', file)), `tests/${file} is missing`);
    }
  });

  test('the render harness covers the Phase 7 screens', () => {
    // .tsx files are not type-checked offline, so these render assertions are
    // the only automated check on the new UI. Losing them would be worse than
    // never having had them, because the gate would still pass.
    const harness = read(path.join(root, 'scripts', 'render-check.mjs'));
    for (const marker of [
      'usage-dashboard.tsx',
      'billing-panel.tsx',
      'admin-shell.tsx',
      'health-checks.tsx',
    ]) {
      assert.ok(harness.includes(marker), `${marker} is not rendered by the harness`);
    }
  });

  test('the quota and billing suites would notice if enforcement were removed', () => {
    // A mutation check in miniature: the assertions must be about refusal, not
    // merely about a function returning.
    const quota = read(path.join(root, 'tests', 'quota.test.ts'));
    assert.match(
      quota,
      /isDenied\(|allowed,\s*false|allowed\)/,
      'no quota test asserts on whether a request was allowed',
    );
    assert.match(
      quota,
      /allowed a request at its ceiling|at its ceiling/,
      'no quota test walks the plans and checks each ceiling actually refuses',
    );
    const billing = read(path.join(root, 'tests', 'billing.test.ts'));
    assert.match(billing, /writable,\s*false/, 'no billing test asserts that writing is blocked');
    assert.match(billing, /readable,\s*true/, 'no billing test asserts that reading survives');
  });
});

/* -------------------------------------------------------------------------- */
/* 11. No payment secrets exposed                                             */
/* -------------------------------------------------------------------------- */

describe('gate 11: no payment secrets exposed', () => {
  test('NO COLUMN ANYWHERE COULD HOLD A CARD', () => {
    const file = path.join(root, 'db', 'schema.sql');
    // Over the DDL only. The schema's own comment explains at length that no
    // card, number, token or CVV is stored — scanning that sentence for the word
    // "CVV" would fail the test on the documentation that proves the point.
    // COLUMN NAMES, not arbitrary text. The schema carries SQL `COMMENT ON`
    // statements — real DDL, not `--` lines — and one of them says in so many
    // words that there is no column for a card number, token or CVV. Scanning
    // the whole DDL would fail on that sentence; scanning the identifiers at the
    // start of each column definition is the actual claim being made.
    const ddl = sqlCode(file).replace(/COMMENT ON[^;]*;/gi, '');
    const columnNames = [...ddl.matchAll(/^\s{2,}(?:ADD COLUMN (?:IF NOT EXISTS )?)?([a-z_][a-z0-9_]*)\s+[a-z]/gim)]
      .map((match) => (match[1] ?? '').toLowerCase());
    assert.ok(columnNames.length > 100, `only ${columnNames.length} columns were found to check`);

    const forbidden = /^(card_number|cardnumber|cvv|cvc|pan|card_pan|full_card|cardholder_name|card_token)$/;
    const offenders = columnNames.filter((name) => forbidden.test(name));
    assert.deepEqual(offenders, [], 'a column name suggests card storage');

    // The four display fields that DO exist are named so they cannot be mistaken
    // for the real thing, and there are exactly four.
    // Taken from the COLUMN NAMES collected above, not from the DDL text: the
    // subscription-event CHECK constraint lists `payment_failed` and
    // `payment_succeeded` as enum values, and a text scan reads those as columns.
    const paymentColumns = columnNames
      .filter((name) => name.startsWith('payment_'))
      .map((name) => name.slice('payment_'.length));
    assert.deepEqual(
      [...new Set(paymentColumns)].sort(),
      ['brand', 'expiry_month', 'expiry_year', 'last4'],
      'the payment columns are not exactly the four a screen needs to identify a card',
    );
    // And the explanation is still in the file for whoever adds the next column.
    assert.match(read(file), /no CVV|never.{0,40}card/i);
  });

  test('no secret is read outside the one module that owns it', () => {
    const offenders: string[] = [];
    for (const file of [...libFiles, ...appFiles, ...componentFiles]) {
      const relative = path.relative(root, file);
      const text = read(file);
      for (const match of text.matchAll(/process\.env\.([A-Z0-9_]+)/g)) {
        const name = match[1] ?? '';
        if (!/SECRET|KEY|TOKEN|PASSWORD|WEBHOOK/.test(name)) continue;
        // The modules that legitimately own a secret.
        if (
          relative.includes('lib/ai/provider') ||
          relative.includes('lib/auth/') ||
          relative.includes('lib/config') ||
          relative.includes('lib/env')
        ) {
          continue;
        }
        offenders.push(`${relative}: ${match[0]}`);
      }
    }
    assert.deepEqual(offenders, [], 'a secret is read outside the module that owns it');
  });

  test('no component — client or server — can see a secret', () => {
    const offenders: string[] = [];
    for (const file of componentFiles) {
      const text = read(file);
      if (/process\.env\.(?!NEXT_PUBLIC_)/.test(text)) offenders.push(path.relative(root, file));
    }
    assert.deepEqual(offenders, [], 'a component reads a server environment variable');
  });

  test('the webhook tells a forger nothing', () => {
    const source = read(path.join(root, 'src', 'app', 'api', 'billing', 'webhook', 'route.ts'));
    // A 401 would confirm the endpoint is live and that only the signature stood
    // in the way; a 500 would suggest a bug had been found.
    assert.ok(!/fail\(401/.test(source), 'a bad signature is answered with 401');
    assert.match(source, /status:\s*202/, 'a bad signature is not answered blandly');
  });

  test('the billing view returns display metadata only', () => {
    const source = code(path.join(root, 'src', 'lib', 'billing', 'service.ts'));
    // Bounded by the braces, not by the first `| null` — `expiryMonth: number |
    // null` contains one, which would cut the block off halfway through.
    const block = /readonly paymentMethod: \{([\s\S]*?)\n  \}/.exec(source)?.[1] ?? '';
    assert.ok(block.length > 0, 'the payment method shape could not be found');
    const fields = [...block.matchAll(/readonly (\w+):/g)].map((m) => m[1]);
    assert.deepEqual(
      fields,
      ['brand', 'last4', 'expiryMonth', 'expiryYear'],
      'the payment method carries a field beyond what a screen needs to identify a card',
    );
  });
});

/* -------------------------------------------------------------------------- */
/* 12. Production build                                                       */
/* -------------------------------------------------------------------------- */

describe('gate 12: production build', () => {
  test('the checked-in schema matches the migrations that build it', () => {
    // `scripts/build-schema.mjs --check` is the authority and runs in `npm run
    // verify`. This asserts the artefacts it compares both exist and agree on
    // the table count, so a forgotten rebuild fails here too.
    const schema = sqlCode(path.join(root, 'db', 'schema.sql'));
    const created = [...schema.matchAll(/CREATE TABLE (?:IF NOT EXISTS )?(\w+)/g)].map(
      (match) => match[1],
    );
    assert.equal(
      created.length,
      TABLES.length,
      `the schema creates ${created.length} tables and the code declares ${TABLES.length}`,
    );
    for (const table of TABLES) {
      assert.ok(created.includes(table), `${table} is declared in code but not created in SQL`);
    }
  });

  test('the migration is forward-only and documents its decisions', () => {
    const migration = read(
      path.join(root, 'db', 'migrations', '0007_subscriptions_usage_admin.sql'),
    );
    assert.ok(!/DROP TABLE/i.test(migration), 'the migration drops a table');
    assert.ok(
      !/DROP COLUMN/i.test(migration),
      'the migration drops a column, which is not reversible on live data',
    );
    assert.ok(migration.length > 4_000, 'the migration carries no explanation of its decisions');
  });

  test('the plan rename widens before it rewrites, and narrows only after', () => {
    const migration = read(
      path.join(root, 'db', 'migrations', '0007_subscriptions_usage_admin.sql'),
    );
    // Narrowing a CHECK constraint before the rows are updated fails on the
    // existing data; the three steps have to be in this order.
    const widen = migration.search(/starter[\s\S]{0,400}?pro/);
    const update = migration.search(/UPDATE organizations[\s\S]{0,200}?SET plan/);
    assert.ok(widen > -1 && update > -1, 'the rename steps could not be found');
    assert.ok(widen < update, 'the rows are rewritten before the constraint allows the new values');
  });

  test('the dependency count has not moved', () => {
    const manifest = JSON.parse(read(path.join(root, 'package.json'))) as {
      readonly dependencies: Record<string, string>;
    };
    assert.deepEqual(
      Object.keys(manifest.dependencies).sort(),
      ['clsx', 'next', 'react', 'react-dom', 'tailwind-merge'],
      'Phase 7 added a production dependency',
    );
  });

  test('every new admin page declares itself noindex and dynamic', () => {
    for (const route of adminRoutes) {
      const segments = route.replace(/^\//, '').split('/');
      const file = appFiles.find((candidate) => {
        const relative = path.relative(path.join(root, 'src', 'app'), candidate).split(path.sep);
        if (relative[relative.length - 1] !== 'page.tsx') return false;
        return relative.slice(0, -1).filter((part) => !part.startsWith('(')).join('/') === segments.join('/');
      });
      assert.ok(file, `${route} has no page`);
      const text = read(file);
      assert.match(text, /force-dynamic/, `${route} is not dynamic, so it could be cached`);
      assert.match(text, /index:\s*false/, `${route} does not declare itself noindex`);
    }
  });
});

/* -------------------------------------------------------------------------- */
/* Stop after Phase 7                                                         */
/* -------------------------------------------------------------------------- */

describe('gate: the work stops at Phase 7', () => {
  test('nothing in the product promises a phase that has already shipped', () => {
    const offenders: string[] = [];
    for (const file of walk(path.join(root, 'src'))) {
      const text = read(file);
      for (const match of text.matchAll(/phase:?\s*['"]Phase (\d+)['"]/g)) {
        // Phases 8 and 9 shipped too, so nothing may still be planned for them.
        if (Number(match[1]) <= 9) offenders.push(`${path.relative(root, file)}: ${match[0]}`);
      }
    }
    assert.deepEqual(offenders, []);
  });

  test('no work beyond Phase 9 has been started', () => {
    // Phase 9 (final QA and release preparation) is the last briefed phase.
    const started: string[] = [];
    for (const file of libFiles) {
      const text = read(file);
      if (/Phase 10 implementation|TODO\(phase10\)/i.test(text)) {
        started.push(path.relative(root, file));
      }
    }
    assert.deepEqual(started, [], 'there is no brief beyond Phase 9');
  });

  test('the navigation reports the usage screen as available, not planned', () => {
    const nav = read(path.join(root, 'src', 'content', 'app-nav.ts'));
    const block = /\{[^}]*href: '\/app\/usage'[^}]*\}/.exec(nav)?.[0] ?? '';
    assert.ok(block.length > 0, 'the usage screen is not in the navigation');
    assert.match(block, /status: 'available'/, 'the usage screen is offered as unbuilt');
  });
});
