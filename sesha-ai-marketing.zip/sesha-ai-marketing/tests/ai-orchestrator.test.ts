import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { signUp, toRole } from '../src/lib/auth/service';
import { completeOnboarding } from '../src/lib/workspace/service';
import { loadWorkspaceContext, renderContext, summarizeContext } from '../src/lib/ai/context';
import { AIOrchestrator, trimHistory } from '../src/lib/ai/orchestrator';
import {
  quotaFor,
  AiCache,
  AiRateLimiter,
  backoffDelay,
  checkQuota,
  currentPeriod,
  selectModel,
  withRetry,
} from '../src/lib/ai/cost';
import { AiError, type AIProvider, type CompletionRequest, type CompletionResult } from '../src/lib/ai/provider';
import { availableAgents, getAgent, plannedAgents } from '../src/lib/ai/agents';
import type { TenantContext } from '../src/lib/tenant';

/**
 * Cost control and the orchestrator, executed end to end against a fake
 * provider. The orchestrator is the only path to a provider in the product, so
 * these tests are what make "usage limits", "error handling", "regenerate" and
 * "no fabricated facts" verifiable rather than aspirational.
 */

const PASSWORD = 'a genuinely long passphrase 2026';

/* -------------------------------------------------------------------------- */
/* Fake provider                                                              */
/* -------------------------------------------------------------------------- */

class FakeProvider implements AIProvider {
  readonly name = 'openai' as const;
  readonly models = [
    { id: 'fast-model', label: 'Fast', tier: 'fast' as const, contextTokens: 100_000, maxOutputTokens: 8_000 },
    { id: 'balanced-model', label: 'Balanced', tier: 'balanced' as const, contextTokens: 100_000, maxOutputTokens: 8_000 },
    { id: 'deep-model', label: 'Deep', tier: 'deep' as const, contextTokens: 200_000, maxOutputTokens: 16_000 },
  ];

  calls = 0;
  lastRequest: CompletionRequest | null = null;
  lastModel = '';
  /** Queue of behaviours; falls back to `defaultText`. */
  script: (string | Error)[] = [];
  defaultText = JSON.stringify({
    blocks: [{ kind: 'recommendation', text: 'Post once a week about one drink.' }],
  });

  isConfigured(): boolean {
    return true;
  }

  async complete(request: CompletionRequest, model: string): Promise<CompletionResult> {
    this.calls += 1;
    this.lastRequest = request;
    this.lastModel = model;

    const next = this.script.shift();
    if (next instanceof Error) throw next;

    return {
      text: next ?? this.defaultText,
      usage: { inputTokens: 100, outputTokens: 50 },
      model,
      provider: this.name,
      truncated: false,
    };
  }
}

/* -------------------------------------------------------------------------- */
/* Fixtures                                                                   */
/* -------------------------------------------------------------------------- */

let db: MemoryDatabase;
let provider: FakeProvider;
let tenant: TenantContext;
let projectId: string;

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: 'https://acme-coffee.example',
};

const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic'] as const,
  marketingChannels: ['organic-search', 'social-organic'] as const,
  brandVoice: { tones: ['friendly'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters' }],
};

async function setup(plan: 'free' | 'pro' | 'business' | 'agency' = 'agency') {
  db = new MemoryDatabase();
  provider = new FakeProvider();

  const authContext = {
    db,
    lockout: new MemoryLockoutStore(),
    secret: 'test-secret-value-at-least-32-bytes-long',
  };
  const signed = await signUp(authContext, { email: 'owner@example.com', password: PASSWORD });
  if (!signed.ok || !signed.userId) throw new Error('signup failed');

  const memberships = await db.memberships.findForUser(signed.userId);
  tenant = {
    userId: signed.userId,
    organizationId: memberships[0]!.organizationId,
    role: toRole(memberships[0]!.role),
  };

  await db.subscriptions.update(tenant.organizationId, { plan });
  const onboarded = await completeOnboarding({ db }, tenant, { business, profile });
  projectId = onboarded.project.id;
}

function orchestrator(overrides: Record<string, unknown> = {}) {
  return new AIOrchestrator({
    db,
    provider,
    cache: new AiCache(),
    limiter: new AiRateLimiter(),
    sleep: async () => {},
    ...overrides,
  });
}

async function context() {
  return loadWorkspaceContext(db, tenant, projectId);
}

beforeEach(async () => {
  await setup();
});

/* -------------------------------------------------------------------------- */
/* Quotas                                                                     */
/* -------------------------------------------------------------------------- */

describe('quotas', () => {
  test('every plan has a quota, and they increase', () => {
    // Phase 7 moved the two MONTHLY figures into the plan registry and left the
    // per-request ceilings here. `quotaFor` joins them, so this still asserts
    // the property that matters: a higher plan is never a lower quota.
    assert.ok(quotaFor('pro').generationsPerMonth < quotaFor('business').generationsPerMonth);
    assert.ok(quotaFor('business').tokensPerMonth < quotaFor('agency').tokensPerMonth);
    assert.ok(quotaFor('pro').requestsPerMinute > 0);
  });

  test('a fresh account is allowed', () => {
    const decision = checkQuota('pro', { generations: 0, tokens: 0 }, {
      inputTokens: 1_000,
      maxOutputTokens: 1_000,
    });
    assert.equal(decision.allowed, true);
  });

  test('exhausted generations are refused with a reason', () => {
    const decision = checkQuota(
      'pro',
      { generations: quotaFor('pro').generationsPerMonth, tokens: 0 },
      { inputTokens: 100, maxOutputTokens: 100 },
    );
    assert.equal(decision.allowed, false);
    if (!decision.allowed) {
      assert.equal(decision.reason, 'generations');
      assert.match(decision.message, /upgrade|billing period/i);
    }
  });

  test('the token budget accounts for the WORST case output', () => {
    // Budgeting only the input would let a request start that cannot finish
    // inside the allowance.
    const used = { generations: 0, tokens: quotaFor('pro').tokensPerMonth - 500 };
    const decision = checkQuota('pro', used, { inputTokens: 100, maxOutputTokens: 1_000 });
    assert.equal(decision.allowed, false);
    if (!decision.allowed) assert.equal(decision.reason, 'tokens');
  });

  test('an oversized single request is refused before any spend', () => {
    const decision = checkQuota('pro', { generations: 0, tokens: 0 }, {
      inputTokens: quotaFor('pro').maxInputTokens + 1,
      maxOutputTokens: 100,
    });
    assert.equal(decision.allowed, false);
    if (!decision.allowed) assert.equal(decision.reason, 'input_too_large');
  });

  test('the period key is the first of the month, in UTC', () => {
    assert.equal(currentPeriod(Date.UTC(2026, 8, 11)), '2026-09-01');
    assert.equal(currentPeriod(Date.UTC(2026, 0, 31)), '2026-01-01');
  });
});

describe('request rate', () => {
  test('allows up to the limit then refuses', () => {
    const limiter = new AiRateLimiter();
    for (let i = 0; i < 5; i += 1) {
      assert.equal(limiter.check('org', 5, 1_000).allowed, true);
    }
    const refused = limiter.check('org', 5, 1_000);
    assert.equal(refused.allowed, false);
    assert.ok(refused.retryAfterSeconds > 0);
  });

  test('is keyed by ORGANIZATION, so one company shares one budget', () => {
    const limiter = new AiRateLimiter();
    limiter.check('org-a', 1, 0);
    assert.equal(limiter.check('org-a', 1, 0).allowed, false);
    assert.equal(limiter.check('org-b', 1, 0).allowed, true);
  });

  test('the window resets', () => {
    const limiter = new AiRateLimiter();
    limiter.check('org', 1, 0);
    assert.equal(limiter.check('org', 1, 0).allowed, false);
    assert.equal(limiter.check('org', 1, 61_000).allowed, true);
  });
});

/* -------------------------------------------------------------------------- */
/* Model selection, retry, cache                                              */
/* -------------------------------------------------------------------------- */

describe('model selection', () => {
  const models = new FakeProvider().models;

  test('matches the task weight', () => {
    assert.equal(selectModel(models, 'light').tier, 'fast');
    assert.equal(selectModel(models, 'standard').tier, 'balanced');
    assert.equal(selectModel(models, 'heavy').tier, 'deep');
  });

  test('an explicit request wins', () => {
    assert.equal(selectModel(models, 'light', 'deep-model').id, 'deep-model');
  });

  test('an unknown request falls back rather than failing', () => {
    assert.equal(selectModel(models, 'light', 'no-such-model').tier, 'fast');
  });

  test('no models at all is an error, not a crash', () => {
    assert.throws(() => selectModel([], 'light'), AiError);
  });
});

describe('retry', () => {
  test('succeeds first time without retrying', async () => {
    const outcome = await withRetry(async () => 'ok', undefined, async () => {});
    assert.equal(outcome.attempts, 1);
  });

  test('retries a retryable error and then succeeds', async () => {
    let calls = 0;
    const outcome = await withRetry(
      async () => {
        calls += 1;
        if (calls < 3) throw new AiError('unavailable', 'blip');
        return 'ok';
      },
      undefined,
      async () => {},
    );
    assert.equal(outcome.attempts, 3);
  });

  test('does NOT retry a non-retryable error', async () => {
    // An invalid key fails identically every time; retrying wastes the user's
    // time and, on some providers, their quota.
    let calls = 0;
    await assert.rejects(() =>
      withRetry(
        async () => {
          calls += 1;
          throw new AiError('unauthorized', 'bad key');
        },
        undefined,
        async () => {},
      ),
    );
    assert.equal(calls, 1);
  });

  test('gives up after the maximum attempts', async () => {
    let calls = 0;
    await assert.rejects(() =>
      withRetry(
        async () => {
          calls += 1;
          throw new AiError('unavailable', 'down');
        },
        { maxAttempts: 3, baseDelayMs: 1, maxDelayMs: 5 },
        async () => {},
      ),
    );
    assert.equal(calls, 3);
  });

  test('back-off grows and is jittered', () => {
    const policy = { maxAttempts: 5, baseDelayMs: 100, maxDelayMs: 10_000 };
    // Full jitter with random()=1 gives the ceiling for that attempt.
    assert.equal(backoffDelay(1, policy, () => 1), 100);
    assert.equal(backoffDelay(2, policy, () => 1), 200);
    assert.equal(backoffDelay(3, policy, () => 1), 400);
    // Jitter means a lower random value gives a shorter delay.
    assert.ok(backoffDelay(3, policy, () => 0.1) < backoffDelay(3, policy, () => 1));
  });

  test('back-off is capped', () => {
    const policy = { maxAttempts: 20, baseDelayMs: 1_000, maxDelayMs: 5_000 };
    assert.equal(backoffDelay(15, policy, () => 1), 5_000);
  });
});

describe('cache', () => {
  const request: CompletionRequest = {
    system: 's',
    messages: [{ role: 'user', content: 'hello' }],
    maxOutputTokens: 100,
    temperature: 0.2,
    timeoutMs: 1_000,
  };

  test('keys include the organization, so tenants cannot share a hit', () => {
    const a = AiCache.key('org-a', 'model', request);
    const b = AiCache.key('org-b', 'model', request);
    assert.notEqual(a, b);
  });

  test('identical requests share a key', () => {
    assert.equal(AiCache.key('org', 'm', request), AiCache.key('org', 'm', { ...request }));
  });

  test('only low-temperature requests are cacheable', () => {
    const cache = new AiCache();
    assert.equal(cache.cacheable(request), true);
    assert.equal(cache.cacheable({ ...request, temperature: 0.8 }), false);
  });

  test('entries expire', () => {
    const cache = new AiCache();
    const result = { text: 'x', usage: { inputTokens: 1, outputTokens: 1 }, model: 'm', provider: 'openai' as const, truncated: false };
    cache.set('k', result, 0);
    assert.ok(cache.get('k', 1_000));
    assert.equal(cache.get('k', 20 * 60 * 1000), null);
  });

  test('evicts when full', () => {
    const cache = new AiCache(3);
    const result = { text: 'x', usage: { inputTokens: 1, outputTokens: 1 }, model: 'm', provider: 'openai' as const, truncated: false };
    for (let i = 0; i < 10; i += 1) cache.set(`k${i}`, result, 0);
    assert.ok(cache.size <= 3);
  });
});

/* -------------------------------------------------------------------------- */
/* Context                                                                    */
/* -------------------------------------------------------------------------- */

describe('workspace context', () => {
  test('loads the business, project and profile', async () => {
    const ctx = await context();
    assert.equal(ctx.business?.name, 'Acme Coffee');
    assert.equal(ctx.project?.id, projectId);
    assert.ok(ctx.profile?.targetAudience);
  });

  test('a foreign project id yields empty context, never another tenant’s data', async () => {
    const other = new MemoryDatabase();
    void other;
    const foreign = await loadWorkspaceContext(db, { ...tenant, organizationId: 'someone-else' }, projectId);
    assert.equal(foreign.project, null);
    assert.equal(foreign.business, null);
    assert.equal(foreign.profile, null);
  });

  test('the rendered prompt contains the real details', async () => {
    const rendered = renderContext(await context());
    assert.ok(rendered.includes('Acme Coffee'));
    assert.ok(rendered.includes('Office workers'));
    assert.ok(rendered.includes('Nagpur'));
  });

  test('the rendered prompt STATES what is missing', async () => {
    const rendered = renderContext(await context());
    assert.ok(rendered.includes('NOT AVAILABLE'));
    assert.ok(/analytics data/i.test(rendered));
    assert.ok(/Do not invent/i.test(rendered));
  });

  test('competitors are named but explicitly unknown', async () => {
    const rendered = renderContext(await context());
    assert.ok(rendered.includes('Rival Roasters'));
    assert.ok(/know nothing about these companies/i.test(rendered));
  });

  test('an over-budget context drops low-priority sections but keeps the gaps', async () => {
    const rendered = renderContext(await context(), { maxTokens: 10 });
    assert.ok(rendered.includes('NOT AVAILABLE'), 'the gaps list must never be dropped');
    assert.ok(rendered.includes('Acme Coffee'), 'core profile must never be dropped');
  });

  test('the summary tells the user what the copilot knows', async () => {
    const summary = summarizeContext(await context());
    assert.equal(summary.projectName, 'Acme Coffee');
    assert.ok(summary.present.includes('Target audience'));
    assert.ok(summary.missing.length > 0);
  });
});

/* -------------------------------------------------------------------------- */
/* Agents                                                                     */
/* -------------------------------------------------------------------------- */

describe('agents', () => {
  test('the four built agents from the brief are available', () => {
    const ids = availableAgents().map((a) => a.id);
    for (const id of ['strategy', 'content', 'social', 'brand']) {
      assert.ok(ids.includes(id as never), `${id} should be available`);
    }
  });

  test('the eight future agents are declared but planned', () => {
    const ids = plannedAgents().map((a) => a.id);
    for (const id of ['seo', 'aeo', 'schema', 'ads', 'lead', 'analytics', 'competitor', 'report']) {
      assert.ok(ids.includes(id as never), `${id} should be declared as planned`);
    }
    assert.equal(plannedAgents().length, 8);
  });

  test('every planned agent names its phase', () => {
    for (const agent of plannedAgents()) {
      assert.ok(agent.phase, `${agent.id} does not say when it arrives`);
    }
  });

  test('analytical agents run colder than creative ones', () => {
    assert.ok(getAgent('strategy').temperature < getAgent('content').temperature);
    assert.ok(getAgent('brand').temperature < getAgent('social').temperature);
  });
});

/* -------------------------------------------------------------------------- */
/* The orchestrator                                                           */
/* -------------------------------------------------------------------------- */

describe('orchestrator', () => {
  test('runs a generation and returns provenance blocks', async () => {
    const result = await orchestrator().run(tenant, {
      agent: 'copilot',
      prompt: 'What should I post this week?',
      context: await context(),
      projectId,
    });

    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.equal(result.response.blocks.length, 1);
    assert.equal(result.cached, false);
    assert.equal(provider.calls, 1);
  });

  test('the workspace context reaches the system prompt', async () => {
    await orchestrator().run(tenant, {
      agent: 'copilot',
      prompt: 'Hello',
      context: await context(),
      projectId,
    });
    assert.ok(provider.lastRequest?.system.includes('Acme Coffee'));
    assert.ok(provider.lastRequest?.system.includes('Office workers'));
  });

  test('REFUSES a planned agent with a useful message', async () => {
    const result = await orchestrator().run(tenant, {
      agent: 'seo',
      prompt: 'Audit my site',
      context: await context(),
    });
    assert.equal(result.ok, false);
    if (!result.ok) {
      assert.equal(result.code, 'agent_not_implemented');
      // The SEO *audit* shipped in Phase 4 and is rule-based; the agent that
      // would write prose over its findings is a later phase, and the refusal
      // message must name a phase that has NOT been delivered. Asserting on the
      // exact number would mean editing this test every phase, so it asserts the
      // property that actually matters.
      // Phase 9 is the last briefed phase, so a planned agent now names no
      // phase number at all — only that it is not built yet and comes later.
      assert.match(result.message, /not built yet/i);
      const match = /Phase (\d+)/.exec(result.message);
      assert.ok(!match || Number(match[1]) > 9, `a planned agent points at shipped Phase ${match?.[1]}`);
    }
    assert.equal(provider.calls, 0, 'no provider call should be made');
  });

  test('rejects an empty or oversized prompt before calling the provider', async () => {
    const ctx = await context();
    const empty = await orchestrator().run(tenant, { agent: 'copilot', prompt: '  ', context: ctx });
    assert.equal(empty.ok, false);

    const huge = await orchestrator().run(tenant, {
      agent: 'copilot',
      prompt: 'x'.repeat(50_000),
      context: ctx,
    });
    assert.equal(huge.ok, false);
    assert.equal(provider.calls, 0);
  });

  test('records usage for both generations and tokens', async () => {
    await orchestrator().run(tenant, {
      agent: 'copilot',
      prompt: 'Hello',
      context: await context(),
      projectId,
    });

    const period = currentPeriod();
    assert.equal(await db.usage.totalFor(tenant.organizationId, 'ai_generation', period), 1);
    assert.equal(await db.usage.totalFor(tenant.organizationId, 'ai_tokens', period), 150);
  });

  test('writes an audit entry that contains NO prompt or output', async () => {
    await orchestrator().run(tenant, {
      agent: 'copilot',
      prompt: 'A very distinctive secret prompt string',
      context: await context(),
      projectId,
    });

    const entries = await db.audit.list(tenant.organizationId);
    const generation = entries.find((e) => e.action === 'ai.generate.copilot');
    assert.ok(generation);
    const serialized = JSON.stringify(generation);
    assert.ok(!serialized.includes('A very distinctive secret prompt string'), 'the prompt was logged');
    assert.ok(!serialized.includes('Post once a week'), 'the output was logged');
  });

  test('enforces the monthly quota', async () => {
    await setup('pro');
    const period = currentPeriod();
    await db.usage.record({
      organizationId: tenant.organizationId,
      projectId: null,
      metric: 'ai_generation',
      quantity: quotaFor('pro').generationsPerMonth,
      periodStart: period,
    });

    const result = await orchestrator().run(tenant, {
      agent: 'copilot',
      prompt: 'Hello',
      context: await context(),
    });
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.code, 'quota_generations');
    assert.equal(provider.calls, 0, 'quota must be checked before spending');
  });

  test('enforces the request rate', async () => {
    await setup('pro');
    const orch = orchestrator();
    const ctx = await context();

    for (let i = 0; i < quotaFor('pro').requestsPerMinute; i += 1) {
      await orch.run(tenant, { agent: 'copilot', prompt: `q${i}`, context: ctx, bypassCache: true });
    }
    const refused = await orch.run(tenant, { agent: 'copilot', prompt: 'one more', context: ctx });
    assert.equal(refused.ok, false);
    if (!refused.ok) assert.equal(refused.code, 'rate_limited');
  });

  test('caches a deterministic request and does not re-bill it', async () => {
    const orch = orchestrator();
    const ctx = await context();

    // Strategy runs at low temperature, so it is cacheable.
    await orch.run(tenant, { agent: 'strategy', prompt: 'Build a plan', context: ctx, projectId });
    const second = await orch.run(tenant, { agent: 'strategy', prompt: 'Build a plan', context: ctx, projectId });

    assert.equal(provider.calls, 1, 'the second call should have been served from cache');
    assert.equal(second.ok, true);
    if (second.ok) {
      assert.equal(second.cached, true);
      assert.equal(second.record.inputTokens, 0, 'a cache hit costs nothing');
    }
  });

  test('REGENERATE bypasses the cache', async () => {
    const orch = orchestrator();
    const ctx = await context();
    await orch.run(tenant, { agent: 'strategy', prompt: 'Build a plan', context: ctx });
    await orch.run(tenant, { agent: 'strategy', prompt: 'Build a plan', context: ctx, bypassCache: true });
    assert.equal(provider.calls, 2);
  });

  test('creative agents are not cached at all', async () => {
    const orch = orchestrator();
    const ctx = await context();
    await orch.run(tenant, { agent: 'content', prompt: 'Write a post', context: ctx });
    await orch.run(tenant, { agent: 'content', prompt: 'Write a post', context: ctx });
    assert.equal(provider.calls, 2, 'a rewrite must not return the identical draft');
  });

  test('REJECTS an unparseable response rather than showing untagged text', async () => {
    provider.script = ['Here is some plausible untagged marketing advice with 40% growth.'];
    const result = await orchestrator().run(tenant, {
      agent: 'copilot',
      prompt: 'Advice?',
      context: await context(),
      projectId,
    });

    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.code, 'bad_response');
    // We were still charged, so usage must still be recorded.
    assert.equal(await db.usage.totalFor(tenant.organizationId, 'ai_generation', currentPeriod()), 1);
  });

  test('surfaces a fabricated statistic as unsafe rather than hiding it', async () => {
    provider.script = [
      JSON.stringify({
        blocks: [{ kind: 'ai_inference', text: 'The local market grew 23% last year.' }],
      }),
    ];
    const result = await orchestrator().run(tenant, {
      agent: 'copilot',
      prompt: 'How is the market?',
      context: await context(),
    });

    assert.equal(result.ok, true);
    if (result.ok) {
      assert.equal(result.response.safe, false);
      assert.ok(result.response.warnings.some((w) => w.severity === 'error'));
    }
  });

  test('maps a provider failure to a safe message and audits it', async () => {
    provider.script = [new AiError('unauthorized', 'key sk-secret123 rejected for org-abc')];
    const result = await orchestrator().run(tenant, {
      agent: 'copilot',
      prompt: 'Hello',
      context: await context(),
    });

    assert.equal(result.ok, false);
    if (!result.ok) {
      assert.ok(!result.message.includes('sk-secret123'), 'the key leaked to the user');
      assert.ok(!result.message.includes('org-abc'));
    }

    const entries = await db.audit.list(tenant.organizationId);
    assert.ok(entries.some((e) => e.action === 'ai.generate.copilot' && e.outcome === 'failure'));
  });

  test('retries a transient failure and then succeeds', async () => {
    provider.script = [new AiError('unavailable', 'blip')];
    const result = await orchestrator({ retry: { maxAttempts: 3, baseDelayMs: 1, maxDelayMs: 2 } }).run(
      tenant,
      { agent: 'copilot', prompt: 'Hello', context: await context() },
    );
    assert.equal(result.ok, true);
    assert.equal(provider.calls, 2);
  });

  test('selects a heavier model for the strategy agent', async () => {
    const ctx = await context();
    await orchestrator().run(tenant, { agent: 'content', prompt: 'Write', context: ctx });
    assert.equal(provider.lastModel, 'balanced-model');

    await orchestrator().run(tenant, { agent: 'strategy', prompt: 'Plan', context: ctx });
    assert.equal(provider.lastModel, 'deep-model');
  });

  test('output tokens are clamped by plan and model, whichever is lower', async () => {
    await setup('pro');
    await orchestrator().run(tenant, {
      agent: 'strategy',
      prompt: 'Plan',
      context: await context(),
      maxOutputTokens: 99_999,
    });
    assert.ok(
      (provider.lastRequest?.maxOutputTokens ?? Infinity) <= quotaFor('pro').maxOutputTokens,
    );
  });
});

describe('history trimming', () => {
  test('keeps the most recent turns within budget', () => {
    const history = Array.from({ length: 50 }, (_, i) => ({
      role: i % 2 === 0 ? ('user' as const) : ('assistant' as const),
      content: 'x'.repeat(400),
    }));
    const trimmed = trimHistory(history, 1_000);
    assert.ok(trimmed.length < history.length);
    assert.equal(trimmed.at(-1)?.content, history.at(-1)?.content, 'the newest turn must survive');
  });

  test('never starts with an assistant turn', () => {
    const trimmed = trimHistory(
      [
        { role: 'assistant', content: 'orphaned answer' },
        { role: 'user', content: 'question' },
      ],
      10_000,
    );
    assert.equal(trimmed[0]?.role, 'user');
  });

  test('an empty history stays empty', () => {
    assert.deepEqual(trimHistory([], 1_000), []);
  });
});
