import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  CONTENT_FORMATS,
  DEFAULT_CONTROLS,
  FORMAT_SPECS,
  LANGUAGES,
  LANGUAGE_SPECS,
  LENGTH_MULTIPLIERS,
  TONES,
  buildContentBrief,
  checkContent,
  creativityToTemperature,
  isContentFormat,
  isLanguage,
  targetWordCount,
  type ContentControls,
} from '../src/lib/content/types';
import {
  PLATFORMS,
  PLATFORM_SPECS,
  POST_STATUSES,
  allPlatforms,
  anyPlatformConnected,
  buildSocialBrief,
  checkPost,
  groupByDate,
  isPlatform,
  normalizeHashtag,
  normalizeHashtags,
} from '../src/lib/social/platforms';
import {
  SECTION_SPECS,
  STRATEGY_SECTIONS,
  buildSectionBrief,
  generatableSections,
  planSections,
} from '../src/lib/strategy/sections';
import type { WorkspaceContext } from '../src/lib/ai/context';

/**
 * Content Studio, social planning and strategy.
 *
 * The assertions that matter here are the ones that stop the product lying: a
 * platform character limit that is actually enforced, a language control that
 * is actually checked, a publish button that cannot exist because no API is
 * connected, and a strategy section that reports missing data instead of
 * inventing it.
 */

const controls = (overrides: Partial<ContentControls> = {}): ContentControls => ({
  ...DEFAULT_CONTROLS,
  format: 'blog',
  topic: 'Speciality coffee',
  ...overrides,
});

/* -------------------------------------------------------------------------- */
/* Formats                                                                    */
/* -------------------------------------------------------------------------- */

describe('content formats', () => {
  test('all twenty formats from the brief exist', () => {
    assert.equal(CONTENT_FORMATS.length, 20);
    for (const expected of [
      'blog', 'article', 'website-copy', 'landing-page', 'product-description',
      'social-post', 'instagram-caption', 'linkedin-post', 'x-post',
      'youtube-script', 'reels-script', 'shorts-script', 'ad-copy',
      'email', 'newsletter', 'whatsapp', 'sms', 'faq', 'how-to', 'comparison',
    ]) {
      assert.ok(isContentFormat(expected), `${expected} is missing`);
    }
  });

  test('every format has a complete spec', () => {
    for (const format of CONTENT_FORMATS) {
      const spec = FORMAT_SPECS[format];
      assert.equal(spec.id, format);
      assert.ok(spec.label.length > 0);
      assert.ok(spec.structure.length > 20, `${format} has no real structural guidance`);
      assert.ok(spec.defaultWords > 0);
    }
  });

  test('formats with a real platform limit declare it', () => {
    assert.equal(FORMAT_SPECS['x-post'].maxCharacters, 280);
    assert.equal(FORMAT_SPECS['instagram-caption'].maxCharacters, 2200);
    assert.equal(FORMAT_SPECS.whatsapp.maxCharacters, 1024);
    // Long-form has no hard ceiling.
    assert.equal(FORMAT_SPECS.blog.maxCharacters, undefined);
  });

  test('answer intent is offered only where it makes sense', () => {
    assert.equal(FORMAT_SPECS.faq.supportsAnswerIntent, true);
    assert.equal(FORMAT_SPECS['how-to'].supportsAnswerIntent, true);
    assert.equal(FORMAT_SPECS.sms.supportsAnswerIntent, false);
  });

  test('length presets scale the target', () => {
    assert.ok(LENGTH_MULTIPLIERS.short < 1);
    assert.ok(LENGTH_MULTIPLIERS.long > 1);
    assert.ok(targetWordCount('blog', 'long') > targetWordCount('blog', 'short'));
  });
});

describe('creativity control', () => {
  test('maps 0–100 to a temperature and clamps out-of-range values', () => {
    assert.equal(creativityToTemperature(0), 0);
    assert.equal(creativityToTemperature(-50), 0);
    assert.ok(creativityToTemperature(100) <= 0.9);
    assert.ok(creativityToTemperature(500) <= 0.9);
  });

  test('never reaches 1.0', () => {
    // Above ~0.9 quality degrades and fabrication rises, which matters more
    // here than usual.
    for (let i = 0; i <= 100; i += 10) {
      assert.ok(creativityToTemperature(i) <= 0.9);
    }
  });

  test('is monotonic', () => {
    assert.ok(creativityToTemperature(80) > creativityToTemperature(20));
  });
});

/* -------------------------------------------------------------------------- */
/* Languages                                                                  */
/* -------------------------------------------------------------------------- */

describe('languages', () => {
  test('the three from the brief are supported', () => {
    assert.deepEqual([...LANGUAGES], ['en', 'hi', 'hinglish']);
    assert.equal(isLanguage('hinglish'), true);
    assert.equal(isLanguage('fr'), false);
  });

  test('each declares its script and a real instruction', () => {
    assert.equal(LANGUAGE_SPECS.hi.script, 'devanagari');
    assert.equal(LANGUAGE_SPECS.hinglish.script, 'latin-mixed');
    for (const language of LANGUAGES) {
      assert.ok(LANGUAGE_SPECS[language].instruction.length > 40);
    }
  });

  test('the Hinglish instruction rules out the common failure mode', () => {
    // "English sentences with a few Hindi words" is what a model does by
    // default, and it reads as a translation exercise.
    const instruction = LANGUAGE_SPECS.hinglish.instruction;
    assert.match(instruction, /Roman script/i);
    assert.match(instruction, /Do NOT write English sentences/i);
  });
});

describe('language enforcement on output', () => {
  test('Hindi requested but Latin returned is an ERROR', () => {
    const issues = checkContent('This is entirely in English.', controls({ language: 'hi' }));
    assert.ok(issues.some((i) => i.severity === 'error' && i.field === 'language'));
  });

  test('Hindi in Devanagari passes', () => {
    const hindi = 'यह हिन्दी में लिखा गया एक उदाहरण है जो देवनागरी लिपि का उपयोग करता है।';
    const issues = checkContent(hindi, controls({ language: 'hi', length: 'short' }));
    assert.ok(!issues.some((i) => i.field === 'language'));
  });

  test('Hinglish containing Devanagari is an ERROR', () => {
    const issues = checkContent('Aapka business नमस्ते grow karega', controls({ language: 'hinglish' }));
    assert.ok(issues.some((i) => i.severity === 'error' && i.field === 'language'));
  });

  test('Hinglish in Roman script passes the script check', () => {
    const issues = checkContent(
      'Aapka business grow karne ke liye ye simple steps follow kijiye.',
      controls({ language: 'hinglish', length: 'short' }),
    );
    assert.ok(!issues.some((i) => i.field === 'language'));
  });

  test('English containing Devanagari is an ERROR', () => {
    const issues = checkContent('This is English नमस्ते नमस्ते नमस्ते', controls({ language: 'en' }));
    assert.ok(issues.some((i) => i.severity === 'error' && i.field === 'language'));
  });
});

describe('output checks', () => {
  test('an X post over 280 characters is an ERROR', () => {
    const issues = checkContent('x'.repeat(300), controls({ format: 'x-post' }));
    assert.ok(issues.some((i) => i.severity === 'error' && /280/.test(i.message)));
  });

  test('an X post within the limit passes', () => {
    const issues = checkContent('A short, complete thought about coffee.', controls({ format: 'x-post', length: 'short' }));
    assert.ok(!issues.some((i) => i.severity === 'error'));
  });

  test('an empty draft is an error', () => {
    assert.equal(checkContent('   ', controls()).length, 1);
  });

  test('a wildly wrong length is a warning, not an error', () => {
    const issues = checkContent('Too short.', controls({ format: 'blog' }));
    const lengthIssue = issues.find((i) => i.field === 'length');
    assert.equal(lengthIssue?.severity, 'warning');
  });

  test('placeholders are surfaced so they are not published by accident', () => {
    const issues = checkContent(
      'Our coffee costs [PRICE] and we open at [OPENING TIME]. '.repeat(20),
      controls({ format: 'blog' }),
    );
    const placeholder = issues.find((i) => /placeholder/i.test(i.message));
    assert.ok(placeholder);
    assert.equal(placeholder?.severity, 'warning');
  });
});

describe('the content brief', () => {
  test('carries every control the user set', () => {
    const brief = buildContentBrief(
      controls({
        format: 'linkedin-post',
        language: 'hinglish',
        tone: 'friendly',
        audience: 'Small business owners',
        callToAction: 'Book a tasting',
        searchIntent: 'commercial',
      }),
    );
    assert.match(brief, /LinkedIn post/);
    assert.match(brief, /Roman script/);
    assert.match(brief, /friendly/);
    assert.match(brief, /Small business owners/);
    assert.match(brief, /Book a tasting/);
  });

  test('states the hard limit where one exists', () => {
    assert.match(buildContentBrief(controls({ format: 'x-post' })), /HARD LIMIT: 280/);
    assert.ok(!/HARD LIMIT/.test(buildContentBrief(controls({ format: 'blog' }))));
  });

  test('falls back to the workspace audience when none is given', () => {
    assert.match(buildContentBrief(controls({ audience: '' })), /workspace context/);
  });

  test('omits intent controls for formats that do not support them', () => {
    const brief = buildContentBrief(controls({ format: 'sms', answerIntent: 'definition' }));
    assert.ok(!/ANSWER INTENT/.test(brief));
  });

  test('every tone is a real option', () => {
    for (const tone of TONES) {
      assert.match(buildContentBrief(controls({ tone })), new RegExp(tone));
    }
  });
});

/* -------------------------------------------------------------------------- */
/* Social                                                                     */
/* -------------------------------------------------------------------------- */

describe('social platforms', () => {
  test('all seven from the brief exist', () => {
    assert.equal(PLATFORMS.length, 7);
    for (const expected of ['instagram', 'facebook', 'linkedin', 'youtube', 'x', 'pinterest', 'whatsapp']) {
      assert.ok(isPlatform(expected), `${expected} is missing`);
    }
  });

  test('every platform declares formats and hashtag rules', () => {
    for (const platform of allPlatforms()) {
      assert.ok(platform.formats.length > 0, `${platform.id} has no formats`);
      for (const format of platform.formats) {
        assert.ok(format.maxCharacters > 0);
        assert.ok(format.notes.length > 10);
      }
    }
  });

  test('WhatsApp correctly has no hashtags', () => {
    assert.equal(PLATFORM_SPECS.whatsapp.hashtags.supported, false);
  });

  test('recommended hashtag counts differ by platform, as they do in reality', () => {
    assert.ok(PLATFORM_SPECS.instagram.hashtags.recommended > PLATFORM_SPECS.x.hashtags.recommended);
  });
});

describe('the publishing promise', () => {
  test('NO platform can publish, and each says why', () => {
    // The brief: do not pretend to publish unless an official API is connected.
    for (const platform of allPlatforms()) {
      assert.equal(platform.canPublish, false, `${platform.id} claims it can publish`);
      assert.ok(platform.publishBlockedReason.length > 10, `${platform.id} gives no reason`);
      assert.ok(platform.apiRequirement.length > 20, `${platform.id} does not say what is needed`);
    }
  });

  test('nothing is connected', () => {
    assert.equal(anyPlatformConnected(), false);
  });

  test('the post lifecycle has NO published or scheduled state', () => {
    // Making the state unrepresentable beats remembering not to use it.
    assert.deepEqual([...POST_STATUSES], ['idea', 'draft', 'ready', 'archived']);
    assert.ok(!POST_STATUSES.includes('published' as never));
    assert.ok(!POST_STATUSES.includes('scheduled' as never));
  });

  test('the social brief tells the model it cannot publish', () => {
    const brief = buildSocialBrief('instagram', 'feed', 'New blend', 3);
    assert.match(brief, /cannot publish/i);
  });
});

describe('post validation', () => {
  const draft = {
    platform: 'x' as const,
    format: 'post',
    caption: 'A short post about coffee.',
    hashtags: ['#coffee'],
    idea: null,
    status: 'draft' as const,
    plannedFor: null,
  };

  test('a valid post passes', () => {
    assert.deepEqual(checkPost(draft), []);
  });

  test('hashtags COUNT TOWARD the character limit', () => {
    // The common bug: validating the caption alone, then the post is rejected
    // by the platform once tags are appended.
    const issues = checkPost({
      ...draft,
      caption: 'x'.repeat(275),
      hashtags: ['#coffee', '#nagpur'],
    });
    assert.ok(issues.some((i) => i.severity === 'error' && /exceeds/.test(i.message)));
  });

  test('too many hashtags for the platform is an error', () => {
    const issues = checkPost({
      ...draft,
      hashtags: Array.from({ length: 10 }, (_, i) => `#tag${i}`),
    });
    assert.ok(issues.some((i) => i.severity === 'error'));
  });

  test('hashtags on WhatsApp are an error', () => {
    const issues = checkPost({
      ...draft,
      platform: 'whatsapp',
      format: 'broadcast',
      hashtags: ['#offer'],
    });
    assert.ok(issues.some((i) => /does not use hashtags/.test(i.message)));
  });

  test('an unknown format for the platform is an error', () => {
    const issues = checkPost({ ...draft, format: 'tiktok-dance' });
    assert.ok(issues.some((i) => i.severity === 'error'));
  });

  test('an invalid hashtag is an error', () => {
    assert.ok(checkPost({ ...draft, hashtags: ['#not a tag'] }).some((i) => i.severity === 'error'));
  });

  test('a malformed planned date is an error', () => {
    assert.ok(checkPost({ ...draft, plannedFor: '11-09-2026' }).some((i) => i.severity === 'error'));
  });

  test('an empty caption is an error', () => {
    assert.ok(checkPost({ ...draft, caption: '  ' }).some((i) => i.severity === 'error'));
  });
});

describe('hashtag handling', () => {
  test('normalises to a single leading hash', () => {
    assert.equal(normalizeHashtag('coffee'), '#coffee');
    assert.equal(normalizeHashtag('##coffee'), '#coffee');
    assert.equal(normalizeHashtag('  #coffee  '), '#coffee');
  });

  test('strips characters platforms reject', () => {
    assert.equal(normalizeHashtag('#coffee-shop!'), '#coffeeshop');
  });

  test('empty input yields nothing', () => {
    assert.equal(normalizeHashtag('###'), '');
  });

  test('de-duplicates and caps a list', () => {
    const tags = normalizeHashtags(['#a', 'a', '#A', '#b', '#c', '#d'], 3);
    assert.equal(tags.length, 3);
    assert.equal(new Set(tags).size, 3);
  });

  test('non-Latin hashtags survive', () => {
    assert.equal(normalizeHashtag('#कॉफी'), '#कॉफी');
  });
});

describe('calendar', () => {
  test('groups entries by date', () => {
    const grouped = groupByDate([
      { date: '2026-09-11', platform: 'x', format: 'post', caption: 'a', status: 'ready' },
      { date: '2026-09-11', platform: 'instagram', format: 'feed', caption: 'b', status: 'draft' },
      { date: '2026-09-12', platform: 'linkedin', format: 'post', caption: 'c', status: 'idea' },
    ]);
    assert.equal(grouped.get('2026-09-11')?.length, 2);
    assert.equal(grouped.get('2026-09-12')?.length, 1);
  });
});

/* -------------------------------------------------------------------------- */
/* Strategy                                                                   */
/* -------------------------------------------------------------------------- */

function makeContext(overrides: Partial<WorkspaceContext> = {}): WorkspaceContext {
  return {
    organizationId: 'org',
    project: { id: 'p', name: 'Acme' } as never,
    business: { id: 'b', name: 'Acme' } as never,
    profile: {
      id: 'mp',
      targetAudience: 'Office workers',
      productsServices: 'Coffee',
      marketingGoals: ['foot-traffic'],
      marketingChannels: ['social-organic'],
      brandVoice: { tones: ['friendly'] },
      competitors: [{ name: 'Rival' }],
    } as never,
    brandKit: null,
    missing: [],
    ...overrides,
  };
}

describe('strategy sections', () => {
  test('all seventeen from the brief exist', () => {
    assert.equal(STRATEGY_SECTIONS.length, 17);
    for (const expected of [
      'market-analysis', 'audience', 'personas', 'positioning', 'usp', 'swot',
      'funnel', 'channel-strategy', 'content-strategy', 'social-strategy',
      'paid-advertising', 'seo-strategy', 'aeo-strategy', 'lead-generation',
      'retargeting', 'kpis', 'plan-30-60-90',
    ]) {
      assert.ok(STRATEGY_SECTIONS.includes(expected as never), `${expected} is missing`);
    }
  });

  test('every section declares what it needs and what it must produce', () => {
    for (const id of STRATEGY_SECTIONS) {
      const spec = SECTION_SPECS[id];
      assert.ok(spec.requires.length > 0, `${id} declares no inputs`);
      assert.ok(spec.instruction.length > 50, `${id} has no real instruction`);
    }
  });

  test('sections that could invent numbers are told not to', () => {
    assert.match(SECTION_SPECS['market-analysis'].instruction, /Do NOT state market size/i);
    assert.match(SECTION_SPECS.kpis.instruction, /DO NOT SET TARGET NUMBERS/i);
    assert.match(SECTION_SPECS['paid-advertising'].instruction, /Do NOT state budgets/i);
    assert.match(SECTION_SPECS.funnel.instruction, /no baseline/i);
  });

  test('personas are forbidden from inventing demographics', () => {
    assert.match(SECTION_SPECS.personas.instruction, /NO invented demographics/i);
  });

  test('SEO and AEO are honest placeholders, not empty headings', () => {
    assert.equal(SECTION_SPECS['seo-strategy'].placeholderUntil, 'a website crawl has run');
    assert.equal(SECTION_SPECS['aeo-strategy'].placeholderUntil, 'a website crawl has run');
    assert.ok(SECTION_SPECS['seo-strategy'].requires.includes('website-content'));
  });
});

describe('section availability', () => {
  test('a complete profile makes most sections fully available', () => {
    const planned = planSections(makeContext());
    const full = planned.filter((s) => s.availability === 'full');
    assert.ok(full.length >= 12, `only ${full.length} sections are fully available`);
  });

  test('SEO and AEO are PARTIAL, because no crawl has run', () => {
    const planned = planSections(makeContext());
    const seo = planned.find((s) => s.spec.id === 'seo-strategy');
    assert.equal(seo?.availability, 'partial');
    assert.match(seo?.note ?? '', /crawl/i);
  });

  test('a missing audience makes dependent sections unavailable, not invented', () => {
    const planned = planSections(
      makeContext({ profile: { ...makeContext().profile!, targetAudience: null } as never }),
    );
    const personas = planned.find((s) => s.spec.id === 'personas');
    assert.equal(personas?.availability, 'unavailable');
    assert.match(personas?.note ?? '', /marketing profile/i);
  });

  test('unavailable sections are excluded from generation entirely', () => {
    const empty = makeContext({ profile: null, business: null });
    const generatable = generatableSections(empty);
    assert.ok(generatable.length < STRATEGY_SECTIONS.length);
    assert.ok(generatable.every((s) => s.availability !== 'unavailable'));
  });

  test('a partial section is told to admit the gap rather than fill it', () => {
    const planned = planSections(makeContext());
    const seo = planned.find((s) => s.spec.id === 'seo-strategy')!;
    const brief = buildSectionBrief(seo);
    assert.match(brief, /MISSING INPUTS/);
    assert.match(brief, /Do not fill the gap/i);
  });

  test('a fully available section gets no missing-inputs note', () => {
    const planned = planSections(makeContext());
    const audience = planned.find((s) => s.spec.id === 'audience')!;
    assert.ok(!/MISSING INPUTS/.test(buildSectionBrief(audience)));
  });
});
