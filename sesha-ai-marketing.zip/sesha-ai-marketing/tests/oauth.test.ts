import assert from 'node:assert/strict';
import { createSign, generateKeyPairSync } from 'node:crypto';
import { test, describe } from 'node:test';

import {
  GOOGLE_AUTH_ENDPOINT,
  buildAuthorizationUrl,
  clearJwksCache,
  deriveCodeChallenge,
  exchangeCode,
  fetchGoogleJwks,
  generateCodeVerifier,
  statesMatch,
  toIdentity,
  verifyIdToken,
  type GoogleConfig,
} from '../src/lib/auth/oauth/google';

/**
 * Google OAuth verification, tested against REAL signatures.
 *
 * A key pair is generated here, tokens are signed with it, and its public half
 * is served as a JWKS — so `verifyIdToken` performs genuine RS256 verification
 * rather than being handed a pre-approved answer. Every rejection path is
 * exercised by tampering with a token that would otherwise be valid.
 */

const config: GoogleConfig = {
  clientId: 'test-client-id.apps.googleusercontent.com',
  clientSecret: 'test-client-secret',
  redirectUri: 'https://app.seshaaimarketing.com/api/auth/google/callback',
};

const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
const jwk = publicKey.export({ format: 'jwk' }) as { n: string; e: string };
const KID = 'test-key-1';
const JWKS = [{ kty: 'RSA', kid: KID, alg: 'RS256', use: 'sig', n: jwk.n, e: jwk.e }];

const NOW = 1_760_000_000_000;
const NOW_SECONDS = Math.floor(NOW / 1000);

function base64url(value: unknown): string {
  return Buffer.from(JSON.stringify(value)).toString('base64url');
}

function signToken(
  claims: Record<string, unknown>,
  options: { kid?: string; alg?: string; signature?: string } = {},
): string {
  const header = base64url({ alg: options.alg ?? 'RS256', kid: options.kid ?? KID, typ: 'JWT' });
  const payload = base64url(claims);
  if (options.signature !== undefined) return `${header}.${payload}.${options.signature}`;
  const signature = createSign('RSA-SHA256').update(`${header}.${payload}`).sign(privateKey);
  return `${header}.${payload}.${signature.toString('base64url')}`;
}

function validClaims(overrides: Record<string, unknown> = {}) {
  return {
    iss: 'https://accounts.google.com',
    aud: config.clientId,
    sub: '1234567890',
    exp: NOW_SECONDS + 3600,
    iat: NOW_SECONDS - 10,
    nonce: 'expected-nonce',
    email: 'person@example.com',
    email_verified: true,
    name: 'Test Person',
    ...overrides,
  };
}

/* -------------------------------------------------------------------------- */
/* PKCE                                                                       */
/* -------------------------------------------------------------------------- */

describe('PKCE', () => {
  test('verifier meets RFC 7636 length requirements', () => {
    const verifier = generateCodeVerifier();
    assert.ok(verifier.length >= 43 && verifier.length <= 128, `length ${verifier.length}`);
    assert.match(verifier, /^[A-Za-z0-9_-]+$/);
  });

  test('verifiers are unique', () => {
    const seen = new Set(Array.from({ length: 500 }, () => generateCodeVerifier()));
    assert.equal(seen.size, 500);
  });

  test('the challenge is the S256 hash, not the verifier', () => {
    const verifier = generateCodeVerifier();
    const challenge = deriveCodeChallenge(verifier);
    assert.notEqual(challenge, verifier);
    assert.equal(challenge, deriveCodeChallenge(verifier), 'must be deterministic');
    assert.notEqual(challenge, deriveCodeChallenge(generateCodeVerifier()));
  });
});

describe('authorization URL', () => {
  const request = buildAuthorizationUrl(config);
  const url = new URL(request.url);

  test('points at Google and carries the client configuration', () => {
    assert.ok(request.url.startsWith(GOOGLE_AUTH_ENDPOINT));
    assert.equal(url.searchParams.get('client_id'), config.clientId);
    assert.equal(url.searchParams.get('redirect_uri'), config.redirectUri);
    assert.equal(url.searchParams.get('response_type'), 'code');
  });

  test('requests only openid, email and profile', () => {
    assert.equal(url.searchParams.get('scope'), 'openid email profile');
  });

  test('sends state, nonce and an S256 challenge', () => {
    assert.equal(url.searchParams.get('state'), request.state);
    assert.equal(url.searchParams.get('nonce'), request.nonce);
    assert.equal(url.searchParams.get('code_challenge_method'), 'S256');
    assert.equal(url.searchParams.get('code_challenge'), deriveCodeChallenge(request.codeVerifier));
  });

  test('NEVER puts the code verifier in the URL', () => {
    assert.ok(!request.url.includes(request.codeVerifier), 'the verifier must stay server-side');
  });

  test('does not request offline access', () => {
    // No refresh token: we never call Google APIs for the user, so storing a
    // long-lived credential would be a liability with no benefit.
    assert.equal(url.searchParams.get('access_type'), 'online');
  });

  test('each request gets fresh state, nonce and verifier', () => {
    const other = buildAuthorizationUrl(config);
    assert.notEqual(other.state, request.state);
    assert.notEqual(other.nonce, request.nonce);
    assert.notEqual(other.codeVerifier, request.codeVerifier);
  });
});

describe('state comparison', () => {
  test('matches identical values and rejects everything else', () => {
    assert.equal(statesMatch('abc123', 'abc123'), true);
    assert.equal(statesMatch('abc123', 'abc124'), false);
    assert.equal(statesMatch('abc123', 'abc1234'), false);
    assert.equal(statesMatch(null, 'abc'), false);
    assert.equal(statesMatch('abc', undefined), false);
    assert.equal(statesMatch('', ''), false, 'an empty state must never satisfy the check');
  });
});

/* -------------------------------------------------------------------------- */
/* ID token verification — the security-critical part                         */
/* -------------------------------------------------------------------------- */

describe('ID token verification', () => {
  const expected = { clientId: config.clientId, nonce: 'expected-nonce' };

  test('accepts a correctly signed token with valid claims', () => {
    const result = verifyIdToken(signToken(validClaims()), JWKS, expected, NOW);
    assert.equal(result.ok, true);
    if (result.ok) assert.equal(result.claims.sub, '1234567890');
  });

  test('REJECTS a tampered payload', () => {
    // The whole point: change a claim, the signature no longer matches.
    const token = signToken(validClaims());
    const [header, , signature] = token.split('.');
    const forged = `${header}.${base64url(validClaims({ email: 'attacker@evil.example' }))}.${signature}`;
    const result = verifyIdToken(forged, JWKS, expected, NOW);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'bad_signature');
  });

  test('REJECTS alg:none', () => {
    const token = signToken(validClaims(), { alg: 'none', signature: '' });
    const result = verifyIdToken(token, JWKS, expected, NOW);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'unsupported_algorithm');
  });

  test('REJECTS an algorithm-confusion attempt (HS256)', () => {
    const token = signToken(validClaims(), { alg: 'HS256', signature: 'anything' });
    const result = verifyIdToken(token, JWKS, expected, NOW);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'unsupported_algorithm');
  });

  test('REJECTS a token signed by a different key', () => {
    const other = generateKeyPairSync('rsa', { modulusLength: 2048 });
    const header = base64url({ alg: 'RS256', kid: KID, typ: 'JWT' });
    const payload = base64url(validClaims());
    const signature = createSign('RSA-SHA256')
      .update(`${header}.${payload}`)
      .sign(other.privateKey)
      .toString('base64url');
    const result = verifyIdToken(`${header}.${payload}.${signature}`, JWKS, expected, NOW);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'bad_signature');
  });

  test('rejects an unknown key id', () => {
    const result = verifyIdToken(signToken(validClaims(), { kid: 'not-a-real-kid' }), JWKS, expected, NOW);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'unknown_key');
  });

  test('rejects a wrong issuer', () => {
    const result = verifyIdToken(
      signToken(validClaims({ iss: 'https://accounts.evil.example' })),
      JWKS,
      expected,
      NOW,
    );
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'bad_issuer');
  });

  test('accepts both issuer spellings Google uses', () => {
    for (const iss of ['https://accounts.google.com', 'accounts.google.com']) {
      assert.equal(verifyIdToken(signToken(validClaims({ iss })), JWKS, expected, NOW).ok, true);
    }
  });

  test('REJECTS a token minted for a different client (audience)', () => {
    const result = verifyIdToken(
      signToken(validClaims({ aud: 'someone-elses-client.apps.googleusercontent.com' })),
      JWKS,
      expected,
      NOW,
    );
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'bad_audience');
  });

  test('accepts an audience array containing our client id', () => {
    const result = verifyIdToken(
      signToken(validClaims({ aud: ['other-client', config.clientId] })),
      JWKS,
      expected,
      NOW,
    );
    assert.equal(result.ok, true);
  });

  test('rejects an expired token', () => {
    const result = verifyIdToken(
      signToken(validClaims({ exp: NOW_SECONDS - 3600 })),
      JWKS,
      expected,
      NOW,
    );
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'expired');
  });

  test('tolerates small clock skew rather than failing a valid login', () => {
    const result = verifyIdToken(
      signToken(validClaims({ exp: NOW_SECONDS - 30 })),
      JWKS,
      expected,
      NOW,
    );
    assert.equal(result.ok, true, '30 seconds of skew should not reject a token');
  });

  test('rejects a token issued in the future', () => {
    const result = verifyIdToken(
      signToken(validClaims({ iat: NOW_SECONDS + 3600 })),
      JWKS,
      expected,
      NOW,
    );
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'issued_in_future');
  });

  test('REJECTS a replayed token with the wrong nonce', () => {
    const result = verifyIdToken(
      signToken(validClaims({ nonce: 'some-other-sessions-nonce' })),
      JWKS,
      expected,
      NOW,
    );
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'nonce_mismatch');
  });

  test('rejects a token with no nonce when one was requested', () => {
    const claims = validClaims();
    delete (claims as Record<string, unknown>).nonce;
    const result = verifyIdToken(signToken(claims), JWKS, expected, NOW);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'nonce_mismatch');
  });

  test('rejects a token with no subject', () => {
    const claims = validClaims();
    delete (claims as Record<string, unknown>).sub;
    const result = verifyIdToken(signToken(claims), JWKS, expected, NOW);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'missing_subject');
  });

  test('rejects malformed input without throwing', () => {
    for (const bad of ['', 'not.a.jwt', 'only-one-part', 'a.b', 'a.b.c.d', '...']) {
      const result = verifyIdToken(bad, JWKS, expected, NOW);
      assert.equal(result.ok, false, `accepted malformed token: ${bad}`);
    }
  });

  test('an empty JWKS rejects everything', () => {
    const result = verifyIdToken(signToken(validClaims()), [], expected, NOW);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'unknown_key');
  });
});

/* -------------------------------------------------------------------------- */
/* Identity mapping                                                           */
/* -------------------------------------------------------------------------- */

describe('identity mapping', () => {
  test('maps verified claims to an identity', () => {
    const identity = toIdentity({
      iss: 'https://accounts.google.com',
      aud: config.clientId,
      sub: 'abc',
      exp: 0,
      iat: 0,
      email: 'person@example.com',
      email_verified: true,
      name: 'Person',
    });
    assert.deepEqual(identity, {
      provider: 'google',
      providerUserId: 'abc',
      email: 'person@example.com',
      emailVerified: true,
      name: 'Person',
    });
  });

  test('email_verified must be exactly true, not merely truthy', () => {
    const identity = toIdentity({
      iss: 'https://accounts.google.com',
      aud: config.clientId,
      sub: 'abc',
      exp: 0,
      iat: 0,
      email: 'person@example.com',
      email_verified: 'true' as unknown as boolean,
    });
    assert.equal(identity.emailVerified, false, 'a string must not be treated as verified');
  });
});

/* -------------------------------------------------------------------------- */
/* Token exchange and JWKS (network paths, with an injected fetch)             */
/* -------------------------------------------------------------------------- */

describe('token exchange', () => {
  test('posts the code and verifier, never the challenge', async () => {
    let capturedBody = '';
    const fakeFetch: typeof fetch = async (_url, init) => {
      capturedBody = String(init?.body ?? '');
      return new Response(JSON.stringify({ id_token: 'x.y.z' }), { status: 200 });
    };

    const result = await exchangeCode(config, 'auth-code', 'the-verifier', fakeFetch);
    assert.equal(result.ok, true);
    assert.match(capturedBody, /code=auth-code/);
    assert.match(capturedBody, /code_verifier=the-verifier/);
    assert.match(capturedBody, /grant_type=authorization_code/);
    assert.ok(!capturedBody.includes('code_challenge'), 'the challenge belongs to the first leg only');
  });

  test('a non-200 response fails without leaking provider detail', async () => {
    const fakeFetch: typeof fetch = async () =>
      new Response(JSON.stringify({ error: 'invalid_client', client_id: 'secret-detail' }), { status: 401 });
    const result = await exchangeCode(config, 'code', 'verifier', fakeFetch);
    assert.equal(result.ok, false);
    if (!result.ok) {
      assert.equal(result.error, 'token_endpoint_status_401');
      assert.ok(!result.error.includes('secret-detail'));
    }
  });

  test('a response with no id_token is rejected', async () => {
    const fakeFetch: typeof fetch = async () =>
      new Response(JSON.stringify({ access_token: 'only-this' }), { status: 200 });
    const result = await exchangeCode(config, 'code', 'verifier', fakeFetch);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'missing_id_token');
  });

  test('a network failure is handled, not thrown', async () => {
    const fakeFetch: typeof fetch = async () => {
      throw new Error('ECONNREFUSED');
    };
    const result = await exchangeCode(config, 'code', 'verifier', fakeFetch);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.error, 'token_endpoint_unreachable');
  });
});

describe('JWKS fetching', () => {
  test('caches keys and serves the cache within the TTL', async () => {
    clearJwksCache();
    let calls = 0;
    const fakeFetch: typeof fetch = async () => {
      calls += 1;
      return new Response(JSON.stringify({ keys: JWKS }), { status: 200 });
    };

    await fetchGoogleJwks(false, fakeFetch, NOW);
    await fetchGoogleJwks(false, fakeFetch, NOW + 1000);
    assert.equal(calls, 1, 'the second call should be served from cache');
  });

  test('force refetches', async () => {
    clearJwksCache();
    let calls = 0;
    const fakeFetch: typeof fetch = async () => {
      calls += 1;
      return new Response(JSON.stringify({ keys: JWKS }), { status: 200 });
    };
    await fetchGoogleJwks(false, fakeFetch, NOW);
    await fetchGoogleJwks(true, fakeFetch, NOW);
    assert.equal(calls, 2);
  });

  test('falls back to the cache when the provider is unavailable', async () => {
    clearJwksCache();
    let first = true;
    const fakeFetch: typeof fetch = async () => {
      if (first) {
        first = false;
        return new Response(JSON.stringify({ keys: JWKS }), { status: 200 });
      }
      return new Response('server error', { status: 503 });
    };

    await fetchGoogleJwks(false, fakeFetch, NOW);
    const keys = await fetchGoogleJwks(true, fakeFetch, NOW);
    assert.equal(keys.length, JWKS.length, 'a provider outage must not break every sign-in');
  });

  test('throws when there is no cache and the provider fails', async () => {
    clearJwksCache();
    const fakeFetch: typeof fetch = async () => new Response('nope', { status: 500 });
    await assert.rejects(() => fetchGoogleJwks(false, fakeFetch, NOW));
  });
});
