import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import { contentSecurityPolicy, securityHeaders } from '../src/lib/security/headers';
import { MemoryRateLimitStore, RATE_LIMITS, clientKey } from '../src/lib/security/rate-limit';
import {
  hasHeaderInjection,
  isProbablyEmail,
  sanitizeMultiline,
  sanitizeText,
} from '../src/lib/security/sanitize';
import {
  MIN_FILL_MS,
  looksAutomated,
  validateContact,
  validateNewsletter,
} from '../src/lib/validation/forms';

describe('security headers', () => {
  const headers = securityHeaders();
  const byKey = new Map(headers.map((h) => [h.key, h.value]));

  test('sets the baseline header set', () => {
    for (const key of [
      'Content-Security-Policy',
      'X-Content-Type-Options',
      'X-Frame-Options',
      'Referrer-Policy',
      'Permissions-Policy',
      'Cross-Origin-Opener-Policy',
    ]) {
      assert.ok(byKey.has(key), `missing ${key}`);
    }
  });

  test('framing is denied two ways', () => {
    assert.equal(byKey.get('X-Frame-Options'), 'DENY');
    assert.match(contentSecurityPolicy, /frame-ancestors 'none'/);
  });

  test('CSP blocks plugins and restricts form targets', () => {
    assert.match(contentSecurityPolicy, /object-src 'none'/);
    assert.match(contentSecurityPolicy, /form-action 'self'/);
    assert.match(contentSecurityPolicy, /base-uri 'self'/);
  });

  test('CSP allow-lists no third-party origins', () => {
    assert.ok(
      !/https?:\/\//.test(contentSecurityPolicy.replace('upgrade-insecure-requests', '')),
      'CSP must not reference external origins in Phase 1',
    );
  });

  test('nosniff is set', () => {
    assert.equal(byKey.get('X-Content-Type-Options'), 'nosniff');
  });
});

describe('rate limiting', () => {
  test('allows up to the limit then blocks', () => {
    const store = new MemoryRateLimitStore();
    const options = { limit: 3, windowMs: 60_000 };
    const results = [0, 1, 2, 3].map(() => store.consume('ip-1', options, 1_000));
    assert.deepEqual(results.map((r) => r.allowed), [true, true, true, false]);
    assert.equal(results[3]?.remaining, 0);
    assert.ok((results[3]?.retryAfterSeconds ?? 0) > 0);
  });

  test('window resets after it expires', () => {
    const store = new MemoryRateLimitStore();
    const options = { limit: 1, windowMs: 1_000 };
    assert.equal(store.consume('ip-2', options, 0).allowed, true);
    assert.equal(store.consume('ip-2', options, 500).allowed, false);
    assert.equal(store.consume('ip-2', options, 1_500).allowed, true);
  });

  test('separate keys have separate budgets', () => {
    const store = new MemoryRateLimitStore();
    const options = { limit: 1, windowMs: 60_000 };
    assert.equal(store.consume('a', options, 0).allowed, true);
    assert.equal(store.consume('b', options, 0).allowed, true);
  });

  test('configured limits are sane', () => {
    assert.ok(RATE_LIMITS.contact.limit > 0 && RATE_LIMITS.contact.windowMs > 0);
    assert.ok(RATE_LIMITS.schemaValidator.limit >= RATE_LIMITS.contact.limit);
  });

  /**
   * `X-Forwarded-For` is written by the client and appended to by each proxy.
   *
   * These tests replace one that asserted the LEFTMOST entry was used — which
   * was the vulnerability written down as an expectation. The leftmost entry is
   * whatever the caller typed, so it hands an attacker an unlimited supply of
   * rate-limit buckets and lets them poison anybody else's by claiming their
   * address. Only entries appended by infrastructure we run can be trusted, and
   * those are at the right-hand end.
   */
  function keyFor(headers: Record<string, string>): string {
    return clientKey({ get: (name) => headers[name] ?? null });
  }

  test('THE CLIENT-SUPPLIED PART OF X-FORWARDED-FOR IS IGNORED', () => {
    // One proxy (the default). The real client address is the last entry; the
    // one before it is whatever the caller claimed.
    assert.equal(
      keyFor({ 'x-forwarded-for': '203.0.113.5, 198.51.100.7' }),
      '198.51.100.7',
      'the spoofable leftmost entry was used as the key',
    );
  });

  test('two callers cannot forge different buckets from the same address', () => {
    const first = keyFor({ 'x-forwarded-for': 'attacker-says-1, 198.51.100.7' });
    const second = keyFor({ 'x-forwarded-for': 'attacker-says-2, 198.51.100.7' });
    assert.equal(first, second, 'varying a forged header produced two separate allowances');
  });

  test('a caller cannot claim someone else\'s address', () => {
    // A victim on 198.51.100.7 and an attacker on 203.0.113.9 claiming to be
    // them must not land in the same bucket.
    const victim = keyFor({ 'x-forwarded-for': '198.51.100.7' });
    const attacker = keyFor({ 'x-forwarded-for': '198.51.100.7, 203.0.113.9' });
    assert.notEqual(attacker, victim, 'an attacker poisoned the victim\'s bucket');
  });

  test('a single entry behind one proxy IS the proxy\'s own observation', () => {
    // The ordinary case: the client sent no header, the proxy appended what it
    // saw, so the one entry is trustworthy and is used even though `x-real-ip`
    // is also present.
    assert.equal(
      keyFor({ 'x-forwarded-for': '203.0.113.5', 'x-real-ip': '198.51.100.7' }),
      '203.0.113.5',
    );
  });

  test('an empty or whitespace-only header does not become a key', () => {
    // `', ,'` parses to nothing, and a blank key would put every such caller in
    // one bucket that is also reachable by anyone sending a blank header.
    assert.equal(keyFor({ 'x-forwarded-for': ' , , ' }), 'unknown-client');
    assert.equal(keyFor({ 'x-forwarded-for': '' }), 'unknown-client');
  });

  test('x-real-ip is preferred over a chain we cannot account for', () => {
    assert.equal(keyFor({ 'x-real-ip': '198.51.100.7' }), '198.51.100.7');
  });

  test('clientKey falls back to a shared bucket, not an open one', () => {
    assert.equal(clientKey({ get: () => null }), 'unknown-client');
  });
});

describe('sanitizers', () => {
  test('strips control characters', () => {
    const dirty = `a${String.fromCharCode(0)}b${String.fromCharCode(7)}c`;
    assert.equal(sanitizeText(dirty), 'abc');
  });

  test('collapses whitespace and trims', () => {
    assert.equal(sanitizeText('  a   b  '), 'a b');
  });

  test('enforces max length', () => {
    assert.equal(sanitizeText('x'.repeat(50), 10).length, 10);
  });

  test('non-strings become empty', () => {
    assert.equal(sanitizeText(42), '');
    assert.equal(sanitizeText(null), '');
    assert.equal(sanitizeText(undefined), '');
    assert.equal(sanitizeText({}), '');
  });

  test('multiline keeps paragraph breaks but collapses runs', () => {
    const out = sanitizeMultiline('line one\n\n\n\nline two');
    assert.equal(out, 'line one\n\nline two');
  });

  test('detects header injection', () => {
    assert.equal(hasHeaderInjection('Name\r\nBcc: a@b.com'), true);
    assert.equal(hasHeaderInjection('Name%0aBcc:'), true);
    assert.equal(hasHeaderInjection('Perfectly Normal Name'), false);
  });

  test('email shape check', () => {
    assert.equal(isProbablyEmail('a@b.co'), true);
    assert.equal(isProbablyEmail('first.last@sub.example.com'), true);
    assert.equal(isProbablyEmail('a@b'), false);
    assert.equal(isProbablyEmail('a b@c.com'), false);
    assert.equal(isProbablyEmail('a@@b.com'), false);
    assert.equal(isProbablyEmail(`${'x'.repeat(250)}@b.com`), false);
  });
});

describe('contact validation', () => {
  const good = {
    name: 'Asha Menon',
    email: 'Asha@Example.COM',
    company: 'Example Ltd',
    topic: 'product',
    message: 'I would like to understand how the content studio handles brand tone.',
    consent: true,
  };

  test('accepts a well-formed submission and normalises the email', () => {
    const result = validateContact(good);
    assert.equal(result.ok, true);
    if (result.ok) assert.equal(result.data.email, 'asha@example.com');
  });

  test('rejects a short name', () => {
    const result = validateContact({ ...good, name: 'A' });
    assert.equal(result.ok, false);
    if (!result.ok) assert.ok(result.errors.name);
  });

  test('rejects a bad email', () => {
    const result = validateContact({ ...good, email: 'not-an-email' });
    assert.equal(result.ok, false);
    if (!result.ok) assert.ok(result.errors.email);
  });

  test('rejects an unknown topic', () => {
    const result = validateContact({ ...good, topic: 'hack' });
    assert.equal(result.ok, false);
    if (!result.ok) assert.ok(result.errors.topic);
  });

  test('rejects a short message', () => {
    const result = validateContact({ ...good, message: 'hi' });
    assert.equal(result.ok, false);
    if (!result.ok) assert.ok(result.errors.message);
  });

  test('requires consent', () => {
    const result = validateContact({ ...good, consent: false });
    assert.equal(result.ok, false);
    if (!result.ok) assert.ok(result.errors.consent);
  });

  test('accepts checkbox-style consent values', () => {
    assert.equal(validateContact({ ...good, consent: 'on' }).ok, true);
  });

  test('rejects header injection in the name', () => {
    const result = validateContact({ ...good, name: 'Bob\r\nBcc: evil@x.com' });
    assert.equal(result.ok, false);
  });

  test('reports several field errors at once', () => {
    const result = validateContact({});
    assert.equal(result.ok, false);
    if (!result.ok) assert.ok(Object.keys(result.errors).length >= 4);
  });
});

describe('bot heuristics', () => {
  test('filled honeypot is flagged', () => {
    assert.equal(looksAutomated({ website: 'http://spam.example' }), true);
  });

  test('empty honeypot with human timing is not flagged', () => {
    const now = 1_000_000;
    assert.equal(looksAutomated({ website: '', renderedAt: now - 30_000 }, now), false);
  });

  test('instant submit is flagged', () => {
    const now = 1_000_000;
    assert.equal(looksAutomated({ renderedAt: now - (MIN_FILL_MS - 500) }, now), true);
  });

  test('missing timestamp alone is not enough to flag', () => {
    assert.equal(looksAutomated({}), false);
  });
});

describe('newsletter validation', () => {
  test('accepts and lowercases a valid address', () => {
    const result = validateNewsletter({ email: 'HELLO@Example.com' });
    assert.equal(result.ok, true);
    if (result.ok) assert.equal(result.data.email, 'hello@example.com');
  });

  test('rejects an empty address', () => {
    assert.equal(validateNewsletter({ email: '' }).ok, false);
  });

  test('rejects an invalid address', () => {
    assert.equal(validateNewsletter({ email: 'nope' }).ok, false);
  });
});
