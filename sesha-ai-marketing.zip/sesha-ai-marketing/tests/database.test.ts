import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { test, describe } from 'node:test';

import { SOFT_DELETE_TABLES, TABLES } from '../src/lib/db/types';

/**
 * Database schema consistency.
 *
 * Three things have to agree: the migrations (the source of truth), the
 * generated full schema, and the table list the application code knows about.
 * Nothing here connects to PostgreSQL — it checks that the three descriptions
 * of the schema cannot silently drift apart.
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const migrationsDir = path.join(root, 'db', 'migrations');

function migrationFiles(): string[] {
  return readdirSync(migrationsDir)
    .filter((name) => name.endsWith('.sql'))
    .sort();
}

function readMigrations(): string {
  return migrationFiles()
    .map((file) => readFileSync(path.join(migrationsDir, file), 'utf8'))
    .join('\n');
}

function tablesIn(sql: string): string[] {
  return [...sql.matchAll(/CREATE TABLE (?:IF NOT EXISTS )?(\w+)/g)].map((m) => m[1]!);
}

/**
 * SQL with comments removed.
 *
 * The convention checks below scan for column definitions, and a `-- never use
 * a naive timestamp` comment would otherwise match as if it were one. Comments
 * are documentation, not schema.
 */
function stripComments(sql: string): string {
  return sql
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .split('\n')
    .map((line) => line.replace(/--.*$/, ''))
    .join('\n');
}

const migrationsSql = stripComments(readMigrations());
const schemaSql = readFileSync(path.join(root, 'db', 'schema.sql'), 'utf8');

describe('migrations', () => {
  test('are numbered and ordered', () => {
    const files = migrationFiles();
    assert.ok(files.length >= 2, 'expected at least the Phase 1 and Phase 2 migrations');
    for (const file of files) {
      assert.match(file, /^\d{4}_[a-z_]+\.sql$/, `badly named migration: ${file}`);
    }
    assert.deepEqual(files, [...files].sort(), 'migrations are not in filename order');
  });

  test('each migration is wrapped in a transaction', () => {
    for (const file of migrationFiles()) {
      const sql = readFileSync(path.join(migrationsDir, file), 'utf8');
      assert.match(sql, /^\s*BEGIN;/m, `${file} does not begin a transaction`);
      assert.match(sql, /^\s*COMMIT;/m, `${file} does not commit`);
    }
  });

  test('no migration drops a table (forward-only, data-preserving)', () => {
    assert.ok(!/DROP TABLE/i.test(migrationsSql), 'a migration drops a table');
  });

  test('THE README LISTS EVERY MIGRATION, IN ORDER', () => {
    // This test exists because the README silently stopped listing migrations
    // after 0005. Phases 6 and 7 each added one, and the "Applying the database"
    // instructions quietly became wrong — the worst kind of documentation bug,
    // because someone following it gets a database that is missing tables and no
    // error telling them why. Nothing else in the suite reads the README, so
    // nothing else would have caught it.
    const readme = readFileSync(path.join(root, 'README.md'), 'utf8');
    const listed = [...readme.matchAll(/db\/migrations\/(\d{4}_[a-z_]+\.sql)/g)]
      .map((match) => match[1])
      .filter((name): name is string => name !== undefined);
    const onDisk = migrationFiles();

    for (const file of onDisk) {
      assert.ok(
        listed.includes(file),
        `${file} is not in the README's apply instructions, so anyone following them gets an incomplete database`,
      );
    }
    for (const file of listed) {
      assert.ok(onDisk.includes(file), `the README tells you to apply ${file}, which does not exist`);
    }
    // Order matters: a later migration applied first fails on missing tables.
    const firstMention = onDisk.map((file) => readme.indexOf(file));
    assert.deepEqual(
      firstMention,
      [...firstMention].sort((a, b) => a - b),
      'the README lists the migrations out of order',
    );
  });
});

describe('schema.sql is generated from the migrations', () => {
  test('every migration table appears in the generated schema', () => {
    const fromMigrations = new Set(tablesIn(migrationsSql));
    const fromSchema = new Set(tablesIn(schemaSql));
    const missing = [...fromMigrations].filter((name) => !fromSchema.has(name));
    assert.deepEqual(missing, [], `db/schema.sql is stale — run: node scripts/build-schema.mjs`);
  });

  test('the generated file is marked as generated', () => {
    assert.match(schemaSql, /GENERATED FILE/);
  });
});

describe('application table list matches the schema', () => {
  test('every table the code knows about exists in the migrations', () => {
    const inSql = new Set(tablesIn(migrationsSql));
    const missing = TABLES.filter((name) => !inSql.has(name));
    assert.deepEqual(missing, [], `declared in code but not in any migration: ${missing.join(', ')}`);
  });

  test('every table in the migrations is declared in code', () => {
    const declared = new Set<string>(TABLES);
    const undeclared = tablesIn(migrationsSql).filter((name) => !declared.has(name));
    assert.deepEqual(undeclared, [], `in the schema but missing from TABLES: ${undeclared.join(', ')}`);
  });

  test('table names are unique', () => {
    assert.equal(new Set(TABLES).size, TABLES.length);
  });
});

describe('schema conventions', () => {
  test('every table has a primary key', () => {
    // Each CREATE TABLE body must contain PRIMARY KEY somewhere.
    const blocks = migrationsSql.split(/CREATE TABLE (?:IF NOT EXISTS )?/).slice(1);
    for (const block of blocks) {
      const name = block.split(/[\s(]/)[0];
      const body = block.slice(0, block.indexOf('\n);') + 3);
      assert.match(body, /PRIMARY KEY/, `${name} has no primary key`);
    }
  });

  test('timestamps are timezone-aware everywhere', () => {
    // A naive `timestamp` column is a bug waiting for a daylight-saving change.
    const naive = [...migrationsSql.matchAll(/\s(\w+)\s+timestamp(?!tz)\b/g)].map((m) => m[1]);
    assert.deepEqual(naive, [], `naive timestamp columns: ${naive.join(', ')}`);
  });

  test('every tenant-scoped table carries organization_id', () => {
    const tenantScoped = [
      'businesses',
      'projects',
      'marketing_profiles',
      'website_crawl_consents',
      'subscriptions',
      'usage_records',
      'notifications',
      'ai_conversations',
      'ai_messages',
    ];
    for (const table of tenantScoped) {
      const match = migrationsSql.match(
        new RegExp(`CREATE TABLE (?:IF NOT EXISTS )?${table}[\\s\\S]*?\\n\\);`),
      );
      assert.ok(match, `${table} not found`);
      assert.match(match![0], /organization_id\s+uuid/, `${table} has no organization_id`);
    }
  });

  test('row-level security is enabled on every tenant-scoped table', () => {
    const tenantScoped = [
      'businesses',
      'projects',
      'marketing_profiles',
      'website_crawl_consents',
      'subscriptions',
      'usage_records',
      'notifications',
      'ai_conversations',
      'ai_messages',
    ];
    for (const table of tenantScoped) {
      assert.match(
        migrationsSql,
        new RegExp(`ALTER TABLE ${table}\\s+ENABLE ROW LEVEL SECURITY`),
        `${table} does not enable row-level security`,
      );
    }
  });

  test('soft-delete tables declare deleted_at', () => {
    for (const table of SOFT_DELETE_TABLES) {
      assert.match(
        migrationsSql,
        new RegExp(`deleted_at`),
        `${table} is marked soft-delete but no deleted_at column exists`,
      );
    }
  });

  test('sessions and tokens are HARD deleted, never soft deleted', () => {
    // Keeping a revoked session row around "for history" is a liability.
    for (const table of ['sessions', 'email_verification_tokens', 'password_reset_tokens']) {
      assert.ok(
        !SOFT_DELETE_TABLES.includes(table as (typeof SOFT_DELETE_TABLES)[number]),
        `${table} must not use soft delete`,
      );
    }
  });

  test('the audit log is append-only at the database level', () => {
    assert.match(migrationsSql, /RULE audit_log_no_update/);
    assert.match(migrationsSql, /RULE audit_log_no_delete/);
  });

  test('session tokens are stored as a hash, never raw', () => {
    assert.match(migrationsSql, /token_hash\s+bytea NOT NULL UNIQUE/);
    assert.ok(
      !/\btoken\s+text\b/.test(migrationsSql),
      'a raw token column would defeat the point of hashing',
    );
  });

  test('password_hash is documented as a hash, and there is no password column', () => {
    assert.ok(!/\bpassword\s+text\b/.test(migrationsSql), 'a plaintext password column exists');
    assert.match(migrationsSql, /password_hash/);
  });

  test('emails use citext so uniqueness is case-insensitive', () => {
    assert.match(migrationsSql, /email\s+citext/);
  });

  test('active email uniqueness survives account deletion', () => {
    // A plain UNIQUE would block reusing an address after a soft delete.
    assert.match(migrationsSql, /users_email_active_idx[\s\S]*?WHERE deleted_at IS NULL/);
  });

  test('the deletion anonymisation function destroys personal data', () => {
    const match = migrationsSql.match(
      /CREATE OR REPLACE FUNCTION anonymize_deleted_user[\s\S]*?\$\$ LANGUAGE plpgsql;/,
    );
    assert.ok(match, 'no anonymisation function');
    const body = match![0];
    for (const field of ['email', 'name', 'password_hash']) {
      assert.ok(body.includes(field), `anonymisation does not clear ${field}`);
    }
    assert.match(body, /DELETE FROM sessions/);
    assert.match(body, /DELETE FROM oauth_accounts/);
  });

  test('foreign keys declare an ON DELETE behaviour', () => {
    const references = [...migrationsSql.matchAll(/REFERENCES\s+\w+\([^)]*\)([^,\n]*)/g)];
    const withoutBehaviour = references.filter((m) => !/ON DELETE/.test(m[1] ?? ''));
    assert.deepEqual(
      withoutBehaviour.map((m) => m[0].slice(0, 60)),
      [],
      'every foreign key should state what happens when the parent is removed',
    );
  });
});
