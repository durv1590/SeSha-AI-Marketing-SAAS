import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  ACTION_EFFECT,
  ACTION_KINDS,
  ACTION_LABEL,
  MAX_RUNS_PER_DAY,
  OPERATOR_LABEL,
  RULE_TEMPLATES,
  TRIGGER_FIELDS,
  TRIGGER_KINDS,
  TRIGGER_LABEL,
  checkRule,
  conditionHolds,
  evaluate,
  hasRuleErrors,
  isActionKind,
  isOutboundAction,
  isTriggerKind,
  render,
  templateTokens,
  type AutomationRule,
} from '../src/lib/automation/types';

function rule(partial: Partial<AutomationRule>): AutomationRule {
  return {
    id: partial.id ?? 'r1',
    name: partial.name ?? 'A rule',
    trigger: partial.trigger ?? 'lead_created',
    conditions: partial.conditions ?? [],
    actions: partial.actions ?? [{ kind: 'create_task', template: 'Do the thing.' }],
    enabled: partial.enabled ?? true,
  };
}

describe('the vocabulary', () => {
  test('every trigger has a label and a declared field list', () => {
    for (const kind of TRIGGER_KINDS) {
      assert.ok(TRIGGER_LABEL[kind].length > 0, kind);
      assert.ok(TRIGGER_FIELDS[kind].length > 0, kind);
    }
  });

  test('every action has a label and says what it actually does', () => {
    for (const kind of ACTION_KINDS) {
      assert.ok(ACTION_LABEL[kind].length > 0, kind);
      assert.ok(ACTION_EFFECT[kind].length > 20, kind);
    }
  });

  test('the brief’s six examples all exist as templates', () => {
    assert.equal(RULE_TEMPLATES.length, 6);
    const triggers = RULE_TEMPLATES.map((template) => template.trigger);
    for (const expected of [
      'lead_created',
      'content_approved',
      'campaign_plan_declined',
      'lead_went_quiet',
      'schema_error_found',
      'structured_data_lost',
    ] as const) {
      assert.ok(triggers.includes(expected), expected);
    }
  });

  test('every template validates against its own trigger', () => {
    for (const template of RULE_TEMPLATES) {
      const problems = checkRule({ ...template, enabled: true });
      assert.ok(!hasRuleErrors(problems), `${template.name}: ${JSON.stringify(problems)}`);
    }
  });

  test('the guards reject anything else', () => {
    assert.ok(isTriggerKind('lead_created'));
    assert.ok(!isTriggerKind('lead_deleted'));
    assert.ok(isActionKind('notify'));
    assert.ok(!isActionKind('send_email'));
  });

  test('there is a daily ceiling', () => {
    assert.ok(MAX_RUNS_PER_DAY > 0 && MAX_RUNS_PER_DAY <= 1000);
  });
});

describe('no action can reach a third party', () => {
  test('isOutboundAction is false for every action SeSha has', () => {
    for (const kind of ACTION_KINDS) {
      assert.equal(isOutboundAction(kind), false, kind);
    }
  });

  test('no action is named as though it sends, posts or spends', () => {
    for (const kind of ACTION_KINDS) {
      assert.ok(!/send|post|publish|email|whatsapp|sms|spend|launch/i.test(kind), kind);
    }
  });

  test('the effect text of every action tells the user nothing is sent', () => {
    // Each one has to make the boundary visible somewhere in its own sentence,
    // because this text is what a person reads while building the rule.
    for (const kind of ACTION_KINDS) {
      const effect = ACTION_EFFECT[kind].toLowerCase();
      assert.ok(
        /nothing is sent|does not contact|does not publish|nothing fires|inside sesha|for a person/.test(effect),
        `${kind}: ${ACTION_EFFECT[kind]}`,
      );
    }
  });

  test('the re-engagement template drafts work rather than contacting the lead', () => {
    const template = RULE_TEMPLATES.find((candidate) => candidate.trigger === 'lead_went_quiet');
    assert.ok(template);
    for (const action of template.actions) {
      assert.equal(isOutboundAction(action.kind), false);
    }
  });
});

describe('checkRule', () => {
  test('rejects a condition on a field the trigger never publishes', () => {
    const problems = checkRule(
      rule({ trigger: 'crawl_completed', conditions: [{ field: 'score', operator: 'is_set' }] }),
    );
    assert.ok(hasRuleErrors(problems));
    assert.match(problems[0]?.message ?? '', /silently never fires/);
  });

  test('accepts a condition on a field the trigger does publish', () => {
    const problems = checkRule(
      rule({ trigger: 'crawl_completed', conditions: [{ field: 'pagesFailed', operator: 'greater_than', value: 0 }] }),
    );
    assert.ok(!hasRuleErrors(problems));
  });

  test('rejects a comparison operator with no value', () => {
    const problems = checkRule(
      rule({ conditions: [{ field: 'score', operator: 'greater_than' }] }),
    );
    assert.ok(hasRuleErrors(problems));
  });

  test('is_set needs no value', () => {
    const problems = checkRule(rule({ conditions: [{ field: 'email', operator: 'is_set' }] }));
    assert.ok(!hasRuleErrors(problems));
  });

  test('rejects a non-numeric value for a numeric comparison', () => {
    const problems = checkRule(
      rule({ conditions: [{ field: 'score', operator: 'greater_than', value: 'high' }] }),
    );
    assert.ok(hasRuleErrors(problems));
    assert.match(problems.map((problem) => problem.message).join(' '), /is not a number/);
  });

  test('rejects a rule with no actions', () => {
    const problems = checkRule(rule({ actions: [] }));
    assert.ok(hasRuleErrors(problems));
    assert.match(problems.map((problem) => problem.message).join(' '), /does nothing is not a rule/);
  });

  test('rejects an action with empty wording', () => {
    const problems = checkRule(rule({ actions: [{ kind: 'create_task', template: '   ' }] }));
    assert.ok(hasRuleErrors(problems));
  });

  test('rejects an unnamed rule', () => {
    assert.ok(hasRuleErrors(checkRule(rule({ name: '  ' }))));
  });

  test('warns about a token the trigger does not provide', () => {
    const problems = checkRule(
      rule({ trigger: 'crawl_completed', actions: [{ kind: 'create_task', template: 'Fix {{pageUrl}}' }] }),
    );
    assert.ok(!hasRuleErrors(problems));
    assert.ok(problems.some((problem) => problem.severity === 'warning' && /pageUrl/.test(problem.message)));
  });

  test('warns when a follow-up has no offset', () => {
    const problems = checkRule(rule({ actions: [{ kind: 'create_follow_up', template: 'Ring them.' }] }));
    assert.ok(problems.some((problem) => /no offset/.test(problem.message)));
  });

  test('warns about an unconditional lead rule', () => {
    const problems = checkRule(rule({ trigger: 'lead_created', conditions: [] }));
    assert.ok(problems.some((problem) => /every lead/.test(problem.message)));
  });

  test('an unknown trigger stops validation rather than producing cascading noise', () => {
    const problems = checkRule({
      name: 'x',
      trigger: 'nonsense' as AutomationRule['trigger'],
      conditions: [{ field: 'whatever', operator: 'is_set' }],
      actions: [],
      enabled: true,
    });
    assert.equal(problems.length, 1);
  });
});

describe('templates and rendering', () => {
  test('templateTokens finds the tokens and tolerates whitespace', () => {
    assert.deepEqual(templateTokens('Hi {{name}} and {{ other }}'), ['name', 'other']);
    assert.deepEqual(templateTokens('none here'), []);
  });

  test('render fills known tokens and blanks unknown ones', () => {
    assert.equal(render('From {{source}}.', { source: 'website' }), 'From website.');
    assert.equal(render('From {{source}}.', {}), 'From .');
    assert.equal(render('From {{source}}.', { source: null }), 'From .');
  });

  test('render does not execute anything in the payload', () => {
    assert.equal(render('{{a}}', { a: '{{b}}' }), '{{b}}', 'one pass only, so a payload cannot inject a token');
  });
});

describe('conditionHolds', () => {
  test('equals compares as text so 5 and "5" agree', () => {
    assert.ok(conditionHolds({ field: 'score', operator: 'equals', value: 5 }, { score: '5' }));
  });

  test('contains is case-insensitive', () => {
    assert.ok(conditionHolds({ field: 'company', operator: 'contains', value: 'ACME' }, { company: 'acme ltd' }));
  });

  test('is_set treats an empty string as not set', () => {
    assert.ok(!conditionHolds({ field: 'email', operator: 'is_set' }, { email: '' }));
    assert.ok(conditionHolds({ field: 'email', operator: 'is_not_set' }, { email: null }));
  });

  test('a non-numeric comparison is false rather than a crash', () => {
    assert.equal(
      conditionHolds({ field: 'score', operator: 'greater_than', value: 5 }, { score: 'high' }),
      false,
    );
    assert.equal(
      conditionHolds({ field: 'score', operator: 'less_than', value: 5 }, { score: null }),
      false,
      'null coerces to 0, which would otherwise make "less than 5" true for a missing field',
    );
  });

  test('an empty string is not a number, so a numeric comparison is false', () => {
    // Number('') is 0, so without the guard "daysSinceActivity is less than 5"
    // was TRUE for a lead whose field arrived blank — a re-engagement task for
    // every lead with no data. Found by mutation testing, not by reading it.
    assert.equal(
      conditionHolds({ field: 'days', operator: 'less_than', value: 5 }, { days: '' }),
      false,
    );
    assert.equal(
      conditionHolds({ field: 'days', operator: 'less_than', value: 5 }, { days: '   ' }),
      false,
    );
    assert.equal(
      conditionHolds({ field: 'days', operator: 'greater_than', value: -1 }, { days: false }),
      false,
      'a boolean is not a quantity either',
    );
  });

  test('not_equals holds when the field is missing', () => {
    assert.ok(conditionHolds({ field: 'stage', operator: 'not_equals', value: 'won' }, {}));
  });

  test('every operator has a label for the interface', () => {
    for (const operator of Object.keys(OPERATOR_LABEL)) {
      assert.ok(OPERATOR_LABEL[operator as keyof typeof OPERATOR_LABEL].length > 0);
    }
  });
});

describe('evaluate', () => {
  test('a disabled rule does not match, and says why', () => {
    const outcome = evaluate(rule({ enabled: false }), { kind: 'lead_created', payload: {} });
    assert.equal(outcome.matched, false);
    assert.ok(outcome.matched === false && /switched off/.test(outcome.reason));
  });

  test('a rule listening for another trigger does not match, and says which', () => {
    const outcome = evaluate(rule({ trigger: 'crawl_completed' }), { kind: 'lead_created', payload: {} });
    assert.ok(outcome.matched === false && /A crawl finishes/.test(outcome.reason));
  });

  test('a failed condition names the condition and the actual value', () => {
    const outcome = evaluate(
      rule({ conditions: [{ field: 'score', operator: 'greater_than', value: 50 }] }),
      { kind: 'lead_created', payload: { score: 12 } },
    );
    assert.ok(outcome.matched === false);
    assert.match(outcome.reason, /score/);
    assert.match(outcome.reason, /12/);
  });

  test('a failed condition on a missing field says "not set" rather than "undefined"', () => {
    const outcome = evaluate(
      rule({ conditions: [{ field: 'score', operator: 'greater_than', value: 50 }] }),
      { kind: 'lead_created', payload: {} },
    );
    assert.ok(outcome.matched === false && /not set/.test(outcome.reason));
    assert.ok(outcome.matched === false && !/undefined/.test(outcome.reason));
  });

  test('all conditions must hold', () => {
    const candidate = rule({
      conditions: [
        { field: 'score', operator: 'greater_than', value: 10 },
        { field: 'email', operator: 'is_set' },
      ],
    });
    assert.equal(evaluate(candidate, { kind: 'lead_created', payload: { score: 20 } }).matched, false);
    assert.equal(
      evaluate(candidate, { kind: 'lead_created', payload: { score: 20, email: 'a@b.c' } }).matched,
      true,
    );
  });

  test('a match returns rendered actions attributed to the rule', () => {
    const outcome = evaluate(
      rule({
        id: 'rule-9',
        name: 'Named rule',
        actions: [{ kind: 'create_follow_up', template: 'Call the {{source}} lead.', offsetDays: 2 }],
      }),
      { kind: 'lead_created', payload: { source: 'website' } },
    );
    assert.ok(outcome.matched === true);
    const action = outcome.actions[0];
    assert.equal(action?.text, 'Call the website lead.');
    assert.equal(action?.offsetDays, 2);
    assert.equal(action?.ruleId, 'rule-9');
    assert.equal(action?.ruleName, 'Named rule');
  });

  test('an action with no offset is dated today rather than left undefined', () => {
    const outcome = evaluate(rule({}), { kind: 'lead_created', payload: {} });
    assert.ok(outcome.matched === true && outcome.actions[0]?.offsetDays === 0);
  });

  test('evaluating decides but does not act — the result is a plan', () => {
    const outcome = evaluate(rule({}), { kind: 'lead_created', payload: {} });
    assert.ok(outcome.matched === true);
    for (const action of outcome.actions) {
      assert.ok((ACTION_KINDS as readonly string[]).includes(action.kind));
      assert.equal(isOutboundAction(action.kind), false);
    }
  });
});
