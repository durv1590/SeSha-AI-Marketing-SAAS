import assert from 'node:assert/strict';
import { test, describe, beforeEach, afterEach } from 'node:test';

import {
  AiError,
  AnthropicProvider,
  GeminiProvider,
  OpenAiProvider,
  PROVIDERS,
  aiIsEnabled,
  allProviders,
  configuredProviders,
  defaultProvider,
  estimateTokens,
  isProviderName,
  publicStatus,
  userFacingMessage,
} from '../src/lib/ai/provider';

/**
 * Provider adapters.
 *
 * `fetch` is injected throughout, so these exercise the real request bodies,
 * the real response parsing and every error path without network access or
 * credentials. What is asserted hardest is the thing that matters most: an API
 * key must never leave the server, and a provider's raw error must never reach
 * the user.
 */

const ENV_KEYS = [
  'OPENAI_API_KEY',
  'ANTHROPIC_API_KEY',
  'GEMINI_API_KEY',
  'AI_PROVIDER',
  'OPENAI_BASE_URL',
  'ANTHROPIC_BASE_URL',
  'GEMINI_BASE_URL',
] as const;

let saved: Record<string, string | undefined> = {};

beforeEach(() => {
  saved = Object.fromEntries(ENV_KEYS.map((key) => [key, process.env[key]]));
  for (const key of ENV_KEYS) delete process.env[key];
});

afterEach(() => {
  for (const key of ENV_KEYS) {
    if (saved[key] === undefined) delete process.env[key];
    else process.env[key] = saved[key];
  }
});

const request = {
  system: 'You are a test.',
  messages: [{ role: 'user' as const, content: 'Hello.' }],
  maxOutputTokens: 100,
  temperature: 0.5,
  timeoutMs: 5_000,
};

function jsonResponse(body: unknown, status = 200, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json', ...headers },
  });
}

/* -------------------------------------------------------------------------- */
/* Registry                                                                   */
/* -------------------------------------------------------------------------- */

describe('registry', () => {
  test('all three providers from the brief exist', () => {
    assert.deepEqual([...PROVIDERS], ['openai', 'anthropic', 'gemini']);
    assert.equal(allProviders().length, 3);
  });

  test('every provider declares models with sane limits', () => {
    for (const provider of allProviders()) {
      assert.ok(provider.models.length > 0, `${provider.name} has no models`);
      for (const model of provider.models) {
        assert.ok(model.contextTokens > 1000, `${model.id} context looks wrong`);
        assert.ok(model.maxOutputTokens > 0);
        assert.ok(['fast', 'balanced', 'deep'].includes(model.tier));
      }
    }
  });

  test('nothing is configured without keys', () => {
    assert.deepEqual(configuredProviders(), []);
    assert.equal(aiIsEnabled(), false);
    assert.equal(defaultProvider(), null);
  });

  test('a key enables exactly that provider', () => {
    process.env.ANTHROPIC_API_KEY = 'test-key';
    assert.equal(aiIsEnabled(), true);
    assert.deepEqual(configuredProviders().map((p) => p.name), ['anthropic']);
    assert.equal(defaultProvider()?.name, 'anthropic');
  });

  test('AI_PROVIDER pins the choice', () => {
    process.env.OPENAI_API_KEY = 'a';
    process.env.GEMINI_API_KEY = 'b';
    process.env.AI_PROVIDER = 'gemini';
    assert.equal(defaultProvider()?.name, 'gemini');
  });

  test('pinning an unconfigured provider yields none rather than a silent fallback', () => {
    process.env.OPENAI_API_KEY = 'a';
    process.env.AI_PROVIDER = 'anthropic';
    assert.equal(defaultProvider(), null, 'should not quietly use a different provider');
  });

  test('isProviderName rejects anything else', () => {
    assert.equal(isProviderName('openai'), true);
    assert.equal(isProviderName('llama'), false);
    assert.equal(isProviderName(null), false);
  });
});

/* -------------------------------------------------------------------------- */
/* Key safety — the important suite                                           */
/* -------------------------------------------------------------------------- */

describe('API keys never leave the server', () => {
  test('publicStatus exposes capability flags, never a key', () => {
    process.env.OPENAI_API_KEY = 'sk-super-secret-value-1234567890';
    const status = publicStatus();
    const serialized = JSON.stringify(status);

    assert.ok(!serialized.includes('sk-super-secret-value-1234567890'), 'the key leaked');
    assert.ok(!/api[_-]?key/i.test(serialized), 'the payload mentions a key field');
    assert.equal(status.enabled, true);
    assert.equal(status.defaultProvider, 'openai');
  });

  test('publicStatus reports configuration without revealing values', () => {
    process.env.ANTHROPIC_API_KEY = 'secret';
    const status = publicStatus();
    const anthropic = status.providers.find((p) => p.name === 'anthropic');
    assert.equal(anthropic?.configured, true);
    assert.equal(Object.keys(anthropic ?? {}).length, 2, 'only name and configured');
  });

  test('the key goes in a HEADER, never in the URL', async () => {
    // A URL ends up in access logs, proxy logs and error reports.
    process.env.GEMINI_API_KEY = 'gemini-secret-key';
    let capturedUrl = '';
    let capturedHeaders: Record<string, string> = {};

    const fakeFetch: typeof fetch = async (url, init) => {
      capturedUrl = String(url);
      capturedHeaders = (init?.headers ?? {}) as Record<string, string>;
      return jsonResponse({
        candidates: [{ content: { parts: [{ text: 'ok' }] }, finishReason: 'STOP' }],
        usageMetadata: { promptTokenCount: 5, candidatesTokenCount: 2 },
      });
    };

    await new GeminiProvider().complete(request, 'gemini-2.5-flash', fakeFetch);
    assert.ok(!capturedUrl.includes('gemini-secret-key'), 'the key is in the URL');
    assert.equal(capturedHeaders['x-goog-api-key'], 'gemini-secret-key');
  });

  test('an unconfigured provider fails before any request is made', async () => {
    let called = false;
    const fakeFetch: typeof fetch = async () => {
      called = true;
      return jsonResponse({});
    };

    await assert.rejects(
      () => new OpenAiProvider().complete(request, 'gpt-4o', fakeFetch),
      (error: unknown) => {
        assert.ok(error instanceof AiError);
        assert.equal(error.code, 'not_configured');
        return true;
      },
    );
    assert.equal(called, false, 'a request was made with no key');
  });
});

/* -------------------------------------------------------------------------- */
/* Request shape                                                              */
/* -------------------------------------------------------------------------- */

describe('OpenAI adapter', () => {
  test('sends the system prompt as a message and parses the reply', async () => {
    process.env.OPENAI_API_KEY = 'k';
    let body: Record<string, unknown> = {};
    const fakeFetch: typeof fetch = async (_url, init) => {
      body = JSON.parse(String(init?.body)) as Record<string, unknown>;
      return jsonResponse({
        choices: [{ message: { content: 'answer' }, finish_reason: 'stop' }],
        usage: { prompt_tokens: 12, completion_tokens: 4 },
      });
    };

    const result = await new OpenAiProvider().complete(request, 'gpt-4o', fakeFetch);
    const messages = body.messages as { role: string; content: string }[];
    assert.equal(messages[0]?.role, 'system');
    assert.equal(result.text, 'answer');
    assert.deepEqual(result.usage, { inputTokens: 12, outputTokens: 4 });
    assert.equal(result.truncated, false);
  });

  test('flags truncation', async () => {
    process.env.OPENAI_API_KEY = 'k';
    const fakeFetch: typeof fetch = async () =>
      jsonResponse({ choices: [{ message: { content: 'cut' }, finish_reason: 'length' }] });
    const result = await new OpenAiProvider().complete(request, 'gpt-4o', fakeFetch);
    assert.equal(result.truncated, true);
  });

  test('maps a content filter to its own error code', async () => {
    process.env.OPENAI_API_KEY = 'k';
    const fakeFetch: typeof fetch = async () =>
      jsonResponse({ choices: [{ message: { content: '' }, finish_reason: 'content_filter' }] });
    await assert.rejects(
      () => new OpenAiProvider().complete(request, 'gpt-4o', fakeFetch),
      (error: unknown) => (error as AiError).code === 'content_filtered',
    );
  });
});

describe('Anthropic adapter', () => {
  test('sends the system prompt as a TOP-LEVEL field, not a message', async () => {
    process.env.ANTHROPIC_API_KEY = 'k';
    let body: Record<string, unknown> = {};
    const fakeFetch: typeof fetch = async (_url, init) => {
      body = JSON.parse(String(init?.body)) as Record<string, unknown>;
      return jsonResponse({
        content: [{ type: 'text', text: 'answer' }],
        stop_reason: 'end_turn',
        usage: { input_tokens: 9, output_tokens: 3 },
      });
    };

    const result = await new AnthropicProvider().complete(request, 'claude-sonnet-4-5', fakeFetch);
    assert.equal(body.system, 'You are a test.');
    const messages = body.messages as { role: string }[];
    assert.ok(!messages.some((m) => m.role === 'system'), 'system must not be in messages');
    assert.equal(result.text, 'answer');
    assert.deepEqual(result.usage, { inputTokens: 9, outputTokens: 3 });
  });

  test('concatenates multiple text parts', async () => {
    process.env.ANTHROPIC_API_KEY = 'k';
    const fakeFetch: typeof fetch = async () =>
      jsonResponse({
        content: [
          { type: 'text', text: 'one ' },
          { type: 'thinking', text: 'ignored' },
          { type: 'text', text: 'two' },
        ],
      });
    const result = await new AnthropicProvider().complete(request, 'claude-sonnet-4-5', fakeFetch);
    assert.equal(result.text, 'one two');
  });

  test('sends the version header', async () => {
    process.env.ANTHROPIC_API_KEY = 'k';
    let headers: Record<string, string> = {};
    const fakeFetch: typeof fetch = async (_url, init) => {
      headers = (init?.headers ?? {}) as Record<string, string>;
      return jsonResponse({ content: [{ type: 'text', text: 'x' }] });
    };
    await new AnthropicProvider().complete(request, 'claude-sonnet-4-5', fakeFetch);
    assert.ok(headers['anthropic-version']);
  });
});

describe('Gemini adapter', () => {
  test('maps assistant turns to the "model" role', async () => {
    process.env.GEMINI_API_KEY = 'k';
    let body: Record<string, unknown> = {};
    const fakeFetch: typeof fetch = async (_url, init) => {
      body = JSON.parse(String(init?.body)) as Record<string, unknown>;
      return jsonResponse({
        candidates: [{ content: { parts: [{ text: 'answer' }] }, finishReason: 'STOP' }],
        usageMetadata: { promptTokenCount: 7, candidatesTokenCount: 2 },
      });
    };

    await new GeminiProvider().complete(
      { ...request, messages: [{ role: 'assistant', content: 'prior' }] },
      'gemini-2.5-flash',
      fakeFetch,
    );
    const contents = body.contents as { role: string }[];
    assert.equal(contents[0]?.role, 'model');
  });

  test('treats a blocked prompt as a filter, not a generic failure', async () => {
    process.env.GEMINI_API_KEY = 'k';
    const fakeFetch: typeof fetch = async () =>
      jsonResponse({ promptFeedback: { blockReason: 'SAFETY' } });
    await assert.rejects(
      () => new GeminiProvider().complete(request, 'gemini-2.5-flash', fakeFetch),
      (error: unknown) => (error as AiError).code === 'content_filtered',
    );
  });
});

/* -------------------------------------------------------------------------- */
/* Error mapping                                                              */
/* -------------------------------------------------------------------------- */

describe('error handling', () => {
  const cases: [number, string, boolean][] = [
    [401, 'unauthorized', false],
    [403, 'unauthorized', false],
    [429, 'rate_limited', true],
    [413, 'context_too_long', false],
    [500, 'unavailable', true],
    [503, 'unavailable', true],
    [418, 'unknown', false],
  ];

  for (const [status, code, retryable] of cases) {
    test(`HTTP ${status} maps to ${code} (retryable: ${retryable})`, async () => {
      process.env.OPENAI_API_KEY = 'k';
      const fakeFetch: typeof fetch = async () => jsonResponse({ error: 'detail' }, status);
      await assert.rejects(
        () => new OpenAiProvider().complete(request, 'gpt-4o', fakeFetch),
        (error: unknown) => {
          const aiError = error as AiError;
          assert.equal(aiError.code, code);
          assert.equal(aiError.retryable, retryable);
          return true;
        },
      );
    });
  }

  test('honours Retry-After', async () => {
    process.env.OPENAI_API_KEY = 'k';
    const fakeFetch: typeof fetch = async () =>
      jsonResponse({}, 429, { 'retry-after': '30' });
    await assert.rejects(
      () => new OpenAiProvider().complete(request, 'gpt-4o', fakeFetch),
      (error: unknown) => (error as AiError).retryAfterSeconds === 30,
    );
  });

  test('a timeout is reported as a timeout', async () => {
    process.env.OPENAI_API_KEY = 'k';
    const fakeFetch: typeof fetch = async (_url, init) =>
      new Promise((_resolve, reject) => {
        init?.signal?.addEventListener('abort', () => {
          const error = new Error('aborted');
          error.name = 'AbortError';
          reject(error);
        });
      });

    await assert.rejects(
      () => new OpenAiProvider().complete({ ...request, timeoutMs: 20 }, 'gpt-4o', fakeFetch),
      (error: unknown) => (error as AiError).code === 'timeout',
    );
  });

  test('a network failure is unavailable, not a crash', async () => {
    process.env.OPENAI_API_KEY = 'k';
    const fakeFetch: typeof fetch = async () => {
      throw new Error('ECONNREFUSED');
    };
    await assert.rejects(
      () => new OpenAiProvider().complete(request, 'gpt-4o', fakeFetch),
      (error: unknown) => (error as AiError).code === 'unavailable',
    );
  });

  test('invalid JSON is a bad response', async () => {
    process.env.OPENAI_API_KEY = 'k';
    const fakeFetch: typeof fetch = async () => new Response('not json', { status: 200 });
    await assert.rejects(
      () => new OpenAiProvider().complete(request, 'gpt-4o', fakeFetch),
      (error: unknown) => (error as AiError).code === 'bad_response',
    );
  });

  test('an empty completion is rejected rather than returned', async () => {
    process.env.OPENAI_API_KEY = 'k';
    const fakeFetch: typeof fetch = async () => jsonResponse({ choices: [{ message: {} }] });
    await assert.rejects(
      () => new OpenAiProvider().complete(request, 'gpt-4o', fakeFetch),
      (error: unknown) => (error as AiError).code === 'bad_response',
    );
  });

  test('user-facing messages never leak provider detail', () => {
    const codes = [
      'not_configured', 'unauthorized', 'rate_limited', 'context_too_long',
      'content_filtered', 'timeout', 'unavailable', 'bad_response', 'unknown',
    ] as const;

    for (const code of codes) {
      const message = userFacingMessage(
        new AiError(code, 'org-abc123 quota exceeded for model gpt-4o key sk-xyz'),
      );
      assert.ok(!message.includes('sk-xyz'), `${code} leaked a key fragment`);
      assert.ok(!message.includes('org-abc123'), `${code} leaked an organisation id`);
      assert.ok(message.length > 10, `${code} has no useful message`);
    }
  });
});

/* -------------------------------------------------------------------------- */
/* Token estimation                                                           */
/* -------------------------------------------------------------------------- */

describe('token estimation', () => {
  test('empty text costs nothing', () => {
    assert.equal(estimateTokens(''), 0);
  });

  test('scales with length', () => {
    assert.ok(estimateTokens('x'.repeat(400)) > estimateTokens('x'.repeat(100)));
  });

  test('Devanagari costs more per character than Latin', () => {
    // A Hindi draft of the same visible length is a bigger request.
    const hindi = 'नमस्ते दुनिया यह एक परीक्षण है';
    const latin = 'x'.repeat(hindi.length);
    assert.ok(estimateTokens(hindi) > estimateTokens(latin));
  });
});
