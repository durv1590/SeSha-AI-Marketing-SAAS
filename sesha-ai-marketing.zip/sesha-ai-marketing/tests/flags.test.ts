import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import { PLANS, type PlanId } from '../src/content/plans';
import {
  CATEGORY_LABEL,
  FLAG_CATEGORIES,
  FLAG_DEFINITIONS,
  FLAG_KEYS,
  checkRule,
  emptyRule,
  evaluate,
  evaluateAll,
  flagDefinition,
  inRollout,
  isFlagKey,
  type FlagRule,
} from '../src/lib/flags';

const TARGET = { organizationId: 'org-1', plan: 'pro' as PlanId };

function rule(partial: Partial<FlagRule> & { key: string }): FlagRule {
  return { ...emptyRule(partial.key), ...partial };
}

describe('the five flag categories the brief names', () => {
  test('all exist and are labelled', () => {
    assert.deepEqual([...FLAG_CATEGORIES], ['ai_provider', 'module', 'beta', 'plan', 'experimental']);
    for (const category of FLAG_CATEGORIES) {
      assert.ok(CATEGORY_LABEL[category].length > 0, category);
    }
  });

  test('every category has at least one declared flag', () => {
    for (const category of FLAG_CATEGORIES) {
      assert.ok(
        FLAG_DEFINITIONS.some((definition) => definition.category === category),
        `${category} has no flags, so the category is a promise with nothing behind it`,
      );
    }
  });

  test('every flag has a description written for whoever is on call', () => {
    for (const definition of FLAG_DEFINITIONS) {
      assert.ok(definition.description.length > 40, definition.key);
      assert.ok(definition.label.length > 0, definition.key);
    }
  });

  test('keys are unique', () => {
    assert.equal(new Set(FLAG_KEYS).size, FLAG_KEYS.length);
  });

  test('the registry is fixed — an unknown key is not a flag', () => {
    assert.ok(isFlagKey('module.crawler'));
    assert.ok(!isFlagKey('module.crawler.v2'));
    assert.equal(flagDefinition('nope'), null);
  });

  test('a flag that needs something external says what', () => {
    for (const definition of FLAG_DEFINITIONS) {
      if (definition.requires === undefined) continue;
      assert.ok(definition.requires.length > 3, definition.key);
    }
    assert.ok(flagDefinition('plan.self_serve_checkout')?.requires);
  });

  test('experimental and beta flags default to off', () => {
    // A flag system whose failure mode is "on" turns a missing row into a launch.
    for (const definition of FLAG_DEFINITIONS) {
      if (definition.category !== 'experimental') continue;
      assert.equal(definition.defaultValue, false, definition.key);
    }
    assert.equal(flagDefinition('beta.report_sharing')?.defaultValue, false);
  });
});

describe('evaluation', () => {
  test('an unknown key is off, and says why', () => {
    const decision = evaluate('not.a.flag', TARGET, null);
    assert.equal(decision.enabled, false);
    assert.equal(decision.because, 'unknown_flag');
    assert.match(decision.explanation, /a typo cannot switch something on/);
  });

  test('with no rule, the declared default applies', () => {
    assert.equal(evaluate('module.crawler', TARGET, null).enabled, true);
    assert.equal(evaluate('beta.report_sharing', TARGET, null).enabled, false);
    assert.equal(evaluate('module.crawler', TARGET, null).because, 'default');
  });

  test('every decision carries an explanation', () => {
    for (const decision of evaluateAll(TARGET, [])) {
      assert.ok(decision.explanation.length > 20, decision.key);
    }
  });

  test('evaluateAll covers every declared flag', () => {
    const decisions = evaluateAll(TARGET, []);
    assert.equal(decisions.length, FLAG_DEFINITIONS.length);
    assert.deepEqual(decisions.map((decision) => decision.key).sort(), [...FLAG_KEYS].sort());
  });
});

describe('the kill switch beats everything', () => {
  const killed = rule({
    key: 'module.crawler',
    disabled: true,
    organizationIds: ['org-1'],
    plans: [...PLANS],
    rolloutPercent: 100,
  });

  test('even a named organization, a plan match and a 100% roll-out', () => {
    // At 2am the person on call needs one thing to turn off that nothing else
    // can re-enable.
    const decision = evaluate('module.crawler', TARGET, killed);
    assert.equal(decision.enabled, false);
    assert.equal(decision.because, 'kill_switch');
    assert.match(decision.explanation, /Nothing overrides this/);
  });

  test('for every flag, on every plan', () => {
    for (const definition of FLAG_DEFINITIONS) {
      for (const plan of PLANS) {
        const decision = evaluate(
          definition.key,
          { organizationId: 'org-1', plan },
          rule({ key: definition.key, disabled: true, organizationIds: ['org-1'], rolloutPercent: 100 }),
        );
        assert.equal(decision.enabled, false, `${definition.key} on ${plan}`);
      }
    }
  });
});

describe('precedence', () => {
  test('an exclusion beats an inclusion, a plan match and a roll-out', () => {
    // "Turn it off for this customer" is what support needs it for, so it has to
    // be reliable against everything below it.
    const decision = evaluate(
      'beta.report_sharing',
      TARGET,
      rule({
        key: 'beta.report_sharing',
        organizationIds: ['org-1'],
        excludedOrganizationIds: ['org-1'],
        plans: ['pro'],
        rolloutPercent: 100,
      }),
    );
    assert.equal(decision.enabled, false);
    assert.equal(decision.because, 'organization_excluded');
  });

  test('a named organization beats the plan and the roll-out', () => {
    const decision = evaluate(
      'beta.report_sharing',
      TARGET,
      rule({ key: 'beta.report_sharing', organizationIds: ['org-1'], rolloutPercent: 0 }),
    );
    assert.equal(decision.enabled, true);
    assert.equal(decision.because, 'organization_included');
  });

  test('a plan match beats the roll-out', () => {
    const decision = evaluate(
      'beta.report_sharing',
      TARGET,
      rule({ key: 'beta.report_sharing', plans: ['pro'], rolloutPercent: 0 }),
    );
    assert.equal(decision.enabled, true);
    assert.equal(decision.because, 'plan');
  });

  test('a plan the target is not on does not match', () => {
    const decision = evaluate(
      'beta.report_sharing',
      TARGET,
      rule({ key: 'beta.report_sharing', plans: ['agency'] }),
    );
    assert.equal(decision.enabled, false);
    assert.equal(decision.because, 'default');
  });
});

describe('roll-out selection', () => {
  test('0% selects nobody and 100% selects everybody', () => {
    for (const id of ['a', 'b', 'zzz', 'org-1']) {
      assert.equal(inRollout(id, 0, 'k'), false, id);
      assert.equal(inRollout(id, 100, 'k'), true, id);
    }
  });

  test('is STABLE — the same organization gets the same answer every time', () => {
    // A Math.random() roll-out flickers a feature on and off between page loads,
    // which users report as the product being broken. They are right.
    const first = inRollout('org-1', 50, 'beta.report_sharing');
    for (let index = 0; index < 50; index += 1) {
      assert.equal(inRollout('org-1', 50, 'beta.report_sharing'), first);
    }
  });

  test('two flags at the same percentage do not select the same cohort', () => {
    // Otherwise one unlucky set of customers receives every experiment.
    const ids = Array.from({ length: 400 }, (_unused, index) => `org-${index}`);
    const a = new Set(ids.filter((id) => inRollout(id, 25, 'flag.a')));
    const b = new Set(ids.filter((id) => inRollout(id, 25, 'flag.b')));
    const overlap = [...a].filter((id) => b.has(id)).length;
    assert.ok(a.size > 0 && b.size > 0);
    assert.ok(
      overlap < a.size,
      'the two cohorts are identical, so the flag key is not mixed into the hash',
    );
  });

  test('the slice is roughly the requested size', () => {
    const ids = Array.from({ length: 4000 }, (_unused, index) => `org-${index}`);
    const selected = ids.filter((id) => inRollout(id, 30, 'flag.a')).length;
    const ratio = selected / ids.length;
    assert.ok(ratio > 0.26 && ratio < 0.34, `got ${(ratio * 100).toFixed(1)}%`);
  });

  test('growing a roll-out never drops anyone already inside it', () => {
    // Shrinking then regrowing is fine; losing a customer when you INCREASE the
    // percentage would take a feature away from someone who had it.
    const ids = Array.from({ length
      : 500 }, (_unused, index) => `org-${index}`);
    for (const id of ids) {
      if (inRollout(id, 20, 'flag.a')) {
        assert.equal(inRollout(id, 50, 'flag.a'), true, id);
      }
    }
  });
});

describe('checkRule', () => {
  test('accepts a sane rule', () => {
    assert.deepEqual(checkRule({ key: 'beta.report_sharing', rolloutPercent: 25, plans: ['pro'] }), []);
  });

  test('rejects an unknown flag', () => {
    assert.equal(checkRule({ key: 'made.up' }).length, 1);
  });

  test('rejects an out-of-range or fractional percentage', () => {
    assert.ok(checkRule({ key: 'beta.report_sharing', rolloutPercent: 101 }).length > 0);
    assert.ok(checkRule({ key: 'beta.report_sharing', rolloutPercent: -1 }).length > 0);
    assert.ok(checkRule({ key: 'beta.report_sharing', rolloutPercent: 12.5 }).length > 0);
  });

  test('rejects an unknown plan', () => {
    assert.ok(
      checkRule({ key: 'beta.report_sharing', plans: ['enterprise' as PlanId] }).length > 0,
    );
  });

  test('rejects an organization that is both included and excluded', () => {
    const problems = checkRule({
      key: 'beta.report_sharing',
      organizationIds: ['org-1'],
      excludedOrganizationIds: ['org-1'],
    });
    assert.equal(problems.length, 1);
    assert.match(problems[0] ?? '', /Exclusion would win/);
  });
});
