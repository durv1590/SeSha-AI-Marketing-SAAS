import assert from 'node:assert/strict';
import { test, describe } from 'node:test';
import { readFileSync, readdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { TABLES } from '../src/lib/db/types';

/**
 * Phase 9 database audit, as a test so it cannot regress.
 *
 * Parses the generated db/schema.sql (which a separate test keeps in step with
 * the migrations). No PostgreSQL server has ever run these migrations in the
 * development environment, so this is structural verification, not execution.
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const migrationsDir = path.join(root, 'db', 'migrations');
const schema = readFileSync(path.join(root, 'db', 'schema.sql'), 'utf8').replace(/--[^\n]*/g, '');

const tables = new Map<string, string>();
for (const match of schema.matchAll(/CREATE TABLE (?:IF NOT EXISTS )?(\w+)\s*\(([\s\S]*?)\n\);/g)) {
  tables.set(match[1]!, match[2]!);
}

const rls = new Set([...schema.matchAll(/ALTER TABLE (\w+)\s+ENABLE ROW LEVEL SECURITY/g)].map((m) => m[1]!));
for (const block of schema.matchAll(/DO \$\$([\s\S]*?)\$\$/g)) {
  if (!block[1]!.includes('ROW LEVEL SECURITY')) continue;
  for (const array of block[1]!.matchAll(/ARRAY\[([^\]]*)\]/g)) {
    for (const name of array[1]!.matchAll(/'(\w+)'/g)) rls.add(name[1]!);
  }
}

/** (table, leading column) for every index, primary key and unique constraint. */
const leading = new Set<string>();
for (const match of schema.matchAll(/CREATE (?:UNIQUE )?INDEX (?:IF NOT EXISTS )?\w+\s+ON (\w+)\s*(?:USING \w+\s*)?\(([^;]*?)\)/g)) {
  leading.add(`${match[1]}.${match[2]!.split(',')[0]!.trim().split(/\s/)[0]}`);
}
for (const [table, body] of tables) {
  for (const match of body.matchAll(/(?:UNIQUE|PRIMARY KEY)\s*\(([^)]*)\)/g)) {
    leading.add(`${table}.${match[1]!.split(',')[0]!.trim()}`);
  }
  for (const line of body.split('\n')) {
    const inline = /^\s*(\w+)\s+\w+.*\b(PRIMARY KEY|UNIQUE)\b/.exec(line);
    if (inline) leading.add(`${table}.${inline[1]}`);
  }
}

function foreignKeys(): string[] {
  const out: string[] = [];
  for (const [table, body] of tables) {
    for (const line of body.split('\n')) {
      const match = /^\s*(\w+)\s+.*REFERENCES\s+(\w+)/.exec(line);
      if (match && match[1] !== 'CONSTRAINT' && match[1] !== 'FOREIGN') out.push(`${table}.${match[1]}`);
    }
  }
  for (const match of schema.matchAll(/ALTER TABLE (\w+)\s+ADD COLUMN (?:IF NOT EXISTS )?(\w+)[^;,]*REFERENCES/g)) {
    out.push(`${match[1]}.${match[2]}`);
  }
  return out;
}

/**
 * Tables deliberately WITHOUT row-level security, each for a stated reason.
 * They are read before a tenant is known (auth), or are platform-level and only
 * reachable through the staff-gated admin repository.
 */
const NO_RLS_BY_DESIGN: Record<string, string> = {
  users: 'read at sign-in, before any tenant is known',
  sessions: 'resolved from a cookie before the tenant is known',
  memberships: 'the table that DETERMINES the tenant',
  organizations: 'looked up by id from a membership',
  oauth_accounts: 'sign-in',
  email_verification_tokens: 'sign-up flow',
  password_reset_tokens: 'reset flow, signed out',
  login_attempts: 'lockout, signed out',
  audit_log: 'append-only security log; tenant reads are filtered by organization_id in code',
  contact_submissions: 'public website form, no tenant',
  newsletter_subscribers: 'public website form, no tenant',
  platform_staff: 'platform admin, staff-gated',
  admin_actions: 'platform admin, staff-gated',
  error_events: 'platform admin, staff-gated',
  feature_flag_rules: 'platform admin, staff-gated',
  system_settings: 'platform admin, staff-gated',
};

describe('database audit', () => {
  test('the schema matches the table registry', () => {
    assert.equal(tables.size, TABLES.length);
    for (const name of TABLES) assert.ok(tables.has(name), `${name} is registered but not in schema.sql`);
  });

  test('EVERY FOREIGN KEY HAS AN INDEX leading with it', () => {
    const unindexed = foreignKeys().filter((key) => !leading.has(key));
    assert.deepEqual(unindexed, [], 'a parent DELETE will sequentially scan these child tables');
  });

  test('every tenant table has row-level security, and every exception is justified', () => {
    const missing = [...tables.keys()].filter((name) => !rls.has(name) && !(name in NO_RLS_BY_DESIGN));
    assert.deepEqual(missing, []);
    // And the allow-list does not rot: each entry is a real table without RLS.
    for (const name of Object.keys(NO_RLS_BY_DESIGN)) {
      assert.ok(tables.has(name), `${name} is allow-listed but does not exist`);
      assert.ok(!rls.has(name), `${name} now has RLS; remove it from the allow-list`);
    }
  });

  test('every migration is one transaction and is forward-only', () => {
    for (const file of readdirSync(migrationsDir).filter((name) => name.endsWith('.sql'))) {
      const sql = readFileSync(path.join(migrationsDir, file), 'utf8').replace(/--[^\n]*/g, '');
      assert.equal((sql.match(/^BEGIN;/gm) ?? []).length, 1, `${file}: not exactly one BEGIN`);
      assert.equal((sql.match(/^COMMIT;/gm) ?? []).length, 1, `${file}: not exactly one COMMIT`);
      if (!file.startsWith('0001')) {
        assert.ok(!/DROP TABLE(?! IF EXISTS \w+_tmp)/i.test(sql), `${file} drops a table`);
        assert.ok(!/DROP COLUMN/i.test(sql), `${file} drops a column`);
      }
    }
  });

  test('migrations are numbered contiguously', () => {
    const numbers = readdirSync(migrationsDir)
      .filter((name) => name.endsWith('.sql'))
      .map((name) => Number(name.slice(0, 4)))
      .sort((a, b) => a - b);
    numbers.forEach((number, index) => assert.equal(number, index + 1));
  });

  test('every tenant table carries a NOT NULL organization_id', () => {
    const offenders: string[] = [];
    for (const [name, body] of tables) {
      if (!rls.has(name)) continue;
      const column = /^\s*organization_id\s+[^\n]*/m.exec(body)?.[0] ?? '';
      if (!column) continue; // RLS via a parent join (e.g. per-project rows)
      // Nullable by design: idempotency keys for provider webhooks and feedback
      // sent before an organization exists belong to no tenant yet.
      if (!/NOT NULL/.test(column) && !['idempotency_keys', 'feedback'].includes(name)) offenders.push(name);
    }
    assert.deepEqual(offenders, []);
  });
});
