import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  REPORT_KINDS,
  REPORT_LABEL,
  REPORT_PURPOSE,
  REPORT_SPAN_DAYS,
  SECTION_IDS,
  SECTION_QUESTION,
  isReportKind,
  orderedSections,
  pointCount,
  section,
  type Report,
} from '../src/lib/reports/types';
import {
  REPORT_METRICS,
  generateReport,
  reportSummary,
  reportTitle,
  type ReportFacts,
} from '../src/lib/reports/generate';
import {
  EXPORT_FORMATS,
  EXPORT_MIME,
  csvField,
  exportFilename,
  isExportFormat,
  metricsCsv,
  sourceColumn,
  toCsv,
  toJson,
} from '../src/lib/reports/export';
import {
  PAGE_HEIGHT,
  PAGE_WIDTH,
  charWidth,
  encodeWinAnsi,
  escapePdfString,
  pdfTextString,
  renderPdf,
  textWidth,
  toPdfBytes,
  wrapText,
} from '../src/lib/reports/pdf';
import {
  DEFAULT_SHARE_DAYS,
  MAX_SHARE_DAYS,
  SHARE_DENIED_MESSAGE,
  checkShare,
  createShareToken,
  hashShareToken,
  looksLikeShareToken,
  sharePath,
  tokenHashesMatch,
} from '../src/lib/reports/share';
import { connectionStates } from '../src/lib/analytics/connections';
import { METRICS, unavailable, type Metric, type MetricValue } from '../src/lib/analytics/metrics';

const AS_OF = '2026-03-01T00:00:00.000Z';

function calculated(value: number, unit: Metric['definition']['unit'] = 'count'): MetricValue {
  return { kind: 'calculated', value, unit, formula: 'Counted from your own pipeline.', inputs: [], asOf: AS_OF };
}

function metric(id: Metric['id'], value: MetricValue, previous?: MetricValue): Metric {
  return { id, definition: METRICS[id], value, ...(previous ? { previous } : {}) };
}

const EMPTY_ACTIVITY = {
  contentCreated: 0,
  contentApproved: 0,
  leadsCreated: 0,
  leadsWon: 0,
  leadsLost: 0,
  calendarDone: 0,
  calendarPlanned: 0,
  calendarSkipped: 0,
  automationRuns: 0,
  automationActions: 0,
};

function facts(partial: Partial<ReportFacts> = {}): ReportFacts {
  return {
    kind: partial.kind ?? 'weekly',
    id: partial.id ?? 'rep-1',
    organizationName: partial.organizationName ?? 'Acme Ltd',
    period: partial.period ?? { from: '2026-03-02', to: '2026-03-08', label: 'Week of 2 March' },
    generatedAt: partial.generatedAt ?? AS_OF,
    metrics: partial.metrics ?? [],
    connections: partial.connections ?? connectionStates([]),
    activity: partial.activity ?? EMPTY_ACTIVITY,
    campaigns: partial.campaigns ?? [],
    pages: partial.pages ?? [],
    causes: partial.causes ?? [],
    recommendations: partial.recommendations ?? [],
  };
}

describe('the nine report kinds', () => {
  test('are exactly the ones the brief names', () => {
    assert.deepEqual(
      [...REPORT_KINDS],
      ['daily', 'weekly', 'monthly', 'campaign', 'seo', 'aeo', 'schema', 'social', 'executive'],
    );
  });

  test('each has a label, a purpose and a span', () => {
    for (const kind of REPORT_KINDS) {
      assert.ok(REPORT_LABEL[kind].length > 0, kind);
      assert.ok(REPORT_PURPOSE[kind].length > 15, kind);
      assert.ok(REPORT_SPAN_DAYS[kind] > 0, kind);
      assert.ok(REPORT_METRICS[kind].length > 0, kind);
    }
  });

  test('a report covers only its own metrics', () => {
    assert.ok(!REPORT_METRICS.seo.includes('cpc'), 'an SEO report with a cost-per-click is a dashboard');
    assert.ok(!REPORT_METRICS.social.includes('seo_score'));
    assert.ok(REPORT_METRICS.campaign.includes('roas'));
  });

  test('isReportKind rejects anything else', () => {
    assert.ok(isReportKind('executive'));
    assert.ok(!isReportKind('quarterly'));
  });
});

describe('the six sections', () => {
  test('are the brief’s six questions', () => {
    assert.equal(SECTION_IDS.length, 6);
    for (const id of SECTION_IDS) assert.match(SECTION_QUESTION[id], /\?$/);
  });

  test('orderedSections fills any that were not built, with a reason', () => {
    const ordered = orderedSections([section('why', [{ text: 'A cause.' }], 'none')]);
    assert.equal(ordered.length, 6);
    assert.deepEqual(ordered.map((entry) => entry.id), [...SECTION_IDS]);
    const missing = ordered.find((entry) => entry.id === 'what_next');
    assert.ok(missing?.emptyReason);
  });

  test('an empty section always carries a reason rather than reading as "nothing to report"', () => {
    const empty = section('what_next', [], 'Because there were no findings.');
    assert.equal(empty.points.length, 0);
    assert.ok(empty.emptyReason);
  });
});

describe('generating a report with nothing connected', () => {
  const report = generateReport(
    facts({
      metrics: [
        metric('leads', calculated(4)),
        metric('conversion', unavailable('Nothing closed.', 'Mark a lead Won.')),
        metric('traffic', unavailable('No analytics.', 'Connect Google Analytics.')),
      ],
      activity: { ...EMPTY_ACTIVITY, leadsCreated: 4, contentCreated: 2, contentApproved: 1 },
    }),
  );

  test('says plainly that nothing is connected', () => {
    assert.equal(report.provenance.anyConnected, false);
    assert.deepEqual(report.provenance.connectedSources, []);
    assert.match(report.provenance.note, /No analytics, advertising or social account is connected/);
  });

  test('all six sections are present and in the brief’s order', () => {
    assert.deepEqual(report.sections.map((entry) => entry.id), [...SECTION_IDS]);
  });

  test('reports the figures it genuinely has', () => {
    const what = report.sections.find((entry) => entry.id === 'what_happened');
    assert.ok(what?.points.some((point) => point.text.includes('Leads: 4')));
  });

  test('reports activity even when every figure is unavailable', () => {
    const barren = generateReport(
      facts({
        metrics: [metric('traffic', unavailable('No analytics.', 'Connect it.'))],
        activity: { ...EMPTY_ACTIVITY, contentCreated: 3, contentApproved: 3 },
      }),
    );
    const what = barren.sections.find((entry) => entry.id === 'what_happened');
    assert.ok(what?.points.some((point) => /3 content items created/.test(point.text)));
  });

  test('never puts a figure next to an unavailable metric', () => {
    for (const entry of report.metrics) {
      if (entry.value.kind === 'unavailable') {
        assert.ok(!('value' in entry.value));
      }
    }
    const what = report.sections.find((entry) => entry.id === 'what_happened');
    assert.ok(!what?.points.some((point) => /Traffic: \d/.test(point.text)));
  });

  test('the "why" section names the absence of measurement rather than inventing a cause', () => {
    const why = report.sections.find((entry) => entry.id === 'why');
    const text = why?.points.map((point) => `${point.text} ${point.detail ?? ''}`).join(' ') ?? '';
    assert.match(text, /could not be measured/);
    assert.match(text, /not a dip/);
  });

  test('refuses to advise on budget it cannot see', () => {
    const campaignReport = generateReport(
      facts({
        kind: 'campaign',
        metrics: [
          metric('cpc', unavailable('No ads account.', 'Connect Google Ads.')),
          metric('roas', unavailable('No ads account.', 'Connect Google Ads.')),
        ],
      }),
    );
    const where = campaignReport.sections.find((entry) => entry.id === 'where_to_review');
    const text = where?.points.map((point) => `${point.text} ${point.detail ?? ''}`).join(' ') ?? '';
    assert.match(text, /Budget cannot be reviewed from SeSha/);
    assert.match(text, /will not suggest moving money it cannot see/);
  });

  test('the summary counts measured against total rather than claiming completeness', () => {
    assert.match(reportSummary(report), /1 of 3 figures measured/);
  });

  test('the title names the organization and the period', () => {
    assert.equal(
      reportTitle('weekly', { from: 'a', to: 'b', label: 'Week of 2 March' }, 'Acme Ltd'),
      'Weekly report — Acme Ltd — Week of 2 March',
    );
  });
});

describe('generating a report with real findings', () => {
  const report = generateReport(
    facts({
      kind: 'seo',
      metrics: [metric('seo_score', calculated(72, 'score'), calculated(64, 'score'))],
      pages: [
        {
          url: 'https://example.com/pricing',
          issues: [{ label: 'Missing title', severity: 'error', area: 'SEO' }],
        },
        { url: 'https://example.com/about', issues: [], lostMarkup: ['Organization'] },
      ],
      campaigns: [
        { id: 'c1', name: 'Spring', platform: 'Google Ads', status: 'declined', planned: 3, done: 0, declinedReason: 'No landing page' },
        { id: 'c2', name: 'Summer', platform: 'Meta Ads', status: 'planned', planned: 4, done: 0 },
      ],
      causes: [{ what: 'The crawl stopped early.', effect: 'Only 20 of 90 pages were seen.', evidence: ['crawl-7'] }],
      recommendations: [{ text: 'Fix the missing titles.', reason: 'Four pages have none.' }],
      activity: { ...EMPTY_ACTIVITY, calendarDone: 1, calendarSkipped: 4 },
    }),
  );

  test('shows the direction of a change and says when it is the wrong way', () => {
    const what = report.sections.find((entry) => entry.id === 'what_happened');
    const point = what?.points.find((entry) => entry.text.startsWith('SEO score'));
    assert.match(point?.detail ?? '', /Up 13%/);
    assert.ok(!/wrong direction/.test(point?.detail ?? ''), 'a rising SEO score is the right direction');
  });

  test('a rise in a metric where up is bad is called out', () => {
    const worse = generateReport(
      facts({ kind: 'schema', metrics: [metric('schema_issues', calculated(9), calculated(3))] }),
    );
    const what = worse.sections.find((entry) => entry.id === 'what_happened');
    assert.match(what?.points[0]?.detail ?? '', /wrong direction/);
  });

  test('a real cause is used instead of the generic absence note', () => {
    const why = report.sections.find((entry) => entry.id === 'why');
    assert.ok(why?.points.some((point) => /crawl stopped early/.test(point.text)));
    assert.ok(why?.points.some((point) => point.evidence?.includes('crawl-7')));
  });

  test('lost markup is reported as lost, not as a finding', () => {
    const pages = report.sections.find((entry) => entry.id === 'which_pages');
    const about = pages?.points.find((point) => point.text.includes('/about'));
    assert.match(about?.detail ?? '', /used to be published here is gone/);
  });

  test('a declined campaign appears as a decision that is waiting', () => {
    const where = report.sections.find((entry) => entry.id === 'where_to_review');
    assert.ok(where?.points.some((point) => /Spring is waiting on a decision/.test(point.text)));
  });

  test('a stalled campaign is called out without pretending to know why', () => {
    const where = report.sections.find((entry) => entry.id === 'where_to_review');
    assert.ok(where?.points.some((point) => /Summer has 4 planned entries and nothing completed/.test(point.text)));
  });

  test('a calendar being skipped more than completed is raised as capacity, not failure', () => {
    const where = report.sections.find((entry) => entry.id === 'where_to_review');
    const point = where?.points.find((entry) => /skipped more than/.test(entry.text));
    assert.match(point?.detail ?? '', /capacity/);
  });

  test('is deterministic — the same facts produce the same report', () => {
    const again = generateReport(
      facts({
        kind: 'seo',
        metrics: [metric('seo_score', calculated(72, 'score'), calculated(64, 'score'))],
        pages: [
          { url: 'https://example.com/pricing', issues: [{ label: 'Missing title', severity: 'error', area: 'SEO' }] },
          { url: 'https://example.com/about', issues: [], lostMarkup: ['Organization'] },
        ],
        campaigns: [
          { id: 'c1', name: 'Spring', platform: 'Google Ads', status: 'declined', planned: 3, done: 0, declinedReason: 'No landing page' },
          { id: 'c2', name: 'Summer', platform: 'Meta Ads', status: 'planned', planned: 4, done: 0 },
        ],
        causes: [{ what: 'The crawl stopped early.', effect: 'Only 20 of 90 pages were seen.', evidence: ['crawl-7'] }],
        recommendations: [{ text: 'Fix the missing titles.', reason: 'Four pages have none.' }],
        activity: { ...EMPTY_ACTIVITY, calendarDone: 1, calendarSkipped: 4 },
      }),
    );
    assert.deepEqual(again, report);
  });

  test('pointCount walks every section', () => {
    assert.equal(
      pointCount(report),
      report.sections.reduce((total, entry) => total + entry.points.length, 0),
    );
  });
});

/* -------------------------------------------------------------------------- */

const SAMPLE: Report = generateReport(
  facts({
    metrics: [
      metric('leads', calculated(4)),
      metric('traffic', unavailable('No analytics account is connected.', 'Connect Google Analytics in Settings.')),
    ],
    activity: { ...EMPTY_ACTIVITY, leadsCreated: 4, leadsWon: 1 },
    recommendations: [{ text: 'Write the pricing page.', reason: 'It is the page people ask about.' }],
  }),
);

describe('export: formats', () => {
  test('the brief’s three file formats exist with correct media types', () => {
    assert.deepEqual([...EXPORT_FORMATS], ['pdf', 'csv', 'json']);
    assert.equal(EXPORT_MIME.pdf, 'application/pdf');
    assert.match(EXPORT_MIME.csv, /^text\/csv/);
    assert.ok(isExportFormat('json'));
    assert.ok(!isExportFormat('xlsx'));
  });

  test('the filename is a safe slug with the right extension', () => {
    const name = exportFilename(SAMPLE, 'csv');
    assert.match(name, /^[a-z0-9-]+\.csv$/);
    assert.ok(!name.includes('/'));
  });
});

describe('export: JSON', () => {
  const parsed = JSON.parse(toJson(SAMPLE)) as {
    schema: string;
    metrics: { id: string; value: { kind: string; value?: number; why?: string } }[];
    sections: { id: string; points: unknown[]; emptyReason?: string }[];
  };

  test('is versioned', () => {
    assert.equal(parsed.schema, 'sesha.report.v1');
  });

  test('carries the discriminated value, not a flattened number', () => {
    const leads = parsed.metrics.find((entry) => entry.id === 'leads');
    assert.equal(leads?.value.kind, 'calculated');
    assert.equal(leads?.value.value, 4);
  });

  test('an unavailable metric is exported as unavailable, with its reason, and no number', () => {
    const traffic = parsed.metrics.find((entry) => entry.id === 'traffic');
    assert.equal(traffic?.value.kind, 'unavailable');
    assert.equal(traffic?.value.value, undefined);
    assert.match(traffic?.value.why ?? '', /No analytics account/);
  });

  test('every section is present, empty ones with their reason', () => {
    assert.equal(parsed.sections.length, 6);
    for (const entry of parsed.sections) {
      if (entry.points.length === 0) assert.ok(entry.emptyReason, entry.id);
    }
  });
});

describe('export: CSV', () => {
  const csv = toCsv(SAMPLE);

  test('escapes quotes, commas and newlines', () => {
    assert.equal(csvField('plain'), 'plain');
    assert.equal(csvField('a,b'), '"a,b"');
    assert.equal(csvField('say "hi"'), '"say ""hi"""');
    assert.equal(csvField('two\nlines'), '"two\nlines"');
  });

  test('neutralises a formula injection', () => {
    // A lead's company name is user-controlled and lands in an export that someone
    // opens in Excel. Without the guard, =HYPERLINK(...) runs on their machine.
    assert.equal(csvField('=1+1'), "'=1+1");
    assert.equal(csvField('@SUM(A1)'), "'@SUM(A1)");
    assert.equal(csvField('-2+3'), "'-2+3");
    assert.equal(csvField('+1'), "'+1");
  });

  test('carries a source column for every metric', () => {
    const metricsSection = metricsCsv(SAMPLE.metrics);
    assert.match(metricsSection.split('\r\n')[0] ?? '', /source/);
    assert.match(metricsSection, /Calculated by SeSha/);
  });

  test('exports an unavailable metric as a row with no value and the reason', () => {
    const lines = metricsCsv(SAMPLE.metrics).split('\r\n');
    const traffic = lines.find((line) => line.startsWith('Traffic'));
    assert.ok(traffic, 'dropping the row would let a reader conclude it was zero');
    assert.match(traffic, /Unavailable/);
    const cells = traffic.split(',');
    assert.equal(cells[1], '', 'the value cell must be empty, not 0');
  });

  test('the source column explains each kind', () => {
    assert.match(sourceColumn(calculated(1)), /Calculated by SeSha: /);
    assert.match(sourceColumn(unavailable('why', 'how')), /Unavailable: why/);
    assert.match(
      sourceColumn({ kind: 'connected_api', value: 1, unit: 'count', source: 'GA4', asOf: AS_OF }),
      /Connected API \(GA4\)/,
    );
    assert.match(
      sourceColumn({ kind: 'ai_estimate', band: 'very_high', basis: 'a guess' }),
      /AI estimate \(very high\)/,
    );
  });

  test('the file carries the connection caveat, not just the figures', () => {
    assert.match(csv, /No analytics, advertising or social account is connected/);
  });

  test('the narrative table carries the empty-section reasons', () => {
    assert.match(csv, /NARRATIVE/);
    assert.match(csv, /Which campaigns\?/);
  });
});

describe('export: PDF', () => {
  const pdf = renderPdf(SAMPLE);

  test('every byte of the document fits in one byte', () => {
    // The cross-reference offsets are computed as string lengths, which is only
    // correct while this holds.
    for (let index = 0; index < pdf.length; index += 1) {
      assert.ok(pdf.charCodeAt(index) <= 0xff, `character ${index} is outside latin1`);
    }
  });

  test('has a header, a trailer and an EOF marker', () => {
    assert.ok(pdf.startsWith('%PDF-1.7'));
    assert.ok(pdf.trimEnd().endsWith('%%EOF'));
    assert.match(pdf, /\/Type \/Catalog/);
    assert.match(pdf, /\/Type \/Pages/);
    assert.match(pdf, /\/Type \/Page\b/);
  });

  test('the cross-reference offsets point at their own objects', () => {
    const startxref = Number(/startxref\n(\d+)/.exec(pdf)?.[1]);
    assert.ok(Number.isFinite(startxref));
    assert.equal(pdf.slice(startxref, startxref + 4), 'xref');

    const table = pdf.slice(startxref);
    const entries = [...table.matchAll(/^(\d{10}) 00000 n $/gm)].map((match) => Number(match[1]));
    assert.ok(entries.length > 0);
    entries.forEach((offset, index) => {
      assert.equal(
        pdf.slice(offset, offset + String(index + 1).length + 6),
        `${index + 1} 0 obj`,
        `object ${index + 1} is not at its recorded offset`,
      );
    });
  });

  test('the size in the trailer matches the object count', () => {
    const size = Number(/\/Size (\d+)/.exec(pdf)?.[1]);
    const objects = [...pdf.matchAll(/^\d+ 0 obj$/gm)].length;
    assert.equal(size, objects + 1, 'the free object 0 is counted too');
  });

  test('every content stream declares its true length', () => {
    const streams = [...pdf.matchAll(/<< \/Length (\d+) >>\nstream\n([\s\S]*?)\nendstream/g)];
    assert.ok(streams.length > 0);
    for (const [, declared, body] of streams) {
      assert.equal(body!.length, Number(declared));
    }
  });

  test('the page boxes are A4-ish and consistent', () => {
    const boxes = [...pdf.matchAll(/\/MediaBox \[0 0 (\d+) (\d+)\]/g)];
    assert.ok(boxes.length > 0);
    for (const [, width, height] of boxes) {
      assert.equal(Number(width), PAGE_WIDTH);
      assert.equal(Number(height), PAGE_HEIGHT);
    }
  });

  test('uses only the standard faces, so nothing needs embedding', () => {
    const fonts = [...pdf.matchAll(/\/BaseFont \/([A-Za-z-]+)/g)].map((match) => match[1]);
    assert.deepEqual(new Set(fonts), new Set(['Helvetica', 'Helvetica-Bold', 'Helvetica-Oblique']));
    assert.ok(!pdf.includes('/FontFile'));
  });

  test('carries the honesty banner before any figure', () => {
    const banner = pdf.indexOf('No data source is connected.');
    const figure = pdf.indexOf('Leads: 4');
    assert.ok(banner > 0);
    assert.ok(figure > banner, 'the caveat must come first, because a PDF is read away from the screen');
  });

  test('says that unavailable figures are not zero', () => {
    assert.match(pdf, /they are not zero/);
  });

  test('prints the unavailable metric without a number', () => {
    assert.match(pdf, /Traffic: not measured/);
  });

  test('toPdfBytes produces the same bytes', () => {
    const bytes = toPdfBytes(SAMPLE);
    assert.equal(bytes.length, pdf.length);
    assert.equal(bytes[0], '%'.charCodeAt(0));
    assert.equal(bytes[1], 'P'.charCodeAt(0));
  });

  test('paginates a long report rather than running off the page', () => {
    const long = generateReport(
      facts({
        kind: 'seo',
        metrics: [metric('seo_score', calculated(70, 'score'))],
        pages: Array.from({ length: 25 }, (_unused, index) => ({
          url: `https://example.com/page-${index}`,
          issues: [{ label: 'Missing title', severity: 'error', area: 'SEO' }],
        })),
        recommendations: Array.from({ length: 20 }, (_unused, index) => ({
          text: `Recommendation ${index}`,
          reason: 'A reason long enough to wrap across more than one line of the page, several times over, so the layout is genuinely exercised.',
        })),
      }),
    );
    const rendered = renderPdf(long);
    const pages = [...rendered.matchAll(/\/Type \/Page\b/g)].length;
    assert.ok(pages > 1, 'a long report must break into pages');
    assert.match(rendered, /Page 1 of /);
  });
});

describe('PDF text handling', () => {
  test('escapes the characters that would break a PDF string', () => {
    assert.equal(escapePdfString('a(b)c'), 'a\\(b\\)c');
    assert.equal(escapePdfString('a\\b'), 'a\\\\b');
  });

  test('an Info-dictionary string with typography is written as UTF-16BE, not WinAnsi', () => {
    // The page content and the metadata use DIFFERENT encodings. Writing the
    // WinAnsi bytes here made readers show "SEO report S Acme Ltd".
    assert.equal(pdfTextString('plain ascii'), '(plain ascii)');
    assert.equal(pdfTextString('a—b'), '<FEFF006120140062>');
    assert.ok(pdfTextString('café').startsWith('<FEFF'));
    assert.match(pdfTextString('café'), /^<FEFF[0-9A-F]+>$/);
    assert.equal(pdfTextString('\u{1F600}'), '<FEFFD83DDE00>', 'surrogate pairs, as UTF-16BE requires');
  });

  test('the rendered document title survives a real PDF reader', () => {
    const rendered = renderPdf(SAMPLE);
    const info = /\/Title (\([^)]*\)|<[0-9A-F]+>)/.exec(rendered)?.[1] ?? '';
    assert.ok(info.length > 0);
    if (info.startsWith('<')) {
      const hex = info.slice(1, -1);
      assert.equal(hex.slice(0, 4), 'FEFF');
      let decoded = '';
      for (let index = 4; index < hex.length; index += 4) {
        decoded += String.fromCharCode(Number.parseInt(hex.slice(index, index + 4), 16));
      }
      assert.equal(decoded, SAMPLE.title);
    } else {
      assert.equal(info.slice(1, -1), SAMPLE.title);
    }
  });

  test('maps typography into WinAnsi rather than dropping it', () => {
    assert.equal(encodeWinAnsi('—').charCodeAt(0), 0x97);
    assert.equal(encodeWinAnsi('’').charCodeAt(0), 0x92);
    assert.equal(encodeWinAnsi('café').charCodeAt(3), 0xe9);
    assert.equal(encodeWinAnsi('₹'), 'INR ');
  });

  test('an unrepresentable character becomes a question mark rather than vanishing', () => {
    assert.equal(encodeWinAnsi('中'), '?');
  });

  test('encoding never produces a character above 0xFF', () => {
    const sample = 'Mixed — text ‘quoted’ with × and 中 and €.';
    for (const character of encodeWinAnsi(sample)) {
      assert.ok(character.charCodeAt(0) <= 0xff);
    }
  });

  test('character widths come from the real font metrics', () => {
    assert.equal(charWidth('i', 'regular'), 222);
    assert.equal(charWidth('W', 'regular'), 944);
    assert.equal(charWidth(' ', 'regular'), 278);
    assert.ok(charWidth('a', 'bold') >= charWidth('a', 'regular'));
    assert.equal(charWidth('a', 'italic'), charWidth('a', 'regular'));
  });

  test('wrapping keeps every line inside the width', () => {
    const text = 'The quick brown fox jumps over the lazy dog and keeps on running for quite some distance.';
    const lines = wrapText(text, 'regular', 10, 200);
    assert.ok(lines.length > 1);
    for (const line of lines) assert.ok(textWidth(line, 'regular', 10) <= 200, line);
    assert.equal(lines.join(' '), text, 'no word may be lost');
  });

  test('breaks a word too long for the line rather than overflowing', () => {
    const url = 'https://example.com/a/very/long/path/that/will/not/fit/on/one/line/at/all/ever';
    const lines = wrapText(url, 'regular', 10, 120);
    assert.ok(lines.length > 1);
    for (const line of lines) assert.ok(textWidth(line, 'regular', 10) <= 120, line);
    assert.equal(lines.join(''), url, 'the URL must still be reconstructable by the person fixing that page');
  });

  test('empty text yields one empty line rather than nothing', () => {
    assert.deepEqual(wrapText('   ', 'regular', 10, 100), ['']);
  });
});

describe('share links', () => {
  const now = new Date('2026-03-01T00:00:00.000Z');

  test('the token is random, long and url-safe', () => {
    const first = createShareToken(DEFAULT_SHARE_DAYS, now);
    const second = createShareToken(DEFAULT_SHARE_DAYS, now);
    assert.notEqual(first.token, second.token);
    assert.ok(looksLikeShareToken(first.token));
    assert.equal(first.token, encodeURIComponent(first.token));
  });

  test('only the hash is meant to be stored, and it is not the token', () => {
    const created = createShareToken(DEFAULT_SHARE_DAYS, now);
    assert.notEqual(created.tokenHash, created.token);
    assert.equal(created.tokenHash, hashShareToken(created.token));
    assert.match(created.tokenHash, /^[0-9a-f]{64}$/);
  });

  test('expiry is clamped to the maximum and never unlimited', () => {
    const forever = createShareToken(100000, now);
    const days = (forever.expiresAt.getTime() - now.getTime()) / 86_400_000;
    assert.equal(days, MAX_SHARE_DAYS);
    const minimum = createShareToken(0, now);
    assert.ok(minimum.expiresAt.getTime() > now.getTime());
  });

  test('an expired link is refused', () => {
    const created = createShareToken(1, now);
    const later = new Date(now.getTime() + 2 * 86_400_000);
    const check = checkShare({ tokenHash: created.tokenHash, expiresAt: created.expiresAt, revokedAt: null }, later);
    assert.equal(check.ok, false);
    assert.ok(check.ok === false && check.reason === 'expired');
  });

  test('revocation takes effect immediately', () => {
    const created = createShareToken(30, now);
    const check = checkShare(
      { tokenHash: created.tokenHash, expiresAt: created.expiresAt, revokedAt: now },
      now,
    );
    assert.ok(check.ok === false && check.reason === 'revoked');
  });

  test('an unknown token is refused', () => {
    assert.ok(checkShare(null, now).ok === false);
  });

  test('the message shown to a stranger does not distinguish the three failures', () => {
    assert.ok(!/expired|revoked|unknown/i.test(SHARE_DENIED_MESSAGE));
  });

  test('hash comparison is length-checked before the constant-time compare', () => {
    assert.ok(tokenHashesMatch('a'.repeat(64), 'a'.repeat(64)));
    assert.ok(!tokenHashesMatch('a'.repeat(64), 'b'.repeat(64)));
    assert.ok(!tokenHashesMatch('short', 'a'.repeat(64)));
  });

  test('a malformed token is rejected before any lookup', () => {
    assert.ok(!looksLikeShareToken('short'));
    assert.ok(!looksLikeShareToken('../../etc/passwd'));
    assert.ok(!looksLikeShareToken(null));
    assert.ok(!looksLikeShareToken(`${'a'.repeat(200)}`));
  });

  test('the share path is relative and escaped', () => {
    assert.equal(sharePath('abc'), '/share/abc');
    assert.ok(sharePath('a/b').startsWith('/share/'));
    assert.ok(!sharePath('a/b').slice('/share/'.length).includes('/'));
  });
});
