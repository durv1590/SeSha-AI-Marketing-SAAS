import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  CircuitBreaker,
  CircuitOpenError,
  IdempotencyStore,
  TimeoutError,
  attempt,
  backoffDelay,
  isRetryableStatus,
  isTransient,
  retry,
  withTimeout,
} from '../src/lib/reliability';

/**
 * Reliability primitives.
 *
 * Every one of these makes things worse if applied carelessly, so the tests are
 * mostly about the refusals: what does NOT get retried, what does NOT reopen a
 * breaker, what is NOT cached as an idempotent result.
 */

const noSleep = async () => {};

describe('timeouts', () => {
  test('a slow operation is cut off at the budget', async () => {
    await assert.rejects(
      () => withTimeout(20, () => new Promise((resolve) => setTimeout(resolve, 5_000)), 'slow thing'),
      (error: unknown) => {
        assert.ok(error instanceof TimeoutError);
        assert.match((error as TimeoutError).message, /slow thing exceeded its 20ms budget/);
        return true;
      },
    );
  });

  test('THE WORK IS TOLD TO STOP, not just abandoned', async () => {
    // A timeout that leaves the work running is a memory leak with good manners.
    let aborted = false;
    await assert.rejects(() =>
      withTimeout(20, (signal) => {
        signal.addEventListener('abort', () => {
          aborted = true;
        });
        return new Promise((resolve) => setTimeout(resolve, 5_000));
      }),
    );
    assert.equal(aborted, true, 'the abort signal never fired');
  });

  test('a prompt operation returns its value untouched', async () => {
    assert.equal(await withTimeout(1_000, async () => 42), 42);
  });

  test('an operation that throws its own error keeps that error', async () => {
    await assert.rejects(
      () =>
        withTimeout(1_000, async () => {
          throw new Error('domain failure');
        }),
      /domain failure/,
    );
  });
});

describe('what is worth retrying', () => {
  test('transient network codes are retryable', () => {
    for (const code of ['ETIMEDOUT', 'ECONNRESET', 'ECONNREFUSED', 'EAI_AGAIN']) {
      assert.equal(isTransient({ code }), true, `${code} was treated as permanent`);
    }
  });

  test('429 and the 5xx family are retryable', () => {
    assert.equal(isRetryableStatus(429), true);
    assert.equal(isRetryableStatus(500), true);
    assert.equal(isRetryableStatus(503), true);
  });

  test('A 4xx IS NOT RETRIED — it was wrong and will stay wrong', () => {
    for (const status of [400, 401, 403, 404, 409, 422]) {
      assert.equal(isRetryableStatus(status), false, `${status} would be retried`);
    }
  });

  test('501 and 505 are not retried either, despite being 5xx', () => {
    // "Not Implemented" will not become implemented between attempts.
    assert.equal(isRetryableStatus(501), false);
    assert.equal(isRetryableStatus(505), false);
  });

  test('AN UNRECOGNISED ERROR IS NOT RETRIED BY DEFAULT', () => {
    // Retrying what we do not understand doubles the load on something already
    // failing, for a reason nobody can name.
    assert.equal(isTransient(new Error('something odd')), false);
    assert.equal(isTransient('a string'), false);
    assert.equal(isTransient(null), false);
  });
});

describe('retries', () => {
  test('succeeds without retrying when the first attempt works', async () => {
    let calls = 0;
    const result = await retry(
      async () => {
        calls += 1;
        return 'ok';
      },
      { idempotent: true, sleep: noSleep },
    );
    assert.equal(result, 'ok');
    assert.equal(calls, 1);
  });

  test('retries a transient failure and returns the eventual success', async () => {
    let calls = 0;
    const result = await retry(
      async () => {
        calls += 1;
        if (calls < 3) throw Object.assign(new Error('flaky'), { code: 'ECONNRESET' });
        return 'recovered';
      },
      { idempotent: true, sleep: noSleep },
    );
    assert.equal(result, 'recovered');
    assert.equal(calls, 3);
  });

  test('A PERMANENT FAILURE IS NOT RETRIED AT ALL', async () => {
    let calls = 0;
    await assert.rejects(() =>
      retry(
        async () => {
          calls += 1;
          throw Object.assign(new Error('bad request'), { status: 400 });
        },
        { idempotent: true, sleep: noSleep },
      ),
    );
    assert.equal(calls, 1, `a 400 was attempted ${calls} times`);
  });

  test('gives up after the configured attempts and rethrows the last error', async () => {
    let calls = 0;
    await assert.rejects(
      () =>
        retry(
          async () => {
            calls += 1;
            throw Object.assign(new Error(`attempt ${calls}`), { code: 'ETIMEDOUT' });
          },
          { idempotent: true, attempts: 4, sleep: noSleep },
        ),
      /attempt 4/,
    );
    assert.equal(calls, 4);
  });

  test('reports each retry, so a log can show the pattern', async () => {
    const seen: number[] = [];
    await assert.rejects(() =>
      retry(
        async () => {
          throw Object.assign(new Error('x'), { code: 'ETIMEDOUT' });
        },
        {
          idempotent: true,
          attempts: 3,
          sleep: noSleep,
          onRetry: ({ attempt: number }) => seen.push(number),
        },
      ),
    );
    // Two retries between three attempts; the final failure is not a "retry".
    assert.deepEqual(seen, [1, 2]);
  });
});

describe('backoff', () => {
  test('grows exponentially, bounded by the ceiling', () => {
    // random() = 1 gives the top of the jitter window, which is the ceiling.
    const top = (attempt: number) =>
      backoffDelay(attempt, { baseDelayMs: 100, maxDelayMs: 5_000, random: () => 0.999 });
    assert.ok(top(1) < top(2) && top(2) < top(3), 'the delay does not grow');
    assert.ok(top(10) <= 5_000, 'the ceiling was exceeded');
  });

  test('IS FULLY JITTERED — two clients do not wait the same time', () => {
    // Without jitter, every waiting client retries in the same millisecond and
    // knocks the recovering service over again.
    const values = new Set(
      Array.from({ length: 200 }, () => backoffDelay(4, { baseDelayMs: 100 })),
    );
    assert.ok(values.size > 50, `only ${values.size} distinct delays across 200 draws`);
  });

  test('a jittered delay can be short, which is the point', () => {
    assert.equal(backoffDelay(5, { baseDelayMs: 100, random: () => 0 }), 0);
  });
});

describe('the circuit breaker', () => {
  function clockedBreaker(options = {}) {
    let now = 0;
    const breaker = new CircuitBreaker('test-provider', {
      failureThreshold: 3,
      resetAfterMs: 1_000,
      now: () => now,
      ...options,
    });
    return { breaker, advance: (ms: number) => (now += ms) };
  }

  const boom = async () => {
    throw new Error('downstream is down');
  };

  test('stays closed while failures are below the threshold', async () => {
    const { breaker } = clockedBreaker();
    await assert.rejects(() => breaker.run(boom));
    await assert.rejects(() => breaker.run(boom));
    assert.equal(breaker.currentState(), 'closed');
  });

  test('opens at the threshold and then refuses WITHOUT calling through', async () => {
    const { breaker } = clockedBreaker();
    for (let index = 0; index < 3; index += 1) await assert.rejects(() => breaker.run(boom));
    assert.equal(breaker.currentState(), 'open');

    let called = false;
    await assert.rejects(
      () =>
        breaker.run(async () => {
          called = true;
          return 'x';
        }),
      (error: unknown) => error instanceof CircuitOpenError,
    );
    assert.equal(called, false, 'the breaker was open and still called through');
  });

  test('A SUCCESS RESETS THE COUNT — failures must be consecutive', async () => {
    // A steady trickle of unrelated errors among mostly-successful traffic is
    // not an outage, and treating it as one takes a working service offline.
    const { breaker } = clockedBreaker();
    await assert.rejects(() => breaker.run(boom));
    await assert.rejects(() => breaker.run(boom));
    await breaker.run(async () => 'fine');
    await assert.rejects(() => breaker.run(boom));
    await assert.rejects(() => breaker.run(boom));
    assert.equal(breaker.currentState(), 'closed', 'non-consecutive failures opened the breaker');
  });

  test('moves to half-open once the window passes, and closes on a good probe', async () => {
    const { breaker, advance } = clockedBreaker();
    for (let index = 0; index < 3; index += 1) await assert.rejects(() => breaker.run(boom));
    assert.equal(breaker.currentState(), 'open');

    advance(1_000);
    assert.equal(breaker.currentState(), 'half_open');

    assert.equal(await breaker.run(async () => 'recovered'), 'recovered');
    assert.equal(breaker.currentState(), 'closed');
  });

  test('a failed probe goes straight back to open with a fresh window', async () => {
    const { breaker, advance } = clockedBreaker();
    for (let index = 0; index < 3; index += 1) await assert.rejects(() => breaker.run(boom));
    advance(1_000);
    assert.equal(breaker.currentState(), 'half_open');

    await assert.rejects(() => breaker.run(boom));
    assert.equal(breaker.currentState(), 'open');
    // The window restarted: still open immediately after.
    advance(999);
    assert.equal(breaker.currentState(), 'open');
  });

  test('HALF-OPEN LETS EXACTLY ONE REQUEST THROUGH', async () => {
    // Letting several through is how a recovering service is knocked over by
    // the probe itself.
    const { breaker, advance } = clockedBreaker();
    for (let index = 0; index < 3; index += 1) await assert.rejects(() => breaker.run(boom));
    advance(1_000);

    let concurrent = 0;
    let maxConcurrent = 0;
    const slow = async () => {
      concurrent += 1;
      maxConcurrent = Math.max(maxConcurrent, concurrent);
      await new Promise((resolve) => setTimeout(resolve, 20));
      concurrent -= 1;
      return 'ok';
    };

    const results = await Promise.allSettled([breaker.run(slow), breaker.run(slow), breaker.run(slow)]);
    assert.equal(maxConcurrent, 1, `${maxConcurrent} probes ran at once`);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
  });

  test('announces its state changes, so they can be logged', async () => {
    const changes: string[] = [];
    const { breaker, advance } = clockedBreaker({
      onStateChange: (from: string, to: string) => changes.push(`${from}->${to}`),
    });
    for (let index = 0; index < 3; index += 1) await assert.rejects(() => breaker.run(boom));
    advance(1_000);
    await breaker.run(async () => 'ok');
    assert.deepEqual(changes, ['closed->open', 'open->half_open', 'half_open->closed']);
  });
});

describe('idempotency', () => {
  test('runs once and replays the stored result', async () => {
    const store = new IdempotencyStore<string>();
    let calls = 0;
    const work = async () => {
      calls += 1;
      return `result-${calls}`;
    };

    const first = await store.once('key-1', work);
    const second = await store.once('key-1', work);

    assert.equal(calls, 1);
    assert.equal(first.replayed, false);
    assert.equal(second.replayed, true);
    assert.equal(second.result, first.result);
  });

  test('THE CONCURRENT CASE RUNS ONCE — which is the whole point', async () => {
    // A check-then-act "have I seen this key" still runs twice when two requests
    // arrive together, which is exactly when a double-submit happens.
    const store = new IdempotencyStore<string>();
    let calls = 0;
    const slow = async () => {
      calls += 1;
      await new Promise((resolve) => setTimeout(resolve, 20));
      return 'charged once';
    };

    const results = await Promise.all([
      store.once('same-key', slow),
      store.once('same-key', slow),
      store.once('same-key', slow),
    ]);

    assert.equal(calls, 1, `the operation ran ${calls} times concurrently`);
    for (const result of results) assert.equal(result.result, 'charged once');
  });

  test('A FAILURE IS NOT CACHED, so retrying with the same key still works', async () => {
    // Caching a failure turns a transient error into a permanent one, defeating
    // the retry that the idempotency key exists to make safe.
    const store = new IdempotencyStore<string>();
    let calls = 0;
    const flaky = async () => {
      calls += 1;
      if (calls === 1) throw new Error('transient');
      return 'succeeded on retry';
    };

    await assert.rejects(() => store.once('key-2', flaky));
    const second = await store.once('key-2', flaky);

    assert.equal(second.result, 'succeeded on retry');
    assert.equal(second.replayed, false);
  });

  test('different keys are independent', async () => {
    const store = new IdempotencyStore<string>();
    const a = await store.once('a', async () => 'A');
    const b = await store.once('b', async () => 'B');
    assert.equal(a.result, 'A');
    assert.equal(b.result, 'B');
  });

  test('a record past its ttl is run again', async () => {
    let now = 0;
    const store = new IdempotencyStore<number>(1_000, () => now);
    let calls = 0;
    const work = async () => {
      calls += 1;
      return calls;
    };

    await store.once('k', work);
    now += 1_001;
    const again = await store.once('k', work);
    assert.equal(again.replayed, false);
    assert.equal(calls, 2);
  });
});

describe('graceful degradation', () => {
  test('returns the value when the optional work succeeds', async () => {
    const result = await attempt(async () => 'panel data', 'unavailable');
    assert.equal(result.ok, true);
    if (result.ok) assert.equal(result.value, 'panel data');
  });

  test('THE FALLBACK IS LABELLED, not silently substituted', async () => {
    // A caller must not be able to present a fallback as though it were real —
    // the same reasoning as `MetricValue` in Phase 6.
    const result = await attempt(
      async () => {
        throw new Error('panel is down');
      },
      'unavailable',
      () => 'That panel could not be loaded.',
    );

    assert.equal(result.ok, false);
    if (!result.ok) {
      assert.equal(result.fallback, 'unavailable');
      assert.equal(result.reason, 'That panel could not be loaded.');
    }
  });

  test('the failure reason is produced by the caller, not the raw error', async () => {
    // The raw message may name internal detail; the caller decides what a user
    // is told.
    const result = await attempt(async () => {
      throw new Error('ECONNREFUSED 10.0.0.5:5432');
    }, null);
    assert.equal(result.ok, false);
    if (!result.ok) assert.ok(!result.reason.includes('10.0.0.5'));
  });
});
