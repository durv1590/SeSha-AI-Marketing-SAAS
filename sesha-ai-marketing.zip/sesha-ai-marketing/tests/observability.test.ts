import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  MAX_FIELD_LENGTH,
  MemorySink,
  REDACTED,
  createLogger,
  redact,
  redactString,
  requestId,
} from '../src/lib/observability/log';
import {
  COUNTERS,
  HISTOGRAMS,
  LATENCY_BUCKETS_MS,
  Metrics,
  percentile,
} from '../src/lib/observability/metrics';

/**
 * Observability, with the emphasis on what must NOT come out of it.
 *
 * The brief's instruction is a list of things not to log — passwords, API keys,
 * sensitive tokens, private user content — and the only way to keep that
 * promise at three in the morning is for it to be impossible to break by
 * forgetting. These tests are mostly about the redactor, because the redactor is
 * the promise.
 */

describe('redaction: keys that name a secret', () => {
  test('a secret key is replaced WITHOUT its value being inspected', () => {
    const out = redact({
      password: 'hunter2',
      newPassword: 'hunter3',
      apiKey: 'sk-live-abcdefghijklmnop',
      authorization: 'Bearer abc',
      cookie: 'session=x',
      clientSecret: 'shh',
    }) as Record<string, unknown>;

    for (const key of Object.keys(out)) {
      assert.equal(out[key], REDACTED, `${key} survived redaction`);
    }
  });

  test('the SUFFIX rules catch the names nobody thought to list', () => {
    const out = redact({
      openaiApiKey: 'x',
      webhookSecret: 'x',
      resetToken: 'x',
      adminPassword: 'x',
      // Separators are normalised before matching.
      'api-key': 'x',
      api_key: 'x',
    }) as Record<string, unknown>;

    for (const key of Object.keys(out)) {
      assert.equal(out[key], REDACTED, `${key} survived redaction`);
    }
  });

  test('an innocent key keeps its value', () => {
    const out = redact({ organizationId: 'org-1', count: 3, ok: true }) as Record<string, unknown>;
    assert.equal(out.organizationId, 'org-1');
    assert.equal(out.count, 3);
    assert.equal(out.ok, true);
  });

  test('a secret nested three levels down is still replaced', () => {
    const out = redact({ a: { b: { c: { password: 'hunter2' } } } }) as {
      a: { b: { c: { password: string } } };
    };
    assert.equal(out.a.b.c.password, REDACTED);
  });
});

describe('redaction: values that ARE secrets under innocent keys', () => {
  // The dangerous case: `{ detail: 'Authorization: Bearer sk-live-…' }`. The key
  // is blameless and the value is a credential.
  const cases: readonly [string, string][] = [
    ['bearer token', 'Authorization: Bearer abcdefghijklmnopqrstuvwxyz'],
    ['basic auth', 'Authorization: Basic YWxhZGRpbjpvcGVuc2VzYW1l'],
    ['openai key', 'request failed with key sk-proj-abcdefghijklmnopqrst'],
    ['stripe key', 'using sk_live_abcdefghijklmnop'],
    ['google key', 'AIzaSyA1234567890abcdefghijklmnopqrs'],
    ['github token', 'ghp_abcdefghijklmnopqrstuvwxyz12'],
    ['a jwt', 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dBjftJeZ4CVPmB92K27u'],
  ];

  for (const [name, value] of cases) {
    test(`a ${name} is scrubbed even under an innocent key`, () => {
      const out = redact({ detail: value }) as { detail: string };
      assert.ok(!out.detail.includes('abcdefghij'), `the ${name} survived: ${out.detail}`);
      assert.ok(out.detail.includes(REDACTED), `the ${name} was not marked as redacted`);
    });
  }

  test('ordinary prose is left alone', () => {
    const message = 'The crawl finished after 12 pages and found 3 problems.';
    assert.equal(redactString(message), message);
  });
});

describe('redaction: bounds', () => {
  test('a long string is cut, and says how long it was', () => {
    const out = redactString('x'.repeat(5_000));
    assert.ok(out.length < 700, `a ${out.length}-char field was written to a log line`);
    assert.match(out, /5000 chars/);
  });

  test('a long array is capped and says how many were dropped', () => {
    const out = redact(Array.from({ length: 100 }, (_, index) => index)) as unknown[];
    assert.ok(out.length <= 21);
    assert.match(String(out[out.length - 1]), /80 more/);
  });

  test('A CYCLIC OBJECT DOES NOT HANG THE LOGGER', () => {
    // A logger that can be hung by the thing it is logging is worse than no
    // logger: it takes the request down with it.
    const cyclic: Record<string, unknown> = { name: 'loop' };
    cyclic.self = cyclic;
    const out = redact(cyclic) as Record<string, unknown>;
    assert.equal(out.name, 'loop');
    assert.equal(out.self, '[circular]');
  });

  test('a deeply nested object stops rather than recursing forever', () => {
    let deep: Record<string, unknown> = { end: true };
    for (let index = 0; index < 50; index += 1) deep = { next: deep };
    const serialised = JSON.stringify(redact(deep));
    assert.ok(serialised.includes('[too deep]'));
  });

  test('an Error keeps its message and stack, both redacted', () => {
    const error = new Error('failed with Bearer abcdefghijklmnopqrstuv');
    const out = redact(error) as { name: string; message: string };
    assert.equal(out.name, 'Error');
    assert.ok(out.message.includes(REDACTED));
  });
});

describe('the logger', () => {
  function loggerWith() {
    const sink = new MemorySink();
    const logger = createLogger(
      { requestId: 'req-1' },
      { sink, level: 'debug', now: () => new Date('2026-09-18T00:00:00.000Z') },
    );
    return { sink, logger };
  }

  test('writes one object per line with the reserved fields', () => {
    const { sink, logger } = loggerWith();
    logger.info('crawl finished', { pages: 12 });

    assert.equal(sink.lines.length, 1);
    const line = sink.lines[0];
    assert.equal(line?.level, 'info');
    assert.equal(line?.message, 'crawl finished');
    assert.equal(line?.requestId, 'req-1');
    assert.equal(line?.pages, 12);
    assert.equal(line?.at, '2026-09-18T00:00:00.000Z');
  });

  test('FIELDS CANNOT OVERWRITE THE RESERVED ONES', () => {
    // A line that can be made to lie about its own level or timestamp is worse
    // than no line, because it is believed.
    const { sink, logger } = loggerWith();
    logger.error('real failure', { level: 'debug', at: 'yesterday', message: 'nothing happened' });

    const line = sink.lines[0];
    assert.equal(line?.level, 'error');
    assert.equal(line?.at, '2026-09-18T00:00:00.000Z');
    assert.equal(line?.message, 'real failure');
  });

  test('THERE IS NO WAY TO LOG A FIELD WITHOUT REDACTION', () => {
    const { sink, logger } = loggerWith();
    logger.info('signed in', { password: 'hunter2', apiKey: 'sk-live-abcdefghijklmnop' });
    const line = sink.lines[0];
    assert.equal(line?.password, REDACTED);
    assert.equal(line?.apiKey, REDACTED);
  });

  test('the message itself is redacted too', () => {
    const { sink, logger } = loggerWith();
    logger.warn('upstream said: Bearer abcdefghijklmnopqrstuvwxyz');
    assert.ok(String(sink.lines[0]?.message).includes(REDACTED));
  });

  test('a level below the threshold writes nothing at all', () => {
    const sink = new MemorySink();
    const logger = createLogger({}, { sink, level: 'warn' });
    logger.debug('noise');
    logger.info('noise');
    logger.warn('kept');
    assert.equal(sink.lines.length, 1);
    assert.equal(sink.lines[0]?.message, 'kept');
  });

  test('a child logger carries its parent context and adds to it', () => {
    const sink = new MemorySink();
    const parent = createLogger({ requestId: 'req-1' }, { sink, level: 'debug' });
    parent.child({ organizationId: 'org-9' }).info('scoped');
    const line = sink.lines[0];
    assert.equal(line?.requestId, 'req-1');
    assert.equal(line?.organizationId, 'org-9');
  });

  test('every line is valid JSON on one line', () => {
    const { sink, logger } = loggerWith();
    logger.info('multi\nline\tmessage', { note: 'with "quotes" and \\ backslashes' });
    const serialised = JSON.stringify(sink.lines[0]);
    assert.doesNotThrow(() => JSON.parse(serialised));
    assert.ok(!serialised.slice(1, -1).includes('\n'), 'a raw newline reached the line');
  });
});

describe('the request id', () => {
  function headers(value: string | null) {
    return { get: (name: string) => (name === 'x-request-id' ? value : null) };
  }

  test('an inbound id is kept, so a trace stays one trace', () => {
    assert.equal(requestId(headers('abc123def456')), 'abc123def456');
  });

  test('AN INBOUND ID IS CONSTRAINED, because it is client-controlled', () => {
    // Without this, a caller writes whatever they like into every log line of
    // their own request — including newlines, which would forge log entries.
    const hostile = requestId(headers('a".\n{"level":"error","message":"forged"}'));
    assert.ok(!hostile.includes('\n'), 'a newline reached the request id');
    assert.ok(!hostile.includes('"'), 'a quote reached the request id');
  });

  test('an absurdly long inbound id is rejected, not truncated', () => {
    const generated = requestId(headers('x'.repeat(5_000)));
    assert.ok(generated.length <= 64);
  });

  test('too short is rejected too — one character is not a trace', () => {
    const generated = requestId(headers('x'));
    assert.ok(generated.length > 8);
  });

  test('no inbound header produces a fresh id', () => {
    const first = requestId(headers(null));
    const second = requestId(headers(null));
    assert.notEqual(first, second);
    assert.match(first, /^[0-9a-f-]{36}$/);
  });
});

describe('metrics', () => {
  test('a snapshot names every declared counter, including the zeroes', () => {
    // A sparse object cannot distinguish "nothing happened" from "nothing was
    // recorded", and the second is a bug.
    const metrics = new Metrics();
    metrics.count('api.request');
    const snapshot = metrics.snapshot();
    for (const name of COUNTERS) {
      assert.ok(name in snapshot.counters, `${name} is missing from the snapshot`);
    }
    assert.equal(snapshot.counters['api.request'], 1);
    assert.equal(snapshot.counters['api.error'], 0);
  });

  test('AN UNDECLARED METRIC IS REFUSED, not invented', () => {
    // The defence against unbounded cardinality: a counter keyed by something
    // with an id in it grows until the process dies.
    const metrics = new Metrics();
    metrics.count('api.request.for.org-123' as never);
    const snapshot = metrics.snapshot();
    assert.ok(!('api.request.for.org-123' in snapshot.counters));
    assert.equal(Object.keys(snapshot.counters).length, COUNTERS.length);
  });

  test('a histogram places observations in the right buckets', () => {
    const metrics = new Metrics();
    for (const ms of [5, 30, 80, 400, 2_000]) metrics.observe('api.latency', ms);

    const snapshot = metrics.snapshot().histograms['api.latency'];
    assert.ok(snapshot);
    assert.equal(snapshot.count, 5);
    // Cumulative: everything at or under 10ms is just the 5ms observation.
    assert.equal(snapshot.buckets.find((b) => b.leMs === 10)?.count, 1);
    assert.equal(snapshot.buckets.find((b) => b.leMs === 50)?.count, 2);
    assert.equal(snapshot.buckets.find((b) => b.leMs === 100)?.count, 3);
    assert.equal(snapshot.buckets.find((b) => b.leMs === 500)?.count, 4);
    assert.equal(snapshot.buckets.find((b) => b.leMs === 3_000)?.count, 5);
    assert.equal(snapshot.maxMs, 2_000);
  });

  test('a percentile reads off a bucket bound rather than inventing precision', () => {
    const metrics = new Metrics();
    for (let index = 0; index < 99; index += 1) metrics.observe('api.latency', 5);
    metrics.observe('api.latency', 9_000);

    const snapshot = metrics.snapshot().histograms['api.latency'];
    assert.ok(snapshot);
    assert.equal(percentile(snapshot, 0.5), 10, 'the median is not the smallest bucket');
    assert.equal(percentile(snapshot, 0.99), 10);
    assert.equal(percentile(snapshot, 1), 10_000, 'the outlier is not in the top bucket');
  });

  test('a percentile beyond the largest bucket says so rather than guessing', () => {
    const metrics = new Metrics();
    metrics.observe('api.latency', 60_000);
    const snapshot = metrics.snapshot().histograms['api.latency'];
    assert.ok(snapshot);
    assert.equal(percentile(snapshot, 1), null, 'an overflow value was reported as a bound');
  });

  test('A FAILED OPERATION STILL CONTRIBUTES ITS LATENCY', () => {
    // Timing only successes is how a dashboard reports that everything is fast
    // while every slow request times out.
    let clock = 0;
    const metrics = new Metrics(() => new Date(clock));
    return metrics
      .time('api.latency', async () => {
        clock += 800;
        throw new Error('nope');
      })
      .then(
        () => assert.fail('the error was swallowed'),
        () => {
          const snapshot = metrics.snapshot().histograms['api.latency'];
          assert.equal(snapshot?.count, 1);
          assert.equal(snapshot?.maxMs, 800);
        },
      );
  });

  test('a negative or non-finite observation is ignored', () => {
    const metrics = new Metrics();
    metrics.observe('api.latency', -1);
    metrics.observe('api.latency', Number.NaN);
    metrics.observe('api.latency', Number.POSITIVE_INFINITY);
    assert.equal(metrics.snapshot().histograms['api.latency']?.count, 0);
  });

  test('the bucket bounds are ordered and cover a useful range', () => {
    assert.deepEqual([...LATENCY_BUCKETS_MS], [...LATENCY_BUCKETS_MS].sort((a, b) => a - b));
    assert.ok(LATENCY_BUCKETS_MS[0]! <= 10);
    assert.ok(LATENCY_BUCKETS_MS[LATENCY_BUCKETS_MS.length - 1]! >= 10_000);
    assert.equal(HISTOGRAMS.length, new Set(HISTOGRAMS).size);
  });
});
