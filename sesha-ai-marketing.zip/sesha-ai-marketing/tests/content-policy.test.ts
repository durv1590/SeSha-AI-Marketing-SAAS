import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { test, describe } from 'node:test';

import { faqs } from '../src/content/faq';
import { modules } from '../src/content/modules';
import { pricingTiers } from '../src/content/pricing';
import { organization } from '../src/content/site';
import { solutionList } from '../src/content/solutions';
import { buildOffers, organizationSchema, softwareApplicationSchema } from '../src/lib/schema';

/**
 * Claims and secrets policy, enforced as tests.
 *
 * The Phase 1 brief says "do not make unsupported claims" and "never fabricate
 * reviews, ratings, awards, prices, credentials or business facts". A rule that
 * only lives in a document gets broken by the next content edit, so it is
 * asserted here instead.
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function walk(dir: string, match: RegExp): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir)) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) out.push(...walk(full, match));
    else if (match.test(entry)) out.push(full);
  }
  return out;
}

const contentFiles = walk(path.join(root, 'src', 'content'), /\.ts$/);
const allSource = walk(path.join(root, 'src'), /\.(ts|tsx)$/);

/** Text visible to a site visitor, gathered from the typed content modules. */
const visibleCopy: string[] = [
  ...modules.flatMap((m) => [m.heading, m.summary, m.detail, ...m.capabilities]),
  ...solutionList.flatMap((s) => [
    s.heroHeading,
    s.definition,
    s.directAnswer,
    s.explanation,
    ...s.challenges,
    ...s.examples.map((e) => `${e.title} ${e.body}`),
    ...s.faqs.map((f) => `${f.question} ${f.answer}`),
  ]),
  ...faqs.map((f) => `${f.question} ${f.answer}`),
  ...pricingTiers.flatMap((t) => [t.description, t.audience, ...t.includes]),
];

describe('no fabricated metrics or superlatives in visible copy', () => {
  const forbidden: readonly { readonly label: string; readonly pattern: RegExp }[] = [
    { label: 'percentage improvement claim', pattern: /\b\d{1,3}\s?%\s*(more|faster|better|increase|growth|improvement|higher|lift)/i },
    { label: 'multiplier claim', pattern: /\b\d+(\.\d+)?x\s+(faster|more|better|growth|results|roi)/i },
    { label: 'customer count claim', pattern: /\b(\d[\d,.]*\+?|thousands|millions|hundreds)\s+(of\s+)?(customers|users|companies|teams|businesses|marketers)\b/i },
    { label: 'trusted-by claim', pattern: /\btrusted by\b/i },
    { label: 'ranking superlative', pattern: /\b(#1|number one|world'?s (best|leading)|market leader|industry[- ]leading|best[- ]in[- ]class)\b/i },
    { label: 'award claim', pattern: /\b(award[- ]winning|voted best|rated \d(\.\d)? (out of|\/) \d)\b/i },
    // Matches a PROMISE of a guarantee, not a denial of one. "We do not
    // guarantee rankings" must stay legal; "we guarantee results" must not.
    {
      label: 'guarantee promise',
      pattern: /\b(we|sesha)\s+(guarantee|promise)\b|\bguaranteed\s+(results|rankings|growth|roi|traffic)\b|\bguaranteed\s+to\s+(rank|increase|improve|grow)\b/i,
    },
    { label: 'rank-first promise', pattern: /\b(we('ll| will)?\s+)?(get you|rank you)\s+(to\s+)?(number one|#1|first|top)\b/i },
  ];

  /**
   * Claims live in assertions, not in questions. "Does SeSha guarantee
   * rankings?" is the heading of an answer that says no — scanning it as if it
   * were a claim produces a false positive, so interrogative sentences are
   * dropped before the patterns run.
   */
  function assertions(text: string): string {
    return text
      .split(/(?<=[.!?])\s+/)
      .filter((sentence) => !sentence.trimEnd().endsWith('?'))
      .join(' ');
  }

  for (const rule of forbidden) {
    test(`copy contains no ${rule.label}`, () => {
      const hits = visibleCopy.filter((text) => rule.pattern.test(assertions(text)));
      assert.deepEqual(
        hits,
        [],
        `${rule.label} found in:\n${hits.map((h) => `  - ${h.slice(0, 120)}`).join('\n')}`,
      );
    });
  }

  test('the ranking question is answered honestly rather than avoided', () => {
    const answer = faqs.find((f) => /guarantee better rankings/i.test(f.question));
    assert.ok(answer, 'the "do you guarantee rankings" question must be answered');
    assert.match(answer.answer, /^No\b/, 'the answer must begin with a plain No');
  });
});

describe('no fabricated business facts', () => {
  test('unverified organization facts are omitted, not invented', () => {
    const org = organizationSchema();
    // The telephone IS published, because it was verified. Anything unverified
    // stays absent.
    assert.equal(org['telephone'], '+918218397819');
    assert.equal(org['address'], undefined);
    assert.equal(org['foundingDate'], undefined);
    assert.equal(organization.sameAs.length, 0);
  });

  test('no review, rating or award markup is ever generated', () => {
    const nodes = [
      organizationSchema(),
      softwareApplicationSchema({
        applicationCategory: 'BusinessApplication',
        operatingSystem: 'Web',
        featureList: ['A'],
      }),
    ];
    for (const node of nodes) {
      for (const key of ['aggregateRating', 'review', 'award', 'reviews']) {
        assert.equal(node[key], undefined, `${key} must never be emitted`);
      }
    }
  });

  test('no placeholder price can reach structured data', () => {
    const offers = buildOffers(
      pricingTiers.map((tier) => ({
        name: tier.name,
        price: tier.monthlyPrice ?? 0,
        currency: tier.currency,
        billingPeriod: 'month',
        verified: tier.verified,
      })),
    );
    assert.equal(offers, undefined);
  });

  test('unverified tiers carry no price value', () => {
    for (const tier of pricingTiers) {
      if (!tier.verified) {
        assert.equal(
          tier.monthlyPrice,
          null,
          `${tier.name} has a price set but is not verified — either verify it or set it to null`,
        );
      }
    }
  });

  test('no testimonial or named-customer content exists in the content layer', () => {
    const offenders: string[] = [];
    for (const file of contentFiles) {
      const contents = readFileSync(file, 'utf8');
      // Structural markers only. Prose that *discusses* testimonials (the blog
      // warns against fabricating them) is fine; a data field that publishes
      // one is not.
      if (/\btestimonials?\s*[:=]\s*\[|customerQuotes?\s*[:=]|\bcustomerLogos?\s*[:=]|\breviews?\s*[:=]\s*\[/i.test(contents)) {
        offenders.push(path.relative(root, file));
      }
    }
    assert.deepEqual(offenders, []);
  });
});

describe('no exposed secrets', () => {
  const secretPatterns: readonly { readonly label: string; readonly pattern: RegExp }[] = [
    { label: 'private key block', pattern: /-----BEGIN [A-Z ]*PRIVATE KEY-----/ },
    { label: 'AWS access key id', pattern: /\bAKIA[0-9A-Z]{16}\b/ },
    { label: 'Google API key', pattern: /\bAIza[0-9A-Za-z_-]{35}\b/ },
    { label: 'Slack token', pattern: /\bxox[baprs]-[0-9A-Za-z-]{10,}/ },
    { label: 'GitHub token', pattern: /\bgh[pousr]_[0-9A-Za-z]{36}\b/ },
    { label: 'bearer literal', pattern: /Authorization:\s*['"]Bearer\s+[A-Za-z0-9._-]{20,}/ },
    { label: 'assigned secret literal', pattern: /(api[_-]?key|secret|password|token)\s*[:=]\s*['"][A-Za-z0-9._\-/+]{16,}['"]/i },
  ];

  for (const rule of secretPatterns) {
    test(`no ${rule.label} in source`, () => {
      const offenders: string[] = [];
      for (const file of allSource) {
        const contents = readFileSync(file, 'utf8');
        if (rule.pattern.test(contents)) offenders.push(path.relative(root, file));
      }
      assert.deepEqual(offenders, []);
    });
  }

  test('no server-only env var is read through a NEXT_PUBLIC_ name', () => {
    const leaked: string[] = [];
    for (const file of allSource) {
      const contents = readFileSync(file, 'utf8');
      for (const match of contents.matchAll(/process\.env\.([A-Z0-9_]+)/g)) {
        const name = match[1]!;
        if (/(SECRET|PASSWORD|PRIVATE|API_KEY|DATABASE_URL|SMTP)/.test(name) && name.startsWith('NEXT_PUBLIC_')) {
          leaked.push(`${path.relative(root, file)}: ${name}`);
        }
      }
    }
    assert.deepEqual(leaked, []);
  });

  test('client components never read a non-public env var', () => {
    const offenders: string[] = [];
    for (const file of allSource) {
      const contents = readFileSync(file, 'utf8');
      if (!/^['"]use client['"]/m.test(contents)) continue;
      for (const match of contents.matchAll(/process\.env\.([A-Z0-9_]+)/g)) {
        const name = match[1]!;
        if (!name.startsWith('NEXT_PUBLIC_') && name !== 'NODE_ENV') {
          offenders.push(`${path.relative(root, file)}: ${name}`);
        }
      }
    }
    assert.deepEqual(offenders, []);
  });
});

describe('accessibility invariants that are statically checkable', () => {
  test('no positive tabIndex anywhere', () => {
    const offenders: string[] = [];
    for (const file of allSource) {
      const contents = readFileSync(file, 'utf8');
      if (/tabIndex=\{[1-9]/.test(contents)) offenders.push(path.relative(root, file));
    }
    assert.deepEqual(offenders, [], 'positive tabIndex breaks natural focus order');
  });

  test('no outline:none without a focus-visible replacement', () => {
    const css = readFileSync(path.join(root, 'src', 'app', 'globals.css'), 'utf8');
    const removesOutline = /outline:\s*(none|0)/.test(css);
    const providesFocusRing = /:focus-visible[\s\S]*outline:\s*2px/.test(css);
    assert.ok(!removesOutline || providesFocusRing, 'focus indicator removed without replacement');
  });

  test('reduced motion is respected globally', () => {
    const css = readFileSync(path.join(root, 'src', 'app', 'globals.css'), 'utf8');
    assert.match(css, /@media \(prefers-reduced-motion: reduce\)/);
  });

  test('every layout that renders pages provides a skip link and a main landmark', () => {
    // The skip link lives in each route-group layout, not the root layout, so
    // the sign-in pages do not inherit marketing navigation. Every layout that
    // wraps real page content must still provide one.
    const layouts = [
      path.join(root, 'src', 'app', '(marketing)', 'layout.tsx'),
      path.join(root, 'src', 'app', '(app)', 'layout.tsx'),
    ].filter((file) => {
      try {
        readFileSync(file, 'utf8');
        return true;
      } catch {
        return false;
      }
    });

    assert.ok(layouts.length > 0, 'no route-group layouts found');

    // A layout may render the landmark itself, or delegate it to a shell
    // component it imports (the application layout delegates to AppShell). The
    // check follows local imports one level so delegation still counts.
    function markupReachableFrom(file: string): string {
      const contents = readFileSync(file, 'utf8');
      let combined = contents;
      for (const match of contents.matchAll(/from\s+'(@\/[^']+)'/g)) {
        const specifier = match[1]!;
        const base = path.join(root, 'src', specifier.slice(2));
        for (const candidate of [`${base}.tsx`, `${base}.ts`, path.join(base, 'index.tsx')]) {
          try {
            combined += readFileSync(candidate, 'utf8');
            break;
          } catch {
            /* not this one */
          }
        }
      }
      return combined;
    }

    for (const file of layouts) {
      const markup = markupReachableFrom(file);
      const name = path.relative(root, file);
      assert.match(markup, /skip-link/, `${name} provides no skip link`);
      assert.match(markup, /href="#main"/, `${name} skip link does not target #main`);
      assert.match(markup, /id="main"/, `${name} provides no #main landmark`);
    }
  });

  test('the onboarding page provides its own landmark (it is outside both groups)', () => {
    const page = readFileSync(path.join(root, 'src', 'app', 'onboarding', 'page.tsx'), 'utf8');
    assert.match(page, /skip-link/);
    assert.match(page, /id="main"/);
  });

  test('the html element declares a language', () => {
    const layout = readFileSync(path.join(root, 'src', 'app', 'layout.tsx'), 'utf8');
    assert.match(layout, /<html lang=/);
  });

  test('exactly one h1 per page component', () => {
    const pageFiles = walk(path.join(root, 'src', 'app'), /^page\.tsx$/);
    const offenders: string[] = [];
    for (const file of pageFiles) {
      const contents = readFileSync(file, 'utf8');
      const count = (contents.match(/<h1[\s>]/g) ?? []).length;
      // Pages render their h1 through PageHero / Hero / SectionHeader as="h1".
      if (count > 1) offenders.push(`${path.relative(root, file)} has ${count} h1 elements`);
    }
    assert.deepEqual(offenders, []);
  });

  test('every img element declares alt text', () => {
    const offenders: string[] = [];
    for (const file of allSource) {
      const contents = readFileSync(file, 'utf8');
      for (const match of contents.matchAll(/<(img|Image)\s[^>]*>/g)) {
        if (!/\salt=/.test(match[0])) offenders.push(`${path.relative(root, file)}: ${match[0].slice(0, 60)}`);
      }
    }
    assert.deepEqual(offenders, []);
  });
});
