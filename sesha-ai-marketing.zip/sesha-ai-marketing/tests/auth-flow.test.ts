import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore, ACCOUNT_POLICY } from '../src/lib/auth/lockout';
import {
  changePassword,
  deleteAccount,
  requestPasswordReset,
  resetPassword,
  resendVerification,
  resolveSession,
  signIn,
  signInWithOAuth,
  signOut,
  signUp,
  toRole,
  type ServiceContext,
} from '../src/lib/auth/service';
import { hashToken } from '../src/lib/auth/tokens';

/**
 * End-to-end authentication flows, executed for real against the in-memory
 * adapter. These are the tests that make the Phase 2 quality gate meaningful:
 * they run the actual sign-up, sign-in, verification, reset, rotation and
 * deletion code paths, not mocks of them.
 */

const GOOD_PASSWORD = 'a genuinely long passphrase 2026';
const OTHER_PASSWORD = 'a different long passphrase 2026';

let db: MemoryDatabase;
let context: ServiceContext;

beforeEach(() => {
  db = new MemoryDatabase();
  context = {
    db,
    lockout: new MemoryLockoutStore(),
    secret: 'test-secret-value-at-least-32-bytes-long',
  };
});

async function register(email = 'user@example.com') {
  const result = await signUp(context, { email, password: GOOD_PASSWORD, name: 'Test User' });
  assert.equal(result.ok, true);
  if (!result.ok) throw new Error('signup failed');
  return result;
}

/* -------------------------------------------------------------------------- */
/* Registration                                                               */
/* -------------------------------------------------------------------------- */

describe('sign up', () => {
  test('creates user, organization, owner membership and trial subscription', async () => {
    const result = await register();
    assert.ok(result.ok && result.userId);
    if (!result.ok || !result.userId) return;

    const user = await db.users.findById(result.userId);
    assert.ok(user);
    assert.equal(user.email, 'user@example.com');
    assert.equal(user.emailVerifiedAt, null, 'a new account must start unverified');

    const memberships = await db.memberships.findForUser(user.id);
    assert.equal(memberships.length, 1);
    assert.equal(memberships[0]?.role, 'owner');

    const subscription = await db.subscriptions.findForOrganization(memberships[0]!.organizationId);
    assert.ok(subscription);
    assert.equal(subscription.status, 'trialing');
  });

  test('never stores the plaintext password', async () => {
    const result = await register();
    if (!result.ok || !result.userId) throw new Error('signup failed');
    const user = await db.users.findById(result.userId);
    assert.ok(user?.passwordHash);
    assert.ok(!user.passwordHash.includes(GOOD_PASSWORD));
    assert.match(user.passwordHash, /^scrypt\$/);
  });

  test('issues a verification token that is stored only as a hash', async () => {
    const result = await register();
    if (!result.ok || !result.verificationToken) throw new Error('no token');
    const stored = await db.emailVerification.findByTokenHash(hashToken(result.verificationToken));
    assert.ok(stored);
    assert.notEqual(stored.tokenHash, result.verificationToken);
  });

  test('normalises the email address', async () => {
    await signUp(context, { email: '  MixedCase@Example.COM ', password: GOOD_PASSWORD });
    const user = await db.users.findByEmail('mixedcase@example.com');
    assert.ok(user, 'email was not normalised');
  });

  test('rejects a weak password before creating anything', async () => {
    const result = await signUp(context, { email: 'weak@example.com', password: 'short' });
    assert.equal(result.ok, false);
    assert.equal(await db.users.findByEmail('weak@example.com'), null);
  });

  test('DOES NOT reveal that an email is already registered', async () => {
    await register('taken@example.com');
    const second = await signUp(context, { email: 'taken@example.com', password: OTHER_PASSWORD });

    // Identical shape to a successful signup — the caller cannot tell.
    assert.equal(second.ok, true);
    if (!second.ok) return;
    assert.equal(second.userId, null);
    assert.equal(second.verificationToken, null);
  });

  test('a duplicate signup does not overwrite the existing account', async () => {
    const first = await register('taken@example.com');
    await signUp(context, { email: 'taken@example.com', password: OTHER_PASSWORD });

    const signedIn = await signIn(context, { email: 'taken@example.com', password: GOOD_PASSWORD });
    assert.equal(signedIn.ok, true, 'the original password must still work');
    if (first.ok && first.userId && signedIn.ok) {
      assert.equal(signedIn.user.id, first.userId);
    }
  });
});

/* -------------------------------------------------------------------------- */
/* Sign in                                                                    */
/* -------------------------------------------------------------------------- */

describe('sign in', () => {
  test('succeeds with the right password and returns a session', async () => {
    await register();
    const result = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.ok(result.token.length > 40);
    assert.equal(result.session.revokedAt, null);
  });

  test('the session token is never stored', async () => {
    await register();
    const result = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    if (!result.ok) throw new Error('sign in failed');
    assert.notEqual(result.session.tokenHash, result.token);
    assert.equal(result.session.tokenHash, hashToken(result.token));
  });

  test('fails with the wrong password', async () => {
    await register();
    const result = await signIn(context, { email: 'user@example.com', password: OTHER_PASSWORD });
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.reason, 'invalid-credentials');
  });

  test('an unknown account and a wrong password are indistinguishable', async () => {
    await register();
    const missing = await signIn(context, { email: 'nobody@example.com', password: GOOD_PASSWORD });
    const wrong = await signIn(context, { email: 'user@example.com', password: OTHER_PASSWORD });
    assert.deepEqual(missing, wrong, 'the two failure modes must be identical to the caller');
  });

  test('an unknown account still costs real CPU (timing defence)', async () => {
    const started = process.hrtime.bigint();
    await signIn(context, { email: 'nobody@example.com', password: GOOD_PASSWORD });
    const elapsedMs = Number(process.hrtime.bigint() - started) / 1e6;
    assert.ok(elapsedMs > 5, `missing-account path returned in ${elapsedMs.toFixed(1)}ms — a timing oracle`);
  });

  test('an unverified email can still sign in (but is flagged)', async () => {
    // Blocking sign-in entirely strands users whose verification email bounced.
    // The session resolves, and the UI gates what an unverified user can do.
    await register();
    const result = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    assert.equal(result.ok, true);
    if (result.ok) assert.equal(result.user.emailVerifiedAt, null);
  });

  test('records the login timestamp', async () => {
    const created = await register();
    await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    if (!created.ok || !created.userId) return;
    const user = await db.users.findById(created.userId);
    assert.ok(user?.lastLoginAt);
  });
});

/* -------------------------------------------------------------------------- */
/* Brute force                                                                */
/* -------------------------------------------------------------------------- */

describe('brute-force protection', () => {
  test('locks the account after repeated failures', async () => {
    await register();
    for (let i = 0; i < ACCOUNT_POLICY.threshold; i += 1) {
      await signIn(context, { email: 'user@example.com', password: 'wrong password here' });
    }
    const result = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    assert.equal(result.ok, false);
    if (!result.ok) {
      assert.equal(result.reason, 'locked');
      assert.ok((result.retryAfterSeconds ?? 0) > 0);
    }
  });

  test('a successful sign-in clears the account counter', async () => {
    await register();
    for (let i = 0; i < ACCOUNT_POLICY.threshold - 1; i += 1) {
      await signIn(context, { email: 'user@example.com', password: 'wrong password here' });
    }
    assert.equal((await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD })).ok, true);

    // The budget is reset, so the next failure does not immediately lock.
    const after = await signIn(context, { email: 'user@example.com', password: 'wrong again here' });
    assert.equal(after.ok, false);
    if (!after.ok) assert.equal(after.reason, 'invalid-credentials');
  });

  test('locking one account does not lock another', async () => {
    await register('a@example.com');
    await register('b@example.com');
    for (let i = 0; i < ACCOUNT_POLICY.threshold; i += 1) {
      await signIn(context, { email: 'a@example.com', password: 'wrong password here' });
    }
    const other = await signIn(context, { email: 'b@example.com', password: GOOD_PASSWORD });
    assert.equal(other.ok, true);
  });

  test('failures against a non-existent account are still counted', async () => {
    for (let i = 0; i < ACCOUNT_POLICY.threshold; i += 1) {
      await signIn(context, { email: 'ghost@example.com', password: 'wrong password here' });
    }
    const result = await signIn(context, { email: 'ghost@example.com', password: 'wrong password here' });
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.reason, 'locked');
  });
});

/* -------------------------------------------------------------------------- */
/* Sessions                                                                   */
/* -------------------------------------------------------------------------- */

describe('session resolution', () => {
  test('a valid token resolves to a user with a role', async () => {
    await register();
    const signedIn = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    if (!signedIn.ok) throw new Error('sign in failed');

    const resolved = await resolveSession(context, signedIn.token);
    assert.ok(resolved);
    assert.equal(resolved.user.email, 'user@example.com');
    assert.equal(resolved.user.role, 'admin', 'the owner maps to the admin role');
    assert.ok(resolved.user.organizationId);
  });

  test('a missing, empty or unknown token resolves to null', async () => {
    assert.equal(await resolveSession(context, null), null);
    assert.equal(await resolveSession(context, ''), null);
    assert.equal(await resolveSession(context, 'not-a-real-token'), null);
  });

  test('signing out invalidates the token immediately', async () => {
    await register();
    const signedIn = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    if (!signedIn.ok) throw new Error('sign in failed');

    await signOut(context, signedIn.session.id);
    assert.equal(await resolveSession(context, signedIn.token), null);
  });

  test('a deleted user cannot resolve a session even if the row survives', async () => {
    const created = await register();
    const signedIn = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    if (!signedIn.ok || !created.ok || !created.userId) throw new Error('setup failed');

    await db.users.softDelete(created.userId, new Date());
    assert.equal(await resolveSession(context, signedIn.token), null);
  });

  test('two sign-ins produce two independent sessions', async () => {
    await register();
    const first = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    const second = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    if (!first.ok || !second.ok) throw new Error('sign in failed');

    assert.notEqual(first.token, second.token);
    await signOut(context, first.session.id);
    assert.equal(await resolveSession(context, first.token), null);
    assert.ok(await resolveSession(context, second.token), 'the other session must survive');
  });
});

/* -------------------------------------------------------------------------- */
/* Email verification                                                         */
/* -------------------------------------------------------------------------- */

describe('email verification', () => {
  test('a valid token verifies the address', async () => {
    const created = await register();
    if (!created.ok || !created.verificationToken || !created.userId) throw new Error('setup failed');

    const { verifyEmail } = await import('../src/lib/auth/service');
    const result = await verifyEmail(context, created.verificationToken);
    assert.equal(result.ok, true);

    const user = await db.users.findById(created.userId);
    assert.ok(user?.emailVerifiedAt);
  });

  test('a verification token is single use', async () => {
    const created = await register();
    if (!created.ok || !created.verificationToken) throw new Error('setup failed');
    const { verifyEmail } = await import('../src/lib/auth/service');

    assert.equal((await verifyEmail(context, created.verificationToken)).ok, true);
    const replay = await verifyEmail(context, created.verificationToken);
    assert.equal(replay.ok, false, 'a used verification link must not work twice');
  });

  test('an unknown token is rejected', async () => {
    const { verifyEmail } = await import('../src/lib/auth/service');
    assert.equal((await verifyEmail(context, 'made-up-token')).ok, false);
  });

  test('verification rotates the session (fixation defence)', async () => {
    const created = await register();
    if (!created.ok || !created.verificationToken) throw new Error('setup failed');
    const before = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    if (!before.ok) throw new Error('sign in failed');

    const { verifyEmail } = await import('../src/lib/auth/service');
    const result = await verifyEmail(context, created.verificationToken);
    assert.equal(result.ok, true);
    if (!result.ok) return;

    assert.notEqual(result.token, before.token);
    assert.equal(await resolveSession(context, before.token), null, 'the old token must be dead');
    assert.ok(await resolveSession(context, result.token));
  });

  test('resending invalidates the previous token', async () => {
    const created = await register();
    if (!created.ok || !created.verificationToken) throw new Error('setup failed');

    const resent = await resendVerification(context, 'user@example.com');
    assert.ok(resent);

    const { verifyEmail } = await import('../src/lib/auth/service');
    assert.equal((await verifyEmail(context, created.verificationToken)).ok, false, 'old link still works');
    assert.equal((await verifyEmail(context, resent.token)).ok, true);
  });

  test('resending for an unknown address returns null (no enumeration)', async () => {
    assert.equal(await resendVerification(context, 'nobody@example.com'), null);
  });
});

/* -------------------------------------------------------------------------- */
/* Password reset                                                             */
/* -------------------------------------------------------------------------- */

describe('password reset', () => {
  test('a reset link lets the user set a new password', async () => {
    await register();
    const requested = await requestPasswordReset(context, 'user@example.com');
    assert.ok(requested);

    const result = await resetPassword(context, requested.token, OTHER_PASSWORD);
    assert.equal(result.ok, true);

    assert.equal((await signIn(context, { email: 'user@example.com', password: OTHER_PASSWORD })).ok, true);
    assert.equal((await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD })).ok, false);
  });

  test('requesting a reset for an unknown address returns null, not an error', async () => {
    // The API route returns the same response either way; this is the seam.
    assert.equal(await requestPasswordReset(context, 'nobody@example.com'), null);
  });

  test('a reset token is single use', async () => {
    await register();
    const requested = await requestPasswordReset(context, 'user@example.com');
    if (!requested) throw new Error('no token');

    assert.equal((await resetPassword(context, requested.token, OTHER_PASSWORD)).ok, true);
    const replay = await resetPassword(context, requested.token, 'yet another long passphrase');
    assert.equal(replay.ok, false);
  });

  test('requesting a new link invalidates the previous one', async () => {
    await register();
    const first = await requestPasswordReset(context, 'user@example.com');
    const second = await requestPasswordReset(context, 'user@example.com');
    if (!first || !second) throw new Error('no token');

    assert.equal((await resetPassword(context, first.token, OTHER_PASSWORD)).ok, false, 'old link still works');
    assert.equal((await resetPassword(context, second.token, OTHER_PASSWORD)).ok, true);
  });

  test('a weak password does NOT consume the token', async () => {
    await register();
    const requested = await requestPasswordReset(context, 'user@example.com');
    if (!requested) throw new Error('no token');

    const weak = await resetPassword(context, requested.token, 'short');
    assert.equal(weak.ok, false);
    if (!weak.ok) assert.equal(weak.reason, 'weak-password');

    // The user gets to try again with the same link.
    assert.equal((await resetPassword(context, requested.token, OTHER_PASSWORD)).ok, true);
  });

  test('resetting revokes every existing session', async () => {
    await register();
    const a = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    const b = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    if (!a.ok || !b.ok) throw new Error('sign in failed');

    const requested = await requestPasswordReset(context, 'user@example.com');
    if (!requested) throw new Error('no token');
    await resetPassword(context, requested.token, OTHER_PASSWORD);

    assert.equal(await resolveSession(context, a.token), null);
    assert.equal(await resolveSession(context, b.token), null);
  });

  test('resetting clears a lockout so the user is not locked out of recovery', async () => {
    await register();
    for (let i = 0; i < ACCOUNT_POLICY.threshold; i += 1) {
      await signIn(context, { email: 'user@example.com', password: 'wrong password here' });
    }
    const requested = await requestPasswordReset(context, 'user@example.com');
    if (!requested) throw new Error('no token');
    await resetPassword(context, requested.token, OTHER_PASSWORD);

    const result = await signIn(context, { email: 'user@example.com', password: OTHER_PASSWORD });
    assert.equal(result.ok, true, 'the user must be able to sign in after recovering');
  });
});

/* -------------------------------------------------------------------------- */
/* Password change                                                            */
/* -------------------------------------------------------------------------- */

describe('password change', () => {
  test('requires the current password', async () => {
    const created = await register();
    const signedIn = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    if (!created.ok || !created.userId || !signedIn.ok) throw new Error('setup failed');

    const wrong = await changePassword(context, {
      userId: created.userId,
      currentPassword: 'not the current password',
      newPassword: OTHER_PASSWORD,
      currentSessionId: signedIn.session.id,
    });
    assert.equal(wrong.ok, false);
  });

  test('ROTATES EVERY SESSION, including the acting one, and issues a fresh one', async () => {
    // Phase 8: the acting session is rotated too. If the password was changed
    // because the session was stolen, keeping that session alive would keep the
    // attacker signed in on it.
    const created = await register();
    const acting = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    const other = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    if (!created.ok || !created.userId || !acting.ok || !other.ok) throw new Error('setup failed');

    const result = await changePassword(context, {
      userId: created.userId,
      currentPassword: GOOD_PASSWORD,
      newPassword: OTHER_PASSWORD,
      currentSessionId: acting.session.id,
    });
    if (!result.ok) throw new Error('password change failed');

    assert.equal(await resolveSession(context, acting.token), null, 'the old acting token must die');
    assert.equal(await resolveSession(context, other.token), null, 'other sessions must be revoked');
    assert.ok(await resolveSession(context, result.token), 'the fresh session must work');
    assert.notEqual(result.token, acting.token);
  });
});

/* -------------------------------------------------------------------------- */
/* Account deletion                                                           */
/* -------------------------------------------------------------------------- */

describe('account deletion', () => {
  test('requires re-authentication', async () => {
    const created = await register();
    const signedIn = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    if (!created.ok || !created.userId || !signedIn.ok) throw new Error('setup failed');
    const memberships = await db.memberships.findForUser(created.userId);

    const denied = await deleteAccount(context, {
      userId: created.userId,
      password: 'wrong password entirely',
      organizationId: memberships[0]!.organizationId,
    });
    assert.equal(denied.ok, false);

    const user = await db.users.findById(created.userId);
    assert.equal(user?.deletedAt, null, 'the account must not be deleted on a failed re-auth');
  });

  test('soft-deletes, revokes sessions and blocks sign-in', async () => {
    const created = await register();
    const signedIn = await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    if (!created.ok || !created.userId || !signedIn.ok) throw new Error('setup failed');
    const memberships = await db.memberships.findForUser(created.userId);

    const result = await deleteAccount(context, {
      userId: created.userId,
      password: GOOD_PASSWORD,
      organizationId: memberships[0]!.organizationId,
    });
    assert.equal(result.ok, true);

    assert.equal(await resolveSession(context, signedIn.token), null);
    assert.equal((await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD })).ok, false);
    assert.equal(await db.users.findByEmail('user@example.com'), null, 'must not be findable for sign-in');

    // The row survives for audit and foreign keys — it is a soft delete.
    const row = await db.users.findById(created.userId);
    assert.ok(row);
    assert.ok(row.deletedAt);
  });

  test('the address can be reused after deletion', async () => {
    const created = await register();
    if (!created.ok || !created.userId) throw new Error('setup failed');
    const memberships = await db.memberships.findForUser(created.userId);
    await deleteAccount(context, {
      userId: created.userId,
      password: GOOD_PASSWORD,
      organizationId: memberships[0]!.organizationId,
    });

    const again = await signUp(context, { email: 'user@example.com', password: OTHER_PASSWORD });
    assert.equal(again.ok, true);
    if (again.ok) assert.ok(again.userId, 'a fresh account should genuinely be created');
  });
});

/* -------------------------------------------------------------------------- */
/* OAuth                                                                      */
/* -------------------------------------------------------------------------- */

describe('OAuth sign-in', () => {
  const identity = {
    provider: 'google' as const,
    providerUserId: 'google-sub-12345',
    email: 'oauth@example.com',
    emailVerified: true,
    name: 'OAuth User',
  };

  test('creates an account on first sign-in, already verified', async () => {
    const result = await signInWithOAuth(context, identity);
    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.equal(result.created, true);

    const user = await db.users.findById(result.userId);
    assert.ok(user?.emailVerifiedAt, 'the provider already verified the address');
    assert.equal(user?.passwordHash, null, 'no password for an OAuth-only account');
  });

  test('signs the same identity back in without creating a duplicate', async () => {
    const first = await signInWithOAuth(context, identity);
    const second = await signInWithOAuth(context, identity);
    assert.ok(first.ok && second.ok);
    if (!first.ok || !second.ok) return;
    assert.equal(second.created, false);
    assert.equal(first.userId, second.userId);
    assert.notEqual(first.token, second.token);
  });

  test('REJECTS an unverified provider email', async () => {
    // Accepting this would allow takeover of any account whose address someone
    // can set, unverified, on the provider side.
    const result = await signInWithOAuth(context, { ...identity, emailVerified: false });
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.reason, 'email-unverified');
  });

  test('REFUSES to link by email to an existing password account', async () => {
    await register('collision@example.com');
    const result = await signInWithOAuth(context, {
      ...identity,
      email: 'collision@example.com',
      providerUserId: 'google-sub-other',
    });
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.reason, 'email-taken');
  });

  test('matches on the provider subject, not the email', async () => {
    // A provider-side email change must not create a second account.
    const first = await signInWithOAuth(context, identity);
    const renamed = await signInWithOAuth(context, { ...identity, email: 'new-address@example.com' });
    assert.ok(first.ok && renamed.ok);
    if (!first.ok || !renamed.ok) return;
    assert.equal(renamed.userId, first.userId);
    assert.equal(renamed.created, false);
  });

  test('an OAuth session resolves like any other', async () => {
    const result = await signInWithOAuth(context, identity);
    if (!result.ok) throw new Error('oauth failed');
    const resolved = await resolveSession(context, result.token);
    assert.ok(resolved);
    assert.equal(resolved.user.email, 'oauth@example.com');
  });
});

/* -------------------------------------------------------------------------- */
/* Audit logging                                                              */
/* -------------------------------------------------------------------------- */

describe('audit logging', () => {
  test('records successes, failures and denials', async () => {
    const created = await register();
    await signIn(context, { email: 'user@example.com', password: 'wrong password here' });
    await signIn(context, { email: 'user@example.com', password: GOOD_PASSWORD });
    if (!created.ok || !created.userId) throw new Error('setup failed');

    const memberships = await db.memberships.findForUser(created.userId);
    const entries = await db.audit.list(memberships[0]!.organizationId);
    assert.ok(entries.length > 0);
    assert.ok(entries.some((e) => e.action === 'auth.signup' && e.outcome === 'success'));
  });

  test('never writes a raw IP address or a password', async () => {
    await signUp(
      context,
      { email: 'audited@example.com', password: GOOD_PASSWORD },
      { ipAddress: '203.0.113.9', userAgent: 'Test/1.0' },
    );
    await signIn(
      context,
      { email: 'audited@example.com', password: 'wrong password here' },
      { ipAddress: '203.0.113.9' },
    );

    const user = await db.users.findByEmail('audited@example.com');
    const memberships = await db.memberships.findForUser(user!.id);
    const entries = await db.audit.list(memberships[0]!.organizationId);
    const serialized = JSON.stringify(entries);

    assert.ok(!serialized.includes('203.0.113.9'), 'raw IP address leaked into the audit log');
    assert.ok(!serialized.includes(GOOD_PASSWORD), 'password leaked into the audit log');
  });
});

describe('role mapping', () => {
  test('owner maps to admin; other roles pass through', () => {
    assert.equal(toRole('owner'), 'admin');
    assert.equal(toRole('admin'), 'admin');
    assert.equal(toRole('manager'), 'manager');
    assert.equal(toRole('team_member'), 'team_member');
    assert.equal(toRole('user'), 'user');
  });
});
