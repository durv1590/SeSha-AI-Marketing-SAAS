import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { signUp, toRole } from '../src/lib/auth/service';
import { AuthorizationError } from '../src/lib/auth/rbac';
import { NotFoundError, type TenantContext } from '../src/lib/tenant';
import {
  projectLimitFor,
  PlanLimitError,
  completeOnboarding,
  createBusiness,
  createProject,
  deleteProject,
  getActiveCrawlConsent,
  getMarketingProfile,
  getProject,
  grantCrawlConsent,
  listProjects,
  revokeCrawlConsent,
  saveMarketingProfile,
  updateProject,
  type WorkspaceContext,
} from '../src/lib/workspace/service';
import {
  CRAWL_CONSENT_VERSION,
  isPrivateHost,
  normalizeWebsiteUrl,
  slugifyProject,
  validateBusiness,
  validateCrawlConsent,
  validateMarketingProfile,
  validateProject,
} from '../src/lib/validation/onboarding';

/**
 * Workspace, tenancy and onboarding, executed for real.
 *
 * The isolation tests here are the important ones: two organizations are
 * created through the actual sign-up flow, then every cross-tenant access path
 * is attempted and must fail as NOT FOUND — never as a leak, and never as a 403
 * that would confirm the resource exists.
 */

const PASSWORD = 'a genuinely long passphrase 2026';

let db: MemoryDatabase;
let workspace: WorkspaceContext;

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: 'https://acme-coffee.example',
};

const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic', 'brand-awareness'] as const,
  marketingChannels: ['organic-search', 'social-organic'] as const,
  brandVoice: { tones: ['friendly', 'direct'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters', url: 'https://rival.example' }],
};

async function makeTenant(email: string): Promise<TenantContext> {
  const context = {
    db,
    lockout: new MemoryLockoutStore(),
    secret: 'test-secret-value-at-least-32-bytes-long',
  };
  const result = await signUp(context, { email, password: PASSWORD, name: 'Owner' });
  if (!result.ok || !result.userId) throw new Error('signup failed');
  const memberships = await db.memberships.findForUser(result.userId);
  const membership = memberships[0]!;
  return {
    userId: result.userId,
    organizationId: membership.organizationId,
    role: toRole(membership.role),
  };
}

beforeEach(() => {
  db = new MemoryDatabase();
  workspace = { db };
});

/* -------------------------------------------------------------------------- */
/* Validation                                                                 */
/* -------------------------------------------------------------------------- */

describe('website URL normalisation', () => {
  test('adds https and keeps a valid host', () => {
    const result = normalizeWebsiteUrl('example.com');
    assert.equal(result.ok, true);
    if (result.ok) assert.equal(result.hostname, 'example.com');
  });

  test('accepts an existing scheme and strips the fragment', () => {
    const result = normalizeWebsiteUrl('https://example.com/page#section');
    assert.equal(result.ok, true);
    if (result.ok) assert.ok(!result.url.includes('#'));
  });

  test('REJECTS loopback and private addresses (SSRF defence)', () => {
    // This value later feeds a crawler. A crawler that will fetch anything the
    // user types is a server-side request forgery vector.
    for (const host of [
      'localhost',
      'http://127.0.0.1',
      'http://10.0.0.5',
      'http://192.168.1.1',
      'http://172.16.4.4',
      'http://169.254.169.254',
      'http://100.64.0.1',
      'http://something.internal',
      'http://box.local',
    ]) {
      assert.equal(normalizeWebsiteUrl(host).ok, false, `accepted private host: ${host}`);
    }
  });

  test('rejects non-http schemes', () => {
    for (const value of ['ftp://example.com', 'javascript:alert(1)', 'file:///etc/passwd']) {
      assert.equal(normalizeWebsiteUrl(value).ok, false, `accepted: ${value}`);
    }
  });

  test('rejects credentials embedded in the URL', () => {
    assert.equal(normalizeWebsiteUrl('https://user:pass@example.com').ok, false);
  });

  test('rejects non-standard ports', () => {
    assert.equal(normalizeWebsiteUrl('https://example.com:8080').ok, false);
    assert.equal(normalizeWebsiteUrl('https://example.com:443').ok, true);
  });

  test('rejects a bare hostname with no dot', () => {
    assert.equal(normalizeWebsiteUrl('intranet').ok, false);
  });

  test('isPrivateHost handles malformed octets', () => {
    assert.equal(isPrivateHost('999.999.999.999'), true);
  });
});

describe('business validation', () => {
  test('accepts a complete business', () => {
    assert.equal(validateBusiness(business).ok, true);
  });

  test('requires name, industry, country and city', () => {
    const result = validateBusiness({});
    assert.equal(result.ok, false);
    if (!result.ok) {
      for (const field of ['name', 'industry', 'country', 'city'] as const) {
        assert.ok(result.errors[field], `missing error for ${field}`);
      }
    }
  });

  test('website is optional but validated when present', () => {
    const without = validateBusiness({ ...business, websiteUrl: '' });
    assert.equal(without.ok, true);
    if (without.ok) assert.equal(without.data.websiteUrl, null);

    const bad = validateBusiness({ ...business, websiteUrl: 'http://127.0.0.1' });
    assert.equal(bad.ok, false);
  });

  test('rejects an unknown industry', () => {
    const result = validateBusiness({ ...business, industry: 'space-mining' });
    assert.equal(result.ok, false);
  });
});

describe('marketing profile validation', () => {
  test('accepts a complete profile', () => {
    assert.equal(validateMarketingProfile(profile).ok, true);
  });

  test('requires every field the brief lists', () => {
    const result = validateMarketingProfile({});
    assert.equal(result.ok, false);
    if (!result.ok) {
      for (const field of [
        'targetAudience',
        'productsServices',
        'priceRange',
        'marketingGoals',
        'marketingChannels',
        'brandVoice',
      ] as const) {
        assert.ok(result.errors[field], `missing error for ${field}`);
      }
    }
  });

  test('drops unknown goals and channels rather than trusting the client', () => {
    const result = validateMarketingProfile({
      ...profile,
      marketingGoals: ['brand-awareness', 'take-over-the-world'],
      marketingChannels: ['email', '../../etc/passwd'],
    });
    assert.equal(result.ok, true);
    if (result.ok) {
      assert.deepEqual([...result.data.marketingGoals], ['brand-awareness']);
      assert.deepEqual([...result.data.marketingChannels], ['email']);
    }
  });

  test('de-duplicates selections', () => {
    const result = validateMarketingProfile({
      ...profile,
      marketingGoals: ['brand-awareness', 'brand-awareness', 'lead-generation'],
    });
    assert.equal(result.ok, true);
    if (result.ok) assert.equal(result.data.marketingGoals.length, 2);
  });

  test('caps the number of brand tones', () => {
    const result = validateMarketingProfile({
      ...profile,
      brandVoice: { tones: ['friendly', 'direct', 'playful', 'technical', 'empathetic'], notes: '' },
    });
    assert.equal(result.ok, true);
    if (result.ok) assert.equal(result.data.brandVoice.tones.length, 3);
  });

  test('rejects a competitor with an invalid URL', () => {
    const result = validateMarketingProfile({
      ...profile,
      competitors: [{ name: 'Bad', url: 'http://localhost' }],
    });
    assert.equal(result.ok, false);
  });

  test('accepts a competitor with no URL', () => {
    const result = validateMarketingProfile({ ...profile, competitors: [{ name: 'Just a name' }] });
    assert.equal(result.ok, true);
    if (result.ok) assert.equal(result.data.competitors[0]?.url, undefined);
  });

  test('caps the competitor list', () => {
    const many = Array.from({ length: 30 }, (_, i) => ({ name: `Competitor ${i}` }));
    const result = validateMarketingProfile({ ...profile, competitors: many });
    assert.equal(result.ok, true);
    if (result.ok) assert.ok(result.data.competitors.length <= 10);
  });
});

describe('crawl consent validation', () => {
  const valid = {
    websiteUrl: 'https://acme-coffee.example',
    consent: true,
    consentVersion: CRAWL_CONSENT_VERSION,
    maxPages: 100,
    retentionDays: 90,
  };

  test('accepts an explicit, versioned consent', () => {
    assert.equal(validateCrawlConsent(valid).ok, true);
  });

  test('REFUSES when consent is absent or false', () => {
    // Silence is not consent. This is the whole point of the step.
    assert.equal(validateCrawlConsent({ ...valid, consent: undefined }).ok, false);
    assert.equal(validateCrawlConsent({ ...valid, consent: false }).ok, false);
    assert.equal(validateCrawlConsent({ ...valid, consent: 'yes' }).ok, false);
  });

  test('refuses a stale consent version', () => {
    const result = validateCrawlConsent({ ...valid, consentVersion: '2020-01-01.v0' });
    assert.equal(result.ok, false);
    if (!result.ok) assert.match(result.errors.consentVersion ?? '', /terms have changed/);
  });

  test('bounds the page limit and retention window', () => {
    assert.equal(validateCrawlConsent({ ...valid, maxPages: 0 }).ok, false);
    assert.equal(validateCrawlConsent({ ...valid, maxPages: 999_999 }).ok, false);
    assert.equal(validateCrawlConsent({ ...valid, retentionDays: 0 }).ok, false);
    assert.equal(validateCrawlConsent({ ...valid, retentionDays: 4000 }).ok, false);
  });

  test('respects robots.txt unless explicitly opted out', () => {
    const result = validateCrawlConsent(valid);
    assert.equal(result.ok, true);
    if (result.ok) assert.equal(result.data.respectRobots, true);
  });
});

describe('project validation', () => {
  test('requires a name', () => {
    assert.equal(validateProject({ name: 'A' }).ok, false);
    assert.equal(validateProject({ name: 'Acme Coffee' }).ok, true);
  });

  test('slugs are URL safe and never empty', () => {
    assert.equal(slugifyProject('Acme Coffee!'), 'acme-coffee');
    assert.equal(slugifyProject('   '), 'project');
    assert.equal(slugifyProject('日本語'), 'project');
    assert.match(slugifyProject('A'.repeat(200)), /^[a-z0-9-]{1,48}$/);
  });
});

/* -------------------------------------------------------------------------- */
/* Tenant isolation — the critical suite                                      */
/* -------------------------------------------------------------------------- */

describe('tenant isolation between two real organizations', () => {
  let alpha: TenantContext;
  let beta: TenantContext;
  let alphaProject: { id: string };

  beforeEach(async () => {
    alpha = await makeTenant('alpha@example.com');
    beta = await makeTenant('beta@example.com');
    alphaProject = await createProject(workspace, alpha, { name: 'Alpha Project' });
  });

  test('the two organizations are genuinely different', () => {
    assert.notEqual(alpha.organizationId, beta.organizationId);
  });

  test('a project is invisible to the other organization', async () => {
    await assert.rejects(() => getProject(workspace, beta, alphaProject.id), NotFoundError);
  });

  test('listing only ever returns your own projects', async () => {
    await createProject(workspace, beta, { name: 'Beta Project' });
    const alphaList = await listProjects(workspace, alpha);
    const betaList = await listProjects(workspace, beta);

    assert.equal(alphaList.length, 1);
    assert.equal(betaList.length, 1);
    assert.equal(alphaList[0]?.name, 'Alpha Project');
    assert.equal(betaList[0]?.name, 'Beta Project');
  });

  test('a cross-tenant update fails as NOT FOUND', async () => {
    await assert.rejects(
      () => updateProject(workspace, beta, alphaProject.id, { name: 'Hijacked' }),
      NotFoundError,
    );
    const untouched = await getProject(workspace, alpha, alphaProject.id);
    assert.equal(untouched.name, 'Alpha Project');
  });

  test('a cross-tenant delete fails and leaves the project alive', async () => {
    await assert.rejects(() => deleteProject(workspace, beta, alphaProject.id), NotFoundError);
    assert.ok(await getProject(workspace, alpha, alphaProject.id));
  });

  test('a cross-tenant marketing profile read fails', async () => {
    await saveMarketingProfile(workspace, alpha, alphaProject.id, profile);
    await assert.rejects(
      () => getMarketingProfile(workspace, beta, alphaProject.id),
      NotFoundError,
    );
  });

  test('a cross-tenant marketing profile write fails', async () => {
    await assert.rejects(
      () => saveMarketingProfile(workspace, beta, alphaProject.id, profile),
      NotFoundError,
    );
  });

  test('a cross-tenant business read fails', async () => {
    const created = await createBusiness(workspace, alpha, business);
    const { getBusiness } = await import('../src/lib/workspace/service');
    await assert.rejects(() => getBusiness(workspace, beta, created.id), NotFoundError);
  });

  test('a cross-tenant crawl consent grant fails', async () => {
    await assert.rejects(
      () =>
        grantCrawlConsent(workspace, beta, alphaProject.id, {
          websiteUrl: 'https://evil.example',
          maxPages: 10,
          respectRobots: true,
          retentionDays: 30,
          consentVersion: CRAWL_CONSENT_VERSION,
        }),
      NotFoundError,
    );
  });

  test('"not yours" and "does not exist" are indistinguishable', async () => {
    let foreign = '';
    let missing = '';
    try {
      await getProject(workspace, beta, alphaProject.id);
    } catch (error) {
      foreign = (error as Error).message;
    }
    try {
      await getProject(workspace, beta, '00000000-0000-0000-0000-000000000000');
    } catch (error) {
      missing = (error as Error).message;
    }
    assert.equal(foreign, missing, 'the error messages leak whether the project exists');
  });

  test('soft-deleted projects disappear from reads', async () => {
    await deleteProject(workspace, alpha, alphaProject.id);
    await assert.rejects(() => getProject(workspace, alpha, alphaProject.id), NotFoundError);
    assert.equal((await listProjects(workspace, alpha)).length, 0);
  });
});

/* -------------------------------------------------------------------------- */
/* Authorization at the service layer                                         */
/* -------------------------------------------------------------------------- */

describe('authorization is enforced in the service, not the UI', () => {
  let owner: TenantContext;

  beforeEach(async () => {
    owner = await makeTenant('owner@example.com');
  });

  test('a plain user cannot create a project', async () => {
    const viewer: TenantContext = { ...owner, role: 'user' };
    await assert.rejects(
      () => createProject(workspace, viewer, { name: 'Nope' }),
      AuthorizationError,
    );
  });

  test('a team member cannot create or delete a project', async () => {
    const member: TenantContext = { ...owner, role: 'team_member' };
    await assert.rejects(() => createProject(workspace, member, { name: 'Nope' }), AuthorizationError);

    const project = await createProject(workspace, owner, { name: 'Owned' });
    await assert.rejects(() => deleteProject(workspace, member, project.id), AuthorizationError);
  });

  test('a manager can create but not delete', async () => {
    const manager: TenantContext = { ...owner, role: 'manager' };
    const project = await createProject(workspace, manager, { name: 'Manager Project' });
    assert.ok(project.id);
    await assert.rejects(() => deleteProject(workspace, manager, project.id), AuthorizationError);
  });

  test('a user without permission is refused before ownership is checked', async () => {
    const viewer: TenantContext = { ...owner, role: 'user' };
    // An authorization error, not a not-found: they must not learn anything
    // about the resource either way.
    await assert.rejects(
      () => deleteProject(workspace, viewer, '00000000-0000-0000-0000-000000000000'),
      AuthorizationError,
    );
  });

  test('a plain user cannot grant crawl consent', async () => {
    const project = await createProject(workspace, owner, { name: 'P' });
    const viewer: TenantContext = { ...owner, role: 'user' };
    await assert.rejects(
      () =>
        grantCrawlConsent(workspace, viewer, project.id, {
          websiteUrl: 'https://example.com',
          maxPages: 10,
          respectRobots: true,
          retentionDays: 30,
          consentVersion: CRAWL_CONSENT_VERSION,
        }),
      AuthorizationError,
    );
  });
});

/* -------------------------------------------------------------------------- */
/* Plan limits                                                                */
/* -------------------------------------------------------------------------- */

describe('plan limits are enforced server-side', () => {
  // Phase 7 renamed the plans and moved the numbers into the plan registry.
  // These tests now read the limit from the registry rather than asserting a
  // literal, so changing a plan's allowance does not require editing a test —
  // what is asserted is that the limit is ENFORCED, which is the property that
  // matters.
  test('the free plan caps projects at its registry limit', async () => {
    const tenant = await makeTenant('free@example.com');
    assert.equal(projectLimitFor('free'), 1);

    await createProject(workspace, tenant, { name: 'First' });
    await assert.rejects(
      () => createProject(workspace, tenant, { name: 'Second' }),
      PlanLimitError,
    );
  });

  test('raising the plan raises the limit', async () => {
    const tenant = await makeTenant('business@example.com');
    await db.subscriptions.update(tenant.organizationId, { plan: 'business' });

    const limit = projectLimitFor('business');
    assert.ok(limit !== null && limit > projectLimitFor('free')!);

    for (let index = 0; index < limit; index += 1) {
      await createProject(workspace, tenant, { name: `Project ${index}` });
    }
    await assert.rejects(() => createProject(workspace, tenant, { name: 'One too many' }), PlanLimitError);
  });

  test('an admin override raises one organization\u2019s limit without a deployment', async () => {
    const tenant = await makeTenant('override@example.com');
    await db.planLimits.set(tenant.organizationId, 'projects', 3, 'Migration from a competitor.', null, new Date());

    await createProject(workspace, tenant, { name: 'One' });
    await createProject(workspace, tenant, { name: 'Two' });
    await createProject(workspace, tenant, { name: 'Three' });
    await assert.rejects(() => createProject(workspace, tenant, { name: 'Four' }), PlanLimitError);
  });

  test('an unlimited plan is not capped', async () => {
    const tenant = await makeTenant('agency@example.com');
    await db.subscriptions.update(tenant.organizationId, { plan: 'agency' });
    assert.equal(projectLimitFor('agency'), null);

    for (let index = 0; index < 8; index += 1) {
      await createProject(workspace, tenant, { name: `Client ${index}` });
    }
    assert.ok(true, 'no refusal');
  });

  test('deleting a project frees a slot', async () => {
    const tenant = await makeTenant('recycle@example.com');
    const first = await createProject(workspace, tenant, { name: 'First' });
    await deleteProject(workspace, tenant, first.id);
    const second = await createProject(workspace, tenant, { name: 'Second' });
    assert.ok(second.id);
  });
});

/* -------------------------------------------------------------------------- */
/* Projects                                                                   */
/* -------------------------------------------------------------------------- */

describe('projects', () => {
  test('slugs are unique within an organization', async () => {
    const tenant = await makeTenant('slugs@example.com');
    await db.subscriptions.update(tenant.organizationId, { plan: 'agency' });

    const a = await createProject(workspace, tenant, { name: 'Acme Coffee' });
    const b = await createProject(workspace, tenant, { name: 'Acme Coffee' });
    assert.notEqual(a.slug, b.slug);
  });

  test('the same slug may exist in a different organization', async () => {
    const alpha = await makeTenant('a@example.com');
    const beta = await makeTenant('b@example.com');
    const one = await createProject(workspace, alpha, { name: 'Shared Name' });
    const two = await createProject(workspace, beta, { name: 'Shared Name' });
    assert.equal(one.slug, two.slug, 'slugs are scoped per organization');
  });

  test('a project cannot be attached to another organization business', async () => {
    const alpha = await makeTenant('alpha2@example.com');
    const beta = await makeTenant('beta2@example.com');
    const alphaBusiness = await createBusiness(workspace, alpha, business);

    await assert.rejects(
      () => createProject(workspace, beta, { name: 'Sneaky', businessId: alphaBusiness.id }),
      NotFoundError,
    );
  });
});

/* -------------------------------------------------------------------------- */
/* Onboarding                                                                 */
/* -------------------------------------------------------------------------- */

describe('onboarding', () => {
  test('creates business, project and marketing profile, and marks the user done', async () => {
    const tenant = await makeTenant('onboard@example.com');
    const result = await completeOnboarding(workspace, tenant, { business, profile });

    assert.equal(result.business.name, 'Acme Coffee');
    assert.equal(result.project.businessId, result.business.id);
    assert.equal(result.profile.projectId, result.project.id);
    assert.equal(result.crawlConsent, null, 'no consent without an explicit grant');

    const user = await db.users.findById(tenant.userId);
    assert.ok(user?.onboardingCompletedAt);
  });

  test('computes profile completeness', async () => {
    const tenant = await makeTenant('complete@example.com');
    const result = await completeOnboarding(workspace, tenant, { business, profile });
    assert.equal(result.profile.completeness, 100);

    const partial = await saveMarketingProfile(workspace, tenant, result.project.id, {
      ...profile,
      competitors: [],
      brandVoice: { tones: [], notes: '' },
    });
    assert.ok(partial.completeness < 100 && partial.completeness > 0);
  });

  test('DOES NOT create a crawl consent without an explicit grant', async () => {
    const tenant = await makeTenant('noconsent@example.com');
    const result = await completeOnboarding(workspace, tenant, { business, profile });
    // A website WAS provided in the business details, and still nothing is
    // consented to. That is the rule this test exists to pin down: entering a
    // URL is not permission to fetch it.
    assert.ok(result.business.websiteUrl, 'the fixture provides a website');
    assert.equal(await getActiveCrawlConsent(workspace, tenant, result.project.id), null);
  });

  test('records a crawl consent when explicitly given', async () => {
    const tenant = await makeTenant('consent@example.com');
    const result = await completeOnboarding(workspace, tenant, {
      business,
      profile,
      crawlConsent: {
        websiteUrl: 'https://acme-coffee.example/',
        maxPages: 50,
        respectRobots: true,
        retentionDays: 60,
        consentVersion: CRAWL_CONSENT_VERSION,
      },
    });

    assert.ok(result.crawlConsent);
    assert.equal(result.crawlConsent?.maxPages, 50);
    assert.equal(result.crawlConsent?.respectRobots, true);
    assert.equal(result.crawlConsent?.revokedAt, null);
  });

  test('a stale consent version is ignored rather than honoured', async () => {
    const tenant = await makeTenant('stale@example.com');
    const result = await completeOnboarding(workspace, tenant, {
      business,
      profile,
      crawlConsent: {
        websiteUrl: 'https://acme-coffee.example/',
        maxPages: 50,
        respectRobots: true,
        retentionDays: 60,
        consentVersion: 'ancient.v0',
      },
    });
    assert.equal(result.crawlConsent, null);
  });

  test('onboarding is audited', async () => {
    const tenant = await makeTenant('audited@example.com');
    await completeOnboarding(workspace, tenant, { business, profile });
    const entries = await db.audit.list(tenant.organizationId);
    assert.ok(entries.some((e) => e.action === 'onboarding.completed' && e.outcome === 'success'));
  });
});

/* -------------------------------------------------------------------------- */
/* Crawl consent lifecycle                                                    */
/* -------------------------------------------------------------------------- */

describe('crawl consent lifecycle', () => {
  test('granting again supersedes rather than stacks', async () => {
    const tenant = await makeTenant('regrant@example.com');
    const project = await createProject(workspace, tenant, { name: 'P' });
    const input = {
      websiteUrl: 'https://example.com/',
      maxPages: 10,
      respectRobots: true,
      retentionDays: 30,
      consentVersion: CRAWL_CONSENT_VERSION,
    };

    const first = await grantCrawlConsent(workspace, tenant, project.id, input);
    const second = await grantCrawlConsent(workspace, tenant, project.id, { ...input, maxPages: 20 });

    const active = await getActiveCrawlConsent(workspace, tenant, project.id);
    assert.equal(active?.id, second.id);

    const all = await db.crawlConsents.listForProject(tenant.organizationId, project.id);
    const superseded = all.find((c) => c.id === first.id);
    assert.ok(superseded?.revokedAt, 'the previous consent must be revoked, not left live');
  });

  test('revoking stops it and can erase the data', async () => {
    const tenant = await makeTenant('revoke@example.com');
    const project = await createProject(workspace, tenant, { name: 'P' });
    const consent = await grantCrawlConsent(workspace, tenant, project.id, {
      websiteUrl: 'https://example.com/',
      maxPages: 10,
      respectRobots: true,
      retentionDays: 30,
      consentVersion: CRAWL_CONSENT_VERSION,
    });

    await revokeCrawlConsent(workspace, { ...tenant, projectId: project.id }, consent.id);

    assert.equal(await getActiveCrawlConsent(workspace, tenant, project.id), null);
    const all = await db.crawlConsents.listForProject(tenant.organizationId, project.id);
    assert.ok(all[0]?.revokedAt);
    assert.ok(all[0]?.dataDeletedAt, 'data erasure should be recorded');
  });

  test('the consent records exactly what was agreed', async () => {
    const tenant = await makeTenant('terms@example.com');
    const project = await createProject(workspace, tenant, { name: 'P' });
    const consent = await grantCrawlConsent(workspace, tenant, project.id, {
      websiteUrl: 'https://example.com/',
      maxPages: 25,
      respectRobots: true,
      retentionDays: 45,
      consentVersion: CRAWL_CONSENT_VERSION,
    });

    // Storing the version means a later change to the wording cannot
    // retroactively widen a consent someone already gave.
    assert.equal(consent.consentVersion, CRAWL_CONSENT_VERSION);
    assert.equal(consent.maxPages, 25);
    assert.equal(consent.retentionDays, 45);
    assert.equal(consent.grantedBy, tenant.userId);
  });

  test('granting and revoking are both audited', async () => {
    const tenant = await makeTenant('crawlaudit@example.com');
    const project = await createProject(workspace, tenant, { name: 'P' });
    const consent = await grantCrawlConsent(workspace, tenant, project.id, {
      websiteUrl: 'https://example.com/',
      maxPages: 10,
      respectRobots: true,
      retentionDays: 30,
      consentVersion: CRAWL_CONSENT_VERSION,
    });
    await revokeCrawlConsent(workspace, { ...tenant, projectId: project.id }, consent.id);

    const entries = await db.audit.list(tenant.organizationId);
    assert.ok(entries.some((e) => e.action === 'crawl.consent.granted'));
    assert.ok(entries.some((e) => e.action === 'crawl.consent.revoked'));
  });
});
