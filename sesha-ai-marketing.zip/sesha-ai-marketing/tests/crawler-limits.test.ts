import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  CrawlQueue,
  DEFAULT_LIMITS,
  MAX_ALLOWED_PAGES,
  PolitenessGate,
  crawlSite,
  limitsForPlan,
  parseRobots,
  parseSitemap,
  resolveLimits,
  isAllowed,
  groupFor,
  crawlDelayMs,
  defaultSitemapUrls,
  parseLastModified,
  NO_ROBOTS,
  ROBOTS_UNAVAILABLE,
  describeRobots,
  extractPage,
  type CrawlGrant,
  type LookupFn,
  type Transport,
  type TransportRequest,
} from '../src/lib/crawler';

/**
 * Crawl limits, robots compliance, sitemap handling and the queue.
 *
 * Everything here is about the crawler being a good citizen: it fetches no more
 * than it said it would, no faster than the site allows, and nothing the site
 * asked it not to. These are the protections that stop a legitimate audit from
 * becoming a denial-of-service against a customer's own website.
 */

const PUBLIC_ADDRESS = '93.184.216.34';
const lookup: LookupFn = async () => [{ address: PUBLIC_ADDRESS, family: 4 }];

/* -------------------------------------------------------------------------- */
/* Limits resolution                                                          */
/* -------------------------------------------------------------------------- */

describe('limits are a ceiling, never a floor', () => {
  test('a request for more pages than the plan allows is CLAMPED', () => {
    const smallest = limitsForPlan('free');
    const resolved = resolveLimits('free', { maxPages: 10_000, maxDepth: 99 });

    assert.equal(resolved.maxPages, smallest.maxPages);
    assert.equal(resolved.maxDepth, smallest.maxDepth);
  });

  test('a request for fewer pages is honoured', () => {
    assert.equal(resolveLimits('agency', { maxPages: 5 }).maxPages, 5);
    assert.equal(resolveLimits('agency', { maxDepth: 1 }).maxDepth, 1);
  });

  test('no plan can exceed the absolute cap', () => {
    for (const plan of ['free', 'pro', 'business', 'agency'] as const) {
      assert.ok(
        limitsForPlan(plan).maxPages <= MAX_ALLOWED_PAGES,
        `${plan} exceeds the absolute page cap`,
      );
    }
  });

  test('plans differ, and larger plans are larger', () => {
    assert.ok(limitsForPlan('free').maxPages < limitsForPlan('pro').maxPages);
    assert.ok(limitsForPlan('pro').maxPages < limitsForPlan('business').maxPages);
    assert.ok(limitsForPlan('business').maxPages < limitsForPlan('agency').maxPages);
  });

  test('zero and negative requests become at least one page', () => {
    assert.equal(resolveLimits('free', { maxPages: 0 }).maxPages, 1);
    assert.equal(resolveLimits('free', { maxPages: -5 }).maxPages, 1);
    assert.equal(resolveLimits('free', { maxDepth: -1 }).maxDepth, 0);
  });

  test('the defaults are polite rather than fast', () => {
    // Roughly one request per second, which is less load than one human browsing.
    assert.ok(DEFAULT_LIMITS.concurrency <= 3, 'default concurrency is too high for a polite crawler');
    assert.ok(DEFAULT_LIMITS.delayMs >= 250, 'default delay is too short');
    assert.ok(DEFAULT_LIMITS.totalTimeoutMs <= 30 * 60_000, 'a crawl could run for too long');
  });
});

/* -------------------------------------------------------------------------- */
/* The queue                                                                  */
/* -------------------------------------------------------------------------- */

describe('the crawl queue', () => {
  const limits = { ...DEFAULT_LIMITS, maxPages: 3, maxDepth: 2 };

  test('deduplicates on the normalised URL', () => {
    const queue = new CrawlQueue(limits);
    assert.equal(queue.enqueue('https://example.com/a', 0, 'seed').accepted, true);
    // Same page, three spellings.
    assert.equal(queue.enqueue('https://example.com/a#top', 0, 'link').accepted, false);
    assert.equal(queue.enqueue('https://example.com/a/', 0, 'link').accepted, false);
    assert.equal(queue.enqueue('https://example.com/a?utm_source=x', 0, 'link').accepted, false);
    assert.equal(queue.pending, 1);
  });

  test('refuses a URL deeper than the limit', () => {
    const queue = new CrawlQueue(limits);
    const result = queue.enqueue('https://example.com/deep', 5, 'link');
    assert.equal(result.accepted, false);
    assert.equal(result.reason, 'too_deep');
  });

  test('refuses once the page BUDGET is full, counting work in flight', () => {
    const queue = new CrawlQueue(limits);
    for (let index = 0; index < 3; index += 1) {
      assert.equal(queue.enqueue(`https://example.com/${index}`, 0, 'link').accepted, true);
    }
    const overflow = queue.enqueue('https://example.com/4', 0, 'link');
    assert.equal(overflow.accepted, false);
    assert.equal(overflow.reason, 'budget_full');
  });

  test('the budget counts DEQUEUED pages too, so it cannot be overshot', () => {
    // The bug this prevents: checking the budget only on enqueue lets already-
    // dequeued work push the real total past the limit.
    const queue = new CrawlQueue(limits);
    queue.enqueue('https://example.com/1', 0, 'seed');
    queue.dequeue();
    queue.enqueue('https://example.com/2', 0, 'link');
    queue.dequeue();
    queue.enqueue('https://example.com/3', 0, 'link');
    queue.dequeue();

    assert.equal(queue.enqueue('https://example.com/4', 0, 'link').accepted, false);
    assert.equal(queue.dequeue(), null, 'dequeued past the page budget');
  });

  test('dequeue stops at the budget even with items still queued', () => {
    const queue = new CrawlQueue({ ...DEFAULT_LIMITS, maxPages: 2, maxDepth: 3 });
    queue.enqueue('https://example.com/1', 0, 'seed');
    queue.enqueue('https://example.com/2', 0, 'link');

    assert.ok(queue.dequeue());
    assert.ok(queue.dequeue());
    assert.equal(queue.dequeue(), null);
  });

  test('is BREADTH-first, so a big site contributes its top levels', () => {
    const queue = new CrawlQueue({ ...DEFAULT_LIMITS, maxPages: 10, maxDepth: 3 });
    queue.enqueue('https://example.com/deep', 2, 'link');
    queue.enqueue('https://example.com/shallow', 0, 'seed');
    queue.enqueue('https://example.com/middle', 1, 'link');

    assert.equal(queue.dequeue()?.url, 'https://example.com/shallow');
    assert.equal(queue.dequeue()?.url, 'https://example.com/middle');
    assert.equal(queue.dequeue()?.url, 'https://example.com/deep');
  });

  test('an invalid URL is refused without throwing', () => {
    const queue = new CrawlQueue(limits);
    const result = queue.enqueue('not a url at all', 0, 'link');
    assert.equal(result.accepted, false);
    assert.equal(result.reason, 'invalid');
  });

  test('a rejected URL is remembered, so it is not reconsidered endlessly', () => {
    const queue = new CrawlQueue(limits);
    queue.reject('https://example.com/blocked', 'robots');
    assert.equal(queue.enqueue('https://example.com/blocked', 0, 'link').accepted, false);
  });

  test('skip reasons are counted, so a crawl can explain what it left out', () => {
    const queue = new CrawlQueue(limits);
    queue.enqueue('https://example.com/a', 0, 'seed');
    queue.enqueue('https://example.com/a', 0, 'link');
    queue.enqueue('https://example.com/deep', 9, 'link');

    const counts = queue.skipCounts();
    assert.equal(counts.duplicate, 1);
    assert.equal(counts.too_deep, 1);
  });
});

/* -------------------------------------------------------------------------- */
/* Politeness                                                                 */
/* -------------------------------------------------------------------------- */

describe('politeness between requests', () => {
  test('the second request to a host waits the delay', async () => {
    let currentTime = 1_000;
    const slept: number[] = [];
    const gate = new PolitenessGate(
      500,
      () => currentTime,
      async (ms) => {
        slept.push(ms);
        currentTime += ms;
      },
    );

    assert.equal(await gate.wait('example.com'), 0);
    assert.equal(await gate.wait('example.com'), 500);
    assert.deepEqual(slept, [500]);
  });

  test('a different host does not wait behind the first', async () => {
    const gate = new PolitenessGate(500, () => 1_000, async () => {});
    await gate.wait('a.example.com');
    assert.equal(await gate.wait('b.example.com'), 0);
  });

  test('two CONCURRENT callers do not both fire immediately', async () => {
    // The slot is reserved before sleeping; otherwise both observe the same
    // "it is time" and the delay achieves nothing.
    let currentTime = 0;
    const gate = new PolitenessGate(1_000, () => currentTime, async (ms) => {
      currentTime += ms;
    });

    const [first, second] = await Promise.all([gate.wait('example.com'), gate.wait('example.com')]);
    assert.equal(first, 0);
    assert.ok(second >= 1_000, 'the second concurrent request did not wait');
  });
});

/* -------------------------------------------------------------------------- */
/* robots.txt                                                                 */
/* -------------------------------------------------------------------------- */

describe('robots.txt parsing', () => {
  test('parses groups, rules, crawl-delay and sitemaps', () => {
    const robots = parseRobots(`
      # a comment
      User-agent: *
      Disallow: /admin
      Allow: /admin/public
      Crawl-delay: 2

      User-agent: SeShaBot
      Disallow: /private/

      Sitemap: https://example.com/sitemap.xml
    `);

    assert.equal(robots.groups.length, 2);
    assert.deepEqual(robots.sitemaps, ['https://example.com/sitemap.xml']);
  });

  test('our own group WINS over the wildcard, and rules are not merged', () => {
    // A site that addresses us specifically has said everything it means to.
    const robots = parseRobots(
      'User-agent: *\nDisallow: /\n\nUser-agent: SeShaBot\nDisallow: /private/',
    );
    assert.deepEqual(groupFor(robots)?.agents, ['seshabot']);
    assert.equal(isAllowed(robots, 'https://example.com/public').allowed, true);
    assert.equal(isAllowed(robots, 'https://example.com/private/x').allowed, false);
  });

  test('the MOST SPECIFIC rule wins, and Allow wins a tie', () => {
    const robots = parseRobots('User-agent: *\nDisallow: /admin\nAllow: /admin/public');
    assert.equal(isAllowed(robots, 'https://example.com/admin/secret').allowed, false);
    assert.equal(isAllowed(robots, 'https://example.com/admin/public/x').allowed, true);
  });

  test('wildcards and end-anchors are honoured', () => {
    const robots = parseRobots('User-agent: *\nDisallow: /*.json$\nDisallow: /tmp/*/cache');
    assert.equal(isAllowed(robots, 'https://example.com/data.json').allowed, false);
    // The $ anchors it, so a query string after .json is not matched.
    assert.equal(isAllowed(robots, 'https://example.com/data.json?v=1').allowed, true);
    assert.equal(isAllowed(robots, 'https://example.com/tmp/a/cache').allowed, false);
  });

  test('an empty Disallow means allow everything', () => {
    const robots = parseRobots('User-agent: *\nDisallow:');
    assert.equal(isAllowed(robots, 'https://example.com/anything').allowed, true);
  });

  test('a regex metacharacter in a path cannot change the pattern', () => {
    const robots = parseRobots('User-agent: *\nDisallow: /a+b(c)');
    assert.equal(isAllowed(robots, 'https://example.com/a+b(c)').allowed, false);
    assert.equal(isAllowed(robots, 'https://example.com/aaab').allowed, true);
  });

  test('consecutive User-agent lines share one group', () => {
    const robots = parseRobots('User-agent: Foo\nUser-agent: SeShaBot\nDisallow: /x');
    assert.equal(isAllowed(robots, 'https://example.com/x').allowed, false);
  });

  test('CRLF, a BOM and unknown directives are all tolerated', () => {
    const robots = parseRobots('﻿User-agent: *\r\nHost: example.com\r\nDisallow: /x\r\n');
    assert.equal(isAllowed(robots, 'https://example.com/x').allowed, false);
  });

  test('an absent robots.txt permits crawling', () => {
    assert.equal(isAllowed(NO_ROBOTS, 'https://example.com/anything').allowed, true);
  });

  test('an UNREADABLE robots.txt permits nothing — fail closed', () => {
    // A 5xx or a timeout is ambiguous, and ambiguity must not be read as consent.
    const decision = isAllowed(ROBOTS_UNAVAILABLE, 'https://example.com/anything');
    assert.equal(decision.allowed, false);
    assert.match(decision.reason, /could not be read/i);
  });

  test('the crawl delay is clamped to a sane window', () => {
    const fast = parseRobots('User-agent: *\nCrawl-delay: 0');
    const slow = parseRobots('User-agent: *\nCrawl-delay: 99999');
    assert.equal(crawlDelayMs(fast, 500, 10_000), 500, 'a zero delay must not override our floor');
    assert.equal(crawlDelayMs(slow, 500, 10_000), 10_000, 'an absurd delay must be capped');
  });

  test('a decimal crawl delay is honoured', () => {
    const robots = parseRobots('User-agent: *\nCrawl-delay: 1.5');
    assert.equal(crawlDelayMs(robots, 100, 10_000), 1_500);
  });

  test('describeRobots explains each state in plain words', () => {
    assert.match(describeRobots(NO_ROBOTS), /no robots\.txt/i);
    assert.match(describeRobots(ROBOTS_UNAVAILABLE), /could not be read/i);
    assert.match(describeRobots(parseRobots('User-agent: *\nDisallow: /x')), /1 rule/);
  });
});

/* -------------------------------------------------------------------------- */
/* Sitemaps                                                                   */
/* -------------------------------------------------------------------------- */

describe('sitemap parsing', () => {
  const base = 'https://example.com/sitemap.xml';

  test('reads a urlset with its metadata', () => {
    const parsed = parseSitemap(
      `<?xml version="1.0"?>
       <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
         <url><loc>https://example.com/a</loc><lastmod>2026-01-15</lastmod><priority>0.8</priority></url>
         <url><loc>https://example.com/b</loc><changefreq>weekly</changefreq></url>
       </urlset>`,
      base,
    );

    assert.equal(parsed.kind, 'urlset');
    assert.equal(parsed.entries.length, 2);
    assert.equal(parsed.entries[0]?.lastModified, '2026-01-15');
    assert.equal(parsed.entries[0]?.priority, 0.8);
    assert.equal(parsed.entries[1]?.changeFrequency, 'weekly');
  });

  test('reads a sitemap index', () => {
    const parsed = parseSitemap(
      `<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
         <sitemap><loc>https://example.com/sitemap-1.xml</loc></sitemap>
         <sitemap><loc>https://example.com/sitemap-2.xml</loc></sitemap>
       </sitemapindex>`,
      base,
    );

    assert.equal(parsed.kind, 'sitemapindex');
    assert.equal(parsed.sitemaps.length, 2);
  });

  test('handles namespace prefixes and CDATA', () => {
    const parsed = parseSitemap(
      `<sm:urlset xmlns:sm="http://www.sitemaps.org/schemas/sitemap/0.9">
         <sm:url><sm:loc><![CDATA[https://example.com/a]]></sm:loc></sm:url>
       </sm:urlset>`,
      base,
    );
    assert.equal(parsed.entries[0]?.url, 'https://example.com/a');
  });

  test('REFUSES a document with a DOCTYPE or ENTITY declaration', () => {
    // The billion-laughs and XXE vehicles. A sitemap has no legitimate use for
    // either, so the document is refused rather than parsed around.
    const bomb = `<?xml version="1.0"?>
      <!DOCTYPE lolz [<!ENTITY lol "lol"><!ENTITY lol2 "&lol;&lol;&lol;">]>
      <urlset><url><loc>https://example.com/&lol2;</loc></url></urlset>`;
    assert.equal(parseSitemap(bomb, base).entries.length, 0);

    const xxe = `<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
      <urlset><url><loc>https://example.com/&xxe;</loc></url></urlset>`;
    assert.equal(parseSitemap(xxe, base).entries.length, 0);
  });

  test('REJECTS cross-site URLs', () => {
    // A sitemap may only list its own site. Honouring one that points elsewhere
    // turns the crawler into a relay for somebody else's link list.
    const parsed = parseSitemap(
      `<urlset>
         <url><loc>https://example.com/mine</loc></url>
         <url><loc>https://evil.example.net/theirs</loc></url>
       </urlset>`,
      base,
    );
    assert.equal(parsed.entries.length, 1);
    assert.equal(parsed.entries[0]?.url, 'https://example.com/mine');
  });

  test('rejects a dangerous scheme in a loc', () => {
    const parsed = parseSitemap(
      `<urlset><url><loc>file:///etc/passwd</loc></url><url><loc>http://127.0.0.1/</loc></url></urlset>`,
      base,
    );
    assert.equal(parsed.entries.length, 0);
  });

  test('reads the plain-text form', () => {
    const parsed = parseSitemap(
      '# comment\nhttps://example.com/a\nhttps://example.com/b\n\n',
      base,
    );
    assert.equal(parsed.kind, 'text');
    assert.equal(parsed.entries.length, 2);
  });

  test('decodes entities without letting &amp;lt; become a tag', () => {
    const parsed = parseSitemap(
      '<urlset><url><loc>https://example.com/a?x=1&amp;y=2</loc></url></urlset>',
      base,
    );
    assert.equal(parsed.entries[0]?.url.includes('y=2'), true);
  });

  test('an out-of-range priority is dropped rather than clamped', () => {
    const parsed = parseSitemap(
      '<urlset><url><loc>https://example.com/a</loc><priority>17</priority></url></urlset>',
      base,
    );
    assert.equal(parsed.entries[0]?.priority, null);
  });

  test('the conventional locations are tried in a sensible order', () => {
    const candidates = defaultSitemapUrls('https://example.com/some/page');
    assert.equal(candidates[0], 'https://example.com/sitemap.xml');
    assert.ok(candidates.every((url) => url.startsWith('https://example.com/')));
  });

  test('lastmod parses both the date and the datetime form', () => {
    assert.ok(parseLastModified('2026-01-15'));
    assert.ok(parseLastModified('2026-01-15T10:30:00Z'));
    assert.equal(parseLastModified('not a date'), null);
    assert.equal(parseLastModified(null), null);
  });
});

/* -------------------------------------------------------------------------- */
/* The crawl, end to end                                                      */
/* -------------------------------------------------------------------------- */

interface Site {
  [url: string]: { status: number; body?: string; headers?: Record<string, string> };
}

function siteTransport(site: Site): { transport: Transport; requests: TransportRequest[] } {
  const requests: TransportRequest[] = [];
  const transport: Transport = async (request) => {
    requests.push(request);
    const page = site[request.url];
    if (!page) return { status: 404, headers: { 'content-type': 'text/html' }, body: '', bytes: 0, truncated: false };
    const body = page.body ?? '';
    return {
      status: page.status,
      headers: { 'content-type': 'text/html', ...page.headers },
      body,
      bytes: Buffer.byteLength(body),
      truncated: false,
    };
  };
  return { transport, requests };
}

function page(title: string, links: string[] = []): string {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>${title}</title><meta name="description" content="A description of ${title} that is long enough to be realistic for testing purposes.">
    <link rel="canonical" href="https://example.com/">
    </head><body><h1>${title}</h1>
    <p>${'Some body text about the subject. '.repeat(20)}</p>
    ${links.map((href) => `<a href="${href}">${href}</a>`).join('')}
    </body></html>`;
}

const grant: CrawlGrant = {
  websiteUrl: 'https://example.com/',
  respectRobots: true,
  maxPages: 50,
  grantedAt: new Date('2026-01-01'),
};

describe('the crawl honours its limits', () => {
  test('stops at the page budget and says so', async () => {
    const site: Site = {
      'https://example.com/robots.txt': { status: 404 },
      'https://example.com/': { status: 200, body: page('Home', ['/a', '/b', '/c', '/d', '/e']) },
    };
    for (const path of ['a', 'b', 'c', 'd', 'e']) {
      site[`https://example.com/${path}`] = { status: 200, body: page(path.toUpperCase()) };
    }

    const { transport, requests } = siteTransport(site);
    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 3, maxDepth: 2, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
    });

    assert.equal(outcome.ok, true);
    if (!outcome.ok) return;
    assert.equal(outcome.report.pages.length, 3);
    assert.ok(outcome.report.stoppedEarly, 'a truncated crawl must say it was truncated');

    // Exactly three PAGE fetches. robots.txt and the sitemap probes are
    // discovery, not pages, and the page budget does not govern them.
    const pageRequests = requests.filter(
      (request) => !/robots\.txt$|sitemap[\w.-]*\.(xml|txt)$/.test(request.url),
    );
    assert.equal(pageRequests.length, 3);
  });

  test('respects the depth limit', async () => {
    const site: Site = {
      'https://example.com/robots.txt': { status: 404 },
      'https://example.com/': { status: 200, body: page('Home', ['/one']) },
      'https://example.com/one': { status: 200, body: page('One', ['/two']) },
      'https://example.com/two': { status: 200, body: page('Two', ['/three']) },
      'https://example.com/three': { status: 200, body: page('Three') },
    };

    const { transport } = siteTransport(site);
    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 50, maxDepth: 1, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
    });

    assert.equal(outcome.ok, true);
    if (!outcome.ok) return;
    // Depth 0 (home) and depth 1 (/one). /two is depth 2 and out of scope.
    const urls = outcome.report.pages.map((item) => item.url);
    assert.ok(urls.includes('https://example.com/'));
    assert.ok(urls.includes('https://example.com/one'));
    assert.ok(!urls.includes('https://example.com/two'), 'crawled past the depth limit');
  });

  test('does not follow a link to another site', async () => {
    const { transport, requests } = siteTransport({
      'https://example.com/robots.txt': { status: 404 },
      'https://example.com/': {
        status: 200,
        body: page('Home', ['https://other.example.net/page', '/mine']),
      },
      'https://example.com/mine': { status: 200, body: page('Mine') },
    });

    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 20, maxDepth: 3, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
    });

    assert.equal(outcome.ok, true);
    assert.ok(
      !requests.some((request) => request.url.includes('other.example.net')),
      'the crawler left the site it was authorised for',
    );
  });

  test('skips asset URLs so the budget is spent on pages', async () => {
    const { transport, requests } = siteTransport({
      'https://example.com/robots.txt': { status: 404 },
      'https://example.com/': {
        status: 200,
        body: page('Home', ['/brochure.pdf', '/photo.jpg', '/styles.css', '/real-page']),
      },
      'https://example.com/real-page': { status: 200, body: page('Real') },
    });

    await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 20, maxDepth: 2, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
    });

    for (const extension of ['.pdf', '.jpg', '.css']) {
      assert.ok(
        !requests.some((request) => request.url.endsWith(extension)),
        `fetched a ${extension} asset`,
      );
    }
  });
});

describe('the crawl honours robots.txt', () => {
  test('a disallowed path is never fetched', async () => {
    const { transport, requests } = siteTransport({
      'https://example.com/robots.txt': {
        status: 200,
        body: 'User-agent: *\nDisallow: /private/',
        headers: { 'content-type': 'text/plain' },
      },
      'https://example.com/': { status: 200, body: page('Home', ['/private/secret', '/public']) },
      'https://example.com/public': { status: 200, body: page('Public') },
      'https://example.com/private/secret': { status: 200, body: page('Secret') },
    });

    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 20, maxDepth: 2, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
    });

    assert.equal(outcome.ok, true);
    if (!outcome.ok) return;
    assert.ok(
      !requests.some((request) => request.url.includes('/private/')),
      'fetched a path robots.txt disallowed',
    );
    assert.ok(outcome.report.robots.blockedCount > 0, 'the blocked count was not recorded');
  });

  test('a disallowed SEED means nothing is crawled', async () => {
    const { transport, requests } = siteTransport({
      'https://example.com/robots.txt': {
        status: 200,
        body: 'User-agent: *\nDisallow: /',
        headers: { 'content-type': 'text/plain' },
      },
      'https://example.com/': { status: 200, body: page('Home') },
    });

    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 20, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
    });

    assert.equal(outcome.ok, true);
    if (!outcome.ok) return;
    assert.equal(outcome.report.pages.length, 0);
    assert.equal(requests.filter((request) => !request.url.endsWith('robots.txt')).length, 0);
  });

  test('an UNREADABLE robots.txt stops the crawl entirely', async () => {
    // A 500 on robots.txt is ambiguous. Crawling anyway risks ignoring rules the
    // owner did set, so the crawl does not start.
    const { transport, requests } = siteTransport({
      'https://example.com/robots.txt': { status: 500 },
      'https://example.com/': { status: 200, body: page('Home') },
    });

    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
    });

    assert.equal(outcome.ok, false);
    if (outcome.ok) return;
    assert.equal(outcome.code, 'robots_unavailable');
    assert.equal(requests.filter((request) => !request.url.endsWith('robots.txt')).length, 0);
  });

  test('a 404 on robots.txt is treated as no rules, and crawling proceeds', async () => {
    const { transport } = siteTransport({
      'https://example.com/robots.txt': { status: 404 },
      'https://example.com/': { status: 200, body: page('Home') },
    });

    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
    });

    assert.equal(outcome.ok, true);
    if (outcome.ok) assert.equal(outcome.report.pages.length, 1);
  });

  test("the site's Crawl-delay is applied", async () => {
    const { transport } = siteTransport({
      'https://example.com/robots.txt': {
        status: 200,
        body: 'User-agent: *\nCrawl-delay: 3',
        headers: { 'content-type': 'text/plain' },
      },
      'https://example.com/': { status: 200, body: page('Home') },
    });

    const slept: number[] = [];
    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 5, concurrency: 1, delayMs: 100, maxDelayMs: 10_000 },
      fetchOptions: { transport, lookup },
      sleep: async (ms) => {
        slept.push(ms);
      },
    });

    assert.equal(outcome.ok, true);
    if (outcome.ok) assert.equal(outcome.report.robots.crawlDelayMs, 3_000);
  });
});

describe('the crawl uses the sitemap', () => {
  test('sitemap URLs are crawled even when nothing links to them', async () => {
    const { transport } = siteTransport({
      'https://example.com/robots.txt': {
        status: 200,
        body: 'User-agent: *\nSitemap: https://example.com/sitemap.xml',
        headers: { 'content-type': 'text/plain' },
      },
      'https://example.com/sitemap.xml': {
        status: 200,
        body: '<urlset><url><loc>https://example.com/orphan</loc></url></urlset>',
        headers: { 'content-type': 'application/xml' },
      },
      'https://example.com/': { status: 200, body: page('Home') },
      'https://example.com/orphan': { status: 200, body: page('Orphan') },
    });

    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 20, maxDepth: 2, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
    });

    assert.equal(outcome.ok, true);
    if (!outcome.ok) return;
    assert.ok(outcome.report.sitemap.found);
    assert.ok(outcome.report.pages.some((item) => item.url === 'https://example.com/orphan'));
  });

  test('a sitemap URL that robots.txt disallows is still not fetched', async () => {
    // The two rules interact: a sitemap listing a disallowed URL does not
    // override the disallow.
    const { transport, requests } = siteTransport({
      'https://example.com/robots.txt': {
        status: 200,
        body: 'User-agent: *\nDisallow: /private/\nSitemap: https://example.com/sitemap.xml',
        headers: { 'content-type': 'text/plain' },
      },
      'https://example.com/sitemap.xml': {
        status: 200,
        body: '<urlset><url><loc>https://example.com/private/page</loc></url></urlset>',
        headers: { 'content-type': 'application/xml' },
      },
      'https://example.com/': { status: 200, body: page('Home') },
      'https://example.com/private/page': { status: 200, body: page('Private') },
    });

    await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 20, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
    });

    assert.ok(!requests.some((request) => request.url.includes('/private/')));
  });

  test('a sitemap index is followed one level', async () => {
    const { transport } = siteTransport({
      'https://example.com/robots.txt': {
        status: 200,
        body: 'Sitemap: https://example.com/sitemap.xml',
        headers: { 'content-type': 'text/plain' },
      },
      'https://example.com/sitemap.xml': {
        status: 200,
        body: '<sitemapindex><sitemap><loc>https://example.com/sitemap-posts.xml</loc></sitemap></sitemapindex>',
        headers: { 'content-type': 'application/xml' },
      },
      'https://example.com/sitemap-posts.xml': {
        status: 200,
        body: '<urlset><url><loc>https://example.com/post-1</loc></url></urlset>',
        headers: { 'content-type': 'application/xml' },
      },
      'https://example.com/': { status: 200, body: page('Home') },
      'https://example.com/post-1': { status: 200, body: page('Post 1') },
    });

    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 20, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
    });

    assert.equal(outcome.ok, true);
    if (outcome.ok) {
      assert.ok(outcome.report.pages.some((item) => item.url === 'https://example.com/post-1'));
    }
  });

  test('a missing sitemap is reported, not invented', async () => {
    const { transport } = siteTransport({
      'https://example.com/robots.txt': { status: 404 },
      'https://example.com/': { status: 200, body: page('Home') },
    });

    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
    });

    assert.equal(outcome.ok, true);
    if (outcome.ok) {
      assert.equal(outcome.report.sitemap.found, false);
      assert.match(outcome.report.sitemap.note, /no sitemap/i);
    }
  });
});

describe('the crawl handles failure and cancellation', () => {
  test('a 404 on one page does not stop the crawl', async () => {
    const { transport } = siteTransport({
      'https://example.com/robots.txt': { status: 404 },
      'https://example.com/': { status: 200, body: page('Home', ['/gone', '/fine']) },
      'https://example.com/fine': { status: 200, body: page('Fine') },
      'https://example.com/gone': { status: 404, body: 'Not found' },
    });

    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 20, maxDepth: 2, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
    });

    assert.equal(outcome.ok, true);
    if (!outcome.ok) return;
    assert.equal(outcome.report.pages.length, 2);
    assert.equal(outcome.report.failures.length, 1);
    assert.equal(outcome.report.failures[0]?.status, 404);
  });

  test('cancellation stops the crawl and keeps what was read', async () => {
    const site: Site = { 'https://example.com/robots.txt': { status: 404 } };
    const paths = Array.from({ length: 10 }, (_, index) => `/p${index}`);
    site['https://example.com/'] = { status: 200, body: page('Home', paths) };
    for (const path of paths) {
      site[`https://example.com${path}`] = { status: 200, body: page(path) };
    }

    const { transport } = siteTransport(site);
    let fetched = 0;
    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 20, maxDepth: 2, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
      onProgress: () => {
        fetched += 1;
      },
      isCancelled: () => fetched >= 3,
    });

    assert.equal(outcome.ok, true);
    if (!outcome.ok) return;
    assert.equal(outcome.report.cancelled, true);
    assert.ok(outcome.report.pages.length > 0, 'a cancelled crawl discarded the pages it had read');
    assert.ok(outcome.report.pages.length < 11);
  });

  test('progress is reported after every page', async () => {
    const { transport } = siteTransport({
      'https://example.com/robots.txt': { status: 404 },
      'https://example.com/': { status: 200, body: page('Home', ['/a']) },
      'https://example.com/a': { status: 200, body: page('A') },
    });

    const progress: number[] = [];
    await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 20, maxDepth: 2, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      sleep: async () => {},
      onProgress: (update) => {
        progress.push(update.fetched);
      },
    });

    assert.deepEqual(progress, [1, 2]);
  });

  test('a blocked seed URL fails before anything is fetched', async () => {
    const { transport, requests } = siteTransport({});
    const outcome = await crawlSite(
      { ...grant, websiteUrl: 'http://169.254.169.254/' },
      { limits: DEFAULT_LIMITS, fetchOptions: { transport, lookup }, sleep: async () => {} },
    );

    assert.equal(outcome.ok, false);
    assert.equal(requests.length, 0);
  });

  test('a crawl records the limits it actually applied', async () => {
    const { transport } = siteTransport({
      'https://example.com/robots.txt': { status: 404 },
      'https://example.com/': { status: 200, body: page('Home') },
    });

    // The grant allows 5; the plan limit allows 50. The narrower wins.
    const outcome = await crawlSite(
      { ...grant, maxPages: 5 },
      {
        limits: { ...DEFAULT_LIMITS, maxPages: 50, concurrency: 1, delayMs: 0 },
        fetchOptions: { transport, lookup },
        sleep: async () => {},
      },
    );

    assert.equal(outcome.ok, true);
    if (outcome.ok) assert.equal(outcome.report.limits.maxPages, 5);
  });
});

/* -------------------------------------------------------------------------- */
/* Page timestamps                                                            */
/* -------------------------------------------------------------------------- */

describe('every page records when it was read', () => {
  test('crawledAt is set on each page', () => {
    const at = new Date('2026-03-01T12:00:00Z');
    const extracted = extractPage({
      url: 'https://example.com/',
      html: page('Home'),
      status: 200,
      bytes: 500,
      responseTimeMs: 120,
      crawledAt: at,
    });
    assert.equal(extracted.crawledAt.toISOString(), at.toISOString());
  });

  test('two pages in one crawl carry their own fetch time', async () => {
    let currentTime = Date.parse('2026-03-01T12:00:00Z');
    const { transport } = siteTransport({
      'https://example.com/robots.txt': { status: 404 },
      'https://example.com/': { status: 200, body: page('Home', ['/a']) },
      'https://example.com/a': { status: 200, body: page('A') },
    });

    const outcome = await crawlSite(grant, {
      limits: { ...DEFAULT_LIMITS, maxPages: 5, maxDepth: 2, concurrency: 1, delayMs: 0 },
      fetchOptions: { transport, lookup },
      now: () => (currentTime += 1_000),
      sleep: async () => {},
    });

    assert.equal(outcome.ok, true);
    if (!outcome.ok) return;
    const times = outcome.report.pages.map((item) => item.crawledAt.getTime());
    assert.equal(new Set(times).size, times.length, 'pages share one timestamp');
  });
});
