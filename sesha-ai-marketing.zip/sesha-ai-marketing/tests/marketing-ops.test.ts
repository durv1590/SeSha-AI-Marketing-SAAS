import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { signUp, toRole } from '../src/lib/auth/service';
import { completeOnboarding } from '../src/lib/workspace/service';
import { NotFoundError, type TenantContext } from '../src/lib/tenant';

import {
  AD_PLATFORMS,
  AD_PLATFORM_SPECS,
  AD_SPECS_AS_OF,
  adsDataStatus,
} from '../src/lib/ads/platforms';
import {
  checkAdPlan,
  checkLandingPage,
  hasErrors,
  performanceStatus,
  recommendBudget,
  type AdPlan,
} from '../src/lib/ads/plan';
import { AdPlanInputError, saveAdPlan, setAdPlanReviewState, startAdPlan } from '../src/lib/ads/service';

import {
  LEAD_STAGES,
  SCORE_BASIS,
  SCORE_MAX,
  canTransition,
  followUpState,
  pipelineCounts,
  scoreIsConsistent,
  scoreLead,
  suggestFollowUp,
  transitionRefusal,
} from '../src/lib/leads/types';
import {
  DuplicateLeadError,
  LeadInputError,
  StageTransitionError,
  createLead,
  getLead,
  logActivity,
  moveStage,
} from '../src/lib/leads/service';

import {
  EMAIL_KINDS,
  WHATSAPP_KINDS,
  WHATSAPP_LIMITS,
  categoryFor,
  checkMessagingPlan,
  hasMessagingErrors,
  isMarketing,
  sendingStatus,
  type EmailPlan,
  type WhatsappPlan,
} from '../src/lib/messaging/types';
import { UnlawfulAudienceError, saveMessagingPlan } from '../src/lib/messaging/service';

import {
  VIDEO_PLATFORMS,
  checkVideoScript,
  hasScriptErrors,
  imageGenerationStatus,
  totalSeconds,
  type VideoScript,
} from '../src/lib/video/types';
import { VideoInputError, saveVideoScript } from '../src/lib/video/service';

/**
 * Advertising plans, leads, messaging and video.
 *
 * Three groups here are about refusal rather than function: a plan cannot be
 * approved while it would be rejected by the platform, a campaign to a bought list
 * is not saved at all, and nothing claims to send or to generate an image.
 */

const PASSWORD = 'a genuinely long passphrase 2026';

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: 'https://acme-coffee.example.com',
};

const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic'] as const,
  marketingChannels: ['organic-search'] as const,
  brandVoice: { tones: ['friendly'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters' }],
};

let db: MemoryDatabase;
let tenant: TenantContext;
let projectId: string;

async function makeTenant(email: string): Promise<{ tenant: TenantContext; projectId: string }> {
  const signed = await signUp(
    { db, lockout: new MemoryLockoutStore(), secret: 'test-secret-value-at-least-32-bytes-long' },
    { email, password: PASSWORD },
  );
  if (!signed.ok || !signed.userId) throw new Error('signup failed');
  const memberships = await db.memberships.findForUser(signed.userId);
  const context: TenantContext = {
    userId: signed.userId,
    organizationId: memberships[0]!.organizationId,
    role: toRole(memberships[0]!.role),
  };
  const onboarded = await completeOnboarding({ db }, context, { business, profile });
  return { tenant: context, projectId: onboarded.project.id };
}

beforeEach(async () => {
  db = new MemoryDatabase();
  const made = await makeTenant(`ops-${Math.random().toString(36).slice(2)}@example.com`);
  tenant = made.tenant;
  projectId = made.projectId;
});

/* -------------------------------------------------------------------------- */
/* Ads                                                                        */
/* -------------------------------------------------------------------------- */

function googlePlan(overrides: Partial<AdPlan> = {}): AdPlan {
  return {
    platform: 'google_ads',
    objective: 'leads',
    campaignName: 'Acme Coffee — leads',
    audience: {
      description: 'Office workers within 2 km searching for coffee near them.',
      locations: ['Nagpur'],
      languages: ['en', 'hi'],
      signals: ['coffee near me'],
      exclusions: ['wholesale'],
    },
    headlines: ['Fresh coffee in Nagpur', 'Roasted this morning', 'Two minutes from MG Road'],
    descriptions: [
      'Speciality coffee roasted in small batches every morning. Open from seven.',
      'Order ahead and collect on your way to the office. No queue.',
    ],
    primaryText: [],
    cta: '',
    creativeConcepts: [],
    landingPage: checkLandingPage('https://acme-coffee.example.com/order', 'google_ads'),
    abIdeas: [],
    budget: recommendBudget({ currency: 'INR', objective: 'leads' }),
    reviewState: 'draft',
    ...overrides,
  };
}

describe('ad platform specifications', () => {
  test('all five platforms from the brief are specified', () => {
    assert.deepEqual([...AD_PLATFORMS], ['google_ads', 'meta', 'instagram', 'linkedin', 'youtube']);
  });

  test('no platform can publish, and there is one place that says so', () => {
    for (const platform of AD_PLATFORMS) {
      assert.equal(AD_PLATFORM_SPECS[platform].canPublish, false);
    }
    const status = adsDataStatus();
    assert.equal(status.connected, false);
    assert.equal(status.canPublish, false);
    assert.equal(status.canReadPerformance, false);
  });

  test('the limits carry a review date, because platforms change them', () => {
    assert.match(AD_SPECS_AS_OF, /^\d{4}-\d{2}$/);
  });

  test('every platform names the format its limits describe', () => {
    for (const platform of AD_PLATFORMS) {
      assert.ok(AD_PLATFORM_SPECS[platform].format.length > 5);
    }
  });

  test('there is no performance data, and the reason is written', () => {
    const status = performanceStatus();
    assert.equal(status.hasData, false);
    assert.match(status.reason, /will not display an estimate in place of a measurement/i);
  });
});

describe('ad plan validation', () => {
  test('a sound Google plan has no errors', () => {
    assert.equal(hasErrors(checkAdPlan(googlePlan())), false);
  });

  test('a headline over the limit is an error that names the count', () => {
    const problems = checkAdPlan(
      googlePlan({ headlines: ['x'.repeat(40), 'Roasted this morning', 'Near MG Road'] }),
    );
    assert.ok(problems.some((problem) => problem.severity === 'error' && /40 characters/.test(problem.message)));
  });

  test('too few headlines is an error', () => {
    const problems = checkAdPlan(googlePlan({ headlines: ['Only one'] }));
    assert.ok(problems.some((problem) => /3 needed/.test(problem.message)));
  });

  test('duplicate headlines are a warning, not an error', () => {
    const problems = checkAdPlan(
      googlePlan({ headlines: ['Same text', 'Same text', 'Third one here'] }),
    );
    const duplicate = problems.find((problem) => /duplicate/i.test(problem.message));
    assert.ok(duplicate);
    assert.equal(duplicate.severity, 'warning');
  });

  test('a CTA not on the platform list is an error', () => {
    const problems = checkAdPlan({
      ...googlePlan(),
      platform: 'meta',
      objective: 'leads',
      primaryText: ['Order ahead and skip the queue.'],
      headlines: ['Fresh coffee nearby'],
      descriptions: ['Roasted this morning'],
      cta: 'Buy immediately',
    });
    assert.ok(problems.some((problem) => problem.severity === 'error' && /own list/.test(problem.message)));
  });

  test('an objective the platform does not offer is an error', () => {
    const problems = checkAdPlan(googlePlan({ objective: 'engagement' }));
    assert.ok(problems.some((problem) => /does not offer/.test(problem.message)));
  });

  test('an A/B idea with identical sides is an error', () => {
    const problems = checkAdPlan(
      googlePlan({
        abIdeas: [
          {
            variable: 'headline',
            a: 'Fresh coffee',
            b: 'Fresh coffee',
            hypothesis: 'Wording matters',
            howToJudge: 'Wait for 100 clicks per side.',
          },
        ],
      }),
    );
    assert.ok(problems.some((problem) => /tests nothing/.test(problem.message)));
  });

  test('a budget with no stated basis is an error', () => {
    const problems = checkAdPlan(
      googlePlan({
        budget: {
          kind: 'ai_recommendation',
          label: 'Recommendation, not a measurement',
          currency: 'INR',
          dailyMin: 500,
          dailyMax: 1_500,
          basis: 'because',
          toMeasure: 'Connect the account.',
        },
      }),
    );
    assert.ok(problems.some((problem) => /must say what it is based on/.test(problem.message)));
  });

  test('a creative concept claiming a generated image is an error', () => {
    const problems = checkAdPlan(
      googlePlan({
        creativeConcepts: [
          {
            title: 'Morning queue',
            visual: 'The counter at 8am with steam rising.',
            angle: 'Freshness you can see',
            imageGenerated: true as unknown as false,
          },
        ],
      }),
    );
    assert.ok(problems.some((problem) => /no image exists/.test(problem.message)));
  });

  test('the budget recommendation is never presented as a measurement', () => {
    const budget = recommendBudget({ currency: 'INR', objective: 'sales', monthlyTarget: 40 });
    assert.equal(budget.kind, 'ai_recommendation');
    assert.match(budget.label, /not a measurement/i);
    assert.ok(budget.basis.length > 60);
    assert.match(budget.toMeasure, /Connect the ad account/i);
  });

  test('the landing-page check only claims what a URL can show', () => {
    const plan = checkLandingPage('http://acme-coffee.example.com/?gclid=abc', 'google_ads');
    assert.ok(plan.notes.some((note) => /http/.test(note)));
    assert.ok(plan.notes.some((note) => /click identifier/.test(note)));
    assert.ok(plan.mustMatch.length >= 3);
  });
});

describe('ad plan service', () => {
  test('a plan with errors can be saved as a draft but not approved', async () => {
    const broken = googlePlan({ headlines: [] });
    const saved = await saveAdPlan({ db }, tenant, { projectId, plan: broken });
    assert.ok(saved.problems.length > 0);
    assert.equal(saved.row.reviewState, 'draft');

    await assert.rejects(
      () => setAdPlanReviewState({ db }, tenant, saved.row.id, 'approved'),
      (error: unknown) => error instanceof AdPlanInputError,
    );
  });

  test('a sound plan can be approved', async () => {
    const saved = await saveAdPlan({ db }, tenant, { projectId, plan: googlePlan() });
    const approved = await setAdPlanReviewState({ db }, tenant, saved.row.id, 'approved');
    assert.equal(approved.row.reviewState, 'approved');
  });

  test('the problems found at save time are stored with the plan', async () => {
    const saved = await saveAdPlan({ db }, tenant, { projectId, plan: googlePlan({ headlines: ['one'] }) });
    const stored = await db.adPlans.findById(tenant.organizationId, saved.row.id);
    assert.ok(stored);
    assert.ok(stored.problems.length > 0);
  });

  test('a started plan has the structure but NO generated copy', async () => {
    const started = await startAdPlan({ db }, tenant, {
      projectId,
      platform: 'meta',
      objective: 'traffic',
    });
    assert.deepEqual([...started.plan.headlines], []);
    assert.deepEqual([...started.plan.descriptions], []);
    assert.equal(started.dataStatus.connected, false);
    assert.ok(started.plan.budget.basis.length > 40);
  });

  test('a plan in another organization is a 404', async () => {
    const saved = await saveAdPlan({ db }, tenant, { projectId, plan: googlePlan() });
    const other = await makeTenant('other-ads@example.com');
    await assert.rejects(
      () => setAdPlanReviewState({ db }, other.tenant, saved.row.id, 'approved'),
      (error: unknown) => error instanceof NotFoundError,
    );
  });
});

/* -------------------------------------------------------------------------- */
/* Leads                                                                      */
/* -------------------------------------------------------------------------- */

describe('the lead pipeline', () => {
  test('the seven stages from the brief exist in order', () => {
    assert.deepEqual(
      [...LEAD_STAGES],
      ['new', 'contacted', 'qualified', 'proposal', 'negotiation', 'won', 'lost'],
    );
  });

  test('a lead cannot jump from new to won', () => {
    assert.equal(canTransition('new', 'won'), false);
    assert.match(transitionRefusal('new', 'won'), /one stage at a time/);
  });

  test('a lead can move forward one stage, or back one', () => {
    assert.equal(canTransition('new', 'contacted'), true);
    assert.equal(canTransition('proposal', 'qualified'), true);
  });

  test('anything can be lost', () => {
    for (const stage of LEAD_STAGES) {
      if (stage === 'lost') continue;
      assert.equal(canTransition(stage, 'lost'), true, `${stage} should be able to be lost`);
    }
  });

  test('a closed lead must be reopened into the pipeline, not straight to won', () => {
    assert.equal(canTransition('lost', 'won'), false);
    assert.equal(canTransition('lost', 'contacted'), true);
  });

  test('pipeline counts include the empty stages', () => {
    const counts = pipelineCounts([{ stage: 'new' }, { stage: 'new' }, { stage: 'won' }]);
    assert.equal(Object.keys(counts).length, LEAD_STAGES.length);
    assert.equal(counts.new, 2);
    assert.equal(counts.proposal, 0);
  });
});

describe('the lead score shows its own reasoning', () => {
  test('the components always add up to the total', () => {
    const score = scoreLead({
      email: 'a@example.com',
      phone: '+91 712 000 0000',
      company: 'Acme',
      enquiry: 'x'.repeat(250),
      source: 'referral',
      activities: ['call', 'email_received'],
      createdAt: new Date('2026-09-01T00:00:00Z'),
      lastActivityAt: new Date('2026-09-01T00:00:00Z'),
      now: new Date('2026-09-01T06:00:00Z'),
    });
    assert.ok(scoreIsConsistent(score), 'a score whose parts do not add up is not auditable');
    assert.equal(score.total, SCORE_MAX);
    assert.equal(score.band, 'hot');
  });

  test('every component carries a written reason', () => {
    const score = scoreLead({
      source: 'unknown',
      activities: [],
      createdAt: new Date('2026-01-01T00:00:00Z'),
      now: new Date('2026-09-01T00:00:00Z'),
    });
    assert.ok(score.components.length >= 5);
    for (const component of score.components) {
      assert.ok(component.why.length > 15, `${component.label} has no reason`);
    }
  });

  test('an unknown source contributes nothing rather than a guess', () => {
    const score = scoreLead({
      source: 'unknown',
      activities: [],
      createdAt: new Date(),
    });
    const sourceComponent = score.components.find((component) => component.label === 'Source');
    assert.ok(sourceComponent);
    assert.equal(sourceComponent.points, 0);
    assert.match(sourceComponent.why, /not recorded/);
  });

  test('the basis says it is a rule, not a prediction', () => {
    assert.match(SCORE_BASIS, /rule-based/i);
    assert.match(SCORE_BASIS, /not a prediction and not a model/i);
  });

  test('a lead with no contact details scores zero for contactability', () => {
    const score = scoreLead({ source: 'manual', activities: [], createdAt: new Date() });
    const contact = score.components.find((component) => component.label === 'Contact details');
    assert.equal(contact?.points, 0);
  });
});

describe('lead service', () => {
  test('a lead needs at least one way to be contacted', async () => {
    await assert.rejects(
      () => createLead({ db }, tenant, { projectId, name: 'Nobody' }),
      (error: unknown) => error instanceof LeadInputError && /no way to follow up/i.test(error.message),
    );
  });

  test('a duplicate email is reported with the existing id, not merged', async () => {
    await createLead({ db }, tenant, { projectId, name: 'A', email: 'dup@example.com' });
    await assert.rejects(
      () => createLead({ db }, tenant, { projectId, name: 'A again', email: 'dup@example.com' }),
      (error: unknown) => error instanceof DuplicateLeadError && error.existingId.length > 0,
    );
  });

  test('a phone number written differently is still recognised as a duplicate', async () => {
    await createLead({ db }, tenant, { projectId, name: 'A', phone: '+91 712 000 0000' });
    await assert.rejects(
      () => createLead({ db }, tenant, { projectId, name: 'A', phone: '0712-000-0000' }),
      (error: unknown) => error instanceof DuplicateLeadError,
    );
  });

  test('a duplicate can be added deliberately', async () => {
    await createLead({ db }, tenant, { projectId, name: 'A', email: 'twice@example.com' });
    const second = await createLead({ db }, tenant, {
      projectId,
      name: 'A',
      email: 'twice@example.com',
      allowDuplicate: true,
    });
    assert.ok(second.lead.id);
  });

  test('an illegal stage move is refused with the reason', async () => {
    const created = await createLead({ db }, tenant, {
      projectId,
      name: 'Jumpy',
      email: 'jump@example.com',
    });
    await assert.rejects(
      () => moveStage({ db }, tenant, created.lead.id, 'won'),
      (error: unknown) => error instanceof StageTransitionError,
    );
  });

  test('a lost lead must say why', async () => {
    const created = await createLead({ db }, tenant, {
      projectId,
      name: 'Gone',
      email: 'gone@example.com',
    });
    await assert.rejects(
      () => moveStage({ db }, tenant, created.lead.id, 'lost'),
      (error: unknown) => error instanceof LeadInputError && /Say why/i.test(error.message),
    );

    const moved = await moveStage({ db }, tenant, created.lead.id, 'lost', {
      lostReason: 'Went with a cheaper supplier.',
    });
    assert.equal(moved.lead.stage, 'lost');
    assert.equal(moved.lead.lostReason, 'Went with a cheaper supplier.');
  });

  test('every stage change is logged with both stages', async () => {
    const created = await createLead({ db }, tenant, {
      projectId,
      name: 'Tracked',
      email: 'tracked@example.com',
    });
    await moveStage({ db }, tenant, created.lead.id, 'contacted');

    const found = await getLead({ db }, tenant, created.lead.id);
    const change = found.activities.find((activity) => activity.kind === 'stage_change');
    assert.ok(change);
    assert.equal(change.fromStage, 'new');
    assert.equal(change.toStage, 'contacted');
  });

  test('the score is recomputed when an activity is logged', async () => {
    const created = await createLead({ db }, tenant, {
      projectId,
      name: 'Engaged',
      email: 'engaged@example.com',
    });
    const before = created.score.total;
    const logged = await logActivity({ db }, tenant, {
      leadId: created.lead.id,
      kind: 'email_received',
      note: 'They replied asking about wholesale.',
    });
    assert.ok(logged.score.total > before, 'a reply should raise the score');
    assert.ok(scoreIsConsistent(logged.score));
  });

  test('a stage change cannot be logged by hand', async () => {
    const created = await createLead({ db }, tenant, {
      projectId,
      name: 'Manual',
      email: 'manual@example.com',
    });
    await assert.rejects(
      () => logActivity({ db }, tenant, { leadId: created.lead.id, kind: 'stage_change' }),
      (error: unknown) => error instanceof LeadInputError,
    );
  });

  test('a follow-up needs a date, and only a follow-up may have one', async () => {
    const created = await createLead({ db }, tenant, {
      projectId,
      name: 'Due',
      email: 'due@example.com',
    });
    await assert.rejects(
      () => logActivity({ db }, tenant, { leadId: created.lead.id, kind: 'follow_up' }),
      (error: unknown) => error instanceof LeadInputError,
    );
    await assert.rejects(
      () =>
        logActivity({ db }, tenant, {
          leadId: created.lead.id,
          kind: 'note',
          dueAt: new Date(),
        }),
      (error: unknown) => error instanceof LeadInputError,
    );
  });

  test('a follow-up state is due, overdue or done', () => {
    const now = new Date('2026-09-12T10:00:00Z');
    assert.equal(followUpState({ dueAt: new Date('2026-09-12T18:00:00Z'), note: '' }, now), 'due_today');
    assert.equal(followUpState({ dueAt: new Date('2026-09-10T10:00:00Z'), note: '' }, now), 'overdue');
    assert.equal(followUpState({ dueAt: new Date('2026-09-20T10:00:00Z'), note: '' }, now), 'due_later');
    assert.equal(
      followUpState({ dueAt: new Date('2026-09-10T10:00:00Z'), note: '', completedAt: now }, now),
      'done',
    );
  });

  test('the suggested follow-up says why that interval', () => {
    const suggestion = suggestFollowUp('proposal', new Date('2026-09-01T00:00:00Z'));
    assert.ok(suggestion.dueAt.getTime() > new Date('2026-09-01T00:00:00Z').getTime());
    assert.match(suggestion.why, /Change it to whatever suits/);
  });

  test('a lead in another organization is a 404', async () => {
    const created = await createLead({ db }, tenant, {
      projectId,
      name: 'Private',
      email: 'private@example.com',
    });
    const other = await makeTenant('other-leads@example.com');
    await assert.rejects(
      () => getLead({ db }, other.tenant, created.lead.id),
      (error: unknown) => error instanceof NotFoundError,
    );
  });
});

/* -------------------------------------------------------------------------- */
/* Messaging                                                                  */
/* -------------------------------------------------------------------------- */

function emailPlan(overrides: Partial<EmailPlan> = {}): EmailPlan {
  return {
    channel: 'email',
    kind: 'promotional',
    subject: 'Two new single origins, roasted this week',
    preheader: 'Both are on the counter from Thursday.',
    body: 'We have two new single origins this week, both roasted on Tuesday. Come and try them.',
    plainText: 'We have two new single origins this week, both roasted on Tuesday.',
    callsToAction: [{ label: 'See the beans', url: 'https://acme-coffee.example.com/beans' }],
    hasUnsubscribe: true,
    senderIdentification: 'Acme Coffee, 12 MG Road, Nagpur 440001',
    optInBasis: 'explicit_opt_in',
    audienceDescription: 'Customers who ticked the newsletter box at the counter.',
    ...overrides,
  };
}

function whatsappPlan(overrides: Partial<WhatsappPlan> = {}): WhatsappPlan {
  return {
    channel: 'whatsapp',
    kind: 'offer',
    category: 'MARKETING',
    header: 'New roast',
    body: 'Hello {{1}}, our new single origin is on the counter from Thursday. Reply STOP to opt out.',
    footer: 'Acme Coffee, Nagpur',
    buttons: [{ label: 'See the beans', kind: 'url', value: 'https://acme-coffee.example.com/beans' }],
    placeholders: ['The customer’s first name'],
    optInBasis: 'explicit_opt_in',
    audienceDescription: 'Customers who opted in at the counter.',
    ...overrides,
  };
}

describe('messaging: what cannot be done', () => {
  test('neither channel can send, and there is one place that says so', () => {
    for (const channel of ['email', 'whatsapp'] as const) {
      const status = sendingStatus(channel);
      assert.equal(status.connected, false);
      assert.equal(status.canSend, false);
      assert.ok(status.whatWouldBeNeeded.length > 40);
    }
    assert.match(sendingStatus('whatsapp').whatWouldBeNeeded, /official/i);
  });

  test('all six email kinds and all five WhatsApp kinds exist', () => {
    assert.equal(EMAIL_KINDS.length, 6);
    assert.equal(WHATSAPP_KINDS.length, 5);
  });

  test('a bought list is refused outright, not warned about', async () => {
    await assert.rejects(
      () =>
        saveMessagingPlan({ db }, tenant, {
          projectId,
          title: 'Cold blast',
          plan: emailPlan({ optInBasis: 'purchased_list' }),
        }),
      (error: unknown) => error instanceof UnlawfulAudienceError,
    );
    const stored = await db.messagingPlans.listForProject(tenant.organizationId, projectId);
    assert.deepEqual(stored, [], 'a refused plan must not be stored even as a draft');
  });

  test('scraped addresses are refused', async () => {
    await assert.rejects(
      () =>
        saveMessagingPlan({ db }, tenant, {
          projectId,
          title: 'Scraped',
          plan: emailPlan({ optInBasis: 'scraped' }),
        }),
      (error: unknown) => error instanceof UnlawfulAudienceError,
    );
  });

  test('no recorded basis is refused', async () => {
    await assert.rejects(
      () =>
        saveMessagingPlan({ db }, tenant, {
          projectId,
          title: 'Unknown',
          plan: emailPlan({ optInBasis: 'none' }),
        }),
      (error: unknown) => error instanceof UnlawfulAudienceError,
    );
  });
});

describe('email rules', () => {
  test('a sound promotional email has no errors', () => {
    assert.equal(hasMessagingErrors(checkMessagingPlan(emailPlan())), false);
  });

  test('a marketing email with no unsubscribe is an ERROR, not a recommendation', () => {
    const problems = checkMessagingPlan(emailPlan({ hasUnsubscribe: false }));
    const found = problems.find((problem) => problem.field === 'hasUnsubscribe');
    assert.ok(found);
    assert.equal(found.severity, 'error');
    assert.match(found.message, /legal requirement/i);
  });

  test('a marketing email with no sender identification is an error', () => {
    const problems = checkMessagingPlan(emailPlan({ senderIdentification: '' }));
    assert.ok(problems.some((problem) => problem.field === 'senderIdentification' && problem.severity === 'error'));
  });

  test('a fake "Re:" subject is an error', () => {
    const problems = checkMessagingPlan(emailPlan({ subject: 'Re: your order' }));
    assert.ok(problems.some((problem) => /deception/i.test(problem.message)));
  });

  test('a guarantee in the copy is an error', () => {
    const problems = checkMessagingPlan(
      emailPlan({ body: 'Guaranteed results in thirty days or your money back, risk-free.' }),
    );
    assert.ok(problems.some((problem) => problem.severity === 'error' && /guarantee/i.test(problem.message)));
  });

  test('manufactured urgency is a warning', () => {
    const problems = checkMessagingPlan(emailPlan({ body: 'Act now! Last chance to buy our coffee today.' }));
    assert.ok(problems.some((problem) => problem.severity === 'warning' && /urgency/i.test(problem.message)));
  });

  test('a long subject is a warning with the client limit named', () => {
    const problems = checkMessagingPlan(emailPlan({ subject: 'x'.repeat(90) }));
    assert.ok(problems.some((problem) => problem.field === 'subject' && problem.severity === 'warning'));
  });

  test('replying to an enquiry does not permit a promotion', () => {
    const problems = checkMessagingPlan(emailPlan({ optInBasis: 'enquiry_reply' }));
    assert.ok(problems.some((problem) => /permits an answer, not a promotion/.test(problem.message)));
  });

  test('a transactional email does not need an unsubscribe', () => {
    const problems = checkMessagingPlan(
      emailPlan({ kind: 'follow_up', hasUnsubscribe: false, optInBasis: 'enquiry_reply' }),
    );
    assert.ok(!problems.some((problem) => problem.field === 'hasUnsubscribe'));
    assert.equal(isMarketing('follow_up'), false);
  });
});

describe('whatsapp template rules', () => {
  test('a sound marketing template has no errors', () => {
    assert.equal(hasMessagingErrors(checkMessagingPlan(whatsappPlan())), false);
  });

  test('the category is derived from the kind, and a mismatch is an error', () => {
    assert.equal(categoryFor('offer'), 'MARKETING');
    assert.equal(categoryFor('appointment'), 'UTILITY');

    const problems = checkMessagingPlan(whatsappPlan({ category: 'UTILITY' }));
    assert.ok(problems.some((problem) => problem.severity === 'error' && /policy breach/i.test(problem.message)));
  });

  test('a marketing template to a non-opted-in audience is an error', () => {
    const problems = checkMessagingPlan(whatsappPlan({ optInBasis: 'contract_necessity' }));
    assert.ok(problems.some((problem) => problem.field === 'optInBasis' && problem.severity === 'error'));
  });

  test('a body over the official limit is an error', () => {
    const problems = checkMessagingPlan(
      whatsappPlan({ body: 'x'.repeat(WHATSAPP_LIMITS.bodyCharacters + 1), placeholders: [] }),
    );
    assert.ok(problems.some((problem) => problem.field === 'body' && problem.severity === 'error'));
  });

  test('placeholders must be numbered from 1 with no gaps', () => {
    const problems = checkMessagingPlan(
      whatsappPlan({
        body: 'Hello {{2}}, your order {{4}} is ready.',
        placeholders: ['name', 'order'],
      }),
    );
    assert.ok(problems.some((problem) => /numbered from \{\{1\}\}/.test(problem.message)));
  });

  test('every placeholder must be described', () => {
    const problems = checkMessagingPlan(
      whatsappPlan({ body: 'Hello {{1}}, your order {{2}} is ready.', placeholders: ['name'] }),
    );
    assert.ok(problems.some((problem) => problem.field === 'placeholders' && problem.severity === 'error'));
  });

  test('a template may not begin with a placeholder', () => {
    const problems = checkMessagingPlan(
      whatsappPlan({ body: '{{1}} your coffee is ready for collection.', placeholders: ['name'] }),
    );
    assert.ok(problems.some((problem) => /may not begin with a placeholder/.test(problem.message)));
  });

  test('too many buttons is an error', () => {
    const problems = checkMessagingPlan(
      whatsappPlan({
        buttons: [
          { label: 'One', kind: 'quick_reply' },
          { label: 'Two', kind: 'quick_reply' },
          { label: 'Three', kind: 'quick_reply' },
          { label: 'Four', kind: 'quick_reply' },
        ],
      }),
    );
    assert.ok(problems.some((problem) => problem.field === 'buttons' && problem.severity === 'error'));
  });

  test('a URL button with no URL is an error', () => {
    const problems = checkMessagingPlan(
      whatsappPlan({ buttons: [{ label: 'Open', kind: 'url' }] }),
    );
    assert.ok(problems.some((problem) => /needs a full URL/.test(problem.message)));
  });

  test('the stored category is derived, not taken from the request', async () => {
    const saved = await saveMessagingPlan({ db }, tenant, {
      projectId,
      title: 'Appointment reminder',
      // A caller claiming MARKETING on a utility kind must not decide the stored
      // category: the derived one wins.
      plan: whatsappPlan({
        kind: 'appointment',
        category: 'MARKETING',
        optInBasis: 'existing_customer',
        body: 'Hello {{1}}, your tasting is booked for Thursday at 4pm.',
        placeholders: ['The customer’s first name'],
      }),
    });
    assert.equal(saved.row.category, 'UTILITY');
  });
});

/* -------------------------------------------------------------------------- */
/* Video                                                                      */
/* -------------------------------------------------------------------------- */

function reelScript(overrides: Partial<VideoScript> = {}): VideoScript {
  return {
    platform: 'instagram_reels',
    topic: 'Why your coffee tastes sour at home',
    hook: 'Your coffee tastes sour because of one setting.',
    scenes: [
      {
        index: 1,
        seconds: 3,
        shot: 'Close on a cup being poured.',
        voiceover: 'Sour coffee is not the beans.',
        onScreenText: 'Not the beans',
      },
      {
        index: 2,
        seconds: 12,
        shot: 'Hands adjusting a grinder dial.',
        voiceover: 'It is the grind. Too coarse and the water runs straight through.',
        onScreenText: 'It is the grind',
      },
      {
        index: 3,
        seconds: 8,
        shot: 'Two cups side by side.',
        voiceover: 'One click finer and it tastes like the shop.',
        onScreenText: 'One click finer',
      },
    ],
    callToAction: 'Come in and we will dial your grinder with you.',
    titles: ['Why home coffee tastes sour'],
    description: 'The one grinder setting that fixes sour coffee.',
    tags: ['coffee', 'nagpur', 'brewing'],
    thumbnailConcepts: [
      {
        title: 'Two cups',
        description: 'Two cups side by side, one pale and one dark, shot from above on a wooden counter.',
        overlayText: 'Sour? One click',
        whyItWorks: 'The contrast states the problem and the fix without reading a word.',
      },
    ],
    thumbnailImagesGenerated: false,
    ...overrides,
  };
}

describe('video scripts', () => {
  test('all four platforms are specified', () => {
    assert.equal(VIDEO_PLATFORMS.length, 4);
  });

  test('no image is generated, and there is one place that says so', () => {
    const status = imageGenerationStatus();
    assert.equal(status.connected, false);
    assert.equal(status.canGenerate, false);
    assert.match(status.whatYouGetInstead, /written thumbnail brief/i);
  });

  test('a sound script has no errors', () => {
    assert.equal(hasScriptErrors(checkVideoScript(reelScript())), false);
  });

  test('scenes that overrun the platform limit are an error', () => {
    const problems = checkVideoScript(
      reelScript({
        scenes: [
          { index: 1, seconds: 200, shot: 'A long shot.', voiceover: 'Words.', onScreenText: 'Words' },
        ],
      }),
    );
    assert.ok(problems.some((problem) => /add up to 200 seconds/.test(problem.message)));
  });

  test('the durations are actually summed', () => {
    assert.equal(totalSeconds(reelScript().scenes), 23);
  });

  test('a scene with no shot is an error, because a shot list needs shots', () => {
    const problems = checkVideoScript(
      reelScript({
        scenes: [{ index: 1, seconds: 5, shot: '   ', voiceover: 'Words.', onScreenText: 'Words' }],
      }),
    );
    assert.ok(problems.some((problem) => /does not say what is on screen/.test(problem.message)));
  });

  test('scene numbering must not jump', () => {
    const problems = checkVideoScript(
      reelScript({
        scenes: [
          { index: 1, seconds: 5, shot: 'A.', voiceover: '', onScreenText: '' },
          { index: 3, seconds: 5, shot: 'B.', voiceover: '', onScreenText: '' },
        ],
      }),
    );
    assert.ok(problems.some((problem) => /numbering jumps/.test(problem.message)));
  });

  test('on a muted platform, speech with no on-screen text is an error', () => {
    const problems = checkVideoScript(
      reelScript({
        platform: 'linkedin_video',
        scenes: [{ index: 1, seconds: 6, shot: 'Talking head.', voiceover: 'Hello there.' }],
      }),
    );
    assert.ok(problems.some((problem) => /plays muted/.test(problem.message)));
  });

  test('a script claiming generated thumbnails is an error', () => {
    const problems = checkVideoScript(
      reelScript({ thumbnailImagesGenerated: true as unknown as false }),
    );
    assert.ok(problems.some((problem) => /no image exists/.test(problem.message)));
  });

  test('a thumbnail overlay longer than four words is a warning', () => {
    const problems = checkVideoScript(
      reelScript({
        thumbnailConcepts: [
          {
            title: 'Wordy',
            description: 'A wide shot of the counter with a long caption across the middle of it.',
            overlayText: 'This is far too many words to read',
            whyItWorks: 'It does not.',
          },
        ],
      }),
    );
    assert.ok(problems.some((problem) => /does not read at thumbnail size/.test(problem.message)));
  });

  test('a script with errors cannot be marked ready', async () => {
    const broken = reelScript({ titles: [] });
    const saved = await saveVideoScript({ db }, tenant, { projectId, script: broken });
    assert.ok(saved.problems.length > 0);
    await assert.rejects(
      () =>
        saveVideoScript({ db }, tenant, {
          projectId,
          script: broken,
          reviewState: 'approved',
        }),
      (error: unknown) => error instanceof VideoInputError,
    );
  });

  test('the stored total is the summed scene duration', async () => {
    const saved = await saveVideoScript({ db }, tenant, { projectId, script: reelScript() });
    assert.equal(saved.row.totalSeconds, 23);
  });
});
