import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import { DEFAULT_LIMITS, extractPage, type CrawlReport, type PageData } from '../src/lib/crawler';
import {
  DATA_BASES,
  SEVERITIES,
  lintFinding,
  lintFindings,
  scoreFindings,
  sortFindings,
  validateFinding,
  type Finding,
} from '../src/lib/audit/finding';
import { SEO_THRESHOLDS, auditSeo } from '../src/lib/audit/seo';
import { AEO_DISCLAIMER, auditAeo } from '../src/lib/audit/aeo';
import {
  KEYWORD_KINDS,
  NO_COMPETITION_DATA,
  NO_VOLUME_DATA,
  classifyIntent,
  classifyKinds,
  competitionLabel,
  computePriority,
  suggestFormat,
  volumeLabel,
} from '../src/lib/keywords/types';
import { extractKeywords, measureRelevance } from '../src/lib/keywords/extract';

/**
 * SEO and AEO audits, and the keyword system.
 *
 * The assertions that matter most here are the negative ones: that no finding
 * promises AI ranking, citation, visibility or traffic, and that no keyword
 * carries a search volume the product cannot know. Both are enforced in code
 * rather than in a style guide, and these tests are what keep them enforced.
 */

/* -------------------------------------------------------------------------- */
/* Fixtures                                                                   */
/* -------------------------------------------------------------------------- */

function html(options: {
  title?: string | null;
  description?: string | null;
  h1?: string[];
  h2?: string[];
  h3?: string[];
  body?: string;
  canonical?: string | null;
  robots?: string | null;
  viewport?: boolean;
  lang?: string | null;
  jsonLd?: unknown[];
  images?: { src: string; alt?: string | null; width?: boolean }[];
  links?: string[];
  badJsonLd?: boolean;
} = {}): string {
  const head: string[] = ['<meta charset="utf-8">'];
  if (options.title !== null) head.push(`<title>${options.title ?? 'A page title that is reasonable'}</title>`);
  if (options.description !== null) {
    head.push(`<meta name="description" content="${options.description ?? 'A meta description long enough to be realistic for a test of the audit behaviour.'}">`);
  }
  if (options.viewport !== false) head.push('<meta name="viewport" content="width=device-width,initial-scale=1">');
  if (options.canonical !== null) head.push(`<link rel="canonical" href="${options.canonical ?? 'https://example.com/'}">`);
  if (options.robots) head.push(`<meta name="robots" content="${options.robots}">`);
  for (const block of options.jsonLd ?? []) {
    head.push(`<script type="application/ld+json">${JSON.stringify(block)}</script>`);
  }
  if (options.badJsonLd) head.push('<script type="application/ld+json">{ not valid json }</script>');

  const body: string[] = [];
  for (const heading of options.h1 ?? ['A main heading']) body.push(`<h1>${heading}</h1>`);
  for (const heading of options.h2 ?? []) body.push(`<h2>${heading}</h2>`);
  for (const heading of options.h3 ?? []) body.push(`<h3>${heading}</h3>`);
  body.push(`<p>${options.body ?? 'Sentence of body text about the subject. '.repeat(30)}</p>`);
  for (const image of options.images ?? []) {
    const alt = image.alt === undefined ? ' alt="A picture"' : image.alt === null ? '' : ` alt="${image.alt}"`;
    const dims = image.width === false ? '' : ' width="800" height="600"';
    body.push(`<img src="${image.src}"${alt}${dims}>`);
  }
  for (const link of options.links ?? []) body.push(`<a href="${link}">link</a>`);

  const langAttribute = options.lang === null ? '' : ` lang="${options.lang ?? 'en'}"`;
  return `<!doctype html><html${langAttribute}><head>${head.join('')}</head><body>${body.join('')}</body></html>`;
}

function makePage(url: string, markup: string, overrides: Partial<PageData> = {}): PageData {
  return {
    ...extractPage({ url, html: markup, status: 200, bytes: markup.length, responseTimeMs: 200 }),
    ...overrides,
  };
}

function makeReport(pages: PageData[], overrides: Partial<CrawlReport> = {}): CrawlReport {
  return {
    siteUrl: 'https://example.com/',
    startedAt: new Date('2026-03-01T10:00:00Z'),
    finishedAt: new Date('2026-03-01T10:05:00Z'),
    pages,
    failures: [],
    robots: {
      url: 'https://example.com/robots.txt',
      found: true,
      readable: true,
      respected: true,
      summary: 'robots.txt found with 0 rules that apply to this crawler.',
      sitemapsDeclared: ['https://example.com/sitemap.xml'],
      blockedCount: 0,
      crawlDelayMs: 500,
    },
    sitemap: {
      found: true,
      urls: pages.map((page) => page.url),
      locations: ['https://example.com/sitemap.xml'],
      kind: 'urlset',
      truncated: false,
      note: 'Found.',
    },
    skipped: {},
    limits: DEFAULT_LIMITS,
    stoppedEarly: null,
    cancelled: false,
    ...overrides,
  };
}

/* -------------------------------------------------------------------------- */
/* The finding contract                                                       */
/* -------------------------------------------------------------------------- */

const goodFinding: Finding = {
  id: 'test-1',
  category: 'Metadata',
  severity: 'high',
  issue: 'Three pages have no title element.',
  evidence: { observation: 'No <title> was found.', urls: ['https://example.com/a'], affectedCount: 3 },
  recommendation: 'Give every page a unique title.',
  expectedBenefit: 'The title is what search engines and people use to judge what a page is about.',
  confidence: 'high',
  dataBasis: 'crawled_page',
};

describe('every finding carries evidence and a basis', () => {
  test('a well-formed finding validates', () => {
    assert.deepEqual(validateFinding(goodFinding), []);
  });

  test('a finding with no evidence observation is invalid', () => {
    const problems = validateFinding({
      ...goodFinding,
      evidence: { observation: '  ', urls: [] },
    });
    assert.ok(problems.length > 0);
  });

  test('a MEASURED finding must cite a URL or a count', () => {
    const problems = validateFinding({
      ...goodFinding,
      evidence: { observation: 'Something was observed.', urls: [] },
    });
    assert.ok(problems.some((problem) => /URL|count/i.test(problem)));
  });

  test('a heuristic finding may cite no URL, because it is not a measurement', () => {
    assert.deepEqual(
      validateFinding({
        ...goodFinding,
        dataBasis: 'heuristic',
        confidence: 'low',
        evidence: { observation: 'A general rule.', urls: [] },
      }),
      [],
    );
  });

  test('a heuristic CANNOT be high confidence', () => {
    const problems = validateFinding({ ...goodFinding, dataBasis: 'heuristic', confidence: 'high' });
    assert.ok(problems.some((problem) => /heuristic/i.test(problem)));
  });

  test('the data-basis vocabulary covers measurement and its absence', () => {
    assert.ok(DATA_BASES.includes('crawled_page'));
    assert.ok(DATA_BASES.includes('heuristic'));
    assert.ok(DATA_BASES.includes('unavailable'));
  });
});

describe('the forbidden-promise linter', () => {
  test('a ranking promise is REJECTED', () => {
    const warnings = lintFinding({
      ...goodFinding,
      expectedBenefit: 'This will improve your ranking on the first page of Google.',
    });
    assert.ok(warnings.length > 0);
  });

  test('an AI citation promise is REJECTED', () => {
    const warnings = lintFinding({
      ...goodFinding,
      expectedBenefit: 'Adding this will ensure your page gets cited by ChatGPT and Perplexity.',
    });
    assert.ok(warnings.length > 0);
  });

  test('an AI visibility promise is REJECTED', () => {
    const warnings = lintFinding({
      ...goodFinding,
      expectedBenefit: 'This guarantees AI visibility across every assistant.',
    });
    assert.ok(warnings.length > 0);
  });

  test('a traffic guarantee is REJECTED', () => {
    const warnings = lintFinding({
      ...goodFinding,
      expectedBenefit: 'This guarantees more traffic and more leads within a month.',
    });
    assert.ok(warnings.length > 0);
  });

  test('an invented percentage improvement is REJECTED', () => {
    const warnings = lintFinding({
      ...goodFinding,
      expectedBenefit: 'Fixing this will increase conversions by 30%.',
    });
    assert.ok(warnings.length > 0);
  });

  test('a ranking superlative is REJECTED', () => {
    const warnings = lintFinding({ ...goodFinding, recommendation: 'Aim to be the #1 result.' });
    assert.ok(warnings.length > 0);
  });

  test('a properly hedged benefit PASSES', () => {
    const warnings = lintFinding({
      ...goodFinding,
      expectedBenefit:
        'A self-contained answer can be quoted without surrounding context, and is easier for a reader to skim.',
    });
    assert.deepEqual(warnings, []);
  });

  test('a MEASURED percentage in the evidence is not a promise', () => {
    // The evidence field states what was observed. "40% of pages have no title"
    // is a fact about the crawl, not a claim about an outcome.
    const warnings = lintFinding({
      ...goodFinding,
      evidence: {
        observation: '40% of pages have no title, and traffic will increase by 90% guaranteed.',
        urls: ['https://example.com/a'],
      },
    });
    assert.deepEqual(warnings, [], 'the linter must not scan the evidence field');
  });

  test('a finding that makes a forbidden promise is DROPPED, not merely flagged', () => {
    // Unlike an AI response, a finding is written by this codebase: a violation
    // is a bug to fix, not a model to caveat.
    const result = lintFindings([
      goodFinding,
      { ...goodFinding, id: 'bad-1', expectedBenefit: 'Guaranteed traffic increase.' },
    ]);

    assert.equal(result.findings.length, 1);
    assert.equal(result.findings[0]?.id, 'test-1');
    assert.deepEqual(result.dropped, ['bad-1']);
    assert.ok(result.warnings.length > 0);
  });
});

describe('scoring says what it is', () => {
  test('a clean site scores 100', () => {
    assert.equal(scoreFindings([]).score, 100);
  });

  test('critical findings cost more than low ones', () => {
    const critical = scoreFindings([{ ...goodFinding, severity: 'critical' }]).score;
    const low = scoreFindings([{ ...goodFinding, severity: 'low' }]).score;
    assert.ok(critical < low);
  });

  test('a low-confidence finding costs less than the same finding measured', () => {
    const measured = scoreFindings([{ ...goodFinding, confidence: 'high' }]).score;
    const judged = scoreFindings([{ ...goodFinding, confidence: 'low' }]).score;
    assert.ok(judged > measured, 'a judgement should not cost as much as a measurement');
  });

  test('the score never leaves 0-100', () => {
    const many = Array.from({ length: 100 }, (_, index) => ({
      ...goodFinding,
      id: `f-${index}`,
      severity: 'critical' as const,
    }));
    const score = scoreFindings(many).score;
    assert.ok(score >= 0 && score <= 100);
  });

  test('the basis DISCLAIMS being an external measurement', () => {
    const basis = scoreFindings([]).basis;
    assert.match(basis, /own weighting/i);
    assert.match(basis, /not a measurement from Google/i);
  });

  test('findings sort most severe first', () => {
    const sorted = sortFindings([
      { ...goodFinding, id: 'a', severity: 'low' },
      { ...goodFinding, id: 'b', severity: 'critical' },
      { ...goodFinding, id: 'c', severity: 'medium' },
    ]);
    assert.deepEqual(sorted.map((finding) => finding.id), ['b', 'c', 'a']);
  });

  test('every severity is a known value', () => {
    for (const severity of SEVERITIES) {
      assert.equal(scoreFindings([{ ...goodFinding, severity }]).counts[severity], 1);
    }
  });
});

/* -------------------------------------------------------------------------- */
/* SEO audit                                                                  */
/* -------------------------------------------------------------------------- */

describe('the SEO audit finds real problems', () => {
  test('a missing title is critical', () => {
    const report = makeReport([makePage('https://example.com/', html({ title: null }))]);
    const audit = auditSeo(report);
    const finding = audit.findings.find((item) => item.id.startsWith('seo-title-missing'));

    assert.ok(finding, 'a missing title was not reported');
    assert.equal(finding.severity, 'critical');
    assert.deepEqual(finding.evidence.urls, ['https://example.com/']);
  });

  test('HTTP pages are critical, and the finding names them', () => {
    const report = makeReport([makePage('http://example.com/', html())]);
    const audit = auditSeo(report);
    const finding = audit.findings.find((item) => item.id.startsWith('seo-https'));

    assert.ok(finding);
    assert.equal(finding.severity, 'critical');
  });

  test('duplicate titles are reported with the pages that share them', () => {
    const report = makeReport([
      makePage('https://example.com/a', html({ title: 'Same Title' })),
      makePage('https://example.com/b', html({ title: 'Same Title' })),
    ]);
    const finding = auditSeo(report).findings.find((item) => item.id.startsWith('seo-title-duplicate'));

    assert.ok(finding);
    assert.equal(finding.evidence.affectedCount, 2);
    assert.match(finding.evidence.observation, /Same Title/);
  });

  test('a missing h1 is reported', () => {
    const report = makeReport([makePage('https://example.com/', html({ h1: [] }))]);
    assert.ok(auditSeo(report).findings.some((item) => item.id.startsWith('seo-h1-missing')));
  });

  test('a skipped heading level is reported', () => {
    const report = makeReport([makePage('https://example.com/', html({ h2: [], h3: ['A sub-heading'] }))]);
    assert.ok(auditSeo(report).findings.some((item) => item.id.startsWith('seo-heading-skip')));
  });

  test('thin content is reported with the actual word count', () => {
    const report = makeReport([makePage('https://example.com/', html({ body: 'Only a few words here.' }))]);
    const finding = auditSeo(report).findings.find((item) => item.id.startsWith('seo-thin-content'));

    assert.ok(finding);
    assert.match(finding.evidence.observation, /\d+ words/);
  });

  test('a missing viewport is reported as a mobile problem', () => {
    const report = makeReport([makePage('https://example.com/', html({ viewport: false }))]);
    const finding = auditSeo(report).findings.find((item) => item.id.startsWith('seo-viewport'));
    assert.ok(finding);
    assert.equal(finding.category, 'Mobile');
  });

  test('an image with no alt attribute is reported, and an empty alt is NOT', () => {
    // alt="" is the correct markup for a decorative image. Counting it as a
    // defect would train users to ignore the finding.
    const missing = makeReport([
      makePage('https://example.com/', html({ images: [{ src: '/a.jpg', alt: null }] })),
    ]);
    assert.ok(auditSeo(missing).findings.some((item) => item.id.startsWith('seo-image-alt')));

    const decorative = makeReport([
      makePage('https://example.com/', html({ images: [{ src: '/a.jpg', alt: '' }] })),
    ]);
    assert.ok(!auditSeo(decorative).findings.some((item) => item.id.startsWith('seo-image-alt')));
  });

  test('invalid structured data is high severity and quotes the parse error', () => {
    const report = makeReport([makePage('https://example.com/', html({ badJsonLd: true }))]);
    const finding = auditSeo(report).findings.find((item) => item.id.startsWith('seo-sd-invalid'));

    assert.ok(finding);
    assert.equal(finding.severity, 'high');
    assert.equal(finding.dataBasis, 'structured_data');
  });

  test('broken internal links are reported with the page that links to them', () => {
    const report = makeReport(
      [makePage('https://example.com/', html({ links: ['/gone'] }))],
      {
        failures: [
          { url: 'https://example.com/gone', code: 'http_error', reason: 'Returned 404.', status: 404, depth: 1 },
        ],
      },
    );
    const finding = auditSeo(report).findings.find((item) => item.id.startsWith('seo-broken-links'));

    assert.ok(finding);
    assert.match(finding.evidence.observation, /linked from https:\/\/example\.com\//);
  });

  test('inconsistent entity names are reported', () => {
    const report = makeReport([
      makePage('https://example.com/a', html({ jsonLd: [{ '@type': 'Organization', name: 'Acme Coffee' }] })),
      makePage('https://example.com/b', html({ jsonLd: [{ '@type': 'Organization', name: 'Acme Coffee Ltd' }] })),
    ]);
    const finding = auditSeo(report).findings.find((item) => item.id.startsWith('seo-entity-name'));

    assert.ok(finding);
    assert.match(finding.evidence.observation, /Acme Coffee/);
  });

  test('a missing sitemap is reported', () => {
    const report = makeReport([makePage('https://example.com/', html())], {
      sitemap: { found: false, urls: [], locations: [], kind: null, truncated: false, note: 'None found.' },
    });
    assert.ok(auditSeo(report).findings.some((item) => item.id.startsWith('seo-sitemap-missing')));
  });

  test('a clean page produces no critical or high findings', () => {
    const clean = makePage(
      'https://example.com/',
      html({
        h2: ['A section'],
        jsonLd: [
          { '@type': 'Organization', name: 'Acme Coffee', sameAs: ['https://linkedin.com/company/acme'] },
        ],
        images: [{ src: '/a.jpg', alt: 'A cup of coffee' }],
      }),
    );
    const audit = auditSeo(makeReport([clean]));
    const serious = audit.findings.filter(
      (item) => item.severity === 'critical' || item.severity === 'high',
    );
    assert.deepEqual(serious.map((item) => item.id), [], `unexpected: ${serious.map((i) => i.issue).join('; ')}`);
  });
});

describe('the SEO audit is honest about its limits', () => {
  test('it always reports what it could NOT check', () => {
    const audit = auditSeo(makeReport([makePage('https://example.com/', html())]));
    assert.ok(audit.notChecked.length > 0);
  });

  test('Core Web Vitals and rankings are explicitly out of scope', () => {
    const audit = auditSeo(makeReport([makePage('https://example.com/', html())]));
    const areas = audit.notChecked.map((item) => item.area.toLowerCase()).join(' | ');
    assert.match(areas, /core web vitals/);
    assert.match(areas, /ranking/);
  });

  test('it says it does not execute JavaScript', () => {
    const audit = auditSeo(makeReport([makePage('https://example.com/', html())]));
    assert.ok(audit.notChecked.some((item) => /javascript/i.test(item.reason)));
  });

  test('a truncated crawl is declared as a limit of the audit', () => {
    const audit = auditSeo(
      makeReport([makePage('https://example.com/', html())], { stoppedEarly: 'Hit the page limit.' }),
    );
    assert.ok(audit.notChecked.some((item) => /beyond the crawl limit/i.test(item.area)));
  });

  test('NO finding anywhere in a full audit makes a forbidden promise', () => {
    // The end-to-end version of the linter test: run the real audit over a site
    // with many problems and confirm nothing it produces promises an outcome.
    const report = makeReport([
      makePage('http://example.com/', html({ title: null, h1: [], viewport: false, badJsonLd: true })),
      makePage('http://example.com/b', html({ title: null, description: null, body: 'Thin.' })),
    ]);
    const audit = auditSeo(report);

    assert.ok(audit.findings.length > 5, 'the fixture should produce plenty of findings');
    for (const finding of audit.findings) {
      assert.deepEqual(
        lintFinding(finding),
        [],
        `"${finding.id}" makes a forbidden promise: ${finding.expectedBenefit}`,
      );
    }
    assert.deepEqual(audit.suppressed, [], 'the audit produced a finding its own linter rejected');
  });

  test('the thresholds are documented so the report can explain itself', () => {
    assert.ok(SEO_THRESHOLDS.titleMax > SEO_THRESHOLDS.titleMin);
    assert.ok(SEO_THRESHOLDS.thinContentWords > 0);
  });

  test('stats count what was measured', () => {
    const audit = auditSeo(
      makeReport([
        makePage('https://example.com/a', html()),
        makePage('http://example.com/b', html({ title: null })),
      ]),
    );
    assert.equal(audit.stats.pagesCrawled, 2);
    assert.equal(audit.stats.httpsPages, 1);
    assert.equal(audit.stats.withTitle, 1);
  });
});

/* -------------------------------------------------------------------------- */
/* AEO audit                                                                  */
/* -------------------------------------------------------------------------- */

describe('the AEO audit', () => {
  test('carries a disclaimer that citation cannot be measured', () => {
    const audit = auditAeo(makeReport([makePage('https://example.com/', html())]));
    assert.equal(audit.disclaimer, AEO_DISCLAIMER);
    assert.match(audit.disclaimer, /no tool can measure/i);
    assert.match(audit.disclaimer, /not a promise/i);
  });

  test('says plainly that AI citation is not checkable', () => {
    const audit = auditAeo(makeReport([makePage('https://example.com/', html())]));
    assert.ok(audit.notChecked.some((item) => /cite/i.test(item.area)));
    // And warns about products that claim otherwise.
    assert.ok(audit.notChecked.some((item) => /suspicion/i.test(item.whatWouldHelp)));
  });

  test('NO finding promises AI visibility, citation or traffic', () => {
    const report = makeReport([
      makePage('https://example.com/', html({ h2: [], h3: [], body: 'Short.', lang: null })),
      makePage('https://example.com/b', html({ body: 'Another short page.' })),
    ]);
    const audit = auditAeo(report);

    assert.ok(audit.findings.length > 3);
    for (const finding of audit.findings) {
      assert.deepEqual(
        lintFinding(finding),
        [],
        `"${finding.id}" makes a forbidden promise: ${finding.expectedBenefit}`,
      );
    }
    assert.deepEqual(audit.suppressed, []);
  });

  test('question headings with no FAQ markup are a concrete opportunity', () => {
    const page = makePage(
      'https://example.com/faq',
      html({ h2: ['How long does delivery take?', 'What is your return policy?'] }),
    );
    const finding = auditAeo(makeReport([page])).findings.find((item) => item.id.startsWith('aeo-faq-markup'));

    assert.ok(finding);
    assert.equal(finding.confidence, 'high');
    assert.match(finding.recommendation, /only what is visible/i);
  });

  test('a site with no question headings at all is reported', () => {
    const page = makePage('https://example.com/', html({ h2: ['Delivery information'] }));
    assert.ok(
      auditAeo(makeReport([page])).findings.some((item) => item.id.startsWith('aeo-conversational')),
    );
  });

  test('a missing Organization entity is high severity', () => {
    const finding = auditAeo(makeReport([makePage('https://example.com/', html())])).findings.find(
      (item) => item.id.startsWith('aeo-entity-missing'),
    );
    assert.ok(finding);
    assert.equal(finding.severity, 'high');
  });

  test('undated content is reported', () => {
    assert.ok(
      auditAeo(makeReport([makePage('https://example.com/', html())])).findings.some((item) =>
        item.id.startsWith('aeo-undated'),
      ),
    );
  });

  test('a dated page is not reported as undated', () => {
    const page = makePage(
      'https://example.com/',
      html({
        jsonLd: [{ '@type': 'Article', datePublished: new Date().toISOString(), author: { name: 'A Writer' } }],
      }),
    );
    assert.ok(
      !auditAeo(makeReport([page])).findings.some((item) => item.id.startsWith('aeo-undated')),
    );
  });

  test('a missing lang attribute is reported', () => {
    assert.ok(
      auditAeo(makeReport([makePage('https://example.com/', html({ lang: null }))])).findings.some(
        (item) => item.id.startsWith('aeo-lang'),
      ),
    );
  });

  test('noindex pages are excluded from the AEO analysis', () => {
    // A page that asks not to be indexed cannot appear in an answer either, so
    // analysing it would produce findings nobody should act on.
    const audit = auditAeo(
      makeReport([makePage('https://example.com/', html({ robots: 'noindex' }))]),
    );
    assert.equal(audit.stats.pagesAnalysed, 0);
  });

  test('stats report what is structurally present', () => {
    const audit = auditAeo(
      makeReport([
        makePage('https://example.com/', html({ h2: ['What is coffee?'] })),
        makePage('https://example.com/b', html()),
      ]),
    );
    assert.equal(audit.stats.pagesAnalysed, 2);
    assert.equal(audit.stats.questionHeadings, 1);
  });
});

/* -------------------------------------------------------------------------- */
/* Keywords                                                                   */
/* -------------------------------------------------------------------------- */

describe('search volume is never fabricated', () => {
  test('the unavailable state is the default and says why', () => {
    assert.equal(NO_VOLUME_DATA.kind, 'unavailable');
    assert.equal(NO_VOLUME_DATA.label, 'Data unavailable');
    assert.match(NO_VOLUME_DATA.why, /no keyword data source/i);
  });

  test('competition is on the same footing', () => {
    assert.equal(NO_COMPETITION_DATA.kind, 'unavailable');
    assert.equal(NO_COMPETITION_DATA.label, 'Data unavailable');
  });

  test('EVERY extracted keyword reports volume as unavailable', () => {
    const report = makeReport([
      makePage('https://example.com/', html({ h2: ['How do I order coffee online?'] })),
    ]);
    const set = extractKeywords(report);

    assert.ok(set.keywords.length > 0);
    for (const keyword of set.keywords) {
      assert.equal(keyword.volume.kind, 'unavailable', `${keyword.query} carries a volume figure`);
      assert.equal(keyword.competition.kind, 'unavailable');
    }
  });

  test('the printed label never contains a bare number for an unavailable value', () => {
    assert.equal(volumeLabel(NO_VOLUME_DATA), 'Data unavailable');
    assert.equal(competitionLabel(NO_COMPETITION_DATA), 'Data unavailable');
    assert.ok(!/\d/.test(volumeLabel(NO_VOLUME_DATA)));
  });

  test('an estimate is labelled "AI estimate" and expressed as a BAND', () => {
    // A band cannot be mistaken for a measurement the way "1,200/month" can.
    const label = volumeLabel({
      kind: 'estimate',
      label: 'AI estimate',
      magnitude: 'moderate',
      basis: 'Inferred from the query wording.',
    });
    assert.match(label, /AI estimate/);
    assert.ok(!/\d/.test(label), 'an estimate must not print a number');
  });

  test('a measured figure must name its source and date', () => {
    const label = volumeLabel({
      kind: 'measured',
      label: 'Measured',
      monthly: 1_200,
      source: 'Search Console',
      asOf: '2026-03',
    });
    assert.match(label, /Search Console/);
    assert.match(label, /2026-03/);
  });

  test('the keyword set carries the data note', () => {
    const set = extractKeywords(makeReport([makePage('https://example.com/', html())]));
    assert.match(set.dataNote, /Data unavailable/);
    assert.match(set.dataNote, /will not show a volume figure it cannot source/i);
  });
});

describe('keyword classification', () => {
  test('intent is read from the wording', () => {
    assert.equal(classifyIntent('buy coffee beans online'), 'transactional');
    assert.equal(classifyIntent('best coffee grinder review'), 'commercial');
    assert.equal(classifyIntent('what is a flat white'), 'informational');
    assert.equal(classifyIntent('acme coffee login'), 'navigational');
  });

  test('an unclassifiable query defaults to informational, not transactional', () => {
    // Defaulting to transactional would overstate the query's value.
    assert.equal(classifyIntent('coffee'), 'informational');
  });

  test('a query is several kinds at once', () => {
    const kinds = classifyKinds('where can I buy coffee near me in Nagpur', true);
    assert.ok(kinds.includes('primary'));
    assert.ok(kinds.includes('long-tail'));
    assert.ok(kinds.includes('local'));
    assert.ok(kinds.includes('transactional'));
    assert.ok(kinds.includes('conversational'));
  });

  test('every kind in the brief is reachable', () => {
    const seen = new Set<string>();
    const samples = [
      'coffee', 'speciality coffee beans', 'coffee shop near me', 'buy coffee online',
      'best coffee grinder', 'what is cold brew', 'how do I make coffee at home',
      'where should I buy my coffee from',
    ];
    for (const query of samples) {
      for (const kind of classifyKinds(query, true)) seen.add(kind);
      for (const kind of classifyKinds(query, false)) seen.add(kind);
    }
    for (const kind of KEYWORD_KINDS) {
      assert.ok(seen.has(kind), `no sample query produced the "${kind}" kind`);
    }
  });

  test('the suggested format follows the query shape', () => {
    assert.equal(suggestFormat('coffee vs tea', 'commercial'), 'comparison');
    assert.equal(suggestFormat('how to brew coffee', 'informational'), 'how-to');
    assert.equal(suggestFormat('what is cold brew?', 'informational'), 'faq-entry');
    assert.equal(suggestFormat('coffee shop near me', 'transactional'), 'location-page');
  });

  test('priority declares that it excludes volume', () => {
    const { PRIORITY_BASIS } = require('../src/lib/keywords/types') as { PRIORITY_BASIS: string };
    assert.match(PRIORITY_BASIS, /does not include search volume/i);
  });

  test('priority rises with relevance and commercial intent', () => {
    const strong = { score: 80, coveringUrls: ['https://example.com/'], basis: 'measured' };
    const weak = { score: 5, coveringUrls: [], basis: 'measured' };
    assert.equal(computePriority(strong, 'transactional'), 'high');
    assert.equal(computePriority(weak, 'informational'), 'low');
  });
});

describe('relevance is measured, not estimated', () => {
  test('a page that covers the query scores higher than one that does not', () => {
    const covering = makePage(
      'https://example.com/roasting',
      html({ title: 'How we roast our coffee', h1: ['Our roasting process'], body: 'We roast coffee slowly. '.repeat(20) }),
    );
    const unrelated = makePage('https://example.com/contact', html({ title: 'Contact us', h1: ['Contact'] }));

    const good = measureRelevance('coffee roasting process', [covering]);
    const bad = measureRelevance('coffee roasting process', [unrelated]);

    assert.ok(good.score > bad.score);
    assert.ok(good.coveringUrls.includes('https://example.com/roasting'));
  });

  test('a term in the title counts for more than the same term in the body', () => {
    const inTitle = makePage('https://example.com/a', html({ title: 'Espresso machines', h1: ['Espresso machines'] }));
    const inBody = makePage(
      'https://example.com/b',
      html({ title: 'Our shop', h1: ['Our shop'], body: 'We also sell espresso machines. '.repeat(10) }),
    );

    assert.ok(
      measureRelevance('espresso machines', [inTitle]).score >
        measureRelevance('espresso machines', [inBody]).score,
    );
  });

  test('an uncovered query scores zero and says so', () => {
    const result = measureRelevance('quantum computing', [makePage('https://example.com/', html())]);
    assert.equal(result.score, 0);
    assert.match(result.basis, /no crawled page mentions/i);
  });

  test('the basis states how the score was arrived at', () => {
    const page = makePage('https://example.com/', html({ title: 'Coffee roasting' }));
    assert.match(measureRelevance('coffee roasting', [page]).basis, /measured against the crawled text/i);
  });

  test('every keyword names where the query came from', () => {
    const set = extractKeywords(
      makeReport([makePage('https://example.com/', html({ h2: ['What is cold brew?'] }))]),
      ['coffee delivery Nagpur'],
    );

    const provided = set.keywords.find((keyword) => keyword.query === 'coffee delivery Nagpur');
    assert.equal(provided?.source, 'user_provided');

    const fromHeading = set.keywords.find((keyword) => keyword.query === 'What is cold brew?');
    assert.equal(fromHeading?.source, 'page_heading');
  });

  test('no keyword is invented: every query appears on the site or was entered', () => {
    const markup = html({ title: 'Acme Coffee | Nagpur', h1: ['Acme Coffee'], h2: ['Our roasting process'] });
    const set = extractKeywords(makeReport([makePage('https://example.com/', markup)]));

    for (const keyword of set.keywords) {
      const appears =
        markup.toLowerCase().includes(keyword.query.toLowerCase()) ||
        // A title has its brand suffix stripped, so check the prefix too.
        markup.toLowerCase().includes(keyword.query.toLowerCase().split(' | ')[0] ?? '');
      assert.ok(appears, `"${keyword.query}" does not appear on the page`);
    }
  });
});
