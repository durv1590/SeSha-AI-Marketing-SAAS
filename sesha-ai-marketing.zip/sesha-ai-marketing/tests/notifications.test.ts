import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  ALWAYS_ON,
  CHANNELS,
  CHANNEL_IDS,
  NOTIFICATION_DESCRIPTION,
  NOTIFICATION_KINDS,
  NOTIFICATION_LABEL,
  PHASE_6_NOTIFICATION_KINDS,
  availableChannels,
  checkPreferenceUpdates,
  defaultPreference,
  defaultPreferences,
  isAlwaysOn,
  isNotificationKind,
  notificationTitle,
  resolvePreferences,
  shouldNotify,
  storedKind,
} from '../src/lib/notifications/types';

describe('the notification vocabulary', () => {
  test('carries the eight kinds the brief names', () => {
    assert.equal(PHASE_6_NOTIFICATION_KINDS.length, 8);
    for (const kind of PHASE_6_NOTIFICATION_KINDS) {
      assert.ok((NOTIFICATION_KINDS as readonly string[]).includes(kind), kind);
    }
    for (const expected of [
      'report_ready',
      'new_lead',
      'campaign_changed',
      'content_scheduled',
      'schema_error',
      'audit_complete',
      'crawl_complete',
      'validation_complete',
    ] as const) {
      assert.ok(PHASE_6_NOTIFICATION_KINDS.includes(expected), expected);
    }
  });

  test('keeps the Phase 2 kinds rather than dropping them', () => {
    for (const kind of ['security', 'billing', 'system'] as const) {
      assert.ok((NOTIFICATION_KINDS as readonly string[]).includes(kind), kind);
    }
  });

  test('every kind has a label and a description a user can act on', () => {
    for (const kind of NOTIFICATION_KINDS) {
      assert.ok(NOTIFICATION_LABEL[kind].length > 0, kind);
      assert.ok(NOTIFICATION_DESCRIPTION[kind].length > 20, kind);
    }
  });

  test('the guard rejects anything else', () => {
    assert.ok(isNotificationKind('new_lead'));
    assert.ok(!isNotificationKind('marketing_blast'));
  });

  test('storedKind is total over every kind', () => {
    for (const kind of NOTIFICATION_KINDS) assert.equal(storedKind(kind), kind);
  });
});

describe('channels', () => {
  test('in-app is the only one available, and email says why it is not', () => {
    assert.deepEqual([...availableChannels()], ['in_app']);
    assert.equal(CHANNELS.email.available, false);
    assert.match(CHANNELS.email.unavailableReason ?? '', /No email provider is connected/);
  });

  test('an unavailable channel is shown rather than hidden', () => {
    // A customer deciding whether to buy should be able to see what is not built.
    assert.ok(CHANNEL_IDS.includes('email'));
    assert.ok((CHANNELS.email.unavailableReason ?? '').length > 40);
  });
});

describe('preferences', () => {
  test('everything is on by default except being told what you just did yourself', () => {
    assert.equal(defaultPreference('new_lead').inApp, true);
    assert.equal(defaultPreference('content_scheduled').inApp, false);
    assert.equal(defaultPreferences().length, NOTIFICATION_KINDS.length);
  });

  test('no kind defaults to email, because email cannot be sent', () => {
    for (const preference of defaultPreferences()) {
      assert.equal(preference.email, false, preference.kind);
    }
  });

  test('a kind with no stored row gets the default, not "off"', () => {
    // Otherwise a new notification kind arrives silently switched off for every
    // existing user, and nobody ever discovers the feature.
    const resolved = resolvePreferences([{ kind: 'new_lead', inApp: false, email: false }]);
    assert.equal(resolved.find((entry) => entry.kind === 'new_lead')?.inApp, false);
    assert.equal(resolved.find((entry) => entry.kind === 'crawl_complete')?.inApp, true);
    assert.equal(resolved.length, NOTIFICATION_KINDS.length);
  });

  test('a stored row cannot switch off a kind that is always on', () => {
    const resolved = resolvePreferences([{ kind: 'security', inApp: false, email: false }]);
    assert.equal(resolved.find((entry) => entry.kind === 'security')?.inApp, true);
  });

  test('a stored email preference is ignored while email is unavailable', () => {
    const resolved = resolvePreferences([{ kind: 'new_lead', inApp: true, email: true }]);
    assert.equal(resolved.find((entry) => entry.kind === 'new_lead')?.email, false);
  });
});

describe('what cannot be switched off, and why', () => {
  test('security and billing are always on', () => {
    assert.ok(isAlwaysOn('security'));
    assert.ok(isAlwaysOn('billing'));
    assert.ok(!isAlwaysOn('new_lead'));
  });

  test('each one carries a reason the interface can show', () => {
    for (const kind of NOTIFICATION_KINDS) {
      if (!isAlwaysOn(kind)) continue;
      assert.ok((ALWAYS_ON[kind] ?? '').length > 40, `${kind} needs an explanation, not just a locked toggle`);
    }
  });

  test('the security reason names the attack it prevents', () => {
    assert.match(ALWAYS_ON.security ?? '', /attacker must not be able to silence it/);
  });

  test('nothing in the brief’s eight is forced on', () => {
    for (const kind of PHASE_6_NOTIFICATION_KINDS) {
      assert.ok(!isAlwaysOn(kind), `${kind} is a marketing notification and must be the user's choice`);
    }
  });
});

describe('checkPreferenceUpdates', () => {
  test('accepts an ordinary change', () => {
    assert.deepEqual(checkPreferenceUpdates([{ kind: 'new_lead', inApp: false }]), []);
  });

  test('refuses to silently accept switching off security', () => {
    const problems = checkPreferenceUpdates([{ kind: 'security', inApp: false }]);
    assert.equal(problems.length, 1);
    assert.match(problems[0]?.message ?? '', /cannot be switched off/);
  });

  test('refuses a channel that cannot send', () => {
    const problems = checkPreferenceUpdates([{ kind: 'new_lead', email: true }]);
    assert.equal(problems.length, 1);
    assert.match(problems[0]?.message ?? '', /No email provider is connected/);
  });

  test('rejects an unknown kind', () => {
    const problems = checkPreferenceUpdates([
      { kind: 'blast' as (typeof NOTIFICATION_KINDS)[number], inApp: true },
    ]);
    assert.equal(problems.length, 1);
  });
});

describe('shouldNotify is the only route to a user', () => {
  const off = resolvePreferences(NOTIFICATION_KINDS.map((kind) => ({ kind, inApp: false, email: false })));

  test('honours a switched-off preference, and says which one', () => {
    const decision = shouldNotify('new_lead', off);
    assert.equal(decision.send, false);
    assert.ok(decision.send === false && /A new lead arrives/.test(decision.reason));
  });

  test('sends an always-on kind regardless of the stored preference', () => {
    const decision = shouldNotify('security', off);
    assert.ok(decision.send === true && decision.channels.includes('in_app'));
  });

  test('shouldNotify refuses to silence security ON ITS OWN, not only via resolvePreferences', () => {
    // Two layers guard this: resolvePreferences forces inApp back on, and
    // shouldNotify short-circuits. The first version of this test went through
    // resolvePreferences, so removing the short-circuit changed nothing and the
    // mutation survived. This one hands shouldNotify a raw, hostile preference
    // list — the shape a future caller who skips resolvePreferences would produce.
    const raw = [
      { kind: 'security' as const, inApp: false, email: false },
      { kind: 'billing' as const, inApp: false, email: false },
    ];
    assert.equal(shouldNotify('security', raw).send, true);
    assert.equal(shouldNotify('billing', raw).send, true);
    assert.equal(shouldNotify('new_lead', [{ kind: 'new_lead' as const, inApp: false, email: false }]).send, false);
  });

  test('uses the default when a kind has no preference at all', () => {
    assert.equal(shouldNotify('crawl_complete', []).send, true);
    assert.equal(shouldNotify('content_scheduled', []).send, false);
  });

  test('never returns email as a channel while email cannot be sent', () => {
    const optimistic = NOTIFICATION_KINDS.map((kind) => ({ kind, inApp: true, email: true }));
    for (const kind of NOTIFICATION_KINDS) {
      const decision = shouldNotify(kind, optimistic);
      assert.ok(decision.send === true);
      assert.ok(!decision.channels.includes('email'), kind);
    }
  });

  test('every kind can be decided without throwing', () => {
    for (const kind of NOTIFICATION_KINDS) {
      const decision = shouldNotify(kind, defaultPreferences());
      assert.ok(typeof decision.send === 'boolean');
    }
  });
});

describe('composing', () => {
  test('a title is collapsed and truncated without losing the start', () => {
    assert.equal(notificationTitle('  a   b  '), 'a b');
    const long = notificationTitle('x'.repeat(400));
    assert.equal(long.length, 120);
    assert.ok(long.endsWith('...'));
  });

  test('a short title is left alone', () => {
    assert.equal(notificationTitle('A crawl finished'), 'A crawl finished');
  });
});
