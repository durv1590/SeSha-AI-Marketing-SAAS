import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import { LIMIT_IDS, LIMITS, PLAN_DEFINITIONS, type LimitId } from '../src/content/plans';
import { effectiveLimits, type EffectiveLimits } from '../src/lib/plans/resolve';
import {
  NEAR_LIMIT_THRESHOLD,
  checkLimit,
  isDenied,
  limitStatus,
  pressurePoints,
  unmeasuredLimits,
  type QuotaContext,
} from '../src/lib/quota';
import {
  MEASURES,
  TRACKED_METRICS,
  USAGE_METRICS,
  WRITABLE_METRICS,
  daysUntilReset,
  isUsageMetric,
  isWritableMetric,
  limitForMetric,
  periodResetAt,
  periodStartOf,
  previousPeriodStart,
} from '../src/lib/usage/metrics';

const NOW = new Date('2026-03-15T10:00:00.000Z');

function context(partial: Partial<QuotaContext> = {}): QuotaContext {
  const plan = partial.plan ?? 'pro';
  return {
    plan,
    limits: partial.limits ?? effectiveLimits(plan),
    used: partial.used ?? 0,
    periodStart: partial.periodStart ?? '2026-03-01',
    now: partial.now ?? NOW,
    ...(partial.blockedReason ? { blockedReason: partial.blockedReason } : {}),
  };
}

/* -------------------------------------------------------------------------- */

describe('every limit is measurable', () => {
  test('no limit is left without a measure', () => {
    // The failure mode of a quota system is silently not enforcing something.
    assert.deepEqual([...unmeasuredLimits()], []);
  });

  test('a per-period limit names at least one recorded metric', () => {
    for (const id of LIMIT_IDS) {
      const measure = MEASURES[id];
      if (measure.kind !== 'per_period') continue;
      assert.ok(measure.metrics.length > 0, id);
      for (const metric of measure.metrics) {
        assert.ok(isUsageMetric(metric), `${id} measures by unknown metric ${metric}`);
      }
    }
  });

  test('an absolute limit names something countable', () => {
    for (const id of LIMIT_IDS) {
      const measure = MEASURES[id];
      if (measure.kind !== 'absolute') continue;
      assert.ok(
        ['projects', 'memberships', 'automation_rules'].includes(measure.countable),
        `${id}: ${measure.countable}`,
      );
    }
  });

  test('the measure kind agrees with the limit kind', () => {
    for (const id of LIMIT_IDS) {
      assert.equal(MEASURES[id].kind, LIMITS[id].kind, id);
    }
  });

  test('SEO and AEO audits are measured independently', () => {
    // They have separate limits in the brief, and Phases 4-6 recorded both as one
    // `audit_run`. With a single counter, spending the SEO allowance would have
    // silently spent the AEO one too.
    const seo = MEASURES.seo_audits;
    const aeo = MEASURES.aeo_audits;
    assert.ok(seo.kind === 'per_period' && aeo.kind === 'per_period');
    assert.ok(seo.metrics.includes('seo_audit'));
    assert.ok(aeo.metrics.includes('aeo_audit'));
    assert.ok(!seo.metrics.includes('aeo_audit'));
    assert.ok(!aeo.metrics.includes('seo_audit'));
  });

  test('the legacy audit metric still counts, and is never written again', () => {
    assert.ok(isUsageMetric('audit_run'));
    assert.ok(!isWritableMetric('audit_run'), 'writing it again would restore the old ambiguity');
    assert.ok(!WRITABLE_METRICS.includes('audit_run'));
  });

  test('the eight things the brief asks to track are all tracked', () => {
    for (const metric of [
      'ai_generation',
      'ai_tokens',
      'content_item',
      'crawl_run',
      'schema_validation',
      'report',
      'api_call',
    ] as const) {
      assert.ok(TRACKED_METRICS.includes(metric), metric);
      assert.ok((USAGE_METRICS as readonly string[]).includes(metric), metric);
    }
    assert.ok(TRACKED_METRICS.includes('seo_audit'));
    assert.ok(TRACKED_METRICS.includes('aeo_audit'));
  });

  test('limitForMetric maps a counter back to its limit', () => {
    assert.equal(limitForMetric('ai_generation'), 'ai_requests');
    assert.equal(limitForMetric('ai_tokens'), 'tokens');
    assert.equal(limitForMetric('report'), 'reports');
    assert.equal(limitForMetric('api_call'), null, 'API calls are tracked but not limited');
  });
});

/* -------------------------------------------------------------------------- */

describe('billing periods', () => {
  test('the period starts on the first, in UTC', () => {
    assert.equal(periodStartOf(new Date('2026-03-15T10:00:00Z')), '2026-03-01');
    assert.equal(periodStartOf(new Date('2026-01-01T00:00:00Z')), '2026-01-01');
    assert.equal(periodStartOf(new Date('2026-12-31T23:59:59Z')), '2026-12-01');
  });

  test('the previous period crosses a year boundary', () => {
    assert.equal(previousPeriodStart('2026-01-01'), '2025-12-01');
    assert.equal(previousPeriodStart('2026-03-01'), '2026-02-01');
  });

  test('the reset is the first of the next month', () => {
    assert.equal(periodResetAt('2026-03-01'), '2026-04-01T00:00:00.000Z');
    assert.equal(periodResetAt('2026-12-01'), '2027-01-01T00:00:00.000Z');
  });

  test('days until reset is never negative', () => {
    assert.equal(daysUntilReset('2026-03-01', new Date('2026-03-15T00:00:00Z')), 17);
    assert.equal(daysUntilReset('2026-03-01', new Date('2026-09-01T00:00:00Z')), 0);
  });
});

/* -------------------------------------------------------------------------- */

describe('checkLimit', () => {
  test('allows a request inside the allowance and says what is left', () => {
    const decision = checkLimit('ai_requests', context({ used: 10 }));
    assert.ok(decision.allowed);
    assert.equal(decision.used, 10);
    assert.equal(decision.remaining, PLAN_DEFINITIONS.pro.limits.ai_requests! - 11);
  });

  test('refuses when the allowance is spent, naming the usage and the reset', () => {
    const decision = checkLimit('ai_requests', context({ used: 500 }));
    assert.ok(isDenied(decision));
    assert.equal(decision.reason, 'period_exhausted');
    assert.match(decision.message, /500/);
    assert.match(decision.message, /resets in \d+ days/);
    assert.equal(decision.resetsAt, '2026-04-01T00:00:00.000Z');
  });

  test('an unlimited limit always allows, and reports no remaining figure', () => {
    const decision = checkLimit('projects', context({ plan: 'agency' }));
    assert.ok(decision.allowed);
    assert.equal(decision.remaining, null);
  });

  test('a zero limit says the feature is not included, not that it ran out', () => {
    const limits = effectiveLimits('free', [
      { limitId: 'reports', value: 0, reason: 'x', setBy: null, setAt: '2026-01-01' },
    ]);
    const decision = checkLimit('reports', context({ plan: 'free', limits, used: 0 }));
    assert.ok(isDenied(decision));
    assert.equal(decision.reason, 'not_included');
    assert.match(decision.message, /not included/);
  });

  test('an absolute limit says remove one or upgrade, and never mentions a reset', () => {
    const decision = checkLimit('projects', context({ used: 3 }));
    assert.ok(isDenied(decision));
    assert.equal(decision.reason, 'at_capacity');
    assert.match(decision.message, /Remove one, or upgrade/);
    assert.equal(decision.resetsAt, undefined, 'an absolute limit does not reset');
    assert.ok(!/resets/.test(decision.message));
  });

  test('a bulk amount is budgeted before the call, not after', () => {
    // Tokens: a single request costs thousands. Checking after the fact means
    // paying for the request that breaks the limit.
    const allowed = checkLimit('tokens', context({ used: 900_000 }), 50_000);
    assert.ok(allowed.allowed);
    const denied = checkLimit('tokens', context({ used: 900_000 }), 200_000);
    assert.ok(isDenied(denied));
  });

  test('a request bigger than the whole monthly allowance says so instead of "wait"', () => {
    // Telling someone to wait for a reset when waiting cannot help is worse than
    // saying nothing.
    const decision = checkLimit('tokens', context({ plan: 'free', used: 0 }), 500_000);
    assert.ok(isDenied(decision));
    assert.match(decision.message, /more than the .* a whole month/);
    assert.ok(!/resets in/.test(decision.message));
  });

  test('a blocked subscription is refused before any limit is consulted', () => {
    const decision = checkLimit(
      'ai_requests',
      context({ used: 0, blockedReason: 'Payment outstanding.' }),
    );
    assert.ok(isDenied(decision));
    assert.equal(decision.reason, 'subscription_blocked');
    assert.equal(decision.message, 'Payment outstanding.');
  });

  test('every limit can be checked without throwing, on every plan', () => {
    for (const plan of ['free', 'pro', 'business', 'agency'] as const) {
      for (const id of LIMIT_IDS) {
        const decision = checkLimit(id, context({ plan, used: 0 }));
        assert.equal(typeof decision.allowed, 'boolean', `${plan}.${id}`);
      }
    }
  });

  test('every limit refuses at its own ceiling', () => {
    // The property that matters: not "some limits are enforced" but "each one is".
    for (const plan of ['free', 'pro'] as const) {
      const limits: EffectiveLimits = effectiveLimits(plan);
      for (const id of LIMIT_IDS) {
        const value = limits[id].value;
        if (value === null) continue;
        const decision = checkLimit(id, context({ plan, limits, used: value }));
        assert.ok(isDenied(decision), `${plan}.${id} allowed a request at its ceiling`);
      }
    }
  });
});

/* -------------------------------------------------------------------------- */

describe('limitStatus', () => {
  const limits = effectiveLimits('pro');

  test('reports a percentage and the remainder', () => {
    const status = limitStatus(limits.ai_requests, 250);
    assert.equal(status.percentUsed, 50);
    assert.equal(status.remaining, 250);
    assert.equal(status.exhausted, false);
    assert.equal(status.nearLimit, false);
  });

  test('flags a limit that is near, from the threshold', () => {
    const value = limits.ai_requests.value as number;
    const status = limitStatus(limits.ai_requests, Math.ceil(value * NEAR_LIMIT_THRESHOLD));
    assert.equal(status.nearLimit, true);
    assert.equal(status.exhausted, false);
  });

  test('is exhausted at exactly the limit, not one past it', () => {
    const value = limits.ai_requests.value as number;
    assert.equal(limitStatus(limits.ai_requests, value).exhausted, true);
    assert.equal(limitStatus(limits.ai_requests, value - 1).exhausted, false);
  });

  test('clamps at 100% when an admin lowered a limit below current usage', () => {
    // A 340% bar reads as a bug rather than as a cap.
    const status = limitStatus(limits.ai_requests, 5_000);
    assert.equal(status.percentUsed, 100);
    assert.equal(status.remaining, 0);
  });

  test('unlimited reports no percentage rather than 0%', () => {
    const status = limitStatus(effectiveLimits('agency').projects, 900);
    assert.equal(status.percentUsed, null);
    assert.equal(status.remaining, null);
    assert.equal(status.exhausted, false);
  });

  test('a zero limit is exhausted from the start', () => {
    const zeroed = effectiveLimits('free', [
      { limitId: 'reports', value: 0, reason: 'x', setBy: null, setAt: '2026-01-01' },
    ]);
    assert.equal(limitStatus(zeroed.reports, 0).exhausted, true);
  });

  test('pressurePoints returns the worst first and ignores the comfortable', () => {
    const statuses = [
      limitStatus(limits.ai_requests, 500),
      limitStatus(limits.tokens, 10),
      limitStatus(limits.projects, 3),
    ];
    const pressure = pressurePoints(statuses);
    assert.equal(pressure.length, 2);
    assert.ok((pressure[0]?.percentUsed ?? 0) >= (pressure[1]?.percentUsed ?? 0));
    assert.ok(!pressure.some((status) => status.limit.id === 'tokens'));
  });
});
