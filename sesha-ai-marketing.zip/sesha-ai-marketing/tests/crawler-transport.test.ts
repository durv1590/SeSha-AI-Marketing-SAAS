import assert from 'node:assert/strict';
import { test, describe, after } from 'node:test';
import { createServer, type Server } from 'node:http';
import type { AddressInfo } from 'node:net';

import { nodeTransport } from '../src/lib/crawler/fetcher';

/**
 * The REAL socket transport, exercised against a real HTTP server.
 *
 * WHY THIS FILE EXISTS
 * Every other crawler test injects a fake `Transport`, which is the right way to
 * test the policy layer — but it meant `nodeTransport` itself had never been
 * executed by anything. The byte cap, the `content-length` pre-check, the
 * address pin and the timeouts were all reviewed code and nothing more.
 *
 * A Phase 8 audit found a real hole behind that: the file's own header promised
 * "a wall-clock timeout covers the whole request, not just the socket idle time,
 * because a server that trickles one byte a second never goes idle", and the
 * only timer was `timeout:` on the request options — which IS the socket idle
 * timer, the exact one a trickling server defeats. The documentation described
 * a defence that was not there. The first test below is the one that would have
 * caught it.
 *
 * These tests bind to 127.0.0.1. That is not a contradiction of the SSRF policy:
 * the policy lives in `ip-policy.ts` and `safeFetch`, both of which refuse
 * loopback long before the transport is reached. `nodeTransport` is the layer
 * BELOW the decision — it connects to an address it is handed — so handing it a
 * local one is how the layer gets tested at all.
 */

const servers: Server[] = [];

after(async () => {
  await Promise.all(
    servers.map((server) => new Promise<void>((resolve) => server.close(() => resolve()))),
  );
});

/** Starts a server on a free port and returns its origin. */
async function serve(handler: Parameters<typeof createServer>[1]): Promise<string> {
  const server = createServer(handler);
  servers.push(server);
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address() as AddressInfo;
  return `http://127.0.0.1:${port}`;
}

function req(url: string, overrides: Record<string, unknown> = {}) {
  return {
    url,
    address: '127.0.0.1',
    family: 4 as const,
    headers: { 'User-Agent': 'test' },
    timeoutMs: 2_000,
    maxBytes: 1_000,
    ...overrides,
  };
}

describe('the real transport: timeouts', () => {
  test('A SLOW-DRIP SERVER IS CUT OFF BY THE WALL CLOCK', async () => {
    // The slowloris shape: headers arrive immediately, then one byte at a time,
    // often enough that the socket is never idle. Against a socket-inactivity
    // timeout alone this request runs forever.
    const origin = await serve((_request, response) => {
      response.writeHead(200, { 'Content-Type': 'text/html' });
      const tick = setInterval(() => response.write('x'), 20);
      // Never calls response.end(). The interval is cleared when the socket dies.
      response.on('close', () => clearInterval(tick));
    });

    const started = Date.now();
    await assert.rejects(
      () => nodeTransport(req(`${origin}/slow`, { timeoutMs: 300, maxBytes: 1_000_000 })),
      (error: NodeJS.ErrnoException) => {
        assert.equal(error.code, 'ETIMEDOUT');
        return true;
      },
      'a server that never stops trickling was not cut off',
    );

    const elapsed = Date.now() - started;
    // Bounded by the budget, not by the socket going idle — which it never does.
    assert.ok(elapsed < 2_000, `the request ran for ${elapsed}ms against a 300ms budget`);
  });

  test('a server that accepts and then says nothing at all still times out', async () => {
    const origin = await serve(() => {
      // No response, ever. This is the case the socket-idle timer DOES catch,
      // and it must keep working now that a second timer exists.
    });

    await assert.rejects(
      () => nodeTransport(req(`${origin}/silent`, { timeoutMs: 300 })),
      (error: NodeJS.ErrnoException) => error.code === 'ETIMEDOUT',
    );
  });

  test('a prompt response is not affected by either timer', async () => {
    const origin = await serve((_request, response) => {
      response.writeHead(200, { 'Content-Type': 'text/html' });
      response.end('<html><body>fine</body></html>');
    });

    const result = await nodeTransport(req(`${origin}/fast`, { timeoutMs: 300 }));
    assert.equal(result.status, 200);
    assert.match(result.body, /fine/);
    assert.equal(result.truncated, false);
  });
});

describe('the real transport: response size', () => {
  test('a DECLARED length over the cap is refused before a byte is read', async () => {
    let bodyWasWritten = false;
    const origin = await serve((_request, response) => {
      response.writeHead(200, {
        'Content-Type': 'text/html',
        'Content-Length': '5000',
      });
      bodyWasWritten = true;
      response.end('y'.repeat(5000));
    });

    await assert.rejects(
      () => nodeTransport(req(`${origin}/big`, { maxBytes: 1_000 })),
      (error: NodeJS.ErrnoException) => {
        assert.equal(error.code, 'ERR_TOO_LARGE');
        return true;
      },
    );
    // The server may or may not have got as far as writing; what matters is
    // that the client refused on the header alone.
    void bodyWasWritten;
  });

  test('an UNDECLARED oversized body is cut at the cap, and says it was cut', async () => {
    // Chunked encoding: no content-length, so the header check cannot help and
    // the streaming cut is the only thing standing between this and memory.
    const origin = await serve((_request, response) => {
      response.writeHead(200, { 'Content-Type': 'text/html' });
      const chunk = 'z'.repeat(500);
      let sent = 0;
      const tick = setInterval(() => {
        sent += 1;
        if (sent > 100) {
          clearInterval(tick);
          response.end();
          return;
        }
        response.write(chunk);
      }, 1);
      response.on('close', () => clearInterval(tick));
    });

    const result = await nodeTransport(req(`${origin}/stream`, { maxBytes: 1_000 }));
    assert.equal(result.truncated, true, 'an oversized stream was not reported as truncated');
    assert.equal(result.bytes, 1_000);
    assert.ok(
      result.body.length <= 1_000,
      `kept ${result.body.length} bytes against a 1000-byte cap`,
    );
  });

  test('a body exactly at the cap is kept whole and not marked truncated', async () => {
    const origin = await serve((_request, response) => {
      response.writeHead(200, { 'Content-Type': 'text/html' });
      response.end('a'.repeat(1_000));
    });

    const result = await nodeTransport(req(`${origin}/exact`, { maxBytes: 1_000 }));
    assert.equal(result.truncated, false, 'a body exactly at the cap was reported as truncated');
    assert.equal(result.bytes, 1_000);
  });
});

describe('the real transport: the address pin', () => {
  test('THE SOCKET NEVER PERFORMS ITS OWN LOOKUP, so a name cannot rebind under it', async () => {
    // The rebinding attack: the name resolves to a public address when policy
    // checks it, and to a private one a moment later when the socket connects.
    // The pin closes that window by giving the socket the approved address and
    // a `lookup` that returns it without consulting DNS.
    //
    // This asserts the property directly: a request whose URL hostname is a name
    // that does NOT resolve at all still succeeds, because nothing ever asks.
    const origin = await serve((_request, response) => {
      response.writeHead(200, { 'Content-Type': 'text/plain' });
      response.end('reached');
    });
    const port = new URL(origin).port;

    const result = await nodeTransport(
      req(`http://nonexistent.invalid:${port}/`, { address: '127.0.0.1' }),
    );

    assert.equal(result.status, 200);
    assert.equal(result.body, 'reached');
    // `.invalid` is reserved by RFC 2606 and resolves nowhere. Reaching the
    // server proves the connection used the pinned address, not the name.
  });

  test('the Host header carries the requested name, not the pinned address', async () => {
    // Virtual hosts depend on this, and so does any audit of a site behind a
    // shared IP: pinning the connection must not change what we asked for.
    let seenHost = '';
    const origin = await serve((request, response) => {
      seenHost = request.headers.host ?? '';
      response.writeHead(200, { 'Content-Type': 'text/plain' });
      response.end('ok');
    });
    const port = new URL(origin).port;

    await nodeTransport(req(`http://example.invalid:${port}/`, { address: '127.0.0.1' }));
    assert.equal(seenHost, `example.invalid:${port}`);
  });
});

describe('the real transport: what it reports back', () => {
  test('headers are lower-cased and a repeated header is joined, not dropped', async () => {
    const origin = await serve((_request, response) => {
      response.writeHead(200, {
        'Content-Type': 'text/html',
        'X-Custom-Thing': 'one',
        'Set-Cookie': ['a=1', 'b=2'],
      });
      response.end('body');
    });

    const result = await nodeTransport(req(`${origin}/headers`));
    assert.equal(result.headers['x-custom-thing'], 'one');
    assert.equal(result.headers['set-cookie'], 'a=1, b=2');
  });

  test('a non-2xx status is returned, not thrown — the caller decides', async () => {
    const origin = await serve((_request, response) => {
      response.writeHead(404, { 'Content-Type': 'text/html' });
      response.end('gone');
    });

    const result = await nodeTransport(req(`${origin}/missing`));
    assert.equal(result.status, 404);
  });

  test('a connection refused is an error the caller can recognise', async () => {
    // Port 1 on loopback with nothing listening.
    await assert.rejects(
      () => nodeTransport(req('http://127.0.0.1:1/', { timeoutMs: 1_000 })),
      (error: NodeJS.ErrnoException) => {
        assert.ok(
          error.code === 'ECONNREFUSED' || error.code === 'ETIMEDOUT',
          `unexpected code ${String(error.code)}`,
        );
        return true;
      },
    );
  });
});
