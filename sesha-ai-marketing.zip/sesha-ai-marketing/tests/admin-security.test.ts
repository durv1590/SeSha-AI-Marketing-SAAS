import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  ADMIN_NOT_FOUND_MESSAGE,
  ADMIN_PERMISSIONS,
  AdminAuthorizationError,
  adminRefusal,
  STAFF_ROLES,
  STAFF_ROLE_DESCRIPTION,
  STAFF_ROLE_LABEL,
  checkAdminAccess,
  isAdminPermission,
  isStaffRole,
  permissionsFor,
  requireAdmin,
  requiresSudo,
  staffRoleFrom,
  type AdminPermission,
  type StaffContext,
  type StaffRole,
} from '../src/lib/admin/auth';
import { PERMISSIONS, ROLES, can } from '../src/lib/auth/rbac';

function staff(partial: Partial<StaffContext> = {}): StaffContext {
  return {
    userId: 'u1',
    email: 'staff@sesha.example',
    role: 'engineer',
    sudo: true,
    sessionId: 's1',
    ipHash: null,
    ...partial,
  };
}

/* -------------------------------------------------------------------------- */
/* The separation that matters most                                          */
/* -------------------------------------------------------------------------- */

describe('an organization admin is NOT a platform admin', () => {
  test('the two role scales share no values', () => {
    // Reusing the org `admin` role would let every customer who made themselves
    // an admin of their own workspace read every other customer's data. It is a
    // one-line mistake and the most expensive one available in this phase.
    for (const role of ROLES) {
      assert.ok(!isStaffRole(role), `"${role}" is an organization role and a staff role`);
    }
    for (const role of STAFF_ROLES) {
      assert.ok(!(ROLES as readonly string[]).includes(role), `"${role}" is in both scales`);
    }
  });

  test('the two permission sets share no values', () => {
    for (const permission of PERMISSIONS) {
      assert.ok(!isAdminPermission(permission), `"${permission}" is in both sets`);
    }
    for (const permission of ADMIN_PERMISSIONS) {
      assert.ok(
        !(PERMISSIONS as readonly string[]).includes(permission),
        `"${permission}" is in both sets`,
      );
    }
  });

  test('no organization role grants any admin permission', () => {
    for (const role of ROLES) {
      for (const permission of ADMIN_PERMISSIONS) {
        assert.ok(
          !can(role, permission as unknown as (typeof PERMISSIONS)[number]),
          `organization role "${role}" grants "${permission}"`,
        );
      }
    }
  });

  test('the highest organization role is refused by every admin permission', () => {
    // The concrete version of the test above: an org owner with role `admin`
    // holds no StaffContext, so every check refuses.
    for (const permission of ADMIN_PERMISSIONS) {
      const access = checkAdminAccess(null, permission);
      assert.equal(access.ok, false, permission);
      assert.equal(access.ok === false && access.needsSudo, false);
    }
  });

  test('a refused stranger is told nothing exists', () => {
    // 404, not 403. A 403 confirms there is a panel worth attacking.
    assert.equal(ADMIN_NOT_FOUND_MESSAGE, 'Not found.');
    const access = checkAdminAccess(null, 'admin:users:read');
    assert.ok(access.ok === false && !/admin|permission|role/i.test(access.message));
  });
});

/* -------------------------------------------------------------------------- */
/* Roles and permissions                                                     */
/* -------------------------------------------------------------------------- */

describe('staff roles', () => {
  test('are three, ordered, and each explained', () => {
    assert.deepEqual([...STAFF_ROLES], ['support', 'engineer', 'platform_owner']);
    for (const role of STAFF_ROLES) {
      assert.ok(STAFF_ROLE_LABEL[role].length > 0, role);
      assert.ok(STAFF_ROLE_DESCRIPTION[role].length > 40, role);
    }
  });

  test('every permission has a minimum role', () => {
    // Written as "minimum role" so a new permission cannot be silently granted
    // to everyone or forgotten for a role.
    for (const permission of ADMIN_PERMISSIONS) {
      const holders = STAFF_ROLES.filter((role) => permissionsFor(role).includes(permission));
      assert.ok(holders.length > 0, `"${permission}" is held by nobody`);
      assert.ok(
        holders.includes('platform_owner'),
        `"${permission}" is not held by the platform owner, so the scale is not a hierarchy`,
      );
    }
  });

  test('support can read and change nothing', () => {
    const held = permissionsFor('support');
    assert.ok(held.length > 0);
    for (const permission of held) {
      assert.ok(
        permission.endsWith(':read') || permission === 'admin:feedback:write',
        `support holds "${permission}"`,
      );
    }
  });

  test('a higher role holds everything a lower one does', () => {
    const support = permissionsFor('support');
    const engineer = permissionsFor('engineer');
    const owner = permissionsFor('platform_owner');
    for (const permission of support) assert.ok(engineer.includes(permission), permission);
    for (const permission of engineer) assert.ok(owner.includes(permission), permission);
    assert.ok(owner.length > engineer.length);
    assert.ok(engineer.length > support.length);
  });

  test('only the platform owner may grant staff access', () => {
    // The one power that must not be self-serve: it is the power to give
    // yourself every other power.
    assert.ok(!permissionsFor('engineer').includes('admin:staff:write'));
    assert.ok(!permissionsFor('support').includes('admin:staff:write'));
    assert.ok(permissionsFor('platform_owner').includes('admin:staff:write'));
  });

  test('the brief’s dashboard surfaces all have a read permission', () => {
    for (const surface of [
      'users',
      'businesses',
      'projects',
      'subscriptions',
      'usage',
      'ai',
      'errors',
      'health',
      'reports',
      'feedback',
      'jobs',
      'security',
    ]) {
      assert.ok(
        isAdminPermission(`admin:${surface}:read`),
        `no read permission for the "${surface}" surface`,
      );
    }
  });

  test('the brief’s controls all have a write permission', () => {
    for (const control of [
      'plans',
      'limits',
      'templates',
      'prompts',
      'flags',
      'validator',
      'system',
    ]) {
      assert.ok(
        isAdminPermission(`admin:${control}:write`),
        `no write permission for the "${control}" control`,
      );
    }
  });
});

/* -------------------------------------------------------------------------- */
/* Strong authentication                                                     */
/* -------------------------------------------------------------------------- */

describe('every write needs a recent sign-in', () => {
  test('every write permission requires sudo', () => {
    // A stolen session cookie must not be enough to change a plan or a flag.
    for (const permission of ADMIN_PERMISSIONS) {
      if (!permission.endsWith(':write')) continue;
      assert.ok(requiresSudo(permission), `"${permission}" can be done without re-authenticating`);
    }
  });

  test('reading the audit log requires sudo too', () => {
    // Someone covering their tracks would start by reading who saw what.
    assert.ok(requiresSudo('admin:audit:read'));
  });

  test('ordinary reads do not require sudo', () => {
    // Asking support to re-authenticate to open a dashboard trains them to type
    // their password into anything that asks.
    assert.ok(!requiresSudo('admin:users:read'));
    assert.ok(!requiresSudo('admin:usage:read'));
  });

  test('a write without sudo is refused, and asks for re-authentication', () => {
    const access = checkAdminAccess(staff({ sudo: false }), 'admin:flags:write');
    assert.equal(access.ok, false);
    assert.ok(access.ok === false && access.needsSudo);
    assert.ok(access.ok === false && /Confirm your password/.test(access.message));
  });

  test('an insufficient role is a different refusal from a missing sudo', () => {
    // Conflating them either teaches staff to ignore permission errors or asks
    // someone to re-authenticate for something they will still be refused.
    const roleRefusal = checkAdminAccess(staff({ role: 'support', sudo: true }), 'admin:flags:write');
    assert.ok(roleRefusal.ok === false && !roleRefusal.needsSudo);
    const sudoRefusal = checkAdminAccess(staff({ role: 'engineer', sudo: false }), 'admin:flags:write');
    assert.ok(sudoRefusal.ok === false && sudoRefusal.needsSudo);
  });

  test('a sufficient role with sudo is allowed', () => {
    assert.deepEqual(checkAdminAccess(staff(), 'admin:flags:write'), { ok: true });
  });
});

describe('requireAdmin', () => {
  test('returns the context when allowed', () => {
    assert.equal(requireAdmin(staff(), 'admin:users:read').userId, 'u1');
  });

  test('throws a typed error carrying the permission and whether sudo is needed', () => {
    assert.throws(
      () => requireAdmin(staff({ sudo: false }), 'admin:flags:write'),
      (error: unknown) => {
        assert.ok(error instanceof AdminAuthorizationError);
        assert.equal(error.permission, 'admin:flags:write');
        assert.equal(error.needsSudo, true);
        return true;
      },
    );
  });

  test('throws for a non-staff caller', () => {
    assert.throws(() => requireAdmin(null, 'admin:users:read'), AdminAuthorizationError);
  });
});

/* -------------------------------------------------------------------------- */
/* Session controls                                                          */
/* -------------------------------------------------------------------------- */

describe('staff access is checked on every request, not trusted from the session', () => {
  test('a revoked row is not staff', () => {
    // Revoking must take effect immediately, not when the session expires —
    // which could be thirty days.
    assert.equal(staffRoleFrom({ role: 'engineer', revokedAt: new Date() }), null);
    assert.equal(staffRoleFrom({ role: 'engineer', revokedAt: null }), 'engineer');
  });

  test('a missing row is not staff', () => {
    assert.equal(staffRoleFrom(null), null);
  });

  test('an unrecognised role is not staff', () => {
    // Including the organization roles, if one were ever written into the table.
    assert.equal(staffRoleFrom({ role: 'admin', revokedAt: null }), null);
    assert.equal(staffRoleFrom({ role: 'owner', revokedAt: null }), null);
    assert.equal(staffRoleFrom({ role: '', revokedAt: null }), null);
  });
});

describe('the permission guard rejects anything it does not know', () => {
  test('an invented permission is refused rather than allowed by default', () => {
    const access = checkAdminAccess(staff({ role: 'platform_owner' }), 'admin:everything' as AdminPermission);
    assert.equal(access.ok, false);
  });

  test('isAdminPermission rejects near-misses', () => {
    assert.ok(isAdminPermission('admin:users:read'));
    assert.ok(!isAdminPermission('admin:users:write'));
    assert.ok(!isAdminPermission('admin:users'));
    assert.ok(!isAdminPermission('users:read'));
  });

  test('permissionsFor is a closed set for every role', () => {
    for (const role of STAFF_ROLES as readonly StaffRole[]) {
      for (const permission of permissionsFor(role)) {
        assert.ok(isAdminPermission(permission), `${role}: ${permission}`);
      }
    }
  });
});

/* -------------------------------------------------------------------------- */
/* What a refused caller is actually SENT                                     */
/* -------------------------------------------------------------------------- */

describe('the HTTP shape of a refusal', () => {
  /**
   * These tests exist because a mutation check caught their absence.
   *
   * Changing the guard's role-based refusal from 404 to 403 left the entire
   * suite green: every test asserted the DECISION (`checkAdminAccess`) and none
   * asserted the RESPONSE. The decision being right is worth nothing if the
   * response leaks what the decision was protecting, so the mapping was pulled
   * out of the request handler into `adminRefusal` and is asserted here.
   */
  function refuse(staff: StaffContext | null, permission: AdminPermission) {
    const access = checkAdminAccess(staff, permission);
    assert.equal(access.ok, false, `${permission} was allowed, so there is nothing to refuse`);
    if (access.ok) throw new Error('unreachable');
    return adminRefusal(access);
  }

  const support: StaffContext = {
    userId: 'u-support',
    email: 'support@example.com',
    role: 'support',
    sudo: true,
    sessionId: 's-1',
    ipHash: null,
  };
  const engineerStale: StaffContext = { ...support, role: 'engineer', sudo: false };

  test('a non-staff caller is sent 404, with nothing in the body', () => {
    const refusal = refuse(null, 'admin:users:read');
    assert.equal(refusal.status, 404);
    assert.equal(refusal.message, ADMIN_NOT_FOUND_MESSAGE);
    assert.equal(refusal.needsSudo, false);
  });

  test('STAFF WITH THE WRONG ROLE IS ALSO SENT 404, NOT 403', () => {
    // Support probing for staff management must not learn it is there.
    const refusal = refuse(support, 'admin:staff:write');
    assert.equal(refusal.status, 404, 'a wrong-role refusal confirmed the endpoint exists');
    assert.equal(refusal.message, ADMIN_NOT_FOUND_MESSAGE);
  });

  test('the 404 body never names a role, a permission or the panel', () => {
    for (const permission of ADMIN_PERMISSIONS) {
      const access = checkAdminAccess(support, permission);
      if (access.ok || access.needsSudo) continue;
      const refusal = adminRefusal(access);
      assert.equal(refusal.status, 404);
      assert.ok(
        !/role|permission|admin|staff|engineer|owner|forbidden/i.test(refusal.message),
        `refusing ${permission} disclosed something: ${refusal.message}`,
      );
    }
  });

  test('a stale sign-in is the ONE case that gets 403, and it says why', () => {
    const refusal = refuse(engineerStale, 'admin:flags:write');
    assert.equal(refusal.status, 403);
    assert.equal(refusal.needsSudo, true);
    // This caller is already known to be staff, so the message may be useful.
    assert.match(refusal.message, /password|sign-in/i);
  });

  test('404 is the only status other than the sudo 403', () => {
    const statuses = new Set<number>();
    for (const staff of [null, support, engineerStale]) {
      for (const permission of ADMIN_PERMISSIONS) {
        const access = checkAdminAccess(staff, permission);
        if (access.ok) continue;
        statuses.add(adminRefusal(access).status);
      }
    }
    assert.deepEqual([...statuses].sort(), [403, 404]);
  });

  test('the sudo flag is set on exactly the 403s', () => {
    for (const staff of [null, support, engineerStale]) {
      for (const permission of ADMIN_PERMISSIONS) {
        const access = checkAdminAccess(staff, permission);
        if (access.ok) continue;
        const refusal = adminRefusal(access);
        assert.equal(
          refusal.needsSudo,
          refusal.status === 403,
          `${permission} returned status ${refusal.status} with needsSudo ${refusal.needsSudo}`,
        );
      }
    }
  });
});
