import { expect, test } from '@playwright/test';

/**
 * Every public route returns 200, renders its h1, and exposes its metadata.
 * The path list mirrors the Phase 1 specification exactly.
 */

const ROUTES = [
  '/',
  '/features',
  '/solutions',
  '/solutions/small-business',
  '/solutions/startups',
  '/solutions/agencies',
  '/solutions/ecommerce',
  '/solutions/local-business',
  '/solutions/real-estate',
  '/solutions/education',
  '/solutions/healthcare',
  '/solutions/restaurants',
  '/seo',
  '/aeo',
  '/schema-validator',
  '/pricing',
  '/resources',
  '/blog',
  '/about',
  '/contact',
  '/privacy',
  '/terms',
  '/security',
  '/faq',
];

for (const route of ROUTES) {
  test(`${route} renders with valid metadata`, async ({ page }) => {
    const response = await page.goto(route);
    expect(response?.status()).toBe(200);

    await expect(page.locator('h1')).toHaveCount(1);
    await expect(page.locator('h1')).not.toBeEmpty();

    const title = await page.title();
    expect(title.length).toBeGreaterThan(0);
    expect(title.length).toBeLessThanOrEqual(60);

    const description = await page.locator('meta[name="description"]').getAttribute('content');
    expect(description?.length ?? 0).toBeGreaterThan(60);
    expect(description?.length ?? 0).toBeLessThanOrEqual(160);

    const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
    expect(canonical).toBeTruthy();
    expect(canonical).not.toContain('?');

    await expect(page.locator('meta[property="og:title"]')).toHaveCount(1);
    await expect(page.locator('meta[name="twitter:card"]')).toHaveCount(1);
  });
}

test('an unknown path returns a real 404', async ({ page }) => {
  const response = await page.goto('/this-page-does-not-exist');
  expect(response?.status()).toBe(404);
  await expect(page.getByRole('heading', { level: 1 })).toContainText('could not find');
});

test('an unknown solution slug returns 404, not a soft 404', async ({ page }) => {
  const response = await page.goto('/solutions/not-a-real-industry');
  expect(response?.status()).toBe(404);
});

test('sitemap lists every route', async ({ request }) => {
  const response = await request.get('/sitemap.xml');
  expect(response.status()).toBe(200);
  const body = await response.text();
  for (const route of ROUTES) {
    expect(body).toContain(route === '/' ? '<loc>' : route);
  }
});

test('robots.txt allows crawling and points at the sitemap', async ({ request }) => {
  const response = await request.get('/robots.txt');
  expect(response.status()).toBe(200);
  const body = await response.text();
  expect(body).toContain('Sitemap:');
  expect(body).toContain('Disallow: /api/');
});
