import { expect, test } from '@playwright/test';

/**
 * Keyboard and assistive-technology behaviour that can only be verified in a
 * real browser.
 */

test('the skip link is the first focusable element and moves focus to main', async ({ page }) => {
  await page.goto('/');
  await page.keyboard.press('Tab');

  const focused = page.locator(':focus');
  await expect(focused).toHaveText(/skip to main content/i);

  await page.keyboard.press('Enter');
  await expect(page).toHaveURL(/#main$/);
});

test('every interactive element shows a visible focus indicator', async ({ page }) => {
  await page.goto('/');
  await page.keyboard.press('Tab');
  await page.keyboard.press('Tab');

  const outline = await page.locator(':focus').evaluate((element) => {
    const style = getComputedStyle(element);
    return { width: style.outlineWidth, style: style.outlineStyle };
  });
  expect(outline.style).not.toBe('none');
  expect(parseFloat(outline.width)).toBeGreaterThan(0);
});

test('the navigation menu opens, closes on Escape and returns focus', async ({ page }) => {
  await page.goto('/');
  const trigger = page.getByRole('button', { name: 'Product' });

  if (await trigger.isVisible()) {
    await trigger.click();
    await expect(trigger).toHaveAttribute('aria-expanded', 'true');
    await page.keyboard.press('Escape');
    await expect(trigger).toHaveAttribute('aria-expanded', 'false');
  }
});

test('FAQ answers are present in the DOM while collapsed', async ({ page }) => {
  await page.goto('/faq');
  const collapsed = page.locator('details:not([open])').first();
  const text = await collapsed.locator('div').last().textContent();
  expect((text ?? '').trim().length).toBeGreaterThan(0);
});

test('the contact form reports validation errors accessibly', async ({ page }) => {
  await page.goto('/contact');
  await page.getByRole('button', { name: /send message/i }).click();

  const alert = page.getByRole('alert').first();
  await expect(alert).toBeVisible();
});

test('page content is readable with JavaScript disabled', async ({ browser }) => {
  const context = await browser.newContext({ javaScriptEnabled: false });
  const page = await context.newPage();
  await page.goto('/aeo');

  await expect(page.locator('h1')).toBeVisible();
  // The AEO requirement: answers must not depend on client-side rendering.
  await expect(page.locator('details').first()).toContainText(/\w{20,}/);
  await context.close();
});
