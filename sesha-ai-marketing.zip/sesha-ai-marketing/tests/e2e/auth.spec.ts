import { expect, test } from '@playwright/test';

/**
 * Authentication end-to-end.
 *
 * These require a running build and were AUTHORED BUT NOT EXECUTED in the
 * offline environment this phase was developed in. Run with:
 *   npm install && npm run build && npm run test:e2e
 */

const PASSWORD = 'a genuinely long passphrase 2026';

function uniqueEmail(): string {
  return `e2e-${Date.now()}-${Math.floor(Math.random() * 1e6)}@example.test`;
}

test.describe('route protection', () => {
  test('signed-out users are redirected away from the workspace', async ({ page }) => {
    await page.goto('/app');
    await expect(page).toHaveURL(/\/sign-in/);
  });

  test('the redirect carries the destination as a path, not a URL', async ({ page }) => {
    await page.goto('/app/projects');
    const url = new URL(page.url());
    const next = url.searchParams.get('next');
    expect(next).toBe('/app/projects');
    expect(next).not.toMatch(/^https?:/);
  });

  test('an open-redirect attempt in ?next is ignored', async ({ page }) => {
    await page.goto('/sign-in?next=https://evil.example');
    // The form must not navigate off-site even if submitted.
    await expect(page.locator('form')).toBeVisible();
  });

  test('onboarding also requires a session', async ({ page }) => {
    await page.goto('/onboarding');
    await expect(page).toHaveURL(/\/sign-in/);
  });
});

test.describe('registration and sign-in', () => {
  test('a new user can register, onboard and reach the workspace', async ({ page }) => {
    const email = uniqueEmail();

    await page.goto('/sign-up');
    await page.getByLabel('Your name').fill('E2E User');
    await page.getByLabel('Work email').fill(email);
    await page.getByLabel('Password').fill(PASSWORD);
    await page.getByRole('checkbox').check();
    await page.getByRole('button', { name: /create account/i }).click();

    await expect(page.getByText(/check your email/i)).toBeVisible();

    await page.goto('/onboarding');
    await expect(page.getByRole('heading', { name: /set up your workspace/i })).toBeVisible();

    // Step 1
    await page.getByLabel('Business name').fill('E2E Coffee');
    await page.getByLabel('Industry').selectOption('hospitality');
    await page.getByLabel('Country').fill('India');
    await page.getByLabel('City').fill('Nagpur');
    await page.getByRole('button', { name: 'Continue' }).click();

    // Step 2
    await page.getByLabel(/who are you trying to reach/i).fill('Local office workers who buy coffee.');
    await page.getByLabel(/what do you sell/i).fill('Speciality coffee and pastries.');
    await page.getByLabel('Price range').selectOption('mid_market');
    await page.getByRole('button', { name: 'foot traffic' }).click();
    await page.getByRole('button', { name: 'organic search' }).click();
    await page.getByRole('button', { name: 'friendly' }).click();
    await page.getByRole('button', { name: 'Continue' }).click();

    // Step 3 — no website entered, so nothing to consent to
    await page.getByRole('button', { name: 'Continue' }).click();

    // Step 4
    await page.getByRole('button', { name: /finish set-up/i }).click();
    await expect(page).toHaveURL(/\/app$/);
    await expect(page.getByRole('heading', { level: 1 })).toContainText(/welcome/i);
  });

  test('a wrong password gives the same message as an unknown account', async ({ page }) => {
    await page.goto('/sign-in');
    await page.getByLabel('Email').fill('definitely-not-registered@example.test');
    await page.getByLabel('Password').fill('some wrong password here');
    await page.getByRole('button', { name: /sign in/i }).click();
    const unknownAccountMessage = await page.getByRole('alert').textContent();

    await page.goto('/sign-in');
    await page.getByLabel('Email').fill('someone@example.test');
    await page.getByLabel('Password').fill('another wrong password');
    await page.getByRole('button', { name: /sign in/i }).click();
    const wrongPasswordMessage = await page.getByRole('alert').textContent();

    // Account enumeration: the two must be indistinguishable.
    expect(wrongPasswordMessage).toBe(unknownAccountMessage);
  });

  test('a weak password is rejected with the reason shown', async ({ page }) => {
    await page.goto('/sign-up');
    await page.getByLabel('Work email').fill(uniqueEmail());
    await page.getByLabel('Password').fill('short');
    await page.getByRole('checkbox').check();
    await page.getByRole('button', { name: /create account/i }).click();
    await expect(page.getByRole('alert').first()).toBeVisible();
  });
});

test.describe('password recovery', () => {
  test('the response is identical for known and unknown addresses', async ({ page }) => {
    await page.goto('/forgot-password');
    await page.getByLabel('Email').fill('nobody-at-all@example.test');
    await page.getByRole('button', { name: /send reset link/i }).click();
    const unknown = await page.getByRole('alert').textContent();

    await page.goto('/forgot-password');
    await page.getByLabel('Email').fill('someone@example.test');
    await page.getByRole('button', { name: /send reset link/i }).click();
    const known = await page.getByRole('alert').textContent();

    expect(known).toBe(unknown);
  });

  test('a reset page with no token explains what to do', async ({ page }) => {
    await page.goto('/reset-password');
    await expect(page.getByText(/missing reset link/i)).toBeVisible();
  });
});

test.describe('session cookies', () => {
  test('the session cookie is httpOnly and SameSite=Lax', async ({ page, context }) => {
    const email = uniqueEmail();
    await page.goto('/sign-up');
    await page.getByLabel('Work email').fill(email);
    await page.getByLabel('Password').fill(PASSWORD);
    await page.getByRole('checkbox').check();
    await page.getByRole('button', { name: /create account/i }).click();
    await expect(page.getByText(/check your email/i)).toBeVisible();

    const cookies = await context.cookies();
    const session = cookies.find((cookie) => cookie.name === 'sesha_session');
    expect(session, 'no session cookie was set').toBeTruthy();
    expect(session?.httpOnly).toBe(true);
    expect(session?.sameSite).toBe('Lax');

    // The CSRF cookie must be readable — the client echoes it back.
    const csrf = cookies.find((cookie) => cookie.name === 'sesha_csrf');
    expect(csrf?.httpOnly).toBe(false);
  });
});

test.describe('API authorization', () => {
  test('unauthenticated API calls are refused', async ({ request }) => {
    expect((await request.get('/api/projects')).status()).toBe(401);
    expect((await request.post('/api/projects', { data: { name: 'X' } })).status()).toBe(401);
    expect((await request.post('/api/onboarding', { data: {} })).status()).toBe(401);
    expect((await request.delete('/api/account')).status()).toBe(401);
  });

  test('the session endpoint reports signed-out state without erroring', async ({ request }) => {
    const response = await request.get('/api/auth/session');
    expect(response.status()).toBe(200);
    const body = (await response.json()) as { data?: { authenticated?: boolean } };
    expect(body.data?.authenticated).toBe(false);
  });

  test('a state-changing request without a CSRF token is refused', async ({ page, request }) => {
    const email = uniqueEmail();
    await page.goto('/sign-up');
    await page.getByLabel('Work email').fill(email);
    await page.getByLabel('Password').fill(PASSWORD);
    await page.getByRole('checkbox').check();
    await page.getByRole('button', { name: /create account/i }).click();
    await expect(page.getByText(/check your email/i)).toBeVisible();

    // Same browser context, but no CSRF header and no Origin.
    const response = await request.post('/api/projects', { data: { name: 'Forged' } });
    expect([401, 403]).toContain(response.status());
  });

  test('the Google start route reports honestly when unconfigured', async ({ request }) => {
    const response = await request.get('/api/auth/google/start', { maxRedirects: 0 });
    // Either a redirect to Google (configured) or a clear 501 (not configured).
    expect([302, 501]).toContain(response.status());
  });
});

test.describe('unbuilt features', () => {
  test('planned features are disabled in the sidebar, not linked', async ({ page }) => {
    // Requires an onboarded session; skipped when run in isolation.
    await page.goto('/app');
    if (!page.url().endsWith('/app')) test.skip();

    const planned = page.locator('[aria-disabled="true"]');
    await expect(planned.first()).toBeVisible();
    await expect(page.getByText('Soon').first()).toBeVisible();
  });
});
