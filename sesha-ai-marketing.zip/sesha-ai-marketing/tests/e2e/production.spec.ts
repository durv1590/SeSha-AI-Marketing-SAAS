import { expect, test } from '@playwright/test';

/**
 * Phase 8 — production behaviour across browsers and devices.
 *
 * Every test here is tagged `@cross-browser`, so it runs on Chromium at all five
 * breakpoints AND on Firefox, WebKit, Edge, Android and iOS (see
 * playwright.config.ts). AUTHORED, NOT EXECUTED: the development environment had
 * no npm registry access, so neither `next build` nor Playwright could run.
 */

const PUBLIC_PAGES = ['/', '/features', '/pricing', '/about', '/contact', '/privacy', '/terms'];

test.describe('@cross-browser layout', () => {
  for (const path of PUBLIC_PAGES) {
    test(`${path} has no horizontal scroll`, async ({ page }) => {
      await page.goto(path);
      const overflow = await page.evaluate(
        () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
      );
      expect(overflow).toBeLessThanOrEqual(0);
    });
  }

  test('exactly one h1 per public page', async ({ page }) => {
    for (const path of PUBLIC_PAGES) {
      await page.goto(path);
      await expect(page.locator('h1'), path).toHaveCount(1);
    }
  });

  test('tap targets are at least 24px (WCAG 2.2 SC 2.5.8)', async ({ page }) => {
    await page.goto('/');
    const small = await page.locator('a:visible, button:visible').evaluateAll((elements) =>
      elements
        .map((element) => element.getBoundingClientRect())
        .filter((box) => box.width > 0 && (box.width < 24 || box.height < 24)).length,
    );
    expect(small).toBe(0);
  });
});

test.describe('@cross-browser forms', () => {
  test('sign-in errors are announced and fields keep their labels', async ({ page }) => {
    await page.goto('/sign-in');
    await page.getByLabel(/email/i).fill('not-an-email');
    await page.getByRole('button', { name: /sign in/i }).click();
    await expect(page.getByRole('alert').first()).toBeVisible();
    await expect(page.getByLabel(/email/i)).toHaveAttribute('aria-invalid', 'true');
  });

  test('the keyboard reaches the submit button without a trap', async ({ page }) => {
    await page.goto('/sign-in');
    for (let step = 0; step < 15; step += 1) {
      await page.keyboard.press('Tab');
      const name = await page.evaluate(() => document.activeElement?.textContent ?? '');
      if (/sign in/i.test(name)) return;
    }
    throw new Error('Submit was not reachable by keyboard within 15 tabs');
  });
});

test.describe('@cross-browser motion and theme', () => {
  test('reduced motion disables transitions', async ({ browser }) => {
    const context = await browser.newContext({ reducedMotion: 'reduce' });
    const page = await context.newPage();
    await page.goto('/');
    const duration = await page
      .locator('a, button')
      .first()
      .evaluate((element) => getComputedStyle(element).transitionDuration);
    expect(parseFloat(duration)).toBeLessThanOrEqual(0.01);
    await context.close();
  });

  test('dark mode applies without a flash of the light theme', async ({ browser }) => {
    const context = await browser.newContext({ colorScheme: 'dark' });
    const page = await context.newPage();
    await page.goto('/');
    await expect(page.locator('html')).toHaveClass(/dark/);
    await context.close();
  });
});

test.describe('@cross-browser production headers', () => {
  test('security headers are present on a page response', async ({ request }) => {
    const response = await request.get('/');
    const headers = response.headers();
    expect(headers['content-security-policy']).toBeTruthy();
    expect(headers['x-content-type-options']).toBe('nosniff');
    expect(headers['referrer-policy']).toBeTruthy();
    expect(headers['x-powered-by']).toBeUndefined();
  });

  test('admin pages are 404 to a signed-out visitor, never 403', async ({ request }) => {
    const response = await request.get('/api/admin/audit');
    expect([401, 404]).toContain(response.status());
  });

  test('robots.txt and sitemap.xml are served', async ({ request }) => {
    expect((await request.get('/robots.txt')).ok()).toBe(true);
    const sitemap = await request.get('/sitemap.xml');
    expect(sitemap.ok()).toBe(true);
    expect(await sitemap.text()).toContain('<urlset');
  });
});
