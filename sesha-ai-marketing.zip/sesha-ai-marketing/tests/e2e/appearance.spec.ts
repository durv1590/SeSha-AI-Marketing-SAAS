import { expect, test } from '@playwright/test';

/** Theme switching, responsiveness and the security header contract. */

test('dark mode preference is honoured on first paint', async ({ browser }) => {
  const context = await browser.newContext({ colorScheme: 'dark' });
  const page = await context.newPage();
  await page.goto('/');

  await expect(page.locator('html')).toHaveClass(/dark/);
  const background = await page.locator('body').evaluate((el) => getComputedStyle(el).backgroundColor);
  expect(background).not.toBe('rgb(255, 255, 255)');
  await context.close();
});

test('the theme toggle switches and persists the choice', async ({ page }) => {
  await page.goto('/');
  const toggle = page.getByRole('button', { name: /switch to .* theme|toggle colour theme/i });
  const before = await page.locator('html').getAttribute('class');

  await toggle.click();
  await expect(page.locator('html')).not.toHaveClass(before ?? '');

  await page.reload();
  await expect(page.locator('html')).not.toHaveClass(before ?? '');
});

test('no horizontal scrolling at any breakpoint', async ({ page }) => {
  for (const width of [360, 414, 768, 1024, 1440, 1920]) {
    await page.setViewportSize({ width, height: 900 });
    await page.goto('/');
    const overflows = await page.evaluate(
      () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
    );
    expect(overflows, `horizontal overflow at ${width}px`).toBe(false);
  }
});

test('security headers are present', async ({ request }) => {
  const response = await request.get('/');
  const headers = response.headers();

  expect(headers['content-security-policy']).toContain("default-src 'self'");
  expect(headers['content-security-policy']).toContain("frame-ancestors 'none'");
  expect(headers['x-content-type-options']).toBe('nosniff');
  expect(headers['x-frame-options']).toBe('DENY');
  expect(headers['referrer-policy']).toBe('strict-origin-when-cross-origin');
  expect(headers['x-powered-by']).toBeUndefined();
});

test('the schema validator round-trips a document', async ({ page }) => {
  await page.goto('/schema-validator');
  await page.getByRole('button', { name: 'Broken breadcrumbs' }).click();
  await page.getByRole('button', { name: 'Validate' }).click();

  await expect(page.getByText(/error/i).first()).toBeVisible();
  await expect(page.getByText(/increase by 1|start at 1/i).first()).toBeVisible();
});

test('the contact API rejects an oversized or malformed body', async ({ request }) => {
  const bad = await request.post('/api/contact', { data: 'not json', headers: { 'content-type': 'text/plain' } });
  expect(bad.status()).toBe(400);

  const invalid = await request.post('/api/contact', { data: { name: 'a' } });
  expect(invalid.status()).toBe(422);
});
