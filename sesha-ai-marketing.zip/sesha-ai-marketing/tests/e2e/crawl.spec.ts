import { expect, test } from '@playwright/test';

/**
 * The crawl and audit surfaces, end to end.
 *
 * AUTHORED BUT NOT EXECUTED. The environment this phase was built in had no npm
 * registry access, so Playwright could not be installed. Run with:
 *   npm install && npm run build && npm run test:e2e
 *
 * NOTHING HERE CRAWLS A REAL SITE. A test that fetched a third-party website on
 * every CI run would be both rude and flaky. The crawl tests are skipped unless
 * CRAWL_E2E=1 and CRAWL_E2E_SITE point at a site you control.
 *
 * What runs unconditionally is the part that matters most: that the crawl
 * surfaces refuse to do anything without consent, and that the refusal is
 * visible rather than a silent no-op.
 */

const PASSWORD = 'a genuinely long passphrase 2026';
const CRAWL_ROUTES = ['/app/website-audit', '/app/seo-aeo'];

function uniqueEmail(): string {
  return `e2e-crawl-${Date.now()}-${Math.floor(Math.random() * 1e6)}@example.test`;
}

async function signUpAndOnboard(
  page: import('@playwright/test').Page,
  options: { website?: string } = {},
): Promise<void> {
  await page.goto('/sign-up');
  await page.getByLabel('Your name').fill('E2E User');
  await page.getByLabel('Work email').fill(uniqueEmail());
  await page.getByLabel('Password').fill(PASSWORD);
  await page.getByRole('checkbox').check();
  await page.getByRole('button', { name: /create account/i }).click();

  await page.goto('/onboarding');
  await page.getByLabel('Business name').fill('E2E Coffee');
  await page.getByLabel('Industry').selectOption('hospitality');
  await page.getByLabel('Country').fill('India');
  await page.getByLabel('City').fill('Nagpur');
  if (options.website) {
    await page.getByLabel(/website/i).fill(options.website);
  }
  await page.getByRole('button', { name: 'Continue' }).click();

  await page.getByLabel(/who are you trying to reach/i).fill('Local office workers.');
  await page.getByLabel(/what do you sell/i).fill('Speciality coffee.');
  await page.getByLabel('Price range').selectOption('mid_market');
  await page.getByRole('button', { name: 'foot traffic' }).click();
  await page.getByRole('button', { name: 'organic search' }).click();
  await page.getByRole('button', { name: 'friendly' }).click();
  await page.getByRole('button', { name: 'Continue' }).click();

  // Step 3: the crawl-consent step. Left ungranted unless a site was given.
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: /finish set-up/i }).click();
  await expect(page).toHaveURL(/\/app$/);
}

test.describe('route protection', () => {
  for (const route of CRAWL_ROUTES) {
    test(`${route} requires a session`, async ({ page }) => {
      await page.goto(route);
      await expect(page).toHaveURL(/\/sign-in/);
    });
  }
});

test.describe('the crawl surfaces render', () => {
  test.beforeEach(async ({ page }) => {
    await signUpAndOnboard(page);
  });

  for (const route of CRAWL_ROUTES) {
    test(`${route} renders one h1 and no error`, async ({ page }) => {
      const response = await page.goto(route);
      expect(response?.status()).toBe(200);
      await expect(page.locator('h1')).toHaveCount(1);
      await expect(page.getByText(/something went wrong/i)).toHaveCount(0);
    });
  }

  test('the crawler policy is published in the product', async ({ page }) => {
    // A user authorising a crawler is entitled to read what it does without
    // reading the source.
    await page.goto('/app/website-audit');
    await expect(page.getByText(/SeShaBot/)).toBeVisible();
    await expect(page.getByText(/obeys robots\.txt, and fails closed/i)).toBeVisible();
    await expect(page.getByText(/cannot be pointed at a private network/i)).toBeVisible();
    await expect(page.getByText(/does not run JavaScript/i)).toBeVisible();
  });
});

test.describe('consent gates the crawl', () => {
  test.beforeEach(async ({ page }) => {
    // Onboarded with NO website, so no consent was granted.
    await signUpAndOnboard(page);
  });

  test('without consent, the crawl button is disabled and the reason is shown', async ({ page }) => {
    await page.goto('/app/website-audit');
    await expect(page.getByText(/crawling is not authorised/i)).toBeVisible();
    await expect(page.getByRole('button', { name: /start a crawl/i })).toBeDisabled();
  });

  test('the audits are disabled until a crawl has run', async ({ page }) => {
    await page.goto('/app/seo-aeo');
    await expect(page.getByRole('button', { name: /run the SEO audit/i })).toBeDisabled();
    await expect(page.getByRole('button', { name: /run the AEO audit/i })).toBeDisabled();
  });

  test('no score or finding is shown before a crawl', async ({ page }) => {
    await page.goto('/app/seo-aeo');
    await expect(page.getByText(/no crawl has run for this project yet/i)).toBeVisible();
    await expect(page.getByText(/will not show a score or a finding it has not measured/i)).toBeVisible();
  });
});

test.describe('no invented metrics on screen', () => {
  test.beforeEach(async ({ page }) => {
    await signUpAndOnboard(page);
  });

  test('the keyword table shows "Data unavailable" and no volume figure', async ({ page }) => {
    await page.goto('/app/website-audit');
    const body = (await page.locator('body').textContent()) ?? '';
    expect(body).not.toMatch(/\d[\d,.]*\s*(?:searches|\/\s*month)\b/i);
  });

  test('no page claims AI ranking, citation or guaranteed traffic', async ({ page }) => {
    for (const route of CRAWL_ROUTES) {
      await page.goto(route);
      const body = (await page.locator('body').textContent()) ?? '';
      expect(body).not.toMatch(/guarantee[ds]?\s+\w*\s*(traffic|ranking|citation)/i);
      expect(body).not.toMatch(/will rank/i);
      expect(body).not.toMatch(/AI visibility score/i);
    }
  });
});

test.describe('a real crawl', () => {
  // Opt-in, and only against a site you control: CRAWL_E2E=1 plus
  // CRAWL_E2E_SITE=https://your-own-site.example
  test.skip(
    !process.env.CRAWL_E2E || !process.env.CRAWL_E2E_SITE,
    'set CRAWL_E2E=1 and CRAWL_E2E_SITE to a site you own',
  );

  test.beforeEach(async ({ page }) => {
    await signUpAndOnboard(page, { website: process.env.CRAWL_E2E_SITE });
  });

  test('a crawl runs, reports progress and produces an audit', async ({ page }) => {
    await page.goto('/app/website-audit');
    await page.getByRole('button', { name: /start a crawl/i }).click();

    // The progress bar is the assertion, not a sleep.
    await expect(page.getByRole('progressbar')).toBeVisible({ timeout: 30_000 });
    await expect(page.getByText(/pages read/i)).toBeVisible({ timeout: 5 * 60_000 });

    await page.goto('/app/seo-aeo');
    await page.getByRole('button', { name: /run the SEO audit/i }).click();
    await expect(page.getByText(/\/100/)).toBeVisible({ timeout: 2 * 60_000 });

    // Every score on screen carries its basis.
    await expect(page.getByText(/own weighting/i)).toBeVisible();
    // And the audit says what it could not check.
    await expect(page.getByText(/could not check/i)).toBeVisible();
  });

  test('a crawl can be cancelled, and what was read is kept', async ({ page }) => {
    await page.goto('/app/website-audit');
    await page.getByRole('button', { name: /crawl/i }).first().click();
    await expect(page.getByRole('button', { name: 'Cancel' })).toBeVisible({ timeout: 30_000 });

    await page.getByRole('button', { name: 'Cancel' }).click();
    await expect(page.getByText(/anything already read was kept/i)).toBeVisible({
      timeout: 2 * 60_000,
    });
  });
});
