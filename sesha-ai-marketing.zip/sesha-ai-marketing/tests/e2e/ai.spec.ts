import { expect, test } from '@playwright/test';

/**
 * The Phase 3 AI surfaces, end to end.
 *
 * AUTHORED BUT NOT EXECUTED. The environment this phase was built in had no
 * npm registry access, so Playwright could not be installed or run. Run with:
 *   npm install && npm run build && npm run test:e2e
 *
 * Two things these cover that the unit and render suites cannot:
 *  · the ROUTE GUARDS, which need a real server and real cookies;
 *  · the behaviour of a deployment with NO provider key, which is the state
 *    every deployment starts in and the one most likely to be hit first.
 *
 * The generation tests are skipped unless AI_E2E=1 and a provider key are set,
 * because a test that spends money at a provider on every CI run is a test
 * people switch off.
 */

const PASSWORD = 'a genuinely long passphrase 2026';
const AI_ROUTES = ['/app/ai', '/app/create', '/app/strategy', '/app/social', '/app/calendar'];

function uniqueEmail(): string {
  return `e2e-ai-${Date.now()}-${Math.floor(Math.random() * 1e6)}@example.test`;
}

/** Registers, onboards and leaves the browser signed in. */
async function signUpAndOnboard(page: import('@playwright/test').Page): Promise<void> {
  await page.goto('/sign-up');
  await page.getByLabel('Your name').fill('E2E User');
  await page.getByLabel('Work email').fill(uniqueEmail());
  await page.getByLabel('Password').fill(PASSWORD);
  await page.getByRole('checkbox').check();
  await page.getByRole('button', { name: /create account/i }).click();

  await page.goto('/onboarding');
  await page.getByLabel('Business name').fill('E2E Coffee');
  await page.getByLabel('Industry').selectOption('hospitality');
  await page.getByLabel('Country').fill('India');
  await page.getByLabel('City').fill('Nagpur');
  await page.getByRole('button', { name: 'Continue' }).click();

  await page.getByLabel(/who are you trying to reach/i).fill('Local office workers who buy coffee.');
  await page.getByLabel(/what do you sell/i).fill('Speciality coffee and pastries.');
  await page.getByLabel('Price range').selectOption('mid_market');
  await page.getByRole('button', { name: 'foot traffic' }).click();
  await page.getByRole('button', { name: 'organic search' }).click();
  await page.getByRole('button', { name: 'friendly' }).click();
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: /finish set-up/i }).click();
  await expect(page).toHaveURL(/\/app$/);
}

test.describe('route protection', () => {
  for (const route of AI_ROUTES) {
    test(`${route} requires a session`, async ({ page }) => {
      await page.goto(route);
      await expect(page).toHaveURL(/\/sign-in/);
    });
  }
});

test.describe('the AI surfaces render', () => {
  test.beforeEach(async ({ page }) => {
    await signUpAndOnboard(page);
  });

  for (const route of AI_ROUTES) {
    test(`${route} renders one h1 and no error state`, async ({ page }) => {
      const response = await page.goto(route);
      expect(response?.status()).toBe(200);
      await expect(page.locator('h1')).toHaveCount(1);
      await expect(page.getByText(/something went wrong/i)).toHaveCount(0);
    });
  }

  test('the copilot explains itself before any question is asked', async ({ page }) => {
    await page.goto('/app/ai');
    await expect(page.getByRole('heading', { level: 1 })).toContainText(/copilot/i);
    await expect(page.getByLabel('Your question')).toBeVisible();
    // The legend must be reachable, because it is what makes the labels usable.
    await expect(page.getByText(/what the labels mean/i)).toBeVisible();
  });

  test('content studio offers the format, language and tone controls', async ({ page }) => {
    await page.goto('/app/create');
    await expect(page.getByLabel('Format')).toBeVisible();
    await expect(page.getByLabel('Language')).toBeVisible();
    await expect(page.getByLabel('Tone')).toBeVisible();
    await expect(page.getByLabel(/creativity/i)).toBeVisible();
  });

  test('the strategy plan can be checked without spending a generation', async ({ page }) => {
    await page.goto('/app/strategy');
    await page.getByRole('button', { name: /check what can be built/i }).click();
    await expect(page.getByText(/sections can be written now/i)).toBeVisible();
    // Sections that need a crawl must be visibly limited, not silently thinner.
    await expect(page.getByText('Limited').first()).toBeVisible();
  });
});

test.describe('publishing is never implied', () => {
  test.beforeEach(async ({ page }) => {
    await signUpAndOnboard(page);
  });

  test('the social page states plainly that nothing is published', async ({ page }) => {
    await page.goto('/app/social');
    await expect(page.getByText(/does not publish to any platform/i)).toBeVisible();
  });

  test('no control anywhere offers to publish or schedule', async ({ page }) => {
    for (const route of ['/app/social', '/app/calendar']) {
      await page.goto(route);
      for (const label of [/^publish$/i, /^post now$/i, /^schedule$/i, /^go live$/i]) {
        await expect(page.getByRole('button', { name: label })).toHaveCount(0);
      }
    }
  });

  test('the calendar calls its dates planned, not scheduled', async ({ page }) => {
    await page.goto('/app/calendar');
    await expect(page.getByText(/notes to you, not a schedule/i)).toBeVisible();
  });
});

test.describe('no provider configured', () => {
  // The default state of a fresh deployment. Skipped when a key IS set,
  // because then the assertion would be testing the opposite case.
  test.skip(Boolean(process.env.AI_E2E), 'a provider key is configured');

  test.beforeEach(async ({ page }) => {
    await signUpAndOnboard(page);
  });

  test('the copilot says AI is unconfigured and disables the control', async ({ page }) => {
    await page.goto('/app/ai');
    await expect(page.getByText(/not configured/i)).toBeVisible();
    await expect(page.getByRole('button', { name: 'Ask' })).toBeDisabled();
  });

  test('content studio disables generation rather than failing on click', async ({ page }) => {
    await page.goto('/app/create');
    await expect(page.getByRole('button', { name: /generate/i })).toBeDisabled();
  });
});

test.describe('generation', () => {
  // Costs money at a real provider, so it is opt-in.
  test.skip(!process.env.AI_E2E, 'set AI_E2E=1 and a provider key to run');

  test.beforeEach(async ({ page }) => {
    await signUpAndOnboard(page);
  });

  test('an answer arrives labelled with where it came from', async ({ page }) => {
    await page.goto('/app/ai');
    await page.getByLabel('Your question').fill('What should I post about this week?');
    await page.getByRole('button', { name: 'Ask' }).click();

    // Generation is slow; the assertion, not a sleep, decides when it is done.
    await expect(page.getByRole('button', { name: 'Copy' })).toBeVisible({ timeout: 90_000 });

    // At least one block must carry a provenance label, or the whole contract
    // has silently stopped being enforced.
    const labels = page.locator('text=/From you|AI estimate|AI inference|Recommendation|Not available/');
    await expect(labels.first()).toBeVisible();
  });

  test('a draft can be generated, copied and exported', async ({ page }) => {
    await page.goto('/app/create');
    await page.getByLabel('Format').selectOption('blog');
    await page.getByLabel('Topic').fill('How we roast our coffee');
    await page.getByRole('button', { name: /generate/i }).click();

    await expect(page.getByRole('button', { name: /^Cop(y|ied)$/ })).toBeVisible({ timeout: 90_000 });
  });

  test('the answer can be shortened, and the rewrite is re-checked', async ({ page }) => {
    await page.goto('/app/ai');
    await page.getByLabel('Your question').fill('Give me three post ideas.');
    await page.getByRole('button', { name: 'Ask' }).click();
    await expect(page.getByRole('button', { name: 'Shorten' })).toBeVisible({ timeout: 90_000 });

    await page.getByRole('button', { name: 'Shorten' }).click();
    await expect(page.getByRole('button', { name: 'Shorten' })).toBeEnabled({ timeout: 90_000 });
  });
});
