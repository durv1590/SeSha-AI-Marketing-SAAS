import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { resolveSession, signIn, signUp, toRole, verifyEmail, type ServiceContext } from '../src/lib/auth/service';
import type { TenantContext } from '../src/lib/tenant';
import { routes, getRoute } from '../src/lib/routes';
import { appRoutes } from '../src/content/app-nav';
import { completeOnboarding, getProject, grantCrawlConsent, listProjects } from '../src/lib/workspace/service';
import { CRAWL_CONSENT_VERSION } from '../src/lib/validation/onboarding';
import { AIOrchestrator } from '../src/lib/ai/orchestrator';
import { AiCache, AiRateLimiter } from '../src/lib/ai/cost';
import type { AIProvider, CompletionRequest, CompletionResult } from '../src/lib/ai/provider';
import { askCopilot, listConversations, type AiServiceContext } from '../src/lib/ai/service';
import { generateStrategy, listStrategies } from '../src/lib/strategy/service';
import { generateContent, listContent } from '../src/lib/content/service';
import { DEFAULT_CONTROLS } from '../src/lib/content/types';
import { getLatestAudit, listJobs, listKeywords, requestJob, runJob, type CrawlServiceContext } from '../src/lib/crawl/service';
import type { Transport } from '../src/lib/crawler';
import { validateForProject, listValidationHistory } from '../src/lib/schema/service';
import { acknowledgeResearch, addCompetitor, analyseCompetitor, latestAnalysis } from '../src/lib/competitors/service';
import { listAdPlans, saveAdPlan, setAdPlanReviewState } from '../src/lib/ads/service';
import { checkLandingPage, recommendBudget, type AdPlan } from '../src/lib/ads/plan';
import { createLead, listLeads } from '../src/lib/leads/service';
import { calendarView, createEvent } from '../src/lib/calendar/service';
import { createRule, fire, listRuns } from '../src/lib/automation/service';
import { analyticsFor } from '../src/lib/analytics/service';
import { hasFigure } from '../src/lib/analytics/metrics';
import { generate, listReports, toReport } from '../src/lib/reports/service';
import { billingView } from '../src/lib/billing/service';
import { entitlementFor } from '../src/lib/plans/service';
import { dashboard } from '../src/lib/usage/service';

/**
 * The complete user journey, visitor to subscriber, through the real service
 * layer against ONE shared in-memory database.
 *
 * Every other suite starts each test from a fresh tenant. This one does not: each
 * step builds on what the earlier steps left behind, and asserts that it did —
 * the same organization and project throughout, ids carried forward, and the
 * counts at the end (analytics, report, usage) reflecting the whole journey. A
 * seam that only breaks when modules are used together shows up here first.
 *
 * The steps are sequential `test()`s; node:test runs them in order, and a failed
 * step leaves the later ones failing on missing state, which is the point.
 */

const PASSWORD = 'a genuinely long passphrase 2026';
const EMAIL = 'founder@acme-coffee.example.com';
const SITE = 'https://acme-coffee.example.com';
const RIVAL = 'https://rival-roasters.example.com';
const SECRET = 'test-secret-value-at-least-32-bytes-long';

/* -------------------------------------------------------------------------- */
/* Fakes: AI provider and HTTP transport (patterns from ai-services / jobs)    */
/* -------------------------------------------------------------------------- */

const CLEAN = JSON.stringify({
  blocks: [
    { kind: 'user_provided', text: 'You sell speciality coffee in Nagpur.' },
    { kind: 'recommendation', text: 'Lead with the roasting process, since that is what differs.' },
  ],
});

class FakeProvider implements AIProvider {
  readonly name = 'openai' as const;
  readonly models = [
    { id: 'fast-model', label: 'Fast', tier: 'fast' as const, contextTokens: 100_000, maxOutputTokens: 8_000 },
    { id: 'balanced-model', label: 'Balanced', tier: 'balanced' as const, contextTokens: 100_000, maxOutputTokens: 8_000 },
    { id: 'deep-model', label: 'Deep', tier: 'deep' as const, contextTokens: 200_000, maxOutputTokens: 16_000 },
  ];
  calls = 0;
  systemPrompts: string[] = [];
  isConfigured(): boolean {
    return true;
  }
  async complete(request: CompletionRequest, model: string): Promise<CompletionResult> {
    this.calls += 1;
    this.systemPrompts.push(request.system);
    return { text: CLEAN, usage: { inputTokens: 100, outputTokens: 50 }, model, provider: this.name, truncated: false };
  }
}

function pageHtml(title: string, links: string[] = []): string {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>${title}</title>
    <meta name="description" content="A description of ${title} long enough to pass the audit threshold comfortably.">
    <link rel="canonical" href="${SITE}/">
    <script type="application/ld+json">${JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: 'Acme Coffee',
      telephone: '+91 712 000 0000',
    })}</script>
    </head><body><h1>${title}</h1><h2>How do we roast our coffee?</h2>
    <p>${'We roast our coffee slowly in small batches every morning. '.repeat(15)}</p>
    ${links.map((href) => `<a href="${href}">${href}</a>`).join('')}
    </body></html>`;
}

function rivalPage(title: string): string {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>${title}</title>
    <meta name="description" content="Rival Roasters is a speciality coffee roastery serving Nagpur since 2014.">
    </head><body><h1>${title}</h1><h2>Single origin beans</h2><h2>Subscriptions</h2>
    <p>${'We roast to order in small batches. '.repeat(20)}</p>
    <a href="https://www.instagram.com/rivalroasters">Instagram</a></body></html>`;
}

/** One scripted internet: the customer's own site and one competitor's. */
const INTERNET: Record<string, { status: number; body?: string }> = {
  [`${SITE}/robots.txt`]: { status: 404 },
  [`${SITE}/`]: { status: 200, body: pageHtml('Acme Coffee', ['/about']) },
  [`${SITE}/about`]: { status: 200, body: pageHtml('About us') },
  [`${RIVAL}/robots.txt`]: { status: 404 },
  [`${RIVAL}/`]: { status: 200, body: rivalPage('Rival Roasters') },
  [`${RIVAL}/about`]: { status: 200, body: rivalPage('About Rival Roasters') },
};

const requests: string[] = [];
const transport: Transport = async (request) => {
  requests.push(request.url);
  const scripted = INTERNET[request.url];
  const body = scripted?.body ?? '';
  return {
    status: scripted?.status ?? 404,
    headers: { 'content-type': 'text/html' },
    body,
    bytes: Buffer.byteLength(body),
    truncated: false,
  };
};
const fetchOptions = { transport, lookup: async () => [{ address: '93.184.216.34', family: 4 as const }] };

/* -------------------------------------------------------------------------- */
/* Fixtures (from phase6-services)                                             */
/* -------------------------------------------------------------------------- */

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: SITE,
};

const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic'] as const,
  marketingChannels: ['organic-search', 'email'] as const,
  brandVoice: { tones: ['friendly'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters' }],
};

/* -------------------------------------------------------------------------- */
/* Shared state, carried from step to step                                     */
/* -------------------------------------------------------------------------- */

const db = new MemoryDatabase();
const provider = new FakeProvider();
const auth: ServiceContext = { db, lockout: new MemoryLockoutStore(), secret: SECRET };
/**
 * The AI clock can be moved forward. The strategy's sections use up the per-minute
 * request allowance, and a real user reads the strategy before opening the
 * Content Studio; the journey says so rather than raising the limit.
 */
let aiClockOffset = 0;
const ai: AiServiceContext = {
  db,
  orchestrator: new AIOrchestrator({
    db,
    provider,
    cache: new AiCache(),
    limiter: new AiRateLimiter(),
    now: () => Date.now() + aiClockOffset,
    sleep: async () => {},
  }),
};
const crawlService: CrawlServiceContext = { db, fetchOptions, sleep: async () => {} };
/** A live clock: rows are stamped with real time, and a frozen one would sit outside the window. */
const ctx = () => ({ db, now: () => new Date() });
const today = new Date().toISOString().slice(0, 10);

let userId = '';
let verificationToken = '';
let sessionToken = '';
let tenant: TenantContext;
let projectId = '';
let businessId = '';
let brandKitId = '';
let consentId = '';
let crawlId = '';
let seoAuditId = '';
let aeoAuditId = '';
let competitorId = '';
let adPlanId = '';
let leadId = '';
let ruleId = '';
let campaignName = '';

describe('complete user journey', () => {
  test('1. visitor: the landing page and the sign-up page exist', () => {
    const home = getRoute('/');
    assert.ok(home, 'the landing page is a registered public route');
    assert.ok(routes.some((route) => route.path === '/pricing'));
    // `/sign-up` is not in the marketing route registry (src/lib/routes.ts drives
    // the sitemap, and an auth form does not belong in it). It is registered in
    // the application route list, which is what the route-coverage test reads.
    assert.equal(getRoute('/sign-up'), undefined);
    assert.ok(appRoutes.includes('/sign-up'));
    assert.ok(appRoutes.includes('/sign-in'));
    assert.ok(appRoutes.includes('/verify-email'));
    assert.ok(appRoutes.includes('/onboarding'));
  });

  test('2. registration: creates the user, organization, owner membership and trial', async () => {
    const result = await signUp(auth, { email: EMAIL, password: PASSWORD, name: 'Asha' });
    assert.equal(result.ok, true);
    if (!result.ok || !result.userId || !result.verificationToken) throw new Error('sign-up failed');
    userId = result.userId;
    verificationToken = result.verificationToken;

    const memberships = await db.memberships.findForUser(userId);
    assert.equal(memberships.length, 1);
    assert.equal(memberships[0]!.role, 'owner');
    tenant = { userId, organizationId: memberships[0]!.organizationId, role: toRole(memberships[0]!.role) };

    const subscription = await db.subscriptions.findForOrganization(tenant.organizationId);
    assert.equal(subscription?.plan, 'free');
    assert.equal(subscription?.status, 'trialing');
    assert.equal((await db.users.findById(userId))?.emailVerifiedAt, null);
  });

  test('3. email verification: the issued token verifies the address, once', async () => {
    // signUp returns the raw token for the caller to email; only its hash is stored.
    const verified = await verifyEmail(auth, verificationToken);
    assert.equal(verified.ok, true);
    if (!verified.ok) return;
    assert.equal(verified.userId, userId);
    assert.ok((await db.users.findById(userId))?.emailVerifiedAt instanceof Date);
    assert.equal((await verifyEmail(auth, verificationToken)).ok, false, 'the link must be single use');
  });

  test('4. login: signIn issues a session that resolves to the same tenant', async () => {
    const signed = await signIn(auth, { email: EMAIL, password: PASSWORD });
    assert.equal(signed.ok, true);
    if (!signed.ok) return;
    assert.equal(signed.user.id, userId);
    sessionToken = signed.token;

    const session = await resolveSession(auth, sessionToken);
    assert.ok(session);
    assert.equal(session.user.id, userId);
    assert.equal(session.user.organizationId, tenant.organizationId);
    assert.equal(session.user.role, 'admin', 'owner maps to the admin RBAC role');
    assert.ok(session.user.emailVerifiedAt, 'the session sees the verified address');
    assert.equal(session.user.onboardingCompletedAt, null, 'not onboarded yet');
  });

  test('5. business onboarding: business, project and marketing profile are created', async () => {
    const onboarded = await completeOnboarding({ db }, tenant, { business, profile });
    projectId = onboarded.project.id;
    businessId = onboarded.business.id;
    assert.equal(onboarded.project.organizationId, tenant.organizationId);
    assert.equal(onboarded.profile.projectId, projectId);
    assert.equal(onboarded.crawlConsent, null, 'no crawl consent unless asked for');

    const session = await resolveSession(auth, sessionToken);
    assert.ok(session?.user.onboardingCompletedAt, 'the session now reports onboarding complete');
  });

  test('6. project: the onboarded project is listed and readable', async () => {
    const projects = await listProjects({ db }, tenant);
    assert.deepEqual(projects.map((project) => project.id), [projectId]);
    const project = await getProject({ db }, tenant, projectId);
    assert.equal(project.name, business.name);
    assert.equal(project.businessId, businessId);
  });

  test('7. brand kit: stored for the project', async () => {
    // There is no brand-kit service function in src/lib; the only writer is the
    // repository. The kit's consumer IS a service (the AI context), which the
    // next step asserts actually reads it.
    const kit = await db.brandKits.upsert({
      organizationId: tenant.organizationId,
      projectId,
      voice: 'Warm and plain-spoken.',
      toneRules: 'Never use exclamation marks.',
      terminology: { 'pour-over': 'hand brew' },
      palette: { primary: '#5b3a29' },
      logoUrl: null,
    });
    brandKitId = kit.id;
    assert.equal((await db.brandKits.findByProject(tenant.organizationId, projectId))?.id, brandKitId);
  });

  test('8. AI Copilot: the answer is grounded in the business, profile and brand kit', async () => {
    const turn = await askCopilot(ai, tenant, { prompt: 'What should I post this week?', projectId });
    assert.equal(turn.result.ok, true);
    assert.equal(turn.conversation.projectId, projectId);
    assert.ok(turn.assistantMessage);

    const sources = turn.assistantMessage.contextSources as readonly { type: string; id: string }[];
    assert.ok(sources.some((source) => source.type === 'project' && source.id === projectId));
    assert.ok(sources.some((source) => source.type === 'business' && source.id === businessId));
    assert.ok(sources.some((source) => source.type === 'brand_kit' && source.id === brandKitId));
    const system = provider.systemPrompts.at(-1) ?? '';
    assert.match(system, /Acme Coffee/);
    assert.match(system, /Never use exclamation marks/);

    assert.equal((await listConversations(ai, tenant, projectId)).length, 1);
  });

  test('9. marketing strategy: generated for the project and stored', async () => {
    const outcome = await generateStrategy(ai, tenant, { projectId });
    assert.equal(outcome.ok, true);
    assert.ok(outcome.strategy);
    assert.equal(outcome.strategy.projectId, projectId);
    // Nothing has been crawled yet, so the SEO section must say it is limited.
    assert.notEqual(outcome.sections.find((section) => section.id === 'seo-strategy')?.availability, 'full');
    assert.equal((await listStrategies(ai, tenant, projectId)).length, 1);
  });

  test('10. content studio: a blog post is generated and saved to the project', async () => {
    aiClockOffset += 61_000; // a minute spent reading the strategy
    const outcome = await generateContent(ai, tenant, {
      projectId,
      controls: { ...DEFAULT_CONTROLS, format: 'blog', topic: 'Our roasting process' },
    });
    assert.equal(outcome.ok, true, JSON.stringify(outcome.result).slice(0, 400));
    assert.ok(outcome.item);
    assert.equal(outcome.item.projectId, projectId);
    assert.notEqual(outcome.item.status, 'approved', 'nothing is approved without a person');
    assert.equal((await listContent(ai, tenant, projectId)).length, 1);
  });

  test('11. website connection: crawl consent is granted for the business website', async () => {
    const consent = await grantCrawlConsent({ db }, tenant, projectId, {
      websiteUrl: SITE,
      consentVersion: CRAWL_CONSENT_VERSION,
      maxPages: 25,
      respectRobots: true,
      retentionDays: 30,
    });
    consentId = consent.id;
    assert.equal(consent.projectId, projectId);
    assert.equal((await db.crawlConsents.findActiveForProject(tenant.organizationId, projectId))?.id, consentId);
    assert.deepEqual(requests, [], 'granting consent fetches nothing');
  });

  test('12. crawl: queued, claimed and run under that consent', async () => {
    const job = await requestJob(crawlService, tenant, { projectId, kind: 'crawl' });
    assert.equal(job.status, 'queued');
    const claimed = await db.jobs.claimNext(new Date());
    assert.equal(claimed?.id, job.id);
    const outcome = await runJob(crawlService, claimed!);

    assert.equal(outcome.job.status, 'completed');
    assert.ok(outcome.crawl);
    crawlId = outcome.crawl.id;
    assert.equal(outcome.crawl.consentId, consentId);
    assert.equal(outcome.crawl.projectId, projectId);
    assert.equal(outcome.crawl.pagesCrawled, 2);
    assert.ok(requests.includes(`${SITE}/about`), 'the crawler followed the internal link');
    assert.ok((await listKeywords(crawlService, tenant, projectId)).length > 0);
  });

  test('13. SEO audit: runs on the stored crawl without refetching', async () => {
    const before = requests.length;
    await requestJob(crawlService, tenant, { projectId, kind: 'seo_audit' });
    const outcome = await runJob(crawlService, (await db.jobs.claimNext(new Date()))!);
    assert.equal(outcome.job.status, 'completed');
    assert.equal(outcome.audit?.kind, 'seo');
    assert.equal(outcome.audit?.crawlId, crawlId);
    seoAuditId = outcome.audit!.id;
    assert.equal(requests.length, before, 'the audit re-fetched the site');
    assert.equal((await getLatestAudit(crawlService, tenant, projectId, 'seo'))?.id, seoAuditId);
  });

  test('14. AEO audit: runs on the same crawl and stores findings', async () => {
    await requestJob(crawlService, tenant, { projectId, kind: 'aeo_audit' });
    const outcome = await runJob(crawlService, (await db.jobs.claimNext(new Date()))!);
    assert.equal(outcome.audit?.kind, 'aeo');
    assert.equal(outcome.audit?.crawlId, crawlId);
    assert.ok(outcome.audit!.findings.length > 0);
    aeoAuditId = outcome.audit!.id;
    assert.notEqual(aeoAuditId, seoAuditId);
    const jobs = await listJobs(crawlService, tenant, projectId);
    assert.equal(jobs.length, 3);
    assert.ok(jobs.every((job) => job.status === 'completed'));
  });

  test('15. schema validation: the crawled home page\'s JSON-LD is validated and kept', async () => {
    const outcome = await validateForProject({ db }, tenant, { projectId, sourceKind: 'page_url', url: `${SITE}/` });
    assert.ok(outcome.result.typesFound.includes('Organization'), 'the markup from the crawl reached the validator');
    assert.ok(outcome.stored);
    assert.equal(outcome.stored.projectId, projectId);
    assert.equal(outcome.stored.sourceUrl, `${SITE}/`);
    assert.ok(outcome.result.limitations.some((limitation) => limitation.code === 'from_stored_crawl'));
    assert.equal((await listValidationHistory({ db }, tenant, projectId)).length, 1);
  });

  test('16. competitor intelligence: analysed only after acknowledgement', async () => {
    const competitor = await addCompetitor({ db, fetchOptions }, tenant, { projectId, name: 'Rival Roasters', websiteUrl: RIVAL });
    competitorId = competitor.id;
    assert.equal(competitor.projectId, projectId);
    await acknowledgeResearch({ db, fetchOptions }, tenant, competitorId, true);

    const outcome = await analyseCompetitor({ db, fetchOptions }, tenant, competitorId);
    assert.ok(outcome.analysis.pagesRead.length > 0);
    assert.ok(requests.some((url) => url.startsWith(RIVAL)), 'the competitor site was read');
    assert.equal((await latestAnalysis({ db, fetchOptions }, tenant, competitorId))?.id, outcome.stored.id);
  });

  test('17. advertising plan: a sound plan is saved for the project', async () => {
    const plan: AdPlan = {
      platform: 'google_ads',
      objective: 'leads',
      campaignName: 'Acme Coffee — catering leads',
      audience: {
        description: 'Office workers within 2 km searching for coffee near them.',
        locations: ['Nagpur'],
        languages: ['en', 'hi'],
        signals: ['coffee near me'],
        exclusions: ['wholesale'],
      },
      headlines: ['Fresh coffee in Nagpur', 'Roasted this morning', 'Two minutes from MG Road'],
      descriptions: [
        'Speciality coffee roasted in small batches every morning. Open from seven.',
        'Order ahead and collect on your way to the office. No queue.',
      ],
      primaryText: [],
      cta: '',
      creativeConcepts: [],
      landingPage: checkLandingPage(`${SITE}/order`, 'google_ads'),
      abIdeas: [],
      budget: recommendBudget({ currency: 'INR', objective: 'leads' }),
      reviewState: 'draft',
    };
    const saved = await saveAdPlan({ db }, tenant, { projectId, plan });
    adPlanId = saved.row.id;
    campaignName = saved.row.campaignName ?? '';
    assert.equal(saved.row.projectId, projectId);
    assert.equal(saved.row.reviewState, 'draft');
    assert.equal(campaignName, plan.campaignName);
  });

  test('18. campaign: the ad plan is approved as the campaign', async () => {
    // There is no separate campaign entity: a campaign IS an ad plan, identified
    // by its campaignName, and the calendar and reports group by that name.
    const approved = await setAdPlanReviewState({ db }, tenant, adPlanId, 'approved');
    assert.equal(approved.row.reviewState, 'approved');
    const plans = await listAdPlans({ db }, tenant, projectId);
    assert.deepEqual(plans.map((row) => row.id), [adPlanId]);
  });

  test('19. lead: an enquiry is captured on the project', async () => {
    const created = await createLead(ctx(), tenant, {
      projectId,
      name: 'Priya',
      email: 'priya@example.com',
      enquiry: 'Do you cater office events?',
      source: 'website_form',
      optInBasis: 'enquiry_reply',
    });
    leadId = created.lead.id;
    assert.equal(created.lead.projectId, projectId);
    assert.equal(created.lead.stage, 'new');
    const pipeline = await listLeads(ctx(), tenant, projectId);
    assert.deepEqual(pipeline.leads.map((lead) => lead.id), [leadId]);
    assert.equal(pipeline.counts.new, 1);
  });

  test('20. calendar: an entry is scheduled under the campaign', async () => {
    const event = await createEvent(ctx(), tenant, projectId, {
      kind: 'ads',
      title: 'Launch the catering campaign',
      date: today,
      campaign: campaignName,
    });
    assert.equal(event.status, 'planned');
    const view = await calendarView(ctx(), tenant, projectId, 'campaign');
    assert.deepEqual(view.events.map((entry) => entry.id), [event.id]);
  });

  test('21. automation: a rule fires on the lead and writes a follow-up', async () => {
    const { rule } = await createRule(ctx(), tenant, projectId, {
      name: 'Follow up new leads',
      trigger: 'lead_created',
      conditions: [{ field: 'email', operator: 'is_set' }],
      actions: [{ kind: 'create_follow_up', template: 'Ring the {{source}} lead.', offsetDays: 1 }],
      enabled: true,
    });
    ruleId = rule.id;
    const results = await fire(
      ctx(),
      tenant.organizationId,
      projectId,
      { kind: 'lead_created', payload: { email: 'priya@example.com', source: 'website_form' }, subjectId: leadId },
      tenant.userId,
    );
    assert.equal(results.length, 1);
    assert.equal(results[0]?.matched, true);
    assert.equal((await listRuns(ctx(), tenant, ruleId)).length, 1);

    const activities = await db.leadActivities.listForLead(tenant.organizationId, leadId);
    assert.ok(activities.some((row) => row.kind === 'follow_up' && /Ring the website_form lead/.test(row.note)));
  });

  test('22. analytics: the lead is counted; connection-dependent metrics are unavailable, not zero', async () => {
    const report = await analyticsFor(ctx(), tenant, projectId);
    assert.equal(report.anyConnected, false);
    const leads = report.metrics.find((metric) => metric.id === 'leads');
    assert.equal(leads?.value.kind, 'calculated');
    assert.ok(hasFigure(leads!.value) && leads!.value.value === 1);

    for (const id of ['traffic', 'impressions', 'ctr', 'cpc', 'roas', 'followers', 'reach'] as const) {
      const metric = report.metrics.find((entry) => entry.id === id);
      assert.equal(metric?.value.kind, 'unavailable', id);
      assert.equal(hasFigure(metric!.value), false, `${id} must not be a zero`);
    }
  });

  test('23. reports: the weekly report draws on the whole journey', async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');
    assert.equal(row.projectId, projectId);
    const report = toReport(row);
    assert.equal(report.provenance.anyConnected, false);

    const leads = report.metrics.find((metric) => metric.id === 'leads');
    assert.ok(leads && hasFigure(leads.value) && leads.value.value === 1);

    const campaigns = report.sections.find((section) => section.id === 'which_campaigns');
    const point = campaigns?.points.find((entry) => entry.evidence?.includes(adPlanId));
    assert.ok(point, 'the approved ad plan appears as a campaign');
    assert.match(point.text, /approved/);
    assert.match(point.detail ?? '', /0 of 1 planned/, 'the calendar entry is grouped under the campaign');

    const pages = report.sections.find((section) => section.id === 'which_pages');
    assert.ok((pages?.points.length ?? 0) > 0, 'audit findings reach the report');
    assert.ok(pages!.points.every((entry) => entry.text.startsWith(SITE)));

    assert.equal((await listReports(ctx(), tenant, projectId)).length, 1);
  });

  test('24. subscription: billing and usage reflect the journey', async () => {
    const billing = await billingView({ db }, tenant);
    assert.equal(billing.plan, 'free');
    assert.equal(billing.status, 'trialing');
    assert.ok(billing.trialEndsAt);

    const entitlement = await entitlementFor({ db }, tenant.organizationId);
    assert.equal(entitlement.writable, true);
    const usage = await dashboard({ db }, tenant.organizationId, entitlement.plan, entitlement.limits);
    const used = (id: string) => usage.limits.find((status) => status.limit.id === id)?.used;

    assert.equal(used('projects'), 1);
    assert.equal(used('website_crawls'), 1);
    assert.equal(used('seo_audits'), 1);
    assert.equal(used('aeo_audits'), 1);
    assert.equal(used('schema_validations'), 1);
    assert.equal(used('automations'), 1);
    assert.equal(used('ai_requests'), provider.calls, 'every provider call is counted');
    assert.equal(used('tokens'), provider.calls * 150);
    assert.equal(used('content_generations'), 1, 'the content-studio post counts against its limit');
    // Fixed in Phase 9: generating a report consumes the `reports` allowance.
    assert.equal(used('reports'), 1);

    // The free plan's single crawl is now spent, so a second one is refused.
    await assert.rejects(() => requestJob(crawlService, tenant, { projectId, kind: 'crawl' }), /limit|allowance|plan/i);
    assert.equal(usage.recentRefusals.length, 0, 'nothing was refused during the journey itself');
  });

  test('the Free plan\'s report allowance now binds (two a month, the third is refused)', async () => {
    await generate(ctx(), tenant, projectId, 'monthly');
    await assert.rejects(() => generate(ctx(), tenant, projectId, 'seo'), /limit|allowance|plan/i);
  });
});
