import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import { SUPPORTED_TYPES, validateJsonLd } from '../src/lib/schema-validator/validate';

const valid = {
  '@context': 'https://schema.org',
  '@type': 'Article',
  headline: 'How answer engine optimisation works',
  description: 'A practical explanation.',
  url: 'https://example.com/blog/aeo',
  datePublished: '2026-01-05',
  dateModified: '2026-02-10',
  author: { '@type': 'Organization', name: 'Editorial Team' },
  publisher: { '@type': 'Organization', name: 'Example', url: 'https://example.com' },
  image: { '@type': 'ImageObject', url: 'https://example.com/a.png' },
  mainEntityOfPage: { '@id': 'https://example.com/blog/aeo#webpage' },
};

describe('parsing', () => {
  test('empty input is an error', () => {
    const report = validateJsonLd('   ');
    assert.equal(report.parsed, false);
    assert.equal(report.valid, false);
  });

  test('malformed JSON reports a parse error rather than throwing', () => {
    const report = validateJsonLd('{ "@type": }');
    assert.equal(report.parsed, false);
    assert.match(report.messages[0]!.message, /could not be parsed/i);
  });

  test('accepts a pasted <script type="application/ld+json"> block', () => {
    const html = `<script type="application/ld+json">${JSON.stringify(valid)}</script>`;
    const report = validateJsonLd(html);
    assert.equal(report.parsed, true);
    assert.equal(report.counts.errors, 0);
  });

  test('rejects input over the size limit', () => {
    const huge = JSON.stringify({ '@context': 'https://schema.org', a: 'x'.repeat(250_000) });
    const report = validateJsonLd(huge);
    assert.equal(report.parsed, false);
    assert.match(report.messages[0]!.message, /byte limit/);
  });
});

describe('context and type checks', () => {
  test('missing @context is an error', () => {
    const report = validateJsonLd(JSON.stringify({ '@type': 'Organization', name: 'x', url: 'https://e.com' }));
    assert.ok(report.messages.some((m) => m.severity === 'error' && /@context/.test(m.message)));
  });

  test('non-schema.org context is a warning, not an error', () => {
    const report = validateJsonLd(
      JSON.stringify({ '@context': 'https://example.org', '@type': 'Organization', name: 'x', url: 'https://e.com' }),
    );
    assert.ok(report.messages.some((m) => m.severity === 'warning' && /schema.org/.test(m.message)));
  });

  test('missing @type is an error', () => {
    const report = validateJsonLd(JSON.stringify({ '@context': 'https://schema.org', name: 'x' }));
    assert.ok(report.messages.some((m) => /no "@type"/.test(m.message)));
  });

  test('unknown type is reported as info, not failure', () => {
    const report = validateJsonLd(
      JSON.stringify({ '@context': 'https://schema.org', '@type': 'Sculpture', name: 'x' }),
    );
    assert.equal(report.counts.errors, 0);
    assert.ok(report.messages.some((m) => m.severity === 'info'));
  });

  test('exposes the list of types it knows', () => {
    assert.ok(SUPPORTED_TYPES.includes('FAQPage'));
    assert.ok(SUPPORTED_TYPES.includes('BreadcrumbList'));
    assert.ok(SUPPORTED_TYPES.includes('SoftwareApplication'));
  });
});

describe('required and recommended properties', () => {
  test('valid article produces no errors', () => {
    const report = validateJsonLd(JSON.stringify(valid));
    assert.equal(report.counts.errors, 0, JSON.stringify(report.messages, null, 2));
    assert.equal(report.valid, true);
    assert.deepEqual(report.typesFound.includes('Article'), true);
  });

  test('a missing required property is an error', () => {
    const { headline: _omitted, ...withoutHeadline } = valid;
    const report = validateJsonLd(JSON.stringify(withoutHeadline));
    assert.ok(report.messages.some((m) => m.severity === 'error' && /headline/.test(m.message)));
  });

  test('a missing datePublished is a WARNING, not an error — and that is deliberate', () => {
    // CHANGED IN PHASE 5, on purpose.
    //
    // The Phase 1 validator treated `datePublished` as required on an Article and
    // reported its absence as an error. Schema.org does not require it: an Article
    // with no date is valid schema.org. What is true is that published
    // search-engine documentation asks for it.
    //
    // Those are different claims, and the brief for this phase is explicit that
    // schema validity must never be represented as search eligibility. So the
    // finding moved to the SEARCH_ELIGIBILITY dimension, which this legacy flat
    // projection renders as a warning. The finding did not get weaker — it got
    // honest about which kind of fact it is.
    const { datePublished: _omitted, ...withoutDate } = valid;
    const report = validateJsonLd(JSON.stringify(withoutDate));
    assert.equal(report.counts.errors, 0);
    assert.ok(
      report.messages.some((m) => m.severity === 'warning' && /datePublished/.test(m.message)),
      'the missing date must still be reported, just not as a validity error',
    );
  });

  test('missing recommended property is a warning', () => {
    const { image: _omitted, ...withoutImage } = valid;
    const report = validateJsonLd(JSON.stringify(withoutImage));
    assert.equal(report.counts.errors, 0);
    assert.ok(report.messages.some((m) => m.severity === 'warning' && /image/.test(m.message)));
  });

  test('empty string does not satisfy a required property', () => {
    const report = validateJsonLd(JSON.stringify({ ...valid, headline: '   ' }));
    assert.ok(report.messages.some((m) => m.severity === 'error' && /headline/.test(m.message)));
  });
});

describe('integrity rules', () => {
  test('invalid date format is an error', () => {
    const report = validateJsonLd(JSON.stringify({ ...valid, datePublished: '05/01/2026' }));
    assert.ok(report.messages.some((m) => m.severity === 'error' && /ISO 8601/.test(m.message)));
  });

  test('dateModified before datePublished is an error', () => {
    const report = validateJsonLd(
      JSON.stringify({ ...valid, datePublished: '2026-05-01', dateModified: '2026-01-01' }),
    );
    assert.ok(report.messages.some((m) => /earlier than/.test(m.message)));
  });

  test('relative url is an error', () => {
    const report = validateJsonLd(JSON.stringify({ ...valid, url: '/blog/aeo' }));
    assert.ok(report.messages.some((m) => /absolute URL/.test(m.message)));
  });

  test('over-long headline is a warning', () => {
    const report = validateJsonLd(JSON.stringify({ ...valid, headline: 'A'.repeat(140) }));
    assert.ok(report.messages.some((m) => m.severity === 'warning' && /Headline is 140/.test(m.message)));
  });

  test('duplicate @id is an error', () => {
    const report = validateJsonLd(
      JSON.stringify({
        '@context': 'https://schema.org',
        '@graph': [
          { '@type': 'Organization', '@id': 'https://e.com/#org', name: 'A', url: 'https://e.com' },
          { '@type': 'Organization', '@id': 'https://e.com/#org', name: 'B', url: 'https://e.com' },
        ],
      }),
    );
    assert.ok(report.messages.some((m) => /Duplicate "@id"/.test(m.message)));
  });

  test('rating markup raises an honesty warning', () => {
    const report = validateJsonLd(
      JSON.stringify({
        ...valid,
        aggregateRating: { '@type': 'AggregateRating', ratingValue: 4.9, reviewCount: 812 },
      }),
    );
    assert.ok(report.messages.some((m) => m.severity === 'warning' && /genuine/.test(m.message)));
  });
});

describe('BreadcrumbList rules', () => {
  const crumbs = (positions: number[]) => ({
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: positions.map((p) => ({
      '@type': 'ListItem',
      position: p,
      name: `Item ${p}`,
      item: `https://e.com/${p}`,
    })),
  });

  test('sequential positions pass', () => {
    assert.equal(validateJsonLd(JSON.stringify(crumbs([1, 2, 3]))).counts.errors, 0);
  });

  test('positions with a gap fail', () => {
    const report = validateJsonLd(JSON.stringify(crumbs([1, 3])));
    assert.ok(report.messages.some((m) => /increase by 1/.test(m.message)));
  });

  test('positions starting at 0 fail', () => {
    const report = validateJsonLd(JSON.stringify(crumbs([0, 1])));
    assert.ok(report.messages.some((m) => /start at 1/.test(m.message)));
  });

  test('missing name on a ListItem is an error', () => {
    const report = validateJsonLd(
      JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        itemListElement: [{ '@type': 'ListItem', position: 1, item: 'https://e.com/1' }],
      }),
    );
    assert.ok(report.messages.some((m) => /missing "name"/.test(m.message)));
  });
});

describe('FAQPage rules', () => {
  test('well-formed FAQ passes', () => {
    const report = validateJsonLd(
      JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: [
          { '@type': 'Question', name: 'Q?', acceptedAnswer: { '@type': 'Answer', text: 'A.' } },
        ],
      }),
    );
    assert.equal(report.counts.errors, 0, JSON.stringify(report.messages));
  });

  test('missing acceptedAnswer is an error', () => {
    const report = validateJsonLd(
      JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: [{ '@type': 'Question', name: 'Q?' }],
      }),
    );
    assert.ok(report.messages.some((m) => /acceptedAnswer/.test(m.message)));
  });

  test('answer without text is an error', () => {
    const report = validateJsonLd(
      JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: [{ '@type': 'Question', name: 'Q?', acceptedAnswer: { '@type': 'Answer' } }],
      }),
    );
    assert.ok(report.messages.some((m) => /missing "text"/.test(m.message)));
  });
});

describe('Offer rules', () => {
  test('price without currency is an error', () => {
    const report = validateJsonLd(
      JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'SoftwareApplication',
        name: 'App',
        applicationCategory: 'BusinessApplication',
        offers: [{ '@type': 'Offer', price: 29 }],
      }),
    );
    assert.ok(report.messages.some((m) => /priceCurrency/.test(m.message)));
  });

  test('offer with neither price nor priceSpecification is an error', () => {
    const report = validateJsonLd(
      JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'Product',
        name: 'Thing',
        offers: [{ '@type': 'Offer' }],
      }),
    );
    assert.ok(report.messages.some((m) => /needs "price"/.test(m.message)));
  });
});

describe('graph traversal', () => {
  test('walks every node in @graph', () => {
    const report = validateJsonLd(
      JSON.stringify({
        '@context': 'https://schema.org',
        '@graph': [
          { '@type': 'Organization', name: 'A', url: 'https://e.com' },
          { '@type': 'WebSite', name: 'A', url: 'https://e.com' },
        ],
      }),
    );
    assert.deepEqual(report.typesFound, ['Organization', 'WebSite']);
    assert.ok(report.nodeCount >= 2);
  });

  test('reference-only nodes are not flagged for missing properties', () => {
    const report = validateJsonLd(
      JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'WebPage',
        name: 'P',
        url: 'https://e.com/p',
        isPartOf: { '@id': 'https://e.com/#website' },
      }),
    );
    assert.equal(report.counts.errors, 0, JSON.stringify(report.messages));
  });
});
