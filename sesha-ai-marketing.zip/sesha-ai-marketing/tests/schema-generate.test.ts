import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { signUp, toRole } from '../src/lib/auth/service';
import { completeOnboarding, grantCrawlConsent } from '../src/lib/workspace/service';
import { CRAWL_CONSENT_VERSION } from '../src/lib/validation/onboarding';
import { NotFoundError, type TenantContext } from '../src/lib/tenant';
import { NEVER_INVENT_PROPERTIES } from '../src/lib/schema-validator';
import {
  GENERATED_KINDS,
  generateSchema,
  refusalFor,
  type GenerateInput,
} from '../src/lib/schema/generate';
import {
  ValidationInputError,
  compareStoredValidations,
  generateForProject,
  listValidationHistory,
  validateForProject,
  type SchemaServiceContext,
} from '../src/lib/schema/service';

/**
 * Schema generation, and the validation history.
 *
 * THE CENTRAL ASSERTION of this file is that the generator never invents. A
 * generated `aggregateRating` is not a marketing flourish — it is a false
 * statement published on the customer's own domain, under their name, that a
 * search engine can penalise them for. So there are tests for every property on
 * the never-invent list, and a test that the generator's own output passes the
 * validator this product ships.
 */

const PASSWORD = 'a genuinely long passphrase 2026';
const SITE = 'https://acme-coffee.example.com';

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: SITE,
};

const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic'] as const,
  marketingChannels: ['organic-search'] as const,
  brandVoice: { tones: ['friendly'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters' }],
};

const facts: GenerateInput['business'] = {
  name: 'Acme Coffee',
  websiteUrl: SITE,
  industry: 'hospitality',
  city: 'Nagpur',
  country: 'IN',
  description: 'A speciality roastery and counter on MG Road.',
  telephone: '+91-712-000-0000',
  streetAddress: '12 MG Road',
  postalCode: '440001',
  region: 'MH',
  logoUrl: `${SITE}/logo.png`,
  sameAs: ['https://www.instagram.com/acmecoffee'],
  openingHours: 'Mo-Sa 07:00-21:00',
  productsServices: 'Speciality coffee',
};

let db: MemoryDatabase;
let tenant: TenantContext;
let projectId: string;
let service: SchemaServiceContext;

async function makeTenant(email: string): Promise<{ tenant: TenantContext; projectId: string }> {
  const signed = await signUp(
    { db, lockout: new MemoryLockoutStore(), secret: 'test-secret-value-at-least-32-bytes-long' },
    { email, password: PASSWORD },
  );
  if (!signed.ok || !signed.userId) throw new Error('signup failed');
  const memberships = await db.memberships.findForUser(signed.userId);
  const context: TenantContext = {
    userId: signed.userId,
    organizationId: memberships[0]!.organizationId,
    role: toRole(memberships[0]!.role),
  };
  const onboarded = await completeOnboarding({ db }, context, { business, profile });
  return { tenant: context, projectId: onboarded.project.id };
}

beforeEach(async () => {
  db = new MemoryDatabase();
  service = { db };
  const made = await makeTenant(`gen-${Math.random().toString(36).slice(2)}@example.com`);
  tenant = made.tenant;
  projectId = made.projectId;
});

/* -------------------------------------------------------------------------- */

describe('the generator never invents', () => {
  test('no generated document contains a rating, review, price or credential', () => {
    for (const kind of GENERATED_KINDS) {
      const generated = generateSchema({ kind, business: facts });
      for (const property of NEVER_INVENT_PROPERTIES) {
        assert.ok(
          !new RegExp(`"${property}"`).test(generated.jsonLd),
          `${kind} generated a "${property}"`,
        );
      }
    }
  });

  test('the refusals are reported, with a reason per property', () => {
    const generated = generateSchema({ kind: 'local_business', business: facts });
    assert.ok(generated.refused.length >= 8);
    for (const refusal of generated.refused) {
      assert.ok(refusal.why.length > 30, `${refusal.property} has no written reason`);
    }
    assert.ok(generated.refused.some((refusal) => refusal.property === 'aggregateRating'));
    assert.ok(generated.refused.some((refusal) => refusal.property === 'price'));
  });

  test('each refusal reason is specific to the property, not one blanket sentence', () => {
    const rating = refusalFor('aggregateRating');
    const price = refusalFor('price');
    const credential = refusalFor('hasCredential');
    assert.notEqual(rating, price);
    assert.notEqual(price, credential);
    assert.match(rating, /customers said/i);
    assert.match(price, /commercial commitment/i);
  });

  test('an unknown property still gets a refusal sentence rather than nothing', () => {
    assert.match(refusalFor('somethingElse'), /does not publish invented facts/i);
  });
});

describe('every value traces to a field', () => {
  test('included values name the field they came from', () => {
    const generated = generateSchema({ kind: 'organization', business: facts });
    assert.ok(generated.included.length > 0);
    for (const value of generated.included) {
      assert.ok(value.from.length > 0, `${value.property} does not say where it came from`);
      assert.ok(['user_provided', 'connected', 'retrieved'].includes(value.source));
    }
  });

  test('a missing field is reported as omitted, with what to do', () => {
    const generated = generateSchema({
      kind: 'organization',
      business: { name: 'Acme Coffee' },
    });
    assert.ok(generated.omitted.length > 0);
    for (const omission of generated.omitted) {
      assert.ok(omission.why.length > 10);
    }
    assert.ok(generated.omitted.some((omission) => omission.property === 'logo'));
  });

  test('an empty business produces a thin document, not an invented one', () => {
    const generated = generateSchema({ kind: 'organization', business: { name: 'X' } });
    const parsed = JSON.parse(generated.jsonLd) as Record<string, unknown>;
    assert.equal(parsed['name'], 'X');
    assert.equal(parsed['description'], undefined);
    assert.equal(parsed['logo'], undefined);
  });

  test('a FAQ with no real questions generates nothing and says why', () => {
    const generated = generateSchema({
      kind: 'faq',
      business: facts,
      page: { url: `${SITE}/faq`, title: 'FAQ' },
    });
    assert.ok(!generated.jsonLd.includes('mainEntity'));
    assert.ok(
      generated.omitted.some(
        (omission) => omission.property === 'mainEntity' && /invented/i.test(omission.why),
      ),
    );
  });

  test('a breadcrumb is only generated from a real trail', () => {
    const empty = generateSchema({
      kind: 'breadcrumb',
      business: facts,
      page: { url: `${SITE}/blog/post` },
    });
    assert.ok(!empty.jsonLd.includes('itemListElement'));

    const real = generateSchema({
      kind: 'breadcrumb',
      business: facts,
      page: {
        url: `${SITE}/blog/post`,
        breadcrumb: [
          { name: 'Home', url: `${SITE}/` },
          { name: 'Blog', url: `${SITE}/blog` },
          { name: 'This post' },
        ],
      },
    });
    assert.ok(real.jsonLd.includes('itemListElement'));
    // The final item legitimately omits its URL.
    const parsed = JSON.parse(real.jsonLd) as { itemListElement: { item?: string }[] };
    assert.equal(parsed.itemListElement[2]!.item, undefined);
  });
});

describe('the generator validates its own output', () => {
  test('every kind produces markup that passes our own validator', () => {
    for (const kind of GENERATED_KINDS) {
      const generated = generateSchema({
        kind,
        business: facts,
        page: {
          url: `${SITE}/about`,
          title: 'About Acme Coffee',
          metaDescription: 'A speciality roastery and counter on MG Road in Nagpur.',
          headline: 'About Acme Coffee',
          datePublished: '2026-03-14',
          dateModified: '2026-04-02',
          authorName: 'A. Mehta',
          imageUrl: `${SITE}/a.png`,
          inLanguage: 'en-IN',
          faqs: [{ question: 'Do you roast in house?', answer: 'Yes, every morning in small batches.' }],
          breadcrumb: [{ name: 'Home', url: `${SITE}/` }, { name: 'About' }],
        },
      });
      assert.equal(
        generated.validation.counts.INVALID,
        0,
        `${kind} generated markup our own validator rejects: ${JSON.stringify(
          generated.validation.issues.filter((issue) => issue.status === 'INVALID'),
          null,
          2,
        )}`,
      );
    }
  });

  test('an article graph includes the organization its publisher points at', () => {
    const generated = generateSchema({
      kind: 'article',
      business: facts,
      page: {
        url: `${SITE}/blog/roasting`,
        title: 'How we roast',
        headline: 'How we roast',
        metaDescription: 'Our roasting process, described.',
        datePublished: '2026-03-14',
        authorName: 'A. Mehta',
        imageUrl: `${SITE}/a.png`,
      },
    });
    // A publisher @id pointing at a node that is not in the graph is a dangling
    // reference, which is worse than no publisher at all.
    assert.ok(generated.jsonLd.includes('#organization'));
    assert.ok(generated.graph.some((node) => node['@type'] === 'Organization'));
  });
});

describe('the service stores and compares', () => {
  test('a validation run is stored with its validator version', async () => {
    const outcome = await validateForProject(service, tenant, {
      projectId,
      sourceKind: 'pasted',
      source: JSON.stringify({ '@context': 'https://schema.org', '@type': 'Organization', name: 'Acme' }),
    });
    assert.ok(outcome.stored);
    assert.equal(outcome.stored.validatorVersion, outcome.result.validatorVersion);
    assert.equal(outcome.stored.projectId, projectId);
  });

  test('`store: false` keeps nothing', async () => {
    await validateForProject(service, tenant, {
      projectId,
      sourceKind: 'pasted',
      source: JSON.stringify({ '@context': 'https://schema.org', '@type': 'Organization', name: 'Acme' }),
      store: false,
    });
    const history = await listValidationHistory(service, tenant, projectId);
    assert.deepEqual(history, []);
  });

  test('a second run of the same source is compared with the first', async () => {
    const broken = JSON.stringify({ '@context': 'https://schema.org', '@type': 'LocalBusiness', name: 'Acme' });
    const fixed = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'LocalBusiness',
      name: 'Acme',
      address: { '@type': 'PostalAddress', addressLocality: 'Nagpur', addressCountry: 'IN' },
    });

    await validateForProject(service, tenant, { projectId, sourceKind: 'pasted', source: broken });
    const second = await validateForProject(service, tenant, {
      projectId,
      sourceKind: 'pasted',
      source: fixed,
    });

    assert.ok(second.comparison);
    assert.ok(second.comparison.fixed.some((issue) => issue.property === 'address'));
  });

  test('two stored runs can be compared by id', async () => {
    const first = await validateForProject(service, tenant, {
      projectId,
      sourceKind: 'pasted',
      source: JSON.stringify({ '@context': 'https://schema.org', '@type': 'LocalBusiness', name: 'A' }),
    });
    const second = await validateForProject(service, tenant, {
      projectId,
      sourceKind: 'pasted',
      source: JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'LocalBusiness',
        name: 'A',
        address: { '@type': 'PostalAddress', addressLocality: 'Nagpur', addressCountry: 'IN' },
      }),
    });

    const comparison = await compareStoredValidations(
      service,
      tenant,
      first.stored!.id,
      second.stored!.id,
    );
    assert.match(comparison.summary, /resolved|new|no change/);
  });

  test('the validation endpoint fetches nothing', async () => {
    // A page-URL run reads the copy the crawler already took under the project's
    // own consent. Fetching an arbitrary URL from a validation endpoint would
    // reintroduce the crawler's threat model in a quieter place.
    await assert.rejects(
      () =>
        validateForProject(service, tenant, {
          projectId,
          sourceKind: 'page_url',
          url: 'https://example.com/anything',
        }),
      (error: unknown) => error instanceof ValidationInputError && /No crawl has run/i.test(error.message),
    );
  });

  test('an oversized document is refused before it is parsed', async () => {
    await assert.rejects(
      () =>
        validateForProject(service, tenant, {
          projectId,
          sourceKind: 'pasted',
          source: 'x'.repeat(300_000),
        }),
      (error: unknown) => error instanceof ValidationInputError && /byte limit/i.test(error.message),
    );
  });

  test('history is tenant-scoped, so another organization sees nothing', async () => {
    await validateForProject(service, tenant, {
      projectId,
      sourceKind: 'pasted',
      source: JSON.stringify({ '@context': 'https://schema.org', '@type': 'Organization', name: 'Acme' }),
    });
    const other = await makeTenant('other-schema@example.com');
    const theirs = await listValidationHistory(service, other.tenant, other.projectId);
    assert.deepEqual(theirs, []);
  });

  test('a project in another organization is a 404', async () => {
    const other = await makeTenant('cross-schema@example.com');
    await assert.rejects(
      () =>
        validateForProject(service, other.tenant, {
          projectId,
          sourceKind: 'pasted',
          source: '{}',
        }),
      (error: unknown) => error instanceof NotFoundError,
    );
  });

  test('generation reads the project\'s own business record', async () => {
    const generated = await generateForProject(service, tenant, {
      projectId,
      kind: 'local_business',
    });
    assert.ok(generated.jsonLd.includes('Acme Coffee'));
    assert.ok(generated.included.some((value) => value.property === 'name'));
  });

  test('generating page markup requires a crawled page, and says so', async () => {
    await grantCrawlConsent({ db }, tenant, projectId, {
      websiteUrl: SITE,
      consentVersion: CRAWL_CONSENT_VERSION,
      maxPages: 10,
      respectRobots: true,
      retentionDays: 30,
    });
    await assert.rejects(
      () =>
        generateForProject(service, tenant, {
          projectId,
          kind: 'article',
          pageUrl: `${SITE}/blog/post`,
        }),
      (error: unknown) =>
        error instanceof ValidationInputError && /not in the most recent crawl/i.test(error.message),
    );
  });
});
