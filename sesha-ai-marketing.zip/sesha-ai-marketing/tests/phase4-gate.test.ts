import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { signUp, toRole } from '../src/lib/auth/service';
import { completeOnboarding, grantCrawlConsent } from '../src/lib/workspace/service';
import { CRAWL_CONSENT_VERSION } from '../src/lib/validation/onboarding';
import type { TenantContext } from '../src/lib/tenant';
import {
  DEFAULT_LIMITS,
  MAX_ALLOWED_PAGES,
  USER_AGENT,
  blockedRangeLabels,
  checkUrl,
  isAllowedAddress,
  limitsForPlan,
  parseRobots,
  parseSitemap,
  resolveHost,
  safeFetch,
  type LookupFn,
  type Transport,
} from '../src/lib/crawler';
import { JOB_STATUSES, canTransition, isRetryable } from '../src/lib/jobs/types';
import {
  cancelJob,
  deleteExpiredCrawlData,
  getLatestAudit,
  listKeywords,
  requestJob,
  retryJob,
  runJob,
  toJobView,
  type CrawlServiceContext,
} from '../src/lib/crawl/service';
import { lintFinding, type Finding } from '../src/lib/audit/finding';

/**
 * The Phase 4 quality gate, executed.
 *
 * Sixteen boxes, one describe block each, named after the brief's line. A
 * checklist someone ticks by hand is a claim; this file makes each line fail
 * loudly if the behaviour regresses.
 */

const PASSWORD = 'a genuinely long passphrase 2026';
const SITE = 'https://acme-coffee.example.com';
const lookup: LookupFn = async () => [{ address: '93.184.216.34', family: 4 }];

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of readdirSync(dir)) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) walk(full, out);
    else if (/\.(ts|tsx)$/.test(entry)) out.push(full);
  }
  return out;
}

/* -------------------------------------------------------------------------- */
/* Fixtures                                                                   */
/* -------------------------------------------------------------------------- */

function pageHtml(title: string, links: string[] = []): string {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>${title}</title>
    <meta name="description" content="A description of ${title} long enough to satisfy the audit threshold.">
    <link rel="canonical" href="${SITE}/">
    </head><body><h1>${title}</h1><h2>How do we roast our coffee?</h2>
    <p>${'We roast in small batches every morning. '.repeat(15)}</p>
    ${links.map((href) => `<a href="${href}">${href}</a>`).join('')}
    </body></html>`;
}

const site: Record<string, { status: number; body?: string }> = {
  [`${SITE}/robots.txt`]: { status: 404 },
  [`${SITE}/`]: { status: 200, body: pageHtml('Acme Coffee', ['/about']) },
  [`${SITE}/about`]: { status: 200, body: pageHtml('About us') },
};

let db: MemoryDatabase;
let tenant: TenantContext;
let projectId: string;
let service: CrawlServiceContext;
let fetched: string[];

function makeService(pages = site): CrawlServiceContext {
  fetched = [];
  const transport: Transport = async (request) => {
    fetched.push(request.url);
    const scripted = pages[request.url];
    const body = scripted?.body ?? '';
    return {
      status: scripted?.status ?? 404,
      headers: { 'content-type': 'text/html' },
      body,
      bytes: Buffer.byteLength(body),
      truncated: false,
    };
  };
  return { db, fetchOptions: { transport, lookup }, sleep: async () => {} };
}

async function setup() {
  db = new MemoryDatabase();
  const signed = await signUp(
    { db, lockout: new MemoryLockoutStore(), secret: 'test-secret-value-at-least-32-bytes-long' },
    { email: 'owner@example.com', password: PASSWORD },
  );
  if (!signed.ok || !signed.userId) throw new Error('signup failed');

  const memberships = await db.memberships.findForUser(signed.userId);
  tenant = {
    userId: signed.userId,
    organizationId: memberships[0]!.organizationId,
    role: toRole(memberships[0]!.role),
  };
  await db.subscriptions.update(tenant.organizationId, { plan: 'agency' });

  const onboarded = await completeOnboarding({ db }, tenant, {
    business: {
      name: 'Acme Coffee',
      industry: 'hospitality',
      country: 'India',
      city: 'Nagpur',
      websiteUrl: SITE,
    },
    profile: {
      targetAudience: 'Office workers within walking distance who buy coffee daily.',
      productsServices: 'Speciality coffee, pastries and a small lunch menu.',
      priceRange: 'mid_market',
      marketingGoals: ['foot-traffic'],
      marketingChannels: ['organic-search'],
      brandVoice: { tones: ['friendly'], notes: 'Warm, never salesy.' },
      competitors: [{ name: 'Rival Roasters' }],
    },
  });
  projectId = onboarded.project.id;
  service = makeService();
}

async function grant(maxPages = 25) {
  return grantCrawlConsent({ db }, tenant, projectId, {
    websiteUrl: SITE,
    consentVersion: CRAWL_CONSENT_VERSION,
    maxPages,
    respectRobots: true,
    retentionDays: 30,
  });
}

async function workOne(context = service) {
  const claimed = await db.jobs.claimNext(new Date());
  if (!claimed) throw new Error('nothing queued');
  return runJob(context, claimed);
}

beforeEach(setup);

/* -------------------------------------------------------------------------- */

describe('gate: URL validation', () => {
  test('only http and https are accepted', () => {
    assert.equal(checkUrl('https://example.com/').ok, true);
    assert.equal(checkUrl('http://example.com/').ok, true);
    for (const bad of ['file:///etc/passwd', 'gopher://x/', 'data:text/html,x', 'javascript:1']) {
      assert.equal(checkUrl(bad).ok, false, `accepted ${bad}`);
    }
  });

  test('credentials, control characters and odd ports are refused', () => {
    assert.equal(checkUrl('https://a:b@example.com/').ok, false);
    assert.equal(checkUrl('http://example.com/\r\nX: y').ok, false);
    assert.equal(checkUrl('http://example.com:6379/').ok, false);
  });

  test('a reserved or single-label hostname is refused', () => {
    for (const bad of ['http://intranet/', 'https://a.internal/', 'https://b.test/']) {
      assert.equal(checkUrl(bad).ok, false, `accepted ${bad}`);
    }
  });
});

describe('gate: SSRF protection', () => {
  test('a name that RESOLVES privately never reaches a socket', async () => {
    let opened = 0;
    const result = await safeFetch('https://rebind.example.com/', {
      transport: async () => {
        opened += 1;
        return { status: 200, headers: {}, body: '', bytes: 0, truncated: false };
      },
      lookup: async () => [{ address: '127.0.0.1', family: 4 }],
    });

    assert.equal(result.ok, false);
    assert.equal(opened, 0, 'a socket was opened to a private address');
  });

  test('the socket is pinned to the CHECKED address, not the hostname', async () => {
    let pinned = '';
    await safeFetch('https://example.com/', {
      transport: async (request) => {
        pinned = request.address;
        return { status: 200, headers: { 'content-type': 'text/html' }, body: 'ok', bytes: 2, truncated: false };
      },
      lookup,
    });
    assert.equal(pinned, '93.184.216.34');
  });

  test('every redirect hop is re-validated', async () => {
    const result = await safeFetch('https://example.com/', {
      transport: async (request) => {
        const headers: Record<string, string> =
          request.url === 'https://example.com/'
            ? { location: 'http://169.254.169.254/' }
            : { 'content-type': 'text/html' };
        const body = request.url === 'https://example.com/' ? '' : 'leaked';
        return {
          status: request.url === 'https://example.com/' ? 302 : 200,
          headers,
          body,
          bytes: Buffer.byteLength(body),
          truncated: false,
        };
      },
      lookup,
    });
    assert.equal(result.ok, false);
  });
});

describe('gate: private IP blocking', () => {
  test('every private and reserved range is refused', () => {
    const blocked = [
      '10.0.0.1', '172.16.0.1', '192.168.1.1', '169.254.169.254', '100.64.0.1',
      '0.0.0.0', '224.0.0.1', '255.255.255.255', '::1', 'fc00::1', 'fe80::1',
      '::ffff:127.0.0.1', '64:ff9b::7f00:1',
    ];
    for (const address of blocked) {
      assert.equal(isAllowedAddress(address), false, `ALLOWED ${address}`);
    }
  });

  test('public addresses are still allowed', () => {
    assert.equal(isAllowedAddress('93.184.216.34'), true);
    assert.equal(isAllowedAddress('2606:2800:220:1:248:1893:25c8:1946'), true);
  });

  test('the blocklist is documented for the interface', () => {
    assert.ok(blockedRangeLabels().length >= 10);
  });
});

describe('gate: robots handling', () => {
  test('a disallowed path is never fetched', async () => {
    await grant();
    const withRobots = makeService({
      ...site,
      [`${SITE}/robots.txt`]: { status: 200, body: 'User-agent: *\nDisallow: /about' },
      [`${SITE}/about`]: { status: 200, body: pageHtml('About') },
    });
    await requestJob(withRobots, tenant, { projectId, kind: 'crawl' });
    await workOne(withRobots);

    assert.ok(!fetched.includes(`${SITE}/about`), 'fetched a disallowed path');
  });

  test('an unreadable robots.txt STOPS the crawl — fail closed', async () => {
    await grant();
    const broken = makeService({ [`${SITE}/robots.txt`]: { status: 500 } });
    await requestJob(broken, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne(broken);

    assert.equal(outcome.job.status, 'failed');
    assert.equal(outcome.job.failureCode, 'robots_unavailable');
    assert.ok(!fetched.includes(`${SITE}/`), 'crawled despite an unreadable robots.txt');
  });

  test('the crawler identifies itself with a contactable user agent', () => {
    assert.match(USER_AGENT, /SeShaBot/);
    assert.match(USER_AGENT, /https?:\/\//);
  });

  test("the site's Crawl-delay is honoured", () => {
    const robots = parseRobots('User-agent: *\nCrawl-delay: 4');
    assert.equal(robots.groups[0]?.crawlDelaySeconds, 4);
  });
});

describe('gate: sitemap handling', () => {
  test('sitemap URLs are crawled even with nothing linking to them', async () => {
    await grant();
    const withSitemap = makeService({
      [`${SITE}/robots.txt`]: { status: 200, body: `Sitemap: ${SITE}/sitemap.xml` },
      [`${SITE}/sitemap.xml`]: {
        status: 200,
        body: `<urlset><url><loc>${SITE}/orphan</loc></url></urlset>`,
      },
      [`${SITE}/`]: { status: 200, body: pageHtml('Home') },
      [`${SITE}/orphan`]: { status: 200, body: pageHtml('Orphan') },
    });
    await requestJob(withSitemap, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne(withSitemap);

    assert.ok(outcome.crawl?.sitemapFound);
    assert.ok(fetched.includes(`${SITE}/orphan`));
  });

  test('an XXE or entity-expansion payload is refused', () => {
    const bomb = `<!DOCTYPE x [<!ENTITY a "b">]><urlset><url><loc>${SITE}/x</loc></url></urlset>`;
    assert.equal(parseSitemap(bomb, `${SITE}/sitemap.xml`).entries.length, 0);
  });

  test('a cross-site sitemap entry is rejected', () => {
    const parsed = parseSitemap(
      `<urlset><url><loc>${SITE}/mine</loc></url><url><loc>https://evil.example.net/x</loc></url></urlset>`,
      `${SITE}/sitemap.xml`,
    );
    assert.equal(parsed.entries.length, 1);
  });
});

describe('gate: crawl limits', () => {
  test('the grant narrows the plan, and the plan caps the request', async () => {
    await grant(2);
    await requestJob(service, tenant, { projectId, kind: 'crawl', maxPages: 9_999 });
    const outcome = await workOne();

    assert.equal(outcome.crawl?.maxPages, 2);
    assert.ok((outcome.crawl?.pagesCrawled ?? 0) <= 2);
  });

  test('no plan exceeds the absolute cap', () => {
    for (const plan of ['free', 'pro', 'business', 'agency'] as const) {
      assert.ok(limitsForPlan(plan).maxPages <= MAX_ALLOWED_PAGES);
    }
  });

  test('the defaults are polite', () => {
    assert.ok(DEFAULT_LIMITS.concurrency <= 3);
    assert.ok(DEFAULT_LIMITS.delayMs >= 250);
  });
});

describe('gate: timeouts', () => {
  test('a request timeout becomes a timeout outcome, not a hang', async () => {
    const result = await safeFetch('https://example.com/', {
      transport: async () => {
        const error = new Error('slow');
        (error as { code?: string }).code = 'ETIMEDOUT';
        throw error;
      },
      lookup,
    });
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.code, 'timeout');
  });

  test('a DNS timeout is reported, not treated as permission', async () => {
    const verdict = await resolveHost('slow.example.com', {
      lookup: () => new Promise(() => {}),
      timeoutMs: 20,
    });
    assert.equal(verdict.ok, false);
  });

  test('a crawl has a whole-run time ceiling', () => {
    assert.ok(DEFAULT_LIMITS.totalTimeoutMs > 0);
    assert.ok(DEFAULT_LIMITS.timeoutMsPerPage > 0);
  });
});

describe('gate: response limits', () => {
  test('the byte cap reaches the transport', async () => {
    let cap = 0;
    await safeFetch('https://example.com/', {
      transport: async (request) => {
        cap = request.maxBytes;
        return { status: 200, headers: { 'content-type': 'text/html' }, body: 'ok', bytes: 2, truncated: false };
      },
      lookup,
      maxBytes: 4_096,
    });
    assert.equal(cap, 4_096);
  });

  test('an oversized response is refused', async () => {
    const result = await safeFetch('https://example.com/', {
      transport: async () => {
        const error = new Error('too big');
        (error as { code?: string }).code = 'ERR_TOO_LARGE';
        throw error;
      },
      lookup,
    });
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.code, 'too_large');
  });

  test('a binary content type is not stored as page text', async () => {
    const result = await safeFetch('https://example.com/x', {
      transport: async () => ({
        status: 200,
        headers: { 'content-type': 'application/pdf' },
        body: '%PDF',
        bytes: 4,
        truncated: false,
      }),
      lookup,
    });
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.code, 'unsupported_type');
  });
});

describe('gate: crawl queue', () => {
  test('each page is fetched once, however many ways it is linked', async () => {
    await grant();
    const looping = makeService({
      [`${SITE}/robots.txt`]: { status: 404 },
      [`${SITE}/`]: { status: 200, body: pageHtml('Home', ['/a', '/a/', '/a#x', '/a?utm_source=y']) },
      [`${SITE}/a`]: { status: 200, body: pageHtml('A', ['/']) },
    });
    await requestJob(looping, tenant, { projectId, kind: 'crawl' });
    await workOne(looping);

    const pageFetches = fetched.filter((url) => url === `${SITE}/a`);
    assert.equal(pageFetches.length, 1, `fetched /a ${pageFetches.length} times`);
  });

  test('the crawl records what it skipped and why', async () => {
    await grant(1);
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();

    assert.ok(outcome.crawl);
    assert.ok(outcome.crawl!.stoppedEarly, 'a truncated crawl must say so');
  });
});

describe('gate: SEO audit', () => {
  test('findings are produced with evidence', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();
    await requestJob(service, tenant, { projectId, kind: 'seo_audit' });
    const outcome = await workOne();

    const audit = outcome.audit!;
    assert.ok(audit.findings.length > 0);
    for (const finding of audit.findings as Finding[]) {
      assert.ok(finding.evidence.observation.length > 0, `${finding.id} has no evidence`);
      assert.ok(finding.recommendation.length > 0);
      assert.ok(finding.expectedBenefit.length > 0);
      assert.ok(finding.confidence);
      assert.ok(finding.dataBasis);
    }
  });

  test('the audit reads the stored crawl and fetches nothing', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();

    const before = fetched.length;
    await requestJob(service, tenant, { projectId, kind: 'seo_audit' });
    await workOne();
    assert.equal(fetched.length, before);
  });
});

describe('gate: AEO audit', () => {
  test('it runs and carries its disclaimer', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();
    await requestJob(service, tenant, { projectId, kind: 'aeo_audit' });
    await workOne();

    const audit = await getLatestAudit(service, tenant, projectId, 'aeo');
    assert.ok(audit);
    assert.ok(audit.notChecked.length > 0);
    const serialized = JSON.stringify(audit.notChecked);
    assert.match(serialized, /cite/i, 'the AEO audit must say citation is unmeasurable');
  });
});

describe('gate: provenance', () => {
  test('every finding names where its facts came from', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();
    for (const kind of ['seo_audit', 'aeo_audit'] as const) {
      await requestJob(service, tenant, { projectId, kind });
      const outcome = await workOne();
      for (const finding of outcome.audit!.findings as Finding[]) {
        assert.ok(
          ['crawled_page', 'crawl_summary', 'robots_txt', 'sitemap', 'structured_data', 'user_provided', 'heuristic', 'unavailable']
            .includes(finding.dataBasis),
          `${finding.id} has an unknown data basis`,
        );
      }
    }
  });

  test('a heuristic finding is never presented as high confidence', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();
    await requestJob(service, tenant, { projectId, kind: 'aeo_audit' });
    const outcome = await workOne();

    for (const finding of outcome.audit!.findings as Finding[]) {
      if (finding.dataBasis === 'heuristic') {
        assert.notEqual(finding.confidence, 'high', `${finding.id} claims to have measured a rule`);
      }
    }
  });

  test('the score is stored with its basis', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();
    await requestJob(service, tenant, { projectId, kind: 'seo_audit' });
    const outcome = await workOne();
    assert.match(outcome.audit!.scoreBasis, /own weighting/i);
  });
});

describe('gate: no fabricated metrics', () => {
  test('NO finding promises ranking, citation, visibility or traffic', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();

    for (const kind of ['seo_audit', 'aeo_audit'] as const) {
      await requestJob(service, tenant, { projectId, kind });
      const outcome = await workOne();
      for (const finding of outcome.audit!.findings as Finding[]) {
        assert.deepEqual(
          lintFinding(finding),
          [],
          `${finding.id} makes a forbidden promise: ${finding.expectedBenefit}`,
        );
      }
      assert.deepEqual(outcome.audit!.suppressed, [], 'a finding was withheld by the linter');
    }
  });

  test('EVERY stored keyword says volume is unavailable', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();

    const keywords = await listKeywords(service, tenant, projectId);
    assert.ok(keywords.length > 0);
    for (const keyword of keywords) {
      assert.equal((keyword.volume as { kind?: string }).kind, 'unavailable');
      assert.equal((keyword.competition as { kind?: string }).kind, 'unavailable');
    }
  });

  test('the keywords table has NO numeric volume column at all', () => {
    // Structural: a nullable number column invites a future writer to fill it
    // with an estimate that then reads as a measurement.
    const migration = readFileSync(path.join(root, 'db', 'migrations', '0004_crawl_audit.sql'), 'utf8');
    const keywordsBlock = /CREATE TABLE IF NOT EXISTS keywords \(([\s\S]*?)\n\);/.exec(migration)?.[1] ?? '';
    assert.ok(keywordsBlock.length > 0, 'the keywords table was not found in the migration');
    assert.ok(
      !/\b(search_volume|monthly_searches|volume)\s+(integer|numeric|bigint)/i.test(keywordsBlock),
      'the keywords table has a numeric volume column',
    );
    assert.ok(/volume\s+jsonb/i.test(keywordsBlock), 'volume must be the provenance union');
  });

  test('a volume figure can only be printed ALONGSIDE its source', () => {
    // The product has one place that formats a volume for display. A figure may
    // appear there only in the `measured` branch, which the type system forces to
    // carry a source and an as-of date. Any other file printing a searches-per-
    // month figure would be inventing one.
    const offenders: string[] = [];

    for (const file of walk(path.join(root, 'src'))) {
      // Comments explain the rule and are not output.
      const code = readFileSync(file, 'utf8')
        .replace(/\/\*[\s\S]*?\*\//g, ' ')
        .replace(/(^|[^:])\/\/[^\n]*/g, '$1');

      for (const match of code.matchAll(/[^\n]*(?:\/\s*month|searches|per month)[^\n]*/gi)) {
        const line = match[0];
        // A template that interpolates a monthly figure must also interpolate
        // the source it came from, on the same line.
        if (/\$\{[^}]*monthly[^}]*\}/.test(line) && !/\$\{[^}]*source[^}]*\}/.test(line)) {
          offenders.push(`${path.relative(root, file)}: ${line.trim().slice(0, 100)}`);
        }
        // A literal digit-led figure is never acceptable.
        if (/\b\d[\d,.]*\s*(?:searches|\/\s*month|per month)/i.test(line)) {
          offenders.push(`${path.relative(root, file)}: ${line.trim().slice(0, 100)}`);
        }
      }
    }
    assert.deepEqual(offenders, []);
  });

  test('the measured variant REQUIRES a source and a date to exist at all', () => {
    // Structural: there is no way to construct a volume with a number but no
    // source, because the union has no such variant.
    const types = readFileSync(path.join(root, 'src', 'lib', 'keywords', 'types.ts'), 'utf8');
    // To the next top-level declaration, not to the first semicolon: the union's
    // own members end in semicolons, so a lazy match stops inside it.
    const union = /export type SearchVolume =([\s\S]*?)\n(?=export |\/\*)/.exec(types)?.[1] ?? '';

    assert.ok(union.length > 0, 'the SearchVolume union was not found');
    assert.ok(/kind: 'measured'/.test(union));
    // Every occurrence of `monthly` in the union sits in a variant that also
    // names a source and an asOf.
    const measured = /kind: 'measured';[\s\S]*?\n\s*\}/.exec(union)?.[0] ?? '';
    assert.match(measured, /monthly: number/);
    assert.match(measured, /source: string/);
    assert.match(measured, /asOf: string/);
    // And there is no bare-number variant.
    assert.ok(
      !/kind: '(?:estimate|unavailable)'[^}]*monthly/.test(union),
      'an estimate or unavailable variant carries a bare number',
    );
  });
});

describe('gate: background jobs', () => {
  test('the five states exist and terminal states are final', () => {
    assert.deepEqual([...JOB_STATUSES], ['queued', 'running', 'completed', 'failed', 'cancelled']);
    for (const terminal of ['completed', 'failed', 'cancelled'] as const) {
      for (const target of JOB_STATUSES) {
        assert.equal(canTransition(terminal, target), false);
      }
    }
  });

  test('progress is written while the job runs', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await workOne();
    const job = (await db.jobs.listForProject(tenant.organizationId, projectId))[0]!;
    assert.ok(job.progressDone > 0);
  });

  test('a queued job can be cancelled and is never claimed', async () => {
    await grant();
    const job = await requestJob(service, tenant, { projectId, kind: 'crawl' });
    await cancelJob(service, tenant, job.id);
    assert.equal(await db.jobs.claimNext(new Date()), null);
  });

  test('a retryable failure can be retried; a permanent one cannot', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const transient = await workOne(makeService({ [`${SITE}/robots.txt`]: { status: 500 } }));
    assert.equal(toJobView(transient.job).canRetry, true);
    await retryJob(service, tenant, transient.job.id);

    assert.equal(isRetryable('blocked'), false);
    assert.equal(isRetryable('invalid_url'), false);
  });
});

describe('gate: error handling', () => {
  test('a 404 on one page does not fail the crawl', async () => {
    await grant();
    const partial = makeService({
      [`${SITE}/robots.txt`]: { status: 404 },
      [`${SITE}/`]: { status: 200, body: pageHtml('Home', ['/gone', '/ok']) },
      [`${SITE}/ok`]: { status: 200, body: pageHtml('OK') },
      [`${SITE}/gone`]: { status: 404 },
    });
    await requestJob(partial, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne(partial);

    assert.equal(outcome.job.status, 'completed');
    assert.equal(outcome.crawl?.pagesFailed, 1);
  });

  test('a failure message never leaks an internal address or code', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne(makeService({ [`${SITE}/robots.txt`]: { status: 500 } }));

    const view = toJobView(outcome.job);
    assert.ok(view.failure);
    assert.ok(!view.failure.includes('_'), 'the raw failure code reached the interface');
  });

  test('a site that answers nothing fails with a clear reason', async () => {
    await grant();
    const dead = makeService({ [`${SITE}/robots.txt`]: { status: 404 } });
    await requestJob(dead, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne(dead);

    assert.equal(outcome.job.status, 'failed');
    assert.equal(outcome.job.failureCode, 'nothing_crawled');
  });
});

describe('gate: security tests', () => {
  test('the crawler is only reachable through safeFetch', () => {
    // Nothing outside the crawler may call node:http or node:https directly:
    // that is the path that bypasses every policy check.
    const offenders: string[] = [];
    for (const file of walk(path.join(root, 'src'))) {
      const relative = path.relative(root, file);
      if (relative.includes(path.join('lib', 'crawler'))) continue;
      const contents = readFileSync(file, 'utf8');
      if (/from\s+['"]node:https?['"]/.test(contents)) offenders.push(relative);
    }
    assert.deepEqual(offenders, [], 'a module outside the crawler opens raw HTTP connections');
  });

  test('no module outside the crawler resolves DNS', () => {
    const offenders: string[] = [];
    for (const file of walk(path.join(root, 'src'))) {
      const relative = path.relative(root, file);
      if (relative.includes(path.join('lib', 'crawler'))) continue;
      const contents = readFileSync(file, 'utf8');
      if (/from\s+['"]node:dns['"]/.test(contents)) offenders.push(relative);
    }
    assert.deepEqual(offenders, []);
  });

  test('no client component imports the crawler', () => {
    // A client component importing it would ship the policy to the browser,
    // where it is advisory rather than enforced.
    const offenders: string[] = [];
    for (const file of walk(path.join(root, 'src'))) {
      const contents = readFileSync(file, 'utf8');
      if (!/^['"]use client['"]/m.test(contents)) continue;
      for (const match of contents.matchAll(/^import\s+(?!type\s)([\s\S]*?)from\s+['"]([^'"]+)['"]/gm)) {
        const specifier = match[2] ?? '';
        const clause = match[1] ?? '';
        // A value import of the crawler, excluding type-only named imports.
        if (/@\/lib\/crawler/.test(specifier) && !/^\s*\{\s*(type\s)/.test(clause)) {
          offenders.push(`${path.relative(root, file)} -> ${specifier}`);
        }
      }
    }
    assert.deepEqual(offenders, []);
  });

  test('the crawl consent table is referenced with RESTRICT, not CASCADE', () => {
    // A consent record is the authorisation for the crawls performed under it,
    // so it must not be deletable while those crawls exist.
    const migration = readFileSync(path.join(root, 'db', 'migrations', '0004_crawl_audit.sql'), 'utf8');
    assert.match(migration, /consent_id[^\n]*REFERENCES website_crawl_consents\(id\) ON DELETE RESTRICT/);
  });

  test('every new table has row-level security enabled', () => {
    const migration = readFileSync(path.join(root, 'db', 'migrations', '0004_crawl_audit.sql'), 'utf8');
    for (const table of ['jobs', 'crawls', 'crawled_pages', 'audits', 'keywords']) {
      assert.match(
        migration,
        new RegExp(`ALTER TABLE ${table}\\s+ENABLE ROW LEVEL SECURITY`),
        `${table} has no row-level security`,
      );
    }
  });

  test('the raw HTML of a crawled page is NOT stored', async () => {
    // Keeping a copy of someone's whole site is a liability with no matching
    // benefit: the audit needs the extracted fields, not the markup.
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();

    const pages = await db.crawls.listPages(tenant.organizationId, outcome.crawl!.id);
    for (const page of pages) {
      assert.ok(!page.textContent.includes('<html'), 'raw markup was stored');
      assert.ok(!page.textContent.includes('<script'), 'script markup was stored');
      assert.ok(!('html' in page), 'a raw HTML column exists on a crawled page');
    }
  });

  test('page content is deleted when its retention period lapses', async () => {
    await grant();
    await requestJob(service, tenant, { projectId, kind: 'crawl' });
    const outcome = await workOne();

    const later = Date.now() + 400 * 24 * 60 * 60 * 1000;
    await deleteExpiredCrawlData({ db, now: () => later });
    assert.deepEqual(await db.crawls.listPages(tenant.organizationId, outcome.crawl!.id), []);
  });
});

describe('gate: no delivered phase is still advertised as upcoming', () => {
  /**
   * Phases 1 to 9 have shipped. Anything still described as arriving "in Phase
   * 7" is now a false promise in the product — it says a feature is coming in a
   * phase that has already been delivered without it. This test exists because
   * exactly that happened at the end of Phase 4: six "Soon" screens, six
   * navigation notes and three agent definitions all still pointed at Phase 4.
   *
   * The rule is mechanical: a planned thing must name a phase later than the
   * last delivered one. Bump DELIVERED when a phase ships.
   */
  const DELIVERED = 9;

  function phaseNumbers(text: string): number[] {
    return [...text.matchAll(/Phase (\d+)/g)].map((match) => Number(match[1]));
  }

  test('no planned agent points at a phase that has already shipped', async () => {
    const { plannedAgents } = await import('../src/lib/ai/agents');
    const planned = plannedAgents();
    assert.ok(planned.length > 0, 'no planned agents were found, so this test proves nothing');
    for (const agent of planned) {
      const phase = agent.phase ?? '';
      for (const number of phaseNumbers(phase)) {
        assert.ok(
          number > DELIVERED,
          `${agent.id} is planned but says it arrives in ${phase}, which has shipped`,
        );
      }
    }
  });

  test('no available agent is described as not implemented', async () => {
    const { availableAgents } = await import('../src/lib/ai/agents');
    const available = availableAgents();
    assert.ok(available.length > 0, 'no available agents were found, so this test proves nothing');
    for (const agent of available) {
      assert.ok(
        !/not implemented/i.test(agent.instructions),
        `${agent.id} is offered as available but its instructions say it is not implemented`,
      );
    }
  });

  test('no navigation note promises a phase that has already shipped', async () => {
    const nav = await import('../src/content/app-nav');
    for (const item of [...nav.appPrimaryNav, ...nav.appMoreNav]) {
      for (const number of phaseNumbers(item.note ?? '')) {
        assert.ok(
          number > DELIVERED,
          `the "${item.label}" note promises Phase ${number}, which has shipped`,
        );
      }
    }
  });

  test('no "Soon" screen promises a phase that has already shipped', () => {
    const offenders: string[] = [];
    for (const file of walk(path.join(root, 'src', 'app'))) {
      const contents = readFileSync(file, 'utf8');
      for (const match of contents.matchAll(/phase="Phase (\d+)"/g)) {
        if (Number(match[1]) <= DELIVERED) offenders.push(`${path.relative(root, file)}: ${match[0]}`);
      }
    }
    assert.deepEqual(offenders, [], 'a coming-soon screen names an already delivered phase');
  });

  test('the navigation reports the SEO/AEO and Website Audit screens as available', async () => {
    const nav = await import('../src/content/app-nav');
    const items = [...nav.appPrimaryNav, ...nav.appMoreNav];
    for (const href of ['/app/seo-aeo', '/app/website-audit']) {
      const item = items.find((candidate) => candidate.href === href);
      assert.ok(item, `${href} is missing from the navigation`);
      assert.equal(item.status, 'available', `${href} shipped in Phase 4 but is still marked planned`);
    }
  });
});
