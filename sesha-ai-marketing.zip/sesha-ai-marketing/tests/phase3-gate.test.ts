import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { signUp, toRole } from '../src/lib/auth/service';
import { completeOnboarding } from '../src/lib/workspace/service';
import type { TenantContext } from '../src/lib/tenant';
import { AIOrchestrator } from '../src/lib/ai/orchestrator';
import { AiCache, AiRateLimiter, quotaFor, selectModel } from '../src/lib/ai/cost';
import { allAgents, availableAgents, plannedAgents } from '../src/lib/ai/agents';
import {
  AiError,
  allProviders,
  publicStatus,
  type AIProvider,
  type CompletionRequest,
  type CompletionResult,
} from '../src/lib/ai/provider';
import { askCopilot, exportBlocks, refine, type AiServiceContext } from '../src/lib/ai/service';
import { generateContent } from '../src/lib/content/service';
import { generateStrategy } from '../src/lib/strategy/service';
import { DEFAULT_CONTROLS } from '../src/lib/content/types';
import { STRATEGY_SECTIONS } from '../src/lib/strategy/sections';
import { PLATFORMS } from '../src/lib/social/platforms';

/**
 * The Phase 3 quality gate, executed.
 *
 * The brief lists fifteen boxes to tick. A checklist someone ticks by hand is
 * a claim; this file turns each line into an assertion that fails loudly if the
 * behaviour regresses. One describe block per gate item, named after it.
 *
 * Where a gate item is covered in depth elsewhere (provenance parsing, cost
 * control, the provider adapters), this file asserts the END-TO-END behaviour
 * and leaves the unit detail to the dedicated suite.
 */

const PASSWORD = 'a genuinely long passphrase 2026';

const CLEAN = JSON.stringify({
  blocks: [
    { kind: 'user_provided', text: 'You sell speciality coffee in Nagpur.' },
    { kind: 'recommendation', text: 'Lead with the roasting process.' },
  ],
});

class FakeProvider implements AIProvider {
  readonly name = 'openai' as const;
  readonly models = [
    { id: 'fast-model', label: 'Fast', tier: 'fast' as const, contextTokens: 100_000, maxOutputTokens: 8_000 },
    { id: 'balanced-model', label: 'Balanced', tier: 'balanced' as const, contextTokens: 100_000, maxOutputTokens: 8_000 },
    { id: 'deep-model', label: 'Deep', tier: 'deep' as const, contextTokens: 200_000, maxOutputTokens: 16_000 },
  ];

  calls = 0;
  systemPrompts: string[] = [];
  userPrompts: string[] = [];
  script: (string | Error)[] = [];
  defaultText = CLEAN;

  isConfigured(): boolean {
    return true;
  }

  async complete(request: CompletionRequest, model: string): Promise<CompletionResult> {
    this.calls += 1;
    this.systemPrompts.push(request.system);
    this.userPrompts.push(request.messages.at(-1)?.content ?? '');
    const next = this.script.shift();
    if (next instanceof Error) throw next;
    return {
      text: next ?? this.defaultText,
      usage: { inputTokens: 100, outputTokens: 50 },
      model,
      provider: this.name,
      truncated: false,
    };
  }
}

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: 'https://acme-coffee.example',
};

const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic'] as const,
  marketingChannels: ['organic-search', 'social-organic'] as const,
  brandVoice: { tones: ['friendly', 'direct'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters' }],
};

let db: MemoryDatabase;
let provider: FakeProvider;
let tenant: TenantContext;
let projectId: string;
let service: AiServiceContext;

async function setup(plan: 'free' | 'pro' | 'business' | 'agency' = 'agency') {
  db = new MemoryDatabase();
  provider = new FakeProvider();

  const signed = await signUp(
    { db, lockout: new MemoryLockoutStore(), secret: 'test-secret-value-at-least-32-bytes-long' },
    { email: 'owner@example.com', password: PASSWORD },
  );
  if (!signed.ok || !signed.userId) throw new Error('signup failed');

  const memberships = await db.memberships.findForUser(signed.userId);
  tenant = {
    userId: signed.userId,
    organizationId: memberships[0]!.organizationId,
    role: toRole(memberships[0]!.role),
  };

  await db.subscriptions.update(tenant.organizationId, { plan });
  const onboarded = await completeOnboarding({ db }, tenant, { business, profile });
  projectId = onboarded.project.id;

  service = {
    db,
    orchestrator: new AIOrchestrator({
      db,
      provider,
      cache: new AiCache(),
      limiter: new AiRateLimiter(),
      sleep: async () => {},
    }),
  };
}

beforeEach(() => setup());

/* -------------------------------------------------------------------------- */

describe('gate: AI chat', () => {
  test('a question produces a labelled answer and a persisted conversation', async () => {
    const turn = await askCopilot(service, tenant, { prompt: 'What should I post?', projectId });

    assert.equal(turn.result.ok, true);
    if (!turn.result.ok) return;
    assert.ok(turn.result.response.blocks.length > 0);
    assert.ok(turn.assistantMessage);

    const messages = await db.aiConversations.listMessages(tenant.organizationId, turn.conversation.id);
    assert.equal(messages.length, 2);
  });
});

describe('gate: AI context', () => {
  test('the system prompt carries the business, audience, goals and channels', async () => {
    await askCopilot(service, tenant, { prompt: 'Anything.', projectId });
    const system = provider.systemPrompts[0] ?? '';

    assert.ok(system.includes('Acme Coffee'), 'the business name is missing');
    assert.ok(system.includes('Nagpur'), 'the city is missing');
    assert.ok(system.toLowerCase().includes('office workers'), 'the audience is missing');
    assert.ok(/foot traffic/i.test(system), 'the marketing goal is missing');
  });

  test('what is MISSING is stated explicitly, so gaps are not filled in', async () => {
    await askCopilot(service, tenant, { prompt: 'Anything.', projectId });
    const system = provider.systemPrompts[0] ?? '';

    assert.ok(system.includes('NOT AVAILABLE'), 'the prompt never names what is missing');
    assert.match(system, /do not invent/i);
  });

  test('competitors are named but explicitly not described', async () => {
    await askCopilot(service, tenant, { prompt: 'Anything.', projectId });
    const system = provider.systemPrompts[0] ?? '';

    assert.ok(system.includes('Rival Roasters'));
    assert.match(system, /know nothing about these companies beyond their names/i);
  });

  test('the summary shown to the user matches what the prompt contained', async () => {
    const turn = await askCopilot(service, tenant, { prompt: 'Anything.', projectId });
    assert.ok(turn.contextSummary.present.includes('Business details'));
    assert.ok(turn.contextSummary.present.includes('Target audience'));
  });
});

describe('gate: strategy', () => {
  test('all seventeen brief sections exist and are accounted for', async () => {
    assert.equal(STRATEGY_SECTIONS.length, 17);

    const outcome = await generateStrategy(service, tenant, { projectId });
    assert.equal(outcome.sections.length, 17);
    for (const id of STRATEGY_SECTIONS) {
      assert.ok(outcome.sections.some((section) => section.id === id), `missing section: ${id}`);
    }
  });

  test('SEO and AEO are the placeholders the brief calls for, not invented audits', async () => {
    const outcome = await generateStrategy(service, tenant, { projectId });
    for (const id of ['seo-strategy', 'aeo-strategy'] as const) {
      const section = outcome.sections.find((item) => item.id === id);
      assert.ok(section, `${id} section is missing`);
      assert.notEqual(section?.availability, 'full', `${id} claims to be complete without a crawl`);
      assert.ok(section?.note, `${id} does not say why it is limited`);
    }
  });
});

describe('gate: content generation', () => {
  test('a draft is produced, checked and saved', async () => {
    const outcome = await generateContent(service, tenant, {
      projectId,
      controls: { ...DEFAULT_CONTROLS, format: 'blog', topic: 'Our roasting process' },
    });

    assert.equal(outcome.ok, true);
    assert.ok(outcome.item);
    assert.ok((outcome.item?.body.length ?? 0) > 0);
  });

  test('the format brief reaches the model', async () => {
    await generateContent(service, tenant, {
      projectId,
      controls: { ...DEFAULT_CONTROLS, format: 'x-post', topic: 'A short thought' },
    });
    const prompt = provider.userPrompts[0] ?? '';
    assert.match(prompt, /FORMAT:/);
    assert.match(prompt, /A short thought/);
  });
});

describe('gate: brand voice', () => {
  test('the brand voice tones and notes reach the system prompt', async () => {
    await generateContent(service, tenant, {
      projectId,
      controls: { ...DEFAULT_CONTROLS, format: 'blog', topic: 'Our roasting process' },
    });
    const system = provider.systemPrompts[0] ?? '';

    assert.ok(system.includes('friendly'), 'a brand tone is missing');
    assert.ok(system.includes('Warm, never salesy.'), 'the brand voice note is missing');
  });
});

describe('gate: languages', () => {
  test('English, Hindi and Hinglish each produce a distinct instruction', async () => {
    const seen = new Set<string>();
    for (const language of ['en', 'hi', 'hinglish'] as const) {
      await setup();
      await generateContent(service, tenant, {
        projectId,
        controls: { ...DEFAULT_CONTROLS, language, format: 'blog', topic: 'Our roasting process' },
      });
      const prompt = provider.userPrompts[0] ?? '';
      assert.match(prompt, /LANGUAGE:/i, `${language} carries no language instruction`);
      seen.add(prompt.split('\n').find((line) => /^LANGUAGE:/i.test(line)) ?? language);
    }
    assert.equal(seen.size, 3, 'two languages produced the same instruction');
  });

  test('Hinglish asks for Roman script and forbids Devanagari', async () => {
    // Script is the whole distinction between Hinglish and Hindi.
    await generateContent(service, tenant, {
      projectId,
      controls: { ...DEFAULT_CONTROLS, language: 'hinglish', format: 'blog', topic: 'Coffee' },
    });
    const prompt = provider.userPrompts[0] ?? '';
    assert.match(prompt, /roman script/i);
    assert.match(prompt, /do not use devanagari/i);
  });

  test('Hindi asks for Devanagari', async () => {
    await generateContent(service, tenant, {
      projectId,
      controls: { ...DEFAULT_CONTROLS, language: 'hi', format: 'blog', topic: 'Coffee' },
    });
    assert.match(provider.userPrompts[0] ?? '', /devanagari/i);
  });
});

describe('gate: save content', () => {
  test('a generated item is retrievable afterwards, with its provenance intact', async () => {
    const outcome = await generateContent(service, tenant, {
      projectId,
      controls: { ...DEFAULT_CONTROLS, format: 'blog', topic: 'Our roasting process' },
    });

    const saved = await db.content.findById(tenant.organizationId, outcome.item!.id);
    assert.ok(saved);
    assert.ok((saved?.blocks.length ?? 0) > 0, 'the provenance blocks were not stored');
    assert.equal(saved?.generatedBy.provider, 'openai');
  });
});

describe('gate: regenerate', () => {
  test('regenerating bypasses the cache, so it actually calls the provider again', async () => {
    // Without bypassing, an identical request would be served from cache and
    // "regenerate" would return the same text — which is not regeneration.
    await refine(service, tenant, { refinement: 'shorten', text: 'Some copy to shorten.', projectId });
    const afterFirst = provider.calls;
    await refine(service, tenant, { refinement: 'shorten', text: 'Some copy to shorten.', projectId });
    assert.equal(provider.calls, afterFirst + 1);
  });
});

describe('gate: export', () => {
  test('all three formats render, and only markdown and json keep the labels', () => {
    const blocks = [
      { kind: 'user_provided' as const, text: 'You sell coffee.' },
      { kind: 'ai_estimate' as const, text: 'Weekends are probably busier.' },
    ];
    assert.ok(exportBlocks(blocks, 'md').body.includes('[AI estimate]'));
    assert.ok(!exportBlocks(blocks, 'txt').body.includes('[AI estimate]'));
    assert.equal(JSON.parse(exportBlocks(blocks, 'json').body).blocks[1].kind, 'ai_estimate');
  });
});

describe('gate: usage limits', () => {
  test('token usage is recorded against the organization on every call', async () => {
    await askCopilot(service, tenant, { prompt: 'Anything.', projectId });

    const period = new Date().toISOString().slice(0, 7) + '-01';
    const generations = await db.usage.listForPeriod(tenant.organizationId, period);
    assert.ok(generations.some((row) => row.metric === 'ai_generation'));
    assert.ok(generations.some((row) => row.metric === 'ai_tokens'));
  });

  test('the lowest paid plan is a real ceiling, not a label', async () => {
    await setup('pro');
    const quota = quotaFor('pro');

    // Pre-load usage to the plan ceiling, then confirm the next call is refused
    // BEFORE the provider is contacted.
    await db.usage.record({
      organizationId: tenant.organizationId,
      projectId: null,
      metric: 'ai_generation',
      quantity: quota.generationsPerMonth,
      periodStart: new Date().toISOString().slice(0, 7) + '-01',
    });

    const turn = await askCopilot(service, tenant, { prompt: 'One more.', projectId });
    assert.equal(turn.result.ok, false);
    assert.equal(provider.calls, 0, 'a quota-exceeded request still reached the provider');
  });

  test('plans differ, so the quota is a product decision rather than a constant', () => {
    assert.ok(quotaFor('free').generationsPerMonth < quotaFor('pro').generationsPerMonth);
    assert.ok(quotaFor('pro').generationsPerMonth < quotaFor('business').generationsPerMonth);
    assert.ok(quotaFor('business').generationsPerMonth < quotaFor('agency').generationsPerMonth);
  });
});

describe('gate: provider abstraction', () => {
  test('all three named providers are present behind one interface', () => {
    const names = allProviders().map((item) => item.name).sort();
    assert.deepEqual(names, ['anthropic', 'gemini', 'openai']);
  });

  test('the orchestrator works against any provider, because it only uses the interface', async () => {
    // The fake provider implements AIProvider and nothing else. That it works
    // end to end is the abstraction actually holding.
    const turn = await askCopilot(service, tenant, { prompt: 'Anything.', projectId });
    assert.equal(turn.result.ok, true);
  });

  test('model selection picks a tier by task weight, not by hard-coded id', () => {
    const models = provider.models;
    assert.equal(selectModel(models, 'light').tier, 'fast');
    assert.equal(selectModel(models, 'heavy').tier, 'deep');
    assert.equal(selectModel(models, 'light', 'deep-model').id, 'deep-model', 'an explicit choice must win');
  });

  test('the four Phase 3 agents are available and the eight future ones are declared', () => {
    const available = availableAgents().map((agent) => agent.id).sort();
    assert.deepEqual(available, ['brand', 'content', 'copilot', 'social', 'strategy']);

    const planned = plannedAgents().map((agent) => agent.id).sort();
    assert.deepEqual(planned, [
      'ads', 'aeo', 'analytics', 'competitor', 'lead', 'report', 'schema', 'seo',
    ]);
    assert.equal(allAgents().length, 13);
  });
});

describe('gate: no exposed API keys', () => {
  test('the public status payload carries no key material', () => {
    const saved = { ...process.env };
    try {
      process.env.OPENAI_API_KEY = 'sk-FAKE-openai-0123456789abcdef';
      const serialized = JSON.stringify(publicStatus());
      assert.ok(!serialized.includes(process.env.OPENAI_API_KEY));
      assert.ok(!/sk-/.test(serialized));
    } finally {
      process.env = saved;
    }
  });

  test('no key reaches an AI response payload', async () => {
    const saved = { ...process.env };
    try {
      process.env.ANTHROPIC_API_KEY = 'sk-ant-FAKE-0123456789abcdef';
      const turn = await askCopilot(service, tenant, { prompt: 'Anything.', projectId });
      assert.ok(!JSON.stringify(turn.result).includes(process.env.ANTHROPIC_API_KEY!));
    } finally {
      process.env = saved;
    }
  });

  test('the audit log records the call without the prompt or the output', async () => {
    await askCopilot(service, tenant, { prompt: 'A secret internal question.', projectId });
    const entries = await db.audit.list(tenant.organizationId, 50);
    const serialized = JSON.stringify(entries);

    assert.ok(serialized.includes('ai'), 'the generation was not audited at all');
    assert.ok(!serialized.includes('A secret internal question.'), 'the prompt was written to the audit log');
    assert.ok(!serialized.includes('Lead with the roasting process.'), 'the output was written to the audit log');
  });
});

describe('gate: no fabricated facts', () => {
  test('an unsourced statistic marks the response unsafe and blocks the clean path', async () => {
    provider.defaultText = JSON.stringify({
      blocks: [{ kind: 'ai_inference', text: 'The market grew 34% last year.' }],
    });

    const turn = await askCopilot(service, tenant, { prompt: 'How big is the market?', projectId });
    assert.equal(turn.result.ok, true);
    if (!turn.result.ok) return;

    assert.equal(turn.result.response.safe, false);
    assert.ok(turn.result.response.warnings.some((warning) => warning.severity === 'error'));
  });

  test('an UNTAGGED response is discarded rather than shown', async () => {
    provider.defaultText = 'The market is worth ₹120 crore and growing fast.';
    const turn = await askCopilot(service, tenant, { prompt: 'How big is the market?', projectId });

    assert.equal(turn.result.ok, false);
    assert.equal(turn.assistantMessage, null, 'an unverifiable answer was stored anyway');
  });

  test('a saved content item with a fabricated claim is flagged for review', async () => {
    provider.defaultText = JSON.stringify({
      blocks: [{ kind: 'ai_inference', text: 'Conversion rates average 4.5% in this sector.' }],
    });

    const outcome = await generateContent(service, tenant, {
      projectId,
      controls: { ...DEFAULT_CONTROLS, format: 'blog', topic: 'Conversion' },
    });
    assert.equal(outcome.item?.status, 'in_review');
  });
});

describe('gate: error handling', () => {
  test('a TRANSIENT failure is retried rather than surfaced', async () => {
    // One blip should not become an error the user has to act on.
    provider.script = [new AiError('unavailable', 'blip', { provider: 'openai' })];
    const turn = await askCopilot(service, tenant, { prompt: 'Anything.', projectId });

    assert.equal(turn.result.ok, true);
    assert.equal(provider.calls, 2, 'the call was not retried exactly once');
  });

  test('a SUSTAINED outage becomes a clear message, never a leaked exception', async () => {
    // Three attempts, so three failures exhausts the policy.
    provider.script = [
      new AiError('unavailable', 'upstream 503 from api.openai.com', { provider: 'openai' }),
      new AiError('unavailable', 'upstream 503 from api.openai.com', { provider: 'openai' }),
      new AiError('unavailable', 'upstream 503 from api.openai.com', { provider: 'openai' }),
    ];
    const turn = await askCopilot(service, tenant, { prompt: 'Anything.', projectId });

    assert.equal(turn.result.ok, false);
    if (turn.result.ok) return;
    assert.ok(!turn.result.message.includes('api.openai.com'), 'the provider host leaked to the user');
    assert.ok(turn.result.message.length > 0);
  });

  test('a rate limit returns a retry hint rather than a bare failure', async () => {
    const limited = () => new AiError('rate_limited', 'slow down', { provider: 'openai', retryAfterSeconds: 12 });
    provider.script = [limited(), limited(), limited()];
    const turn = await askCopilot(service, tenant, { prompt: 'Anything.', projectId });

    assert.equal(turn.result.ok, false);
    if (turn.result.ok) return;
    assert.equal(turn.result.code, 'rate_limited');
    assert.equal(turn.result.retryAfterSeconds, 12);
  });

  test('an unparseable response is reported honestly as discarded', async () => {
    provider.defaultText = 'not json at all';
    const turn = await askCopilot(service, tenant, { prompt: 'Anything.', projectId });

    assert.equal(turn.result.ok, false);
    if (turn.result.ok) return;
    assert.match(turn.result.message, /sourcing|discarded|regenerat/i);
  });

  test('a failure is still audited, so an outage is visible afterwards', async () => {
    const down = () => new AiError('unavailable', 'down', { provider: 'openai' });
    provider.script = [down(), down(), down()];
    await askCopilot(service, tenant, { prompt: 'Anything.', projectId });

    const entries = await db.audit.list(tenant.organizationId, 50);
    assert.ok(JSON.stringify(entries).includes('failure'));
  });
});

describe('gate: no pretend publishing', () => {
  test('every platform refuses to publish and says what it would need', () => {
    assert.equal(PLATFORMS.length, 7);
  });
});
