import assert from 'node:assert/strict';
import { test, describe } from 'node:test';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  PAST_DUE_GRACE_DAYS,
  STATUS_EXPLANATION,
  STATUS_LABEL,
  SUBSCRIPTION_EVENTS,
  SUBSCRIPTION_STATUSES,
  TRANSITIONS,
  accessFor,
  applyEvent,
  billingStatus,
  isSubscriptionStatus,
  nullProvider,
  type SubscriptionEvent,
  type SubscriptionStatus,
} from '../src/lib/billing/types';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const NOW = new Date('2026-03-15T10:00:00.000Z');

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of readdirSync(dir)) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) walk(full, out);
    else if (/\.(ts|tsx)$/.test(entry)) out.push(full);
  }
  return out;
}

/* -------------------------------------------------------------------------- */
/* No payment secrets                                                        */
/* -------------------------------------------------------------------------- */

describe('no sensitive payment data is stored', () => {
  test('nothing in the billing module declares a card field', () => {
    // Crude on purpose. The expensive version of this mistake is a PCI incident,
    // not a bug report, so the check is blunt and fires early.
    const forbidden = [
      'cardNumber',
      'card_number',
      'pan',
      'cvv',
      'cvc',
      'securityCode',
      'expiryDate',
      'accountNumber',
      'account_number',
      'routingNumber',
      'sortCode',
      'iban',
    ];
    for (const file of walk(path.join(root, 'src', 'lib', 'billing'))) {
      const text = readFileSync(file, 'utf8');
      for (const field of forbidden) {
        // Only flag a DECLARATION, not the word appearing in a comment that
        // explains why it is absent — which is the most useful text in the file.
        const declaration = new RegExp(`(readonly\\s+)?${field}\\s*[?:]`, 'i');
        assert.ok(
          !declaration.test(text),
          `${path.relative(root, file)} declares "${field}"`,
        );
      }
    }
  });

  test('no database column anywhere could hold a card', () => {
    const migrations = readdirSync(path.join(root, 'db', 'migrations'))
      .filter((name) => name.endsWith('.sql'))
      .map((name) => readFileSync(path.join(root, 'db', 'migrations', name), 'utf8'))
      .join('\n')
      .split('\n')
      .filter((line) => !line.trim().startsWith('--'))
      .join('\n');

    for (const column of [
      'card_number',
      'cvv',
      'cvc',
      'pan',
      'security_code',
      'account_number',
      'routing_number',
      'sort_code',
      'iban',
      'card_token',
    ]) {
      assert.ok(
        !new RegExp(`^\\s+${column}\\s+`, 'm').test(migrations),
        `a migration declares a "${column}" column`,
      );
    }
  });

  test('the payment method summary holds display metadata and nothing chargeable', () => {
    const text = readFileSync(path.join(root, 'src', 'lib', 'billing', 'types.ts'), 'utf8');
    const block = /export interface PaymentMethodSummary \{([\s\S]*?)\n\}/.exec(text)?.[1] ?? '';
    assert.ok(block.length > 0, 'PaymentMethodSummary was not found');
    const fields = [...block.matchAll(/readonly (\w+)/g)].map((match) => match[1]);
    assert.deepEqual([...fields].sort(), ['brand', 'expiryMonth', 'expiryYear', 'last4']);
  });

  test('no provider method accepts or returns a card', () => {
    const text = readFileSync(path.join(root, 'src', 'lib', 'billing', 'types.ts'), 'utf8');
    const block = /export interface PaymentProvider \{([\s\S]*?)\n\}/.exec(text)?.[1] ?? '';
    assert.ok(block.length > 0);

    // COMMENTS ARE STRIPPED FIRST. The first version of this scanned the raw
    // block and failed on "no method takes a card, and no method returns one" —
    // the sentence that documents the guarantee, and the most useful text in the
    // interface. Same defect as the Phase 5 "spend" assertion and the Phase 6
    // "write access" one: a test that looks for a topic rather than a claim
    // pushes the fix in exactly the wrong direction, deleting the explanation to
    // satisfy the check. This looks at the SIGNATURES.
    const signatures = block
      .replace(/\/\*\*[\s\S]*?\*\//g, '')
      .replace(/\/\/.*$/gm, '');

    assert.ok(!/card|cvv|pan\b/i.test(signatures), 'a provider method signature mentions a card');
    // And the prose is still there, because it is worth keeping. Asserted against
    // the whole file: the sentence sits in the doc comment ABOVE the interface,
    // which the block capture deliberately excludes.
    assert.match(text, /no method takes a card/);
  });
});

/* -------------------------------------------------------------------------- */
/* The null provider                                                         */
/* -------------------------------------------------------------------------- */

describe('the provider that ships', () => {
  test('is not configured, and says so', () => {
    assert.equal(nullProvider.configured, false);
    const status = billingStatus();
    assert.equal(status.configured, false);
    assert.match(status.message, /No payment provider is connected/);
    assert.match(status.message, /Plan limits still apply/);
  });

  test('refuses every operation with a reason, and charges nothing', async () => {
    const calls = [
      nullProvider.createCheckout({
        organizationId: 'o1',
        plan: 'pro',
        returnUrl: 'https://example.com/return',
        reference: 'r1',
      }),
      nullProvider.createPortalSession('cus_1', 'https://example.com'),
      nullProvider.changePlan('sub_1', 'business'),
      nullProvider.cancel('sub_1', true),
      nullProvider.fetchSubscription('sub_1'),
    ];
    for (const call of calls) {
      const outcome = await call;
      assert.equal(outcome.ok, false);
      assert.ok(outcome.ok === false && /Nothing was charged/.test(outcome.reason));
    }
  });

  test('NEVER verifies a webhook', () => {
    // The most dangerous possible return value in the codebase. An unverifiable
    // webhook must not be trusted, and a permissive stub here would let anyone
    // grant themselves an agency plan with a curl command.
    assert.equal(nullProvider.verifyWebhook('{}', 'sig'), false);
    assert.equal(nullProvider.verifyWebhook('', ''), false);
    assert.equal(nullProvider.verifyWebhook('anything', 'anything'), false);
  });
});

/* -------------------------------------------------------------------------- */
/* Subscription state                                                        */
/* -------------------------------------------------------------------------- */

describe('subscription states', () => {
  test('cover the ones the brief names, plus the two the machine needs', () => {
    for (const status of ['trialing', 'active', 'past_due', 'canceled'] as const) {
      assert.ok((SUBSCRIPTION_STATUSES as readonly string[]).includes(status), status);
    }
    assert.ok((SUBSCRIPTION_STATUSES as readonly string[]).includes('incomplete'));
    assert.ok(isSubscriptionStatus('past_due'));
    assert.ok(!isSubscriptionStatus('expired'));
  });

  test('each has a label and an explanation written for a worried person', () => {
    for (const status of SUBSCRIPTION_STATUSES) {
      assert.ok(STATUS_LABEL[status].length > 0, status);
      assert.ok(STATUS_EXPLANATION[status].length > 25, status);
    }
  });

  test('the non-payment and cancellation messages promise the data is intact', () => {
    assert.match(STATUS_EXPLANATION.past_due, /Nothing is deleted/);
    assert.match(STATUS_EXPLANATION.canceled, /still here and still exports/);
  });
});

describe('what a state permits', () => {
  test('READ ACCESS IS NEVER REVOKED, in any state', () => {
    // A customer's content is theirs. Holding it hostage to collect a debt is
    // wrong and, under most data-protection regimes, unlawful.
    for (const status of SUBSCRIPTION_STATUSES) {
      const access = accessFor(status, { now: NOW, pastDueSince: new Date('2020-01-01') });
      assert.equal(access.readable, true, status);
    }
  });

  test('active and trialing can write', () => {
    assert.equal(accessFor('active', { now: NOW }).writable, true);
    assert.equal(accessFor('trialing', { now: NOW }).writable, true);
  });

  test('a failed payment keeps working through the grace window', () => {
    const since = new Date(NOW.getTime() - (PAST_DUE_GRACE_DAYS - 1) * 86_400_000);
    const access = accessFor('past_due', { now: NOW, pastDueSince: since });
    assert.equal(access.writable, true, 'a bank declining a routine charge is not the customer’s fault');
  });

  test('writes stop after the grace window, with a reason that says nothing is lost', () => {
    const since = new Date(NOW.getTime() - (PAST_DUE_GRACE_DAYS + 1) * 86_400_000);
    const access = accessFor('past_due', { now: NOW, pastDueSince: since });
    assert.equal(access.writable, false);
    assert.match(access.reason ?? '', /still here and still exports/);
  });

  test('a missing grace-window start gives the customer the benefit of the doubt', () => {
    // A missing timestamp is our bookkeeping problem, not theirs.
    assert.equal(accessFor('past_due', { now: NOW, pastDueSince: null }).writable, true);
  });

  test('cancelled and paused stop writes but keep the archive', () => {
    for (const status of ['canceled', 'paused', 'incomplete'] as const) {
      const access = accessFor(status, { now: NOW });
      assert.equal(access.writable, false, status);
      assert.equal(access.readable, true, status);
      assert.ok((access.reason ?? '').length > 20, status);
    }
  });
});

describe('the state machine', () => {
  test('every state is reachable from another', () => {
    const reachable = new Set<SubscriptionStatus>();
    for (const from of SUBSCRIPTION_STATUSES) {
      for (const event of SUBSCRIPTION_EVENTS) {
        const next = TRANSITIONS[from][event];
        if (next && next !== from) reachable.add(next);
      }
    }
    for (const status of SUBSCRIPTION_STATUSES) {
      if (status === 'incomplete') continue; // the starting state
      assert.ok(reachable.has(status), `${status} is unreachable`);
    }
  });

  test('every declared transition lands on a real status', () => {
    for (const from of SUBSCRIPTION_STATUSES) {
      for (const [event, to] of Object.entries(TRANSITIONS[from])) {
        assert.ok(isSubscriptionStatus(to), `${from} --${event}--> ${String(to)}`);
      }
    }
  });

  test('a payment failure moves an active subscription to past_due', () => {
    const result = applyEvent('active', 'payment_failed');
    assert.equal(result.status, 'past_due');
    assert.equal(result.changed, true);
  });

  test('a successful payment recovers a past_due subscription', () => {
    assert.equal(applyEvent('past_due', 'payment_succeeded').status, 'active');
  });

  test('requesting cancellation does NOT end the subscription', () => {
    // They have paid to the end of the period and keep it.
    const result = applyEvent('active', 'cancellation_requested');
    assert.equal(result.status, 'active');
    assert.equal(result.changed, false);
  });

  test('cancellation takes effect only when the period ends', () => {
    assert.equal(applyEvent('active', 'cancellation_effective').status, 'canceled');
  });

  test('an out-of-order or retried webhook is ignored, not an error', () => {
    // Providers retry and deliver out of order. Throwing would let a retried
    // payment_succeeded break an active subscription.
    const retried = applyEvent('active', 'payment_succeeded');
    assert.equal(retried.status, 'active');
    const nonsense = applyEvent('canceled', 'renewed');
    assert.equal(nonsense.status, 'canceled');
    assert.equal(nonsense.changed, false);
    assert.ok((nonsense.note ?? '').length > 20, 'the reason is recorded, never silent');
    assert.match(nonsense.note ?? '', /out of order/);
  });

  test('a cancelled subscription cannot be revived except by a new checkout', () => {
    for (const event of SUBSCRIPTION_EVENTS) {
      const result = applyEvent('canceled', event as SubscriptionEvent);
      if (result.status === 'canceled') continue;
      assert.ok(
        ['checkout_completed', 'trial_started'].includes(event),
        `"${event}" revived a cancelled subscription`,
      );
    }
  });

  test('nothing transitions out of a state without an event for it', () => {
    for (const from of SUBSCRIPTION_STATUSES) {
      const unlisted = SUBSCRIPTION_EVENTS.filter((event) => TRANSITIONS[from][event] === undefined);
      for (const event of unlisted) {
        assert.equal(applyEvent(from, event).status, from, `${from} moved on "${event}"`);
      }
    }
  });
});
