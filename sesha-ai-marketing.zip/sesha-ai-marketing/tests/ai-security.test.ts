import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { test, describe } from 'node:test';

import { AiError, publicStatus, userFacingMessage, type AiErrorCode } from '../src/lib/ai/provider';

/**
 * "The frontend must never receive provider API keys. Use backend environment
 * variables."
 *
 * That is a one-line rule with several ways to break it, so each one is a test:
 * a client component importing the provider module (the bundler would then ship
 * the whole call path), a key name appearing in NEXT_PUBLIC_*, a key travelling
 * in a URL where it lands in logs, and an error message that quotes the
 * provider's own response back to the user.
 *
 * The import check is AST-accurate rather than a regex, because `import type`
 * is erased at compile time and must not be treated as a bundled dependency.
 */

const require = createRequire(import.meta.url);
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const ts = require('typescript') as typeof import('typescript');

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function walk(dir: string, match: RegExp): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir)) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) out.push(...walk(full, match));
    else if (match.test(entry)) out.push(full);
  }
  return out;
}

const allSource = walk(path.join(root, 'src'), /\.(ts|tsx)$/);

/** Every module that reads a provider key or can reach one. */
const SERVER_ONLY_AI_MODULES = [
  '@/lib/ai',
  '@/lib/ai/provider',
  '@/lib/ai/orchestrator',
  '@/lib/ai/context',
  '@/lib/ai/cost',
  '@/lib/ai/agents',
];

const PROVIDER_KEY_VARS = ['OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'GEMINI_API_KEY'];

interface SourceImport {
  readonly specifier: string;
  /** True when the whole import is erased at compile time. */
  readonly typeOnly: boolean;
}

function readImports(file: string): SourceImport[] {
  const source = ts.createSourceFile(
    file,
    readFileSync(file, 'utf8'),
    ts.ScriptTarget.ESNext,
    true,
    file.endsWith('.tsx') ? ts.ScriptKind.TSX : ts.ScriptKind.TS,
  );

  const imports: SourceImport[] = [];
  source.forEachChild((node) => {
    if (!ts.isImportDeclaration(node)) return;
    if (!ts.isStringLiteral(node.moduleSpecifier)) return;
    const specifier = node.moduleSpecifier.text;
    const clause = node.importClause;

    // `import '...'` is a side-effect import: not erased.
    if (!clause) {
      imports.push({ specifier, typeOnly: false });
      return;
    }
    if (clause.isTypeOnly) {
      imports.push({ specifier, typeOnly: true });
      return;
    }
    // `import { type A, type B } from` is also fully erased.
    const named = clause.namedBindings;
    if (!clause.name && named && ts.isNamedImports(named) && named.elements.length > 0) {
      imports.push({ specifier, typeOnly: named.elements.every((el) => el.isTypeOnly) });
      return;
    }
    imports.push({ specifier, typeOnly: false });
  });
  return imports;
}

function isClientComponent(contents: string): boolean {
  return /^['"]use client['"]/m.test(contents);
}

/** Resolve a relative import back to the alias form, so both spellings are caught. */
function toAlias(file: string, specifier: string): string {
  if (!specifier.startsWith('.')) return specifier;
  const resolved = path.resolve(path.dirname(file), specifier);
  const relative = path.relative(path.join(root, 'src'), resolved);
  return `@/${relative.split(path.sep).join('/')}`;
}

describe('provider keys cannot reach the browser', () => {
  test('no client component imports a server-only AI module as a value', () => {
    const offenders: string[] = [];
    for (const file of allSource) {
      if (!isClientComponent(readFileSync(file, 'utf8'))) continue;
      for (const imported of readImports(file)) {
        if (imported.typeOnly) continue;
        const alias = toAlias(file, imported.specifier);
        if (SERVER_ONLY_AI_MODULES.includes(alias)) {
          offenders.push(`${path.relative(root, file)} imports ${alias}`);
        }
      }
    }
    assert.deepEqual(
      offenders,
      [],
      'a client component that imports the AI provider ships the key-reading code to the browser',
    );
  });

  test('a type-only import of an AI module is allowed, and the check knows the difference', () => {
    // Guards the checker itself: if it degraded to a substring match it would
    // fail here, and the previous test would then be vacuously strict.
    const probe = path.join(root, 'tests', '__probe-type-only.tsx');
    const imports = ts.createSourceFile(
      probe,
      "'use client';\nimport type { ProviderName } from '@/lib/ai/provider';\nexport const x: ProviderName = 'openai';\n",
      ts.ScriptTarget.ESNext,
      true,
      ts.ScriptKind.TSX,
    );
    let sawTypeOnly = false;
    imports.forEachChild((node) => {
      if (ts.isImportDeclaration(node) && node.importClause?.isTypeOnly) sawTypeOnly = true;
    });
    assert.equal(sawTypeOnly, true);
  });

  test('no provider key is ever named NEXT_PUBLIC_*', () => {
    const offenders: string[] = [];
    for (const file of allSource) {
      const contents = readFileSync(file, 'utf8');
      for (const match of contents.matchAll(/process\.env\.(NEXT_PUBLIC_[A-Z0-9_]+)/g)) {
        const name = match[1]!;
        if (/(API_KEY|SECRET|TOKEN|PASSWORD|PRIVATE)/.test(name)) {
          offenders.push(`${path.relative(root, file)}: ${name}`);
        }
      }
    }
    assert.deepEqual(offenders, []);
  });

  test('provider key variables are read in exactly one module', () => {
    const readers = new Set<string>();
    for (const file of allSource) {
      const contents = readFileSync(file, 'utf8');
      for (const key of PROVIDER_KEY_VARS) {
        if (new RegExp(`process\\.env\\.${key}\\b`).test(contents)) {
          readers.add(path.relative(root, file));
        }
      }
    }
    assert.deepEqual(
      [...readers],
      ['src/lib/ai/provider.ts'],
      'keys must be read in one place, so there is one place to audit',
    );
  });

  test('no key material is hard-coded anywhere in the source', () => {
    // The shapes real keys take, rather than the word "key".
    const keyShapes: readonly { readonly label: string; readonly pattern: RegExp }[] = [
      { label: 'an OpenAI key', pattern: /\bsk-[A-Za-z0-9_-]{20,}/ },
      { label: 'an Anthropic key', pattern: /\bsk-ant-[A-Za-z0-9_-]{20,}/ },
      { label: 'a Google API key', pattern: /\bAIza[A-Za-z0-9_-]{30,}/ },
    ];
    const offenders: string[] = [];
    for (const file of allSource) {
      const contents = readFileSync(file, 'utf8');
      for (const shape of keyShapes) {
        if (shape.pattern.test(contents)) {
          offenders.push(`${path.relative(root, file)}: ${shape.label}`);
        }
      }
    }
    assert.deepEqual(offenders, []);
  });
});

describe('keys do not travel where they get logged', () => {
  const providerSource = readFileSync(path.join(root, 'src', 'lib', 'ai', 'provider.ts'), 'utf8');

  test('the Gemini key goes in a header, never the query string', () => {
    // Query strings end up in proxy logs and browser history; headers do not.
    assert.ok(
      !/[?&]key=\$\{|[?&]key=['"]?\s*\+/.test(providerSource),
      'a key in the URL leaks into every log along the path',
    );
    assert.match(providerSource, /'x-goog-api-key'/);
  });

  test('each provider sends its key in the documented auth header', () => {
    assert.match(providerSource, /Authorization.*Bearer/s);
    assert.match(providerSource, /'x-api-key'/);
  });
});

describe('errors do not leak provider internals', () => {
  const codes: readonly AiErrorCode[] = [
    'not_configured',
    'unauthorized',
    'rate_limited',
    'context_too_long',
    'content_filtered',
    'timeout',
    'unavailable',
    'bad_response',
  ];

  test('a user-facing message never quotes the provider response', () => {
    const secret = 'sk-ant-THIS-IS-A-FAKE-KEY-0123456789';
    for (const code of codes) {
      const error = new AiError(code, `provider said: ${secret} rejected`, { provider: 'anthropic' });
      const message = userFacingMessage(error);
      assert.ok(!message.includes(secret), `${code} leaked key material`);
      assert.ok(!message.includes('provider said'), `${code} echoed the raw provider message`);
    }
  });

  test('every error code has a written message, so none falls back to raw text', () => {
    for (const code of codes) {
      const message = userFacingMessage(new AiError(code, 'raw', {}));
      assert.ok(message.length > 0);
      assert.ok(!message.includes('raw'));
    }
  });
});

describe('the public status payload', () => {
  test('reports configuration without revealing any of it', () => {
    const saved = { ...process.env };
    try {
      process.env.OPENAI_API_KEY = 'sk-FAKE-openai-key-0123456789abcdef';
      process.env.ANTHROPIC_API_KEY = 'sk-ant-FAKE-anthropic-0123456789';
      process.env.GEMINI_API_KEY = 'AIzaFAKEgeminikey0123456789abcdefghij';

      const serialized = JSON.stringify(publicStatus());
      for (const value of [process.env.OPENAI_API_KEY, process.env.ANTHROPIC_API_KEY, process.env.GEMINI_API_KEY]) {
        assert.ok(!serialized.includes(value!), 'publicStatus leaked a key');
      }
      assert.ok(!/sk-|AIza/.test(serialized));
    } finally {
      process.env = saved;
    }
  });

  test('exposes only names, flags and model labels', () => {
    const status = publicStatus();
    assert.deepEqual(Object.keys(status).sort(), ['defaultProvider', 'enabled', 'models', 'providers']);
    for (const provider of status.providers) {
      assert.deepEqual(Object.keys(provider).sort(), ['configured', 'name']);
      assert.equal(typeof provider.configured, 'boolean');
    }
    for (const model of status.models) {
      assert.deepEqual(Object.keys(model).sort(), ['id', 'label', 'tier']);
    }
  });

  test('says AI is off when nothing is configured, rather than failing later', () => {
    const saved = { ...process.env };
    try {
      for (const key of [...PROVIDER_KEY_VARS, 'AI_PROVIDER']) delete process.env[key];
      const status = publicStatus();
      assert.equal(status.enabled, false);
      assert.equal(status.defaultProvider, null);
      assert.deepEqual(status.models, []);
      assert.ok(status.providers.every((p) => !p.configured));
    } finally {
      process.env = saved;
    }
  });
});
