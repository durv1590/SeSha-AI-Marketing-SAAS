import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  LEGACY_PLANS,
  LEGACY_PLAN_MAP,
  LIMITS,
  LIMIT_IDS,
  PLANS,
  PLANS_BY_RANK,
  PLAN_DEFINITIONS,
  formatLimit,
  isPlanId,
  planChange,
  resolvePlanId,
  type LimitId,
  type PlanId,
} from '../src/content/plans';
import {
  clampLimit,
  describeLimit,
  effectiveLimit,
  effectiveLimits,
  type LimitOverride,
} from '../src/lib/plans/resolve';

describe('the four plans the brief names', () => {
  test('are exactly free, pro, business and agency', () => {
    assert.deepEqual([...PLANS], ['free', 'pro', 'business', 'agency']);
  });

  test('each has a definition with a distinct rank', () => {
    const ranks = PLANS.map((id) => PLAN_DEFINITIONS[id].rank);
    assert.equal(new Set(ranks).size, PLANS.length);
    assert.deepEqual(PLANS_BY_RANK.map((plan) => plan.id), ['free', 'pro', 'business', 'agency']);
  });

  test('free requires no payment and offers no trial', () => {
    assert.equal(PLAN_DEFINITIONS.free.requiresPayment, false);
    assert.equal(PLAN_DEFINITIONS.free.trialDays, 0);
  });

  test('every paid plan requires payment', () => {
    for (const id of ['pro', 'business', 'agency'] as const) {
      assert.equal(PLAN_DEFINITIONS[id].requiresPayment, true, id);
    }
  });

  test('the guard rejects anything else', () => {
    assert.ok(isPlanId('business'));
    assert.ok(!isPlanId('enterprise'));
    assert.ok(!isPlanId('starter'), 'a legacy id is not a canonical plan');
  });
});

describe('there is no price anywhere in the plan registry', () => {
  test('no plan definition carries an amount or a currency', () => {
    // The brief says do not hard-code pricing into business logic. Limits are an
    // engineering fact; a price is a commitment by the business, and it lives in
    // pricing.ts behind its own fabrication guard.
    for (const id of PLANS) {
      const keys = Object.keys(PLAN_DEFINITIONS[id]);
      for (const forbidden of ['price', 'monthlyPrice', 'amount', 'currency', 'cost']) {
        assert.ok(!keys.includes(forbidden), `${id} carries "${forbidden}"`);
      }
    }
  });

  test('planChange compares rank, not price', () => {
    assert.equal(planChange('free', 'pro'), 'upgrade');
    assert.equal(planChange('agency', 'pro'), 'downgrade');
    assert.equal(planChange('business', 'business'), 'same');
  });
});

describe('the eleven limits the brief names', () => {
  test('all exist, in the brief’s order', () => {
    assert.deepEqual([...LIMIT_IDS], [
      'ai_requests',
      'tokens',
      'content_generations',
      'website_crawls',
      'seo_audits',
      'aeo_audits',
      'schema_validations',
      'projects',
      'team_members',
      'reports',
      'automations',
    ]);
  });

  test('each declares a kind, a unit and a description a user can act on', () => {
    for (const id of LIMIT_IDS) {
      const limit = LIMITS[id];
      assert.ok(['per_period', 'absolute'].includes(limit.kind), id);
      assert.ok(limit.unit.length > 0, id);
      assert.ok(limit.description.length > 25, id);
    }
  });

  test('the absolute limits are the ones that would be wrong to reset monthly', () => {
    // Resetting these each month would either delete a customer's projects or
    // let them create unlimited ones. Counting them per period is the bug this
    // distinction exists to prevent.
    const absolute = LIMIT_IDS.filter((id) => LIMITS[id].kind === 'absolute');
    assert.deepEqual([...absolute].sort(), ['automations', 'projects', 'team_members']);
  });

  test('every plan sets a value for every limit', () => {
    for (const id of PLANS) {
      for (const limitId of LIMIT_IDS) {
        const value = PLAN_DEFINITIONS[id].limits[limitId];
        assert.ok(value === null || typeof value === 'number', `${id}.${limitId}`);
        if (typeof value === 'number') assert.ok(value >= 0, `${id}.${limitId} is negative`);
      }
    }
  });

  test('a higher-ranked plan is never more restrictive than a lower one', () => {
    // An upgrade that lowers a limit is a billing complaint waiting to happen.
    for (let index = 1; index < PLANS_BY_RANK.length; index += 1) {
      const lower = PLANS_BY_RANK[index - 1]!;
      const higher = PLANS_BY_RANK[index]!;
      for (const limitId of LIMIT_IDS) {
        const a = lower.limits[limitId];
        const b = higher.limits[limitId];
        if (b === null) continue; // unlimited is never more restrictive
        assert.ok(
          a !== null && b >= a,
          `${higher.id}.${limitId} (${String(b)}) is below ${lower.id}.${limitId} (${String(a)})`,
        );
      }
    }
  });
});

describe('the plan rename does not take anything away', () => {
  test('every legacy plan maps to a canonical one', () => {
    for (const legacy of LEGACY_PLANS) {
      assert.ok(isPlanId(LEGACY_PLAN_MAP[legacy]), legacy);
    }
  });

  test('a paid legacy plan does not become free', () => {
    // starter was a PAID tier. Mapping it to free would hand a paying customer a
    // free plan and cut their quotas mid-month.
    assert.notEqual(LEGACY_PLAN_MAP.starter, 'free');
    for (const legacy of LEGACY_PLANS) {
      assert.notEqual(LEGACY_PLAN_MAP[legacy], 'free', legacy);
    }
  });

  test('NO MIGRATED ORGANIZATION LOSES AN ENTITLEMENT', () => {
    // The rule migration 0007 is written against. The old limits are the ones
    // Phases 2-6 actually enforced, from lib/ai/cost.ts, plus the project cap
    // from workspace/service.ts. Anything not previously enforced cannot be a
    // loss, so only the previously-enforced ones are checked here.
    const previouslyEnforced: Record<string, Partial<Record<LimitId, number>>> = {
      starter: { ai_requests: 200, tokens: 500_000 },
      growth: { ai_requests: 2_000, tokens: 6_000_000 },
      agency: { ai_requests: 10_000, tokens: 40_000_000 },
    };

    for (const legacy of LEGACY_PLANS) {
      const destination = PLAN_DEFINITIONS[LEGACY_PLAN_MAP[legacy]];
      for (const [limitId, oldValue] of Object.entries(previouslyEnforced[legacy] ?? {})) {
        const now = destination.limits[limitId as LimitId];
        assert.ok(
          now === null || now >= oldValue,
          `${legacy} -> ${destination.id}: ${limitId} fell from ${oldValue} to ${String(now)}`,
        );
      }
    }
  });

  test('resolvePlanId accepts both vocabularies and rejects anything else', () => {
    assert.equal(resolvePlanId('business'), 'business');
    assert.equal(resolvePlanId('starter'), 'pro');
    assert.equal(resolvePlanId('growth'), 'business');
    assert.equal(resolvePlanId('agency'), 'agency');
    assert.equal(resolvePlanId('enterprise'), null);
    assert.equal(resolvePlanId(null), null);
    assert.equal(resolvePlanId(7), null);
  });
});

describe('effective limits', () => {
  const override = (partial: Partial<LimitOverride> & { limitId: LimitId }): LimitOverride => ({
    value: 99,
    reason: 'Granted for a migration.',
    setBy: 'staff-1',
    setAt: '2026-03-01T00:00:00.000Z',
    ...partial,
  });

  test('are total over every limit', () => {
    const limits = effectiveLimits('pro');
    assert.deepEqual(Object.keys(limits).sort(), [...LIMIT_IDS].sort());
  });

  test('come from the plan when there is no override', () => {
    const limit = effectiveLimit('pro', 'projects');
    assert.equal(limit.source, 'plan');
    assert.equal(limit.value, PLAN_DEFINITIONS.pro.limits.projects);
    assert.equal(limit.override, undefined);
  });

  test('an override replaces the value and says who set it and why', () => {
    const limit = effectiveLimit('pro', 'projects', [override({ limitId: 'projects', value: 40 })]);
    assert.equal(limit.source, 'override');
    assert.equal(limit.value, 40);
    assert.equal(limit.override?.setBy, 'staff-1');
    assert.ok((limit.override?.reason ?? '').length > 0);
  });

  test('an override can grant unlimited', () => {
    const limit = effectiveLimit('free', 'reports', [override({ limitId: 'reports', value: null })]);
    assert.equal(limit.value, null);
  });

  test('an override of one limit leaves the others on the plan', () => {
    const limits = effectiveLimits('pro', [override({ limitId: 'projects', value: 40 })]);
    assert.equal(limits.projects.source, 'override');
    assert.equal(limits.tokens.source, 'plan');
  });

  test('clampLimit refuses a value that would make every check fail', () => {
    assert.equal(clampLimit(null), null);
    assert.equal(clampLimit(10), 10);
    assert.equal(clampLimit(10.7), 10);
    assert.equal(clampLimit(0), 0);
    assert.equal(clampLimit(-1), undefined, 'a negative ceiling has no sensible message');
    assert.equal(clampLimit('40'), undefined);
    assert.equal(clampLimit(Number.NaN), undefined);
    assert.equal(clampLimit(Number.POSITIVE_INFINITY), undefined);
  });
});

describe('describeLimit', () => {
  test('says unlimited, not included, or the figure with its period', () => {
    assert.match(describeLimit(effectiveLimit('agency', 'projects')), /unlimited/);
    assert.match(describeLimit(effectiveLimit('pro', 'ai_requests')), /this month/);
    assert.ok(!describeLimit(effectiveLimit('pro', 'projects')).includes('this month'));
  });
});

describe('formatLimit', () => {
  test('distinguishes unlimited from zero', () => {
    assert.equal(formatLimit(null), 'Unlimited');
    assert.equal(formatLimit(0), 'Not included');
    assert.match(formatLimit(1500), /1,500/);
  });
});
