import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { signUp, toRole } from '../src/lib/auth/service';
import { completeOnboarding } from '../src/lib/workspace/service';
import { NotFoundError, type TenantContext } from '../src/lib/tenant';

import { analyticsFor, connectionsFor, periodOf, previousPeriod } from '../src/lib/analytics/service';
import { hasFigure } from '../src/lib/analytics/metrics';
import { calendarView, createEvent, removeEvent, updateEvent, CalendarInputError } from '../src/lib/calendar/service';
import {
  AutomationInputError,
  createFromTemplate,
  createRule,
  fire,
  listRules,
  listRuns,
  testRule,
  updateRule,
} from '../src/lib/automation/service';
import { RULE_TEMPLATES } from '../src/lib/automation/types';
import {
  ShareDeniedError,
  exportReport,
  generate,
  listReports,
  revokeShare,
  shareReport,
  toReport,
  viewShared,
} from '../src/lib/reports/service';
import { SHARE_DENIED_MESSAGE } from '../src/lib/reports/share';
import {
  NotificationInputError,
  broadcast,
  preferenceView,
  preferencesFor,
  send,
  updatePreferences,
} from '../src/lib/notifications/service';
import { createLead } from '../src/lib/leads/service';

/**
 * Phase 6 services against the in-memory database.
 *
 * The point of this file is the seams the unit tests cannot reach: that a report
 * generated with nothing connected really does come out with no figures for the
 * connected metrics, that an automation really does write a task and not an
 * email, that a share link really does stop working when revoked, and that a
 * preference a user sets really is honoured by the code that sends.
 */

const PASSWORD = 'a genuinely long passphrase 2026';

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: 'https://acme-coffee.example.com',
};

const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic'] as const,
  marketingChannels: ['organic-search', 'email'] as const,
  brandVoice: { tones: ['friendly'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters' }],
};

let db: MemoryDatabase;
let tenant: TenantContext;
let projectId: string;
/**
 * The service clock is real time, not a fixed instant.
 *
 * The memory store stamps `createdAt` with its own `new Date()`, exactly as a
 * database DEFAULT now() will. Pinning the service to a date in the past
 * therefore puts every row it creates OUTSIDE the reporting window, and the
 * first version of this file reported zero leads after creating one — a test
 * artefact that looked exactly like a metric bug.
 *
 * Calendar dates are passed explicitly as YYYY-MM-DD strings, so those tests
 * stay deterministic regardless.
 */
const NOW = new Date();
/**
 * A LIVE clock, not a captured instant.
 *
 * A reporting period ends at "now", and `inWindow` excludes anything after it —
 * correctly, since a row dated in the future is not part of the period. Freezing
 * the clock at module load therefore put every row the test creates a few
 * milliseconds INTO the future, and the leads metric read zero after a lead was
 * created. That looked exactly like a metric bug and was a test bug.
 */
const ctx = () => ({ db, now: () => new Date() });

async function makeTenant(email: string): Promise<{ tenant: TenantContext; projectId: string }> {
  const signed = await signUp(
    { db, lockout: new MemoryLockoutStore(), secret: 'test-secret-value-at-least-32-bytes-long' },
    { email, password: PASSWORD },
  );
  if (!signed.ok || !signed.userId) throw new Error('signup failed');
  const memberships = await db.memberships.findForUser(signed.userId);
  const context: TenantContext = {
    userId: signed.userId,
    organizationId: memberships[0]!.organizationId,
    role: toRole(memberships[0]!.role),
  };
  const onboarded = await completeOnboarding({ db }, context, { business, profile });
  return { tenant: context, projectId: onboarded.project.id };
}

beforeEach(async () => {
  db = new MemoryDatabase();
  const made = await makeTenant(`p6-${Math.random().toString(36).slice(2)}@example.com`);
  tenant = made.tenant;
  projectId = made.projectId;
});

/* -------------------------------------------------------------------------- */
/* Analytics                                                                  */
/* -------------------------------------------------------------------------- */

describe('analytics service', () => {
  test('nothing is connected for a new project', async () => {
    const states = await connectionsFor(ctx(), tenant, projectId);
    assert.equal(states.length, 6);
    assert.ok(states.every((state) => !state.connected));
  });

  test('produces all nineteen metrics, with the connection-dependent ones unavailable', async () => {
    const report = await analyticsFor(ctx(), tenant, projectId);
    assert.equal(report.metrics.length, 19);
    assert.equal(report.anyConnected, false);

    for (const id of ['traffic', 'impressions', 'ctr', 'cpc', 'cpa', 'roas', 'followers', 'reach', 'engagement', 'organic_search'] as const) {
      const metric = report.metrics.find((entry) => entry.id === id);
      assert.equal(metric?.value.kind, 'unavailable', id);
      assert.equal(hasFigure(metric!.value), false, id);
    }
  });

  test('every unavailable metric says what would make it available', async () => {
    const report = await analyticsFor(ctx(), tenant, projectId);
    for (const metric of report.metrics) {
      if (metric.value.kind !== 'unavailable') continue;
      assert.ok(metric.value.why.length > 20, metric.id);
      assert.ok(metric.value.whatWouldMakeItAvailable.length > 20, metric.id);
    }
  });

  test('counts agree with the metric list', async () => {
    const report = await analyticsFor(ctx(), tenant, projectId);
    assert.equal(report.counts.available + report.counts.unavailable, report.metrics.length);
  });

  test('leads become a calculated figure as soon as there is a lead', async () => {
    await createLead(ctx(), tenant, {
      projectId,
      name: 'Priya',
      email: 'priya@example.com',
      enquiry: 'Do you do catering?',
      source: 'website_form',
      optInBasis: 'enquiry_reply',
    });
    const report = await analyticsFor(ctx(), tenant, projectId);
    const leads = report.metrics.find((entry) => entry.id === 'leads');
    assert.equal(leads?.value.kind, 'calculated');
    assert.ok(hasFigure(leads!.value) && leads!.value.value === 1);
  });

  test('conversion stays unavailable while nothing has closed', async () => {
    await createLead(ctx(), tenant, {
      projectId,
      name: 'Priya',
      email: 'priya@example.com',
      enquiry: 'Do you do catering?',
      source: 'website_form',
      optInBasis: 'enquiry_reply',
    });
    const report = await analyticsFor(ctx(), tenant, projectId);
    assert.equal(report.metrics.find((entry) => entry.id === 'conversion')?.value.kind, 'unavailable');
  });

  test('the comparison period is the same length and ends where this one starts', () => {
    const period = periodOf(NOW, 7, 'Week');
    const before = previousPeriod(period);
    assert.equal(before.to, period.from);
    assert.equal(
      new Date(period.to).getTime() - new Date(period.from).getTime(),
      new Date(before.to).getTime() - new Date(before.from).getTime(),
    );
  });

  test('another organization cannot read this project', async () => {
    const other = await makeTenant('other-analytics@example.com');
    await assert.rejects(() => analyticsFor(ctx(), other.tenant, projectId), NotFoundError);
  });
});

/* -------------------------------------------------------------------------- */
/* Calendar                                                                   */
/* -------------------------------------------------------------------------- */

describe('calendar service', () => {
  test('creates an entry and finds it in the weekly view', async () => {
    await createEvent(ctx(), tenant, projectId, {
      kind: 'blog',
      title: 'Publish the catering page',
      date: '2026-03-12',
    });
    const view = await calendarView(ctx(), tenant, projectId, 'weekly', '2026-03-11');
    assert.equal(view.events.length, 1);
    assert.equal(view.events[0]?.status, 'planned');
    assert.equal(view.events[0]?.origin, 'manual');
  });

  test('refuses a malformed date rather than storing one', async () => {
    await assert.rejects(
      () => createEvent(ctx(), tenant, projectId, { kind: 'blog', title: 'x', date: '12/03/2026' }),
      CalendarInputError,
    );
  });

  test('refuses an empty title', async () => {
    await assert.rejects(
      () => createEvent(ctx(), tenant, projectId, { kind: 'blog', title: '   ', date: '2026-03-12' }),
      CalendarInputError,
    );
  });

  test('an accepted suggestion is recorded as one, not as something the user planned', async () => {
    const row = await createEvent(ctx(), tenant, projectId, {
      kind: 'email',
      title: 'Draft the monthly update',
      date: '2026-03-13',
      fromSuggestion: true,
    });
    assert.equal(row.origin, 'accepted_suggestion');
  });

  test('suggestions are returned but never stored', async () => {
    const view = await calendarView(ctx(), tenant, projectId, 'weekly', '2026-03-11');
    assert.ok(view.suggestions.length > 0, 'this customer listed channels, so there is something to suggest');
    assert.equal(view.events.length, 0, 'nothing was written');
    const again = await calendarView(ctx(), tenant, projectId, 'weekly', '2026-03-11');
    assert.equal(again.events.length, 0, 'reading twice must not accumulate entries');
  });

  test('every suggestion names what it was based on', async () => {
    const view = await calendarView(ctx(), tenant, projectId, 'weekly', '2026-03-11');
    for (const suggestion of view.suggestions) {
      assert.ok(suggestion.basedOn.length > 0, suggestion.title);
      assert.ok(suggestion.why.length > 20, suggestion.title);
    }
  });

  test('the campaign view groups entries regardless of date', async () => {
    await createEvent(ctx(), tenant, projectId, { kind: 'ads', title: 'A', date: '2026-01-02', campaign: 'Spring' });
    await createEvent(ctx(), tenant, projectId, { kind: 'ads', title: 'B', date: '2026-09-02', campaign: 'Spring' });
    await createEvent(ctx(), tenant, projectId, { kind: 'blog', title: 'C', date: '2026-03-02' });
    const view = await calendarView(ctx(), tenant, projectId, 'campaign');
    assert.equal(view.events.length, 2, 'the ungrouped entry is not invented into a campaign');
  });

  test('updating and removing an entry', async () => {
    const row = await createEvent(ctx(), tenant, projectId, { kind: 'blog', title: 'Draft', date: '2026-03-12' });
    const updated = await updateEvent(ctx(), tenant, row.id, { status: 'done', title: 'Published' });
    assert.equal(updated.status, 'done');
    assert.equal(updated.title, 'Published');
    await removeEvent(ctx(), tenant, row.id);
    const view = await calendarView(ctx(), tenant, projectId, 'weekly', '2026-03-11');
    assert.equal(view.events.length, 0);
  });

  test("another organization's entry is not found", async () => {
    const row = await createEvent(ctx(), tenant, projectId, { kind: 'blog', title: 'Draft', date: '2026-03-12' });
    const other = await makeTenant('other-calendar@example.com');
    await assert.rejects(() => updateEvent(ctx(), other.tenant, row.id, { status: 'done' }), NotFoundError);
  });
});

/* -------------------------------------------------------------------------- */
/* Automation                                                                 */
/* -------------------------------------------------------------------------- */

describe('automation service', () => {
  test('a new rule starts switched off', async () => {
    const { rule } = await createRule(ctx(), tenant, projectId, {
      name: 'New lead',
      trigger: 'lead_created',
      conditions: [{ field: 'email', operator: 'is_set' }],
      actions: [{ kind: 'create_task', template: 'Ring the {{source}} lead.' }],
    });
    assert.equal(rule.enabled, false, 'an automation nobody chose is one nobody expects');
  });

  test('every offered template can be created', async () => {
    // Phase 7 added an automations limit, and Free allows one. This test is
    // about the templates, not about the limit (which tests/phase7-services
    // covers), so it runs on a plan with room for all six.
    await db.subscriptions.update(tenant.organizationId, { plan: 'business' });
    for (const template of RULE_TEMPLATES) {
      const rule = await createFromTemplate(ctx(), tenant, projectId, template.name);
      assert.equal(rule.enabled, false);
      assert.equal(rule.name, template.name);
    }
    const rules = await listRules(ctx(), tenant, projectId);
    assert.equal(rules.length, RULE_TEMPLATES.length);
  });

  test('a rule whose condition names a field the trigger lacks is refused', async () => {
    await assert.rejects(
      () =>
        createRule(ctx(), tenant, projectId, {
          name: 'Broken',
          trigger: 'crawl_completed',
          conditions: [{ field: 'score', operator: 'is_set' }],
          actions: [{ kind: 'create_task', template: 'x' }],
        }),
      AutomationInputError,
    );
  });

  test('an edit is re-validated in full, not only the changed field', async () => {
    const { rule } = await createRule(ctx(), tenant, projectId, {
      name: 'Leads',
      trigger: 'lead_created',
      conditions: [{ field: 'score', operator: 'greater_than', value: 10 }],
      actions: [{ kind: 'create_task', template: 'x' }],
    });
    // 'score' is valid for lead_created and not for crawl_completed: changing
    // only the trigger must be caught.
    await assert.rejects(
      () => updateRule(ctx(), tenant, rule.id, { trigger: 'crawl_completed' }),
      AutomationInputError,
    );
  });

  test('firing an enabled rule creates a follow-up on the lead and no message', async () => {
    const { rule } = await createRule(ctx(), tenant, projectId, {
      name: 'Follow up',
      trigger: 'lead_created',
      conditions: [{ field: 'email', operator: 'is_set' }],
      actions: [{ kind: 'create_follow_up', template: 'Ring the {{source}} lead.', offsetDays: 1 }],
      enabled: true,
    });

    const lead = await createLead(ctx(), tenant, {
      projectId,
      name: 'Priya',
      email: 'priya@example.com',
      enquiry: 'Catering?',
      source: 'website_form',
      optInBasis: 'enquiry_reply',
    });

    const results = await fire(
      ctx(),
      tenant.organizationId,
      projectId,
      { kind: 'lead_created', payload: { email: 'priya@example.com', source: 'website_form' }, subjectId: lead.lead.id },
      tenant.userId,
    );

    assert.equal(results.length, 1);
    assert.equal(results[0]?.matched, true);

    const activities = await db.leadActivities.listForLead(tenant.organizationId, lead.lead.id);
    const followUp = activities.find((row) => row.kind === 'follow_up' && row.dueAt !== null);
    assert.ok(followUp, 'the follow-up must exist');
    assert.match(followUp.note, /Ring the website_form lead/);
    assert.match(followUp.note, new RegExp(rule.name));
  });

  test('a run that did nothing is recorded with the condition that failed', async () => {
    const { rule } = await createRule(ctx(), tenant, projectId, {
      name: 'High scores only',
      trigger: 'lead_created',
      conditions: [{ field: 'score', operator: 'greater_than', value: 90 }],
      actions: [{ kind: 'create_task', template: 'Ring them.' }],
      enabled: true,
    });

    const results = await fire(ctx(), tenant.organizationId, projectId, {
      kind: 'lead_created',
      payload: { score: 10 },
    });
    assert.equal(results[0]?.matched, false);

    const runs = await listRuns(ctx(), tenant, rule.id);
    assert.equal(runs.length, 1);
    assert.equal(runs[0]?.matched, false);
    assert.match(runs[0]?.skipReason ?? '', /score/);
    assert.match(runs[0]?.skipReason ?? '', /10/);
  });

  test('a disabled rule is not evaluated at all', async () => {
    const { rule } = await createRule(ctx(), tenant, projectId, {
      name: 'Off',
      trigger: 'lead_created',
      conditions: [],
      actions: [{ kind: 'create_task', template: 'x' }],
    });
    const results = await fire(ctx(), tenant.organizationId, projectId, { kind: 'lead_created', payload: {} });
    assert.equal(results.length, 0);
    assert.equal((await listRuns(ctx(), tenant, rule.id)).length, 0);
  });

  test('testing a rule writes nothing, and works on a rule that is still off', async () => {
    const { rule } = await createRule(ctx(), tenant, projectId, {
      name: 'Preview me',
      trigger: 'lead_created',
      conditions: [{ field: 'email', operator: 'is_set' }],
      actions: [{ kind: 'create_task', template: 'Ring the {{source}} lead.' }],
    });

    const result = await testRule(ctx(), tenant, rule.id, { email: 'a@b.c', source: 'website' });
    assert.equal(result.matched, true);
    assert.equal(result.enabledForPreview, true, 'the preview must say it assumed the rule was on');
    assert.equal(result.actions[0]?.text, 'Ring the website lead.');

    assert.equal((await listRuns(ctx(), tenant, rule.id)).length, 0, 'a preview writes nothing');
  });

  test("another organization's rule is not found", async () => {
    const { rule } = await createRule(ctx(), tenant, projectId, {
      name: 'Mine',
      trigger: 'lead_created',
      conditions: [],
      actions: [{ kind: 'create_task', template: 'x' }],
    });
    const other = await makeTenant('other-automation@example.com');
    await assert.rejects(() => testRule(ctx(), other.tenant, rule.id, {}), NotFoundError);
  });
});

/* -------------------------------------------------------------------------- */
/* Reports                                                                    */
/* -------------------------------------------------------------------------- */

describe('report service', () => {
  test('a report generated with nothing connected contains no fabricated figure', async () => {
    const row = await generate(ctx(), tenant, projectId, 'monthly');
    const report = toReport(row);

    assert.equal(report.provenance.anyConnected, false);
    assert.deepEqual([...report.provenance.connectedSources], []);

    for (const metric of report.metrics) {
      if (metric.definition.requires === 'none') continue;
      assert.equal(metric.value.kind, 'unavailable', metric.id);
    }
  });

  test('all six sections are present in the brief’s order, empty ones with a reason', async () => {
    const report = toReport(await generate(ctx(), tenant, projectId, 'weekly'));
    assert.deepEqual(report.sections.map((section) => section.id), [
      'what_happened',
      'why',
      'what_next',
      'which_campaigns',
      'which_pages',
      'where_to_review',
    ]);
    for (const section of report.sections) {
      if (section.points.length === 0) assert.ok(section.emptyReason, section.id);
    }
  });

  test('it is stored whole, so reading it back does not re-run the generator', async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');
    const first = toReport(row);
    const stored = await db.reports.findById(tenant.organizationId, row.id);
    assert.deepEqual(toReport(stored!), first);
  });

  test('every export format renders the stored report', async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');

    const json = await exportReport(ctx(), tenant, row.id, 'json');
    const parsed = JSON.parse(json.body as string) as { schema: string };
    assert.equal(parsed.schema, 'sesha.report.v1');

    const csv = await exportReport(ctx(), tenant, row.id, 'csv');
    assert.match(csv.body as string, /METRICS/);

    const pdf = await exportReport(ctx(), tenant, row.id, 'pdf');
    assert.ok(pdf.body instanceof Uint8Array);
    assert.equal(String.fromCharCode(...(pdf.body as Uint8Array).slice(0, 8)), '%PDF-1.7');
  });

  test('exporting the same report twice produces identical bytes', async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');
    const a = await exportReport(ctx(), tenant, row.id, 'pdf');
    const b = await exportReport(ctx(), tenant, row.id, 'pdf');
    assert.deepEqual(a.body, b.body);
  });

  test('listing returns the reports for the project', async () => {
    await generate(ctx(), tenant, projectId, 'weekly');
    await generate(ctx(), tenant, projectId, 'seo');
    const rows = await listReports(ctx(), tenant, projectId);
    assert.equal(rows.length, 2);
  });

  test("another organization's report is not found", async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');
    const other = await makeTenant('other-report@example.com');
    await assert.rejects(() => exportReport(ctx(), other.tenant, row.id, 'json'), NotFoundError);
  });
});

describe('share links', () => {
  test('a fresh link resolves to the report', async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');
    const shared = await shareReport(ctx(), tenant, row.id);
    const viewed = await viewShared(ctx(), shared.token);
    assert.equal(viewed.row.id, row.id);
    assert.match(shared.path, /^\/share\//);
  });

  test('only the hash is stored', async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');
    const shared = await shareReport(ctx(), tenant, row.id);
    assert.notEqual(shared.share.tokenHash, shared.token);
    assert.ok(!JSON.stringify(shared.share).includes(shared.token));
  });

  test('revocation takes effect immediately, with the same message as any other failure', async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');
    const shared = await shareReport(ctx(), tenant, row.id);
    await revokeShare(ctx(), tenant, shared.share.id);

    await assert.rejects(
      () => viewShared(ctx(), shared.token),
      (error: unknown) => {
        assert.ok(error instanceof ShareDeniedError);
        assert.equal(error.message, SHARE_DENIED_MESSAGE);
        assert.equal(error.reason, 'revoked');
        return true;
      },
    );
  });

  test('an expired link is refused with the identical message', async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');
    const shared = await shareReport(ctx(), tenant, row.id, 1);
    const later = { db, now: () => new Date(NOW.getTime() + 3 * 86_400_000) };
    await assert.rejects(
      () => viewShared(later, shared.token),
      (error: unknown) => {
        assert.ok(error instanceof ShareDeniedError);
        assert.equal(error.message, SHARE_DENIED_MESSAGE);
        return true;
      },
    );
  });

  test('an invented token is refused without touching the database', async () => {
    // "Without touching the database" is the actual claim, and asserting only the
    // rejection does not test it: a lookup that finds nothing rejects identically.
    // Mutation testing caught that. The shape guard exists so a scanner cannot use
    // lookup timing to tell a malformed token from a missing one, so the test has
    // to observe the lookup.
    let lookups = 0;
    const original = db.reportShares.findByTokenHash.bind(db.reportShares);
    const spied = {
      ...ctx(),
      db: {
        ...db,
        reportShares: {
          ...db.reportShares,
          findByTokenHash: async (hash: string) => {
            lookups += 1;
            return original(hash);
          },
        },
      } as unknown as typeof db,
    };

    await assert.rejects(() => viewShared(spied, 'not-a-real-token'), ShareDeniedError);
    assert.equal(lookups, 0, 'a malformed token must be refused before any lookup');

    await assert.rejects(() => viewShared(spied, 'A'.repeat(43)), ShareDeniedError);
    assert.equal(lookups, 1, 'a well-shaped but unknown token is looked up, and still refused');
  });

  test('viewing records the view', async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');
    const shared = await shareReport(ctx(), tenant, row.id);
    await viewShared(ctx(), shared.token);
    await viewShared(ctx(), shared.token);
    const reloaded = await db.reportShares.findByTokenHash(shared.share.tokenHash);
    assert.equal(reloaded?.viewCount, 2);
  });

  test('sharing is recorded in the audit log', async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');
    await shareReport(ctx(), tenant, row.id);
    const entries = await db.audit.list(tenant.organizationId);
    assert.ok(entries.some((entry) => entry.action === 'report.shared'));
  });
});

/* -------------------------------------------------------------------------- */
/* Notifications                                                              */
/* -------------------------------------------------------------------------- */

describe('notification service', () => {
  test('a user with no stored rows gets the defaults', async () => {
    const preferences = await preferencesFor(ctx(), tenant);
    assert.equal(preferences.find((entry) => entry.kind === 'new_lead')?.inApp, true);
    assert.equal(preferences.find((entry) => entry.kind === 'content_scheduled')?.inApp, false);
  });

  test('switching a kind off stops it being sent', async () => {
    const before = await send(ctx(), tenant.organizationId, tenant.userId, {
      kind: 'new_lead',
      title: 'A lead arrived',
      body: 'From the website.',
    });
    assert.equal(before.sent, true);

    await updatePreferences(ctx(), tenant, [{ kind: 'new_lead', inApp: false }]);

    const after = await send(ctx(), tenant.organizationId, tenant.userId, {
      kind: 'new_lead',
      title: 'Another lead',
      body: 'From the website.',
    });
    assert.equal(after.sent, false);
    assert.match(after.reason ?? '', /switched off/);

    const rows = await db.notifications.listForUser(tenant.organizationId, tenant.userId);
    assert.equal(rows.filter((row) => row.kind === 'new_lead').length, 1);
  });

  test('security notifications cannot be switched off, and saying so is an error not a silent ignore', async () => {
    await assert.rejects(
      () => updatePreferences(ctx(), tenant, [{ kind: 'security', inApp: false }]),
      NotificationInputError,
    );
    const result = await send(ctx(), tenant.organizationId, tenant.userId, {
      kind: 'security',
      title: 'Your password changed',
      body: 'If this was not you, act now.',
    });
    assert.equal(result.sent, true);
  });

  test('email cannot be switched on while no provider is connected', async () => {
    await assert.rejects(
      () => updatePreferences(ctx(), tenant, [{ kind: 'new_lead', email: true }]),
      NotificationInputError,
    );
  });

  test('the settings view explains the locked rows rather than just greying them', async () => {
    const view = await preferenceView(ctx(), tenant);
    const security = view.find((entry) => entry.preference.kind === 'security');
    assert.ok((security?.lockedReason ?? '').length > 40);
    const lead = view.find((entry) => entry.preference.kind === 'new_lead');
    assert.equal(lead?.lockedReason, undefined);
  });

  test("a user cannot read another user's settings", async () => {
    const other = await makeTenant('other-notify@example.com');
    await assert.rejects(
      () => preferencesFor(ctx(), tenant, other.tenant.userId),
      NotificationInputError,
    );
  });

  test('a broadcast reports who was not notified rather than silently reaching fewer people', async () => {
    await updatePreferences(ctx(), tenant, [{ kind: 'crawl_complete', inApp: false }]);
    const results = await broadcast(ctx(), tenant.organizationId, {
      kind: 'crawl_complete',
      title: 'Crawl finished',
      body: '20 pages read.',
    });
    assert.equal(results.length, 1);
    assert.equal(results[0]?.result.sent, false);
  });

  test('an automation notification still obeys the preference', async () => {
    await updatePreferences(ctx(), tenant, [{ kind: 'schema_error', inApp: false }]);
    await createRule(ctx(), tenant, projectId, {
      name: 'Schema errors',
      trigger: 'schema_error_found',
      conditions: [],
      actions: [{ kind: 'notify', template: 'Fix {{check}} on {{pageUrl}}.' }],
      enabled: true,
    });

    await fire(
      ctx(),
      tenant.organizationId,
      projectId,
      { kind: 'schema_error_found', payload: { check: 'missing name', pageUrl: 'https://x.example/a' } },
      tenant.userId,
    );

    const rows = await db.notifications.listForUser(tenant.organizationId, tenant.userId);
    assert.equal(
      rows.filter((row) => row.kind === 'schema_error').length,
      0,
      'asking for the automation is not the same as asking to be told every time it runs',
    );
  });
});
