import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  SOLUTION_SLUGS,
  getBreadcrumbs,
  getRoute,
  isRegisteredRoute,
  normalizePath,
  routes,
  sitemapRoutes,
} from '../src/lib/routes';

describe('normalizePath', () => {
  test('root stays root', () => {
    assert.equal(normalizePath('/'), '/');
    assert.equal(normalizePath(''), '/');
  });

  test('strips trailing slash, query and hash', () => {
    assert.equal(normalizePath('/pricing/'), '/pricing');
    assert.equal(normalizePath('/pricing?utm_source=x'), '/pricing');
    assert.equal(normalizePath('/pricing#plans'), '/pricing');
    assert.equal(normalizePath('/pricing/?a=1#b'), '/pricing');
  });

  test('collapses duplicate slashes', () => {
    assert.equal(normalizePath('/solutions//startups'), '/solutions/startups');
  });
});

describe('route registry', () => {
  test('every route path is normalized and unique', () => {
    const seen = new Set<string>();
    for (const route of routes) {
      assert.equal(route.path, normalizePath(route.path), `${route.path} is not normalized`);
      assert.ok(route.path.startsWith('/'), `${route.path} must start with /`);
      assert.ok(!seen.has(route.path), `duplicate route ${route.path}`);
      seen.add(route.path);
    }
  });

  test('every declared parent exists', () => {
    for (const route of routes) {
      if (route.parent !== null) {
        assert.ok(isRegisteredRoute(route.parent), `parent ${route.parent} of ${route.path} missing`);
      }
    }
  });

  test('all nine solution verticals are registered', () => {
    assert.equal(SOLUTION_SLUGS.length, 9);
    for (const slug of SOLUTION_SLUGS) {
      assert.ok(isRegisteredRoute(`/solutions/${slug}`), `/solutions/${slug} missing`);
    }
  });

  test('every route required by the Phase 1 specification exists', () => {
    const required = [
      '/',
      '/features',
      '/solutions',
      '/seo',
      '/aeo',
      '/schema-validator',
      '/pricing',
      '/resources',
      '/blog',
      '/about',
      '/contact',
      '/privacy',
      '/terms',
      '/security',
      '/faq',
      ...SOLUTION_SLUGS.map((s) => `/solutions/${s}`),
    ];
    for (const path of required) {
      assert.ok(isRegisteredRoute(path), `spec route ${path} is not registered`);
    }
    assert.equal(required.length, 24);
  });

  test('sitemap priorities are within range', () => {
    for (const route of sitemapRoutes()) {
      assert.ok(
        route.sitemap.priority >= 0 && route.sitemap.priority <= 1,
        `${route.path} priority out of range`,
      );
    }
  });

  test('home has the highest priority', () => {
    const home = getRoute('/');
    assert.ok(home);
    assert.equal(home.sitemap.priority, 1.0);
  });
});

describe('getBreadcrumbs', () => {
  test('root returns a single crumb', () => {
    assert.deepEqual(getBreadcrumbs('/'), [{ path: '/', label: 'Home' }]);
  });

  test('top-level page returns Home + page', () => {
    assert.deepEqual(getBreadcrumbs('/pricing'), [
      { path: '/', label: 'Home' },
      { path: '/pricing', label: 'Pricing' },
    ]);
  });

  test('nested solution resolves through its parent', () => {
    assert.deepEqual(getBreadcrumbs('/solutions/startups'), [
      { path: '/', label: 'Home' },
      { path: '/solutions', label: 'Solutions' },
      { path: '/solutions/startups', label: 'Startups' },
    ]);
  });

  test('blog resolves under resources', () => {
    const trail = getBreadcrumbs('/blog').map((c) => c.path);
    assert.deepEqual(trail, ['/', '/resources', '/blog']);
  });

  test('unregistered nested path degrades gracefully', () => {
    const trail = getBreadcrumbs('/blog/some-post');
    assert.deepEqual(trail.map((c) => c.path), ['/', '/resources', '/blog', '/blog/some-post']);
    assert.equal(trail[trail.length - 1]?.label, 'Some Post');
  });

  test('trailing slash produces the same trail', () => {
    assert.deepEqual(getBreadcrumbs('/solutions/agencies/'), getBreadcrumbs('/solutions/agencies'));
  });
});
