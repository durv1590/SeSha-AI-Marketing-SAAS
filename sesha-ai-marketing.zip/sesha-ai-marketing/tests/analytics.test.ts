import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  CONNECTION_DEPENDENT_METRICS,
  FIRST_PARTY_METRICS,
  METRICS,
  METRIC_IDS,
  NO_CONNECTED_DATA,
  SOURCE_KINDS,
  SOURCE_LABEL,
  SOURCE_MEANING,
  change,
  formatValue,
  hasFigure,
  isAvailable,
  isMetricId,
  unavailable,
  type MetricValue,
} from '../src/lib/analytics/metrics';
import {
  CONNECTION_DEFINITIONS,
  CONNECTION_PROVIDERS,
  analyticsStatus,
  anyConnected,
  availableSources,
  connectionStates,
  whyUnavailable,
} from '../src/lib/analytics/connections';
import {
  auditScoreMetric,
  contentActivityMetric,
  contentCoverageMetric,
  conversionMetric,
  crawlErrorsMetric,
  leadsMetric,
  schemaIssuesMetric,
  unavailableForConnection,
} from '../src/lib/analytics/compute';

const AS_OF = '2026-03-01T00:00:00.000Z';

describe('the metric vocabulary', () => {
  test('carries the nineteen metrics the brief names', () => {
    assert.equal(METRIC_IDS.length, 19);
    for (const id of METRIC_IDS) {
      assert.equal(METRICS[id].id, id);
      assert.ok(METRICS[id].label.length > 0);
      assert.ok(METRICS[id].description.length > 0);
    }
  });

  test('carries the six source labels the brief names', () => {
    assert.deepEqual([...SOURCE_KINDS], [
      'connected_api',
      'user_provided',
      'retrieved',
      'calculated',
      'ai_estimate',
      'unavailable',
    ]);
    for (const kind of SOURCE_KINDS) {
      assert.ok(SOURCE_LABEL[kind].length > 0);
      assert.ok(SOURCE_MEANING[kind].length > 20, `${kind} needs a real explanation`);
    }
  });

  test('no metric is both first-party and connection-dependent', () => {
    for (const id of FIRST_PARTY_METRICS) {
      assert.ok(!CONNECTION_DEPENDENT_METRICS.includes(id));
    }
    assert.equal(FIRST_PARTY_METRICS.length + CONNECTION_DEPENDENT_METRICS.length, METRIC_IDS.length);
  });

  test('every metric declares at least one source kind it could legitimately have', () => {
    for (const id of METRIC_IDS) {
      assert.ok(METRICS[id].possibleSources.length > 0, id);
    }
  });

  test('an AI estimate is never a possible source for a metric that can be measured', () => {
    for (const id of METRIC_IDS) {
      const definition = METRICS[id];
      if (definition.possibleSources.includes('ai_estimate')) {
        assert.ok(
          !definition.possibleSources.includes('connected_api') &&
            !definition.possibleSources.includes('calculated'),
          `${id} would let an estimate stand in for a real measurement`,
        );
      }
    }
  });

  test('the metrics where up is bad are marked as such', () => {
    for (const id of ['crawl_errors', 'schema_issues', 'cpc', 'cpa'] as const) {
      assert.equal(METRICS[id].higherIsBetter, false, id);
    }
    assert.equal(METRICS.leads.higherIsBetter, true);
  });

  test('isMetricId rejects anything else', () => {
    assert.ok(isMetricId('leads'));
    assert.ok(!isMetricId('sessions'));
    assert.ok(!isMetricId(7));
  });
});

describe('MetricValue keeps a bare number unrepresentable', () => {
  test('unavailable carries the standard label, a reason and a route', () => {
    const value = unavailable('Because.', 'Do this.');
    assert.equal(value.kind, 'unavailable');
    assert.equal(value.label, NO_CONNECTED_DATA);
    assert.equal(isAvailable(value), false);
    assert.equal(hasFigure(value), false);
    assert.equal(formatValue(value), null);
  });

  test('an estimate has a band and no figure', () => {
    const value: MetricValue = { kind: 'ai_estimate', band: 'moderate', basis: 'Guessed.' };
    assert.equal(hasFigure(value), false);
    assert.equal(formatValue(value), null);
    assert.equal(isAvailable(value), true);
  });

  test('formatValue renders each unit distinctly', () => {
    const build =(value: number, unit: 'percent' | 'currency' | 'score' | 'ratio' | 'count' | 'duration_days'): MetricValue => ({
      kind: 'calculated',
      value,
      unit,
      formula: 'x',
      inputs: [],
      asOf: AS_OF,
    });
    assert.equal(formatValue(build(33.333, 'percent')), '33.3%');
    assert.equal(formatValue(build(78, 'score')), '78 / 100');
    assert.equal(formatValue(build(2.5, 'ratio')), '2.5×');
    assert.equal(formatValue(build(3.25, 'duration_days')), '3.3 days');
    assert.ok(formatValue(build(1200, 'currency'))?.startsWith('INR'));
  });
});

describe('change', () => {
  const calc = (value: number): MetricValue => ({
    kind: 'calculated',
    value,
    unit: 'count',
    formula: 'x',
    inputs: [],
    asOf: AS_OF,
  });

  test('is null when there is no previous period', () => {
    assert.equal(change(calc(10), undefined), null);
  });

  test('is null across different source kinds', () => {
    const api: MetricValue = { kind: 'connected_api', value: 5, unit: 'count', source: 'GA', asOf: AS_OF };
    assert.equal(change(calc(10), api), null);
  });

  test('is null when either side has no figure', () => {
    assert.equal(change(calc(10), unavailable('a', 'b')), null);
    assert.equal(change(unavailable('a', 'b'), calc(10)), null);
  });

  test('reports percent as null rather than infinity when the base is zero', () => {
    const result = change(calc(5), calc(0));
    assert.ok(result);
    assert.equal(result.percent, null);
    assert.equal(result.delta, 5);
    assert.equal(result.direction, 'up');
  });

  test('reports direction correctly', () => {
    assert.equal(change(calc(5), calc(10))?.direction, 'down');
    assert.equal(change(calc(10), calc(10))?.direction, 'flat');
  });
});

describe('connections', () => {
  const rows = (provider: string, connected: boolean, problem: string | null = null) => [
    {
      provider,
      connectedAt: connected ? new Date(AS_OF) : null,
      disconnectedAt: null,
      lastSyncedAt: null,
      problem,
    },
  ];

  test('every provider is disconnected when there are no rows', () => {
    const states = connectionStates([]);
    assert.equal(states.length, CONNECTION_PROVIDERS.length);
    assert.ok(states.every((state) => !state.connected));
    assert.equal(anyConnected(states), false);
  });

  test('a disconnected row does not count as connected', () => {
    const states = connectionStates([
      {
        provider: 'google_analytics',
        connectedAt: new Date(AS_OF),
        disconnectedAt: new Date(AS_OF),
        lastSyncedAt: null,
        problem: null,
      },
    ]);
    assert.equal(anyConnected(states), false);
  });

  test('a connection with a problem does not make its metrics available', () => {
    const states = connectionStates(rows('google_analytics', true, 'Token expired'));
    assert.equal(anyConnected(states), true);
    assert.ok(!availableSources(states).has('analytics'));
  });

  test('availableSources always includes none', () => {
    assert.ok(availableSources(connectionStates([])).has('none'));
  });

  test('whyUnavailable names the specific accounts, not "a data source"', () => {
    const ads = whyUnavailable('ads_account');
    assert.match(ads.whatWouldMakeItAvailable, /Google Ads/);
    assert.match(ads.whatWouldMakeItAvailable, /Meta Ads/);
    const search = whyUnavailable('search_console');
    assert.match(search.whatWouldMakeItAvailable, /Search Console/);
    assert.ok(!search.whatWouldMakeItAvailable.includes('Google Ads'));
  });

  test('no connection definition asks for write access', () => {
    // The first version of this looked for the WORDS "write access" and failed on
    // "SeSha never needs write access to analytics" — an explicit disclaimer, the
    // best sentence in the file. Same defect as the Phase 5 advertising assertion
    // that flagged the word "spend": a test looking for a topic rather than a
    // claim would have pushed the fix in exactly the wrong direction, deleting the
    // reassurance to satisfy the check. So it looks for a REQUEST instead.
    for (const provider of CONNECTION_PROVIDERS) {
      const how = CONNECTION_DEFINITIONS[provider].howToConnect.toLowerCase();
      assert.ok(!/grant (write|full|manage)/.test(how), provider);
      assert.ok(!/request(s|ing)? (write|publish|spend)/.test(how), provider);
      assert.ok(/read|access/.test(how), `${provider} should say what access it asks for`);
    }
  });

  test('analyticsStatus says plainly that nothing is a measurement of the audience', () => {
    const status = analyticsStatus(connectionStates([]));
    assert.equal(status.anyConnected, false);
    assert.match(status.message, /No analytics, advertising or social account is connected/);
  });

  test('analyticsStatus names the live sources when there are any', () => {
    const status = analyticsStatus(connectionStates(rows('meta_pages', true)));
    assert.equal(status.anyConnected, true);
    assert.match(status.message, /Facebook and Instagram pages/);
  });
});

describe('computing what SeSha genuinely has', () => {
  const leads = { total: 10, won: 3, lost: 2, open: 5, inPeriod: 4, asOf: AS_OF };

  test('leads is calculated and shows its inputs', () => {
    const value = leadsMetric(leads);
    assert.equal(value.kind, 'calculated');
    assert.ok(hasFigure(value) && value.value === 4);
    assert.ok(value.kind === 'calculated' && value.inputs.length === 2);
  });

  test('conversion is won over closed, excluding open leads', () => {
    const value = conversionMetric(leads);
    assert.ok(value.kind === 'calculated');
    assert.equal(Math.round(value.value), 60);
    assert.match(value.formula, /Open leads are excluded/);
  });

  test('conversion is unavailable rather than 0% when nothing has closed', () => {
    const value = conversionMetric({ ...leads, won: 0, lost: 0 });
    assert.equal(value.kind, 'unavailable');
    assert.ok(value.kind === 'unavailable' && /would claim you convert nobody/.test(value.why));
  });

  test('content coverage is unavailable rather than 0% when nothing is tracked', () => {
    const value = contentCoverageMetric({ keywordsTracked: 0, keywordsCovered: 0, asOf: AS_OF });
    assert.equal(value.kind, 'unavailable');
    assert.equal(contentCoverageMetric(null).kind, 'unavailable');
  });

  test('the audit score carries its own basis into the formula', () => {
    const value = auditScoreMetric(
      { score: 72, basis: "SeSha's own weighting, not a Google measurement.", findingCount: 9, checkedAt: AS_OF },
      'seo',
    );
    assert.ok(value.kind === 'calculated');
    assert.match(value.formula, /not a Google measurement/);
  });

  test('the audit score is unavailable, and says which audit, when none has run', () => {
    const value = auditScoreMetric(null, 'aeo');
    assert.ok(value.kind === 'unavailable' && value.why.includes('AEO'));
  });

  test('schema issues counts errors only, and says warnings are separate', () => {
    const value = schemaIssuesMetric({ invalid: 3, warnings: 11, checkedAt: AS_OF, validatorVersion: '1.0' });
    assert.ok(value.kind === 'calculated' && value.value === 3);
    assert.match(value.formula, /Warnings and recommendations are counted separately/);
  });

  test('crawl errors disclose when the crawl stopped early', () => {
    const value = crawlErrorsMetric({
      pagesCrawled: 20,
      pagesFailed: 2,
      finishedAt: AS_OF,
      stoppedEarly: 'page budget reached',
    });
    assert.ok(value.kind === 'calculated');
    assert.match(value.formula, /stopped early/);
  });

  test('content activity is labelled activity, not performance', () => {
    const value = contentActivityMetric({ created: 4, approved: 2, asOf: AS_OF });
    assert.ok(value.kind === 'calculated');
    assert.match(value.formula, /ACTIVITY, not performance/);
  });

  test('content activity falls back to unavailable when nothing was created', () => {
    assert.equal(contentActivityMetric({ created: 0, approved: 0, asOf: AS_OF }).kind, 'unavailable');
    assert.equal(contentActivityMetric(null).kind, 'unavailable');
  });

  test('unavailableForConnection never produces a figure, for any source', () => {
    for (const requires of ['analytics', 'search_console', 'ads_account', 'social_account'] as const) {
      const value = unavailableForConnection(requires);
      assert.equal(value.kind, 'unavailable');
      assert.equal(hasFigure(value), false);
      assert.ok(value.kind === 'unavailable' && value.whatWouldMakeItAvailable.length > 20);
    }
  });
});

describe('the module exports no way to invent a figure', () => {
  test('nothing in compute.ts is named like an estimator', () => {
    const names = Object.keys({
      auditScoreMetric,
      contentActivityMetric,
      contentCoverageMetric,
      conversionMetric,
      crawlErrorsMetric,
      leadsMetric,
      schemaIssuesMetric,
      unavailableForConnection,
    });
    for (const name of names) {
      assert.ok(!/estimate|predict|project|simulate|mock|fake/i.test(name), name);
    }
  });
});
