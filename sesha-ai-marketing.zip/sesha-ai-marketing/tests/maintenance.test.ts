import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import {
  MIN_CRON_SECRET_LENGTH,
  isMaintenanceAuthorized,
  runMaintenance,
} from '../src/lib/jobs/maintenance';

const SECRET = 'x'.repeat(MIN_CRON_SECRET_LENGTH);

describe('the maintenance endpoint\'s authorisation', () => {
  test('the right bearer secret is accepted', () => {
    assert.equal(isMaintenanceAuthorized(`Bearer ${SECRET}`, SECRET), true);
  });

  test('NO SECRET CONFIGURED MEANS NOTHING IS AUTHORISED, not everything', () => {
    assert.equal(isMaintenanceAuthorized('Bearer anything', undefined), false);
    assert.equal(isMaintenanceAuthorized('Bearer ', ''), false);
  });

  test('a short secret is refused outright', () => {
    const short = 'y'.repeat(MIN_CRON_SECRET_LENGTH - 1);
    assert.equal(isMaintenanceAuthorized(`Bearer ${short}`, short), false);
  });

  test('wrong, missing or non-bearer credentials are refused', () => {
    assert.equal(isMaintenanceAuthorized(`Bearer ${SECRET}z`, SECRET), false);
    assert.equal(isMaintenanceAuthorized(null, SECRET), false);
    assert.equal(isMaintenanceAuthorized(SECRET, SECRET), false);
    assert.equal(isMaintenanceAuthorized(`Basic ${SECRET}`, SECRET), false);
  });
});

describe('a maintenance run', () => {
  test('runs both tasks and reports each', async () => {
    const report = await runMaintenance({ db: new MemoryDatabase() });
    assert.deepEqual(report.jobs, { requeued: 0, abandoned: 0 });
    assert.deepEqual(report.retention, { pagesDeleted: 0 });
  });

  test('ONE TASK FAILING DOES NOT SKIP THE OTHER', async () => {
    const db = new MemoryDatabase();
    (db.jobs as { findStale: unknown }).findStale = async () => {
      throw new TypeError('connection reset');
    };
    const report = await runMaintenance({ db });
    assert.deepEqual(report.jobs, { error: 'TypeError' });
    assert.deepEqual(report.retention, { pagesDeleted: 0 }, 'retention was skipped');
  });
});
