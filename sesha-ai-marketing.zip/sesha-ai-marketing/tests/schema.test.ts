import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  articleSchema,
  breadcrumbSchema,
  buildGraph,
  buildOffers,
  faqPageSchema,
  organizationSchema,
  prune,
  schemaIds,
  serializeJsonLd,
  softwareApplicationSchema,
  webPageSchema,
  webSiteSchema,
} from '../src/lib/schema';
import { authors } from '../src/content/site';
import { validateJsonLd } from '../src/lib/schema-validator/validate';

describe('prune', () => {
  test('drops undefined, null and empty values', () => {
    assert.deepEqual(prune({ a: 1, b: undefined, c: null, d: '', e: [], f: {} }), { a: 1 });
  });

  test('trims strings', () => {
    assert.deepEqual(prune({ a: '  x  ' }), { a: 'x' });
  });

  test('recurses into nested objects and arrays', () => {
    assert.deepEqual(prune({ a: { b: { c: undefined, d: 2 } }, e: [1, undefined, 3] }), {
      a: { b: { d: 2 } },
      e: [1, 3],
    });
  });

  test('collapses an object that becomes empty', () => {
    assert.equal(prune({ a: { b: undefined } }), undefined);
  });

  test('keeps boolean false and numeric zero', () => {
    assert.deepEqual(prune({ a: false, b: 0 }), { a: false, b: 0 });
  });
});

describe('organizationSchema', () => {
  const org = organizationSchema();

  test('declares the right type and id', () => {
    assert.equal(org['@type'], 'Organization');
    assert.equal(org['@id'], schemaIds.organization);
  });

  test('never emits unverified properties', () => {
    for (const forbidden of ['aggregateRating', 'review', 'award', 'numberOfEmployees']) {
      assert.equal(org[forbidden], undefined, `${forbidden} must not be published`);
    }
  });

  test('omits sameAs while no verified profiles exist', () => {
    assert.equal(org['sameAs'], undefined);
  });

  test('publishes the VERIFIED telephone and still omits the unverified address', () => {
    // The phone number was confirmed by the owner in September 2026; the postal
    // address has not been, so it stays out of the structured data rather than
    // being guessed. That asymmetry is the whole rule.
    assert.equal(org['telephone'], '+918218397819');
    assert.equal(org['address'], undefined);
  });
});

describe('webSiteSchema', () => {
  test('links to the organization as publisher', () => {
    const site = webSiteSchema();
    assert.deepEqual(site['publisher'], { '@id': schemaIds.organization });
  });

  test('does not advertise a SearchAction the site cannot serve', () => {
    assert.equal(webSiteSchema()['potentialAction'], undefined);
  });
});

describe('webPageSchema', () => {
  const page = webPageSchema({
    path: '/pricing',
    name: 'Pricing',
    description: 'Compare plans.',
    dateModified: '2026-09-01',
  });

  test('is part of the website and references its breadcrumb', () => {
    assert.deepEqual(page['isPartOf'], { '@id': schemaIds.website });
    assert.deepEqual(page['breadcrumb'], { '@id': schemaIds.breadcrumb('/pricing') });
  });

  test('url is absolute', () => {
    assert.match(String(page['url']), /^https?:\/\//);
  });
});

describe('breadcrumbSchema', () => {
  const crumbs = breadcrumbSchema('/solutions/startups');
  const items = crumbs['itemListElement'] as { position: number; name: string; item: string }[];

  test('positions start at 1 and increment', () => {
    assert.deepEqual(items.map((i) => i.position), [1, 2, 3]);
  });

  test('items are absolute URLs', () => {
    for (const item of items) assert.match(item.item, /^https?:\/\//);
  });

  test('first crumb is Home', () => {
    assert.equal(items[0]?.name, 'Home');
  });
});

describe('faqPageSchema', () => {
  test('returns null when there are no usable entries', () => {
    assert.equal(faqPageSchema('/faq', []), null);
    assert.equal(faqPageSchema('/faq', [{ question: '  ', answer: '  ' }]), null);
  });

  test('maps entries to Question / acceptedAnswer pairs', () => {
    const faq = faqPageSchema('/faq', [{ question: 'What is AEO?', answer: 'Answer engine optimisation.' }]);
    assert.ok(faq);
    const entities = faq['mainEntity'] as { '@type': string; acceptedAnswer: { text: string } }[];
    assert.equal(entities.length, 1);
    assert.equal(entities[0]?.['@type'], 'Question');
    assert.equal(entities[0]?.acceptedAnswer.text, 'Answer engine optimisation.');
  });
});

describe('articleSchema', () => {
  const article = articleSchema({
    path: '/blog/example',
    headline: 'A'.repeat(150),
    description: 'Example description.',
    datePublished: '2026-03-01',
    author: authors.editorial!,
  });

  test('truncates headline to the rich-result limit', () => {
    assert.equal(String(article['headline']).length, 110);
  });

  test('defaults dateModified to datePublished', () => {
    assert.equal(article['dateModified'], '2026-03-01');
  });

  test('publisher references the organization node', () => {
    assert.deepEqual(article['publisher'], { '@id': schemaIds.organization });
  });
});

describe('buildOffers — fabrication guard', () => {
  test('drops unverified (placeholder) prices entirely', () => {
    const offers = buildOffers([
      { name: 'Starter', price: 29, currency: 'USD', billingPeriod: 'month', verified: false },
      { name: 'Growth', price: 99, currency: 'USD', billingPeriod: 'month', verified: false },
    ]);
    assert.equal(offers, undefined, 'placeholder pricing must never reach structured data');
  });

  test('publishes only verified prices', () => {
    const offers = buildOffers([
      { name: 'Starter', price: 29, currency: 'USD', billingPeriod: 'month', verified: true },
      { name: 'Growth', price: 99, currency: 'USD', billingPeriod: 'month', verified: false },
    ]);
    assert.equal(offers?.length, 1);
    assert.equal((offers?.[0] as { name: string }).name, 'Starter');
  });

  test('software schema omits offers when none are verified', () => {
    const software = softwareApplicationSchema({
      applicationCategory: 'BusinessApplication',
      operatingSystem: 'Web',
      featureList: ['SEO', 'AEO'],
      offers: buildOffers([
        { name: 'Starter', price: 29, currency: 'USD', billingPeriod: 'month', verified: false },
      ]),
    });
    assert.equal(software['offers'], undefined);
    assert.equal(software['aggregateRating'], undefined);
    assert.equal(software['review'], undefined);
  });
});

describe('graph assembly', () => {
  test('drops null and empty nodes', () => {
    const graph = buildGraph([organizationSchema(), null, undefined, {}]);
    assert.equal((graph['@graph'] as unknown[]).length, 1);
  });

  test('serialisation escapes angle brackets for safe inline injection', () => {
    const serialized = serializeJsonLd(buildGraph([{ '@type': 'Thing', name: '</script><b>x' }]));
    assert.ok(!serialized.includes('</script>'));
    assert.ok(serialized.includes('\\u003c'));
  });

  test('serialised output round-trips to the same data', () => {
    const graph = buildGraph([organizationSchema(), webSiteSchema()]);
    const parsed = JSON.parse(serializeJsonLd(graph).replace(/\\u003c/g, '<').replace(/\\u003e/g, '>'));
    assert.equal(parsed['@context'], 'https://schema.org');
    assert.equal(parsed['@graph'].length, 2);
  });
});

describe('generated schema passes our own validator (dogfooding)', () => {
  test('a full home-page graph validates with zero errors', () => {
    const graph = buildGraph([
      organizationSchema(),
      webSiteSchema(),
      webPageSchema({ path: '/', name: 'Home', description: 'Home page description.' }),
      breadcrumbSchema('/'),
      softwareApplicationSchema({
        applicationCategory: 'BusinessApplication',
        operatingSystem: 'Web',
        featureList: ['SEO', 'AEO', 'Content'],
      }),
    ]);
    const report = validateJsonLd(JSON.stringify(graph));
    const errors = report.messages.filter((m) => m.severity === 'error');
    assert.deepEqual(errors, [], errors.map((e) => `${e.path}: ${e.message}`).join('\n'));
    assert.equal(report.valid, true);
  });

  test('an FAQ page graph validates with zero errors', () => {
    const graph = buildGraph([
      webPageSchema({ path: '/faq', name: 'FAQ', description: 'Questions and answers.' }),
      breadcrumbSchema('/faq'),
      faqPageSchema('/faq', [
        { question: 'What is SeSha?', answer: 'An AI-assisted marketing workspace.' },
      ]),
    ]);
    const report = validateJsonLd(JSON.stringify(graph));
    assert.equal(report.counts.errors, 0, JSON.stringify(report.messages, null, 2));
  });
});
