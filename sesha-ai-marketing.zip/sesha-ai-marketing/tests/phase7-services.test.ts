import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { signUp, toRole } from '../src/lib/auth/service';
import { completeOnboarding } from '../src/lib/workspace/service';
import type { TenantContext } from '../src/lib/tenant';

import { PLAN_DEFINITIONS } from '../src/content/plans';
import { entitlementFor, overridesFor, planOf } from '../src/lib/plans/service';
import { QuotaExceededError, enforce, enforceOrThrow, writeAccess } from '../src/lib/quota/service';
import { isDenied } from '../src/lib/quota';
import { dashboard, record, usedFor } from '../src/lib/usage/service';
import { periodStartOf } from '../src/lib/usage/metrics';
import {
  BillingError,
  applyWebhook,
  billingView,
  cancel,
  changePlan,
  startCheckout,
} from '../src/lib/billing/service';
import { PAST_DUE_GRACE_DAYS, nullProvider, type PaymentProvider } from '../src/lib/billing/types';
import { decide, isEnabled } from '../src/lib/flags/service';
import {
  AdminAuthorizationError,
  type StaffContext,
} from '../src/lib/admin/auth';
import {
  grantStaff,
  health,
  listAdminActions,
  listFlags,
  listOrganizations,
  organizationDetail,
  overview,
  revokeStaff,
  setFlagRule,
  setLimitOverride,
  setPlan,
  setSetting,
  settingValue,
  staffFor,
} from '../src/lib/admin/service';

/**
 * Phase 7 services against the in-memory database.
 *
 * The seams the unit tests cannot reach: that a limit is really enforced end to
 * end, that a refusal is really recorded, that a webhook really is idempotent,
 * that an admin read is really audited, and that an organization admin really
 * cannot reach the admin panel.
 */

const PASSWORD = 'a genuinely long passphrase 2026';

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: 'https://acme-coffee.example.com',
};

const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic'] as const,
  marketingChannels: ['organic-search'] as const,
  brandVoice: { tones: ['friendly'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters' }],
};

let db: MemoryDatabase;
let tenant: TenantContext;
let projectId: string;
const ctx = () => ({ db, now: () => new Date() });

async function makeTenant(email: string): Promise<{ tenant: TenantContext; projectId: string; userId: string }> {
  const signed = await signUp(
    { db, lockout: new MemoryLockoutStore(), secret: 'test-secret-value-at-least-32-bytes-long' },
    { email, password: PASSWORD },
  );
  if (!signed.ok || !signed.userId) throw new Error('signup failed');
  const memberships = await db.memberships.findForUser(signed.userId);
  const context: TenantContext = {
    userId: signed.userId,
    organizationId: memberships[0]!.organizationId,
    role: toRole(memberships[0]!.role),
  };
  const onboarded = await completeOnboarding({ db }, context, { business, profile });
  return { tenant: context, projectId: onboarded.project.id, userId: signed.userId };
}

async function makeStaff(role: StaffContext['role'], sudo = true): Promise<StaffContext> {
  const made = await makeTenant(`staff-${Math.random().toString(36).slice(2)}@sesha.example`);
  await db.platformStaff.grant({
    userId: made.userId,
    role,
    grantedBy: made.userId,
    reason: 'Test fixture.',
    at: new Date(),
  });
  const staff = await staffFor(
    ctx(),
    { id: made.userId, email: 'staff@sesha.example' },
    { id: 'session-1', sudo, ipHash: null },
  );
  if (!staff) throw new Error('staff not resolved');
  return staff;
}

beforeEach(async () => {
  db = new MemoryDatabase();
  const made = await makeTenant(`p7-${Math.random().toString(36).slice(2)}@example.com`);
  tenant = made.tenant;
  projectId = made.projectId;
});

/* -------------------------------------------------------------------------- */
/* Entitlement                                                                */
/* -------------------------------------------------------------------------- */

describe('entitlement', () => {
  test('a new organization is on free and may write', async () => {
    const entitlement = await entitlementFor(ctx(), tenant.organizationId);
    assert.equal(entitlement.plan, 'free');
    assert.equal(entitlement.writable, true);
    assert.equal(entitlement.limits.projects.value, PLAN_DEFINITIONS.free.limits.projects);
  });

  test('an admin override changes the effective limit and names its reason', async () => {
    await db.planLimits.set(tenant.organizationId, 'projects', 40, 'Migration.', null, new Date());
    const entitlement = await entitlementFor(ctx(), tenant.organizationId);
    assert.equal(entitlement.limits.projects.value, 40);
    assert.equal(entitlement.limits.projects.source, 'override');
    assert.equal(entitlement.limits.projects.override?.reason, 'Migration.');
  });

  test('a stored override that is not a sane limit is ignored, not applied', async () => {
    // A negative ceiling would refuse every request with a message nobody can
    // act on. The plan default is the better answer.
    await db.planLimits.set(tenant.organizationId, 'projects', -5, 'Typo.', null, new Date());
    const overrides = await overridesFor(ctx(), tenant.organizationId);
    assert.equal(overrides.length, 0);
    const entitlement = await entitlementFor(ctx(), tenant.organizationId);
    assert.equal(entitlement.limits.projects.source, 'plan');
  });

  test('a cancelled subscription is readable but not writable', async () => {
    await db.subscriptions.update(tenant.organizationId, { status: 'canceled' });
    const entitlement = await entitlementFor(ctx(), tenant.organizationId);
    assert.equal(entitlement.writable, false);
    assert.match(entitlement.blockedReason ?? '', /still here and still exports/);
  });

  test('a failed payment inside the grace window still writes', async () => {
    await db.subscriptions.update(tenant.organizationId, {
      status: 'past_due',
      pastDueSince: new Date(Date.now() - (PAST_DUE_GRACE_DAYS - 1) * 86_400_000),
    });
    assert.equal((await entitlementFor(ctx(), tenant.organizationId)).writable, true);
  });

  test('a failed payment past the grace window stops writes', async () => {
    await db.subscriptions.update(tenant.organizationId, {
      status: 'past_due',
      pastDueSince: new Date(Date.now() - (PAST_DUE_GRACE_DAYS + 2) * 86_400_000),
    });
    const access = await writeAccess(ctx(), tenant.organizationId);
    assert.equal(access.writable, false);
    assert.match(access.reason ?? '', /Everything you have is still here/);
  });

  test('an unrecognised stored plan falls back to free rather than throwing', async () => {
    // A rolling deploy can write an old spelling. A screen that throws on an
    // unexpected plan breaks for the customer mid-migration.
    await db.subscriptions.update(tenant.organizationId, {
      plan: 'enterprise' as 'free',
    });
    assert.equal(planOf(await db.subscriptions.findForOrganization(tenant.organizationId)), 'free');
  });

  test('a legacy plan spelling still resolves upward', async () => {
    await db.subscriptions.update(tenant.organizationId, { plan: 'growth' as 'business' });
    const entitlement = await entitlementFor(ctx(), tenant.organizationId);
    assert.equal(entitlement.plan, 'business');
  });
});

/* -------------------------------------------------------------------------- */
/* Usage and quota                                                            */
/* -------------------------------------------------------------------------- */

describe('usage recording', () => {
  test('records against the current billing period', async () => {
    await record(ctx(), { organizationId: tenant.organizationId, metric: 'ai_generation' });
    await record(ctx(), { organizationId: tenant.organizationId, metric: 'ai_generation' });
    const used = await usedFor(
      ctx(),
      tenant.organizationId,
      'ai_requests',
      periodStartOf(new Date()),
    );
    assert.equal(used, 2);
  });

  test('a bulk quantity is recorded as a quantity, not as rows', async () => {
    await record(ctx(), { organizationId: tenant.organizationId, metric: 'ai_tokens', quantity: 4_000 });
    assert.equal(
      await usedFor(ctx(), tenant.organizationId, 'tokens', periodStartOf(new Date())),
      4_000,
    );
  });

  test('the legacy audit metric cannot be written', async () => {
    await assert.rejects(
      () => record(ctx(), { organizationId: tenant.organizationId, metric: 'audit_run' }),
      /not a metric that may be written/,
    );
  });

  test('SEO and AEO audits are counted independently', async () => {
    await record(ctx(), { organizationId: tenant.organizationId, metric: 'seo_audit' });
    const period = periodStartOf(new Date());
    assert.equal(await usedFor(ctx(), tenant.organizationId, 'seo_audits', period), 1);
    assert.equal(
      await usedFor(ctx(), tenant.organizationId, 'aeo_audits', period),
      0,
      'spending the SEO allowance must not spend the AEO one',
    );
  });

  test('an absolute limit counts live rows, not usage history', async () => {
    // The project created by onboarding.
    assert.equal(await usedFor(ctx(), tenant.organizationId, 'projects', periodStartOf(new Date())), 1);
    assert.equal(await usedFor(ctx(), tenant.organizationId, 'team_members', periodStartOf(new Date())), 1);
  });
});

describe('the quota gate', () => {
  test('allows inside the limit and refuses at it', async () => {
    const limit = PLAN_DEFINITIONS.free.limits.ai_requests as number;
    for (let index = 0; index < limit; index += 1) {
      const decision = await enforce(ctx(), tenant.organizationId, 'ai_requests');
      assert.ok(decision.allowed, `request ${index} was refused early`);
      await record(ctx(), { organizationId: tenant.organizationId, metric: 'ai_generation' });
    }
    const denied = await enforce(ctx(), tenant.organizationId, 'ai_requests');
    assert.ok(isDenied(denied));
    assert.equal(denied.reason, 'period_exhausted');
  });

  test('records every refusal, with the usage frozen at that moment', async () => {
    await db.planLimits.set(tenant.organizationId, 'reports', 0, 'Not on this plan.', null, new Date());
    const denied = await enforce(ctx(), tenant.organizationId, 'reports');
    assert.ok(isDenied(denied));

    const refusals = await db.quotaRefusals.listForOrganization(tenant.organizationId);
    assert.equal(refusals.length, 1);
    assert.equal(refusals[0]?.limitId, 'reports');
    assert.equal(refusals[0]?.reason, 'not_included');
    assert.equal(refusals[0]?.limitAtRefusal, 0);
    assert.equal(refusals[0]?.plan, 'free');
  });

  test('a later limit change does not rewrite why someone was blocked', async () => {
    await db.planLimits.set(tenant.organizationId, 'reports', 0, 'x', null, new Date());
    await enforce(ctx(), tenant.organizationId, 'reports');
    await db.planLimits.set(tenant.organizationId, 'reports', 500, 'Upgraded.', null, new Date());

    const refusals = await db.quotaRefusals.listForOrganization(tenant.organizationId);
    assert.equal(refusals[0]?.limitAtRefusal, 0, 'the history says what the limit was at the time');
  });

  test('a dry run does not record a refusal', async () => {
    await db.planLimits.set(tenant.organizationId, 'reports', 0, 'x', null, new Date());
    await enforce(ctx(), tenant.organizationId, 'reports', { record: false });
    assert.equal((await db.quotaRefusals.listForOrganization(tenant.organizationId)).length, 0);
  });

  test('a blocked subscription refuses before any limit is measured', async () => {
    await db.subscriptions.update(tenant.organizationId, { status: 'canceled' });
    const denied = await enforce(ctx(), tenant.organizationId, 'ai_requests');
    assert.ok(isDenied(denied));
    assert.equal(denied.reason, 'subscription_blocked');
  });

  test('enforceOrThrow carries the whole decision', async () => {
    await db.planLimits.set(tenant.organizationId, 'reports', 0, 'x', null, new Date());
    await assert.rejects(
      () => enforceOrThrow(ctx(), tenant.organizationId, 'reports'),
      (error: unknown) => {
        assert.ok(error instanceof QuotaExceededError);
        assert.equal(error.decision.limitId, 'reports');
        assert.equal(error.decision.reason, 'not_included');
        return true;
      },
    );
  });

  test('a bulk amount is budgeted before the work', async () => {
    const limit = PLAN_DEFINITIONS.free.limits.tokens as number;
    const decision = await enforce(ctx(), tenant.organizationId, 'tokens', { amount: limit + 1 });
    assert.ok(isDenied(decision));
    assert.match(decision.message, /more than the/);
  });
});

describe('the usage dashboard', () => {
  test('covers every limit and the eight tracked metrics', async () => {
    const entitlement = await entitlementFor(ctx(), tenant.organizationId);
    const view = await dashboard(ctx(), tenant.organizationId, entitlement.plan, entitlement.limits);
    assert.equal(view.limits.length, 11);
    assert.equal(view.tracked.length, 9, 'the eight named things, with SEO and AEO audits separate');
    assert.match(view.resetsAt, /^\d{4}-\d{2}-01T00:00:00\.000Z$/);
  });

  test('reports pressure once a limit is close', async () => {
    const limit = PLAN_DEFINITIONS.free.limits.ai_requests as number;
    for (let index = 0; index < limit; index += 1) {
      await record(ctx(), { organizationId: tenant.organizationId, metric: 'ai_generation' });
    }
    const entitlement = await entitlementFor(ctx(), tenant.organizationId);
    const view = await dashboard(ctx(), tenant.organizationId, entitlement.plan, entitlement.limits);
    assert.ok(view.pressure.some((status) => status.limit.id === 'ai_requests'));
    assert.ok(view.pressure[0]?.exhausted);
  });

  test('shows recent refusals so "why was I blocked" has an answer', async () => {
    await db.planLimits.set(tenant.organizationId, 'reports', 0, 'x', null, new Date());
    await enforce(ctx(), tenant.organizationId, 'reports');
    const entitlement = await entitlementFor(ctx(), tenant.organizationId);
    const view = await dashboard(ctx(), tenant.organizationId, entitlement.plan, entitlement.limits);
    assert.equal(view.recentRefusals.length, 1);
  });
});

/* -------------------------------------------------------------------------- */
/* Billing                                                                    */
/* -------------------------------------------------------------------------- */

describe('billing with no provider connected', () => {
  test('the view says so, and offers no checkout', async () => {
    const view = await billingView(ctx(), tenant);
    assert.equal(view.provider.configured, false);
    assert.match(view.provider.message, /No payment provider is connected/);
    assert.match(view.provider.message, /Plan limits still apply/);
  });

  test('starting a checkout is refused with a reason, not a crash', async () => {
    await assert.rejects(
      () => startCheckout(ctx(), tenant, 'pro', 'https://app.example.com/billing'),
      (error: unknown) => {
        assert.ok(error instanceof BillingError);
        // The refusal comes from `billingStatus()`, the gate every screen reads,
        // not from the provider stub. Both say nothing is charged; the first
        // version of this looked for the provider's exact wording.
        assert.match(error.message, /nothing can be charged/);
        assert.match(error.message, /Plan limits still apply/);
        return true;
      },
    );
  });

  test('an upgrade is refused without a provider', async () => {
    await assert.rejects(() => changePlan(ctx(), tenant, 'business'), BillingError);
  });

  test('a downgrade to free IS applied immediately', async () => {
    // It takes money away from us, not from the customer, so there is nobody to
    // defraud and no reason to make them wait.
    await db.subscriptions.update(tenant.organizationId, { plan: 'business' });
    const result = await changePlan(ctx(), tenant, 'free');
    assert.equal(result.applied, true);
    assert.equal(result.plan, 'free');
    assert.match(result.message, /Nothing has been deleted/);
    assert.equal(planOf(await db.subscriptions.findForOrganization(tenant.organizationId)), 'free');
  });

  test('a downgrade that puts them over a limit deletes nothing', async () => {
    await db.subscriptions.update(tenant.organizationId, { plan: 'business' });
    const { createProject } = await import('../src/lib/workspace/service');
    await createProject({ db }, tenant, { name: 'Second' });
    await createProject({ db }, tenant, { name: 'Third' });

    await changePlan(ctx(), tenant, 'free');

    const projects = await db.projects.listForOrganization(tenant.organizationId);
    assert.equal(projects.length, 3, 'nothing was deleted');

    // And new work is refused until they are back inside the limit.
    const decision = await enforce(ctx(), tenant.organizationId, 'projects');
    assert.ok(isDenied(decision));
    assert.equal(decision.reason, 'at_capacity');
  });

  test('cancelling schedules the end of the period and keeps everything', async () => {
    const result = await cancel(ctx(), tenant);
    assert.match(result.message, /Cancellation scheduled/);
    const subscription = await db.subscriptions.findForOrganization(tenant.organizationId);
    assert.equal(subscription?.cancelAtPeriodEnd, true);
    assert.notEqual(subscription?.status, 'canceled', 'they have paid to the end of the period');
  });

  test('cancelling immediately still keeps the data', async () => {
    const result = await cancel(ctx(), tenant, true);
    assert.match(result.message, /still here and still exports/);
    const subscription = await db.subscriptions.findForOrganization(tenant.organizationId);
    assert.equal(subscription?.status, 'canceled');
    const projects = await db.projects.listForOrganization(tenant.organizationId);
    assert.equal(projects.length, 1);
  });
});

describe('webhooks', () => {
  test('a payment failure opens the grace window', async () => {
    const outcome = await applyWebhook(ctx(), {
      organizationId: tenant.organizationId,
      event: 'payment_failed',
      externalEventId: 'evt_1',
    });
    assert.ok(outcome.ok && outcome.applied);
    const subscription = await db.subscriptions.findForOrganization(tenant.organizationId);
    assert.equal(subscription?.status, 'past_due');
    assert.ok(subscription?.pastDueSince);
  });

  test('a repeated failure does NOT restart the grace window', async () => {
    // A provider retrying a declined card daily would otherwise extend the
    // window forever and the account would never be paused.
    await applyWebhook(ctx(), {
      organizationId: tenant.organizationId,
      event: 'payment_failed',
      externalEventId: 'evt_1',
    });
    const first = (await db.subscriptions.findForOrganization(tenant.organizationId))?.pastDueSince;

    await applyWebhook(ctx(), {
      organizationId: tenant.organizationId,
      event: 'payment_failed',
      externalEventId: 'evt_2',
    });
    const second = (await db.subscriptions.findForOrganization(tenant.organizationId))?.pastDueSince;
    assert.equal(first?.getTime(), second?.getTime());
  });

  test('recovery clears the grace window', async () => {
    await applyWebhook(ctx(), {
      organizationId: tenant.organizationId,
      event: 'payment_failed',
      externalEventId: 'evt_1',
    });
    await applyWebhook(ctx(), {
      organizationId: tenant.organizationId,
      event: 'payment_succeeded',
      externalEventId: 'evt_2',
    });
    const subscription = await db.subscriptions.findForOrganization(tenant.organizationId);
    assert.equal(subscription?.status, 'active');
    assert.equal(subscription?.pastDueSince, null);
  });

  test('IS IDEMPOTENT — a retried event is not applied twice', async () => {
    await applyWebhook(ctx(), {
      organizationId: tenant.organizationId,
      event: 'payment_failed',
      externalEventId: 'evt_same',
    });
    const replay = await applyWebhook(ctx(), {
      organizationId: tenant.organizationId,
      event: 'payment_failed',
      externalEventId: 'evt_same',
    });
    assert.ok(replay.ok);
    assert.equal(replay.applied, false);
    assert.match(replay.note ?? '', /Already processed/);
    assert.equal((await db.billingEvents.listForOrganization(tenant.organizationId)).length, 1);
  });

  test('an out-of-order event is recorded as not applied, with a reason', async () => {
    const outcome = await applyWebhook(ctx(), {
      organizationId: tenant.organizationId,
      event: 'renewed',
      externalEventId: 'evt_odd',
    });
    assert.ok(outcome.ok);
    const events = await db.billingEvents.listForOrganization(tenant.organizationId);
    assert.equal(events.length, 1);
    assert.ok((events[0]?.note ?? '').length > 10, 'an ignored webhook must be visible, not silent');
  });

  test('a plan change from a webhook is applied', async () => {
    const outcome = await applyWebhook(ctx(), {
      organizationId: tenant.organizationId,
      event: 'plan_changed',
      externalEventId: 'evt_plan',
      plan: 'business',
    });
    assert.ok(outcome.ok && outcome.applied);
    assert.equal(planOf(await db.subscriptions.findForOrganization(tenant.organizationId)), 'business');
  });

  test('only display metadata is stored for a payment method', async () => {
    await applyWebhook(ctx(), {
      organizationId: tenant.organizationId,
      event: 'checkout_completed',
      externalEventId: 'evt_pm',
      paymentMethod: { brand: 'visa', last4: '4242', expiryMonth: 11, expiryYear: 2030 },
    });
    const subscription = await db.subscriptions.findForOrganization(tenant.organizationId);
    assert.equal(subscription?.paymentLast4, '4242');
    assert.equal(subscription?.paymentBrand, 'visa');
    const serialised = JSON.stringify(subscription);
    assert.ok(!/cardNumber|cvv|token/i.test(serialised));
  });

  test('a webhook for an unknown organization is refused', async () => {
    const outcome = await applyWebhook(ctx(), {
      organizationId: 'does-not-exist',
      event: 'payment_succeeded',
      externalEventId: 'evt_x',
    });
    assert.equal(outcome.ok, false);
  });
});

describe('a configured provider', () => {
  const provider: PaymentProvider = {
    ...nullProvider,
    name: 'test-provider',
    configured: true,
    createCheckout: async () => ({
      ok: true,
      value: { url: 'https://provider.example/checkout/1', externalId: 'cs_1', expiresAt: '2026-04-01T00:00:00.000Z' },
    }),
  };

  test('can start a checkout, and nothing local changes yet', async () => {
    const result = await startCheckout(
      { db, provider },
      tenant,
      'pro',
      'https://app.example.com/billing',
    );
    assert.match(result.url, /provider\.example/);
    // The customer has not paid. A row that said otherwise is the bug the
    // billing service is arranged to avoid.
    assert.equal(planOf(await db.subscriptions.findForOrganization(tenant.organizationId)), 'free');
  });

  test('refuses a checkout for a plan that needs no payment', async () => {
    await assert.rejects(
      () => startCheckout({ db, provider }, tenant, 'free', 'https://app.example.com/billing'),
      /nothing to check out/,
    );
  });
});

/* -------------------------------------------------------------------------- */
/* Feature flags                                                              */
/* -------------------------------------------------------------------------- */

describe('feature flags against the database', () => {
  test('an absent rule gives the declared default', async () => {
    assert.equal(await isEnabled(ctx(), 'module.crawler', { organizationId: tenant.organizationId, plan: 'free' }), true);
    assert.equal(await isEnabled(ctx(), 'beta.report_sharing', { organizationId: tenant.organizationId, plan: 'free' }), false);
  });

  test('a stored rule is honoured, and the decision says which rule', async () => {
    await db.featureFlags.upsert({
      key: 'beta.report_sharing',
      disabled: false,
      organizationIds: [tenant.organizationId],
      excludedOrganizationIds: [],
      plans: [],
      rolloutPercent: 0,
      updatedBy: null,
    });
    const decision = await decide(ctx(), 'beta.report_sharing', {
      organizationId: tenant.organizationId,
      plan: 'free',
    });
    assert.equal(decision.enabled, true);
    assert.equal(decision.because, 'organization_included');
  });

  test('the kill switch beats a named organization', async () => {
    await db.featureFlags.upsert({
      key: 'module.crawler',
      disabled: true,
      organizationIds: [tenant.organizationId],
      excludedOrganizationIds: [],
      plans: ['free', 'pro', 'business', 'agency'],
      rolloutPercent: 100,
      updatedBy: null,
    });
    const decision = await decide(ctx(), 'module.crawler', {
      organizationId: tenant.organizationId,
      plan: 'free',
    });
    assert.equal(decision.enabled, false);
    assert.equal(decision.because, 'kill_switch');
  });
});

/* -------------------------------------------------------------------------- */
/* Admin                                                                      */
/* -------------------------------------------------------------------------- */

describe('admin access', () => {
  test('an ordinary user resolves to no staff context', async () => {
    const staff = await staffFor(
      ctx(),
      { id: tenant.userId, email: 'customer@example.com' },
      { id: 's', sudo: true, ipHash: null },
    );
    assert.equal(staff, null);
  });

  test('AN ORGANIZATION ADMIN IS REFUSED BY THE ADMIN PANEL', async () => {
    // The most expensive mistake available in this phase, asserted end to end:
    // this user has the highest ORGANIZATION role and no platform access.
    assert.equal(tenant.role, 'admin');
    await assert.rejects(() => overview(ctx(), null), AdminAuthorizationError);
    const staff = await staffFor(
      ctx(),
      { id: tenant.userId, email: 'customer@example.com' },
      { id: 's', sudo: true, ipHash: null },
    );
    await assert.rejects(() => overview(ctx(), staff), AdminAuthorizationError);
  });

  test('a revoked staff row grants nothing, immediately', async () => {
    const staff = await makeStaff('engineer');
    await db.platformStaff.revoke(staff.userId, staff.userId, new Date());
    const again = await staffFor(
      ctx(),
      { id: staff.userId, email: staff.email },
      { id: 's', sudo: true, ipHash: null },
    );
    assert.equal(again, null);
  });

  test('support can read and cannot write', async () => {
    const support = await makeStaff('support');
    await listOrganizations(ctx(), support);
    await assert.rejects(
      () => setLimitOverride(ctx(), support, tenant.organizationId, 'projects', 9, 'x'),
      AdminAuthorizationError,
    );
  });

  test('a write without sudo is refused', async () => {
    const engineer = await makeStaff('engineer', false);
    await assert.rejects(
      () => setLimitOverride(ctx(), engineer, tenant.organizationId, 'projects', 9, 'why'),
      (error: unknown) => {
        assert.ok(error instanceof AdminAuthorizationError);
        assert.equal(error.needsSudo, true);
        return true;
      },
    );
  });

  test('only a platform owner may grant staff access', async () => {
    const engineer = await makeStaff('engineer');
    const target = await makeTenant('newstaff@sesha.example');
    await assert.rejects(
      () => grantStaff(ctx(), engineer, target.userId, 'support', 'Joining support.'),
      AdminAuthorizationError,
    );

    const owner = await makeStaff('platform_owner');
    await grantStaff(ctx(), owner, target.userId, 'support', 'Joining support.');
    const row = await db.platformStaff.findByUser(target.userId);
    assert.equal(row?.role, 'support');
  });

  test('the last platform owner cannot revoke themselves', async () => {
    const owner = await makeStaff('platform_owner');
    await assert.rejects(
      () => revokeStaff(ctx(), owner, owner.userId),
      /last platform owner/,
    );
  });

  test('re-granting clears a revocation rather than leaving a contradictory row', async () => {
    const owner = await makeStaff('platform_owner');
    const target = await makeTenant('rejoin@sesha.example');
    await grantStaff(ctx(), owner, target.userId, 'support', 'First time.');
    await revokeStaff(ctx(), owner, target.userId);
    await grantStaff(ctx(), owner, target.userId, 'engineer', 'Rejoined.');

    const row = await db.platformStaff.findByUser(target.userId);
    assert.equal(row?.revokedAt, null, 'a granted-and-revoked row would read as revoked');
    assert.equal(row?.role, 'engineer');
  });
});

describe('every admin action is audited', () => {
  test('a READ is recorded, not just a write', async () => {
    const staff = await makeStaff('support');
    await listOrganizations(ctx(), staff, { query: 'acme' });
    const actions = await db.adminActions.list({ kind: 'read' });
    const entry = actions.find((row) => row.action === 'admin.organizations.list');
    assert.ok(entry, '"who looked at which customer" needs read auditing');
    assert.equal(entry.staffUserId, staff.userId);
    assert.equal(entry.outcome, 'success');
    // The search term is recorded so someone fishing for a named customer
    // leaves a trace.
    assert.equal((entry.metadata as { query?: string }).query, 'acme');
  });

  test('reading one organization records which organization', async () => {
    const staff = await makeStaff('support');
    await organizationDetail(ctx(), staff, tenant.organizationId);
    const actions = await db.adminActions.list({ targetOrganizationId: tenant.organizationId });
    assert.ok(actions.some((row) => row.action === 'admin.organization.read'));
  });

  test('A REFUSAL IS RECORDED AS DENIED', async () => {
    // The events most worth auditing are the ones that failed.
    const support = await makeStaff('support');
    await assert.rejects(() =>
      setLimitOverride(ctx(), support, tenant.organizationId, 'projects', 9, 'x'),
    );
    const actions = await db.adminActions.list({});
    const denied = actions.find((row) => row.outcome === 'denied');
    assert.ok(denied);
    assert.equal(denied.permission, 'admin:limits:write');
  });

  test('a write is recorded with what changed', async () => {
    const engineer = await makeStaff('engineer');
    await setLimitOverride(ctx(), engineer, tenant.organizationId, 'projects', 12, 'Agreed with sales.');
    const actions = await db.adminActions.list({ kind: 'write' });
    const entry = actions.find((row) => row.action === 'admin.limit.set');
    assert.ok(entry);
    assert.equal((entry.metadata as { value?: number }).value, 12);
    assert.equal((entry.metadata as { reason?: string }).reason, 'Agreed with sales.');
  });

  test('reading the audit log itself requires sudo', async () => {
    const engineer = await makeStaff('engineer', false);
    await assert.rejects(() => listAdminActions(ctx(), engineer), AdminAuthorizationError);
    const withSudo = await makeStaff('engineer', true);
    await listAdminActions(ctx(), withSudo);
  });
});

describe('admin controls', () => {
  test('an override set from the panel takes effect on the enforcement path', async () => {
    const engineer = await makeStaff('engineer');
    await setLimitOverride(ctx(), engineer, tenant.organizationId, 'reports', 0, 'Suspected abuse.');
    const decision = await enforce(ctx(), tenant.organizationId, 'reports');
    assert.ok(isDenied(decision));
    assert.equal(decision.reason, 'not_included');
  });

  test('an override without a reason is refused', async () => {
    const engineer = await makeStaff('engineer');
    await assert.rejects(
      () => setLimitOverride(ctx(), engineer, tenant.organizationId, 'projects', 9, '   '),
      /Say why/,
    );
  });

  test('changing a plan from the panel records why', async () => {
    const engineer = await makeStaff('engineer');
    await setPlan(ctx(), engineer, tenant.organizationId, 'business', 'Agreed on a call.');
    assert.equal(planOf(await db.subscriptions.findForOrganization(tenant.organizationId)), 'business');
    const events = await db.billingEvents.listForOrganization(tenant.organizationId);
    assert.match(events[0]?.note ?? '', /Agreed on a call/);
  });

  test('a flag rule set from the panel is honoured', async () => {
    const engineer = await makeStaff('engineer');
    await setFlagRule(ctx(), engineer, { key: 'beta.report_sharing', plans: ['free'] });
    assert.equal(
      await isEnabled(ctx(), 'beta.report_sharing', { organizationId: tenant.organizationId, plan: 'free' }),
      true,
    );
  });

  test('an invalid flag rule is refused', async () => {
    const engineer = await makeStaff('engineer');
    await assert.rejects(
      () => setFlagRule(ctx(), engineer, { key: 'beta.report_sharing', rolloutPercent: 140 }),
      /between 0 and 100/,
    );
    await assert.rejects(() => setFlagRule(ctx(), engineer, { key: 'made.up' }), /not a flag/);
  });

  test('flags are listed with their availability, not just their state', async () => {
    const staff = await makeStaff('support');
    const flags = await listFlags(ctx(), staff);
    const checkout = flags.find((flag) => flag.key === 'plan.self_serve_checkout');
    assert.equal(checkout?.available, false);
    assert.match(checkout?.unavailableReason ?? '', /No payment provider is connected/);
  });

  test('a setting is validated, stored and read back', async () => {
    const engineer = await makeStaff('engineer');
    await setSetting(ctx(), engineer, 'system.banner', '  Maintenance at 22:00 IST.  ');
    assert.equal(await settingValue(ctx(), 'system.banner'), 'Maintenance at 22:00 IST.');
  });

  test('a setting that can only be narrowed refuses to be widened', async () => {
    const engineer = await makeStaff('engineer');
    await setSetting(ctx(), engineer, 'crawler.max_pages_ceiling', 100);
    assert.equal(await settingValue(ctx(), 'crawler.max_pages_ceiling'), 100);
    await assert.rejects(
      () => setSetting(ctx(), engineer, 'crawler.max_pages_ceiling', 5_000),
      /only be lowered/,
    );
  });

  test('an unknown setting is refused', async () => {
    const engineer = await makeStaff('engineer');
    await assert.rejects(() => setSetting(ctx(), engineer, 'made.up', 1), /not a setting/);
  });
});

describe('system health reports only what it can measure', () => {
  test('no uptime or latency figure is invented', async () => {
    const staff = await makeStaff('support');
    const report = await health(ctx(), staff);
    const serialised = JSON.stringify(report.checks);
    // Looks for an invented FIGURE, not for words. The first version used
    // /ms\b/ and matched the word "problems" — a check that fires on ordinary
    // English gets deleted rather than fixed.
    assert.ok(!/uptime/i.test(serialised), 'an uptime figure would be invented');
    assert.ok(!/\d+(\.\d+)?\s*%/.test(serialised), 'a percentage here would be invented');
    assert.ok(!/\d+\s*ms\b/i.test(serialised), 'a latency figure would be invented');
    assert.ok(!/all systems (are )?operational/i.test(serialised));
    assert.ok(report.notMeasured.length >= 3);
    assert.ok(report.notMeasured.some((entry) => /Uptime/.test(entry)));
  });

  test('reports the real adapter and the real secrets', async () => {
    const staff = await makeStaff('support');
    const report = await health(ctx(), staff);
    const database = report.checks.find((check) => check.id === 'database');
    assert.ok(database);
    assert.match(database.detail, /In-memory|PostgreSQL/);
  });
});

describe('the admin panel cannot reach customer content', () => {
  test('organization detail returns metadata, never content', async () => {
    const { createLead } = await import('../src/lib/leads/service');
    await createLead({ db }, tenant, {
      projectId,
      name: 'Priya Sharma',
      email: 'priya@customer.example',
      enquiry: 'A confidential enquiry about a merger.',
      source: 'website_form',
      optInBasis: 'enquiry_reply',
    });

    const staff = await makeStaff('platform_owner');
    const detail = await organizationDetail(ctx(), staff, tenant.organizationId);
    assert.ok(detail);

    const serialised = JSON.stringify(detail);
    assert.ok(!serialised.includes('confidential enquiry'), 'a lead body reached the admin panel');
    assert.ok(!serialised.includes('priya@customer.example'), 'a lead email reached the admin panel');
    // What it DOES have: the plan, the limits and who the members are.
    assert.equal(detail.plan, 'free');
    assert.equal(detail.limits.length, 11);
    assert.ok(detail.members.length > 0);
  });

  test('there is no admin read method that returns customer content', async () => {
    const methods = Object.keys(db.adminRead);
    for (const method of methods) {
      assert.ok(
        !/lead|content|article|report_body|message|strategy/i.test(method),
        `adminRead.${method} looks like it returns customer content`,
      );
    }
  });
});
