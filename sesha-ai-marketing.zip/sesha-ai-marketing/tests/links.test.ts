import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { test, describe } from 'node:test';

import { posts } from '../src/content/blog';
import { footerNav, flatNav, headerCta, primaryNav } from '../src/content/nav';
import { resourceCollections } from '../src/content/resources';
import { solutionList } from '../src/content/solutions';
import { isRegisteredRoute, normalizePath, routes } from '../src/lib/routes';
import { appRoutes } from '../src/content/app-nav';
import { adminRoutes } from '../src/content/admin-nav';

/**
 * Internal-link integrity.
 *
 * Every internal href anywhere in the codebase must resolve to a registered
 * route, a known blog post, or a same-page anchor. This is the check that makes
 * "no broken links" a build-time guarantee rather than a manual click-through.
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const srcDir = path.join(root, 'src');

function walk(dir: string): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir)) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) out.push(...walk(full));
    else if (/\.(ts|tsx)$/.test(entry)) out.push(full);
  }
  return out;
}

const sourceFiles = walk(srcDir);

/**
 * Valid link targets that are not entries in the PUBLIC route registry.
 *
 * Authenticated application routes are deliberately kept out of `lib/routes.ts`
 * so they never reach the sitemap or the marketing footer — but links to them
 * still have to resolve, so they are listed here.
 *
 * The admin routes are kept out for a stronger reason: the panel returns 404 to
 * anyone who is not platform staff, so a sitemap entry for it would advertise a
 * door that is meant to be invisible. `tests/admin-security.test.ts` asserts
 * that none of them appears in the public registry.
 */
const nonRouteTargets = new Set<string>([
  ...posts.map((post) => `/blog/${post.slug}`),
  ...appRoutes.map((route) => normalizePath(route)),
  ...adminRoutes.map((route) => normalizePath(route)),
  '/404',
  '/sitemap.xml',
  '/robots.txt',
]);

function isValidTarget(href: string): boolean {
  if (href.startsWith('#')) return true;
  if (href.startsWith('mailto:') || href.startsWith('tel:')) return true;
  if (/^https?:\/\//i.test(href)) return true;
  if (!href.startsWith('/')) return false;
  if (href.startsWith('/api/')) return true;

  const normalized = normalizePath(href);
  return isRegisteredRoute(normalized) || nonRouteTargets.has(normalized);
}

describe('navigation targets', () => {
  test('every primary nav link resolves', () => {
    for (const group of primaryNav) {
      if (group.href) {
        assert.ok(isRegisteredRoute(group.href), `nav group href ${group.href} is not a route`);
      }
      for (const link of group.links) {
        assert.ok(isRegisteredRoute(link.href), `nav link ${link.href} is not a route`);
      }
    }
  });

  test('every flat nav link and the header CTA resolve', () => {
    for (const link of flatNav) {
      assert.ok(isRegisteredRoute(link.href), `${link.href} is not a route`);
    }
    assert.ok(isRegisteredRoute(headerCta.href), `${headerCta.href} is not a route`);
  });

  test('every footer link resolves', () => {
    for (const group of footerNav) {
      for (const link of group.links) {
        assert.ok(isRegisteredRoute(link.href), `footer link ${link.href} is not a route`);
      }
    }
  });

  test('footer reaches every registered route (no orphan pages)', () => {
    const footerHrefs = new Set(footerNav.flatMap((g) => g.links.map((l) => normalizePath(l.href))));
    const navHrefs = new Set([
      ...primaryNav.flatMap((g) => [
        ...(g.href ? [normalizePath(g.href)] : []),
        ...g.links.map((l) => normalizePath(l.href)),
      ]),
      ...flatNav.map((l) => normalizePath(l.href)),
    ]);

    const reachable = new Set([...footerHrefs, ...navHrefs, '/']);
    const orphans = routes
      .map((r) => r.path)
      .filter((p) => !reachable.has(p))
      // Solution detail pages are reached from /solutions, which IS in the nav.
      .filter((p) => !p.startsWith('/solutions/'));

    assert.deepEqual(orphans, [], `orphaned routes: ${orphans.join(', ')}`);
  });
});

describe('content links', () => {
  test('every solution related-link resolves', () => {
    for (const solution of solutionList) {
      for (const link of solution.related) {
        assert.ok(isValidTarget(link.href), `${solution.slug} links to ${link.href}`);
      }
    }
  });

  test('every blog related-link resolves', () => {
    for (const post of posts) {
      for (const link of post.related) {
        assert.ok(isValidTarget(link.href), `${post.slug} links to ${link.href}`);
      }
    }
  });

  test('every resource item link resolves', () => {
    for (const collection of resourceCollections) {
      for (const item of collection.items) {
        assert.ok(isValidTarget(item.href), `${collection.id} links to ${item.href}`);
      }
    }
  });
});

describe('source-wide href scan', () => {
  const hrefPattern = /href=(?:"([^"]+)"|\{`([^`]+)`\}|'([^']+)')/g;

  test('every literal href in the codebase resolves', () => {
    const broken: string[] = [];

    for (const file of sourceFiles) {
      const contents = readFileSync(file, 'utf8');
      for (const match of contents.matchAll(hrefPattern)) {
        const raw = match[1] ?? match[2] ?? match[3];
        if (!raw) continue;
        // Skip template literals with interpolation — those are checked by the
        // typed content tests above.
        if (raw.includes('${')) continue;
        if (!isValidTarget(raw)) {
          broken.push(`${path.relative(root, file)} -> ${raw}`);
        }
      }
    }

    assert.deepEqual(broken, [], `broken internal links:\n${broken.join('\n')}`);
  });

  test('no hard-coded localhost or staging URLs', () => {
    const offenders: string[] = [];
    for (const file of sourceFiles) {
      const contents = readFileSync(file, 'utf8');
      // Some files legitimately contain these strings:
      //   · content/site.ts — the development fallback origin;
      //   · validation/onboarding.ts — the Phase 2 SSRF blocklist;
      //   · lib/crawler/ip-policy.ts, url-policy.ts, resolver.ts — the Phase 4
      //     address and URL policies, which must NAME the private hosts and
      //     ranges they refuse. A blocklist that cannot mention 127.0.0.1 is not
      //     a blocklist, and its tests must be able to assert on the names.
      //   · lib/schema-validator/datatypes.ts — the Phase 5 URL check, which
      //     recognises a localhost URL in the user's markup in order to tell them
      //     it must not be published. Same reasoning: a check for a string cannot
      //     avoid containing that string.
      // Everything else is held to the rule.
      const exempt = [
        path.join('content', 'site.ts'),
        path.join('validation', 'onboarding.ts'),
        path.join('crawler', 'ip-policy.ts'),
        path.join('crawler', 'url-policy.ts'),
        path.join('crawler', 'resolver.ts'),
        path.join('schema-validator', 'datatypes.ts'),
      ];
      if (exempt.some((suffix) => file.endsWith(suffix))) continue;
      if (/https?:\/\/localhost|127\.0\.0\.1|\.vercel\.app|staging\./i.test(contents)) {
        offenders.push(path.relative(root, file));
      }
    }
    assert.deepEqual(offenders, []);
  });
});

describe('route coverage in the app directory', () => {
  test('every registered route has a page file', () => {
    const missing: string[] = [];
    for (const route of routes) {
      if (route.path.startsWith('/solutions/') && route.path !== '/solutions') continue; // dynamic
      // Public pages live in the (marketing) route group, so the sign-in and
      // application layouts do not inherit marketing navigation.
      const segment = route.path === '/' ? '' : route.path.slice(1);
      const candidate = path.join(srcDir, 'app', '(marketing)', segment, 'page.tsx');
      try {
        statSync(candidate);
      } catch {
        missing.push(route.path);
      }
    }
    assert.deepEqual(missing, [], `routes without a page.tsx: ${missing.join(', ')}`);
  });

  test('the dynamic solution route exists', () => {
    statSync(path.join(srcDir, 'app', '(marketing)', 'solutions', '[slug]', 'page.tsx'));
  });

  test('the dynamic blog route exists', () => {
    statSync(path.join(srcDir, 'app', '(marketing)', 'blog', '[slug]', 'page.tsx'));
  });

  test('sitemap, robots and 404 exist', () => {
    statSync(path.join(srcDir, 'app', 'sitemap.ts'));
    statSync(path.join(srcDir, 'app', 'robots.ts'));
    statSync(path.join(srcDir, 'app', 'not-found.tsx'));
  });
});
