import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  AuthorizationError,
  PERMISSIONS,
  ROLES,
  can,
  hasAtLeast,
  isRole,
  minimumRoleFor,
  permissionsFor,
  requirePermission,
  type Permission,
  type Role,
} from '../src/lib/auth/rbac';
import {
  NotFoundError,
  assertProject,
  assertTenant,
  authorize,
  filterTenant,
  rlsStatement,
  tenantFilter,
  type TenantContext,
} from '../src/lib/tenant';
import {
  ACCOUNT_POLICY,
  ADDRESS_POLICY,
  MemoryLockoutStore,
  accountKey,
  addressKey,
} from '../src/lib/auth/lockout';
import {
  REFRESH_THRESHOLD_MS,
  createSessionRecord,
  hashIpAddress,
  isSudo,
  sessionCookieOptions,
  csrfCookieOptions,
  validateSessionRecord,
  type SessionRecord,
} from '../src/lib/auth/session';
import { SESSION_ABSOLUTE_LIFETIME, SESSION_IDLE_TIMEOUT } from '../src/lib/auth/tokens';

/* -------------------------------------------------------------------------- */
/* RBAC                                                                       */
/* -------------------------------------------------------------------------- */

describe('roles', () => {
  test('the four specified roles exist, in order', () => {
    assert.deepEqual([...ROLES], ['user', 'team_member', 'manager', 'admin']);
  });

  test('role inheritance is a total order', () => {
    assert.equal(hasAtLeast('admin', 'user'), true);
    assert.equal(hasAtLeast('manager', 'team_member'), true);
    assert.equal(hasAtLeast('team_member', 'manager'), false);
    assert.equal(hasAtLeast('user', 'user'), true);
  });

  test('isRole rejects anything unexpected', () => {
    assert.equal(isRole('admin'), true);
    assert.equal(isRole('superadmin'), false);
    assert.equal(isRole(''), false);
    assert.equal(isRole(null), false);
    assert.equal(isRole(42), false);
  });
});

describe('permissions', () => {
  test('every permission declares a minimum role', () => {
    const missing = PERMISSIONS.filter((p) => minimumRoleFor(p) === undefined);
    assert.deepEqual(missing, [], `permissions with no minimum role: ${missing.join(', ')}`);
  });

  test('an unknown permission is denied, never allowed by default', () => {
    assert.equal(can('admin', 'not:a:permission' as Permission), false);
  });

  test('admin holds every permission', () => {
    assert.equal(permissionsFor('admin').length, PERMISSIONS.length);
  });

  test('a plain user cannot mutate anything', () => {
    const mutations: Permission[] = [
      'project:create',
      'project:update',
      'project:delete',
      'business:update',
      'brand:update',
      'content:create',
      'content:publish',
      'campaign:manage',
      'lead:manage',
      'member:invite',
      'member:remove',
      'member:change_role',
      'billing:manage',
      'organization:update',
      'organization:delete',
      'crawl:request',
    ];
    for (const permission of mutations) {
      assert.equal(can('user', permission), false, `user must not hold ${permission}`);
    }
  });

  test('destructive and billing permissions are admin-only', () => {
    const adminOnly: Permission[] = [
      'project:delete',
      'member:remove',
      'member:change_role',
      'billing:manage',
      'organization:update',
      'organization:delete',
      'audit:read',
    ];
    for (const permission of adminOnly) {
      assert.equal(can('manager', permission), false, `manager must not hold ${permission}`);
      assert.equal(can('admin', permission), true);
    }
  });

  test('permissions are monotonic across the role order', () => {
    // If a lower role has a permission, every higher role must have it too.
    for (const permission of PERMISSIONS) {
      let seenGranted = false;
      for (const role of ROLES) {
        const granted = can(role, permission);
        if (seenGranted) {
          assert.equal(granted, true, `${permission} granted to a lower role but not to ${role}`);
        }
        if (granted) seenGranted = true;
      }
    }
  });

  test('requirePermission throws AuthorizationError with the required role named', () => {
    assert.throws(
      () => requirePermission('team_member', 'billing:manage'),
      (error: unknown) => {
        assert.ok(error instanceof AuthorizationError);
        assert.equal(error.code, 'FORBIDDEN');
        assert.match(error.message, /admin/);
        return true;
      },
    );
  });

  test('requirePermission is silent when allowed', () => {
    assert.doesNotThrow(() => requirePermission('admin', 'organization:delete'));
  });
});

/* -------------------------------------------------------------------------- */
/* Tenant isolation                                                           */
/* -------------------------------------------------------------------------- */

describe('tenant isolation', () => {
  const ctx: TenantContext = { userId: 'u1', organizationId: 'org-a', role: 'admin' };
  const own = { id: 'p1', organizationId: 'org-a', projectId: 'proj-1' };
  const foreign = { id: 'p2', organizationId: 'org-b', projectId: 'proj-2' };

  test('own rows pass through', () => {
    assert.equal(assertTenant(ctx, own), own);
  });

  test('a foreign row is NOT FOUND, not FORBIDDEN', () => {
    // The distinction matters: 403 would confirm the row exists and turn the
    // check into an id-enumeration oracle.
    assert.throws(
      () => assertTenant(ctx, foreign, 'Project'),
      (error: unknown) => {
        assert.ok(error instanceof NotFoundError);
        assert.equal(error.code, 'NOT_FOUND');
        return true;
      },
    );
  });

  test('a missing row and a foreign row are indistinguishable', () => {
    let missingMessage = '';
    let foreignMessage = '';
    try {
      assertTenant(ctx, null, 'Project');
    } catch (error) {
      missingMessage = (error as Error).message;
    }
    try {
      assertTenant(ctx, foreign, 'Project');
    } catch (error) {
      foreignMessage = (error as Error).message;
    }
    assert.equal(missingMessage, foreignMessage, 'error messages leak existence');
  });

  test('undefined is rejected', () => {
    assert.throws(() => assertTenant(ctx, undefined), NotFoundError);
  });

  test('project scoping rejects a row from another project in the same org', () => {
    const sameOrgOtherProject = { id: 'p3', organizationId: 'org-a', projectId: 'proj-9' };
    assert.throws(() => assertProject(ctx, sameOrgOtherProject, 'proj-1'), NotFoundError);
    assert.equal(assertProject(ctx, own, 'proj-1'), own);
  });

  test('authorize checks the permission BEFORE ownership', () => {
    const viewer: TenantContext = { userId: 'u2', organizationId: 'org-a', role: 'user' };
    // Even for a row they own, a user without the permission is refused —
    // and with an authorization error, not a not-found.
    assert.throws(() => authorize(viewer, 'project:delete', own), AuthorizationError);
  });

  test('authorize returns the row when permitted and owned', () => {
    assert.equal(authorize(ctx, 'project:delete', own), own);
  });

  test('list filtering drops foreign rows silently', () => {
    const filtered = filterTenant(ctx, [own, foreign, { id: 'p4', organizationId: 'org-a' }]);
    assert.equal(filtered.length, 2);
    assert.ok(filtered.every((row) => row.organizationId === 'org-a'));
  });

  test('an empty list stays empty', () => {
    assert.deepEqual(filterTenant(ctx, []), []);
  });

  test('tenantFilter produces the mandatory query fragment', () => {
    assert.deepEqual(tenantFilter(ctx), { organization_id: 'org-a' });
  });

  test('the row-level-security statement is parameterised, never interpolated', () => {
    const statement = rlsStatement("org-a'; DROP TABLE users; --");
    assert.ok(!statement.text.includes('DROP TABLE'), 'organization id reached the SQL text');
    assert.equal(statement.values[1], "org-a'; DROP TABLE users; --");
    assert.match(statement.text, /\$1.*\$2/);
  });
});

/* -------------------------------------------------------------------------- */
/* Brute-force protection                                                     */
/* -------------------------------------------------------------------------- */

describe('lockout', () => {
  test('locks after the threshold is reached', () => {
    const store = new MemoryLockoutStore();
    const key = accountKey('user@example.com');
    for (let i = 0; i < ACCOUNT_POLICY.threshold - 1; i += 1) {
      assert.equal(store.recordFailure(key, ACCOUNT_POLICY, 1000).locked, false);
    }
    const final = store.recordFailure(key, ACCOUNT_POLICY, 1000);
    assert.equal(final.locked, true);
    assert.ok(final.retryAfterSeconds > 0);
  });

  test('lockout is temporary, not permanent (denial-of-service defence)', () => {
    const store = new MemoryLockoutStore();
    const key = accountKey('victim@example.com');
    for (let i = 0; i < ACCOUNT_POLICY.threshold; i += 1) {
      store.recordFailure(key, ACCOUNT_POLICY, 0);
    }
    assert.equal(store.status(key, ACCOUNT_POLICY, 0).locked, true);
    const afterLockout = ACCOUNT_POLICY.baseLockoutMs + 1;
    assert.equal(store.status(key, ACCOUNT_POLICY, afterLockout).locked, false);
  });

  test('back-off is exponential and capped', () => {
    const store = new MemoryLockoutStore();
    const key = accountKey('persistent@example.com');
    let last = 0;
    for (let i = 0; i < ACCOUNT_POLICY.threshold + 12; i += 1) {
      const result = store.recordFailure(key, ACCOUNT_POLICY, 0);
      if (result.locked) {
        assert.ok(result.retryAfterSeconds >= last, 'back-off went backwards');
        last = result.retryAfterSeconds;
      }
    }
    assert.equal(last, Math.ceil(ACCOUNT_POLICY.maxLockoutMs / 1000), 'back-off is not capped');
  });

  test('counters reset after the window with no failures', () => {
    const store = new MemoryLockoutStore();
    const key = accountKey('occasional@example.com');
    store.recordFailure(key, ACCOUNT_POLICY, 0);
    store.recordFailure(key, ACCOUNT_POLICY, 0);
    const later = ACCOUNT_POLICY.windowMs + 1;
    assert.equal(store.status(key, ACCOUNT_POLICY, later).failuresRemaining, ACCOUNT_POLICY.threshold);
  });

  test('a successful sign-in clears the account counter', () => {
    const store = new MemoryLockoutStore();
    const key = accountKey('user@example.com');
    store.recordFailure(key, ACCOUNT_POLICY, 0);
    store.recordFailure(key, ACCOUNT_POLICY, 0);
    store.clear(key);
    assert.equal(store.status(key, ACCOUNT_POLICY, 0).failuresRemaining, ACCOUNT_POLICY.threshold);
  });

  test('account and address counters are independent', () => {
    const store = new MemoryLockoutStore();
    const account = accountKey('a@example.com');
    const address = addressKey('203.0.113.5');
    for (let i = 0; i < ACCOUNT_POLICY.threshold; i += 1) {
      store.recordFailure(account, ACCOUNT_POLICY, 0);
    }
    assert.equal(store.status(account, ACCOUNT_POLICY, 0).locked, true);
    assert.equal(store.status(address, ADDRESS_POLICY, 0).locked, false);
  });

  test('the address policy defends credential stuffing across many accounts', () => {
    // One attempt per account never trips a per-account limit; the address
    // counter is what catches it.
    const store = new MemoryLockoutStore();
    const address = addressKey('198.51.100.7');
    for (let i = 0; i < ADDRESS_POLICY.threshold; i += 1) {
      store.recordFailure(address, ADDRESS_POLICY, 0);
    }
    assert.equal(store.status(address, ADDRESS_POLICY, 0).locked, true);
  });

  test('separate accounts do not interfere', () => {
    const store = new MemoryLockoutStore();
    for (let i = 0; i < ACCOUNT_POLICY.threshold; i += 1) {
      store.recordFailure(accountKey('a@example.com'), ACCOUNT_POLICY, 0);
    }
    assert.equal(store.status(accountKey('b@example.com'), ACCOUNT_POLICY, 0).locked, false);
  });

  test('account keys are case- and whitespace-insensitive', () => {
    assert.equal(accountKey('  User@Example.COM '), accountKey('user@example.com'));
  });
});

/* -------------------------------------------------------------------------- */
/* Sessions                                                                   */
/* -------------------------------------------------------------------------- */

function sessionAt(now: number, overrides: Partial<SessionRecord> = {}): SessionRecord {
  return {
    id: 's1',
    userId: 'u1',
    tokenHash: 'hash',
    createdAt: new Date(now),
    expiresAt: new Date(now + 30 * 24 * 60 * 60 * 1000),
    lastActiveAt: new Date(now),
    revokedAt: null,
    sudoUntil: null,
    userAgent: null,
    ipHash: null,
    ...overrides,
  };
}

describe('session lifecycle', () => {
  const now = 1_700_000_000_000;

  test('a fresh session is valid', () => {
    const result = validateSessionRecord(sessionAt(now), now);
    assert.equal(result.valid, true);
  });

  test('a missing session is invalid', () => {
    const result = validateSessionRecord(null, now);
    assert.equal(result.valid, false);
    if (!result.valid) assert.equal(result.reason, 'not-found');
  });

  test('a revoked session is invalid even before its expiry', () => {
    const result = validateSessionRecord(sessionAt(now, { revokedAt: new Date(now) }), now + 1000);
    assert.equal(result.valid, false);
    if (!result.valid) assert.equal(result.reason, 'revoked');
  });

  test('an expired session is invalid', () => {
    const record = sessionAt(now, { expiresAt: new Date(now - 1) });
    const result = validateSessionRecord(record, now);
    assert.equal(result.valid, false);
    if (!result.valid) assert.equal(result.reason, 'expired');
  });

  test('idle timeout expires an inactive session', () => {
    const record = sessionAt(now, {
      lastActiveAt: new Date(now - SESSION_IDLE_TIMEOUT - 1),
      expiresAt: new Date(now + 10 * 24 * 60 * 60 * 1000),
    });
    const result = validateSessionRecord(record, now);
    assert.equal(result.valid, false);
    if (!result.valid) assert.equal(result.reason, 'idle-timeout');
  });

  test('absolute lifetime expires an actively used session', () => {
    // The important case: constant activity must NOT renew a session forever.
    const record = sessionAt(now, {
      createdAt: new Date(now - SESSION_ABSOLUTE_LIFETIME - 1),
      lastActiveAt: new Date(now),
      expiresAt: new Date(now + 10 * 24 * 60 * 60 * 1000),
    });
    const result = validateSessionRecord(record, now);
    assert.equal(result.valid, false);
    if (!result.valid) assert.equal(result.reason, 'absolute-timeout');
  });

  test('lastActiveAt is refreshed only when meaningfully stale', () => {
    const fresh = validateSessionRecord(sessionAt(now), now);
    assert.equal(fresh.valid && fresh.shouldRefresh, false);

    const stale = validateSessionRecord(
      sessionAt(now, { lastActiveAt: new Date(now - REFRESH_THRESHOLD_MS - 1) }),
      now,
    );
    assert.equal(stale.valid && stale.shouldRefresh, true);
  });

  test('creating a session never stores the token', () => {
    const created = createSessionRecord({ userId: 'u1' }, now);
    assert.ok(created.token.length > 40);
    assert.notEqual(created.record.tokenHash, created.token);
    assert.ok(!JSON.stringify(created.record).includes(created.token));
  });

  test('each session gets a distinct token', () => {
    const a = createSessionRecord({ userId: 'u1' }, now);
    const b = createSessionRecord({ userId: 'u1' }, now);
    assert.notEqual(a.token, b.token);
    assert.notEqual(a.record.tokenHash, b.record.tokenHash);
  });

  test('sudo is off by default and time-limited when granted', () => {
    const plain = createSessionRecord({ userId: 'u1' }, now);
    assert.equal(plain.record.sudoUntil, null);
    assert.equal(isSudo({ ...plain.record, id: 's' }, now), false);

    const elevated = createSessionRecord({ userId: 'u1', sudo: true }, now);
    const record = { ...elevated.record, id: 's' };
    assert.equal(isSudo(record, now), true);
    assert.equal(isSudo(record, now + 16 * 60 * 1000), false);
  });

  test('IP addresses are keyed-hashed, never stored raw', () => {
    const hashed = hashIpAddress('203.0.113.5', 'secret');
    assert.ok(hashed);
    assert.ok(!hashed.includes('203.0.113.5'));
    assert.equal(hashed.length, 64);
    // A different key yields a different hash — so the hash is not reversible
    // by simply hashing the whole IPv4 space.
    assert.notEqual(hashed, hashIpAddress('203.0.113.5', 'other-secret'));
    assert.equal(hashIpAddress(null, 'secret'), null);
  });
});

describe('cookie attributes', () => {
  test('the session cookie is httpOnly, lax and secure in production', () => {
    const production = sessionCookieOptions(true, 3600);
    assert.equal(production.httpOnly, true, 'session cookie must not be readable by JavaScript');
    assert.equal(production.secure, true);
    assert.equal(production.sameSite, 'lax');
    assert.equal(production.path, '/');
  });

  test('secure is relaxed only outside production', () => {
    assert.equal(sessionCookieOptions(false).secure, false);
  });

  test('the CSRF cookie is deliberately readable, but still same-site', () => {
    const csrf = csrfCookieOptions(true);
    assert.equal(csrf.httpOnly, false, 'the client must echo this value back');
    assert.equal(csrf.secure, true);
    assert.equal(csrf.sameSite, 'lax');
  });

  test('no cookie is ever SameSite=None', () => {
    for (const options of [sessionCookieOptions(true), csrfCookieOptions(true)]) {
      assert.notEqual(options.sameSite, 'none');
    }
  });
});
