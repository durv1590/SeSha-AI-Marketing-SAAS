import assert from 'node:assert/strict';
import Module from 'node:module';
import { test, describe, beforeEach } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { resolveSession, signIn, signUp, toRole, type ServiceContext } from '../src/lib/auth/service';
import { validateSessionRecord } from '../src/lib/auth/session';
import { AuthorizationError } from '../src/lib/auth/rbac';
import { completeOnboarding, deleteProject, getProject, grantCrawlConsent } from '../src/lib/workspace/service';
import { NotFoundError, type TenantContext } from '../src/lib/tenant';
import { CRAWL_CONSENT_VERSION, normalizeWebsiteUrl, validateCrawlConsent } from '../src/lib/validation/onboarding';
import { checkUrl } from '../src/lib/crawler/url-policy';
import { safeFetch, type Transport } from '../src/lib/crawler/fetcher';
import { explainFailure, isRetryable } from '../src/lib/jobs/types';
import { reapStaleJobs, requestJob, retryJob, runJob, toJobView, type CrawlServiceContext } from '../src/lib/crawl/service';
import { AIOrchestrator } from '../src/lib/ai/orchestrator';
import { AiCache, AiRateLimiter, DEFAULT_TIMEOUT_MS, currentPeriod } from '../src/lib/ai/cost';
import { loadWorkspaceContext } from '../src/lib/ai/context';
import { AiError, OpenAiProvider, type AIProvider, type CompletionRequest, type CompletionResult } from '../src/lib/ai/provider';
import { validateJsonLd } from '../src/lib/schema-validator/validate';
import { MemoryRateLimitStore } from '../src/lib/security/rate-limit';
import { enforceRateLimit } from '../src/lib/api/respond';
import { CircuitBreaker, CircuitOpenError, TimeoutError, isTransient, retry, withTimeout } from '../src/lib/reliability';

/**
 * Failure recovery, simulated against the real code.
 *
 * Every test breaks one thing on purpose and asserts three properties: the
 * failure is REPORTED (a typed error or an honest failure state, never a
 * silent success), NOTHING INTERNAL LEAKS into what a user would see, and the
 * system WORKS AGAIN once the fault is removed.
 */

const PASSWORD = 'a genuinely long passphrase 2026';
const SECRET = 'test-secret-value-at-least-32-bytes-long';
const SITE = 'https://acme-coffee.example.com';
const INTERNAL = 'postgres://admin:hunter2@10.0.0.5:5432/prod';
const noSleep = async () => {};

/* -------------------------------------------------------------------------- */
/* errorResponse lives in guard.ts, which imports next/headers. The sandbox   */
/* stub of `next` has no next/headers, so it is stubbed here — errorResponse  */
/* itself never touches cookies or headers.                                   */
/* -------------------------------------------------------------------------- */

type Loader = { _load: (request: string, ...rest: unknown[]) => unknown };
const loader = Module as unknown as Loader;
const originalLoad = loader._load;
loader._load = function (this: unknown, request: string, ...rest: unknown[]) {
  if (request === 'next/headers') {
    return { cookies: async () => ({ get: () => undefined }), headers: async () => new Headers() };
  }
  return originalLoad.call(this, request, ...rest);
};

async function errorResponseFor(error: unknown): Promise<{ status: number; body: string }> {
  const { errorResponse } = await import('../src/lib/api/guard');
  const quiet = console.error;
  console.error = () => {};
  try {
    const response = errorResponse(error);
    return { status: response.status, body: await response.text() };
  } finally {
    console.error = quiet;
  }
}

/* -------------------------------------------------------------------------- */
/* Fixtures                                                                   */
/* -------------------------------------------------------------------------- */

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: SITE,
};
const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic'] as const,
  marketingChannels: ['organic-search'] as const,
  brandVoice: { tones: ['friendly'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters' }],
};

let db: MemoryDatabase;
let auth: ServiceContext;
let tenant: TenantContext;
let projectId: string;

async function makeTenant(email: string) {
  const signed = await signUp(auth, { email, password: PASSWORD });
  if (!signed.ok || !signed.userId) throw new Error('signup failed');
  const memberships = await db.memberships.findForUser(signed.userId);
  const context: TenantContext = {
    userId: signed.userId,
    organizationId: memberships[0]!.organizationId,
    role: toRole(memberships[0]!.role),
  };
  await db.subscriptions.update(context.organizationId, { plan: 'agency' });
  const onboarded = await completeOnboarding({ db }, context, { business, profile });
  return { tenant: context, projectId: onboarded.project.id };
}

beforeEach(async () => {
  db = new MemoryDatabase();
  auth = { db, lockout: new MemoryLockoutStore(), secret: SECRET };
  ({ tenant, projectId } = await makeTenant('owner@example.com'));
});

class ScriptedProvider implements AIProvider {
  readonly name = 'openai' as const;
  readonly models = [
    { id: 'fast-model', label: 'Fast', tier: 'fast' as const, contextTokens: 100_000, maxOutputTokens: 8_000 },
    { id: 'balanced-model', label: 'Balanced', tier: 'balanced' as const, contextTokens: 100_000, maxOutputTokens: 8_000 },
    { id: 'deep-model', label: 'Deep', tier: 'deep' as const, contextTokens: 200_000, maxOutputTokens: 16_000 },
  ];
  calls = 0;
  lastRequest: CompletionRequest | null = null;
  script: (string | Error)[] = [];
  isConfigured(): boolean {
    return true;
  }
  async complete(request: CompletionRequest, model: string): Promise<CompletionResult> {
    this.calls += 1;
    this.lastRequest = request;
    const next = this.script.shift();
    if (next instanceof Error) throw next;
    const text = next ?? JSON.stringify({ blocks: [{ kind: 'recommendation', text: 'Post weekly.' }] });
    return { text, usage: { inputTokens: 100, outputTokens: 50 }, model, provider: this.name, truncated: false };
  }
}

function orchestratorWith(provider: AIProvider) {
  return new AIOrchestrator({
    db,
    provider,
    cache: new AiCache(),
    limiter: new AiRateLimiter(),
    sleep: noSleep,
    retry: { maxAttempts: 3, baseDelayMs: 1, maxDelayMs: 2 },
  });
}

async function ask(provider: AIProvider, prompt = 'What should I post?') {
  const context = await loadWorkspaceContext(db, tenant, projectId);
  return orchestratorWith(provider).run(tenant, { agent: 'copilot', prompt, context, projectId });
}

const generations = () => db.usage.totalFor(tenant.organizationId, 'ai_generation', currentPeriod());

type Page = { status: number; body?: string };
function transportFor(pages: Record<string, Page>, fault?: (url: string) => Error | null): Transport {
  return async (request) => {
    const error = fault?.(request.url);
    if (error) throw error;
    const page = pages[request.url] ?? { status: 404 };
    const body = page.body ?? '';
    return { status: page.status, headers: { 'content-type': 'text/html' }, body, bytes: Buffer.byteLength(body), truncated: false };
  };
}
const lookup = async () => [{ address: '93.184.216.34', family: 4 as const }];
const homePage = `<!doctype html><html lang="en"><head><title>Acme Coffee</title>
  <meta name="description" content="Speciality coffee roasted slowly in small batches in Nagpur every morning.">
  </head><body><h1>Acme Coffee</h1><p>${'We roast our coffee slowly in small batches. '.repeat(20)}</p></body></html>`;
const healthySite: Record<string, Page> = {
  [`${SITE}/robots.txt`]: { status: 404 },
  [`${SITE}/`]: { status: 200, body: homePage },
};
function crawlService(pages = healthySite, fault?: (url: string) => Error | null): CrawlServiceContext {
  return { db, fetchOptions: { transport: transportFor(pages, fault), lookup }, sleep: noSleep };
}
async function queueCrawl() {
  await grantCrawlConsent({ db }, tenant, projectId, {
    websiteUrl: SITE,
    consentVersion: CRAWL_CONSENT_VERSION,
    maxPages: 5,
    respectRobots: true,
    retentionDays: 30,
  });
  return requestJob(crawlService(), tenant, { projectId, kind: 'crawl' });
}
async function claimAndRun(service: CrawlServiceContext, at = new Date()) {
  const claimed = await db.jobs.claimNext(at);
  if (!claimed) throw new Error('nothing queued');
  return runJob(service, claimed);
}
const refused = () => Object.assign(new Error('connect ECONNREFUSED 10.1.2.3:443'), { code: 'ECONNREFUSED' });

/* 1 ------------------------------------------------------------------------- */
describe('1. API timeout', () => {
  test('withTimeout rejects with a typed TimeoutError, aborts the work, and the next call works', async () => {
    let aborted = false;
    await assert.rejects(
      () => withTimeout(20, (signal) => {
        signal.addEventListener('abort', () => (aborted = true));
        return new Promise((resolve) => setTimeout(resolve, 5_000));
      }, 'analytics sync'),
      (error: unknown) => error instanceof TimeoutError && isTransient(error),
    );
    assert.equal(aborted, true);
    assert.equal(await withTimeout(1_000, async () => 'fine'), 'fine');
  });

  test('the AI adapter turns a hung provider into AiError("timeout")', async () => {
    const saved = process.env.OPENAI_API_KEY;
    process.env.OPENAI_API_KEY = 'k';
    try {
      const hung: typeof fetch = async (_url, init) => new Promise((_resolve, reject) => {
        init?.signal?.addEventListener('abort', () => reject(Object.assign(new Error('aborted'), { name: 'AbortError' })));
      });
      const request = { system: 's', messages: [{ role: 'user' as const, content: 'hi' }], maxOutputTokens: 10, temperature: 0, timeoutMs: 20 };
      await assert.rejects(() => new OpenAiProvider().complete(request, 'gpt-4o', hung), (error: unknown) => (error as AiError).code === 'timeout');
    } finally {
      if (saved === undefined) delete process.env.OPENAI_API_KEY;
      else process.env.OPENAI_API_KEY = saved;
    }
  });

  test('the orchestrator sends a deadline and reports a timeout honestly, without charging', async () => {
    const provider = new ScriptedProvider();
    provider.script = [new AiError('timeout', 'x'), new AiError('timeout', 'x'), new AiError('timeout', 'x')];
    const result = await ask(provider);
    assert.equal(provider.lastRequest?.timeoutMs, DEFAULT_TIMEOUT_MS);
    assert.equal(result.ok, false);
    if (!result.ok) {
      assert.equal(result.code, 'timeout');
      assert.match(result.message, /too long/i);
    }
    assert.equal(provider.calls, 3, 'a timeout is retryable, up to the cap');
    assert.equal(await generations(), 0);
  });
});

/* 2 ------------------------------------------------------------------------- */
describe('2. AI provider unavailable', () => {
  test('a 503-style outage is reported, nothing is generated, nothing is charged, and it recovers', async () => {
    const provider = new ScriptedProvider();
    provider.script = [1, 2, 3].map(() => new AiError('unavailable', `Provider returned 503 for org-internal-42`));
    const down = await ask(provider);
    assert.equal(down.ok, false);
    if (!down.ok) {
      assert.equal(down.code, 'unavailable');
      assert.ok(!down.message.includes('org-internal-42') && !down.message.includes('503'));
      assert.ok(!('response' in down), 'a failure carries no generated content');
    }
    assert.equal(await generations(), 0, 'a failed provider call must not be billed');
    const audit = await db.audit.list(tenant.organizationId);
    assert.ok(audit.some((entry) => entry.action === 'ai.generate.copilot' && entry.outcome === 'failure'));

    const up = await ask(provider);
    assert.equal(up.ok, true, 'the provider came back and the orchestrator did not stay broken');
  });

  test('a raw non-AiError throw (a bug in an adapter) becomes a generic message', async () => {
    const provider = new ScriptedProvider();
    provider.script = [new TypeError(`Cannot read properties of undefined (reading 'choices') at ${INTERNAL}`)];
    const result = await ask(provider);
    assert.equal(result.ok, false);
    if (!result.ok) {
      assert.equal(result.code, 'unknown');
      assert.ok(!result.message.includes('choices') && !result.message.includes('hunter2'));
    }
  });
});

describe('2b. AI provider circuit breaker (Phase 9)', () => {
  test('after five outage-class failures, requests fail FAST without calling the provider', async () => {
    const provider = new ScriptedProvider();
    provider.script = Array.from({ length: 15 }, () => new AiError('unavailable', 'down'));
    for (let round = 0; round < 5; round += 1) await ask(provider);
    const callsBefore = provider.calls;

    const fast = await ask(provider);
    assert.equal(fast.ok, false);
    if (!fast.ok) {
      assert.equal(fast.code, 'unavailable');
      assert.ok((fast.retryAfterSeconds ?? 0) > 0, 'the user is told when to try again');
    }
    assert.equal(provider.calls, callsBefore, 'an open breaker must not call the provider');
  });

  test('a content refusal is not an outage and never opens the breaker', async () => {
    const provider = new ScriptedProvider();
    provider.script = Array.from({ length: 7 }, () => new AiError('content_filtered', 'no'));
    for (let round = 0; round < 7; round += 1) await ask(provider);
    const up = await ask(provider);
    assert.equal(up.ok, true, 'filtered prompts tripped the breaker for everyone');
  });
});

/* 3 ------------------------------------------------------------------------- */
describe('3. database failure', () => {
  test('a throwing repository surfaces as an error (not a 404 or empty result) and maps to a bare 500', async () => {
    const real = db.projects.findById;
    db.projects.findById = async () => {
      throw new Error(`connection terminated unexpectedly: ${INTERNAL}`);
    };
    let caught: unknown;
    await getProject({ db }, tenant, projectId).catch((error: unknown) => (caught = error));
    assert.ok(caught instanceof Error, 'the failure was swallowed');
    assert.ok(!(caught instanceof NotFoundError), 'an outage must not masquerade as "not found"');

    const { status, body } = await errorResponseFor(caught);
    assert.equal(status, 500);
    assert.deepEqual(JSON.parse(body), { ok: false, message: 'Something went wrong. Please try again.' });
    assert.ok(!body.includes('hunter2') && !body.includes('10.0.0.5') && !body.includes(' at '));

    db.projects.findById = real;
    assert.equal((await getProject({ db }, tenant, projectId)).id, projectId, 'recovered once the DB is back');
  });
});

/* 4 ------------------------------------------------------------------------- */
describe('4. crawl failure', () => {
  test('robots.txt 500 fails the job with a code, a human explanation, and an allowed retry', async () => {
    await queueCrawl();
    const outcome = await claimAndRun(crawlService({ [`${SITE}/robots.txt`]: { status: 500 } }));
    assert.equal(outcome.job.status, 'failed');
    assert.equal(outcome.job.failureCode, 'robots_unavailable');
    const view = toJobView(outcome.job);
    assert.ok(view.failure && !view.failure.includes('_'));
    assert.equal(view.canRetry, true);
    const requeued = await retryJob(crawlService(), tenant, outcome.job.id);
    assert.equal(requeued.status, 'queued');

    const again = await claimAndRun(crawlService(), new Date(requeued.notBefore!.getTime() + 1));
    assert.equal(again.job.status, 'completed', 'the retried crawl succeeds once the site is healthy');
  });

  test('connection refused on every request fails the job (retryably) and leaks no address', async () => {
    await queueCrawl();
    const outcome = await claimAndRun(crawlService(healthySite, refused));
    assert.equal(outcome.job.status, 'failed');
    // GAP (documented): the site is unreachable, but the robots.txt probe fails
    // first, so the user is told robots.txt was unreadable, not that the site is down.
    assert.equal(outcome.job.failureCode, 'robots_unavailable');
    const view = toJobView(outcome.job);
    assert.equal(view.canRetry, true);
    assert.ok(!JSON.stringify(view).includes('10.1.2.3') && !JSON.stringify(view).includes('ECONNREFUSED'));
    assert.ok(explainFailure('network_error').length > 10);
  });
});

/* 5 ------------------------------------------------------------------------- */
describe('5. invalid URL', () => {
  const hostile = ['javascript:alert(1)', 'file:///etc/passwd', 'http://localhost/', 'http://127.0.0.1/', 'http://169.254.169.254/latest', 'not a url at all', '', '%%%'];

  test('the crawler URL policy refuses every one, with a reason, without throwing', () => {
    for (const input of hostile) {
      const verdict = checkUrl(input);
      assert.equal(verdict.ok, false, `crawler accepted ${JSON.stringify(input)}`);
      if (!verdict.ok) assert.ok(verdict.reason.length > 0);
    }
  });

  test('onboarding validation refuses every one, and consent validation reports a field error', () => {
    for (const input of hostile) {
      assert.equal(normalizeWebsiteUrl(input).ok, false, `onboarding accepted ${JSON.stringify(input)}`);
    }
    const consent = validateCrawlConsent({ websiteUrl: 'http://localhost/', consent: true, consentVersion: CRAWL_CONSENT_VERSION });
    assert.equal(consent.ok, false);
    if (!consent.ok) assert.ok(consent.errors.websiteUrl);
    assert.equal(normalizeWebsiteUrl('acme-coffee.example.com').ok, true, 'a good URL still passes');
  });
});

/* 6 ------------------------------------------------------------------------- */
describe('6. invalid schema', () => {
  test('malformed and hostile JSON-LD produce a report with errors, never a throw', () => {
    const inputs = ['{ "@type": }', '[1, 2', 'null', '[]', '"just a string"', '{"@context":"https://schema.org","@type":42}',
      '{"@context":"https://schema.org","@type":"Organization","url":"javascript:alert(1)"}', `${'['.repeat(5_000)}${']'.repeat(5_000)}`,
      `${'{"a":'.repeat(2_000)}1${'}'.repeat(2_000)}`, '<p>No markup on this page.</p>'];
    // BUG FIXED: the nested-array input overflowed the stack (RangeError), and the
    // node-less inputs (`null`, `[]`, plain HTML) were reported valid: "No errors found".
    for (const input of inputs) {
      let report: ReturnType<typeof validateJsonLd> | undefined;
      assert.doesNotThrow(() => (report = validateJsonLd(input)), `threw on ${input.slice(0, 40)}`);
      assert.ok(report);
      assert.equal(report.valid, false, `reported valid: ${input.slice(0, 40)}`);
      assert.ok(report.messages.length > 0, `no message explains ${input.slice(0, 40)}`);
    }
  });
});

/* 7 ------------------------------------------------------------------------- */
describe('7. rate limit', () => {
  test('an exhausted bucket is denied with a retry-after, then the window resets', () => {
    const store = new MemoryRateLimitStore();
    const options = { limit: 3, windowMs: 60_000 };
    for (let i = 0; i < 3; i += 1) assert.equal(store.consume('k', options, 1_000).allowed, true);
    const denied = store.consume('k', options, 1_000);
    assert.equal(denied.allowed, false);
    assert.equal(denied.remaining, 0);
    assert.equal(denied.retryAfterSeconds, 60);
    assert.equal(store.consume('k', options, 61_001).allowed, true);
  });

  test('enforceRateLimit returns a real 429 with Retry-After and a plain message', async () => {
    const request = () => new Request('https://sesha.example/api/contact', { method: 'POST', headers: { 'x-real-ip': '203.0.113.77' } });
    for (let i = 0; i < 5; i += 1) assert.equal(enforceRateLimit(request(), 'contact').allowed, true);
    const result = enforceRateLimit(request(), 'contact');
    assert.equal(result.allowed, false);
    if (result.allowed) return;
    assert.equal(result.response.status, 429);
    assert.ok(Number(result.response.headers.get('Retry-After')) > 0);
    const body = (await result.response.json()) as { ok: boolean; message: string };
    assert.equal(body.ok, false);
    assert.match(body.message, /too many requests/i);
    const other = new Request('https://sesha.example/api/contact', { method: 'POST', headers: { 'x-real-ip': '203.0.113.78' } });
    assert.equal(enforceRateLimit(other, 'contact').allowed, true, 'one client is not locked out by another');
  });
});

/* 8 ------------------------------------------------------------------------- */
describe('8. unauthorized request', () => {
  test("another tenant's project is NotFound (404), and the owner is unaffected", async () => {
    const intruder = await makeTenant('intruder@example.com');
    await assert.rejects(() => getProject({ db }, intruder.tenant, projectId), NotFoundError);
    const { status, body } = await errorResponseFor(new NotFoundError('Project'));
    assert.equal(status, 404);
    assert.ok(!body.includes(projectId));
    assert.equal((await getProject({ db }, tenant, projectId)).id, projectId);
  });

  test('a missing permission is an AuthorizationError mapped to 403, and nothing is deleted', async () => {
    const viewer: TenantContext = { ...tenant, role: 'user' };
    let caught: unknown;
    await deleteProject({ db }, viewer, projectId).catch((error: unknown) => (caught = error));
    assert.ok(caught instanceof AuthorizationError);
    assert.equal((await errorResponseFor(caught)).status, 403);
    assert.equal((await getProject({ db }, tenant, projectId)).deletedAt, null);
  });
});

/* 9 ------------------------------------------------------------------------- */
describe('9. expired session', () => {
  test('idle and absolute timeouts resolve to null; signing in again works', async () => {
    const first = await signIn(auth, { email: 'owner@example.com', password: PASSWORD });
    if (!first.ok) throw new Error('sign in failed');
    const DAY = 24 * 60 * 60_000;
    assert.ok(await resolveSession(auth, first.token));
    assert.equal(await resolveSession({ ...auth, now: () => Date.now() + 15 * DAY }, first.token), null, 'idle timeout');
    assert.equal(await resolveSession({ ...auth, now: () => Date.now() + 91 * DAY }, first.token), null, 'absolute timeout');

    const busy = { ...first.session, createdAt: new Date(Date.now() - 91 * DAY), lastActiveAt: new Date(), expiresAt: new Date(Date.now() + DAY) };
    const verdict = validateSessionRecord(busy);
    assert.equal(verdict.valid, false);
    if (!verdict.valid) assert.equal(verdict.reason, 'absolute-timeout', 'activity does not extend the absolute lifetime');

    const second = await signIn(auth, { email: 'owner@example.com', password: PASSWORD });
    assert.ok(second.ok && (await resolveSession(auth, second.token)));
  });
});

/* 10 ------------------------------------------------------------------------ */
describe('10. network failure', () => {
  test('ECONNREFUSED in the fetcher is a network_error: transient, retryable, no address leaked', async () => {
    const result = await safeFetch(`${SITE}/`, { transport: transportFor({}, refused), lookup });
    assert.equal(result.ok, false);
    if (result.ok) return;
    assert.equal(result.code, 'network_error');
    assert.ok(!result.reason.includes('10.1.2.3'));
    assert.equal(isRetryable(result.code), true);
    assert.equal(isTransient(refused()), true);
  });

  test('retry retries a transient idempotent call, then gives up with the last error', async () => {
    let calls = 0;
    await assert.rejects(() => retry(async () => { calls += 1; throw refused(); }, { idempotent: true, attempts: 4, sleep: noSleep }), /ECONNREFUSED/);
    assert.equal(calls, 4);
    calls = 0;
    const value = await retry(async () => { calls += 1; if (calls < 2) throw refused(); return 'back'; }, { idempotent: true, sleep: noSleep });
    assert.equal(value, 'back');
  });

  test('non-idempotent retry is refused at compile time; at runtime the flag is NOT checked (gap)', async () => {
    let calls = 0;
    const unsafe = { sleep: noSleep, attempts: 3, idempotent: false } as unknown as Parameters<typeof retry>[1];
    await assert.rejects(() => retry(async () => { calls += 1; throw refused(); }, unsafe));
    // Documents actual behaviour: a cast defeats the guard and the call is repeated.
    assert.equal(calls, 3);
  });
});

/* 11 ------------------------------------------------------------------------ */
describe('11. job failure', () => {
  test('a throwing step ends the job "failed" (worker_error), never stuck "running", and a retry succeeds', async () => {
    const job = await queueCrawl();
    const real = db.keywords.replaceForProject;
    db.keywords.replaceForProject = async () => {
      throw new Error(`deadlock detected on ${INTERNAL}`);
    };
    const outcome = await claimAndRun(crawlService());
    db.keywords.replaceForProject = real;

    assert.equal(outcome.job.status, 'failed');
    assert.equal(outcome.job.failureCode, 'worker_error');
    const stored = await db.jobs.findById(tenant.organizationId, job.id);
    assert.equal(stored?.status, 'failed', 'the stored job is not left running');
    assert.ok(!JSON.stringify(toJobView(outcome.job)).includes('hunter2'));

    const requeued = await retryJob(crawlService(), tenant, job.id);
    const again = await claimAndRun(crawlService(), new Date(requeued.notBefore!.getTime() + 1));
    assert.equal(again.job.status, 'completed');
  });

  test('a job whose worker died is requeued by the reaper', async () => {
    await queueCrawl();
    await db.jobs.claimNext(new Date(Date.now() - 60 * 60_000));
    assert.deepEqual(await reapStaleJobs({ db, now: () => Date.now() }), { requeued: 1, abandoned: 0 });
  });
});

/* 12 ------------------------------------------------------------------------ */
describe('12. partial response', () => {
  const partials = [
    '{"blocks":[{"kind":"recommendation","text":"Post on Mon',
    JSON.stringify({ blocks: [{ text: 'No provenance kind here.' }] }),
    JSON.stringify({ blocks: [{ kind: 'made_up_kind', text: 'Growth is 40%.' }] }),
    JSON.stringify({ blocks: [] }),
    'Sure! Here is your plan: post every day.',
  ];

  for (const [index, text] of partials.entries()) {
    test(`AI partial/unsourced output #${index} is rejected, not displayed`, async () => {
      const provider = new ScriptedProvider();
      provider.script = [text];
      const result = await ask(provider);
      assert.equal(result.ok, false);
      if (!result.ok) {
        assert.equal(result.code, 'bad_response');
        assert.ok(!result.message.includes('Post on Mon') && !result.message.includes('40%'));
      }
      // By design the call WAS made and billed, so usage is recorded honestly.
      assert.equal(await generations(), 1);
    });
  }

  test('an oversized crawl body is refused (too_large) or flagged truncated, never passed off as whole', async () => {
    const tooLarge: Transport = async () => { throw Object.assign(new Error('too big'), { code: 'ERR_TOO_LARGE' }); };
    const refusedBody = await safeFetch(`${SITE}/`, { transport: tooLarge, lookup, maxBytes: 1_000 });
    assert.equal(refusedBody.ok, false);
    if (!refusedBody.ok) assert.equal(refusedBody.code, 'too_large');

    const cut: Transport = async () => ({ status: 200, headers: { 'content-type': 'text/html' }, body: 'x'.repeat(1_000), bytes: 1_000, truncated: true });
    const truncated = await safeFetch(`${SITE}/`, { transport: cut, lookup, maxBytes: 1_000 });
    assert.equal(truncated.ok, true);
    if (truncated.ok) assert.equal(truncated.truncated, true);
  });
});

/* Circuit breaker ------------------------------------------------------------ */
describe('circuit breaker', () => {
  test('opens after repeated failures, fails fast, and recovers through one half-open probe', async () => {
    let now = 0;
    const breaker = new CircuitBreaker('ai-provider', { failureThreshold: 3, resetAfterMs: 1_000, now: () => now });
    let downstream = 0;
    const failing = async () => { downstream += 1; throw refused(); };
    for (let i = 0; i < 3; i += 1) await assert.rejects(() => breaker.run(failing));
    assert.equal(breaker.currentState(), 'open');

    await assert.rejects(() => breaker.run(failing), (error: unknown) => error instanceof CircuitOpenError && error.retryAfterMs > 0);
    assert.equal(downstream, 3, 'an open breaker must not call through');

    now += 1_000;
    assert.equal(breaker.currentState(), 'half_open');
    assert.equal(await breaker.run(async () => 'healthy'), 'healthy');
    assert.equal(breaker.currentState(), 'closed');
  });
});
