import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { signUp, toRole } from '../src/lib/auth/service';
import { completeOnboarding } from '../src/lib/workspace/service';
import type { TenantContext } from '../src/lib/tenant';

import {
  SCHEMA_SYNTAXES,
  SUPPORTED_SCHEMA_TYPES,
  VALIDATION_DIMENSIONS,
  VALIDATION_STATUSES,
  VALIDATOR_VERSION,
  buildCorrection,
  parseMicrodata,
  parseRdfa,
  validateSchema,
} from '../src/lib/schema-validator';
import { generateSchema } from '../src/lib/schema/generate';
import { validateForProject, listValidationHistory } from '../src/lib/schema/service';
import { analyzeCompetitor } from '../src/lib/competitors/analyze';
import { AD_PLATFORMS, adsDataStatus } from '../src/lib/ads/platforms';
import { checkAdPlan, performanceStatus, recommendBudget } from '../src/lib/ads/plan';
import { LEAD_STAGES, SCORE_BASIS, scoreIsConsistent, scoreLead } from '../src/lib/leads/types';
import { createLead } from '../src/lib/leads/service';
import {
  EMAIL_KINDS,
  WHATSAPP_KINDS,
  checkMessagingPlan,
  sendingStatus,
} from '../src/lib/messaging/types';
import { VIDEO_PLATFORMS, checkVideoScript, imageGenerationStatus } from '../src/lib/video/types';

/**
 * The Phase 5 quality gate, executed.
 *
 * Fourteen boxes, one describe block each, named after the brief's line — the
 * same shape as the Phase 3 and Phase 4 gates. A checklist someone ticks by hand
 * is a claim; this file makes each line fail loudly if the behaviour regresses.
 */

const PASSWORD = 'a genuinely long passphrase 2026';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of readdirSync(dir)) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) walk(full, out);
    else if (/\.(ts|tsx)$/.test(entry)) out.push(full);
  }
  return out;
}

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: 'https://acme-coffee.example.com',
};

const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic'] as const,
  marketingChannels: ['organic-search'] as const,
  brandVoice: { tones: ['friendly'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters' }],
};

let db: MemoryDatabase;
let tenant: TenantContext;
let projectId: string;

beforeEach(async () => {
  db = new MemoryDatabase();
  const signed = await signUp(
    { db, lockout: new MemoryLockoutStore(), secret: 'test-secret-value-at-least-32-bytes-long' },
    { email: `gate5-${Math.random().toString(36).slice(2)}@example.com`, password: PASSWORD },
  );
  if (!signed.ok || !signed.userId) throw new Error('signup failed');
  const memberships = await db.memberships.findForUser(signed.userId);
  tenant = {
    userId: signed.userId,
    organizationId: memberships[0]!.organizationId,
    role: toRole(memberships[0]!.role),
  };
  const onboarded = await completeOnboarding({ db }, tenant, { business, profile });
  projectId = onboarded.project.id;
});

/* -------------------------------------------------------------------------- */

describe('gate: schema parser', () => {
  test('all three syntaxes are parsed', () => {
    assert.deepEqual([...SCHEMA_SYNTAXES], ['json-ld', 'microdata', 'rdfa']);

    const html = `
      <script type="application/ld+json">{"@context":"https://schema.org","@type":"WebSite","name":"A","url":"https://e.com"}</script>
      <div itemscope itemtype="https://schema.org/Person"><span itemprop="name">B</span></div>
      <div vocab="https://schema.org/" typeof="Course"><span property="name">C</span><span property="description">D</span></div>`;
    const result = validateSchema({ source: html, sourceKind: 'page_url' });
    assert.deepEqual([...result.syntaxes].sort(), ['json-ld', 'microdata', 'rdfa']);
  });

  test('the parser reads HTML without a DOM library and without fetching', () => {
    const parse = readFileSync(path.join(root, 'src', 'lib', 'schema-validator', 'parse.ts'), 'utf8');
    assert.ok(!/fetch\(/.test(parse), 'the parser must not make network requests');
    assert.ok(!/from ['"](?:jsdom|cheerio|parse5|xml2js|fast-xml-parser)['"]/.test(parse));
  });

  test('malformed JSON in one block does not discard the others', () => {
    const html = `
      <script type="application/ld+json">{ broken</script>
      <script type="application/ld+json">{"@context":"https://schema.org","@type":"Organization","name":"Acme"}</script>`;
    const result = validateSchema({ source: html, sourceKind: 'page_url' });
    assert.ok(result.typesFound.includes('Organization'));
    assert.ok(result.issues.some((issue) => issue.check === 'parse_invalid_json'));
  });

  test('microdata and RDFa readers report what they could not follow', () => {
    const micro = parseMicrodata(
      '<div itemscope itemtype="https://schema.org/Product" itemref="x"><span itemprop="name">A</span></div>',
    );
    assert.ok(micro.limitations.length > 0);
    const rdfa = parseRdfa('<div typeof="Organization"><span property="name">A</span></div>');
    assert.ok(rdfa.limitations.length > 0);
  });
});

describe('gate: schema validator', () => {
  test('all twenty-four types the brief names are supported', () => {
    assert.equal(SUPPORTED_SCHEMA_TYPES.length, 24);
  });

  test('all six statuses exist and are used', () => {
    assert.equal(VALIDATION_STATUSES.length, 6);
  });

  test('all four dimensions exist, and every issue carries one', () => {
    assert.equal(VALIDATION_DIMENSIONS.length, 4);
    const result = validateSchema({
      source: JSON.stringify({ '@type': 'Article', headline: 'x', datePublished: 'yesterday' }),
      sourceKind: 'pasted',
    });
    for (const issue of result.issues) {
      assert.ok(VALIDATION_DIMENSIONS.includes(issue.dimension), issue.check);
    }
  });

  test('every finding carries a path and an explanation', () => {
    const result = validateSchema({
      source: JSON.stringify({ '@context': 'https://schema.org', '@type': 'LocalBusiness', name: 'A' }),
      sourceKind: 'pasted',
    });
    for (const issue of result.issues) {
      assert.ok(issue.path.length > 0, issue.check);
      assert.ok(issue.explanation.length > 20, issue.check);
    }
  });

  test('the validator never contacts a search engine', () => {
    const engine = readFileSync(path.join(root, 'src', 'lib', 'schema-validator', 'engine.ts'), 'utf8');
    assert.ok(!/fetch\(|https?:\/\/(?:www\.)?google\.com/.test(engine));
  });
});

describe('gate: validation history', () => {
  test('a run is stored with its version, source and timestamp', async () => {
    const outcome = await validateForProject({ db }, tenant, {
      projectId,
      sourceKind: 'pasted',
      source: JSON.stringify({ '@context': 'https://schema.org', '@type': 'Organization', name: 'Acme' }),
    });
    assert.ok(outcome.stored);
    assert.equal(outcome.stored.validatorVersion, VALIDATOR_VERSION);
    assert.ok(outcome.stored.checkedAt instanceof Date);
  });

  test('the history is listable and ordered newest first', async () => {
    for (const name of ['A', 'B', 'C']) {
      await validateForProject({ db }, tenant, {
        projectId,
        sourceKind: 'pasted',
        source: JSON.stringify({ '@context': 'https://schema.org', '@type': 'Organization', name }),
      });
    }
    const history = await listValidationHistory({ db }, tenant, projectId);
    assert.equal(history.length, 3);
    assert.ok(history[0]!.checkedAt.getTime() >= history[2]!.checkedAt.getTime());
  });

  test('a comparison names a validator-version change, because it confounds the diff', async () => {
    const { compareResults } = await import('../src/lib/schema-validator');
    const base = validateSchema({
      source: JSON.stringify({ '@context': 'https://schema.org', '@type': 'Organization', name: 'A' }),
      sourceKind: 'pasted',
    });
    const older = { ...base, validatorVersion: '4.0.0' };
    const comparison = compareResults(older, base);
    assert.equal(comparison.versionChanged, true);
    assert.match(comparison.summary, /validator itself changed/);
  });
});

describe('gate: corrected JSON-LD', () => {
  test('a correction offers before and after', () => {
    const source = JSON.stringify({ '@type': 'Organization', name: 'Acme' });
    const correction = buildCorrection(source, validateSchema({ source, sourceKind: 'pasted' }));
    assert.ok(correction.available);
    assert.notEqual(correction.before, correction.after);
  });

  test('a placeholder is visibly fake', () => {
    const source = JSON.stringify({ '@context': 'https://schema.org', '@type': 'LocalBusiness', name: 'A' });
    const correction = buildCorrection(source, validateSchema({ source, sourceKind: 'pasted' }));
    for (const placeholder of correction.placeholders) {
      const parsed = JSON.parse(correction.after) as Record<string, unknown>;
      assert.match(String(parsed[placeholder]), /^<add /);
    }
  });

  test('a correction never fills in a rating, price or credential', () => {
    const source = JSON.stringify({ '@context': 'https://schema.org', '@type': 'Product', name: 'Beans' });
    const correction = buildCorrection(source, validateSchema({ source, sourceKind: 'pasted' }));
    for (const property of ['aggregateRating', 'review', 'price', 'hasCredential']) {
      assert.ok(!new RegExp(`"${property}"`).test(correction.after), `filled in ${property}`);
    }
  });
});

describe('gate: competitor analysis', () => {
  test('all thirteen dimensions the brief names exist', async () => {
    const { COMPETITOR_DIMENSIONS } = await import('../src/lib/competitors/types');
    assert.equal(COMPETITOR_DIMENSIONS.length, 13);
  });

  test('verified data and AI inference are structurally distinct', () => {
    const analysis = analyzeCompetitor({
      competitorName: 'Rival',
      pages: [
        {
          url: 'https://rival.example.com/',
          readAt: '2026-09-01T10:00:00.000Z',
          status: 200,
          title: 'Rival',
          metaDescription: 'Rival Roasters is a speciality roastery in Nagpur serving since 2014.',
          h1: ['Rival'],
          h2: ['Beans'],
          textContent: 'words '.repeat(100),
          internalLinks: [],
          externalLinks: [],
          imageCount: 0,
          imagesWithAlt: 0,
          isHttps: true,
        },
      ],
    });
    for (const finding of analysis.findings) {
      if (finding.evidence.kind === 'verified_public') {
        assert.ok(finding.evidence.sourceUrl.length > 0);
        assert.ok(finding.evidence.observedAt.length > 0);
      } else {
        assert.ok(finding.evidence.basedOn.length > 0);
      }
    }
  });

  test('an analysis row has no column for the competitor\'s page content', () => {
    const migration = readFileSync(
      path.join(root, 'db', 'migrations', '0005_schema_competitors_ops.sql'),
      'utf8',
    );
    const table = migration.slice(
      migration.indexOf('CREATE TABLE IF NOT EXISTS competitor_analyses'),
      migration.indexOf('CREATE INDEX IF NOT EXISTS competitor_analyses_competitor_idx'),
    );
    assert.ok(!/\bhtml\b|\btext_content\b|\bpage_body\b/.test(table));
  });

  test('the acknowledgement is referenced with RESTRICT, like crawl consent', () => {
    const migration = readFileSync(
      path.join(root, 'db', 'migrations', '0005_schema_competitors_ops.sql'),
      'utf8',
    );
    assert.match(
      migration,
      /acknowledgement_id[^\n]*REFERENCES competitor_acknowledgements\(id\) ON DELETE RESTRICT/,
    );
  });
});

describe('gate: ads planning', () => {
  test('all five platforms from the brief are planned for', () => {
    assert.deepEqual([...AD_PLATFORMS], ['google_ads', 'meta', 'instagram', 'linkedin', 'youtube']);
  });

  test('a plan covers every element the brief lists', () => {
    const plan = {
      platform: 'google_ads' as const,
      objective: 'leads' as const,
      campaignName: 'Test',
      audience: { description: 'x'.repeat(30), locations: [], languages: [], signals: [], exclusions: [] },
      headlines: ['One heading here', 'Two heading here', 'Three heading here'],
      descriptions: ['A description long enough to be real.', 'A second description.'],
      primaryText: [],
      cta: '',
      creativeConcepts: [],
      landingPage: { url: 'https://acme-coffee.example.com/x', mustMatch: [], notes: [] },
      abIdeas: [],
      budget: recommendBudget({ currency: 'INR', objective: 'leads' }),
      reviewState: 'draft' as const,
    };
    // Every field the brief names is on the type; this compiles only if so.
    assert.ok(plan.audience && plan.headlines && plan.descriptions && plan.landingPage);
    assert.equal(checkAdPlan(plan).filter((problem) => problem.severity === 'error').length, 0);
  });

  test('AI recommendations are separated from live data, because there is none', () => {
    assert.equal(adsDataStatus().connected, false);
    assert.equal(performanceStatus().hasData, false);
    const budget = recommendBudget({ currency: 'INR', objective: 'sales' });
    assert.equal(budget.kind, 'ai_recommendation');
  });

  test('no budget type can carry a measurement', () => {
    const source = readFileSync(path.join(root, 'src', 'lib', 'ads', 'plan.ts'), 'utf8');
    const start = source.indexOf('export interface BudgetRecommendation');
    const block = source.slice(start, source.indexOf('}', start));
    assert.ok(!/costPerClick|conversionRate|spent|impressions/.test(block));
  });
});

describe('gate: leads', () => {
  test('the pipeline has the seven stages the brief names', () => {
    assert.deepEqual(
      [...LEAD_STAGES],
      ['new', 'contacted', 'qualified', 'proposal', 'negotiation', 'won', 'lost'],
    );
  });

  test('a lead carries source, status, score, notes and activities', async () => {
    const created = await createLead({ db }, tenant, {
      projectId,
      name: 'Test Lead',
      email: 'lead@example.com',
      enquiry: 'Asking about wholesale.',
      source: 'website_form',
    });
    assert.equal(created.lead.source, 'website_form');
    assert.equal(created.lead.stage, 'new');
    assert.ok(created.lead.score >= 0);
    assert.ok(created.lead.enquiry.length > 0);
  });

  test('the score is never stored without its components and basis', async () => {
    const created = await createLead({ db }, tenant, {
      projectId,
      name: 'Scored',
      email: 'scored@example.com',
    });
    assert.ok(created.lead.scoreComponents.length > 0);
    assert.ok(created.lead.scoreBasis.length > 40);
    assert.equal(created.lead.scoreBasis, SCORE_BASIS);
  });

  test('the components add up to the total', () => {
    const score = scoreLead({ email: 'a@b.com', source: 'referral', activities: [], createdAt: new Date() });
    assert.ok(scoreIsConsistent(score));
  });

  test('the database refuses a score with no basis', () => {
    const migration = readFileSync(
      path.join(root, 'db', 'migrations', '0005_schema_competitors_ops.sql'),
      'utf8',
    );
    assert.match(migration, /leads_score_has_basis/);
  });
});

describe('gate: email', () => {
  test('all six email kinds exist', () => {
    assert.deepEqual(
      [...EMAIL_KINDS],
      ['welcome', 'promotional', 'follow_up', 'newsletter', 're_engagement', 'nurturing'],
    );
  });

  test('a marketing email with no unsubscribe cannot pass', () => {
    const problems = checkMessagingPlan({
      channel: 'email',
      kind: 'promotional',
      subject: 'Offer',
      preheader: 'Offer inside',
      body: 'A body long enough to count as a real email body for the validator.',
      callsToAction: [],
      hasUnsubscribe: false,
      senderIdentification: 'Acme Coffee, Nagpur',
      optInBasis: 'explicit_opt_in',
      audienceDescription: 'Subscribers who opted in.',
    });
    assert.ok(problems.some((problem) => problem.severity === 'error' && problem.field === 'hasUnsubscribe'));
  });
});

describe('gate: whatsapp planning', () => {
  test('all five WhatsApp kinds exist', () => {
    assert.deepEqual([...WHATSAPP_KINDS], ['product', 'follow_up', 'offer', 'appointment', 'retention']);
  });

  test('content is template-shaped, as the official API requires', () => {
    const problems = checkMessagingPlan({
      channel: 'whatsapp',
      kind: 'offer',
      category: 'MARKETING',
      body: 'Hello {{1}}, our new roast is in.',
      buttons: [],
      placeholders: ['First name'],
      optInBasis: 'explicit_opt_in',
      audienceDescription: 'Opted-in customers.',
    });
    assert.equal(problems.filter((problem) => problem.severity === 'error').length, 0);
  });

  test('official APIs only — and no unofficial route is offered', () => {
    const status = sendingStatus('whatsapp');
    assert.equal(status.canSend, false);
    assert.match(status.whatWouldBeNeeded, /official WhatsApp Business API/i);
    assert.match(status.whatWouldBeNeeded, /unofficial automation gets numbers banned/i);
  });

  test('there is no send path anywhere in the codebase', () => {
    // The brief says "do not enable unauthorized spam". The strongest form of that
    // is that no function exists which could send.
    const offenders: string[] = [];
    for (const file of walk(path.join(root, 'src'))) {
      const contents = readFileSync(file, 'utf8');
      if (/\b(?:sendWhatsapp|sendWhatsApp|sendBulk|blastMessages|sendCampaign)\s*\(/.test(contents)) {
        offenders.push(path.relative(root, file));
      }
    }
    assert.deepEqual(offenders, []);
  });

  test('no messaging table records having sent anything', () => {
    const migration = readFileSync(
      path.join(root, 'db', 'migrations', '0005_schema_competitors_ops.sql'),
      'utf8',
    );
    const table = migration.slice(
      migration.indexOf('CREATE TABLE IF NOT EXISTS messaging_plans'),
      migration.indexOf('CREATE INDEX IF NOT EXISTS messaging_plans_project_idx'),
    );
    assert.ok(!/\bsent_at\b|\bscheduled_at\b|'sent'|'scheduled'/.test(table));
  });
});

describe('gate: video', () => {
  test('scripts cover hooks, scenes, voice-over, shot list, CTA, titles, tags and thumbnails', () => {
    const problems = checkVideoScript({
      platform: 'youtube_shorts',
      topic: 'Sour coffee',
      hook: 'Your coffee is sour for one reason.',
      scenes: [
        {
          index: 1,
          seconds: 10,
          shot: 'Close on the grinder.',
          voiceover: 'It is the grind.',
          onScreenText: 'The grind',
        },
      ],
      callToAction: 'Come and we will dial it in.',
      titles: ['Why your coffee is sour'],
      description: 'One setting fixes it.',
      tags: ['coffee'],
      thumbnailConcepts: [
        {
          title: 'Two cups',
          description: 'Two cups side by side, one pale and one dark, from above.',
          overlayText: 'Sour? One click',
          whyItWorks: 'States problem and fix at a glance.',
        },
      ],
      thumbnailImagesGenerated: false,
    });
    assert.equal(problems.filter((problem) => problem.severity === 'error').length, 0);
    assert.equal(VIDEO_PLATFORMS.length, 4);
  });

  test('image generation is off, and no type can hold an image', () => {
    assert.equal(imageGenerationStatus().canGenerate, false);
    const source = readFileSync(path.join(root, 'src', 'lib', 'video', 'types.ts'), 'utf8');
    const start = source.indexOf('export interface ThumbnailConcept');
    const block = source.slice(start, source.indexOf('}', start));
    assert.ok(!/imageUrl|imageData|base64|src/.test(block));
  });

  test('no video table has an image column', () => {
    const migration = readFileSync(
      path.join(root, 'db', 'migrations', '0005_schema_competitors_ops.sql'),
      'utf8',
    );
    const table = migration.slice(
      migration.indexOf('CREATE TABLE IF NOT EXISTS video_scripts'),
      migration.indexOf('CREATE INDEX IF NOT EXISTS video_scripts_project_idx'),
    );
    assert.ok(!/image_url|thumbnail_url|image_data/.test(table));
  });
});

describe('gate: provenance', () => {
  test('generated schema reports where every value came from', () => {
    const generated = generateSchema({
      kind: 'organization',
      business: { name: 'Acme Coffee', websiteUrl: 'https://acme-coffee.example.com' },
    });
    for (const value of generated.included) {
      assert.ok(['user_provided', 'connected', 'retrieved'].includes(value.source));
      assert.ok(value.from.length > 0);
    }
  });

  test('a competitor finding cannot exist without evidence', () => {
    const analysis = analyzeCompetitor({ competitorName: 'Rival', pages: [] });
    for (const finding of analysis.findings) {
      assert.ok(finding.evidence);
    }
  });

  test('a validation result says what it did not evaluate', () => {
    const result = validateSchema({
      source: JSON.stringify({ '@context': 'https://schema.org', '@type': 'Organization', name: 'A' }),
      sourceKind: 'pasted',
    });
    assert.ok(result.issues.some((issue) => issue.status === 'NOT_EVALUATED'));
  });
});

describe('gate: no fabricated facts', () => {
  test('no Phase 5 module promises a ranking, a citation or guaranteed traffic', () => {
    const forbidden: { readonly label: string; readonly pattern: RegExp }[] = [
      { label: 'guaranteed traffic', pattern: /\bguarantee[ds]?\s+\w*\s*(?:traffic|ranking|results|leads)\b/i },
      { label: 'a promised ranking', pattern: /\bwill rank\b/i },
      { label: 'a promised citation', pattern: /\bwill be cited\b/i },
      { label: 'an AI visibility score', pattern: /\bAI visibility score\b/i },
      { label: 'a ranking superlative', pattern: /(#1\b|\bnumber one\b|\btop of (?:google|search)\b)/i },
    ];

    const directories = ['schema-validator', 'schema', 'competitors', 'ads', 'leads', 'messaging', 'video'];
    for (const directory of directories) {
      for (const file of walk(path.join(root, 'src', 'lib', directory))) {
        const contents = readFileSync(file, 'utf8');
        // Strings only: a comment may legitimately describe what is forbidden.
        const strings = [...contents.matchAll(/(?:'((?:[^'\\]|\\.)*)'|"((?:[^"\\]|\\.)*)"|`([^`]*)`)/g)]
          .map((match) => match[1] ?? match[2] ?? match[3] ?? '');
        for (const value of strings) {
          for (const rule of forbidden) {
            assert.ok(
              !rule.pattern.test(value),
              `${path.relative(root, file)} contains ${rule.label}: ${value.slice(0, 120)}`,
            );
          }
        }
      }
    }
  });

  test('the generator refuses the properties people fake', () => {
    const generated = generateSchema({ kind: 'local_business', business: { name: 'A' } });
    assert.ok(generated.refused.length > 0);
    for (const property of ['aggregateRating', 'review', 'price', 'availability', 'award']) {
      assert.ok(
        generated.refused.some((refusal) => refusal.property === property),
        `${property} is not on the refusal list`,
      );
    }
  });

  test('an ad plan cannot claim a generated image', () => {
    const problems = checkAdPlan({
      platform: 'meta',
      objective: 'traffic',
      campaignName: 'X',
      audience: { description: 'x'.repeat(30), locations: [], languages: [], signals: [], exclusions: [] },
      headlines: ['One'],
      descriptions: [],
      primaryText: ['Some text'],
      cta: 'Learn more',
      creativeConcepts: [
        {
          title: 'A',
          visual: 'B',
          angle: 'C',
          imageGenerated: true as unknown as false,
        },
      ],
      landingPage: { url: 'https://acme-coffee.example.com/', mustMatch: [], notes: [] },
      abIdeas: [],
      budget: recommendBudget({ currency: 'INR', objective: 'traffic' }),
      reviewState: 'draft',
    });
    assert.ok(problems.some((problem) => /no image exists/.test(problem.message)));
  });
});

describe('gate: security tests', () => {
  test('no Phase 5 module opens a raw socket or resolves DNS itself', () => {
    const offenders: string[] = [];
    for (const directory of ['schema-validator', 'schema', 'ads', 'leads', 'messaging', 'video']) {
      for (const file of walk(path.join(root, 'src', 'lib', directory))) {
        const contents = readFileSync(file, 'utf8');
        if (/from\s+['"]node:(?:https?|dns|net)['"]/.test(contents)) {
          offenders.push(path.relative(root, file));
        }
      }
    }
    assert.deepEqual(offenders, [], 'only the crawler may open connections');
  });

  test('competitor fetching goes through the crawler\'s own safe path', () => {
    const service = readFileSync(path.join(root, 'src', 'lib', 'competitors', 'service.ts'), 'utf8');
    assert.match(service, /safeFetch/);
    assert.ok(!/from\s+['"]node:(?:https?|dns|net)['"]/.test(service));
  });

  test('every new table has row-level security enabled', () => {
    const migration = readFileSync(
      path.join(root, 'db', 'migrations', '0005_schema_competitors_ops.sql'),
      'utf8',
    );
    for (const table of [
      'schema_validations',
      'competitors',
      'competitor_acknowledgements',
      'competitor_analyses',
      'ad_plans',
      'lead_activities',
      'messaging_plans',
      'video_scripts',
    ]) {
      assert.match(
        migration,
        new RegExp(`ALTER TABLE ${table}\\s+ENABLE ROW LEVEL SECURITY`),
        `${table} has no row-level security`,
      );
    }
  });

  test('a forbidden opt-in basis cannot be stored', () => {
    const migration = readFileSync(
      path.join(root, 'db', 'migrations', '0005_schema_competitors_ops.sql'),
      'utf8',
    );
    const table = migration.slice(
      migration.indexOf('CREATE TABLE IF NOT EXISTS messaging_plans'),
      migration.indexOf('CREATE INDEX IF NOT EXISTS messaging_plans_project_idx'),
    );
    assert.ok(!/purchased_list|scraped/.test(table), 'the column must not permit a forbidden basis');
  });

  test('no client component imports a service or the database', () => {
    const offenders: string[] = [];
    for (const file of walk(path.join(root, 'src', 'components'))) {
      const contents = readFileSync(file, 'utf8');
      if (!/^['"]use client['"]/m.test(contents)) continue;
      for (const match of contents.matchAll(/^import\s+(?!type\s)([\s\S]*?)from\s+['"]([^'"]+)['"]/gm)) {
        const specifier = match[2] ?? '';
        const clause = match[1] ?? '';
        if (/\/service$|@\/lib\/db/.test(specifier) && !/^\s*\{\s*(type\s)/.test(clause)) {
          offenders.push(`${path.relative(root, file)} -> ${specifier}`);
        }
      }
    }
    assert.deepEqual(offenders, []);
  });
});

describe('gate: production build', () => {
  test('no new production dependency was added', () => {
    const manifest = JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8')) as {
      dependencies: Record<string, string>;
    };
    assert.deepEqual(Object.keys(manifest.dependencies).sort(), [
      'clsx',
      'next',
      'react',
      'react-dom',
      'tailwind-merge',
    ]);
  });

  test('every new route is a real route file with an exported handler', () => {
    const routes = [
      'schema/validate',
      'schema/generate',
      'schema/history',
      'competitors',
      'competitors/[id]',
      'ads',
      'ads/[id]',
      'leads',
      'leads/[id]',
      'leads/[id]/activities',
      'messaging',
      'messaging/[id]',
      'video',
      'video/[id]',
    ];
    for (const route of routes) {
      const file = path.join(root, 'src', 'app', 'api', route, 'route.ts');
      const contents = readFileSync(file, 'utf8');
      assert.ok(
        /export async function (?:GET|POST|PATCH|DELETE)/.test(contents),
        `${route} exports no handler`,
      );
    }
  });

  test('the generated schema file matches the migrations', () => {
    const schema = readFileSync(path.join(root, 'db', 'schema.sql'), 'utf8');
    for (const table of ['schema_validations', 'competitors', 'ad_plans', 'messaging_plans', 'video_scripts']) {
      assert.ok(schema.includes(`CREATE TABLE IF NOT EXISTS ${table}`), `${table} missing from schema.sql`);
    }
  });
});

describe('gate: no delivered phase is still advertised as upcoming', () => {
  // Carried forward from Phase 4, with DELIVERED bumped. See that file for why.
  const DELIVERED = 5;

  function phaseNumbers(text: string): number[] {
    return [...text.matchAll(/Phase (\d+)/g)].map((match) => Number(match[1]));
  }

  test('no planned agent points at a phase that has already shipped', async () => {
    const { plannedAgents } = await import('../src/lib/ai/agents');
    for (const agent of plannedAgents()) {
      for (const number of phaseNumbers(agent.phase ?? '')) {
        assert.ok(number > DELIVERED, `${agent.id} says it arrives in Phase ${number}, which has shipped`);
      }
    }
  });

  test('no navigation note promises a phase that has already shipped', async () => {
    const nav = await import('../src/content/app-nav');
    for (const item of [...nav.appPrimaryNav, ...nav.appMoreNav]) {
      for (const number of phaseNumbers(item.note ?? '')) {
        assert.ok(number > DELIVERED, `the "${item.label}" note promises Phase ${number}`);
      }
    }
  });

  test('no "Soon" screen promises a phase that has already shipped', () => {
    const offenders: string[] = [];
    for (const file of walk(path.join(root, 'src', 'app'))) {
      const contents = readFileSync(file, 'utf8');
      for (const match of contents.matchAll(/phase="Phase (\d+)"/g)) {
        if (Number(match[1]) <= DELIVERED) offenders.push(`${path.relative(root, file)}: ${match[0]}`);
      }
    }
    assert.deepEqual(offenders, []);
  });

  test('the screens delivered in Phase 5 are marked available', async () => {
    const nav = await import('../src/content/app-nav');
    const items = [...nav.appPrimaryNav, ...nav.appMoreNav];
    for (const href of [
      '/app/schema-validator',
      '/app/competitors',
      '/app/campaigns',
      '/app/leads',
      '/app/messaging',
      '/app/video',
    ]) {
      const item = items.find((candidate) => candidate.href === href);
      assert.ok(item, `${href} is missing from the navigation`);
      assert.equal(item.status, 'available', `${href} shipped but is still marked planned`);
    }
  });
});
