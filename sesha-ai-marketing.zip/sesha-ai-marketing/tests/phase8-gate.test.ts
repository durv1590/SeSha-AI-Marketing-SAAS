import assert from 'node:assert/strict';
import { test, describe } from 'node:test';
import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { isAllowedAddress, checkHostname } from '../src/lib/crawler/ip-policy';
import { ALLOWED_PROTOCOLS } from '../src/lib/crawler/url-policy';
import { DEFAULT_MAX_BYTES, DEFAULT_MAX_REDIRECTS, DEFAULT_TIMEOUT_MS } from '../src/lib/crawler/fetcher';
import { CURRENT_PARAMS } from '../src/lib/auth/password';
import { ACCOUNT_POLICY } from '../src/lib/auth/lockout';
import { SESSION_IDLE_TIMEOUT, SESSION_ABSOLUTE_LIFETIME } from '../src/lib/auth/tokens';
import { clientKey } from '../src/lib/security/rate-limit';
import { MAX_PAGE_SIZE, decodeCursor, encodeCursor, pageSize } from '../src/lib/api/pagination';
import { REDACTED, redact } from '../src/lib/observability/log';
import { isMaintenanceAuthorized } from '../src/lib/jobs/maintenance';
import { TABLES } from '../src/lib/db/types';

/**
 * PHASE 8 QUALITY GATE — the sixteen items in the brief, one describe each.
 *
 * Behaviour is tested where it can be exercised; the rest is a source scan
 * over comment-stripped code, so a control cannot be satisfied by a comment
 * that promises it. Item 16 (production build) is checked as far as it can be
 * offline, and says so: `next build` has never run in this environment.
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (relative: string) => readFileSync(path.join(root, relative), 'utf8');

function walk(dir: string, filter = /\.(ts|tsx)$/): string[] {
  const out: string[] = [];
  if (!existsSync(dir)) return out;
  for (const entry of readdirSync(dir)) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) out.push(...walk(full, filter));
    else if (filter.test(entry)) out.push(full);
  }
  return out;
}

/** Strips block and line comments, so a promise in prose satisfies nothing. */
function code(text: string): string {
  return text.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"`])\/\/.*$/gm, '$1');
}

const apiRoutes = walk(path.join(root, 'src', 'app', 'api')).filter((file) => file.endsWith('route.ts'));
const rel = (file: string) => path.relative(root, file);
const MUTATING = /export async function (POST|PUT|PATCH|DELETE)\b/;

/* 1 ------------------------------------------------------------------------ */
describe('gate 1: security audit', () => {
  test('the audit document covers every §1, §2 and §3 heading of the brief', () => {
    const audit = read('SECURITY-AUDIT.md');
    for (const term of [
      'Authentication', 'Authorization', 'Session', 'Password', 'API security', 'SQL injection',
      'XSS', 'CSRF', 'SSRF', 'File handling', 'URL validation', 'Tenant isolation',
      'Rate limiting', 'Secret exposure', 'Admin security',
      'DNS rebinding', 'metadata', 'Redirect', 'Large responses', 'Slow responses',
      'Dangerous protocols', 'Resource exhaustion',
      'Data export', 'Account deletion', 'Crawl history deletion', 'Retention', 'AI disclosure',
    ]) {
      assert.ok(audit.includes(term), `SECURITY-AUDIT.md does not address "${term}"`);
    }
  });

  test('the audit states its residual risks rather than claiming completeness', () => {
    assert.match(read('SECURITY-AUDIT.md'), /## Residual risks/);
  });
});

/* 2 ------------------------------------------------------------------------ */
describe('gate 2: SSRF', () => {
  test('loopback, private, link-local and cloud-metadata addresses are refused', () => {
    for (const address of [
      '127.0.0.1', '10.0.0.1', '172.16.0.1', '192.168.1.1', '169.254.169.254',
      '0.0.0.0', '::1', 'fd00:ec2::254', '::ffff:127.0.0.1', '100.64.0.1',
    ]) {
      assert.equal(isAllowedAddress(address), false, `${address} is reachable`);
    }
    assert.equal(isAllowedAddress('93.184.216.34'), true, 'a public address is refused');
  });

  test('internal hostnames are refused before resolution', () => {
    for (const host of ['localhost', 'metadata.google.internal']) {
      assert.equal(checkHostname(host).allowed, false, `${host} is allowed`);
    }
  });

  test('only http and https; bounded redirects, bytes and time', () => {
    assert.deepEqual([...ALLOWED_PROTOCOLS], ['http:', 'https:']);
    assert.ok(DEFAULT_MAX_REDIRECTS <= 5);
    assert.ok(DEFAULT_MAX_BYTES <= 5_000_000);
    assert.ok(DEFAULT_TIMEOUT_MS <= 30_000);
  });

  test('the transport has a wall clock and pins the vetted address', () => {
    const fetcher = code(read('src/lib/crawler/fetcher.ts'));
    assert.match(fetcher, /wallClock = setTimeout\(/);
    assert.match(fetcher, /options\?\.all/);
  });
});

/* 3 ------------------------------------------------------------------------ */
describe('gate 3: tenant isolation', () => {
  // Routes that are public BY DESIGN. Anything else must authenticate.
  const PUBLIC = [
    'api/auth/', 'api/contact/', 'api/newsletter/', 'api/schema-validator/', 'api/health/',
    'api/share/', 'api/billing/webhook', 'api/internal/maintenance/',
  ];

  test('every non-public API route authenticates before it reads data', () => {
    const offenders = apiRoutes
      .filter((file) => !PUBLIC.some((prefix) => rel(file).includes(prefix)))
      .filter((file) => !/require(Auth|Authorized|Staff)\(/.test(code(read(rel(file)))))
      .map(rel);
    assert.deepEqual(offenders, []);
  });

  test('the export cannot include another tenant (behaviour: tests/privacy.test.ts)', () => {
    assert.match(read('tests/privacy.test.ts'), /EXPORT CONTAINS NOTHING OF ANOTHER/);
  });
});

/* 4 ------------------------------------------------------------------------ */
describe('gate 4: authentication', () => {
  test('password hashing, lockout and session lifetimes meet the policy', () => {
    assert.ok(CURRENT_PARAMS.N >= 65_536);
    assert.ok(ACCOUNT_POLICY.threshold <= 5);
    assert.ok(SESSION_IDLE_TIMEOUT <= 14 * 24 * 60 * 60 * 1000);
    assert.ok(SESSION_ABSOLUTE_LIFETIME <= 90 * 24 * 60 * 60 * 1000);
  });

  test('a password change revokes every session, the acting one included', () => {
    const service = code(read('src/lib/auth/service.ts'));
    const body = service.slice(service.indexOf('export async function changePassword'));
    assert.match(body.slice(0, 3_000), /revokeAllForUser/);
  });

  test('the session cookie is httpOnly', () => {
    assert.match(code(read('src/lib/auth/session.ts')), /httpOnly: true/);
  });
});

/* 5 ------------------------------------------------------------------------ */
describe('gate 5: authorization', () => {
  test('every admin API route goes through the admin guard', () => {
    const offenders = apiRoutes
      .filter((file) => rel(file).includes(`api${path.sep}admin`))
      .filter((file) => !/requireAdmin\w*\(|adminGuard|guardAdmin|requireStaff/.test(code(read(rel(file)))))
      .map(rel);
    assert.deepEqual(offenders, []);
  });

  test('the admin refusal shape lives in one place', () => {
    assert.match(code(read('src/lib/api/admin-guard.ts')), /adminRefusal\(/);
  });

  test('the export requires both sudo and a permission', () => {
    const route = code(read('src/app/api/account/export/route.ts'));
    assert.match(route, /isSudo\(/);
    assert.match(route, /can\(auth\.tenant\.role, 'billing:read'\)/);
  });
});

/* 6 ------------------------------------------------------------------------ */
describe('gate 6: rate limiting', () => {
  test('every mutating API route is rate limited (the bearer-only cron route excepted)', () => {
    const offenders = apiRoutes
      .filter((file) => MUTATING.test(read(rel(file))))
      .filter((file) => !rel(file).includes('internal'))
      .filter((file) => !/enforceRateLimit\(|rateLimit\(|checkRateLimit\(/.test(code(read(rel(file)))))
      .map(rel);
    assert.deepEqual(offenders, []);
  });

  test('a client cannot choose its own rate-limit identity', () => {
    const headers = (value: string) => ({ get: (name: string) => (name === 'x-forwarded-for' ? value : null) });
    // Behind one proxy, the proxy appended the real address LAST.
    assert.equal(clientKey(headers('6.6.6.6, 203.0.113.9')), clientKey(headers('1.1.1.1, 203.0.113.9')));
  });
});

/* 7 ------------------------------------------------------------------------ */
describe('gate 7: performance', () => {
  test('page size is capped and cursors are opaque and validated', () => {
    assert.ok(MAX_PAGE_SIZE <= 100);
    assert.equal(pageSize('100000'), MAX_PAGE_SIZE);
    assert.equal(decodeCursor('not-a-cursor'), null);
    const cursor = encodeCursor({ at: new Date(0).toISOString(), id: 'x' });
    assert.ok(decodeCursor(cursor));
  });

  test('the admin audit list is paginated, not unbounded', () => {
    assert.match(code(read('src/app/api/admin/audit/route.ts')), /pageParams\(/);
  });

  test('migration 0008 indexes the foreign keys and the cursor order', () => {
    const sql = read('db/migrations/0008_indexes_and_operations.sql');
    assert.ok((sql.match(/CREATE INDEX IF NOT EXISTS/g) ?? []).length >= 25);
    assert.match(sql, /\(created_at DESC, id DESC\)/);
    assert.ok(TABLES.includes('idempotency_keys' as never));
  });

  test('non-fingerprinted assets are never cached immutable', () => {
    const config = code(read('next.config.ts'));
    assert.ok(!config.includes('/fonts/'), 'the dead /fonts rule is back');
    assert.ok(!/brand\|og[\s\S]{0,200}immutable/.test(config));
  });
});

/* 8 ------------------------------------------------------------------------ */
describe('gate 8: accessibility', () => {
  test('every design-token pair meets WCAG contrast in both themes', () => {
    const run = spawnSync(process.execPath, [path.join(root, 'scripts', 'contrast-check.mjs')], {
      encoding: 'utf8',
    });
    assert.equal(run.status, 0, run.stdout.split('\n').filter((line) => line.includes('FAIL')).join('\n'));
  });

  test('every data table has a caption', () => {
    const offenders: string[] = [];
    for (const file of walk(path.join(root, 'src'), /\.tsx$/)) {
      const text = read(rel(file));
      const tables = (text.match(/<table\b/g) ?? []).length;
      const captions = (text.match(/<caption\b/g) ?? []).length;
      if (tables > captions) offenders.push(rel(file));
    }
    assert.deepEqual(offenders, []);
  });

  test('dialogs have generated, unique label ids', () => {
    assert.match(code(read('src/components/ui/modal.tsx')), /useId\(\)/);
  });

  test('reduced motion is honoured globally', () => {
    assert.match(read('src/app/globals.css'), /prefers-reduced-motion: reduce/);
  });
});

/* 9 ------------------------------------------------------------------------ */
describe('gate 9: SEO', () => {
  test('robots and sitemap are generated', () => {
    assert.ok(existsSync(path.join(root, 'src', 'app', 'robots.ts')));
    assert.ok(existsSync(path.join(root, 'src', 'app', 'sitemap.ts')));
  });

  test('every marketing page declares metadata', () => {
    const offenders = walk(path.join(root, 'src', 'app', '(marketing)'), /^page\.tsx$/)
      .filter((file) => !/export (const metadata|async function generateMetadata|function generateMetadata)/.test(read(rel(file))))
      .map(rel);
    assert.deepEqual(offenders, []);
  });
});

/* 10 ----------------------------------------------------------------------- */
describe('gate 10: AEO', () => {
  test('FAQ content is emitted as FAQPage structured data', () => {
    assert.match(read('src/components/marketing/faq-section.tsx'), /FAQPage/);
  });

  test('the Organization entity is described in structured data', () => {
    assert.match(read('src/lib/schema/index.ts'), /Organization/);
  });
});

/* 11 ----------------------------------------------------------------------- */
describe('gate 11: error monitoring', () => {
  test('errors are persisted and the logger has an error level', () => {
    assert.ok(TABLES.includes('error_events' as never));
    assert.match(code(read('src/lib/observability/log.ts')), /level === 'error'/);
  });
});

/* 12 ----------------------------------------------------------------------- */
describe('gate 12: logging never carries secrets', () => {
  test('secret keys and secret-shaped values are redacted', () => {
    const out = redact({
      password: 'hunter2hunter2',
      apiKey: 'abc',
      note: 'Authorization: Bearer abcdefghijklmnop then Bearer qrstuvwxyz012345',
      nested: { sessionToken: 'x' },
    }) as Record<string, unknown>;
    assert.equal(out.password, REDACTED);
    assert.equal(out.apiKey, REDACTED);
    assert.ok(!String(out.note).includes('abcdefghijklmnop'));
    assert.ok(!String(out.note).includes('qrstuvwxyz012345'), 'only the first token was redacted');
    assert.equal((out.nested as Record<string, unknown>).sessionToken, REDACTED);
  });

  test('the export route logs counts, never the document', () => {
    const route = code(read('src/app/api/account/export/route.ts'));
    assert.match(route, /counts: exported\.counts/);
    assert.ok(!/log\.\w+\([^)]*body/.test(route));
  });
});

/* 13 ----------------------------------------------------------------------- */
describe('gate 13: backup strategy', () => {
  test('the runbook defines PITR, logical dumps, encryption and a restore drill', () => {
    const ops = read('docs/OPERATIONS.md');
    for (const term of ['PITR', 'pg_dump', 'encrypted', 'Restore drill', 'RPO', 'RTO']) {
      assert.ok(ops.includes(term), `OPERATIONS.md is missing "${term}"`);
    }
  });
});

/* 14 ----------------------------------------------------------------------- */
describe('gate 14: data deletion', () => {
  test('account and crawl-history deletion are reachable over HTTP', () => {
    assert.match(read('src/app/api/account/route.ts'), /export async function DELETE/);
    assert.match(read('src/app/api/crawl/route.ts'), /export async function DELETE/);
  });

  test('revoking consent deletes the pages, not just the marker', () => {
    const service = code(read('src/lib/workspace/service.ts'));
    const body = service.slice(service.indexOf('export async function revokeCrawlConsent'));
    assert.match(body.slice(0, 2_500), /deletePages\(/);
  });

  test('retention is enforced by a scheduled entry point that refuses the unauthenticated', () => {
    assert.match(code(read('src/lib/jobs/maintenance.ts')), /deleteExpiredCrawlData\(/);
    assert.equal(isMaintenanceAuthorized('Bearer x', undefined), false);
  });
});

/* 15 ----------------------------------------------------------------------- */
describe('gate 15: data export', () => {
  test('the export is a no-store attachment and reachable from Settings', () => {
    const route = code(read('src/app/api/account/export/route.ts'));
    assert.match(route, /'Cache-Control': 'private, no-store'/);
    assert.match(route, /attachment; filename=/);
    assert.match(read('src/app/(app)/app/settings/page.tsx'), /<ExportDataCard/);
  });

  test('the privacy policy discloses AI processing, crawling and the export', () => {
    const legal = read('src/content/legal.ts');
    assert.match(legal, /id: 'ai-processing'/);
    assert.match(legal, /id: 'crawling'/);
    assert.match(legal, /download a complete copy/);
  });
});

/* 16 ----------------------------------------------------------------------- */
describe('gate 16: production build', () => {
  test('the build is configured to fail on type errors and hide its framework', () => {
    const config = code(read('next.config.ts'));
    assert.match(config, /ignoreBuildErrors: false/);
    assert.match(config, /poweredByHeader: false/);
  });

  test('`npm run verify` includes the real build, and the report says it has not run', () => {
    const pkg = JSON.parse(read('package.json')) as { scripts: Record<string, string> };
    assert.match(pkg.scripts.verify ?? '', /npm run build/);
    assert.match(read('PHASE-8-REPORT.md'), /has not been run/i);
  });

  test('the cross-browser specs exist for Firefox, WebKit, Edge, Android and iOS', () => {
    const config = read('playwright.config.ts');
    for (const name of ['firefox', 'webkit', 'edge', 'android', 'ios']) {
      assert.match(config, new RegExp(`name: '${name}'`));
    }
    assert.match(read('tests/e2e/production.spec.ts'), /@cross-browser/);
  });
});
