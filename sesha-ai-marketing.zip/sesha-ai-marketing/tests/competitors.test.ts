import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { signUp, toRole } from '../src/lib/auth/service';
import { completeOnboarding } from '../src/lib/workspace/service';
import { NotFoundError, type TenantContext } from '../src/lib/tenant';
import type { Transport } from '../src/lib/crawler';
import {
  COMPETITOR_ACKNOWLEDGEMENT,
  COMPETITOR_ACKNOWLEDGEMENT_VERSION,
  COMPETITOR_FETCH_POLICY,
  analyzeCompetitor,
  withInferences,
  type CompetitorPage,
} from '../src/lib/competitors/analyze';
import {
  AcknowledgementRequiredError,
  CompetitorInputError,
  acknowledgeResearch,
  addCompetitor,
  analyseCompetitor,
  latestAnalysis,
  listCompetitors,
  withdrawAcknowledgement,
  type CompetitorServiceContext,
} from '../src/lib/competitors/service';
import {
  COMPETITOR_DIMENSIONS,
  FORBIDDEN_CLAIMS,
  lintCompetitorFindings,
  type CompetitorFinding,
} from '../src/lib/competitors/types';

/**
 * Competitor intelligence.
 *
 * The assertions that matter most are the two authorisation ones and the
 * verified-versus-inferred separation. These findings are about a THIRD PARTY: an
 * invented claim here is not an inaccuracy in a marketing tool, it is a statement
 * about another business that the user may repeat in a pitch.
 */

const PASSWORD = 'a genuinely long passphrase 2026';
const RIVAL = 'https://rival-roasters.example.com';

function rivalPage(title: string, extra = ''): string {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8">
    <title>${title}</title>
    <meta name="description" content="Rival Roasters is a speciality coffee roastery serving Nagpur since 2014.">
    </head><body><h1>${title}</h1>
    <h2>Single origin beans</h2><h2>Subscriptions</h2>
    <p>${'We roast to order in small batches. '.repeat(20)}</p>
    <a href="https://www.instagram.com/rivalroasters">Instagram</a>
    <a href="https://www.linkedin.com/company/rival">LinkedIn</a>
    <img src="/a.png" alt="Our roastery"><img src="/b.png">
    ${extra}
    </body></html>`;
}

function transportFor(pages: Record<string, { status: number; body?: string; type?: string }>): {
  transport: Transport;
  requests: string[];
} {
  const requests: string[] = [];
  const transport: Transport = async (request) => {
    requests.push(request.url);
    const scripted = pages[request.url];
    if (!scripted) {
      return { status: 404, headers: { 'content-type': 'text/html' }, body: '', bytes: 0, truncated: false };
    }
    const body = scripted.body ?? '';
    return {
      status: scripted.status,
      headers: { 'content-type': scripted.type ?? 'text/html' },
      body,
      bytes: Buffer.byteLength(body),
      truncated: false,
    };
  };
  return { transport, requests };
}

const defaultRival: Record<string, { status: number; body?: string; type?: string }> = {
  [`${RIVAL}/robots.txt`]: { status: 404 },
  [`${RIVAL}/`]: { status: 200, body: rivalPage('Rival Roasters') },
  [`${RIVAL}/about`]: { status: 200, body: rivalPage('About Rival Roasters') },
  [`${RIVAL}/pricing`]: { status: 200, body: rivalPage('Pricing') },
};

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: 'https://acme-coffee.example.com',
};

const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic'] as const,
  marketingChannels: ['organic-search'] as const,
  brandVoice: { tones: ['friendly'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters' }],
};

let db: MemoryDatabase;
let tenant: TenantContext;
let projectId: string;
let service: CompetitorServiceContext;
let requests: string[];

async function makeTenant(email: string): Promise<{ tenant: TenantContext; projectId: string }> {
  const signed = await signUp(
    { db, lockout: new MemoryLockoutStore(), secret: 'test-secret-value-at-least-32-bytes-long' },
    { email, password: PASSWORD },
  );
  if (!signed.ok || !signed.userId) throw new Error('signup failed');
  const memberships = await db.memberships.findForUser(signed.userId);
  const context: TenantContext = {
    userId: signed.userId,
    organizationId: memberships[0]!.organizationId,
    role: toRole(memberships[0]!.role),
  };
  const onboarded = await completeOnboarding({ db }, context, { business, profile });
  return { tenant: context, projectId: onboarded.project.id };
}

function serviceWith(pages = defaultRival): CompetitorServiceContext {
  const scripted = transportFor(pages);
  requests = scripted.requests;
  return {
    db,
    fetchOptions: {
      transport: scripted.transport,
      lookup: async () => [{ address: '93.184.216.34', family: 4 }],
    },
  };
}

async function addRival(): Promise<string> {
  const competitor = await addCompetitor(service, tenant, {
    projectId,
    name: 'Rival Roasters',
    websiteUrl: RIVAL,
  });
  return competitor.id;
}

beforeEach(async () => {
  db = new MemoryDatabase();
  service = serviceWith();
  const made = await makeTenant(`owner-${Math.random().toString(36).slice(2)}@example.com`);
  tenant = made.tenant;
  projectId = made.projectId;
});

/* -------------------------------------------------------------------------- */

describe('authorisation', () => {
  test('analysis is refused without an acknowledgement', async () => {
    const id = await addRival();
    await assert.rejects(
      () => analyseCompetitor(service, tenant, id),
      (error: unknown) => error instanceof AcknowledgementRequiredError,
    );
    assert.deepEqual(requests, [], 'nothing may be fetched without authorisation');
  });

  test('the acknowledgement records who accepted it, when, and which wording', async () => {
    const id = await addRival();
    await acknowledgeResearch(service, tenant, id, true);

    const live = await db.competitorAcknowledgements.findLive(tenant.organizationId, id);
    assert.ok(live);
    assert.equal(live.acknowledgedBy, tenant.userId);
    assert.equal(live.statementVersion, COMPETITOR_ACKNOWLEDGEMENT_VERSION);
    assert.equal(live.maxPages, COMPETITOR_FETCH_POLICY.maxPages);
  });

  test('declining records nothing and reads no page', async () => {
    const id = await addRival();
    await assert.rejects(
      () => acknowledgeResearch(service, tenant, id, false),
      (error: unknown) => error instanceof AcknowledgementRequiredError,
    );
    assert.equal(await db.competitorAcknowledgements.findLive(tenant.organizationId, id), null);
  });

  test('the acknowledgement is checked AGAIN immediately before fetching', async () => {
    // The gap between requesting an analysis and making the first request is where
    // a withdrawal lands. Removing this second check is the mutation this test
    // exists to catch.
    const id = await addRival();
    await acknowledgeResearch(service, tenant, id, true);

    const sneaky: CompetitorServiceContext = {
      ...service,
      db: {
        ...db,
        competitorAcknowledgements: {
          ...db.competitorAcknowledgements,
          // Live for the first check, withdrawn by the time the fetch starts.
          findLive: (() => {
            let calls = 0;
            return async (organizationId: string, competitorId: string) => {
              calls += 1;
              if (calls === 1) {
                return db.competitorAcknowledgements.findLive(organizationId, competitorId);
              }
              return null;
            };
          })(),
        },
      } as typeof db,
    };

    await assert.rejects(
      () => analyseCompetitor(sneaky, tenant, id),
      (error: unknown) => error instanceof AcknowledgementRequiredError,
    );
    assert.deepEqual(requests, [], 'a withdrawn acknowledgement must stop the fetch');
  });

  test('withdrawing stops further reading but keeps past analyses', async () => {
    const id = await addRival();
    await acknowledgeResearch(service, tenant, id, true);
    await analyseCompetitor(service, tenant, id);

    await withdrawAcknowledgement(service, tenant, id);

    const kept = await latestAnalysis(service, tenant, id);
    assert.ok(kept, 'past analyses are the customer\'s own record and are kept');

    await assert.rejects(
      () => analyseCompetitor(service, tenant, id),
      (error: unknown) => error instanceof AcknowledgementRequiredError,
    );
  });

  test('the acknowledgement wording says what actually happens', async () => {
    assert.match(COMPETITOR_ACKNOWLEDGEMENT, /publicly available pages/i);
    assert.match(COMPETITOR_ACKNOWLEDGEMENT, /three pages/i);
    assert.match(COMPETITOR_ACKNOWLEDGEMENT, /robots\.txt/i);
    assert.match(COMPETITOR_ACKNOWLEDGEMENT, /no page content is stored/i);
    assert.match(COMPETITOR_ACKNOWLEDGEMENT, /inference/i);
  });

  test('a competitor in another organization is a 404, not a 403', async () => {
    const id = await addRival();
    const other = await makeTenant('other-competitors@example.com');
    await assert.rejects(
      () => analyseCompetitor(service, other.tenant, id),
      (error: unknown) => error instanceof NotFoundError,
    );
  });
});

describe('the fetch policy is the crawler\'s, narrowed', () => {
  test('at most three pages are read', async () => {
    const id = await addRival();
    await acknowledgeResearch(service, tenant, id, true);
    await analyseCompetitor(service, tenant, id);

    const pageRequests = requests.filter((url) => !url.endsWith('/robots.txt'));
    assert.ok(
      pageRequests.length <= COMPETITOR_FETCH_POLICY.maxPages,
      `read ${pageRequests.length} pages, cap is ${COMPETITOR_FETCH_POLICY.maxPages}`,
    );
  });

  test('an unreadable robots.txt stops everything — it fails closed', async () => {
    service = serviceWith({
      ...defaultRival,
      [`${RIVAL}/robots.txt`]: { status: 503 },
    });
    const id = await addRival();
    await acknowledgeResearch(service, tenant, id, true);

    const outcome = await analyseCompetitor(service, tenant, id);
    assert.deepEqual(outcome.analysis.pagesRead, []);
    assert.ok(
      outcome.analysis.limitations.some((limitation) => /fails closed/i.test(limitation.detail)),
    );
    const pageRequests = requests.filter((url) => !url.endsWith('/robots.txt'));
    assert.deepEqual(pageRequests, []);
  });

  test('a disallowing robots.txt is obeyed', async () => {
    service = serviceWith({
      ...defaultRival,
      [`${RIVAL}/robots.txt`]: {
        status: 200,
        body: 'User-agent: *\nDisallow: /\n',
        type: 'text/plain',
      },
    });
    const id = await addRival();
    await acknowledgeResearch(service, tenant, id, true);

    const outcome = await analyseCompetitor(service, tenant, id);
    assert.deepEqual(outcome.analysis.pagesRead, []);
    const pageRequests = requests.filter((url) => !url.endsWith('/robots.txt'));
    assert.deepEqual(pageRequests, []);
  });

  test('a competitor URL pointing at a private address is refused at entry', async () => {
    for (const url of ['http://127.0.0.1/', 'http://localhost:3000/', 'http://169.254.169.254/']) {
      await assert.rejects(
        () => addCompetitor(service, tenant, { projectId, name: `Rival ${url}`, websiteUrl: url }),
        (error: unknown) => error instanceof CompetitorInputError,
        `${url} should be refused`,
      );
    }
  });

  test('page content is NOT stored', async () => {
    const id = await addRival();
    await acknowledgeResearch(service, tenant, id, true);
    const outcome = await analyseCompetitor(service, tenant, id);

    const stored = JSON.stringify(outcome.stored);
    assert.ok(!stored.includes('<html'), 'raw markup was stored');
    assert.ok(!stored.includes('We roast to order'), 'page text was stored');
    assert.ok(!('html' in outcome.stored), 'a content column exists on the analysis row');
    assert.equal(COMPETITOR_FETCH_POLICY.storesPageContent, false);
  });
});

describe('verified observations versus inference', () => {
  const page: CompetitorPage = {
    url: `${RIVAL}/`,
    readAt: '2026-09-01T10:00:00.000Z',
    status: 200,
    title: 'Rival Roasters',
    metaDescription: 'Rival Roasters is a speciality coffee roastery serving Nagpur since 2014.',
    h1: ['Rival Roasters'],
    h2: ['Single origin beans', 'Subscriptions'],
    textContent: 'We roast to order in small batches. '.repeat(20),
    internalLinks: [`${RIVAL}/about`],
    externalLinks: ['https://www.instagram.com/rivalroasters'],
    imageCount: 2,
    imagesWithAlt: 1,
    html: '<html><script src="https://connect.facebook.net/en_US/fbevents.js"></script></html>',
    isHttps: true,
  };

  test('every verified finding carries a source URL and a time', () => {
    const analysis = analyzeCompetitor({ competitorName: 'Rival Roasters', pages: [page] });
    const verified = analysis.findings.filter(
      (finding) => finding.evidence.kind === 'verified_public',
    );
    assert.ok(verified.length > 0);
    for (const finding of verified) {
      assert.equal(finding.evidence.kind, 'verified_public');
      if (finding.evidence.kind === 'verified_public') {
        assert.ok(finding.evidence.sourceUrl.length > 0, finding.statement);
        assert.ok(finding.evidence.observedAt.length > 0, finding.statement);
      }
    }
  });

  test('an inference can never be recorded as verified, even if the caller asks', () => {
    const analysis = analyzeCompetitor({ competitorName: 'Rival Roasters', pages: [page] });
    const withGuesses = withInferences(analysis, [
      {
        dimension: 'strengths',
        statement: 'They are positioned for subscription customers rather than walk-ins.',
        basedOn: ['Their home page names subscriptions as a heading.'],
      },
    ]);
    const added = withGuesses.findings.find((finding) =>
      finding.statement.startsWith('They are positioned'),
    );
    assert.ok(added);
    assert.equal(added.evidence.kind, 'ai_inference');
  });

  test('an inference with no basis is dropped', () => {
    const outcome = lintCompetitorFindings([
      {
        dimension: 'weaknesses',
        statement: 'Their content is thin.',
        evidence: { kind: 'ai_inference', basedOn: [] },
        confidence: 'low',
      },
    ]);
    assert.deepEqual(outcome.findings, []);
    assert.match(outcome.dropped[0]!.reason, /what it was drawn from/);
  });

  test('the advertising finding never claims spend, reach or performance', () => {
    const analysis = analyzeCompetitor({ competitorName: 'Rival Roasters', pages: [page] });
    const advertising = analysis.findings.filter((finding) => finding.dimension === 'advertising');
    assert.ok(advertising.length > 0);
    for (const finding of advertising) {
      // The word "spend" DOES appear — in the sentence saying spend cannot be
      // seen. What must never appear is a spend, budget, impression or reach
      // FIGURE, so the pattern looks for a quantity attached to those words
      // rather than for the words themselves. An earlier version of this
      // assertion flagged the honest disclaimer, which would have pushed the
      // fix in exactly the wrong direction.
      assert.ok(
        !/\b(?:spends?|spend of|budget of|impressions of|reach of)\s*(?:about\s*|around\s*)?[₹$€£]?\s*\d/i.test(
          finding.statement,
        ),
        `advertising finding states a figure: ${finding.statement}`,
      );
      assert.match(finding.statement, /cannot be seen from outside|not proof/i);
    }
  });

  test('dimensions with nothing found are NAMED, not left blank', () => {
    const analysis = analyzeCompetitor({ competitorName: 'Rival Roasters', pages: [] });
    assert.equal(analysis.findings.length, 0);
    assert.equal(analysis.notCovered.length, COMPETITOR_DIMENSIONS.length);
    for (const entry of analysis.notCovered) {
      assert.ok(entry.why.length > 30, `${entry.dimension} has no explanation`);
    }
  });

  test('reading nothing is reported as absence, not as a negative finding', () => {
    const analysis = analyzeCompetitor({ competitorName: 'Rival Roasters', pages: [] });
    assert.ok(analysis.limitations.some((limitation) => limitation.code === 'nothing_read'));
    assert.match(
      analysis.limitations.find((limitation) => limitation.code === 'nothing_read')!.detail,
      /absent rather than negative/i,
    );
  });

  test('the counts split verified from inferred', () => {
    const analysis = analyzeCompetitor({ competitorName: 'Rival Roasters', pages: [page] });
    const withGuesses = withInferences(analysis, [
      {
        dimension: 'opportunities',
        statement: 'A walk-in lunch offer would not compete with their subscription focus.',
        basedOn: ['Their headings emphasise subscriptions.'],
      },
    ]);
    assert.equal(withGuesses.counts.verified, analysis.counts.verified);
    assert.equal(withGuesses.counts.inferred, 1);
  });
});

describe('forbidden claims are dropped, not flagged', () => {
  function finding(statement: string, quote?: string): CompetitorFinding {
    return {
      dimension: 'positioning',
      statement,
      evidence: {
        kind: 'verified_public',
        sourceUrl: RIVAL,
        observedAt: '2026-09-01T10:00:00.000Z',
        ...(quote ? { quote } : {}),
      },
      confidence: 'high',
    };
  }

  test('a revenue claim is dropped', () => {
    const outcome = lintCompetitorFindings([finding('Their revenue of ₹4 crore makes them the leader.')]);
    assert.deepEqual(outcome.findings, []);
    assert.equal(outcome.dropped.length, 1);
  });

  test('a traffic figure is dropped', () => {
    const outcome = lintCompetitorFindings([finding('They get 40k monthly visitors.')]);
    assert.deepEqual(outcome.findings, []);
  });

  test('a follower count is dropped', () => {
    const outcome = lintCompetitorFindings([finding('They have 12k followers on Instagram.')]);
    assert.deepEqual(outcome.findings, []);
  });

  test('an allegation of wrongdoing is dropped', () => {
    const outcome = lintCompetitorFindings([finding('They use fake reviews on their product pages.')]);
    assert.deepEqual(outcome.findings, []);
  });

  test('a figure QUOTED from their own page is kept, because that is reporting', () => {
    const outcome = lintCompetitorFindings([
      finding(
        'Their home page says they have 400 customers.',
        'Trusted by 400 customers across Nagpur',
      ),
    ]);
    assert.equal(outcome.findings.length, 1, 'repeating a site\'s own claim with the quote is reporting');
  });

  test('a figure claimed as quoted but ABSENT from the quote is still dropped', () => {
    // Without this, the quote exemption would be a hole wide enough for every
    // fabricated number.
    const outcome = lintCompetitorFindings([
      finding('Their home page says they have 4000 customers.', 'Trusted by 400 customers'),
    ]);
    assert.deepEqual(outcome.findings, []);
  });

  test('every forbidden pattern is exercised by at least one case above', () => {
    // A pattern nobody tests is a pattern that may never have matched anything.
    assert.ok(FORBIDDEN_CLAIMS.length >= 6);
    const samples = [
      'Their revenue of ₹4 crore makes them the leader.',
      'They get 40k monthly visitors.',
      'They have 12k followers on Instagram.',
      'Their conversion rate of 4% beats yours.',
      'They rank #1 for coffee nagpur.',
      'They use fake reviews on their product pages.',
      'They have over 400 customers.',
    ];
    for (const rule of FORBIDDEN_CLAIMS) {
      assert.ok(
        samples.some((sample) => rule.pattern.test(sample)),
        `no sample exercises the "${rule.label}" pattern`,
      );
    }
  });
});

describe('storage and listing', () => {
  test('an analysis references the acknowledgement that authorised it', async () => {
    const id = await addRival();
    await acknowledgeResearch(service, tenant, id, true);
    const outcome = await analyseCompetitor(service, tenant, id);

    const live = await db.competitorAcknowledgements.findLive(tenant.organizationId, id);
    assert.equal(outcome.stored.acknowledgementId, live!.id);

    const under = await db.competitorAnalyses.listForAcknowledgement(
      tenant.organizationId,
      live!.id,
    );
    assert.equal(under.length, 1);
  });

  test('a duplicate competitor name is refused', async () => {
    await addRival();
    await assert.rejects(
      () => addCompetitor(service, tenant, { projectId, name: 'Rival Roasters' }),
      (error: unknown) => error instanceof CompetitorInputError,
    );
  });

  test('listing is scoped, so another tenant sees an empty list rather than an error', async () => {
    await addRival();
    const other = await makeTenant('scoped-competitors@example.com');
    const theirs = await listCompetitors(service, other.tenant, other.projectId);
    assert.deepEqual(theirs, []);
  });

  test('a competitor with no website cannot be analysed, and says why', async () => {
    const competitor = await addCompetitor(service, tenant, { projectId, name: 'Unknown Rival' });
    await acknowledgeResearch(service, tenant, competitor.id, true);
    await assert.rejects(
      () => analyseCompetitor(service, tenant, competitor.id),
      (error: unknown) =>
        error instanceof CompetitorInputError && /no website recorded/i.test(error.message),
    );
  });
});
