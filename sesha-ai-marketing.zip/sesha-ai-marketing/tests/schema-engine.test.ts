import assert from 'node:assert/strict';
import { test, describe } from 'node:test';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  DIMENSION_MEANING,
  NEVER_INVENT_PROPERTIES,
  SUPPORTED_SCHEMA_TYPES,
  VALIDATION_DIMENSIONS,
  VALIDATION_STATUSES,
  VALIDATOR_VERSION,
  buildCorrection,
  compareResults,
  isPlaceholder,
  parseMicrodata,
  parseRdfa,
  rulesFor,
  validateSchema,
  type ValidationDimension,
  type ValidationIssue,
  type ValidationResult,
  type ValidationStatus,
} from '../src/lib/schema-validator';
import {
  checkDate,
  checkDuration,
  checkNumber,
  checkUrl,
} from '../src/lib/schema-validator/datatypes';

/**
 * The Phase 5 validation engine.
 *
 * The single most important group in this file is "the four dimensions are not
 * interchangeable": it is what stops the validator from telling a user that a
 * missing image is the same kind of fact as malformed JSON.
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function validate(document: unknown): ValidationResult {
  const source = typeof document === 'string' ? document : JSON.stringify(document);
  return validateSchema({ source, sourceKind: 'pasted' });
}

function issue(result: ValidationResult, check: string): ValidationIssue | undefined {
  return result.issues.find((candidate) => candidate.check === check);
}

function issuesOf(result: ValidationResult, status: ValidationStatus): ValidationIssue[] {
  return result.issues.filter((candidate) => candidate.status === status);
}

function dimensionsOf(result: ValidationResult): Set<ValidationDimension> {
  return new Set(result.issues.map((candidate) => candidate.dimension));
}

const ORG = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'Acme Coffee',
  url: 'https://acme-coffee.example.com',
  logo: 'https://acme-coffee.example.com/logo.png',
  description: 'A speciality roastery in Nagpur.',
  sameAs: 'https://www.linkedin.com/company/acme',
  contactPoint: { '@type': 'ContactPoint', contactType: 'customer support', telephone: '+91-712-000-0000' },
  address: {
    '@type': 'PostalAddress',
    streetAddress: '12 MG Road',
    addressLocality: 'Nagpur',
    addressCountry: 'IN',
  },
};

/* -------------------------------------------------------------------------- */

describe('the six statuses', () => {
  test('all six exist and only INVALID means the markup is wrong', () => {
    assert.deepEqual(
      [...VALIDATION_STATUSES],
      ['VALID', 'INVALID', 'WARNING', 'RECOMMENDATION', 'NOT_EVALUATED', 'UNSUPPORTED'],
    );
  });

  test('an empty document is NOT_EVALUATED, never VALID', () => {
    // "We found no structured data" and "your structured data is correct" are
    // different sentences and only one of them is true here.
    const result = validateSchema({ source: '<html><body><p>Hello</p></body></html>', sourceKind: 'page_url' });
    assert.equal(result.overall, 'NOT_EVALUATED');
    assert.notEqual(result.overall, 'VALID');
  });

  test('a well-formed document is VALID', () => {
    const result = validate(ORG);
    assert.equal(result.overall, 'VALID', JSON.stringify(issuesOf(result, 'INVALID'), null, 2));
  });

  test('an unknown type is UNSUPPORTED, not INVALID', () => {
    const result = validate({ '@context': 'https://schema.org', '@type': 'Sculpture', name: 'Marble' });
    assert.equal(issuesOf(result, 'INVALID').length, 0);
    const unsupported = issue(result, 'type_unsupported');
    assert.ok(unsupported);
    assert.equal(unsupported.status, 'UNSUPPORTED');
    assert.match(unsupported.explanation, /limit of this tool, not a problem with your markup/);
  });

  test('every run reports what it did NOT evaluate', () => {
    const result = validate(ORG);
    const notEvaluated = issuesOf(result, 'NOT_EVALUATED');
    assert.ok(notEvaluated.length > 0, 'a run that claims to have checked everything is lying');
    assert.ok(notEvaluated.some((candidate) => candidate.check === 'rich_result_not_predicted'));
    assert.ok(notEvaluated.some((candidate) => candidate.check === 'ai_citation_not_measured'));
  });

  test('the validator version is recorded on every result', () => {
    assert.equal(validate(ORG).validatorVersion, VALIDATOR_VERSION);
  });

  test('the timestamp is recorded on every result', () => {
    const result = validateSchema({
      source: JSON.stringify(ORG),
      sourceKind: 'pasted',
      now: () => new Date('2026-09-12T06:00:00Z'),
    });
    assert.equal(result.checkedAt, '2026-09-12T06:00:00.000Z');
  });

  test('the source URL is recorded when one was given', () => {
    const result = validateSchema({
      source: JSON.stringify(ORG),
      sourceKind: 'page_url',
      sourceUrl: 'https://acme-coffee.example.com/about',
    });
    assert.equal(result.sourceUrl, 'https://acme-coffee.example.com/about');
    assert.equal(result.sourceKind, 'page_url');
  });
});

describe('the four dimensions are not interchangeable', () => {
  test('all four exist and each says what it may claim', () => {
    assert.deepEqual(
      [...VALIDATION_DIMENSIONS],
      ['SCHEMA_VALIDITY', 'SEARCH_ELIGIBILITY', 'SEO_GUIDANCE', 'AEO_CLARITY'],
    );
    for (const dimension of VALIDATION_DIMENSIONS) {
      assert.ok(DIMENSION_MEANING[dimension].length > 80, `${dimension} needs a written meaning`);
    }
  });

  test('malformed JSON is a SCHEMA_VALIDITY fact', () => {
    const result = validate('{ "@type": }');
    const parseIssue = result.issues[0]!;
    assert.equal(parseIssue.dimension, 'SCHEMA_VALIDITY');
    assert.equal(parseIssue.status, 'INVALID');
  });

  test('a missing search-documented property is SEARCH_ELIGIBILITY, not SCHEMA_VALIDITY', () => {
    const { image: _omitted, ...article } = {
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: 'How we roast',
      datePublished: '2026-03-14',
      author: { '@type': 'Person', name: 'A. Mehta' },
      image: 'https://example.com/a.png',
    };
    const result = validate(article);
    const found = result.issues.find((candidate) => candidate.property === 'image');
    assert.ok(found);
    assert.equal(found.dimension, 'SEARCH_ELIGIBILITY');
    assert.notEqual(found.status, 'INVALID', 'a missing image does not make the markup invalid');
  });

  test('the search requirements are dated, because they change', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: 'No date here',
    });
    const search = result.issues.filter((candidate) => candidate.dimension === 'SEARCH_ELIGIBILITY');
    assert.ok(search.length > 0);
    assert.ok(
      search.some((candidate) => /as of \d{4}-\d{2}/i.test(candidate.explanation)),
      'a requirement presented as timeless is a quiet lie within a year',
    );
  });

  test('AEO findings are about clarity, never about citation', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'WebPage',
      name: 'About us',
      url: 'https://example.com/about',
    });
    const aeo = result.issues.filter((candidate) => candidate.dimension === 'AEO_CLARITY');
    assert.ok(aeo.length > 0);
    for (const candidate of aeo) {
      assert.ok(
        !/will (?:be )?(?:cited|quoted|ranked)/i.test(candidate.explanation),
        `AEO finding promises an outcome: ${candidate.explanation}`,
      );
    }
  });

  test('one document can produce findings in several dimensions at once', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: 'x'.repeat(140),
      datePublished: 'yesterday',
    });
    const dimensions = dimensionsOf(result);
    assert.ok(dimensions.has('SCHEMA_VALIDITY'));
    assert.ok(dimensions.has('SEO_GUIDANCE'));
    assert.ok(dimensions.size >= 3);
  });

  test('NO finding anywhere promises a ranking, a citation or guaranteed traffic', () => {
    // The engine's own text is scanned, not just what one document happens to
    // produce: a forbidden promise added to a rarely-hit branch would otherwise
    // ship unnoticed.
    const source = readFileSync(path.join(root, 'src', 'lib', 'schema-validator', 'engine.ts'), 'utf8');
    const explanations = [...source.matchAll(/explanation:\s*(?:`([^`]*)`|'((?:[^'\\]|\\.)*)'|"((?:[^"\\]|\\.)*)")/g)]
      .map((match) => match[1] ?? match[2] ?? match[3] ?? '');
    assert.ok(explanations.length > 20, 'the explanation scan found almost nothing, so it proves nothing');

    const forbidden: { readonly label: string; readonly pattern: RegExp }[] = [
      { label: 'a guarantee', pattern: /\bguarantee[ds]?\b/i },
      { label: 'a promised rich result', pattern: /\bwill (?:get|appear|show|receive) a rich result\b/i },
      { label: 'a promised ranking', pattern: /\bwill rank\b/i },
      { label: 'a promised citation', pattern: /\bwill be cited\b/i },
      { label: 'an AI visibility score', pattern: /\bAI visibility\b/i },
    ];
    for (const explanation of explanations) {
      for (const rule of forbidden) {
        assert.ok(
          !rule.pattern.test(explanation),
          `an explanation contains ${rule.label}: ${explanation}`,
        );
      }
    }
  });
});

describe('the twenty-four types', () => {
  const REQUIRED_BY_BRIEF = [
    'Organization', 'LocalBusiness', 'Person', 'WebSite', 'WebPage', 'Article',
    'BlogPosting', 'NewsArticle', 'Product', 'Offer', 'Review', 'AggregateRating',
    'Event', 'Recipe', 'FAQPage', 'HowTo', 'BreadcrumbList', 'VideoObject',
    'ImageObject', 'Service', 'Course', 'JobPosting', 'SoftwareApplication', 'ItemList',
  ];

  test('every type the brief names has rules', () => {
    for (const type of REQUIRED_BY_BRIEF) {
      assert.ok(rulesFor(type), `${type} has no rules`);
    }
    assert.equal(REQUIRED_BY_BRIEF.length, 24);
  });

  test('the supported list is exactly those twenty-four', () => {
    assert.deepEqual([...SUPPORTED_SCHEMA_TYPES].sort(), [...REQUIRED_BY_BRIEF].sort());
  });

  test('a LocalBusiness subtype is checked as a LocalBusiness, not reported unsupported', () => {
    const resolved = rulesFor('CafeOrCoffeeShop');
    assert.ok(resolved);
    assert.equal(resolved.as, 'LocalBusiness');

    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'CafeOrCoffeeShop',
      name: 'Acme Coffee',
    });
    assert.equal(issue(result, 'type_unsupported'), undefined);
    // And it still gets the LocalBusiness requirement.
    assert.ok(result.issues.some((candidate) => candidate.property === 'address'));
  });

  test('every required property in the registry has a data-type rule and an example', () => {
    for (const type of SUPPORTED_SCHEMA_TYPES) {
      const resolved = rulesFor(type)!;
      for (const property of [...resolved.rule.required, ...resolved.rule.recommended]) {
        const result = validate({ '@context': 'https://schema.org', '@type': type });
        const found = result.issues.find((candidate) => candidate.property === property);
        if (found && found.check.endsWith('_missing')) {
          assert.ok(
            found.correctedExample !== undefined || property === 'step' || property === 'mainEntity',
            `${type}.${property} is reported missing with no corrected example`,
          );
        }
      }
    }
  });
});

describe('required, recommended and empty values', () => {
  test('a missing required property is INVALID and names the property', () => {
    const result = validate({ '@context': 'https://schema.org', '@type': 'LocalBusiness', name: 'Acme' });
    const found = issue(result, 'required_property_missing');
    assert.ok(found);
    assert.equal(found.status, 'INVALID');
    assert.equal(found.property, 'address');
    assert.equal(found.dimension, 'SCHEMA_VALIDITY');
  });

  test('a whitespace-only value does not satisfy a required property', () => {
    const result = validate({ '@context': 'https://schema.org', '@type': 'Organization', name: '   ' });
    assert.ok(result.issues.some((candidate) => candidate.property === 'name' && candidate.status === 'INVALID'));
  });

  test('an empty array does not satisfy a required property', () => {
    const result = validate({ '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: [] });
    assert.ok(result.issues.some((candidate) => candidate.property === 'mainEntity'));
  });

  test('a purely optional property is a RECOMMENDATION, never an error', () => {
    const { alternateName: _unused, ...site } = {
      '@context': 'https://schema.org',
      '@type': 'WebSite',
      name: 'Acme',
      url: 'https://acme-coffee.example.com',
      publisher: { '@id': 'https://acme-coffee.example.com/#organization' },
      inLanguage: 'en-IN',
      description: 'Speciality coffee.',
      alternateName: 'x',
    };
    const result = validate(site);
    const found = result.issues.find((candidate) => candidate.property === 'alternateName');
    assert.ok(found);
    assert.equal(found.status, 'RECOMMENDATION');
  });

  test('a reference-only node is not asked for properties it does not carry', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'WebPage',
      name: 'Home',
      url: 'https://acme-coffee.example.com/',
      isPartOf: { '@id': 'https://acme-coffee.example.com/#website' },
    });
    assert.equal(issuesOf(result, 'INVALID').length, 0, JSON.stringify(issuesOf(result, 'INVALID')));
  });

  test('a nested author is NOT held to the publisher requirements', () => {
    // An editorial team as author is correct markup. Demanding a logo and a
    // contact point on it is noise, and noise teaches users to ignore findings.
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: 'How we roast',
      image: 'https://acme-coffee.example.com/a.png',
      datePublished: '2026-03-14',
      author: { '@type': 'Organization', name: 'Editorial Team' },
      publisher: ORG,
    });
    const authorFindings = result.issues.filter((candidate) => candidate.path.startsWith('$.author'));
    assert.deepEqual(authorFindings, [], JSON.stringify(authorFindings, null, 2));
  });
});

describe('data types', () => {
  test('a relative URL is rejected with an explanation a person can act on', () => {
    const result = checkUrl('/logo.png');
    assert.equal(result.ok, false);
    assert.match(result.reason!, /absolute URL/);
  });

  test('http is accepted but flagged, not rejected', () => {
    const result = checkUrl('http://example.com/a.png');
    assert.equal(result.ok, true);
    assert.match(result.reason!, /http rather than https/);
  });

  test('localhost is an advisory, not an error — it is the normal development value', () => {
    // A validator that calls http://localhost:3000 invalid is wrong about the most
    // common development setup there is. What matters is that it must not be what
    // gets published, and the reason says exactly that.
    const result = checkUrl('http://localhost:3000/logo.png');
    assert.equal(result.ok, true);
    assert.match(result.reason!, /must not be what you publish/);
  });

  test('an ambiguous date is refused and the unambiguous form is shown', () => {
    const result = checkDate('05/01/2026');
    assert.equal(result.ok, false);
    assert.match(result.reason!, /ISO 8601/);
    assert.match(result.reason!, /ambiguous/);
  });

  test('a date that does not exist is refused even though it matches the pattern', () => {
    assert.equal(checkDate('2026-02-31').ok, false);
    assert.equal(checkDate('2026-03-14').ok, true);
  });

  test('a price with a currency symbol is refused, and the reason says where the currency goes', () => {
    const result = checkNumber('₹1499');
    assert.equal(result.ok, false);
    assert.match(result.reason!, /priceCurrency/);
  });

  test('a thousands separator is refused with the corrected form', () => {
    const result = checkNumber('1,499.00');
    assert.equal(result.ok, false);
    assert.match(result.reason!, /1499\.00/);
  });

  test('a number written as a string is accepted, because schema.org permits it', () => {
    assert.equal(checkNumber('4.6').ok, true);
  });

  test('a human-readable duration is refused in favour of ISO 8601', () => {
    assert.equal(checkDuration('15 minutes').ok, false);
    assert.equal(checkDuration('PT15M').ok, true);
  });

  test('a bad date in a document is INVALID and names ISO 8601', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: 'x',
      datePublished: '14/03/2026',
    });
    const found = issue(result, 'data_type_invalid');
    assert.ok(found);
    assert.equal(found.status, 'INVALID');
    assert.match(found.explanation, /ISO 8601/);
    assert.equal(found.found, '14/03/2026');
  });

  test('an enum written without the schema.org prefix is accepted with a note', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Offer',
      price: '499.00',
      priceCurrency: 'INR',
      availability: 'InStock',
    });
    const found = issue(result, 'enum_spelling');
    assert.ok(found);
    assert.equal(found.status, 'RECOMMENDATION');
  });

  test('an invalid enum value is INVALID and lists what is accepted', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Offer',
      price: '499.00',
      priceCurrency: 'INR',
      availability: 'Available',
    });
    const found = result.issues.find(
      (candidate) => candidate.property === 'availability' && candidate.status === 'INVALID',
    );
    assert.ok(found);
    assert.match(found.explanation, /InStock/);
  });

  test('a currency symbol in priceCurrency is refused', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Offer',
      price: '499.00',
      priceCurrency: '₹',
    });
    assert.ok(
      result.issues.some(
        (candidate) => candidate.property === 'priceCurrency' && candidate.status === 'INVALID',
      ),
    );
  });
});

describe('images and logos', () => {
  test('an ImageObject with url rather than contentUrl is valid', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'ImageObject',
      url: 'https://acme-coffee.example.com/a.png',
    });
    assert.equal(issuesOf(result, 'INVALID').length, 0, JSON.stringify(issuesOf(result, 'INVALID')));
  });

  test('an image node with no URL at all is INVALID', () => {
    const result = validate({ '@context': 'https://schema.org', '@type': 'ImageObject', caption: 'Our shop' });
    const found = issue(result, 'one_of_missing');
    assert.ok(found);
    assert.equal(found.status, 'INVALID');
  });

  test('a logo ImageObject with no url is INVALID and says why', () => {
    const result = validate({
      ...ORG,
      logo: { '@type': 'ImageObject', caption: 'Logo' },
    });
    const found = issue(result, 'logo_no_url');
    assert.ok(found);
    assert.match(found.explanation, /no image to fetch/);
  });

  test('image dimensions are reported as NOT_EVALUATED rather than passed over', () => {
    const result = validate(ORG);
    const found = issue(result, 'image_not_fetched');
    assert.ok(found);
    assert.equal(found.status, 'NOT_EVALUATED');
  });
});

describe('@context, @type and @id', () => {
  test('a missing @context is INVALID', () => {
    const result = validate({ '@type': 'Organization', name: 'Acme' });
    const found = issue(result, 'context_missing');
    assert.ok(found);
    assert.equal(found.status, 'INVALID');
  });

  test('a non-schema.org context is a WARNING, because the validator only knows schema.org', () => {
    const result = validate({ '@context': 'https://example.org', '@type': 'Organization', name: 'Acme' });
    const found = issue(result, 'context_not_schema_org');
    assert.ok(found);
    assert.equal(found.status, 'WARNING');
  });

  test('http://schema.org is a RECOMMENDATION, not a warning', () => {
    const result = validate({ '@context': 'http://schema.org', '@type': 'Organization', name: 'Acme' });
    assert.equal(issue(result, 'context_variant')?.status, 'RECOMMENDATION');
    assert.equal(issue(result, 'context_not_schema_org'), undefined);
  });

  test('a remote @context is never fetched', () => {
    // The document is a stranger's. Dereferencing a URL inside it would rebuild
    // the crawler's threat model through a side door.
    const source = readFileSync(path.join(root, 'src', 'lib', 'schema-validator', 'parse.ts'), 'utf8');
    assert.ok(!/fetch\(/.test(source), 'the parser must not perform network requests');
    const engine = readFileSync(path.join(root, 'src', 'lib', 'schema-validator', 'engine.ts'), 'utf8');
    assert.ok(!/fetch\(/.test(engine), 'the engine must not perform network requests');
  });

  test('an inline @context object is reported as a limitation, not as valid', () => {
    const result = validate({
      '@context': { '@vocab': 'https://schema.org/' },
      '@type': 'Organization',
      name: 'Acme',
    });
    assert.ok(result.limitations.some((limitation) => limitation.code === 'inline_context'));
  });

  test('a missing @type is INVALID', () => {
    const result = validate({ '@context': 'https://schema.org', name: 'Acme' });
    const found = issue(result, 'type_missing');
    assert.ok(found);
    assert.equal(found.status, 'INVALID');
  });

  test('a duplicate @id is INVALID', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@graph': [
        { '@type': 'Organization', '@id': 'https://e.com/#org', name: 'A' },
        { '@type': 'Organization', '@id': 'https://e.com/#org', name: 'B' },
      ],
    });
    const found = issue(result, 'duplicate_id');
    assert.ok(found);
    assert.equal(found.status, 'INVALID');
  });

  test('one @id used for two different types is INVALID', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@graph': [
        { '@type': 'Organization', '@id': 'https://e.com/#thing', name: 'A' },
        { '@type': 'Product', '@id': 'https://e.com/#thing', name: 'A' },
      ],
    });
    assert.ok(issue(result, 'id_type_conflict'));
  });

  test('a non-absolute @id is a WARNING with the corrected form', () => {
    const result = validate({ ...ORG, '@id': 'org-1' });
    const found = issue(result, 'id_not_absolute');
    assert.ok(found);
    assert.match(found.correctedExample!, /https:\/\//);
  });
});

describe('nesting and duplicate entities', () => {
  test('every node in a @graph is walked', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@graph': [
        { '@type': 'Organization', name: 'Acme', url: 'https://e.com' },
        { '@type': 'WebSite', name: 'Acme', url: 'https://e.com' },
      ],
    });
    assert.ok(result.typesFound.includes('Organization'));
    assert.ok(result.typesFound.includes('WebSite'));
    assert.ok(result.entities.length >= 2);
  });

  test('a document nested past the depth limit is refused rather than walked', () => {
    let nested: Record<string, unknown> = { '@type': 'Person', name: 'Deep' };
    for (let index = 0; index < 20; index += 1) nested = { '@type': 'Person', name: 'x', author: nested };
    const result = validate({ '@context': 'https://schema.org', ...nested });
    assert.ok(result.issues.some((candidate) => candidate.check === 'parse_too_deep'));
  });

  test('the same entity in two syntaxes is a WARNING that names the risk', () => {
    const html = `
      <script type="application/ld+json">
        {"@context":"https://schema.org","@type":"Product","name":"Single Origin","offers":{"@type":"Offer","price":"499.00","priceCurrency":"INR"}}
      </script>
      <div itemscope itemtype="https://schema.org/Product">
        <span itemprop="name">Single Origin</span>
      </div>`;
    const result = validateSchema({ source: html, sourceKind: 'page_url' });
    const found = issue(result, 'duplicate_entity_across_syntaxes');
    assert.ok(found);
    assert.equal(found.status, 'WARNING');
    assert.match(found.explanation, /Two copies can disagree/);
  });

  test('two copies of an entity that DISAGREE are flagged separately', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@graph': [
        { '@type': 'Organization', name: 'Acme', telephone: '+91-712-000-0000' },
        { '@type': 'Organization', name: 'Acme', telephone: '+91-712-999-9999' },
      ],
    });
    const found = issue(result, 'duplicate_entity_conflict');
    assert.ok(found);
    assert.equal(found.property, 'telephone');
  });
});

describe('breadcrumb hierarchy', () => {
  const crumbs = (positions: readonly number[]) => ({
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: positions.map((position) => ({
      '@type': 'ListItem',
      position,
      name: `Item ${position}`,
      item: `https://e.com/${position}`,
    })),
  });

  test('a sequential trail is valid', () => {
    assert.equal(issuesOf(validate(crumbs([1, 2, 3])), 'INVALID').length, 0);
  });

  test('a gap in the positions is INVALID', () => {
    assert.ok(issue(validate(crumbs([1, 3])), 'breadcrumb_position_sequence'));
  });

  test('starting at 0 is INVALID', () => {
    assert.ok(issue(validate(crumbs([0, 1])), 'breadcrumb_position_start'));
  });

  test('a ListItem with no name is INVALID', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [{ '@type': 'ListItem', position: 1, item: 'https://e.com/1' }],
    });
    assert.ok(issue(result, 'breadcrumb_name_missing'));
  });

  test('only the LAST item may omit its item URL', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home' },
        { '@type': 'ListItem', position: 2, name: 'Blog', item: 'https://e.com/blog' },
      ],
    });
    assert.ok(issue(result, 'breadcrumb_item_missing'), 'a non-final item needs an item URL');

    const trailing = validate({
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://e.com/' },
        { '@type': 'ListItem', position: 2, name: 'This page' },
      ],
    });
    assert.equal(issue(trailing, 'breadcrumb_item_missing'), undefined);
  });
});

describe('consistency rules', () => {
  test('an offer with no price is INVALID', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: 'Beans',
      offers: { '@type': 'Offer' },
    });
    assert.ok(issue(result, 'offer_no_price'));
  });

  test('a price with no currency is INVALID', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Offer',
      price: '499.00',
    });
    assert.ok(issue(result, 'offer_no_currency'));
  });

  test('offers in two currencies on one product is a WARNING', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: 'Beans',
      offers: [
        { '@type': 'Offer', price: '499.00', priceCurrency: 'INR' },
        { '@type': 'Offer', price: '9.00', priceCurrency: 'USD' },
      ],
    });
    assert.ok(issue(result, 'product_currency_conflict'));
  });

  test('a rating above its scale is INVALID', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'AggregateRating',
      ratingValue: 9.5,
      reviewCount: 10,
    });
    assert.ok(issue(result, 'rating_above_best'));
  });

  test('an inverted scale is INVALID', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'AggregateRating',
      ratingValue: 3,
      bestRating: 1,
      worstRating: 5,
      reviewCount: 4,
    });
    assert.ok(issue(result, 'rating_scale_inverted'));
  });

  test('an aggregate rating with no count is flagged', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'AggregateRating',
      ratingValue: 4.5,
    });
    assert.ok(issue(result, 'one_of_missing'));
  });

  test('an aggregate rating of zero ratings is INVALID', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'AggregateRating',
      ratingValue: 4.5,
      reviewCount: 0,
    });
    assert.ok(issue(result, 'rating_count_zero'));
  });

  test('a review with no named author is INVALID', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Review',
      author: { '@type': 'Person' },
      reviewRating: { '@type': 'Rating', ratingValue: 5 },
      itemReviewed: { '@type': 'Product', name: 'Beans' },
    });
    assert.ok(issue(result, 'review_author_unnamed'));
  });

  test('ANY node publishing a rating gets the honesty warning, not only Product', () => {
    // The earlier version of this check only fired for Product, which is the node
    // a fabricated rating is least often attached to.
    for (const type of ['Product', 'Article', 'Service', 'LocalBusiness']) {
      const result = validate({
        '@context': 'https://schema.org',
        '@type': type,
        name: 'Thing',
        headline: 'Thing',
        address: { '@type': 'PostalAddress', addressLocality: 'Nagpur', addressCountry: 'IN' },
        aggregateRating: { '@type': 'AggregateRating', ratingValue: 4.9, reviewCount: 812 },
      });
      const found = issue(result, 'rating_must_be_genuine');
      assert.ok(found, `${type} did not get the honesty warning`);
      assert.match(found.explanation, /genuine reviews/);
      assert.match(found.explanation, /never generate a rating/);
    }
  });

  test('two different organization names on one page is a WARNING', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@graph': [
        { '@type': 'Organization', '@id': 'https://e.com/#a', name: 'Acme Coffee' },
        { '@type': 'Organization', '@id': 'https://e.com/#b', name: 'Acme Holdings' },
      ],
    });
    const found = issue(result, 'organization_name_conflict');
    assert.ok(found);
    assert.match(found.explanation, /parentOrganization/);
  });

  test('an event that ends before it starts is INVALID', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Event',
      name: 'Cupping session',
      startDate: '2026-07-01T19:00:00+05:30',
      endDate: '2026-07-01T17:00:00+05:30',
      location: { '@type': 'Place', name: 'Roastery', address: { '@type': 'PostalAddress', addressLocality: 'Nagpur', addressCountry: 'IN' } },
    });
    assert.ok(issue(result, 'event_dates_out_of_order'));
  });

  test('an itemList whose count disagrees with its contents is a WARNING', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'ItemList',
      name: 'Top beans',
      numberOfItems: 5,
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'One' },
        { '@type': 'ListItem', position: 2, name: 'Two' },
      ],
    });
    assert.ok(issue(result, 'itemlist_count_mismatch'));
  });

  test('an expired offer validity is flagged as a search-eligibility warning', () => {
    const result = validateSchema({
      source: JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'Offer',
        price: '499.00',
        priceCurrency: 'INR',
        priceValidUntil: '2020-01-01',
      }),
      sourceKind: 'pasted',
      now: () => new Date('2026-09-12T00:00:00Z'),
    });
    const found = issue(result, 'validity_expired');
    assert.ok(found);
    assert.equal(found.dimension, 'SEARCH_ELIGIBILITY');
  });

  test('dateModified before datePublished is INVALID', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: 'x',
      datePublished: '2026-05-01',
      dateModified: '2026-01-01',
    });
    assert.ok(issue(result, 'dates_out_of_order'));
  });
});

describe('deprecated properties', () => {
  test('a superseded property is a WARNING naming its replacement', () => {
    const result = validate({
      '@context': 'https://schema.org',
      '@type': 'Recipe',
      name: 'Cold brew',
      ingredients: '200 g coffee',
    });
    const found = issue(result, 'deprecated_property');
    assert.ok(found);
    assert.equal(found.status, 'WARNING');
    assert.match(found.explanation, /recipeIngredient/);
  });

  test('the deprecation list only claims what it is confident about', () => {
    const source = readFileSync(path.join(root, 'src', 'lib', 'schema-validator', 'registry.ts'), 'utf8');
    assert.match(source, /DELIBERATELY NOT EXHAUSTIVE/);
  });
});

describe('canonical URL', () => {
  test('a url that disagrees with the canonical is a WARNING', () => {
    const result = validateSchema({
      source: JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'WebPage',
        name: 'About',
        url: 'https://acme-coffee.example.com/about?utm_source=x',
      }),
      sourceKind: 'page_url',
      canonicalUrl: 'https://acme-coffee.example.com/about',
    });
    const found = issue(result, 'canonical_mismatch');
    assert.ok(found);
    assert.equal(found.dimension, 'SEARCH_ELIGIBILITY');
  });

  test('with no canonical supplied the check is NOT_EVALUATED, not silently skipped', () => {
    const result = validate({ '@context': 'https://schema.org', '@type': 'WebPage', name: 'About' });
    assert.equal(issue(result, 'canonical_unknown')?.status, 'NOT_EVALUATED');
  });
});

describe('microdata', () => {
  test('reads itemscope, itemtype and itemprop', () => {
    const outcome = parseMicrodata(`
      <div itemscope itemtype="https://schema.org/LocalBusiness">
        <h1 itemprop="name">Acme Coffee</h1>
        <meta itemprop="telephone" content="+91-712-000-0000">
        <a itemprop="url" href="https://acme-coffee.example.com">site</a>
      </div>`);
    assert.equal(outcome.nodes.length, 1);
    const node = outcome.nodes[0]!;
    assert.deepEqual([...node.types], ['LocalBusiness']);
    assert.equal(node.properties['name'], 'Acme Coffee');
    assert.equal(node.properties['telephone'], '+91-712-000-0000');
    assert.equal(node.properties['url'], 'https://acme-coffee.example.com');
    assert.equal(node.syntax, 'microdata');
  });

  test('a meta element uses content, not its text', () => {
    const outcome = parseMicrodata(
      '<div itemscope itemtype="https://schema.org/Product"><meta itemprop="name" content="Beans">ignored</div>',
    );
    assert.equal(outcome.nodes[0]!.properties['name'], 'Beans');
  });

  test('nested itemscope becomes its own node', () => {
    const outcome = parseMicrodata(`
      <div itemscope itemtype="https://schema.org/Product">
        <span itemprop="name">Beans</span>
        <div itemprop="offers" itemscope itemtype="https://schema.org/Offer">
          <meta itemprop="price" content="499.00">
          <meta itemprop="priceCurrency" content="INR">
        </div>
      </div>`);
    assert.equal(outcome.nodes.length, 2);
    const offer = outcome.nodes.find((node) => node.types.includes('Offer'));
    assert.ok(offer);
    assert.equal(offer.parent, outcome.nodes[0]!.path);
    assert.equal(offer.properties['price'], '499.00');
  });

  test('microdata is validated by the same rules as JSON-LD', () => {
    const result = validateSchema({
      source: '<div itemscope itemtype="https://schema.org/LocalBusiness"><span itemprop="name">Acme</span></div>',
      sourceKind: 'page_url',
    });
    const found = issue(result, 'required_property_missing');
    assert.ok(found, 'a missing address must be reported in microdata too');
    assert.equal(found.property, 'address');
  });

  test('what the reader could not follow is reported as a limitation', () => {
    const outcome = parseMicrodata(
      '<div itemscope itemtype="https://schema.org/Product" itemref="extra"><span itemprop="name">X</span></div>',
    );
    assert.ok(outcome.limitations.some((limitation) => limitation.code === 'microdata_itemref'));
    assert.ok(outcome.limitations.some((limitation) => limitation.code === 'microdata_flat_read'));
  });

  test('commented-out markup is not read as markup', () => {
    const outcome = parseMicrodata(
      '<!-- <div itemscope itemtype="https://schema.org/Product"><span itemprop="name">Ghost</span></div> -->',
    );
    assert.equal(outcome.nodes.length, 0);
  });
});

describe('rdfa', () => {
  test('reads vocab, typeof and property', () => {
    const outcome = parseRdfa(`
      <div vocab="https://schema.org/" typeof="Organization">
        <span property="name">Acme Coffee</span>
        <a property="url" href="https://acme-coffee.example.com">site</a>
      </div>`);
    assert.equal(outcome.nodes.length, 1);
    assert.deepEqual([...outcome.nodes[0]!.types], ['Organization']);
    assert.equal(outcome.nodes[0]!.properties['name'], 'Acme Coffee');
    assert.equal(outcome.nodes[0]!.syntax, 'rdfa');
  });

  test('a prefixed type resolves to its local name', () => {
    const outcome = parseRdfa('<div typeof="schema:Person"><span property="schema:name">A. Mehta</span></div>');
    assert.deepEqual([...outcome.nodes[0]!.types], ['Person']);
    assert.equal(outcome.nodes[0]!.properties['name'], 'A. Mehta');
  });

  test('the RDFa reader says what it did not resolve', () => {
    const outcome = parseRdfa('<div prefix="ex: https://example.com/" typeof="Organization"><span property="name">A</span></div>');
    assert.ok(outcome.limitations.some((limitation) => limitation.code === 'rdfa_lite_only'));
    assert.ok(outcome.limitations.some((limitation) => limitation.code === 'rdfa_prefix'));
  });

  test('all three syntaxes on one page are all found', () => {
    const html = `
      <script type="application/ld+json">{"@context":"https://schema.org","@type":"WebSite","name":"A","url":"https://e.com"}</script>
      <div itemscope itemtype="https://schema.org/Person"><span itemprop="name">B</span></div>
      <div vocab="https://schema.org/" typeof="Course"><span property="name">C</span><span property="description">D</span></div>`;
    const result = validateSchema({ source: html, sourceKind: 'page_url' });
    assert.deepEqual([...result.syntaxes].sort(), ['json-ld', 'microdata', 'rdfa']);
  });
});

describe('corrected JSON-LD', () => {
  test('adds a missing @context', () => {
    const source = JSON.stringify({ '@type': 'Organization', name: 'Acme' });
    const correction = buildCorrection(source, validate(JSON.parse(source)));
    assert.ok(correction.available);
    assert.match(correction.after, /"@context": "https:\/\/schema\.org"/);
    assert.ok(correction.changes.some((change) => /@context/.test(change)));
  });

  test('a missing property becomes a VISIBLY fake placeholder, never a plausible value', () => {
    const source = JSON.stringify({ '@context': 'https://schema.org', '@type': 'LocalBusiness', name: 'Acme' });
    const correction = buildCorrection(source, validate(JSON.parse(source)));
    const after = JSON.parse(correction.after) as Record<string, unknown>;
    assert.ok(isPlaceholder(after['address']), 'address should be an obvious placeholder');
    assert.match(String(after['address']), /^<add /);
    assert.ok(correction.placeholders.includes('address'));
  });

  test('it NEVER fills in a rating, a review, a price or a credential', () => {
    const source = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: 'Beans',
    });
    const correction = buildCorrection(source, validate(JSON.parse(source)));
    const after = correction.after;
    for (const property of NEVER_INVENT_PROPERTIES) {
      assert.ok(!new RegExp(`"${property}"`).test(after), `the correction invented ${property}`);
    }
  });

  test('a refusal is reported rather than silently omitted', () => {
    const source = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: 'Beans',
      aggregateRating: { '@type': 'AggregateRating', ratingValue: 4.9, reviewCount: 10 },
    });
    const result = validate(JSON.parse(source));
    const correction = buildCorrection(source, result);
    // The Product one-of finding names offers/review/aggregateRating, all of which
    // are on the never-invent list.
    assert.ok(
      correction.refusals.length > 0 || !/"(?:price|ratingValue)"\s*:\s*"<add/.test(correction.after),
    );
  });

  test('a relative URL is made absolute when the page URL is known', () => {
    const source = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: 'Acme',
      url: '/about',
    });
    const correction = buildCorrection(source, validate(JSON.parse(source)), {
      pageUrl: 'https://acme-coffee.example.com/about',
    });
    assert.match(correction.after, /"url": "https:\/\/acme-coffee\.example\.com\/about"/);
  });

  test('a deprecated property is renamed', () => {
    const source = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Recipe',
      name: 'Cold brew',
      ingredients: '200 g coffee',
    });
    const correction = buildCorrection(source, validate(JSON.parse(source)));
    const after = JSON.parse(correction.after) as Record<string, unknown>;
    assert.equal(after['recipeIngredient'], '200 g coffee');
    assert.equal(after['ingredients'], undefined);
  });

  test('microdata is NOT rewritten, and the refusal says why', () => {
    const html = '<div itemscope itemtype="https://schema.org/Product"><span itemprop="name">Beans</span></div>';
    const result = validateSchema({ source: html, sourceKind: 'page_url' });
    const correction = buildCorrection(html, result);
    assert.equal(correction.available, false);
    assert.match(correction.unavailableReason!, /rewriting your HTML automatically is not something this tool will do/);
  });

  test('before and after are both returned so the change is reviewable', () => {
    const source = JSON.stringify({ '@type': 'Organization', name: 'Acme' });
    const correction = buildCorrection(source, validate(JSON.parse(source)));
    assert.notEqual(correction.before, correction.after);
    assert.ok(correction.before.includes('Acme'));
  });

  test('unparseable JSON gets no correction, with a reason', () => {
    const correction = buildCorrection('{ bad', validate('{ bad'));
    assert.equal(correction.available, false);
    assert.match(correction.unavailableReason!, /Fix the syntax error first/);
  });
});

describe('history and comparison over time', () => {
  const withError = {
    '@context': 'https://schema.org',
    '@type': 'LocalBusiness',
    name: 'Acme Coffee',
  };
  const fixed = {
    ...withError,
    address: { '@type': 'PostalAddress', addressLocality: 'Nagpur', addressCountry: 'IN' },
  };

  test('a resolved finding is reported as resolved', () => {
    const comparison = compareResults(validate(withError), validate(fixed));
    assert.ok(comparison.fixed.some((candidate) => candidate.property === 'address'));
    assert.match(comparison.summary, /resolved/);
  });

  test('a new finding is reported as new', () => {
    const comparison = compareResults(validate(fixed), validate(withError));
    assert.ok(comparison.introduced.some((candidate) => candidate.property === 'address'));
    assert.match(comparison.summary, /new/);
  });

  test('no change says so rather than showing an empty diff', () => {
    const comparison = compareResults(validate(fixed), validate(fixed));
    assert.equal(comparison.fixed.length, 0);
    assert.equal(comparison.introduced.length, 0);
    assert.match(comparison.summary, /no change/);
  });

  test('a validator version change is called out, because it confounds the comparison', () => {
    const older = { ...validate(fixed), validatorVersion: '4.0.0' } as ValidationResult;
    const comparison = compareResults(older, validate(fixed));
    assert.equal(comparison.versionChanged, true);
    assert.match(comparison.summary, /the validator itself changed/);
  });
});
