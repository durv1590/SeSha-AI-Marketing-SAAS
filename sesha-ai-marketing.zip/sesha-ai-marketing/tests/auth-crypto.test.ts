import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  CURRENT_PARAMS,
  PASSWORD_MIN_LENGTH,
  checkPasswordPolicy,
  dummyVerify,
  parseHash,
  passwordHasher,
} from '../src/lib/auth/password';
import {
  SESSION_ABSOLUTE_LIFETIME,
  SESSION_IDLE_TIMEOUT,
  TOKEN_LIFETIMES,
  generateNumericCode,
  generateToken,
  hashToken,
  isExpired,
  tokensMatch,
} from '../src/lib/auth/tokens';
import {
  CSRF_HEADER,
  isSafeMethod,
  issueCsrfToken,
  verifyCsrf,
  verifyOrigin,
} from '../src/lib/auth/csrf';

/* -------------------------------------------------------------------------- */
/* Password hashing                                                           */
/* -------------------------------------------------------------------------- */

describe('password hashing', () => {
  test('hashes and verifies a correct password', async () => {
    const hash = await passwordHasher.hash('correct horse battery staple 42');
    assert.equal(await passwordHasher.verify('correct horse battery staple 42', hash), true);
  });

  test('rejects an incorrect password', async () => {
    const hash = await passwordHasher.hash('correct horse battery staple 42');
    assert.equal(await passwordHasher.verify('correct horse battery staple 43', hash), false);
  });

  test('never stores the plaintext password', async () => {
    const password = 'a-very-distinctive-passphrase-9182';
    const hash = await passwordHasher.hash(password);
    assert.ok(!hash.includes(password), 'plaintext leaked into the stored hash');
  });

  test('produces a different hash each time (unique salt)', async () => {
    const a = await passwordHasher.hash('same password every time');
    const b = await passwordHasher.hash('same password every time');
    assert.notEqual(a, b, 'identical hashes mean the salt is not random');
    assert.equal(await passwordHasher.verify('same password every time', a), true);
    assert.equal(await passwordHasher.verify('same password every time', b), true);
  });

  test('stored format is self-describing and parseable', async () => {
    const hash = await passwordHasher.hash('another passphrase here');
    const parsed = parseHash(hash);
    assert.ok(parsed);
    assert.equal(parsed.params.N, CURRENT_PARAMS.N);
    assert.equal(parsed.params.r, CURRENT_PARAMS.r);
    assert.equal(parsed.params.keylen, CURRENT_PARAMS.keylen);
    assert.equal(parsed.hash.length, CURRENT_PARAMS.keylen);
    assert.ok(parsed.salt.length >= 16);
  });

  test('uses memory-hard parameters at or above the OWASP floor', () => {
    // OWASP: scrypt with N >= 2^15 at r=8, p=1.
    assert.ok(CURRENT_PARAMS.N >= 2 ** 15, `N is ${CURRENT_PARAMS.N}`);
    assert.ok(CURRENT_PARAMS.r >= 8);
    assert.ok(CURRENT_PARAMS.keylen >= 32);
  });

  test('malformed stored values return false rather than throwing', async () => {
    for (const bad of ['', 'nonsense', 'scrypt$1$2$3', 'bcrypt$1$2$3$4$5$6', '$$$$$$']) {
      assert.equal(await passwordHasher.verify('anything', bad), false, `threw or passed on: ${bad}`);
    }
  });

  test('a hostile stored value cannot force a huge allocation', () => {
    assert.equal(parseHash('scrypt$1099511627776$8$1$64$c2FsdA$aGFzaA'), null);
    assert.equal(parseHash('scrypt$65536$9999$1$64$c2FsdA$aGFzaA'), null);
    assert.equal(parseHash('scrypt$65536$8$1$99999$c2FsdA$aGFzaA'), null);
  });

  test('needsRehash flags weaker parameters and accepts current ones', async () => {
    const current = await passwordHasher.hash('current parameters password');
    assert.equal(passwordHasher.needsRehash(current), false);

    const weak = `scrypt$16384$8$1$64$${Buffer.from('salt').toString('base64url')}$${Buffer.from('x'.repeat(64)).toString('base64url')}`;
    assert.equal(passwordHasher.needsRehash(weak), true);
    assert.equal(passwordHasher.needsRehash('garbage'), true);
  });

  test('unicode passwords normalise consistently', async () => {
    // Same string, different Unicode normal forms.
    const composed = 'café-passphrase-2026';
    const decomposed = 'café-passphrase-2026';
    const hash = await passwordHasher.hash(composed);
    assert.equal(await passwordHasher.verify(decomposed, hash), true);
  });

  test('dummyVerify returns false and does real work (timing defence)', async () => {
    const started = process.hrtime.bigint();
    const result = await dummyVerify('some password');
    const elapsedMs = Number(process.hrtime.bigint() - started) / 1e6;
    assert.equal(result, false);
    assert.ok(elapsedMs > 5, `dummy verify took only ${elapsedMs.toFixed(1)}ms — too fast to mask timing`);
  });
});

describe('password policy', () => {
  test('requires a reasonable minimum length', () => {
    assert.equal(checkPasswordPolicy('short').ok, false);
    assert.equal(checkPasswordPolicy('x'.repeat(PASSWORD_MIN_LENGTH - 1)).ok, false);
  });

  test('accepts a long passphrase with no symbols', () => {
    // NIST SP 800-63B: length beats composition rules.
    assert.equal(checkPasswordPolicy('several ordinary words strung together').ok, true);
  });

  test('rejects known-common passwords', () => {
    assert.equal(checkPasswordPolicy('passwordpassword').ok, false);
    assert.equal(checkPasswordPolicy('correcthorsebatterystaple').ok, false);
  });

  test('rejects a single repeated character', () => {
    assert.equal(checkPasswordPolicy('aaaaaaaaaaaaaaaa').ok, false);
  });

  test('rejects a password containing the user email or name', () => {
    const result = checkPasswordPolicy('durvesh-secret-passphrase', ['durvesh@example.com', 'Durvesh']);
    assert.equal(result.ok, false);
    assert.ok(result.problems.some((p) => /name or email/.test(p)));
  });

  test('rejects an absurdly long password (CPU bound)', () => {
    assert.equal(checkPasswordPolicy('x'.repeat(5000)).ok, false);
  });
});

/* -------------------------------------------------------------------------- */
/* Tokens                                                                     */
/* -------------------------------------------------------------------------- */

describe('tokens', () => {
  test('issues high-entropy tokens', () => {
    const { token } = generateToken(TOKEN_LIFETIMES.session);
    // 32 bytes base64url ~= 43 characters.
    assert.ok(token.length >= 42, `token is only ${token.length} chars`);
    assert.match(token, /^[A-Za-z0-9_-]+$/);
  });

  test('tokens are unique across many draws', () => {
    const seen = new Set<string>();
    for (let i = 0; i < 1000; i += 1) {
      seen.add(generateToken(TOKEN_LIFETIMES.session).token);
    }
    assert.equal(seen.size, 1000);
  });

  test('the stored hash is not the token', () => {
    const issued = generateToken(TOKEN_LIFETIMES.session);
    assert.notEqual(issued.hash, issued.token);
    assert.equal(issued.hash, hashToken(issued.token));
    assert.equal(issued.hash.length, 64, 'expected hex SHA-256');
  });

  test('hashing is deterministic', () => {
    assert.equal(hashToken('abc'), hashToken('abc'));
    assert.notEqual(hashToken('abc'), hashToken('abd'));
  });

  test('tokensMatch is exact and total', () => {
    assert.equal(tokensMatch('abc', 'abc'), true);
    assert.equal(tokensMatch('abc', 'abd'), false);
    assert.equal(tokensMatch('abc', 'abcd'), false);
    assert.equal(tokensMatch('', ''), true);
    // @ts-expect-error — exercising the runtime guard
    assert.equal(tokensMatch(null, 'abc'), false);
  });

  test('password reset tokens are short-lived', () => {
    assert.ok(TOKEN_LIFETIMES.passwordReset <= 60 * 60 * 1000, 'reset window is too long');
  });

  test('session idle timeout is shorter than the absolute lifetime', () => {
    assert.ok(SESSION_IDLE_TIMEOUT < SESSION_ABSOLUTE_LIFETIME);
  });

  test('expiry handles dates, strings and rubbish', () => {
    const future = new Date(Date.now() + 10_000);
    const past = new Date(Date.now() - 10_000);
    assert.equal(isExpired(future), false);
    assert.equal(isExpired(past), true);
    assert.equal(isExpired(future.toISOString()), false);
    assert.equal(isExpired(null), true);
    assert.equal(isExpired(undefined), true);
    assert.equal(isExpired('not a date'), true);
  });

  test('numeric codes are the right length and unbiased in shape', () => {
    const counts = new Map<string, number>();
    for (let i = 0; i < 2000; i += 1) {
      const code = generateNumericCode(6);
      assert.match(code, /^\d{6}$/);
      const firstDigit = code[0]!;
      counts.set(firstDigit, (counts.get(firstDigit) ?? 0) + 1);
    }
    // With rejection sampling every leading digit should appear.
    assert.equal(counts.size, 10, 'leading digit distribution looks biased');
  });
});

/* -------------------------------------------------------------------------- */
/* CSRF                                                                       */
/* -------------------------------------------------------------------------- */

describe('CSRF', () => {
  const secret = 'a-test-secret-at-least-32-bytes-long!!';
  const sessionId = 'session-123';

  test('a freshly issued token verifies', () => {
    const token = issueCsrfToken(sessionId, secret);
    assert.deepEqual(verifyCsrf(token, token, sessionId, secret), { ok: true });
  });

  test('a missing cookie or header is rejected', () => {
    const token = issueCsrfToken(sessionId, secret);
    assert.equal(verifyCsrf(null, token, sessionId, secret).ok, false);
    assert.equal(verifyCsrf(token, null, sessionId, secret).ok, false);
    assert.equal(verifyCsrf('', '', sessionId, secret).ok, false);
  });

  test('mismatched halves are rejected', () => {
    const a = issueCsrfToken(sessionId, secret);
    const b = issueCsrfToken(sessionId, secret);
    const result = verifyCsrf(a, b, sessionId, secret);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.reason, 'mismatch');
  });

  test('a token from another session is rejected (session binding)', () => {
    const token = issueCsrfToken('other-session', secret);
    const result = verifyCsrf(token, token, sessionId, secret);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.reason, 'bad-signature');
  });

  test('an attacker-forged token without the secret is rejected', () => {
    const forged = 'attackervalue.attackersignature';
    const result = verifyCsrf(forged, forged, sessionId, secret);
    assert.equal(result.ok, false);
  });

  test('a malformed token is rejected, not crashed on', () => {
    const result = verifyCsrf('nodot', 'nodot', sessionId, secret);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.reason, 'malformed');
  });

  test('safe methods are recognised', () => {
    assert.equal(isSafeMethod('GET'), true);
    assert.equal(isSafeMethod('head'), true);
    assert.equal(isSafeMethod('POST'), false);
    assert.equal(isSafeMethod('DELETE'), false);
  });

  test('the header name is the conventional one', () => {
    assert.equal(CSRF_HEADER, 'x-csrf-token');
  });
});

describe('origin checking', () => {
  const allowed = 'https://app.seshaaimarketing.com';

  test('matching origin passes', () => {
    assert.equal(verifyOrigin(allowed, null, allowed), true);
    assert.equal(verifyOrigin('https://app.seshaaimarketing.com/', null, allowed), true);
  });

  test('foreign origin fails', () => {
    assert.equal(verifyOrigin('https://evil.example', null, allowed), false);
  });

  test('a lookalike subdomain fails', () => {
    assert.equal(verifyOrigin('https://app.seshaaimarketing.com.evil.example', null, allowed), false);
  });

  test('a scheme downgrade fails', () => {
    assert.equal(verifyOrigin('http://app.seshaaimarketing.com', null, allowed), false);
  });

  test('MISSING origin fails closed', () => {
    // This is the important one: accepting a missing Origin on a state-changing
    // request is a trivial CSRF bypass.
    assert.equal(verifyOrigin(null, null, allowed), false);
    assert.equal(verifyOrigin(undefined, undefined, allowed), false);
  });

  test('referer is used only as a fallback', () => {
    assert.equal(verifyOrigin(null, `${allowed}/dashboard`, allowed), true);
    assert.equal(verifyOrigin(null, 'https://evil.example/x', allowed), false);
    assert.equal(verifyOrigin(null, 'not-a-url', allowed), false);
  });
});
