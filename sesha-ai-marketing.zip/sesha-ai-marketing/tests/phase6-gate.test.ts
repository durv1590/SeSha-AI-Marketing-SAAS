import assert from 'node:assert/strict';
import { test, describe, beforeEach } from 'node:test';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { MemoryDatabase } from '../src/lib/db/memory-store';
import { MemoryLockoutStore } from '../src/lib/auth/lockout';
import { signUp, toRole } from '../src/lib/auth/service';
import { completeOnboarding } from '../src/lib/workspace/service';
import type { TenantContext } from '../src/lib/tenant';

import {
  METRIC_IDS,
  METRICS,
  NO_CONNECTED_DATA,
  SOURCE_KINDS,
  SOURCE_LABEL,
  SOURCE_MEANING,
  formatValue,
  hasFigure,
} from '../src/lib/analytics/metrics';
import { analyticsFor, connectionsFor } from '../src/lib/analytics/service';
import { CALENDAR_VIEWS, EVENT_KINDS, STATUS_LABEL } from '../src/lib/calendar/types';
import { calendarView, createEvent } from '../src/lib/calendar/service';
import {
  ACTION_EFFECT,
  ACTION_KINDS,
  TRIGGER_KINDS,
  isOutboundAction,
  RULE_TEMPLATES,
} from '../src/lib/automation/types';
import { createRule, fire, listRuns } from '../src/lib/automation/service';
import { REPORT_KINDS, SECTION_IDS, SECTION_QUESTION } from '../src/lib/reports/types';
import { exportReport, generate, revokeShare, shareReport, toReport, viewShared } from '../src/lib/reports/service';
import { EXPORT_FORMATS } from '../src/lib/reports/export';
import {
  ALWAYS_ON,
  CHANNELS,
  NOTIFICATION_KINDS,
  PHASE_6_NOTIFICATION_KINDS,
  shouldNotify,
  resolvePreferences,
} from '../src/lib/notifications/types';
import { send, updatePreferences } from '../src/lib/notifications/service';
import { createLead } from '../src/lib/leads/service';

/**
 * The Phase 6 quality gate, executed.
 *
 * Eleven boxes, one describe block each, named after the brief's line — the same
 * shape as the Phase 3, 4 and 5 gates. A checklist someone ticks by hand is a
 * claim; this file makes each line fail loudly if the behaviour regresses.
 */

const PASSWORD = 'a genuinely long passphrase 2026';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of readdirSync(dir)) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) walk(full, out);
    else if (/\.(ts|tsx)$/.test(entry)) out.push(full);
  }
  return out;
}

const business = {
  name: 'Acme Coffee',
  industry: 'hospitality' as const,
  country: 'India',
  city: 'Nagpur',
  websiteUrl: 'https://acme-coffee.example.com',
};

const profile = {
  targetAudience: 'Office workers within walking distance who buy coffee daily.',
  productsServices: 'Speciality coffee, pastries and a small lunch menu.',
  priceRange: 'mid_market' as const,
  marketingGoals: ['foot-traffic'] as const,
  marketingChannels: ['organic-search', 'email'] as const,
  brandVoice: { tones: ['friendly'] as const, notes: 'Warm, never salesy.' },
  competitors: [{ name: 'Rival Roasters' }],
};

let db: MemoryDatabase;
let tenant: TenantContext;
let projectId: string;
const ctx = () => ({ db, now: () => new Date() });

beforeEach(async () => {
  db = new MemoryDatabase();
  const signed = await signUp(
    { db, lockout: new MemoryLockoutStore(), secret: 'test-secret-value-at-least-32-bytes-long' },
    { email: `gate6-${Math.random().toString(36).slice(2)}@example.com`, password: PASSWORD },
  );
  if (!signed.ok || !signed.userId) throw new Error('signup failed');
  const memberships = await db.memberships.findForUser(signed.userId);
  tenant = {
    userId: signed.userId,
    organizationId: memberships[0]!.organizationId,
    role: toRole(memberships[0]!.role),
  };
  const onboarded = await completeOnboarding({ db }, tenant, { business, profile });
  projectId = onboarded.project.id;
});

/* -------------------------------------------------------------------------- */
/* 1. Analytics                                                               */
/* -------------------------------------------------------------------------- */

describe('gate 1: analytics', () => {
  test('the nineteen metrics the brief names all exist', () => {
    assert.equal(METRIC_IDS.length, 19);
    for (const id of [
      'leads',
      'conversion',
      'traffic',
      'engagement',
      'reach',
      'impressions',
      'ctr',
      'cpc',
      'cpa',
      'roas',
      'followers',
      'content_performance',
      'campaign_performance',
      'organic_search',
      'seo_score',
      'aeo_score',
      'schema_issues',
      'crawl_errors',
      'content_coverage',
    ] as const) {
      assert.ok((METRIC_IDS as readonly string[]).includes(id), id);
    }
  });

  test('the analytics surface produces all nineteen for a real project', async () => {
    const report = await analyticsFor(ctx(), tenant, projectId);
    assert.equal(report.metrics.length, 19);
    assert.deepEqual(report.metrics.map((metric) => metric.id).sort(), [...METRIC_IDS].sort());
  });

  test('the metrics SeSha genuinely has are calculated, not unavailable', async () => {
    await createLead(ctx(), tenant, {
      projectId,
      name: 'Priya',
      email: 'priya@example.com',
      enquiry: 'Catering?',
      source: 'website_form',
      optInBasis: 'enquiry_reply',
    });
    const report = await analyticsFor(ctx(), tenant, projectId);
    const leads = report.metrics.find((metric) => metric.id === 'leads');
    assert.equal(leads?.value.kind, 'calculated');
  });
});

/* -------------------------------------------------------------------------- */
/* 2. Data source labels                                                      */
/* -------------------------------------------------------------------------- */

describe('gate 2: every metric identifies its source', () => {
  test('the six labels the brief names all exist and are explained', () => {
    assert.deepEqual([...SOURCE_KINDS], [
      'connected_api',
      'user_provided',
      'retrieved',
      'calculated',
      'ai_estimate',
      'unavailable',
    ]);
    for (const kind of SOURCE_KINDS) {
      assert.ok(SOURCE_LABEL[kind].length > 0, kind);
      assert.ok(SOURCE_MEANING[kind].length > 20, kind);
    }
  });

  test('no metric value can carry a figure without its provenance', async () => {
    const report = await analyticsFor(ctx(), tenant, projectId);
    for (const metric of report.metrics) {
      const value = metric.value;
      if (!hasFigure(value)) continue;
      assert.ok(typeof value.asOf === 'string' && value.asOf.length > 0, metric.id);
      switch (value.kind) {
        case 'calculated':
          assert.ok(value.formula.length > 10, metric.id);
          break;
        case 'connected_api':
          assert.ok(value.source.length > 0, metric.id);
          break;
        case 'retrieved':
          assert.ok(value.sourceUrl.length > 0, metric.id);
          break;
        case 'user_provided':
          assert.ok(value.enteredBy.length > 0, metric.id);
          break;
      }
    }
  });
});

/* -------------------------------------------------------------------------- */
/* 3. Marketing calendar                                                      */
/* -------------------------------------------------------------------------- */

describe('gate 3: the marketing calendar', () => {
  test('the four views the brief names all exist', () => {
    assert.deepEqual([...CALENDAR_VIEWS], ['daily', 'weekly', 'monthly', 'campaign']);
  });

  test('the ten event kinds the brief names all exist', () => {
    assert.equal(EVENT_KINDS.length, 10);
    for (const kind of ['social', 'blog', 'email', 'ads', 'offer', 'event'] as const) {
      assert.ok((EVENT_KINDS as readonly string[]).includes(kind), kind);
    }
    for (const kind of ['website_update', 'seo_task', 'aeo_task', 'schema_task'] as const) {
      assert.ok((EVENT_KINDS as readonly string[]).includes(kind), kind);
    }
  });

  test('every view renders for a real project', async () => {
    for (const view of CALENDAR_VIEWS) {
      const result = await calendarView(ctx(), tenant, projectId, view, '2026-03-11');
      assert.equal(result.view, view);
    }
  });

  test('AI recommends activities for empty dates, from this customer’s own data', async () => {
    const result = await calendarView(ctx(), tenant, projectId, 'weekly', '2026-03-11');
    assert.ok(result.suggestions.length > 0);
    for (const suggestion of result.suggestions) {
      assert.ok(suggestion.basedOn.length > 0, suggestion.title);
      assert.ok(suggestion.why.length > 20, suggestion.title);
    }
  });

  test('no status claims the calendar publishes or schedules anything', () => {
    assert.deepEqual(Object.keys(STATUS_LABEL).sort(), ['done', 'planned', 'skipped']);
  });
});

/* -------------------------------------------------------------------------- */
/* 4. Automation engine                                                       */
/* -------------------------------------------------------------------------- */

describe('gate 4: trigger, condition, action', () => {
  test('the brief’s six examples all exist as offered rules', () => {
    assert.equal(RULE_TEMPLATES.length, 6);
  });

  test('every trigger is an event SeSha genuinely has', () => {
    assert.ok(TRIGGER_KINDS.length >= 6);
    // No trigger that could never fire: nothing depends on an ads or social API.
    for (const kind of TRIGGER_KINDS) {
      assert.ok(!/ads_|spend|impression|follower/.test(kind), kind);
    }
  });

  test('NO action can reach a third party', () => {
    for (const kind of ACTION_KINDS) {
      assert.equal(isOutboundAction(kind), false, kind);
      assert.ok(!/send|post|publish|email|whatsapp|sms|spend|launch/i.test(kind), kind);
      assert.ok(ACTION_EFFECT[kind].length > 20, kind);
    }
  });

  test('a rule runs end to end and produces work for a person, not a message', async () => {
    const { rule } = await createRule(ctx(), tenant, projectId, {
      name: 'Follow up',
      trigger: 'lead_created',
      conditions: [{ field: 'email', operator: 'is_set' }],
      actions: [{ kind: 'create_follow_up', template: 'Ring the {{source}} lead.', offsetDays: 1 }],
      enabled: true,
    });
    const lead = await createLead(ctx(), tenant, {
      projectId,
      name: 'Priya',
      email: 'priya@example.com',
      enquiry: 'Catering?',
      source: 'website_form',
      optInBasis: 'enquiry_reply',
    });
    const results = await fire(
      ctx(),
      tenant.organizationId,
      projectId,
      { kind: 'lead_created', payload: { email: 'priya@example.com', source: 'website_form' }, subjectId: lead.lead.id },
      tenant.userId,
    );
    assert.equal(results[0]?.matched, true);

    const activities = await db.leadActivities.listForLead(tenant.organizationId, lead.lead.id);
    assert.ok(activities.some((row) => row.kind === 'follow_up' && row.dueAt !== null));

    const runs = await listRuns(ctx(), tenant, rule.id);
    assert.equal(runs.length, 1);
  });

  test('a run that did nothing is still recorded, with the condition that failed', async () => {
    const { rule } = await createRule(ctx(), tenant, projectId, {
      name: 'High scores only',
      trigger: 'lead_created',
      conditions: [{ field: 'score', operator: 'greater_than', value: 90 }],
      actions: [{ kind: 'create_task', template: 'Ring them.' }],
      enabled: true,
    });
    await fire(ctx(), tenant.organizationId, projectId, { kind: 'lead_created', payload: { score: 5 } });
    const runs = await listRuns(ctx(), tenant, rule.id);
    assert.equal(runs.length, 1);
    assert.equal(runs[0]?.matched, false);
    assert.ok((runs[0]?.skipReason ?? '').length > 10);
  });
});

/* -------------------------------------------------------------------------- */
/* 5. Report generator                                                        */
/* -------------------------------------------------------------------------- */

describe('gate 5: the nine reports and the six questions', () => {
  // Phase 9 made report generation consume the `reports` allowance (it was
  // checked but never recorded). Nine kinds exceed the Free plan's two, so this
  // gate runs on Agency, where reports are unlimited; the limit itself is
  // asserted in tests/journey.test.ts and tests/quota.test.ts.
  beforeEach(async () => {
    await db.subscriptions.update(tenant.organizationId, { plan: 'agency' });
  });

  test('the nine kinds the brief names all exist', () => {
    assert.deepEqual([...REPORT_KINDS], [
      'daily',
      'weekly',
      'monthly',
      'campaign',
      'seo',
      'aeo',
      'schema',
      'social',
      'executive',
    ]);
  });

  test('every kind generates, and answers all six questions or says why not', async () => {
    for (const kind of REPORT_KINDS) {
      const row = await generate(ctx(), tenant, projectId, kind);
      const report = toReport(row);
      assert.deepEqual(report.sections.map((section) => section.id), [...SECTION_IDS], kind);
      for (const section of report.sections) {
        assert.equal(section.question, SECTION_QUESTION[section.id], kind);
        if (section.points.length === 0) {
          assert.ok(
            (section.emptyReason ?? '').length > 20,
            `${kind}: "${section.question}" is empty with no explanation`,
          );
        }
      }
    }
  });

  test('a report carries which sources were connected when it was generated', async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');
    assert.deepEqual([...row.connectedSources], []);
    assert.equal(toReport(row).provenance.anyConnected, false);
  });
});

/* -------------------------------------------------------------------------- */
/* 6. Export                                                                  */
/* -------------------------------------------------------------------------- */

describe('gate 6: PDF, CSV, JSON and share', () => {
  test('the three file formats the brief names all exist', () => {
    assert.deepEqual([...EXPORT_FORMATS], ['pdf', 'csv', 'json']);
  });

  test('each format renders, and the PDF is a real PDF', async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');

    const json = await exportReport(ctx(), tenant, row.id, 'json');
    assert.equal(typeof json.body, 'string');
    JSON.parse(json.body as string);

    const csv = await exportReport(ctx(), tenant, row.id, 'csv');
    assert.match(csv.body as string, /METRICS/);

    const pdf = await exportReport(ctx(), tenant, row.id, 'pdf');
    assert.ok(pdf.body instanceof Uint8Array);
    const bytes = pdf.body as Uint8Array;
    assert.equal(String.fromCharCode(...bytes.slice(0, 5)), '%PDF-');
    assert.match(String.fromCharCode(...bytes.slice(-40)), /%%EOF/);
  });

  test('an unavailable metric exports as a row with no number, not as a missing row', async () => {
    const row = await generate(ctx(), tenant, projectId, 'monthly');
    const csv = (await exportReport(ctx(), tenant, row.id, 'csv')).body as string;
    const line = csv.split('\r\n').find((candidate) => candidate.startsWith('Traffic'));
    assert.ok(line, 'dropping the row lets a reader conclude the figure was zero');
    assert.match(line, /Unavailable/);
    assert.equal(line.split(',')[1], '');
  });

  test('a share link works, expires, and stops immediately when revoked', async () => {
    const row = await generate(ctx(), tenant, projectId, 'weekly');
    const shared = await shareReport(ctx(), tenant, row.id);
    assert.notEqual(shared.share.tokenHash, shared.token);
    assert.ok(shared.share.expiresAt.getTime() > Date.now());

    const viewed = await viewShared(ctx(), shared.token);
    assert.equal(viewed.row.id, row.id);

    await revokeShare(ctx(), tenant, shared.share.id);
    await assert.rejects(() => viewShared(ctx(), shared.token));
  });
});

/* -------------------------------------------------------------------------- */
/* 7. Notifications                                                           */
/* -------------------------------------------------------------------------- */

describe('gate 7: notifications, and the user controls them', () => {
  test('the eight kinds the brief names all exist', () => {
    assert.equal(PHASE_6_NOTIFICATION_KINDS.length, 8);
    for (const kind of PHASE_6_NOTIFICATION_KINDS) {
      assert.ok((NOTIFICATION_KINDS as readonly string[]).includes(kind), kind);
    }
  });

  test('a user can switch a marketing notification off, and it stops', async () => {
    const before = await send(ctx(), tenant.organizationId, tenant.userId, {
      kind: 'new_lead',
      title: 'A lead arrived',
      body: 'From the website.',
    });
    assert.equal(before.sent, true);

    await updatePreferences(ctx(), tenant, [{ kind: 'new_lead', inApp: false }]);

    const after = await send(ctx(), tenant.organizationId, tenant.userId, {
      kind: 'new_lead',
      title: 'Another one',
      body: 'From the website.',
    });
    assert.equal(after.sent, false);
  });

  test('none of the brief’s eight is forced on', () => {
    for (const kind of PHASE_6_NOTIFICATION_KINDS) {
      assert.equal(ALWAYS_ON[kind], undefined, `${kind} must be the user's choice`);
    }
  });

  test('security and billing cannot be silenced, and the reason is available to show', () => {
    for (const kind of ['security', 'billing'] as const) {
      assert.ok((ALWAYS_ON[kind] ?? '').length > 40, kind);
      const off = resolvePreferences([{ kind, inApp: false, email: false }]);
      assert.equal(shouldNotify(kind, off).send, true, kind);
    }
  });

  test('no channel that cannot send is ever returned', () => {
    const optimistic = NOTIFICATION_KINDS.map((kind) => ({ kind, inApp: true, email: true }));
    for (const kind of NOTIFICATION_KINDS) {
      const decision = shouldNotify(kind, resolvePreferences(optimistic));
      if (!decision.send) continue;
      for (const channel of decision.channels) {
        assert.equal(CHANNELS[channel].available, true, `${kind} would use an unavailable channel`);
      }
    }
  });
});

/* -------------------------------------------------------------------------- */
/* 8. Background jobs                                                         */
/* -------------------------------------------------------------------------- */

describe('gate 8: background jobs', () => {
  test('the job kinds Phase 6 adds are declared in the migration', () => {
    const sql = readFileSync(
      path.join(root, 'db', 'migrations', '0006_analytics_calendar_automation_reports.sql'),
      'utf8',
    );
    for (const kind of ['report_generation', 'automation_sweep']) {
      assert.match(sql, new RegExp(`'${kind}'`), `the jobs CHECK does not allow '${kind}'`);
    }
  });

  test('a report is generated through a repository, not inline in a route handler', () => {
    const route = readFileSync(path.join(root, 'src', 'app', 'api', 'reports', 'route.ts'), 'utf8');
    assert.ok(!/SELECT |INSERT /i.test(route), 'the route reaches past the service layer');
    assert.match(route, /from '@\/lib\/reports\/service'/);
  });
});

/* -------------------------------------------------------------------------- */
/* 9. No fake metrics                                                         */
/* -------------------------------------------------------------------------- */

describe('gate 9: never fabricate analytics', () => {
  test('with nothing connected, no metric requiring a connection carries a figure', async () => {
    const report = await analyticsFor(ctx(), tenant, projectId);
    const states = await connectionsFor(ctx(), tenant, projectId);
    assert.ok(states.every((state) => !state.connected));

    for (const metric of report.metrics) {
      if (METRICS[metric.id].requires === 'none') continue;
      assert.equal(metric.value.kind, 'unavailable', metric.id);
      assert.equal(hasFigure(metric.value), false, metric.id);
      assert.equal(formatValue(metric.value), null, metric.id);
    }
  });

  test('the sentence the brief requires appears wherever a connection is what is missing', async () => {
    // Scoped to the metrics that need a CONNECTION. The first version asserted the
    // sentence on every unavailable metric and failed on `conversion`, whose label
    // is "Nothing closed yet" — and rightly so: nothing is missing from the data
    // there, the customer simply has not closed a deal. Stamping "No connected
    // data available." on it would have been a small lie, and satisfying the test
    // by adding one would have been the wrong fix.
    const report = await analyticsFor(ctx(), tenant, projectId);
    const needsConnection = report.metrics.filter(
      (metric) => METRICS[metric.id].requires !== 'none' && metric.value.kind === 'unavailable',
    );
    assert.ok(needsConnection.length > 0);
    for (const metric of needsConnection) {
      assert.equal(
        metric.value.kind === 'unavailable' ? metric.value.label : '',
        NO_CONNECTED_DATA,
        metric.id,
      );
    }

    // Every unavailable metric, whatever the reason, still has to say why and what
    // would change it.
    for (const metric of report.metrics) {
      if (metric.value.kind !== 'unavailable') continue;
      assert.ok(metric.value.why.length > 20, metric.id);
      assert.ok(metric.value.whatWouldMakeItAvailable.length > 20, metric.id);
    }
  });

  test('no column anywhere stores a traffic, impression, click or follower figure', () => {
    const sql = readFileSync(path.join(root, 'db', 'schema.sql'), 'utf8');
    // Column definitions only: a CHECK list or a comment mentioning the word is
    // fine, a column holding the number is not.
    const columns = [...sql.matchAll(/^\s{4}([a-z_]+)\s+(integer|bigint|numeric|real|double)/gm)].map(
      (match) => match[1]!,
    );
    for (const column of columns) {
      assert.ok(
        !/^(sessions|users|pageviews|impressions|clicks|followers|reach|engagement|spend|revenue|ctr|cpc|cpa|roas)$/.test(
          column,
        ),
        `db/schema.sql has a column "${column}" that would hold a figure SeSha cannot measure`,
      );
    }
  });

  test('no analytics or reporting module exports a function that would invent a figure', () => {
    // Scoped to the modules that produce METRICS. The first version swept all of
    // src/lib and flagged `estimateTokens` in the AI provider — which estimates
    // the size of a prompt, not a customer's traffic, and is exactly the kind of
    // honest estimate this codebase is fine with. A gate that fires on unrelated
    // code gets weakened until it fires on nothing.
    const offenders: string[] = [];
    for (const directory of ['analytics', 'reports', 'calendar', 'automation']) {
      for (const file of walk(path.join(root, 'src', 'lib', directory))) {
        const text = readFileSync(file, 'utf8');
        for (const match of text.matchAll(
          /export\s+(?:async\s+)?(?:function|const)\s+(\w*(?:estimate|predict|simulate|fake|mock|placeholder)\w*)/gi,
        )) {
          offenders.push(`${path.relative(root, file)}: ${match[1]}`);
        }
      }
    }
    assert.deepEqual(offenders, []);
  });

  test('the report generator has no path that substitutes zero for unavailable', () => {
    const source = readFileSync(path.join(root, 'src', 'lib', 'reports', 'generate.ts'), 'utf8');
    assert.ok(!/\?\?\s*0\b/.test(source), 'a `?? 0` in the generator is how a fabricated zero appears');
  });
});

/* -------------------------------------------------------------------------- */
/* 10. Tests                                                                  */
/* -------------------------------------------------------------------------- */

describe('gate 10: the new surfaces are tested', () => {
  test('every Phase 6 module has a test file that imports it', () => {
    const testSources = readdirSync(path.join(root, 'tests'))
      .filter((name) => name.endsWith('.test.ts'))
      .map((name) => readFileSync(path.join(root, 'tests', name), 'utf8'))
      .join('\n');

    for (const module of [
      'analytics/metrics',
      'analytics/connections',
      'analytics/compute',
      'analytics/service',
      'calendar/types',
      'calendar/service',
      'automation/types',
      'automation/service',
      'reports/types',
      'reports/generate',
      'reports/export',
      'reports/pdf',
      'reports/share',
      'reports/service',
      'notifications/types',
      'notifications/service',
    ]) {
      assert.match(testSources, new RegExp(`lib/${module}'`), `${module} has no test importing it`);
    }
  });

  test('every Phase 6 API route exists', () => {
    for (const route of [
      'analytics/route.ts',
      'calendar/route.ts',
      'calendar/[id]/route.ts',
      'automations/route.ts',
      'automations/[id]/route.ts',
      'reports/route.ts',
      'reports/[id]/route.ts',
      'reports/[id]/export/route.ts',
      'notifications/route.ts',
      'notifications/preferences/route.ts',
      'share/[token]/route.ts',
    ]) {
      const full = path.join(root, 'src', 'app', 'api', route);
      assert.ok(statSync(full).isFile(), `${route} is missing`);
    }
  });
});

/* -------------------------------------------------------------------------- */
/* 11. Production build                                                       */
/* -------------------------------------------------------------------------- */

describe('gate 11: the code is buildable and internally consistent', () => {
  test('every table the code declares exists in the migrations', () => {
    const sql = walk(path.join(root, 'db', 'migrations'))
      .concat([])
      .map(() => '')
      .join('');
    void sql;
    const migrations = readdirSync(path.join(root, 'db', 'migrations'))
      .filter((name) => name.endsWith('.sql'))
      .map((name) => readFileSync(path.join(root, 'db', 'migrations', name), 'utf8'))
      .join('\n');

    for (const table of [
      'data_connections',
      'calendar_events',
      'automation_rules',
      'automation_runs',
      'reports',
      'report_shares',
      'notification_preferences',
    ]) {
      assert.match(migrations, new RegExp(`CREATE TABLE IF NOT EXISTS ${table}\\b`), table);
    }
  });

  test('every Phase 6 table is tenant-isolated by row-level security', () => {
    const sql = readFileSync(
      path.join(root, 'db', 'migrations', '0006_analytics_calendar_automation_reports.sql'),
      'utf8',
    );
    for (const table of [
      'data_connections',
      'calendar_events',
      'automation_rules',
      'automation_runs',
      'reports',
      'report_shares',
      'notification_preferences',
    ]) {
      assert.match(sql, new RegExp(`ALTER TABLE ${table}\\s+ENABLE ROW LEVEL SECURITY`), table);
      assert.match(sql, new RegExp(`'${table}'`), `${table} is missing from the policy loop`);
    }
  });

  test('db/schema.sql is regenerated from the migrations', () => {
    const generated = readFileSync(path.join(root, 'db', 'schema.sql'), 'utf8');
    for (const table of ['calendar_events', 'automation_runs', 'report_shares']) {
      assert.match(generated, new RegExp(`CREATE TABLE IF NOT EXISTS ${table}\\b`), table);
    }
  });

  test('production dependencies are unchanged', () => {
    const pkg = JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8')) as {
      dependencies: Record<string, string>;
    };
    assert.deepEqual(Object.keys(pkg.dependencies).sort(), [
      'clsx',
      'next',
      'react',
      'react-dom',
      'tailwind-merge',
    ]);
  });

  test('the PDF writer uses no dependency at all', () => {
    const source = readFileSync(path.join(root, 'src', 'lib', 'reports', 'pdf.ts'), 'utf8');
    const imports = [...source.matchAll(/^import .*from '([^']+)'/gm)].map((match) => match[1]!);
    for (const specifier of imports) {
      assert.ok(
        specifier.startsWith('.') || specifier.startsWith('@/'),
        `the PDF writer imports "${specifier}" — it must have no external dependency`,
      );
    }
  });
});

/* -------------------------------------------------------------------------- */
/* Stop after Phase 6                                                         */
/* -------------------------------------------------------------------------- */

/**
 * Phase 6's boundary, kept and moved forward.
 *
 * When this file was written the boundary was "nothing promises Phase 6 or
 * earlier, and Phase 7 has not begun". Phase 7 has now shipped, so the second
 * half of that is history — `tests/phase7-gate.test.ts` owns the live boundary
 * and this block keeps the check that does not belong to any one phase: the
 * product must never advertise a phase that has already been delivered without
 * the thing it promised. Phase 7 caught eight planned AI agents still pointing
 * at Phase 7, which is exactly what this is for.
 */
describe('gate: no phase boundary is left behind', () => {
  test('nothing in the product is described as arriving in a phase that has shipped', () => {
    const DELIVERED = 8;
    const offenders: string[] = [];
    for (const file of walk(path.join(root, 'src'))) {
      const text = readFileSync(file, 'utf8');
      for (const match of text.matchAll(/phase:?\s*['"]Phase (\d+)['"]/g)) {
        if (Number(match[1]) <= DELIVERED) {
          offenders.push(`${path.relative(root, file)}: ${match[0]}`);
        }
      }
    }
    assert.deepEqual(offenders, []);
  });
});
