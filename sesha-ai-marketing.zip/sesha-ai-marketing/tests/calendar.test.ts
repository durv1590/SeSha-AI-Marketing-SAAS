import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  CALENDAR_VIEWS,
  DERIVABLE_KINDS,
  EVENT_KINDS,
  EVENT_LABEL,
  ORIGIN_LABEL,
  STATUS_LABEL,
  SUGGESTIBLE_CHANNELS,
  VIEW_LABEL,
  addDays,
  datesInRange,
  groupByCampaign,
  groupByDate,
  inRange,
  isCalendarView,
  isEventKind,
  parseDateKey,
  rangeFor,
  suggestForEmptyDates,
  toDateKey,
  type CalendarEvent,
} from '../src/lib/calendar/types';

function event(partial: Partial<CalendarEvent> & { readonly date: string }): CalendarEvent {
  return {
    id: partial.id ?? `e-${partial.date}`,
    kind: partial.kind ?? 'social',
    title: partial.title ?? 'Something',
    notes: partial.notes ?? '',
    status: partial.status ?? 'planned',
    origin: partial.origin ?? 'manual',
    ...(partial.campaign ? { campaign: partial.campaign } : {}),
    date: partial.date,
  };
}

describe('the calendar vocabulary', () => {
  test('carries the ten event kinds the brief names', () => {
    assert.equal(EVENT_KINDS.length, 10);
    for (const kind of EVENT_KINDS) assert.ok(EVENT_LABEL[kind].length > 0);
    for (const expected of ['social', 'blog', 'email', 'ads', 'offer', 'event'] as const) {
      assert.ok((EVENT_KINDS as readonly string[]).includes(expected), expected);
    }
  });

  test('carries the four views the brief names', () => {
    assert.deepEqual([...CALENDAR_VIEWS], ['daily', 'weekly', 'monthly', 'campaign']);
    for (const view of CALENDAR_VIEWS) assert.ok(VIEW_LABEL[view].length > 0);
  });

  test('status has no "published" or "scheduled" value', () => {
    // SeSha cannot publish or schedule anything. A status saying it did would be
    // the calendar quietly claiming a capability the rest of the product refuses.
    const statuses = Object.keys(STATUS_LABEL);
    assert.deepEqual(statuses.sort(), ['done', 'planned', 'skipped']);
  });

  test('every origin is explained, including accepted suggestions', () => {
    assert.ok(ORIGIN_LABEL.accepted_suggestion.length > 0);
    assert.ok(ORIGIN_LABEL.derived.length > 0);
    assert.ok(ORIGIN_LABEL.manual.length > 0);
  });

  test('derivable kinds are a subset of the event kinds', () => {
    for (const kind of DERIVABLE_KINDS) assert.ok((EVENT_KINDS as readonly string[]).includes(kind));
  });

  test('the guards reject anything else', () => {
    assert.ok(isCalendarView('weekly'));
    assert.ok(!isCalendarView('yearly'));
    assert.ok(isEventKind('blog'));
    assert.ok(!isEventKind('podcast'));
  });
});

describe('dates', () => {
  test('a date key round-trips', () => {
    const key = '2026-03-09';
    const parsed = parseDateKey(key);
    assert.ok(parsed);
    assert.equal(toDateKey(parsed), key);
  });

  test('a malformed key is null rather than an Invalid Date', () => {
    assert.equal(parseDateKey('2026-13-40'), null);
    assert.equal(parseDateKey('not a date'), null);
    assert.equal(parseDateKey('2026-3-9'), null);
  });

  test('addDays crosses months and years', () => {
    assert.equal(addDays('2026-02-28', 1), '2026-03-01');
    assert.equal(addDays('2026-12-31', 1), '2027-01-01');
    assert.equal(addDays('2026-01-01', -1), '2025-12-31');
  });

  test('the weekly range starts on Monday whichever day is the anchor', () => {
    // 2026-03-11 is a Wednesday.
    const range = rangeFor('weekly', '2026-03-11');
    assert.equal(range.from, '2026-03-09');
    assert.equal(range.to, '2026-03-15');
    const monday = rangeFor('weekly', '2026-03-09');
    assert.equal(monday.from, '2026-03-09');
    const sunday = rangeFor('weekly', '2026-03-15');
    assert.equal(sunday.from, '2026-03-09', 'a Sunday belongs to the week that began on Monday');
  });

  test('the monthly range covers the whole month', () => {
    const range = rangeFor('monthly', '2026-02-17');
    assert.equal(range.from, '2026-02-01');
    assert.equal(range.to, '2026-02-28');
    assert.equal(datesInRange(range).length, 28);
  });

  test('the daily range is one day', () => {
    const range = rangeFor('daily', '2026-03-11');
    assert.equal(range.from, range.to);
    assert.equal(datesInRange(range).length, 1);
  });

  test('inRange is inclusive at both ends', () => {
    const range = rangeFor('weekly', '2026-03-11');
    assert.ok(inRange('2026-03-09', range));
    assert.ok(inRange('2026-03-15', range));
    assert.ok(!inRange('2026-03-08', range));
    assert.ok(!inRange('2026-03-16', range));
  });
});

describe('grouping', () => {
  const events = [
    event({ date: '2026-03-09', id: 'a' }),
    event({ date: '2026-03-09', id: 'b' }),
    event({ date: '2026-03-11', id: 'c', campaign: 'Spring' }),
    event({ date: '2026-03-12', id: 'd', campaign: 'Spring' }),
    event({ date: '2026-03-13', id: 'e' }),
  ];

  test('groupByDate returns an entry for every date in the range, including empty ones', () => {
    const range = rangeFor('weekly', '2026-03-11');
    const grouped = groupByDate(events, range);
    assert.equal(grouped.length, 7);
    const ninth = grouped.find((day) => day.date === '2026-03-09');
    assert.equal(ninth?.events.length, 2);
    const tenth = grouped.find((day) => day.date === '2026-03-10');
    assert.equal(tenth?.events.length, 0, 'an empty day must be present, not absent');
  });

  test('groupByCampaign separates the ungrouped entries rather than inventing a campaign for them', () => {
    const groups = groupByCampaign(events);
    const spring = groups.find((group) => group.campaign === 'Spring');
    assert.equal(spring?.events.length, 2);
    const rest = groups.filter((group) => group.campaign !== 'Spring');
    assert.equal(rest.reduce((total, group) => total + group.events.length, 0), 3);
  });
});

describe('suggestions for empty dates', () => {
  const range = rangeFor('weekly', '2026-03-11');

  test('nothing is suggested when the customer listed no channels and has no open work', () => {
    const suggestions = suggestForEmptyDates({ range, events: [], channels: [], openTasks: [] });
    assert.equal(suggestions.length, 0, 'guessing a channel they never mentioned is guessing');
  });

  test('real open work is placed before anything derived from a channel', () => {
    const suggestions = suggestForEmptyDates({
      range,
      events: [],
      channels: ['social-organic'],
      openTasks: [{ kind: 'seo_task', title: 'Fix the missing titles', why: 'Four pages have no title.' }],
    });
    assert.ok(suggestions.length > 0);
    assert.equal(suggestions[0]?.kind, 'seo_task');
    assert.match(suggestions[0]?.basedOn[0] ?? '', /your own audits/);
  });

  test('every suggestion carries a reason that is not "the date is empty"', () => {
    const suggestions = suggestForEmptyDates({
      range,
      events: [],
      channels: ['email', 'paid-ads'],
      openTasks: [],
    });
    assert.ok(suggestions.length > 0);
    for (const suggestion of suggestions) {
      assert.ok(suggestion.why.length > 20, suggestion.title);
      assert.ok(!/empty/i.test(suggestion.why), suggestion.why);
      assert.ok(suggestion.basedOn.length > 0);
    }
  });

  test('a busy stretch is left alone', () => {
    const busy = datesInRange(range).map((date) => event({ date }));
    assert.equal(suggestForEmptyDates({ range, events: busy, channels: ['email'], openTasks: [] }).length, 0);
  });

  test('a date next to a busy day is not treated as a gap', () => {
    const suggestions = suggestForEmptyDates({
      range,
      events: [event({ date: '2026-03-09' })],
      channels: ['email'],
      openTasks: [],
      gapDays: 2,
    });
    assert.ok(!suggestions.some((suggestion) => suggestion.date === '2026-03-10'));
    assert.ok(!suggestions.some((suggestion) => suggestion.date === '2026-03-11'));
  });

  test('an unrecognised channel produces nothing rather than a generic filler', () => {
    const suggestions = suggestForEmptyDates({
      range,
      events: [],
      channels: ['telepathy'],
      openTasks: [],
    });
    assert.equal(suggestions.length, 0);
  });

  test('channel names are matched case- and separator-insensitively', () => {
    const suggestions = suggestForEmptyDates({
      range,
      events: [],
      channels: ['Social Organic'],
      openTasks: [],
    });
    assert.ok(suggestions.length > 0);
  });

  test('the suggestible channels are listed for the interface', () => {
    assert.ok(SUGGESTIBLE_CHANNELS.length >= 6);
    assert.ok(SUGGESTIBLE_CHANNELS.includes('organic-search'));
  });

  test('a suggestion is not a CalendarEvent and has no id or status', () => {
    const suggestions = suggestForEmptyDates({
      range,
      events: [],
      channels: ['email'],
      openTasks: [],
    });
    const first = suggestions[0];
    assert.ok(first);
    assert.ok(!('id' in first), 'a suggestion with an id is one refactor away from being saved as a plan');
    assert.ok(!('status' in first));
  });
});
