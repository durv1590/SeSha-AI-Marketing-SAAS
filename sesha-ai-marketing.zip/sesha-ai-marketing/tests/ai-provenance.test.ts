import assert from 'node:assert/strict';
import { test, describe } from 'node:test';

import {
  PROVENANCE_DISPLAY,
  PROVENANCE_INSTRUCTION,
  PROVENANCE_KINDS,
  SOURCED_KINDS,
  UNSOURCED_KINDS,
  blocksToText,
  isProvenanceKind,
  isSourced,
  lintClaims,
  parseProvenance,
  summarize,
  type ProvenanceBlock,
} from '../src/lib/ai/provenance';

/**
 * Provenance and the claim linter.
 *
 * This is the suite that backs "never present AI assumptions as facts". It
 * checks both halves of the defence: the parser rejects a response that does
 * not declare its sourcing, and the linter independently catches a fabricated
 * statistic even when the model tagged it as something harmless.
 */

const block = (kind: string, text: string, source?: unknown) => ({ kind, text, ...(source ? { source } : {}) });
const wrap = (...blocks: unknown[]) => JSON.stringify({ blocks });

describe('the seven kinds', () => {
  test('all seven from the brief exist', () => {
    assert.deepEqual([...PROVENANCE_KINDS], [
      'user_provided',
      'connected',
      'retrieved',
      'ai_estimate',
      'ai_inference',
      'recommendation',
      'unavailable',
    ]);
  });

  test('sourced and unsourced kinds do not overlap', () => {
    for (const kind of SOURCED_KINDS) {
      assert.ok(!UNSOURCED_KINDS.includes(kind), `${kind} is in both lists`);
    }
  });

  test('only sourced kinds may be presented as fact', () => {
    for (const kind of PROVENANCE_KINDS) {
      assert.equal(
        PROVENANCE_DISPLAY[kind].presentAsFact,
        isSourced(kind),
        `${kind} presentAsFact disagrees with isSourced`,
      );
    }
  });

  test('every kind has a label and a description', () => {
    for (const kind of PROVENANCE_KINDS) {
      assert.ok(PROVENANCE_DISPLAY[kind].label.length > 0);
      assert.ok(PROVENANCE_DISPLAY[kind].description.length > 0);
    }
  });

  test('isProvenanceKind rejects anything else', () => {
    assert.equal(isProvenanceKind('user_provided'), true);
    assert.equal(isProvenanceKind('fact'), false);
    assert.equal(isProvenanceKind(''), false);
    assert.equal(isProvenanceKind(null), false);
  });
});

describe('parsing', () => {
  test('parses a well-formed response', () => {
    const result = parseProvenance(wrap(block('user_provided', 'Your audience is local diners.')));
    assert.equal(result.ok, true);
    if (result.ok) assert.equal(result.response.blocks.length, 1);
  });

  test('accepts an already-parsed object', () => {
    const result = parseProvenance({ blocks: [block('recommendation', 'Post twice a week.')] });
    assert.equal(result.ok, true);
  });

  test('tolerates a code fence, which models add unprompted', () => {
    const fenced = '```json\n' + wrap(block('ai_inference', 'A conclusion.')) + '\n```';
    assert.equal(parseProvenance(fenced).ok, true);
  });

  test('REJECTS untagged prose rather than showing it unlabelled', () => {
    // The failure mode this prevents: a wall of plausible text with no sourcing.
    const result = parseProvenance('Your market is worth $4.2 billion and growing fast.');
    assert.equal(result.ok, false);
  });

  test('rejects an unknown kind', () => {
    const result = parseProvenance(wrap(block('fact', 'Definitely true.')));
    assert.equal(result.ok, false);
    if (!result.ok) assert.match(result.reason, /unknown provenance kind/);
  });

  test('rejects a block with no text', () => {
    assert.equal(parseProvenance(wrap(block('recommendation', '   '))).ok, false);
  });

  test('rejects an empty or missing blocks array', () => {
    assert.equal(parseProvenance(JSON.stringify({ blocks: [] })).ok, false);
    assert.equal(parseProvenance(JSON.stringify({ answer: 'hi' })).ok, false);
  });

  test('REQUIRES a source on "retrieved" and "connected"', () => {
    // A claim that says it came from somewhere has to say where.
    assert.equal(parseProvenance(wrap(block('retrieved', 'From your site.'))).ok, false);
    assert.equal(parseProvenance(wrap(block('connected', 'From analytics.'))).ok, false);

    const withSource = parseProvenance(
      wrap(block('retrieved', 'From your site.', { type: 'page', id: 'p1' })),
    );
    assert.equal(withSource.ok, true);
  });

  test('rejects malformed input without throwing', () => {
    for (const bad of ['', '{', '[]', 'null', '{"blocks":"nope"}', JSON.stringify({ blocks: [1, 2] })]) {
      assert.equal(parseProvenance(bad).ok, false, `accepted: ${bad}`);
    }
  });

  test('rejects an absurd number of blocks', () => {
    const many = Array.from({ length: 500 }, () => block('recommendation', 'x'));
    assert.equal(parseProvenance(JSON.stringify({ blocks: many })).ok, false);
  });
});

describe('the claim linter', () => {
  test('a sourced statistic is fine', () => {
    // The user told us this. Repeating it is not a fabrication.
    const warnings = lintClaims([
      { kind: 'user_provided', text: 'Your average order value is ₹2,400.' },
    ]);
    assert.deepEqual(warnings, []);
  });

  test('an UNSOURCED statistic stated as fact is an ERROR', () => {
    const warnings = lintClaims([
      { kind: 'ai_inference', text: 'The Indian coffee market grew 18% last year.' },
    ]);
    assert.equal(warnings.length >= 1, true);
    assert.equal(warnings[0]?.severity, 'error');
  });

  test('a hedged estimate is a warning, not an error', () => {
    const warnings = lintClaims([
      { kind: 'ai_estimate', text: 'Roughly 20% of visitors might convert, but verify this.' },
    ]);
    assert.equal(warnings[0]?.severity, 'warning');
  });

  test('catches currency amounts', () => {
    const cases = [
      'Expect ₹50,000 in monthly revenue.',
      'The market is worth $4.2 billion.',
      'Budget Rs. 25000 per month.',
    ];
    for (const text of cases) {
      const warnings = lintClaims([{ kind: 'ai_inference', text }]);
      assert.ok(warnings.length > 0, `missed: ${text}`);
    }
  });

  test('catches invented studies and surveys', () => {
    const warnings = lintClaims([
      { kind: 'ai_inference', text: 'A study found that customers prefer local roasters.' },
    ]);
    assert.ok(warnings.some((w) => /study|survey/i.test(w.message) || w.severity === 'error'));
  });

  test('catches ranking claims', () => {
    const warnings = lintClaims([
      { kind: 'recommendation', text: 'Position yourself as the #1 roaster in the city.' },
    ]);
    assert.ok(warnings.length > 0);
  });

  test('catches multiplier claims', () => {
    const warnings = lintClaims([
      { kind: 'ai_inference', text: 'This will deliver 3x more engagement.' },
    ]);
    assert.ok(warnings.length > 0);
  });

  test('"unavailable" blocks are never linted', () => {
    // Saying "we do not have your 40% figure" is honest, not a claim.
    const warnings = lintClaims([
      { kind: 'unavailable', text: 'We do not have conversion data, so no 40% baseline exists.' },
    ]);
    assert.deepEqual(warnings, []);
  });

  test('ordinary prose produces no warnings', () => {
    const warnings = lintClaims([
      { kind: 'recommendation', text: 'Publish a short post each week about one drink.' },
      { kind: 'ai_inference', text: 'Your audience is likely to be time-poor on weekdays.' },
    ]);
    assert.deepEqual(warnings, []);
  });

  test('the warning names the offending excerpt', () => {
    const warnings = lintClaims([
      { kind: 'ai_inference', text: 'Some preamble. Conversion rates average 4.5% in this sector. More text.' },
    ]);
    assert.ok(warnings[0]?.excerpt.includes('4.5%'));
  });
});

describe('parse and lint together', () => {
  test('a response with a fabricated statistic parses but is NOT safe', () => {
    const result = parseProvenance(
      wrap(
        block('user_provided', 'You sell speciality coffee in Nagpur.'),
        block('ai_inference', 'The local market is worth ₹120 crore.'),
      ),
    );
    assert.equal(result.ok, true);
    if (!result.ok) return;

    // It parsed — the model followed the format. It is still not publishable.
    assert.equal(result.response.safe, false);
    assert.ok(result.response.warnings.some((w) => w.severity === 'error'));
  });

  test('a clean response is safe', () => {
    const result = parseProvenance(
      wrap(
        block('user_provided', 'You sell speciality coffee in Nagpur.'),
        block('recommendation', 'Lead with the roasting process, since that is what differs.'),
        block('unavailable', 'No footfall data is connected, so timing cannot be optimised yet.'),
      ),
    );
    assert.equal(result.ok, true);
    if (result.ok) {
      assert.equal(result.response.safe, true);
      assert.deepEqual(result.response.warnings, []);
    }
  });
});

describe('rendering', () => {
  const blocks: ProvenanceBlock[] = [
    { kind: 'user_provided', text: 'First.' },
    { kind: 'ai_estimate', text: 'Second.' },
  ];

  test('plain text has no labels, for clean copy and paste', () => {
    assert.equal(blocksToText(blocks), 'First.\n\nSecond.');
  });

  test('annotated text labels the unsourced blocks only', () => {
    const annotated = blocksToText(blocks, { annotate: true });
    assert.ok(!annotated.includes('[From you]'));
    assert.ok(annotated.includes('[AI estimate]'));
  });

  test('summarize counts every kind', () => {
    const counts = summarize(blocks);
    assert.equal(counts.user_provided, 1);
    assert.equal(counts.ai_estimate, 1);
    assert.equal(counts.recommendation, 0);
  });
});

describe('the prompt contract', () => {
  test('names every kind the parser accepts', () => {
    for (const kind of PROVENANCE_KINDS) {
      assert.ok(PROVENANCE_INSTRUCTION.includes(kind), `instruction omits "${kind}"`);
    }
  });

  test('forbids the specific fabrications the linter checks for', () => {
    for (const word of ['statistic', 'market size', 'percentage', 'study', 'survey', 'review', 'testimonial']) {
      assert.ok(
        PROVENANCE_INSTRUCTION.toLowerCase().includes(word),
        `instruction does not forbid inventing a ${word}`,
      );
    }
  });
});
