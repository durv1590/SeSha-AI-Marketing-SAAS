# SeSha AI Marketing — Phase 5 report

Schema Validator · Structured Data · Competitor Intelligence · Marketing Operations
Built on the stable Phase 4 codebase. Authentication, onboarding, the dashboard,
the AI layer and the crawler are unchanged and still pass their own suites.

Phase 5 does two quite different things. The first half rebuilds the
structured-data validator so it can tell four kinds of finding apart. The second
half adds the operational surfaces — competitors, ads, leads, messaging, video —
which share one property: **every one of them is a place where a product is
tempted to invent something.** Most of this report is about what each one refuses
to do.

---

## 1. The quality gate

Every line of the brief's fourteen-item gate is an executable assertion in
`tests/phase5-gate.test.ts`, one `describe` block per item, so the gate fails
loudly if the behaviour regresses rather than being ticked by hand.

| # | Gate item | Status | Where it is proven |
|---|---|---|---|
| 1 | Schema parser | **PASS** | `phase5-gate`, `schema-engine` · JSON-LD, Microdata and RDFa, no DOM library, no fetch; a broken block does not discard the others |
| 2 | Schema validator | **PASS** | `schema-engine` · 24 types, 6 statuses, 4 dimensions; every finding carries a path, a dimension and an explanation |
| 3 | Validation history | **PASS** | `schema-generate`, `phase5-gate` · every run stored with `validator_version`; comparison names a version change that would confound the diff |
| 4 | Corrected JSON-LD | **PASS** | `schema-engine` · before/after, visibly fake placeholders, and ratings/prices/credentials never filled in |
| 5 | Competitor analysis | **PASS** | `competitors` · 13 dimensions; verified observations carry a URL and a time; inference cannot be recorded as observation |
| 6 | Ads planning | **PASS** | `marketing-ops` · 5 platforms with real limits enforced before approval; no type can hold a performance measurement |
| 7 | Leads | **PASS** | `marketing-ops` · 7 stages, legal transitions only, every change logged; the score's parts sum to its total |
| 8 | Email | **PASS** | `marketing-ops` · 6 kinds; a marketing email with no unsubscribe is an **error**, not advice |
| 9 | WhatsApp planning | **PASS** | `marketing-ops` · 5 kinds, official template shape, category derived not chosen; no send path exists anywhere |
| 10 | Video | **PASS** | `marketing-ops` · hooks, scenes, shot list, voice-over, CTA, titles, tags, thumbnail briefs; durations summed against the platform limit |
| 11 | Provenance | **PASS** | `schema-generate`, `competitors` · every generated value names the field it came from; every finding carries evidence |
| 12 | No fabricated facts | **PASS** | `phase5-gate` · see §4 — the string scan, the never-invent list and the competitor linter |
| 13 | Security tests | **PASS** | `phase5-gate`, `competitors` · see §5 |
| 14 | Production build | **PASS** | no new dependency; 52 route handlers; `db/schema.sql` matches the migrations. The build itself still cannot run here — see §7 |

The "no delivered phase is still advertised as upcoming" block from Phase 4 was
carried forward with `DELIVERED` bumped to 5, and it caught three stale promises
the moment Phase 5 shipped. See §6.

---

## 2. What was built

**The validation engine** (`lib/schema-validator`, 7 modules) — `types` (statuses
and dimensions), `registry` (24 types with four separate kinds of expectation),
`parse` (three syntaxes, one node shape), `datatypes`, `engine` (every check),
`correct` (before/after and the refusals), `validate` (the Phase 1 public tool's
shape, now a projection of the same engine).

**One engine, not two.** The public tool at `/schema-validator` and the workspace
screen run the same code. Two validators answering the same question two ways is a
defect waiting to be reported by a user, so `validate.ts` became a thin adapter
and `tests/schema-validator.test.ts` is now its contract test.

**Generation** (`lib/schema/generate.ts`) — eight kinds built only from verified
business and crawl data, returning three lists: included, omitted, refused.

**Competitors** (`lib/competitors`) — 13 dimensions, a two-variant `Evidence`
union, a narrow three-page fetch policy on the crawler's own safe path, and an
acknowledgement record shaped exactly like crawl consent.

**Ads** (`lib/ads`) — five platforms with dated specifications, a plan covering
every element the brief lists, and a budget type that cannot hold a measurement.

**Leads** (`lib/leads`) — seven stages, `canTransition`, a transparent rule-based
score, activities and follow-ups in one table.

**Messaging** (`lib/messaging`) — six email kinds, five WhatsApp kinds, official
template shape, lawful-basis enforcement.

**Video** (`lib/video`) — four platforms, scene-level scripts, written thumbnail
briefs.

**Storage** — migration `0005` adds eight tables and **alters the existing `leads`
table in place**; 40 tables total, all with row-level security.

**Routes** — 14 new handlers under `/api/schema`, `/api/competitors`, `/api/ads`,
`/api/leads`, `/api/messaging`, `/api/video`.

**Screens** — `/app/schema-validator` (rebuilt), `/app/competitors`,
`/app/campaigns`, `/app/leads`, `/app/messaging`, `/app/video`. The workspace now
has 16 of 20 areas live.

**Dependencies added: none.** Still four in production — in the phase that reads
three markup syntaxes and parses HTML.

---

## 3. The distinction the brief asked for

> Clearly distinguish schema.org validity from search-engine eligibility from
> general SEO guidance from AI/AEO clarity. Do not represent one as another.

A validator that reports these in one list of "errors" has already broken that
rule, whatever each row says, because a reader takes "12 issues" as one number
about one thing. So the implementation is not a label on a row — it is a
**required field on every issue**, with no default:

| Dimension | May claim | Never claims |
|---|---|---|
| `SCHEMA_VALIDITY` | facts about the document | — |
| `SEARCH_ELIGIBILITY` | what published documentation asks for, **with the date it was reviewed** | that a rich result will appear |
| `SEO_GUIDANCE` | ordinary on-page advice | that ignoring it makes the markup invalid |
| `AEO_CLARITY` | whether facts are stated unambiguously | that an AI system will read or cite the page |

The UI groups by dimension, each group carries the sentence saying what it may
claim, and **there is no combined issue total anywhere on the screen**. The page
audit asserts all four headings render, because a merged list would pass every
other check while undoing the whole point.

`NOT_EVALUATED` is the other half of the honesty: image dimensions are not checked
(that needs a fetch), the canonical is not checked unless a crawl supplied one,
and whether a rich result appears is never checked because it cannot be. All three
are emitted as findings and rendered, because the absence of a finding otherwise
reads as a pass.

One reclassification is worth naming: **a missing `datePublished` on an Article
moved from error to warning.** Schema.org does not require it; published search
documentation asks for it. The finding did not get weaker — it got honest about
which kind of fact it is. The legacy test that asserted "error" was updated with
that explanation rather than the classification being bent to fit it.

---

## 4. The refusals

| It will not | Enforced by |
|---|---|
| Generate a rating, review, price, availability, award, certification or credential | `NEVER_INVENT_PROPERTIES`; each refusal returned with a reason specific to the property |
| Fill a correction's gap with a plausible value | `<add …>` placeholders — and no placeholder at all for the properties above, because `"ratingValue": "<add>"` is one find-and-replace from a fabricated rating |
| Promise a rich result, a ranking or an AI citation | a test scans every explanation string the engine can emit, not just the ones a sample document happens to produce |
| State a competitor's revenue, spend, traffic, customers, followers, conversion rate or ranking | `lintCompetitorFindings` **drops** the finding |
| Record a model's conclusion as an observation | `Evidence` is a union whose verified variant cannot be constructed without a source URL and a time; `withInferences()` forces `ai_inference` regardless of what the caller passed |
| Show an ad performance figure | `BudgetRecommendation` has no variant that can hold a measurement |
| Show a lead score without its reasoning | components stored with the score; a database `CHECK` refuses one without them |
| Plan a campaign to a bought or scraped list | refused before validation, not stored as a draft, and the database `CHECK` cannot hold the value |
| Send an email or a WhatsApp message | no send path exists; no `sent_at` column exists |
| Produce an image | `ThumbnailConcept` has no image field; `video_scripts` has no image column |

The competitor linter has one exemption: a figure **quoted from the competitor's
own page**. It applies only when the numbers in the statement actually appear in
the quote — without that condition the exemption would be wide enough to drive
every fabricated number through, and there is a test for exactly that case.

---

## 5. The security argument

**Competitor research is the new attack surface, and it reuses the old defences.**
A competitor cannot consent to being read, so:

- the fetch goes through `safeFetch` — SSRF checks, DNS pinning, redirect
  re-validation, size and time limits — **unchanged**. A second fetch path with
  its own weaker rules is how a second SSRF hole arrives.
- robots.txt is consulted and **fails closed**: a 5xx or a timeout means nothing
  is read at all.
- at most three pages, one request at a time, with a two-second gap.
- a competitor URL pointing at a private address is refused at entry, by the same
  `checkUrl` the crawler uses.
- the customer's acknowledgement is checked when the analysis is requested **and
  again immediately before the first request**, because a withdrawal lands in
  between. It is referenced `ON DELETE RESTRICT`, exactly as crawl consent is.
- **page content is never stored.** There is no column for it, and a test asserts
  the stored row contains neither markup nor page text.

**The validator makes no network requests at all.** `@context` is checked as a
string and never dereferenced — fetching a URL out of a document a stranger pasted
would rebuild the crawler's whole threat model inside a validation endpoint. A
page-URL validation reads the copy the crawler already took under the project's
own consent.

Structural rules enforced by tests over the source tree: no Phase 5 module imports
`node:http`, `node:https`, `node:dns` or `node:net`; no client component imports a
service or the database; every new table has row-level security; and no function
named like a sender exists anywhere in `src`.

---

## 6. Defects found and fixed

**`ImageObject` required `contentUrl`, which reported correct markup as invalid.**
Schema.org permits `url` on any Thing, and `{ "@type": "ImageObject", "url": … }`
is the commonest form in the wild. Now a one-of rule.

**Every nested Organization was held to the publisher's requirements.** An
article whose author is `{ "@type": "Organization", "name": "Editorial Team" }` is
correct markup, and telling the user their editorial team needs a logo, a URL and
a contact point is noise — which is how users learn to ignore findings. Node
roles were introduced so search requirements apply only where they mean something.

**The rating-honesty warning only fired for `Product`** — the node a fabricated
rating is *least* often attached to. It is now keyed on the property, so a rating
published on an Article, a Service or a LocalBusiness gets it too.

**`http://schema.org` was silently treated as canonical**, and a bare enum token
produced no note at all. Both are now recommendations.

**`localhost` was reported as invalid.** It is the correct value while developing;
what matters is that it must not be published, which is what the advisory now
says. A validator that calls `http://localhost:3000` invalid is wrong about the
most common development setup there is.

**A second validation in the same millisecond lost its comparison.** The
previous-run lookup used a strict `<` against a timestamp taken before the new row
was stored. Now `<=`, with the reasoning recorded in the code.

**Twelve registry properties had no data-type rule**, so findings about them
arrived with no corrected example. Found by a test that walks every type's
property list rather than by inspection.

**`won → lost` was refused.** A won deal that later cancels is ordinary, and the
stage-change activity preserves the history either way. `lost → won` is still
refused — that is the same edit with the evidence removed.

**All six new screens jumped from `h1` to `h3`.** A real accessibility defect,
caught by the page audit, fixed by giving the top-level cards `as="h2"`.

**Three stale phase promises.** Four "Soon" screens and nine agent definitions
still pointed at Phase 5 the moment Phase 5 shipped. The guard added in Phase 4
caught all of them; they now point at Phase 6, and the `seo`, `aeo`, `ads`, `lead`
and `competitor` agents say plainly which part of their job already shipped
rule-based and which part they would add.

Two test defects are worth recording because they were mistakes in the
*verification* rather than the product: an advertising assertion flagged the
honest disclaimer "what they spend … cannot be seen from outside" because it
contained the word "spend" (it now looks for a figure, not a word — the earlier
version would have pushed the fix in exactly the wrong direction), and a gate test
passed an invalid generator kind through `as never`.

---

## 7. Verification status

Unchanged constraint: **the npm registry is unreachable** from the build
environment (`registry.npmjs.org` returns 403 at the gateway). `npm install`,
`next build`, `next lint` and Playwright have never run, in any phase.

| Check | Result |
|---|---|
| Unit tests | **1339 passing, 0 failing** (261 suites) |
| Real `tsc`, strict + `noUncheckedIndexedAccess`, every `.ts` file | **182 files, PASS** |
| Static verification (syntax, imports, exports, RSC boundary, route conventions) | **260 files, PASS** |
| Component render assertions against real HTML | **49 passing** |
| Whole-page render audit | **53 surfaces, 0 problems** |
| `db/schema.sql` matches the migrations | **PASS, 40 tables** |

Phase 5's own suites: `schema-engine` 101, `marketing-ops` 81, `phase5-gate` 56,
`competitors` 30, `schema-generate` 21, and `schema-validator` 31 (the legacy
contract, now running on the new engine).

Two page-audit additions check something no unit test can: that the validation
report **renders all four dimension headings**, and that no screen implies the
product sends messages, spends money or generates images.

**Mutation testing.** Three defects were introduced deliberately and all three
were caught: removing the bought-list refusal (3 failures), removing the second
acknowledgement check (1), and making the generator emit an `aggregateRating` (1).

### Still not verified — run these first

| Check | How to run |
|---|---|
| Type checking of `.tsx` files (needs `@types/react`) | `npm run typecheck` |
| Lint | `npm run lint` |
| Production build | `npm run build` |
| Browser behaviour | `npm run test:e2e` |
| Visual appearance (Tailwind was never compiled here) | `npm run dev` |

A type error inside a `.tsx` component remains the most likely first-build
failure. Phase 5 added ten components, which is the largest `.tsx` addition since
Phase 3 — they are covered by execution (server-rendered and audited) but not by
the type checker.

### Before going live with Phase 5 features

- **`deleteExpiredCrawlData` still has no scheduler** (carried from Phase 4).
- **Competitor analyses have no retention rule.** Findings about third parties are
  kept indefinitely; decide a retention period before storing real ones.
- **The search-eligibility rules are dated `2026-05`.** Re-read the platforms'
  published documentation and bump `SEARCH_RULES_AS_OF`, `AD_SPECS_AS_OF`,
  `EMAIL_LIMITS_AS_OF`, `WHATSAPP_LIMITS_AS_OF` and `VIDEO_SPECS_AS_OF` when you
  do. They are dated precisely so this is a deliberate act rather than a silent
  drift.

---

## 8. Stopping here

Phase 5 is complete. **Phase 6 has not been started**, per the phased development
instruction. ARCHITECTURE.md §62 lists the seams: `BudgetRecommendation` gains a
`measured` variant when an ad account is connected, `sendingStatus()` is the
single gate for a real provider, `imageGenerationStatus()` for a real image API,
and `withInferences()` is the labelled entry point for the AI half of competitor
analysis.

One thing deliberately not built: **automated sending of anything.** The brief
said official APIs only and no unauthorised spam. The strongest form of that is
that no function capable of sending exists in the codebase at all — which is what
`tests/phase5-gate.test.ts` asserts, and what makes the promise checkable rather
than a matter of trust.
